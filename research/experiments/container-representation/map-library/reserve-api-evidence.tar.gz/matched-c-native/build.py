from pathlib import Path
import hashlib,json,os,platform,subprocess,time
D=Path(__file__).resolve().parent; P=D.parent/'paired-image'; H=D.parents[2]
LLVM=Path('<llvm-toolchain-root>/bin')
assert os.environ.get('WHITEFOOT_CHECK_OWNER'), 'run through run-check.pl'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
records=[]
def run(name,args):
 start=time.monotonic()
 with (D/(name+'.stdout')).open('wb') as out,(D/(name+'.stderr')).open('wb') as err:
  result=subprocess.run(args,cwd=H,stdout=out,stderr=err)
 row={'stage':name,'argv':args,'exit':result.returncode,'wall_s':time.monotonic()-start}
 records.append(row);(D/'build-statuses.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps(row),flush=True)
 assert result.returncode==0,name
original=json.loads((P/'link-commands.json').read_text())['paired'];links={}
for mode in ('timed','account'):
 args=original[mode].copy()
 args.remove(str(P/f'wf-b-{mode}.o'))
 args[args.index(str(P/f'driver-{mode}.o'))]=str(D/f'driver-{mode}.o')
 args.insert(args.index(str(P/f'wf-a-{mode}.o')),str(D/f'c-{mode}.o'))
 args[-1]=str(D/f'matched-{mode}');links[mode]=args
inputs={}
for args in links.values():
 for arg in args:
  p=Path(arg)
  if arg.endswith(('.o','.a')) and p.parent!=D:inputs[arg]=sha(p)
for p in [D/'criterion.txt',D/'integration.txt',D/'matched-reserve.c',D/'driver.c',D/'build.py',D/'checks.py',H/'map-oracle.h',P/'link-commands.json']:
 inputs[str(p)]=sha(p)
(D/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
(D/'metadata.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=H,text=True).strip(),'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'platform':platform.platform(),'clang':subprocess.check_output(['clang','--version'],text=True),'preparation_only_before_root_authorization':True},indent=2)+'\n')
for mode in ('timed','account'):
 flags=['clang','-O3','-std=c11','-Wall','-Wextra','-Werror']+(['-DACCOUNT_ONLY'] if mode=='account' else [])
 run('compile-c-'+mode,flags+['-c',str(D/'matched-reserve.c'),'-o',str(D/f'c-{mode}.o')])
 run('compile-driver-'+mode,flags+['-I',str(H),'-c',str(D/'driver.c'),'-o',str(D/f'driver-{mode}.o')])
 run('link-'+mode,links[mode])
(D/'link-commands.json').write_text(json.dumps(links,indent=2)+'\n')
run('native',[str(LLVM/'llvm-objdump'),'--disassemble','--no-show-raw-insn',str(D/'matched-timed')])
run('symbols',[str(LLVM/'llvm-nm'),'-n',str(D/'matched-timed')])
for path,digest in inputs.items():assert sha(path)==digest,('input changed',path)
(D/'images.json').write_text(json.dumps({mode:sha(D/f'matched-{mode}') for mode in ('timed','account')},indent=2)+'\n')
print('BUILD COMPLETE; correctness/native review outstanding; no timing',flush=True)
