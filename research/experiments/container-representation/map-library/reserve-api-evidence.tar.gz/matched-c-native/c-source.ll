; ModuleID = 'research/experiments/container-representation/map-library/.build/reserve-api/matched-c/matched-reserve.c'
source_filename = "research/experiments/container-representation/map-library/.build/reserve-api/matched-c/matched-reserve.c"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx26.0.0"

%struct.word_Owner = type { %struct.word_Map, %struct.Env, i64, i64 }
%struct.word_Map = type { i64, i64, ptr, i64, i64 }
%struct.Env = type { i64, i8 }
%struct.word_Put = type { i32, i8, %struct.word_Pair }
%struct.word_Pair = type { i64, i64 }
%struct.word_Cell = type { i32, %struct.word_Pair }
%struct.Digest = type { i64, i64, i64, i64 }
%struct.record_Owner = type { %struct.record_Map, %struct.Env, i64, i64 }
%struct.record_Map = type { i64, i64, ptr, i64, i64 }
%struct.record_Put = type { i32, i8, %struct.record_Pair }
%struct.record_Pair = type { i64, %struct.Record }
%struct.Record = type { [32 x i64] }
%struct.record_Cell = type { i32, %struct.record_Pair }

@.str = private unnamed_addr constant [25 x i8] c"prepared fresh insertion\00", align 1
@.str.1 = private unnamed_addr constant [26 x i8] c"physical capacity ceiling\00", align 1
@empty_anchor = internal global [8 x i8] zeroinitializer, align 8
@.str.2 = private unnamed_addr constant [11 x i8] c"allocation\00", align 1
@__stderrp = external global ptr, align 8
@.str.3 = private unnamed_addr constant [21 x i8] c"matched reserve: %s\0A\00", align 1

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define void @eco_c_map_reserve_word_prepare(ptr noundef %0, i64 noundef %1, i64 noundef %2, i64 noundef %3) #0 {
  %5 = alloca ptr, align 8
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  %8 = alloca i64, align 8
  %9 = alloca ptr, align 8
  %10 = alloca %struct.word_Owner, align 8
  %11 = alloca i64, align 8
  %12 = alloca %struct.word_Put, align 8
  %13 = alloca %struct.word_Pair, align 8
  store ptr %0, ptr %5, align 8
  store i64 %1, ptr %6, align 8
  store i64 %2, ptr %7, align 8
  store i64 %3, ptr %8, align 8
  %14 = load ptr, ptr %5, align 8
  store ptr %14, ptr %9, align 8
  %15 = load ptr, ptr %9, align 8
  %16 = getelementptr inbounds nuw %struct.word_Owner, ptr %10, i32 0, i32 0
  %17 = load i64, ptr %6, align 8
  %18 = call i64 @slots(i64 noundef %17)
  call void @word_new(ptr dead_on_unwind writable sret(%struct.word_Map) align 8 %16, i64 noundef %18)
  %19 = getelementptr inbounds nuw %struct.word_Owner, ptr %10, i32 0, i32 1
  %20 = getelementptr inbounds nuw %struct.Env, ptr %19, i32 0, i32 0
  %21 = load i64, ptr %8, align 8
  %22 = xor i64 %21, -7046029254386353131
  store i64 %22, ptr %20, align 8
  %23 = getelementptr inbounds nuw %struct.Env, ptr %19, i32 0, i32 1
  store i8 0, ptr %23, align 8
  %24 = getelementptr i8, ptr %19, i64 9
  call void @llvm.memset.p0.i64(ptr align 1 %24, i8 0, i64 7, i1 false)
  %25 = getelementptr inbounds nuw %struct.word_Owner, ptr %10, i32 0, i32 2
  %26 = load i64, ptr %8, align 8
  store i64 %26, ptr %25, align 8
  %27 = getelementptr inbounds nuw %struct.word_Owner, ptr %10, i32 0, i32 3
  %28 = load i64, ptr %7, align 8
  store i64 %28, ptr %27, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %15, ptr align 8 %10, i64 72, i1 false)
  store i64 0, ptr %11, align 8
  br label %29

29:                                               ; preds = %51, %4
  %30 = load i64, ptr %11, align 8
  %31 = load i64, ptr %7, align 8
  %32 = icmp ult i64 %30, %31
  br i1 %32, label %33, label %54

33:                                               ; preds = %29
  %34 = load ptr, ptr %9, align 8
  %35 = getelementptr inbounds nuw %struct.word_Owner, ptr %34, i32 0, i32 0
  %36 = load ptr, ptr %9, align 8
  %37 = getelementptr inbounds nuw %struct.word_Owner, ptr %36, i32 0, i32 1
  %38 = getelementptr inbounds nuw %struct.word_Pair, ptr %13, i32 0, i32 0
  %39 = load i64, ptr %11, align 8
  %40 = mul i64 %39, 2
  %41 = add i64 %40, 1
  store i64 %41, ptr %38, align 8
  %42 = getelementptr inbounds nuw %struct.word_Pair, ptr %13, i32 0, i32 1
  %43 = load i64, ptr %8, align 8
  %44 = load i64, ptr %11, align 8
  %45 = add i64 %43, %44
  %46 = call i64 @word_make(i64 noundef %45)
  store i64 %46, ptr %42, align 8
  %47 = load [2 x i64], ptr %13, align 8
  call void @word_put(ptr dead_on_unwind writable sret(%struct.word_Put) align 8 %12, ptr noundef %35, ptr noundef %37, [2 x i64] %47)
  %48 = getelementptr inbounds nuw %struct.word_Put, ptr %12, i32 0, i32 0
  %49 = load i32, ptr %48, align 8
  %50 = icmp eq i32 %49, 0
  call void @require(i1 noundef zeroext %50, ptr noundef @.str)
  br label %51

51:                                               ; preds = %33
  %52 = load i64, ptr %11, align 8
  %53 = add i64 %52, 1
  store i64 %53, ptr %11, align 8
  br label %29, !llvm.loop !6

54:                                               ; preds = %29
  ret void
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal void @word_new(ptr dead_on_unwind noalias writable sret(%struct.word_Map) align 8 %0, i64 noundef %1) #0 {
  %3 = alloca i64, align 8
  %4 = alloca ptr, align 8
  %5 = alloca i64, align 8
  %6 = alloca %struct.word_Cell, align 8
  store i64 %1, ptr %3, align 8
  %7 = load i64, ptr %3, align 8
  %8 = icmp ule i64 %7, 16384
  call void @require(i1 noundef zeroext %8, ptr noundef @.str.1)
  %9 = load i64, ptr %3, align 8
  %10 = icmp ne i64 %9, 0
  br i1 %10, label %11, label %15

11:                                               ; preds = %2
  %12 = load i64, ptr %3, align 8
  %13 = mul i64 %12, 24
  %14 = call ptr @malloc(i64 noundef %13) #8
  br label %16

15:                                               ; preds = %2
  br label %16

16:                                               ; preds = %15, %11
  %17 = phi ptr [ %14, %11 ], [ @empty_anchor, %15 ]
  store ptr %17, ptr %4, align 8
  %18 = load ptr, ptr %4, align 8
  %19 = icmp ne ptr %18, null
  call void @require(i1 noundef zeroext %19, ptr noundef @.str.2)
  store i64 0, ptr %5, align 8
  br label %20

20:                                               ; preds = %30, %16
  %21 = load i64, ptr %5, align 8
  %22 = load i64, ptr %3, align 8
  %23 = icmp ult i64 %21, %22
  br i1 %23, label %24, label %33

24:                                               ; preds = %20
  %25 = load ptr, ptr %4, align 8
  %26 = load i64, ptr %5, align 8
  %27 = getelementptr inbounds nuw %struct.word_Cell, ptr %25, i64 %26
  call void @llvm.memset.p0.i64(ptr align 8 %6, i8 0, i64 24, i1 false)
  %28 = getelementptr inbounds nuw %struct.word_Cell, ptr %6, i32 0, i32 0
  %29 = getelementptr inbounds nuw %struct.word_Cell, ptr %6, i32 0, i32 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %27, ptr align 8 %6, i64 24, i1 false)
  br label %30

30:                                               ; preds = %24
  %31 = load i64, ptr %5, align 8
  %32 = add i64 %31, 1
  store i64 %32, ptr %5, align 8
  br label %20, !llvm.loop !8

33:                                               ; preds = %20
  %34 = getelementptr inbounds nuw %struct.word_Map, ptr %0, i32 0, i32 0
  %35 = load i64, ptr %3, align 8
  store i64 %35, ptr %34, align 8
  %36 = getelementptr inbounds nuw %struct.word_Map, ptr %0, i32 0, i32 1
  %37 = load i64, ptr %3, align 8
  store i64 %37, ptr %36, align 8
  %38 = getelementptr inbounds nuw %struct.word_Map, ptr %0, i32 0, i32 2
  %39 = load ptr, ptr %4, align 8
  store ptr %39, ptr %38, align 8
  %40 = getelementptr inbounds nuw %struct.word_Map, ptr %0, i32 0, i32 3
  store i64 0, ptr %40, align 8
  %41 = getelementptr inbounds nuw %struct.word_Map, ptr %0, i32 0, i32 4
  store i64 0, ptr %41, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal i64 @slots(i64 noundef %0) #0 {
  %2 = alloca i64, align 8
  store i64 %0, ptr %2, align 8
  %3 = load i64, ptr %2, align 8
  %4 = icmp eq i64 %3, 0
  br i1 %4, label %8, label %5

5:                                                ; preds = %1
  %6 = load i64, ptr %2, align 8
  %7 = icmp ugt i64 %6, 8192
  br i1 %7, label %8, label %9

8:                                                ; preds = %5, %1
  br label %15

9:                                                ; preds = %5
  %10 = load i64, ptr %2, align 8
  %11 = sub i64 %10, 1
  %12 = mul i64 4, %11
  %13 = udiv i64 %12, 3
  %14 = add i64 %13, 1
  br label %15

15:                                               ; preds = %9, %8
  %16 = phi i64 [ 0, %8 ], [ %14, %9 ]
  ret i64 %16
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #1

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #2

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal void @word_put(ptr dead_on_unwind noalias writable sret(%struct.word_Put) align 8 %0, ptr noundef %1, ptr noundef %2, [2 x i64] %3) #0 {
  %5 = alloca %struct.word_Pair, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca i64, align 8
  %9 = alloca i64, align 8
  %10 = alloca i64, align 8
  %11 = alloca i64, align 8
  store [2 x i64] %3, ptr %5, align 8
  store ptr %1, ptr %6, align 8
  store ptr %2, ptr %7, align 8
  %12 = load ptr, ptr %6, align 8
  %13 = getelementptr inbounds nuw %struct.word_Map, ptr %12, i32 0, i32 0
  %14 = load i64, ptr %13, align 8
  store i64 %14, ptr %8, align 8
  %15 = load i64, ptr %8, align 8
  %16 = load i64, ptr %8, align 8
  %17 = udiv i64 %16, 4
  %18 = sub i64 %15, %17
  store i64 %18, ptr %9, align 8
  %19 = load ptr, ptr %6, align 8
  %20 = getelementptr inbounds nuw %struct.word_Map, ptr %19, i32 0, i32 3
  %21 = load i64, ptr %20, align 8
  %22 = sub i64 -1, %21
  %23 = load ptr, ptr %6, align 8
  %24 = getelementptr inbounds nuw %struct.word_Map, ptr %23, i32 0, i32 4
  %25 = load i64, ptr %24, align 8
  %26 = icmp ult i64 %22, %25
  br i1 %26, label %27, label %28

27:                                               ; preds = %4
  br label %36

28:                                               ; preds = %4
  %29 = load ptr, ptr %6, align 8
  %30 = getelementptr inbounds nuw %struct.word_Map, ptr %29, i32 0, i32 3
  %31 = load i64, ptr %30, align 8
  %32 = load ptr, ptr %6, align 8
  %33 = getelementptr inbounds nuw %struct.word_Map, ptr %32, i32 0, i32 4
  %34 = load i64, ptr %33, align 8
  %35 = add i64 %31, %34
  br label %36

36:                                               ; preds = %28, %27
  %37 = phi i64 [ -1, %27 ], [ %35, %28 ]
  store i64 %37, ptr %10, align 8
  %38 = load i64, ptr %10, align 8
  %39 = load i64, ptr %9, align 8
  %40 = icmp uge i64 %38, %39
  br i1 %40, label %41, label %70

41:                                               ; preds = %36
  %42 = load i64, ptr %8, align 8
  %43 = icmp ult i64 %42, 16384
  br i1 %43, label %44, label %70

44:                                               ; preds = %41
  store i64 16384, ptr %11, align 8
  %45 = load ptr, ptr %6, align 8
  %46 = getelementptr inbounds nuw %struct.word_Map, ptr %45, i32 0, i32 3
  %47 = load i64, ptr %46, align 8
  %48 = load i64, ptr %9, align 8
  %49 = udiv i64 %48, 2
  %50 = icmp ult i64 %47, %49
  br i1 %50, label %51, label %53

51:                                               ; preds = %44
  %52 = load i64, ptr %8, align 8
  store i64 %52, ptr %11, align 8
  br label %65

53:                                               ; preds = %44
  %54 = load i64, ptr %8, align 8
  %55 = icmp eq i64 %54, 0
  br i1 %55, label %56, label %57

56:                                               ; preds = %53
  store i64 1, ptr %11, align 8
  br label %64

57:                                               ; preds = %53
  %58 = load i64, ptr %8, align 8
  %59 = icmp ule i64 %58, 8192
  br i1 %59, label %60, label %63

60:                                               ; preds = %57
  %61 = load i64, ptr %8, align 8
  %62 = mul i64 %61, 2
  store i64 %62, ptr %11, align 8
  br label %63

63:                                               ; preds = %60, %57
  br label %64

64:                                               ; preds = %63, %56
  br label %65

65:                                               ; preds = %64, %51
  %66 = load ptr, ptr %6, align 8
  %67 = load i64, ptr %11, align 8
  %68 = load ptr, ptr %7, align 8
  %69 = call zeroext i1 @word_rebuild(ptr noundef %66, i64 noundef %67, ptr noundef %68)
  br label %70

70:                                               ; preds = %65, %41, %36
  %71 = load ptr, ptr %6, align 8
  %72 = load ptr, ptr %7, align 8
  %73 = load [2 x i64], ptr %5, align 8
  call void @word_try_put(ptr dead_on_unwind writable sret(%struct.word_Put) align 8 %0, ptr noundef %71, ptr noundef %72, [2 x i64] %73)
  ret void
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal i64 @word_make(i64 noundef %0) #0 {
  %2 = alloca i64, align 8
  store i64 %0, ptr %2, align 8
  %3 = load i64, ptr %2, align 8
  ret i64 %3
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal void @require(i1 noundef zeroext %0, ptr noundef %1) #0 {
  %3 = alloca i8, align 1
  %4 = alloca ptr, align 8
  %5 = zext i1 %0 to i8
  store i8 %5, ptr %3, align 1
  store ptr %1, ptr %4, align 8
  %6 = load i8, ptr %3, align 1
  %7 = trunc i8 %6 to i1
  br i1 %7, label %12, label %8

8:                                                ; preds = %2
  %9 = load ptr, ptr @__stderrp, align 8
  %10 = load ptr, ptr %4, align 8
  %11 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %9, ptr noundef @.str.3, ptr noundef %10) #9
  call void @exit(i32 noundef 1) #10
  unreachable

12:                                               ; preds = %2
  ret void
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define i64 @eco_c_map_reserve_word_raw(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %6 = load ptr, ptr %3, align 8
  store ptr %6, ptr %5, align 8
  %7 = load ptr, ptr %5, align 8
  %8 = getelementptr inbounds nuw %struct.word_Owner, ptr %7, i32 0, i32 0
  %9 = load i64, ptr %4, align 8
  %10 = load ptr, ptr %5, align 8
  %11 = getelementptr inbounds nuw %struct.word_Owner, ptr %10, i32 0, i32 1
  %12 = call zeroext i1 @word_reserve(ptr noundef %8, i64 noundef %9, ptr noundef %11)
  %13 = zext i1 %12 to i64
  ret i64 %13
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal zeroext i1 @word_reserve(ptr noundef %0, i64 noundef %1, ptr noundef %2) #0 {
  %4 = alloca i1, align 1
  %5 = alloca ptr, align 8
  %6 = alloca i64, align 8
  %7 = alloca ptr, align 8
  store ptr %0, ptr %5, align 8
  store i64 %1, ptr %6, align 8
  store ptr %2, ptr %7, align 8
  %8 = load i64, ptr %6, align 8
  %9 = icmp ugt i64 %8, 16384
  br i1 %9, label %10, label %11

10:                                               ; preds = %3
  store i1 false, ptr %4, align 1
  br label %23

11:                                               ; preds = %3
  %12 = load i64, ptr %6, align 8
  %13 = load ptr, ptr %5, align 8
  %14 = getelementptr inbounds nuw %struct.word_Map, ptr %13, i32 0, i32 0
  %15 = load i64, ptr %14, align 8
  %16 = icmp ule i64 %12, %15
  br i1 %16, label %17, label %18

17:                                               ; preds = %11
  store i1 true, ptr %4, align 1
  br label %23

18:                                               ; preds = %11
  %19 = load ptr, ptr %5, align 8
  %20 = load i64, ptr %6, align 8
  %21 = load ptr, ptr %7, align 8
  %22 = call zeroext i1 @word_rebuild(ptr noundef %19, i64 noundef %20, ptr noundef %21)
  store i1 %22, ptr %4, align 1
  br label %23

23:                                               ; preds = %18, %17, %10
  %24 = load i1, ptr %4, align 1
  ret i1 %24
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define i64 @eco_c_map_reserve_word_step(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = load i64, ptr %4, align 8
  %7 = call i64 @slots(i64 noundef %6)
  %8 = call i64 @eco_c_map_reserve_word_raw(ptr noundef %5, i64 noundef %7)
  ret i64 %8
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define i64 @eco_c_map_reserve_word_geometry(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %4 = load ptr, ptr %2, align 8
  store ptr %4, ptr %3, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = getelementptr inbounds nuw %struct.word_Owner, ptr %5, i32 0, i32 0
  %7 = getelementptr inbounds nuw %struct.word_Map, ptr %6, i32 0, i32 0
  %8 = load i64, ptr %7, align 8
  %9 = shl i64 %8, 32
  %10 = load ptr, ptr %3, align 8
  %11 = getelementptr inbounds nuw %struct.word_Owner, ptr %10, i32 0, i32 0
  %12 = getelementptr inbounds nuw %struct.word_Map, ptr %11, i32 0, i32 3
  %13 = load i64, ptr %12, align 8
  %14 = add i64 %9, %13
  ret i64 %14
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define i64 @eco_c_map_reserve_word_insert(ptr noundef %0, i64 noundef %1, i64 noundef %2) #0 {
  %4 = alloca i64, align 8
  %5 = alloca ptr, align 8
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  %8 = alloca ptr, align 8
  %9 = alloca i64, align 8
  %10 = alloca %struct.word_Put, align 8
  %11 = alloca %struct.word_Pair, align 8
  store ptr %0, ptr %5, align 8
  store i64 %1, ptr %6, align 8
  store i64 %2, ptr %7, align 8
  %12 = load ptr, ptr %5, align 8
  store ptr %12, ptr %8, align 8
  %13 = load ptr, ptr %8, align 8
  %14 = getelementptr inbounds nuw %struct.word_Owner, ptr %13, i32 0, i32 2
  %15 = load i64, ptr %14, align 8
  %16 = load i64, ptr %6, align 8
  %17 = add i64 %15, %16
  %18 = call i64 @word_make(i64 noundef %17)
  store i64 %18, ptr %9, align 8
  %19 = load i64, ptr %7, align 8
  %20 = icmp ne i64 %19, 0
  br i1 %20, label %21, label %22

21:                                               ; preds = %3
  call void @word_damage(ptr noundef %9)
  br label %22

22:                                               ; preds = %21, %3
  %23 = load ptr, ptr %8, align 8
  %24 = getelementptr inbounds nuw %struct.word_Owner, ptr %23, i32 0, i32 0
  %25 = load ptr, ptr %8, align 8
  %26 = getelementptr inbounds nuw %struct.word_Owner, ptr %25, i32 0, i32 1
  %27 = getelementptr inbounds nuw %struct.word_Pair, ptr %11, i32 0, i32 0
  %28 = load i64, ptr %6, align 8
  %29 = mul i64 %28, 2
  %30 = add i64 %29, 1
  store i64 %30, ptr %27, align 8
  %31 = getelementptr inbounds nuw %struct.word_Pair, ptr %11, i32 0, i32 1
  %32 = load i64, ptr %9, align 8
  store i64 %32, ptr %31, align 8
  %33 = load [2 x i64], ptr %11, align 8
  call void @word_put(ptr dead_on_unwind writable sret(%struct.word_Put) align 8 %10, ptr noundef %24, ptr noundef %26, [2 x i64] %33)
  %34 = getelementptr inbounds nuw %struct.word_Put, ptr %10, i32 0, i32 0
  %35 = load i32, ptr %34, align 8
  %36 = icmp ne i32 %35, 0
  br i1 %36, label %37, label %45

37:                                               ; preds = %22
  %38 = getelementptr inbounds nuw %struct.word_Put, ptr %10, i32 0, i32 2
  %39 = getelementptr inbounds nuw %struct.word_Pair, ptr %38, i32 0, i32 0
  %40 = load i64, ptr %39, align 8
  %41 = getelementptr inbounds nuw %struct.word_Put, ptr %10, i32 0, i32 2
  %42 = getelementptr inbounds nuw %struct.word_Pair, ptr %41, i32 0, i32 1
  %43 = load i64, ptr %42, align 8
  %44 = call i64 @word_content(i64 noundef %40, i64 noundef %43)
  store i64 0, ptr %4, align 8
  br label %46

45:                                               ; preds = %22
  store i64 1, ptr %4, align 8
  br label %46

46:                                               ; preds = %45, %37
  %47 = load i64, ptr %4, align 8
  ret i64 %47
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal void @word_damage(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = load i64, ptr %3, align 8
  %5 = add i64 %4, 1
  store i64 %5, ptr %3, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal i64 @word_content(i64 noundef %0, i64 noundef %1) #0 {
  %3 = alloca i64, align 8
  %4 = alloca i64, align 8
  store i64 %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %5 = load i64, ptr %3, align 8
  %6 = mul i64 %5, 131
  %7 = load i64, ptr %4, align 8
  %8 = add i64 %6, %7
  ret i64 %8
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define i64 @eco_c_map_reserve_word_finish(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  %4 = alloca %struct.Digest, align 8
  %5 = alloca %struct.word_Cell, align 8
  %6 = alloca %struct.Digest, align 8
  store ptr %0, ptr %2, align 8
  %7 = load ptr, ptr %2, align 8
  store ptr %7, ptr %3, align 8
  call void @llvm.memset.p0.i64(ptr align 8 %4, i8 0, i64 32, i1 false)
  %8 = getelementptr inbounds nuw %struct.Digest, ptr %4, i32 0, i32 0
  %9 = load ptr, ptr %3, align 8
  %10 = getelementptr inbounds nuw %struct.word_Owner, ptr %9, i32 0, i32 2
  %11 = load i64, ptr %10, align 8
  store i64 %11, ptr %8, align 8
  %12 = getelementptr inbounds nuw %struct.Digest, ptr %4, i32 0, i32 1
  %13 = getelementptr inbounds nuw %struct.Digest, ptr %4, i32 0, i32 2
  %14 = getelementptr inbounds nuw %struct.Digest, ptr %4, i32 0, i32 3
  br label %15

15:                                               ; preds = %43, %1
  %16 = load ptr, ptr %3, align 8
  %17 = getelementptr inbounds nuw %struct.word_Owner, ptr %16, i32 0, i32 0
  %18 = getelementptr inbounds nuw %struct.word_Map, ptr %17, i32 0, i32 0
  %19 = load i64, ptr %18, align 8
  %20 = icmp ugt i64 %19, 0
  br i1 %20, label %21, label %44

21:                                               ; preds = %15
  %22 = load ptr, ptr %3, align 8
  %23 = getelementptr inbounds nuw %struct.word_Owner, ptr %22, i32 0, i32 0
  %24 = getelementptr inbounds nuw %struct.word_Map, ptr %23, i32 0, i32 2
  %25 = load ptr, ptr %24, align 8
  %26 = load ptr, ptr %3, align 8
  %27 = getelementptr inbounds nuw %struct.word_Owner, ptr %26, i32 0, i32 0
  %28 = getelementptr inbounds nuw %struct.word_Map, ptr %27, i32 0, i32 0
  %29 = load i64, ptr %28, align 8
  %30 = add i64 %29, -1
  store i64 %30, ptr %28, align 8
  %31 = getelementptr inbounds nuw %struct.word_Cell, ptr %25, i64 %30
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %5, ptr align 8 %31, i64 24, i1 false)
  %32 = getelementptr inbounds nuw %struct.word_Cell, ptr %5, i32 0, i32 0
  %33 = load i32, ptr %32, align 8
  %34 = icmp eq i32 %33, 2
  br i1 %34, label %35, label %43

35:                                               ; preds = %21
  %36 = getelementptr inbounds nuw %struct.word_Cell, ptr %5, i32 0, i32 1
  %37 = getelementptr inbounds nuw %struct.word_Pair, ptr %36, i32 0, i32 0
  %38 = load i64, ptr %37, align 8
  %39 = getelementptr inbounds nuw %struct.word_Cell, ptr %5, i32 0, i32 1
  %40 = getelementptr inbounds nuw %struct.word_Pair, ptr %39, i32 0, i32 1
  %41 = load i64, ptr %40, align 8
  %42 = call i64 @word_content(i64 noundef %38, i64 noundef %41)
  call void @consume(ptr noundef %4, i64 noundef %42)
  br label %43

43:                                               ; preds = %35, %21
  br label %15, !llvm.loop !9

44:                                               ; preds = %15
  %45 = load ptr, ptr %3, align 8
  %46 = getelementptr inbounds nuw %struct.word_Owner, ptr %45, i32 0, i32 0
  %47 = getelementptr inbounds nuw %struct.word_Map, ptr %46, i32 0, i32 1
  %48 = load i64, ptr %47, align 8
  %49 = icmp ne i64 %48, 0
  br i1 %49, label %50, label %55

50:                                               ; preds = %44
  %51 = load ptr, ptr %3, align 8
  %52 = getelementptr inbounds nuw %struct.word_Owner, ptr %51, i32 0, i32 0
  %53 = getelementptr inbounds nuw %struct.word_Map, ptr %52, i32 0, i32 2
  %54 = load ptr, ptr %53, align 8
  call void @free(ptr noundef %54)
  br label %55

55:                                               ; preds = %50, %44
  %56 = load ptr, ptr %3, align 8
  %57 = load ptr, ptr %3, align 8
  %58 = call i64 @llvm.objectsize.i64.p0(ptr %57, i1 false, i1 true, i1 false)
  %59 = call ptr @__memset_chk(ptr noundef %56, i32 noundef 0, i64 noundef 72, i64 noundef %58) #9
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 %4, i64 32, i1 false)
  %60 = call i64 @digest_finish(ptr noundef %6)
  ret i64 %60
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal void @consume(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %5 = load i64, ptr %4, align 8
  %6 = load ptr, ptr %3, align 8
  %7 = getelementptr inbounds nuw %struct.Digest, ptr %6, i32 0, i32 1
  %8 = load i64, ptr %7, align 8
  %9 = add i64 %8, %5
  store i64 %9, ptr %7, align 8
  %10 = load i64, ptr %4, align 8
  %11 = call i64 @mix(i64 noundef %10)
  %12 = load ptr, ptr %3, align 8
  %13 = getelementptr inbounds nuw %struct.Digest, ptr %12, i32 0, i32 2
  %14 = load i64, ptr %13, align 8
  %15 = xor i64 %14, %11
  store i64 %15, ptr %13, align 8
  %16 = load ptr, ptr %3, align 8
  %17 = getelementptr inbounds nuw %struct.Digest, ptr %16, i32 0, i32 3
  %18 = load i64, ptr %17, align 8
  %19 = add i64 %18, 1
  store i64 %19, ptr %17, align 8
  ret void
}

declare void @free(ptr noundef) #3

; Function Attrs: nounwind
declare ptr @__memset_chk(ptr noundef, i32 noundef, i64 noundef, i64 noundef) #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.objectsize.i64.p0(ptr, i1 immarg, i1 immarg, i1 immarg) #5

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal i64 @digest_finish(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = getelementptr inbounds nuw %struct.Digest, ptr %0, i32 0, i32 0
  %4 = load i64, ptr %3, align 8
  %5 = call i64 @mix(i64 noundef %4)
  %6 = getelementptr inbounds nuw %struct.Digest, ptr %0, i32 0, i32 1
  %7 = load i64, ptr %6, align 8
  %8 = call i64 @mix(i64 noundef %7)
  %9 = xor i64 %5, %8
  %10 = getelementptr inbounds nuw %struct.Digest, ptr %0, i32 0, i32 2
  %11 = load i64, ptr %10, align 8
  %12 = xor i64 %9, %11
  %13 = getelementptr inbounds nuw %struct.Digest, ptr %0, i32 0, i32 3
  %14 = load i64, ptr %13, align 8
  %15 = mul i64 %14, -7046029254386353131
  %16 = xor i64 %12, %15
  ret i64 %16
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define void @eco_c_map_reserve_record_prepare(ptr noundef %0, i64 noundef %1, i64 noundef %2, i64 noundef %3) #0 {
  %5 = alloca ptr, align 8
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  %8 = alloca i64, align 8
  %9 = alloca ptr, align 8
  %10 = alloca %struct.record_Owner, align 8
  %11 = alloca i64, align 8
  %12 = alloca %struct.record_Put, align 8
  %13 = alloca %struct.record_Pair, align 8
  %14 = alloca %struct.record_Pair, align 8
  store ptr %0, ptr %5, align 8
  store i64 %1, ptr %6, align 8
  store i64 %2, ptr %7, align 8
  store i64 %3, ptr %8, align 8
  %15 = load ptr, ptr %5, align 8
  store ptr %15, ptr %9, align 8
  %16 = load ptr, ptr %9, align 8
  %17 = getelementptr inbounds nuw %struct.record_Owner, ptr %10, i32 0, i32 0
  %18 = load i64, ptr %6, align 8
  %19 = call i64 @slots(i64 noundef %18)
  call void @record_new(ptr dead_on_unwind writable sret(%struct.record_Map) align 8 %17, i64 noundef %19)
  %20 = getelementptr inbounds nuw %struct.record_Owner, ptr %10, i32 0, i32 1
  %21 = getelementptr inbounds nuw %struct.Env, ptr %20, i32 0, i32 0
  %22 = load i64, ptr %8, align 8
  %23 = xor i64 %22, -7046029254386353131
  store i64 %23, ptr %21, align 8
  %24 = getelementptr inbounds nuw %struct.Env, ptr %20, i32 0, i32 1
  store i8 0, ptr %24, align 8
  %25 = getelementptr i8, ptr %20, i64 9
  call void @llvm.memset.p0.i64(ptr align 1 %25, i8 0, i64 7, i1 false)
  %26 = getelementptr inbounds nuw %struct.record_Owner, ptr %10, i32 0, i32 2
  %27 = load i64, ptr %8, align 8
  store i64 %27, ptr %26, align 8
  %28 = getelementptr inbounds nuw %struct.record_Owner, ptr %10, i32 0, i32 3
  %29 = load i64, ptr %7, align 8
  store i64 %29, ptr %28, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %16, ptr align 8 %10, i64 72, i1 false)
  store i64 0, ptr %11, align 8
  br label %30

30:                                               ; preds = %50, %4
  %31 = load i64, ptr %11, align 8
  %32 = load i64, ptr %7, align 8
  %33 = icmp ult i64 %31, %32
  br i1 %33, label %34, label %53

34:                                               ; preds = %30
  %35 = load ptr, ptr %9, align 8
  %36 = getelementptr inbounds nuw %struct.record_Owner, ptr %35, i32 0, i32 0
  %37 = load ptr, ptr %9, align 8
  %38 = getelementptr inbounds nuw %struct.record_Owner, ptr %37, i32 0, i32 1
  %39 = getelementptr inbounds nuw %struct.record_Pair, ptr %13, i32 0, i32 0
  %40 = load i64, ptr %11, align 8
  %41 = mul i64 %40, 2
  %42 = add i64 %41, 1
  store i64 %42, ptr %39, align 8
  %43 = getelementptr inbounds nuw %struct.record_Pair, ptr %13, i32 0, i32 1
  %44 = load i64, ptr %8, align 8
  %45 = load i64, ptr %11, align 8
  %46 = add i64 %44, %45
  call void @record_make(ptr dead_on_unwind writable sret(%struct.Record) align 8 %43, i64 noundef %46)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %14, ptr align 8 %13, i64 264, i1 false)
  call void @record_put(ptr dead_on_unwind writable sret(%struct.record_Put) align 8 %12, ptr noundef %36, ptr noundef %38, ptr noundef %14)
  %47 = getelementptr inbounds nuw %struct.record_Put, ptr %12, i32 0, i32 0
  %48 = load i32, ptr %47, align 8
  %49 = icmp eq i32 %48, 0
  call void @require(i1 noundef zeroext %49, ptr noundef @.str)
  br label %50

50:                                               ; preds = %34
  %51 = load i64, ptr %11, align 8
  %52 = add i64 %51, 1
  store i64 %52, ptr %11, align 8
  br label %30, !llvm.loop !10

53:                                               ; preds = %30
  ret void
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal void @record_new(ptr dead_on_unwind noalias writable sret(%struct.record_Map) align 8 %0, i64 noundef %1) #0 {
  %3 = alloca i64, align 8
  %4 = alloca ptr, align 8
  %5 = alloca i64, align 8
  %6 = alloca %struct.record_Cell, align 8
  store i64 %1, ptr %3, align 8
  %7 = load i64, ptr %3, align 8
  %8 = icmp ule i64 %7, 16384
  call void @require(i1 noundef zeroext %8, ptr noundef @.str.1)
  %9 = load i64, ptr %3, align 8
  %10 = icmp ne i64 %9, 0
  br i1 %10, label %11, label %15

11:                                               ; preds = %2
  %12 = load i64, ptr %3, align 8
  %13 = mul i64 %12, 272
  %14 = call ptr @malloc(i64 noundef %13) #8
  br label %16

15:                                               ; preds = %2
  br label %16

16:                                               ; preds = %15, %11
  %17 = phi ptr [ %14, %11 ], [ @empty_anchor, %15 ]
  store ptr %17, ptr %4, align 8
  %18 = load ptr, ptr %4, align 8
  %19 = icmp ne ptr %18, null
  call void @require(i1 noundef zeroext %19, ptr noundef @.str.2)
  store i64 0, ptr %5, align 8
  br label %20

20:                                               ; preds = %30, %16
  %21 = load i64, ptr %5, align 8
  %22 = load i64, ptr %3, align 8
  %23 = icmp ult i64 %21, %22
  br i1 %23, label %24, label %33

24:                                               ; preds = %20
  %25 = load ptr, ptr %4, align 8
  %26 = load i64, ptr %5, align 8
  %27 = getelementptr inbounds nuw %struct.record_Cell, ptr %25, i64 %26
  call void @llvm.memset.p0.i64(ptr align 8 %6, i8 0, i64 272, i1 false)
  %28 = getelementptr inbounds nuw %struct.record_Cell, ptr %6, i32 0, i32 0
  %29 = getelementptr inbounds nuw %struct.record_Cell, ptr %6, i32 0, i32 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %27, ptr align 8 %6, i64 272, i1 false)
  br label %30

30:                                               ; preds = %24
  %31 = load i64, ptr %5, align 8
  %32 = add i64 %31, 1
  store i64 %32, ptr %5, align 8
  br label %20, !llvm.loop !11

33:                                               ; preds = %20
  %34 = getelementptr inbounds nuw %struct.record_Map, ptr %0, i32 0, i32 0
  %35 = load i64, ptr %3, align 8
  store i64 %35, ptr %34, align 8
  %36 = getelementptr inbounds nuw %struct.record_Map, ptr %0, i32 0, i32 1
  %37 = load i64, ptr %3, align 8
  store i64 %37, ptr %36, align 8
  %38 = getelementptr inbounds nuw %struct.record_Map, ptr %0, i32 0, i32 2
  %39 = load ptr, ptr %4, align 8
  store ptr %39, ptr %38, align 8
  %40 = getelementptr inbounds nuw %struct.record_Map, ptr %0, i32 0, i32 3
  store i64 0, ptr %40, align 8
  %41 = getelementptr inbounds nuw %struct.record_Map, ptr %0, i32 0, i32 4
  store i64 0, ptr %41, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal void @record_put(ptr dead_on_unwind noalias writable sret(%struct.record_Put) align 8 %0, ptr noundef %1, ptr noundef %2, ptr noundef %3) #0 {
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca i64, align 8
  %9 = alloca i64, align 8
  %10 = alloca i64, align 8
  %11 = alloca i64, align 8
  %12 = alloca %struct.record_Pair, align 8
  store ptr %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  store ptr %3, ptr %7, align 8
  %13 = load ptr, ptr %5, align 8
  %14 = getelementptr inbounds nuw %struct.record_Map, ptr %13, i32 0, i32 0
  %15 = load i64, ptr %14, align 8
  store i64 %15, ptr %8, align 8
  %16 = load i64, ptr %8, align 8
  %17 = load i64, ptr %8, align 8
  %18 = udiv i64 %17, 4
  %19 = sub i64 %16, %18
  store i64 %19, ptr %9, align 8
  %20 = load ptr, ptr %5, align 8
  %21 = getelementptr inbounds nuw %struct.record_Map, ptr %20, i32 0, i32 3
  %22 = load i64, ptr %21, align 8
  %23 = sub i64 -1, %22
  %24 = load ptr, ptr %5, align 8
  %25 = getelementptr inbounds nuw %struct.record_Map, ptr %24, i32 0, i32 4
  %26 = load i64, ptr %25, align 8
  %27 = icmp ult i64 %23, %26
  br i1 %27, label %28, label %29

28:                                               ; preds = %4
  br label %37

29:                                               ; preds = %4
  %30 = load ptr, ptr %5, align 8
  %31 = getelementptr inbounds nuw %struct.record_Map, ptr %30, i32 0, i32 3
  %32 = load i64, ptr %31, align 8
  %33 = load ptr, ptr %5, align 8
  %34 = getelementptr inbounds nuw %struct.record_Map, ptr %33, i32 0, i32 4
  %35 = load i64, ptr %34, align 8
  %36 = add i64 %32, %35
  br label %37

37:                                               ; preds = %29, %28
  %38 = phi i64 [ -1, %28 ], [ %36, %29 ]
  store i64 %38, ptr %10, align 8
  %39 = load i64, ptr %10, align 8
  %40 = load i64, ptr %9, align 8
  %41 = icmp uge i64 %39, %40
  br i1 %41, label %42, label %71

42:                                               ; preds = %37
  %43 = load i64, ptr %8, align 8
  %44 = icmp ult i64 %43, 16384
  br i1 %44, label %45, label %71

45:                                               ; preds = %42
  store i64 16384, ptr %11, align 8
  %46 = load ptr, ptr %5, align 8
  %47 = getelementptr inbounds nuw %struct.record_Map, ptr %46, i32 0, i32 3
  %48 = load i64, ptr %47, align 8
  %49 = load i64, ptr %9, align 8
  %50 = udiv i64 %49, 2
  %51 = icmp ult i64 %48, %50
  br i1 %51, label %52, label %54

52:                                               ; preds = %45
  %53 = load i64, ptr %8, align 8
  store i64 %53, ptr %11, align 8
  br label %66

54:                                               ; preds = %45
  %55 = load i64, ptr %8, align 8
  %56 = icmp eq i64 %55, 0
  br i1 %56, label %57, label %58

57:                                               ; preds = %54
  store i64 1, ptr %11, align 8
  br label %65

58:                                               ; preds = %54
  %59 = load i64, ptr %8, align 8
  %60 = icmp ule i64 %59, 8192
  br i1 %60, label %61, label %64

61:                                               ; preds = %58
  %62 = load i64, ptr %8, align 8
  %63 = mul i64 %62, 2
  store i64 %63, ptr %11, align 8
  br label %64

64:                                               ; preds = %61, %58
  br label %65

65:                                               ; preds = %64, %57
  br label %66

66:                                               ; preds = %65, %52
  %67 = load ptr, ptr %5, align 8
  %68 = load i64, ptr %11, align 8
  %69 = load ptr, ptr %6, align 8
  %70 = call zeroext i1 @record_rebuild(ptr noundef %67, i64 noundef %68, ptr noundef %69)
  br label %71

71:                                               ; preds = %66, %42, %37
  %72 = load ptr, ptr %5, align 8
  %73 = load ptr, ptr %6, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %12, ptr align 8 %3, i64 264, i1 false)
  call void @record_try_put(ptr dead_on_unwind writable sret(%struct.record_Put) align 8 %0, ptr noundef %72, ptr noundef %73, ptr noundef %12)
  ret void
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal void @record_make(ptr dead_on_unwind noalias writable sret(%struct.Record) align 8 %0, i64 noundef %1) #0 {
  %3 = alloca i64, align 8
  %4 = alloca i32, align 4
  store i64 %1, ptr %3, align 8
  store i32 0, ptr %4, align 4
  br label %5

5:                                                ; preds = %17, %2
  %6 = load i32, ptr %4, align 4
  %7 = icmp ult i32 %6, 32
  br i1 %7, label %8, label %20

8:                                                ; preds = %5
  %9 = load i64, ptr %3, align 8
  %10 = load i32, ptr %4, align 4
  %11 = zext i32 %10 to i64
  %12 = add i64 %9, %11
  %13 = getelementptr inbounds nuw %struct.Record, ptr %0, i32 0, i32 0
  %14 = load i32, ptr %4, align 4
  %15 = zext i32 %14 to i64
  %16 = getelementptr inbounds nuw [32 x i64], ptr %13, i64 0, i64 %15
  store i64 %12, ptr %16, align 8
  br label %17

17:                                               ; preds = %8
  %18 = load i32, ptr %4, align 4
  %19 = add i32 %18, 1
  store i32 %19, ptr %4, align 4
  br label %5, !llvm.loop !12

20:                                               ; preds = %5
  ret void
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define i64 @eco_c_map_reserve_record_raw(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %6 = load ptr, ptr %3, align 8
  store ptr %6, ptr %5, align 8
  %7 = load ptr, ptr %5, align 8
  %8 = getelementptr inbounds nuw %struct.record_Owner, ptr %7, i32 0, i32 0
  %9 = load i64, ptr %4, align 8
  %10 = load ptr, ptr %5, align 8
  %11 = getelementptr inbounds nuw %struct.record_Owner, ptr %10, i32 0, i32 1
  %12 = call zeroext i1 @record_reserve(ptr noundef %8, i64 noundef %9, ptr noundef %11)
  %13 = zext i1 %12 to i64
  ret i64 %13
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal zeroext i1 @record_reserve(ptr noundef %0, i64 noundef %1, ptr noundef %2) #0 {
  %4 = alloca i1, align 1
  %5 = alloca ptr, align 8
  %6 = alloca i64, align 8
  %7 = alloca ptr, align 8
  store ptr %0, ptr %5, align 8
  store i64 %1, ptr %6, align 8
  store ptr %2, ptr %7, align 8
  %8 = load i64, ptr %6, align 8
  %9 = icmp ugt i64 %8, 16384
  br i1 %9, label %10, label %11

10:                                               ; preds = %3
  store i1 false, ptr %4, align 1
  br label %23

11:                                               ; preds = %3
  %12 = load i64, ptr %6, align 8
  %13 = load ptr, ptr %5, align 8
  %14 = getelementptr inbounds nuw %struct.record_Map, ptr %13, i32 0, i32 0
  %15 = load i64, ptr %14, align 8
  %16 = icmp ule i64 %12, %15
  br i1 %16, label %17, label %18

17:                                               ; preds = %11
  store i1 true, ptr %4, align 1
  br label %23

18:                                               ; preds = %11
  %19 = load ptr, ptr %5, align 8
  %20 = load i64, ptr %6, align 8
  %21 = load ptr, ptr %7, align 8
  %22 = call zeroext i1 @record_rebuild(ptr noundef %19, i64 noundef %20, ptr noundef %21)
  store i1 %22, ptr %4, align 1
  br label %23

23:                                               ; preds = %18, %17, %10
  %24 = load i1, ptr %4, align 1
  ret i1 %24
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define i64 @eco_c_map_reserve_record_step(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = load i64, ptr %4, align 8
  %7 = call i64 @slots(i64 noundef %6)
  %8 = call i64 @eco_c_map_reserve_record_raw(ptr noundef %5, i64 noundef %7)
  ret i64 %8
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define i64 @eco_c_map_reserve_record_geometry(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %4 = load ptr, ptr %2, align 8
  store ptr %4, ptr %3, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = getelementptr inbounds nuw %struct.record_Owner, ptr %5, i32 0, i32 0
  %7 = getelementptr inbounds nuw %struct.record_Map, ptr %6, i32 0, i32 0
  %8 = load i64, ptr %7, align 8
  %9 = shl i64 %8, 32
  %10 = load ptr, ptr %3, align 8
  %11 = getelementptr inbounds nuw %struct.record_Owner, ptr %10, i32 0, i32 0
  %12 = getelementptr inbounds nuw %struct.record_Map, ptr %11, i32 0, i32 3
  %13 = load i64, ptr %12, align 8
  %14 = add i64 %9, %13
  ret i64 %14
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define i64 @eco_c_map_reserve_record_insert(ptr noundef %0, i64 noundef %1, i64 noundef %2) #0 {
  %4 = alloca i64, align 8
  %5 = alloca ptr, align 8
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  %8 = alloca ptr, align 8
  %9 = alloca %struct.Record, align 8
  %10 = alloca %struct.record_Put, align 8
  %11 = alloca %struct.record_Pair, align 8
  %12 = alloca %struct.record_Pair, align 8
  %13 = alloca %struct.Record, align 8
  store ptr %0, ptr %5, align 8
  store i64 %1, ptr %6, align 8
  store i64 %2, ptr %7, align 8
  %14 = load ptr, ptr %5, align 8
  store ptr %14, ptr %8, align 8
  %15 = load ptr, ptr %8, align 8
  %16 = getelementptr inbounds nuw %struct.record_Owner, ptr %15, i32 0, i32 2
  %17 = load i64, ptr %16, align 8
  %18 = load i64, ptr %6, align 8
  %19 = add i64 %17, %18
  call void @record_make(ptr dead_on_unwind writable sret(%struct.Record) align 8 %9, i64 noundef %19)
  %20 = load i64, ptr %7, align 8
  %21 = icmp ne i64 %20, 0
  br i1 %21, label %22, label %23

22:                                               ; preds = %3
  call void @record_damage(ptr noundef %9)
  br label %23

23:                                               ; preds = %22, %3
  %24 = load ptr, ptr %8, align 8
  %25 = getelementptr inbounds nuw %struct.record_Owner, ptr %24, i32 0, i32 0
  %26 = load ptr, ptr %8, align 8
  %27 = getelementptr inbounds nuw %struct.record_Owner, ptr %26, i32 0, i32 1
  %28 = getelementptr inbounds nuw %struct.record_Pair, ptr %11, i32 0, i32 0
  %29 = load i64, ptr %6, align 8
  %30 = mul i64 %29, 2
  %31 = add i64 %30, 1
  store i64 %31, ptr %28, align 8
  %32 = getelementptr inbounds nuw %struct.record_Pair, ptr %11, i32 0, i32 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %32, ptr align 8 %9, i64 256, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %12, ptr align 8 %11, i64 264, i1 false)
  call void @record_put(ptr dead_on_unwind writable sret(%struct.record_Put) align 8 %10, ptr noundef %25, ptr noundef %27, ptr noundef %12)
  %33 = getelementptr inbounds nuw %struct.record_Put, ptr %10, i32 0, i32 0
  %34 = load i32, ptr %33, align 8
  %35 = icmp ne i32 %34, 0
  br i1 %35, label %36, label %43

36:                                               ; preds = %23
  %37 = getelementptr inbounds nuw %struct.record_Put, ptr %10, i32 0, i32 2
  %38 = getelementptr inbounds nuw %struct.record_Pair, ptr %37, i32 0, i32 0
  %39 = load i64, ptr %38, align 8
  %40 = getelementptr inbounds nuw %struct.record_Put, ptr %10, i32 0, i32 2
  %41 = getelementptr inbounds nuw %struct.record_Pair, ptr %40, i32 0, i32 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %13, ptr align 8 %41, i64 256, i1 false)
  %42 = call i64 @record_content(i64 noundef %39, ptr noundef %13)
  store i64 0, ptr %4, align 8
  br label %44

43:                                               ; preds = %23
  store i64 1, ptr %4, align 8
  br label %44

44:                                               ; preds = %43, %36
  %45 = load i64, ptr %4, align 8
  ret i64 %45
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal void @record_damage(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr inbounds nuw %struct.Record, ptr %3, i32 0, i32 0
  %5 = getelementptr inbounds [32 x i64], ptr %4, i64 0, i64 31
  %6 = load i64, ptr %5, align 8
  %7 = add i64 %6, 1
  store i64 %7, ptr %5, align 8
  ret void
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal i64 @record_content(i64 noundef %0, ptr noundef %1) #0 {
  %3 = alloca i64, align 8
  %4 = alloca ptr, align 8
  %5 = alloca i32, align 4
  store i64 %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  store i32 0, ptr %5, align 4
  br label %6

6:                                                ; preds = %18, %2
  %7 = load i32, ptr %5, align 4
  %8 = icmp ult i32 %7, 32
  br i1 %8, label %9, label %21

9:                                                ; preds = %6
  %10 = load i64, ptr %3, align 8
  %11 = mul i64 %10, 131
  %12 = getelementptr inbounds nuw %struct.Record, ptr %1, i32 0, i32 0
  %13 = load i32, ptr %5, align 4
  %14 = zext i32 %13 to i64
  %15 = getelementptr inbounds nuw [32 x i64], ptr %12, i64 0, i64 %14
  %16 = load i64, ptr %15, align 8
  %17 = add i64 %11, %16
  store i64 %17, ptr %3, align 8
  br label %18

18:                                               ; preds = %9
  %19 = load i32, ptr %5, align 4
  %20 = add i32 %19, 1
  store i32 %20, ptr %5, align 4
  br label %6, !llvm.loop !13

21:                                               ; preds = %6
  %22 = load i64, ptr %3, align 8
  ret i64 %22
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define i64 @eco_c_map_reserve_record_finish(ptr noundef %0) #0 {
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  %4 = alloca %struct.Digest, align 8
  %5 = alloca %struct.record_Cell, align 8
  %6 = alloca %struct.Record, align 8
  %7 = alloca %struct.Digest, align 8
  store ptr %0, ptr %2, align 8
  %8 = load ptr, ptr %2, align 8
  store ptr %8, ptr %3, align 8
  call void @llvm.memset.p0.i64(ptr align 8 %4, i8 0, i64 32, i1 false)
  %9 = getelementptr inbounds nuw %struct.Digest, ptr %4, i32 0, i32 0
  %10 = load ptr, ptr %3, align 8
  %11 = getelementptr inbounds nuw %struct.record_Owner, ptr %10, i32 0, i32 2
  %12 = load i64, ptr %11, align 8
  store i64 %12, ptr %9, align 8
  %13 = getelementptr inbounds nuw %struct.Digest, ptr %4, i32 0, i32 1
  %14 = getelementptr inbounds nuw %struct.Digest, ptr %4, i32 0, i32 2
  %15 = getelementptr inbounds nuw %struct.Digest, ptr %4, i32 0, i32 3
  br label %16

16:                                               ; preds = %43, %1
  %17 = load ptr, ptr %3, align 8
  %18 = getelementptr inbounds nuw %struct.record_Owner, ptr %17, i32 0, i32 0
  %19 = getelementptr inbounds nuw %struct.record_Map, ptr %18, i32 0, i32 0
  %20 = load i64, ptr %19, align 8
  %21 = icmp ugt i64 %20, 0
  br i1 %21, label %22, label %44

22:                                               ; preds = %16
  %23 = load ptr, ptr %3, align 8
  %24 = getelementptr inbounds nuw %struct.record_Owner, ptr %23, i32 0, i32 0
  %25 = getelementptr inbounds nuw %struct.record_Map, ptr %24, i32 0, i32 2
  %26 = load ptr, ptr %25, align 8
  %27 = load ptr, ptr %3, align 8
  %28 = getelementptr inbounds nuw %struct.record_Owner, ptr %27, i32 0, i32 0
  %29 = getelementptr inbounds nuw %struct.record_Map, ptr %28, i32 0, i32 0
  %30 = load i64, ptr %29, align 8
  %31 = add i64 %30, -1
  store i64 %31, ptr %29, align 8
  %32 = getelementptr inbounds nuw %struct.record_Cell, ptr %26, i64 %31
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %5, ptr align 8 %32, i64 272, i1 false)
  %33 = getelementptr inbounds nuw %struct.record_Cell, ptr %5, i32 0, i32 0
  %34 = load i32, ptr %33, align 8
  %35 = icmp eq i32 %34, 2
  br i1 %35, label %36, label %43

36:                                               ; preds = %22
  %37 = getelementptr inbounds nuw %struct.record_Cell, ptr %5, i32 0, i32 1
  %38 = getelementptr inbounds nuw %struct.record_Pair, ptr %37, i32 0, i32 0
  %39 = load i64, ptr %38, align 8
  %40 = getelementptr inbounds nuw %struct.record_Cell, ptr %5, i32 0, i32 1
  %41 = getelementptr inbounds nuw %struct.record_Pair, ptr %40, i32 0, i32 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 %41, i64 256, i1 false)
  %42 = call i64 @record_content(i64 noundef %39, ptr noundef %6)
  call void @consume(ptr noundef %4, i64 noundef %42)
  br label %43

43:                                               ; preds = %36, %22
  br label %16, !llvm.loop !14

44:                                               ; preds = %16
  %45 = load ptr, ptr %3, align 8
  %46 = getelementptr inbounds nuw %struct.record_Owner, ptr %45, i32 0, i32 0
  %47 = getelementptr inbounds nuw %struct.record_Map, ptr %46, i32 0, i32 1
  %48 = load i64, ptr %47, align 8
  %49 = icmp ne i64 %48, 0
  br i1 %49, label %50, label %55

50:                                               ; preds = %44
  %51 = load ptr, ptr %3, align 8
  %52 = getelementptr inbounds nuw %struct.record_Owner, ptr %51, i32 0, i32 0
  %53 = getelementptr inbounds nuw %struct.record_Map, ptr %52, i32 0, i32 2
  %54 = load ptr, ptr %53, align 8
  call void @free(ptr noundef %54)
  br label %55

55:                                               ; preds = %50, %44
  %56 = load ptr, ptr %3, align 8
  %57 = load ptr, ptr %3, align 8
  %58 = call i64 @llvm.objectsize.i64.p0(ptr %57, i1 false, i1 true, i1 false)
  %59 = call ptr @__memset_chk(ptr noundef %56, i32 noundef 0, i64 noundef 72, i64 noundef %58) #9
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %7, ptr align 8 %4, i64 32, i1 false)
  %60 = call i64 @digest_finish(ptr noundef %7)
  ret i64 %60
}

; Function Attrs: allocsize(0)
declare ptr @malloc(i64 noundef) #6

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal zeroext i1 @word_rebuild(ptr noundef %0, i64 noundef %1, ptr noundef %2) #0 {
  %4 = alloca i1, align 1
  %5 = alloca ptr, align 8
  %6 = alloca i64, align 8
  %7 = alloca ptr, align 8
  %8 = alloca %struct.word_Map, align 8
  %9 = alloca ptr, align 8
  %10 = alloca i64, align 8
  %11 = alloca i64, align 8
  %12 = alloca %struct.word_Cell, align 8
  %13 = alloca %struct.word_Pair, align 8
  %14 = alloca i8, align 1
  %15 = alloca i64, align 8
  %16 = alloca i64, align 8
  %17 = alloca i64, align 8
  %18 = alloca i64, align 8
  %19 = alloca %struct.word_Put, align 8
  store ptr %0, ptr %5, align 8
  store i64 %1, ptr %6, align 8
  store ptr %2, ptr %7, align 8
  %20 = load i64, ptr %6, align 8
  %21 = icmp ugt i64 %20, 16384
  br i1 %21, label %28, label %22

22:                                               ; preds = %3
  %23 = load i64, ptr %6, align 8
  %24 = load ptr, ptr %5, align 8
  %25 = getelementptr inbounds nuw %struct.word_Map, ptr %24, i32 0, i32 0
  %26 = load i64, ptr %25, align 8
  %27 = icmp ult i64 %23, %26
  br i1 %27, label %28, label %29

28:                                               ; preds = %22, %3
  store i1 false, ptr %4, align 1
  br label %127

29:                                               ; preds = %22
  %30 = load i64, ptr %6, align 8
  %31 = icmp eq i64 %30, 0
  br i1 %31, label %32, label %33

32:                                               ; preds = %29
  store i1 true, ptr %4, align 1
  br label %127

33:                                               ; preds = %29
  %34 = load i64, ptr %6, align 8
  call void @word_new(ptr dead_on_unwind writable sret(%struct.word_Map) align 8 %8, i64 noundef %34)
  %35 = load ptr, ptr %5, align 8
  %36 = getelementptr inbounds nuw %struct.word_Map, ptr %35, i32 0, i32 2
  %37 = load ptr, ptr %36, align 8
  store ptr %37, ptr %9, align 8
  %38 = load ptr, ptr %5, align 8
  %39 = getelementptr inbounds nuw %struct.word_Map, ptr %38, i32 0, i32 0
  %40 = load i64, ptr %39, align 8
  store i64 %40, ptr %10, align 8
  %41 = load ptr, ptr %5, align 8
  %42 = getelementptr inbounds nuw %struct.word_Map, ptr %41, i32 0, i32 1
  %43 = load i64, ptr %42, align 8
  store i64 %43, ptr %11, align 8
  %44 = getelementptr inbounds nuw %struct.word_Map, ptr %8, i32 0, i32 2
  %45 = load ptr, ptr %44, align 8
  %46 = load ptr, ptr %5, align 8
  %47 = getelementptr inbounds nuw %struct.word_Map, ptr %46, i32 0, i32 2
  store ptr %45, ptr %47, align 8
  %48 = getelementptr inbounds nuw %struct.word_Map, ptr %8, i32 0, i32 0
  %49 = load i64, ptr %48, align 8
  %50 = load ptr, ptr %5, align 8
  %51 = getelementptr inbounds nuw %struct.word_Map, ptr %50, i32 0, i32 0
  store i64 %49, ptr %51, align 8
  %52 = getelementptr inbounds nuw %struct.word_Map, ptr %8, i32 0, i32 1
  %53 = load i64, ptr %52, align 8
  %54 = load ptr, ptr %5, align 8
  %55 = getelementptr inbounds nuw %struct.word_Map, ptr %54, i32 0, i32 1
  store i64 %53, ptr %55, align 8
  br label %56

56:                                               ; preds = %118, %67, %33
  %57 = load i64, ptr %10, align 8
  %58 = icmp ugt i64 %57, 0
  br i1 %58, label %59, label %119

59:                                               ; preds = %56
  %60 = load ptr, ptr %9, align 8
  %61 = load i64, ptr %10, align 8
  %62 = add i64 %61, -1
  store i64 %62, ptr %10, align 8
  %63 = getelementptr inbounds nuw %struct.word_Cell, ptr %60, i64 %62
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %12, ptr align 8 %63, i64 24, i1 false)
  %64 = getelementptr inbounds nuw %struct.word_Cell, ptr %12, i32 0, i32 0
  %65 = load i32, ptr %64, align 8
  %66 = icmp ne i32 %65, 2
  br i1 %66, label %67, label %68

67:                                               ; preds = %59
  br label %56, !llvm.loop !15

68:                                               ; preds = %59
  %69 = getelementptr inbounds nuw %struct.word_Cell, ptr %12, i32 0, i32 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %13, ptr align 8 %69, i64 16, i1 false)
  store i8 1, ptr %14, align 1
  br label %70

70:                                               ; preds = %117, %68
  %71 = load i8, ptr %14, align 1
  %72 = trunc i8 %71 to i1
  br i1 %72, label %73, label %118

73:                                               ; preds = %70
  %74 = load ptr, ptr %7, align 8
  %75 = getelementptr inbounds nuw %struct.word_Pair, ptr %13, i32 0, i32 0
  %76 = load i64, ptr %75, align 8
  %77 = call i64 @key_hash(ptr noundef %74, i64 noundef %76)
  store i64 %77, ptr %15, align 8
  %78 = load ptr, ptr %5, align 8
  %79 = getelementptr inbounds nuw %struct.word_Map, ptr %78, i32 0, i32 0
  %80 = load i64, ptr %79, align 8
  store i64 %80, ptr %16, align 8
  store i64 0, ptr %17, align 8
  br label %81

81:                                               ; preds = %114, %73
  %82 = load i64, ptr %17, align 8
  %83 = load i64, ptr %16, align 8
  %84 = icmp ult i64 %82, %83
  br i1 %84, label %85, label %117

85:                                               ; preds = %81
  %86 = load i64, ptr %15, align 8
  %87 = load i64, ptr %16, align 8
  %88 = urem i64 %86, %87
  %89 = load i64, ptr %17, align 8
  %90 = load i64, ptr %16, align 8
  %91 = call i64 @probe(i64 noundef %88, i64 noundef %89, i64 noundef %90)
  store i64 %91, ptr %18, align 8
  %92 = load ptr, ptr %5, align 8
  %93 = getelementptr inbounds nuw %struct.word_Map, ptr %92, i32 0, i32 2
  %94 = load ptr, ptr %93, align 8
  %95 = load i64, ptr %18, align 8
  %96 = getelementptr inbounds nuw %struct.word_Cell, ptr %94, i64 %95
  %97 = getelementptr inbounds nuw %struct.word_Cell, ptr %96, i32 0, i32 0
  %98 = load i32, ptr %97, align 8
  %99 = icmp ne i32 %98, 2
  br i1 %99, label %100, label %113

100:                                              ; preds = %85
  %101 = load ptr, ptr %5, align 8
  %102 = load i64, ptr %18, align 8
  %103 = load [2 x i64], ptr %13, align 8
  call void @word_exchange(ptr dead_on_unwind writable sret(%struct.word_Put) align 8 %19, ptr noundef %101, i64 noundef %102, [2 x i64] %103)
  %104 = getelementptr inbounds nuw %struct.word_Put, ptr %19, i32 0, i32 0
  %105 = load i32, ptr %104, align 8
  %106 = icmp ne i32 %105, 0
  %107 = zext i1 %106 to i8
  store i8 %107, ptr %14, align 1
  %108 = load i8, ptr %14, align 1
  %109 = trunc i8 %108 to i1
  br i1 %109, label %110, label %112

110:                                              ; preds = %100
  %111 = getelementptr inbounds nuw %struct.word_Put, ptr %19, i32 0, i32 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %13, ptr align 8 %111, i64 16, i1 false)
  br label %112

112:                                              ; preds = %110, %100
  br label %117

113:                                              ; preds = %85
  br label %114

114:                                              ; preds = %113
  %115 = load i64, ptr %17, align 8
  %116 = add i64 %115, 1
  store i64 %116, ptr %17, align 8
  br label %81, !llvm.loop !16

117:                                              ; preds = %112, %81
  br label %70, !llvm.loop !17

118:                                              ; preds = %70
  br label %56, !llvm.loop !15

119:                                              ; preds = %56
  %120 = load i64, ptr %11, align 8
  %121 = icmp ne i64 %120, 0
  br i1 %121, label %122, label %124

122:                                              ; preds = %119
  %123 = load ptr, ptr %9, align 8
  call void @free(ptr noundef %123)
  br label %124

124:                                              ; preds = %122, %119
  %125 = load ptr, ptr %5, align 8
  %126 = getelementptr inbounds nuw %struct.word_Map, ptr %125, i32 0, i32 4
  store i64 0, ptr %126, align 8
  store i1 true, ptr %4, align 1
  br label %127

127:                                              ; preds = %124, %32, %28
  %128 = load i1, ptr %4, align 1
  ret i1 %128
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal void @word_try_put(ptr dead_on_unwind noalias writable sret(%struct.word_Put) align 8 %0, ptr noundef %1, ptr noundef %2, [2 x i64] %3) #0 {
  %5 = alloca %struct.word_Pair, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca i64, align 8
  %9 = alloca i64, align 8
  %10 = alloca i64, align 8
  %11 = alloca i64, align 8
  %12 = alloca i64, align 8
  %13 = alloca ptr, align 8
  store [2 x i64] %3, ptr %5, align 8
  store ptr %1, ptr %6, align 8
  store ptr %2, ptr %7, align 8
  %14 = load ptr, ptr %7, align 8
  %15 = getelementptr inbounds nuw %struct.word_Pair, ptr %5, i32 0, i32 0
  %16 = load i64, ptr %15, align 8
  %17 = call i64 @key_hash(ptr noundef %14, i64 noundef %16)
  store i64 %17, ptr %8, align 8
  %18 = load ptr, ptr %6, align 8
  %19 = getelementptr inbounds nuw %struct.word_Map, ptr %18, i32 0, i32 0
  %20 = load i64, ptr %19, align 8
  store i64 %20, ptr %9, align 8
  %21 = load i64, ptr %9, align 8
  store i64 %21, ptr %10, align 8
  %22 = load i64, ptr %9, align 8
  %23 = icmp ugt i64 %22, 0
  br i1 %23, label %24, label %92

24:                                               ; preds = %4
  %25 = load i64, ptr %8, align 8
  %26 = load i64, ptr %9, align 8
  %27 = urem i64 %25, %26
  store i64 %27, ptr %11, align 8
  store i64 0, ptr %12, align 8
  br label %28

28:                                               ; preds = %88, %24
  %29 = load i64, ptr %12, align 8
  %30 = load i64, ptr %9, align 8
  %31 = icmp ult i64 %29, %30
  br i1 %31, label %32, label %91

32:                                               ; preds = %28
  %33 = load ptr, ptr %6, align 8
  %34 = getelementptr inbounds nuw %struct.word_Map, ptr %33, i32 0, i32 2
  %35 = load ptr, ptr %34, align 8
  %36 = load i64, ptr %11, align 8
  %37 = getelementptr inbounds nuw %struct.word_Cell, ptr %35, i64 %36
  store ptr %37, ptr %13, align 8
  %38 = load ptr, ptr %13, align 8
  %39 = getelementptr inbounds nuw %struct.word_Cell, ptr %38, i32 0, i32 0
  %40 = load i32, ptr %39, align 8
  %41 = icmp eq i32 %40, 2
  br i1 %41, label %42, label %54

42:                                               ; preds = %32
  %43 = load ptr, ptr %13, align 8
  %44 = getelementptr inbounds nuw %struct.word_Cell, ptr %43, i32 0, i32 1
  %45 = getelementptr inbounds nuw %struct.word_Pair, ptr %44, i32 0, i32 0
  %46 = load i64, ptr %45, align 8
  %47 = getelementptr inbounds nuw %struct.word_Pair, ptr %5, i32 0, i32 0
  %48 = load i64, ptr %47, align 8
  %49 = icmp eq i64 %46, %48
  br i1 %49, label %50, label %54

50:                                               ; preds = %42
  %51 = load ptr, ptr %6, align 8
  %52 = load i64, ptr %11, align 8
  %53 = load [2 x i64], ptr %5, align 8
  call void @word_exchange(ptr dead_on_unwind writable sret(%struct.word_Put) align 8 %0, ptr noundef %51, i64 noundef %52, [2 x i64] %53)
  br label %133

54:                                               ; preds = %42, %32
  %55 = load ptr, ptr %13, align 8
  %56 = getelementptr inbounds nuw %struct.word_Cell, ptr %55, i32 0, i32 0
  %57 = load i32, ptr %56, align 8
  %58 = icmp eq i32 %57, 0
  br i1 %58, label %59, label %66

59:                                               ; preds = %54
  %60 = load i64, ptr %10, align 8
  %61 = load i64, ptr %9, align 8
  %62 = icmp eq i64 %60, %61
  br i1 %62, label %63, label %65

63:                                               ; preds = %59
  %64 = load i64, ptr %11, align 8
  store i64 %64, ptr %10, align 8
  br label %65

65:                                               ; preds = %63, %59
  br label %91

66:                                               ; preds = %54
  %67 = load ptr, ptr %13, align 8
  %68 = getelementptr inbounds nuw %struct.word_Cell, ptr %67, i32 0, i32 0
  %69 = load i32, ptr %68, align 8
  %70 = icmp eq i32 %69, 1
  br i1 %70, label %71, label %77

71:                                               ; preds = %66
  %72 = load i64, ptr %10, align 8
  %73 = load i64, ptr %9, align 8
  %74 = icmp eq i64 %72, %73
  br i1 %74, label %75, label %77

75:                                               ; preds = %71
  %76 = load i64, ptr %11, align 8
  store i64 %76, ptr %10, align 8
  br label %77

77:                                               ; preds = %75, %71, %66
  %78 = load i64, ptr %11, align 8
  %79 = add i64 %78, 1
  %80 = load i64, ptr %9, align 8
  %81 = icmp ult i64 %79, %80
  br i1 %81, label %82, label %85

82:                                               ; preds = %77
  %83 = load i64, ptr %11, align 8
  %84 = add i64 %83, 1
  br label %86

85:                                               ; preds = %77
  br label %86

86:                                               ; preds = %85, %82
  %87 = phi i64 [ %84, %82 ], [ 0, %85 ]
  store i64 %87, ptr %11, align 8
  br label %88

88:                                               ; preds = %86
  %89 = load i64, ptr %12, align 8
  %90 = add i64 %89, 1
  store i64 %90, ptr %12, align 8
  br label %28, !llvm.loop !18

91:                                               ; preds = %65, %28
  br label %92

92:                                               ; preds = %91, %4
  %93 = load i64, ptr %10, align 8
  %94 = load i64, ptr %9, align 8
  %95 = icmp ult i64 %93, %94
  br i1 %95, label %96, label %128

96:                                               ; preds = %92
  %97 = load ptr, ptr %6, align 8
  %98 = getelementptr inbounds nuw %struct.word_Map, ptr %97, i32 0, i32 3
  %99 = load i64, ptr %98, align 8
  %100 = icmp ult i64 %99, 16384
  br i1 %100, label %101, label %128

101:                                              ; preds = %96
  %102 = load ptr, ptr %6, align 8
  %103 = getelementptr inbounds nuw %struct.word_Map, ptr %102, i32 0, i32 3
  %104 = load i64, ptr %103, align 8
  %105 = add i64 %104, 1
  store i64 %105, ptr %103, align 8
  %106 = load ptr, ptr %6, align 8
  %107 = getelementptr inbounds nuw %struct.word_Map, ptr %106, i32 0, i32 2
  %108 = load ptr, ptr %107, align 8
  %109 = load i64, ptr %10, align 8
  %110 = getelementptr inbounds nuw %struct.word_Cell, ptr %108, i64 %109
  %111 = getelementptr inbounds nuw %struct.word_Cell, ptr %110, i32 0, i32 0
  %112 = load i32, ptr %111, align 8
  %113 = icmp eq i32 %112, 1
  br i1 %113, label %114, label %124

114:                                              ; preds = %101
  %115 = load ptr, ptr %6, align 8
  %116 = getelementptr inbounds nuw %struct.word_Map, ptr %115, i32 0, i32 4
  %117 = load i64, ptr %116, align 8
  %118 = icmp ugt i64 %117, 0
  br i1 %118, label %119, label %124

119:                                              ; preds = %114
  %120 = load ptr, ptr %6, align 8
  %121 = getelementptr inbounds nuw %struct.word_Map, ptr %120, i32 0, i32 4
  %122 = load i64, ptr %121, align 8
  %123 = add i64 %122, -1
  store i64 %123, ptr %121, align 8
  br label %124

124:                                              ; preds = %119, %114, %101
  %125 = load ptr, ptr %6, align 8
  %126 = load i64, ptr %10, align 8
  %127 = load [2 x i64], ptr %5, align 8
  call void @word_exchange(ptr dead_on_unwind writable sret(%struct.word_Put) align 8 %0, ptr noundef %125, i64 noundef %126, [2 x i64] %127)
  br label %133

128:                                              ; preds = %96, %92
  %129 = getelementptr inbounds nuw %struct.word_Put, ptr %0, i32 0, i32 0
  store i32 1, ptr %129, align 8
  %130 = getelementptr inbounds nuw %struct.word_Put, ptr %0, i32 0, i32 1
  store i8 1, ptr %130, align 4
  %131 = getelementptr i8, ptr %0, i64 5
  call void @llvm.memset.p0.i64(ptr align 1 %131, i8 0, i64 3, i1 false)
  %132 = getelementptr inbounds nuw %struct.word_Put, ptr %0, i32 0, i32 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %132, ptr align 8 %5, i64 16, i1 false)
  br label %133

133:                                              ; preds = %128, %124, %50
  ret void
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal i64 @key_hash(ptr noundef %0, i64 noundef %1) #0 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = getelementptr inbounds nuw %struct.Env, ptr %5, i32 0, i32 1
  %7 = load i8, ptr %6, align 8
  %8 = trunc i8 %7 to i1
  br i1 %8, label %9, label %10

9:                                                ; preds = %2
  br label %17

10:                                               ; preds = %2
  %11 = load i64, ptr %4, align 8
  %12 = load ptr, ptr %3, align 8
  %13 = getelementptr inbounds nuw %struct.Env, ptr %12, i32 0, i32 0
  %14 = load i64, ptr %13, align 8
  %15 = xor i64 %11, %14
  %16 = call i64 @mix(i64 noundef %15)
  br label %17

17:                                               ; preds = %10, %9
  %18 = phi i64 [ 0, %9 ], [ %16, %10 ]
  ret i64 %18
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal i64 @probe(i64 noundef %0, i64 noundef %1, i64 noundef %2) #0 {
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  store i64 %0, ptr %4, align 8
  store i64 %1, ptr %5, align 8
  store i64 %2, ptr %6, align 8
  %8 = load i64, ptr %6, align 8
  %9 = load i64, ptr %4, align 8
  %10 = sub i64 %8, %9
  store i64 %10, ptr %7, align 8
  %11 = load i64, ptr %5, align 8
  %12 = load i64, ptr %7, align 8
  %13 = icmp uge i64 %11, %12
  br i1 %13, label %14, label %18

14:                                               ; preds = %3
  %15 = load i64, ptr %5, align 8
  %16 = load i64, ptr %7, align 8
  %17 = sub i64 %15, %16
  br label %22

18:                                               ; preds = %3
  %19 = load i64, ptr %4, align 8
  %20 = load i64, ptr %5, align 8
  %21 = add i64 %19, %20
  br label %22

22:                                               ; preds = %18, %14
  %23 = phi i64 [ %17, %14 ], [ %21, %18 ]
  ret i64 %23
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal void @word_exchange(ptr dead_on_unwind noalias writable sret(%struct.word_Put) align 8 %0, ptr noundef %1, i64 noundef %2, [2 x i64] %3) #0 {
  %5 = alloca %struct.word_Pair, align 8
  %6 = alloca ptr, align 8
  %7 = alloca i64, align 8
  %8 = alloca %struct.word_Cell, align 8
  %9 = alloca %struct.word_Cell, align 8
  store [2 x i64] %3, ptr %5, align 8
  store ptr %1, ptr %6, align 8
  store i64 %2, ptr %7, align 8
  %10 = load ptr, ptr %6, align 8
  %11 = getelementptr inbounds nuw %struct.word_Map, ptr %10, i32 0, i32 2
  %12 = load ptr, ptr %11, align 8
  %13 = load i64, ptr %7, align 8
  %14 = getelementptr inbounds nuw %struct.word_Cell, ptr %12, i64 %13
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %8, ptr align 8 %14, i64 24, i1 false)
  %15 = load ptr, ptr %6, align 8
  %16 = getelementptr inbounds nuw %struct.word_Map, ptr %15, i32 0, i32 2
  %17 = load ptr, ptr %16, align 8
  %18 = load i64, ptr %7, align 8
  %19 = getelementptr inbounds nuw %struct.word_Cell, ptr %17, i64 %18
  %20 = getelementptr inbounds nuw %struct.word_Cell, ptr %9, i32 0, i32 0
  store i32 2, ptr %20, align 8
  %21 = getelementptr i8, ptr %9, i64 4
  call void @llvm.memset.p0.i64(ptr align 4 %21, i8 0, i64 4, i1 false)
  %22 = getelementptr inbounds nuw %struct.word_Cell, ptr %9, i32 0, i32 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %22, ptr align 8 %5, i64 16, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %19, ptr align 8 %9, i64 24, i1 false)
  %23 = getelementptr inbounds nuw %struct.word_Cell, ptr %8, i32 0, i32 0
  %24 = load i32, ptr %23, align 8
  %25 = icmp eq i32 %24, 2
  br i1 %25, label %26, label %32

26:                                               ; preds = %4
  %27 = getelementptr inbounds nuw %struct.word_Put, ptr %0, i32 0, i32 0
  store i32 1, ptr %27, align 8
  %28 = getelementptr inbounds nuw %struct.word_Put, ptr %0, i32 0, i32 1
  store i8 0, ptr %28, align 4
  %29 = getelementptr i8, ptr %0, i64 5
  call void @llvm.memset.p0.i64(ptr align 1 %29, i8 0, i64 3, i1 false)
  %30 = getelementptr inbounds nuw %struct.word_Put, ptr %0, i32 0, i32 2
  %31 = getelementptr inbounds nuw %struct.word_Cell, ptr %8, i32 0, i32 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %30, ptr align 8 %31, i64 16, i1 false)
  br label %36

32:                                               ; preds = %4
  call void @llvm.memset.p0.i64(ptr align 8 %0, i8 0, i64 24, i1 false)
  %33 = getelementptr inbounds nuw %struct.word_Put, ptr %0, i32 0, i32 0
  %34 = getelementptr inbounds nuw %struct.word_Put, ptr %0, i32 0, i32 1
  %35 = getelementptr inbounds nuw %struct.word_Put, ptr %0, i32 0, i32 2
  br label %36

36:                                               ; preds = %32, %26
  ret void
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal i64 @mix(i64 noundef %0) #0 {
  %2 = alloca i64, align 8
  store i64 %0, ptr %2, align 8
  %3 = load i64, ptr %2, align 8
  %4 = lshr i64 %3, 30
  %5 = load i64, ptr %2, align 8
  %6 = xor i64 %5, %4
  store i64 %6, ptr %2, align 8
  %7 = load i64, ptr %2, align 8
  %8 = mul i64 %7, -4658895280553007687
  store i64 %8, ptr %2, align 8
  %9 = load i64, ptr %2, align 8
  %10 = lshr i64 %9, 27
  %11 = load i64, ptr %2, align 8
  %12 = xor i64 %11, %10
  store i64 %12, ptr %2, align 8
  %13 = load i64, ptr %2, align 8
  %14 = mul i64 %13, -7723592293110705685
  store i64 %14, ptr %2, align 8
  %15 = load i64, ptr %2, align 8
  %16 = load i64, ptr %2, align 8
  %17 = lshr i64 %16, 31
  %18 = xor i64 %15, %17
  ret i64 %18
}

; Function Attrs: nounwind
declare i32 @fprintf(ptr noundef, ptr noundef, ...) #4

; Function Attrs: noreturn
declare void @exit(i32 noundef) #7

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal zeroext i1 @record_rebuild(ptr noundef %0, i64 noundef %1, ptr noundef %2) #0 {
  %4 = alloca i1, align 1
  %5 = alloca ptr, align 8
  %6 = alloca i64, align 8
  %7 = alloca ptr, align 8
  %8 = alloca %struct.record_Map, align 8
  %9 = alloca ptr, align 8
  %10 = alloca i64, align 8
  %11 = alloca i64, align 8
  %12 = alloca %struct.record_Cell, align 8
  %13 = alloca %struct.record_Pair, align 8
  %14 = alloca i8, align 1
  %15 = alloca i64, align 8
  %16 = alloca i64, align 8
  %17 = alloca i64, align 8
  %18 = alloca i64, align 8
  %19 = alloca %struct.record_Put, align 8
  %20 = alloca %struct.record_Pair, align 8
  store ptr %0, ptr %5, align 8
  store i64 %1, ptr %6, align 8
  store ptr %2, ptr %7, align 8
  %21 = load i64, ptr %6, align 8
  %22 = icmp ugt i64 %21, 16384
  br i1 %22, label %29, label %23

23:                                               ; preds = %3
  %24 = load i64, ptr %6, align 8
  %25 = load ptr, ptr %5, align 8
  %26 = getelementptr inbounds nuw %struct.record_Map, ptr %25, i32 0, i32 0
  %27 = load i64, ptr %26, align 8
  %28 = icmp ult i64 %24, %27
  br i1 %28, label %29, label %30

29:                                               ; preds = %23, %3
  store i1 false, ptr %4, align 1
  br label %127

30:                                               ; preds = %23
  %31 = load i64, ptr %6, align 8
  %32 = icmp eq i64 %31, 0
  br i1 %32, label %33, label %34

33:                                               ; preds = %30
  store i1 true, ptr %4, align 1
  br label %127

34:                                               ; preds = %30
  %35 = load i64, ptr %6, align 8
  call void @record_new(ptr dead_on_unwind writable sret(%struct.record_Map) align 8 %8, i64 noundef %35)
  %36 = load ptr, ptr %5, align 8
  %37 = getelementptr inbounds nuw %struct.record_Map, ptr %36, i32 0, i32 2
  %38 = load ptr, ptr %37, align 8
  store ptr %38, ptr %9, align 8
  %39 = load ptr, ptr %5, align 8
  %40 = getelementptr inbounds nuw %struct.record_Map, ptr %39, i32 0, i32 0
  %41 = load i64, ptr %40, align 8
  store i64 %41, ptr %10, align 8
  %42 = load ptr, ptr %5, align 8
  %43 = getelementptr inbounds nuw %struct.record_Map, ptr %42, i32 0, i32 1
  %44 = load i64, ptr %43, align 8
  store i64 %44, ptr %11, align 8
  %45 = getelementptr inbounds nuw %struct.record_Map, ptr %8, i32 0, i32 2
  %46 = load ptr, ptr %45, align 8
  %47 = load ptr, ptr %5, align 8
  %48 = getelementptr inbounds nuw %struct.record_Map, ptr %47, i32 0, i32 2
  store ptr %46, ptr %48, align 8
  %49 = getelementptr inbounds nuw %struct.record_Map, ptr %8, i32 0, i32 0
  %50 = load i64, ptr %49, align 8
  %51 = load ptr, ptr %5, align 8
  %52 = getelementptr inbounds nuw %struct.record_Map, ptr %51, i32 0, i32 0
  store i64 %50, ptr %52, align 8
  %53 = getelementptr inbounds nuw %struct.record_Map, ptr %8, i32 0, i32 1
  %54 = load i64, ptr %53, align 8
  %55 = load ptr, ptr %5, align 8
  %56 = getelementptr inbounds nuw %struct.record_Map, ptr %55, i32 0, i32 1
  store i64 %54, ptr %56, align 8
  br label %57

57:                                               ; preds = %118, %68, %34
  %58 = load i64, ptr %10, align 8
  %59 = icmp ugt i64 %58, 0
  br i1 %59, label %60, label %119

60:                                               ; preds = %57
  %61 = load ptr, ptr %9, align 8
  %62 = load i64, ptr %10, align 8
  %63 = add i64 %62, -1
  store i64 %63, ptr %10, align 8
  %64 = getelementptr inbounds nuw %struct.record_Cell, ptr %61, i64 %63
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %12, ptr align 8 %64, i64 272, i1 false)
  %65 = getelementptr inbounds nuw %struct.record_Cell, ptr %12, i32 0, i32 0
  %66 = load i32, ptr %65, align 8
  %67 = icmp ne i32 %66, 2
  br i1 %67, label %68, label %69

68:                                               ; preds = %60
  br label %57, !llvm.loop !19

69:                                               ; preds = %60
  %70 = getelementptr inbounds nuw %struct.record_Cell, ptr %12, i32 0, i32 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %13, ptr align 8 %70, i64 264, i1 false)
  store i8 1, ptr %14, align 1
  br label %71

71:                                               ; preds = %117, %69
  %72 = load i8, ptr %14, align 1
  %73 = trunc i8 %72 to i1
  br i1 %73, label %74, label %118

74:                                               ; preds = %71
  %75 = load ptr, ptr %7, align 8
  %76 = getelementptr inbounds nuw %struct.record_Pair, ptr %13, i32 0, i32 0
  %77 = load i64, ptr %76, align 8
  %78 = call i64 @key_hash(ptr noundef %75, i64 noundef %77)
  store i64 %78, ptr %15, align 8
  %79 = load ptr, ptr %5, align 8
  %80 = getelementptr inbounds nuw %struct.record_Map, ptr %79, i32 0, i32 0
  %81 = load i64, ptr %80, align 8
  store i64 %81, ptr %16, align 8
  store i64 0, ptr %17, align 8
  br label %82

82:                                               ; preds = %114, %74
  %83 = load i64, ptr %17, align 8
  %84 = load i64, ptr %16, align 8
  %85 = icmp ult i64 %83, %84
  br i1 %85, label %86, label %117

86:                                               ; preds = %82
  %87 = load i64, ptr %15, align 8
  %88 = load i64, ptr %16, align 8
  %89 = urem i64 %87, %88
  %90 = load i64, ptr %17, align 8
  %91 = load i64, ptr %16, align 8
  %92 = call i64 @probe(i64 noundef %89, i64 noundef %90, i64 noundef %91)
  store i64 %92, ptr %18, align 8
  %93 = load ptr, ptr %5, align 8
  %94 = getelementptr inbounds nuw %struct.record_Map, ptr %93, i32 0, i32 2
  %95 = load ptr, ptr %94, align 8
  %96 = load i64, ptr %18, align 8
  %97 = getelementptr inbounds nuw %struct.record_Cell, ptr %95, i64 %96
  %98 = getelementptr inbounds nuw %struct.record_Cell, ptr %97, i32 0, i32 0
  %99 = load i32, ptr %98, align 8
  %100 = icmp ne i32 %99, 2
  br i1 %100, label %101, label %113

101:                                              ; preds = %86
  %102 = load ptr, ptr %5, align 8
  %103 = load i64, ptr %18, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %20, ptr align 8 %13, i64 264, i1 false)
  call void @record_exchange(ptr dead_on_unwind writable sret(%struct.record_Put) align 8 %19, ptr noundef %102, i64 noundef %103, ptr noundef %20)
  %104 = getelementptr inbounds nuw %struct.record_Put, ptr %19, i32 0, i32 0
  %105 = load i32, ptr %104, align 8
  %106 = icmp ne i32 %105, 0
  %107 = zext i1 %106 to i8
  store i8 %107, ptr %14, align 1
  %108 = load i8, ptr %14, align 1
  %109 = trunc i8 %108 to i1
  br i1 %109, label %110, label %112

110:                                              ; preds = %101
  %111 = getelementptr inbounds nuw %struct.record_Put, ptr %19, i32 0, i32 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %13, ptr align 8 %111, i64 264, i1 false)
  br label %112

112:                                              ; preds = %110, %101
  br label %117

113:                                              ; preds = %86
  br label %114

114:                                              ; preds = %113
  %115 = load i64, ptr %17, align 8
  %116 = add i64 %115, 1
  store i64 %116, ptr %17, align 8
  br label %82, !llvm.loop !20

117:                                              ; preds = %112, %82
  br label %71, !llvm.loop !21

118:                                              ; preds = %71
  br label %57, !llvm.loop !19

119:                                              ; preds = %57
  %120 = load i64, ptr %11, align 8
  %121 = icmp ne i64 %120, 0
  br i1 %121, label %122, label %124

122:                                              ; preds = %119
  %123 = load ptr, ptr %9, align 8
  call void @free(ptr noundef %123)
  br label %124

124:                                              ; preds = %122, %119
  %125 = load ptr, ptr %5, align 8
  %126 = getelementptr inbounds nuw %struct.record_Map, ptr %125, i32 0, i32 4
  store i64 0, ptr %126, align 8
  store i1 true, ptr %4, align 1
  br label %127

127:                                              ; preds = %124, %33, %29
  %128 = load i1, ptr %4, align 1
  ret i1 %128
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal void @record_try_put(ptr dead_on_unwind noalias writable sret(%struct.record_Put) align 8 %0, ptr noundef %1, ptr noundef %2, ptr noundef %3) #0 {
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca i64, align 8
  %9 = alloca i64, align 8
  %10 = alloca i64, align 8
  %11 = alloca i64, align 8
  %12 = alloca i64, align 8
  %13 = alloca ptr, align 8
  %14 = alloca %struct.record_Pair, align 8
  %15 = alloca %struct.record_Pair, align 8
  store ptr %1, ptr %5, align 8
  store ptr %2, ptr %6, align 8
  store ptr %3, ptr %7, align 8
  %16 = load ptr, ptr %6, align 8
  %17 = getelementptr inbounds nuw %struct.record_Pair, ptr %3, i32 0, i32 0
  %18 = load i64, ptr %17, align 8
  %19 = call i64 @key_hash(ptr noundef %16, i64 noundef %18)
  store i64 %19, ptr %8, align 8
  %20 = load ptr, ptr %5, align 8
  %21 = getelementptr inbounds nuw %struct.record_Map, ptr %20, i32 0, i32 0
  %22 = load i64, ptr %21, align 8
  store i64 %22, ptr %9, align 8
  %23 = load i64, ptr %9, align 8
  store i64 %23, ptr %10, align 8
  %24 = load i64, ptr %9, align 8
  %25 = icmp ugt i64 %24, 0
  br i1 %25, label %26, label %93

26:                                               ; preds = %4
  %27 = load i64, ptr %8, align 8
  %28 = load i64, ptr %9, align 8
  %29 = urem i64 %27, %28
  store i64 %29, ptr %11, align 8
  store i64 0, ptr %12, align 8
  br label %30

30:                                               ; preds = %89, %26
  %31 = load i64, ptr %12, align 8
  %32 = load i64, ptr %9, align 8
  %33 = icmp ult i64 %31, %32
  br i1 %33, label %34, label %92

34:                                               ; preds = %30
  %35 = load ptr, ptr %5, align 8
  %36 = getelementptr inbounds nuw %struct.record_Map, ptr %35, i32 0, i32 2
  %37 = load ptr, ptr %36, align 8
  %38 = load i64, ptr %11, align 8
  %39 = getelementptr inbounds nuw %struct.record_Cell, ptr %37, i64 %38
  store ptr %39, ptr %13, align 8
  %40 = load ptr, ptr %13, align 8
  %41 = getelementptr inbounds nuw %struct.record_Cell, ptr %40, i32 0, i32 0
  %42 = load i32, ptr %41, align 8
  %43 = icmp eq i32 %42, 2
  br i1 %43, label %44, label %55

44:                                               ; preds = %34
  %45 = load ptr, ptr %13, align 8
  %46 = getelementptr inbounds nuw %struct.record_Cell, ptr %45, i32 0, i32 1
  %47 = getelementptr inbounds nuw %struct.record_Pair, ptr %46, i32 0, i32 0
  %48 = load i64, ptr %47, align 8
  %49 = getelementptr inbounds nuw %struct.record_Pair, ptr %3, i32 0, i32 0
  %50 = load i64, ptr %49, align 8
  %51 = icmp eq i64 %48, %50
  br i1 %51, label %52, label %55

52:                                               ; preds = %44
  %53 = load ptr, ptr %5, align 8
  %54 = load i64, ptr %11, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %14, ptr align 8 %3, i64 264, i1 false)
  call void @record_exchange(ptr dead_on_unwind writable sret(%struct.record_Put) align 8 %0, ptr noundef %53, i64 noundef %54, ptr noundef %14)
  br label %133

55:                                               ; preds = %44, %34
  %56 = load ptr, ptr %13, align 8
  %57 = getelementptr inbounds nuw %struct.record_Cell, ptr %56, i32 0, i32 0
  %58 = load i32, ptr %57, align 8
  %59 = icmp eq i32 %58, 0
  br i1 %59, label %60, label %67

60:                                               ; preds = %55
  %61 = load i64, ptr %10, align 8
  %62 = load i64, ptr %9, align 8
  %63 = icmp eq i64 %61, %62
  br i1 %63, label %64, label %66

64:                                               ; preds = %60
  %65 = load i64, ptr %11, align 8
  store i64 %65, ptr %10, align 8
  br label %66

66:                                               ; preds = %64, %60
  br label %92

67:                                               ; preds = %55
  %68 = load ptr, ptr %13, align 8
  %69 = getelementptr inbounds nuw %struct.record_Cell, ptr %68, i32 0, i32 0
  %70 = load i32, ptr %69, align 8
  %71 = icmp eq i32 %70, 1
  br i1 %71, label %72, label %78

72:                                               ; preds = %67
  %73 = load i64, ptr %10, align 8
  %74 = load i64, ptr %9, align 8
  %75 = icmp eq i64 %73, %74
  br i1 %75, label %76, label %78

76:                                               ; preds = %72
  %77 = load i64, ptr %11, align 8
  store i64 %77, ptr %10, align 8
  br label %78

78:                                               ; preds = %76, %72, %67
  %79 = load i64, ptr %11, align 8
  %80 = add i64 %79, 1
  %81 = load i64, ptr %9, align 8
  %82 = icmp ult i64 %80, %81
  br i1 %82, label %83, label %86

83:                                               ; preds = %78
  %84 = load i64, ptr %11, align 8
  %85 = add i64 %84, 1
  br label %87

86:                                               ; preds = %78
  br label %87

87:                                               ; preds = %86, %83
  %88 = phi i64 [ %85, %83 ], [ 0, %86 ]
  store i64 %88, ptr %11, align 8
  br label %89

89:                                               ; preds = %87
  %90 = load i64, ptr %12, align 8
  %91 = add i64 %90, 1
  store i64 %91, ptr %12, align 8
  br label %30, !llvm.loop !22

92:                                               ; preds = %66, %30
  br label %93

93:                                               ; preds = %92, %4
  %94 = load i64, ptr %10, align 8
  %95 = load i64, ptr %9, align 8
  %96 = icmp ult i64 %94, %95
  br i1 %96, label %97, label %128

97:                                               ; preds = %93
  %98 = load ptr, ptr %5, align 8
  %99 = getelementptr inbounds nuw %struct.record_Map, ptr %98, i32 0, i32 3
  %100 = load i64, ptr %99, align 8
  %101 = icmp ult i64 %100, 16384
  br i1 %101, label %102, label %128

102:                                              ; preds = %97
  %103 = load ptr, ptr %5, align 8
  %104 = getelementptr inbounds nuw %struct.record_Map, ptr %103, i32 0, i32 3
  %105 = load i64, ptr %104, align 8
  %106 = add i64 %105, 1
  store i64 %106, ptr %104, align 8
  %107 = load ptr, ptr %5, align 8
  %108 = getelementptr inbounds nuw %struct.record_Map, ptr %107, i32 0, i32 2
  %109 = load ptr, ptr %108, align 8
  %110 = load i64, ptr %10, align 8
  %111 = getelementptr inbounds nuw %struct.record_Cell, ptr %109, i64 %110
  %112 = getelementptr inbounds nuw %struct.record_Cell, ptr %111, i32 0, i32 0
  %113 = load i32, ptr %112, align 8
  %114 = icmp eq i32 %113, 1
  br i1 %114, label %115, label %125

115:                                              ; preds = %102
  %116 = load ptr, ptr %5, align 8
  %117 = getelementptr inbounds nuw %struct.record_Map, ptr %116, i32 0, i32 4
  %118 = load i64, ptr %117, align 8
  %119 = icmp ugt i64 %118, 0
  br i1 %119, label %120, label %125

120:                                              ; preds = %115
  %121 = load ptr, ptr %5, align 8
  %122 = getelementptr inbounds nuw %struct.record_Map, ptr %121, i32 0, i32 4
  %123 = load i64, ptr %122, align 8
  %124 = add i64 %123, -1
  store i64 %124, ptr %122, align 8
  br label %125

125:                                              ; preds = %120, %115, %102
  %126 = load ptr, ptr %5, align 8
  %127 = load i64, ptr %10, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %15, ptr align 8 %3, i64 264, i1 false)
  call void @record_exchange(ptr dead_on_unwind writable sret(%struct.record_Put) align 8 %0, ptr noundef %126, i64 noundef %127, ptr noundef %15)
  br label %133

128:                                              ; preds = %97, %93
  %129 = getelementptr inbounds nuw %struct.record_Put, ptr %0, i32 0, i32 0
  store i32 1, ptr %129, align 8
  %130 = getelementptr inbounds nuw %struct.record_Put, ptr %0, i32 0, i32 1
  store i8 1, ptr %130, align 4
  %131 = getelementptr i8, ptr %0, i64 5
  call void @llvm.memset.p0.i64(ptr align 1 %131, i8 0, i64 3, i1 false)
  %132 = getelementptr inbounds nuw %struct.record_Put, ptr %0, i32 0, i32 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %132, ptr align 8 %3, i64 264, i1 false)
  br label %133

133:                                              ; preds = %128, %125, %52
  ret void
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal void @record_exchange(ptr dead_on_unwind noalias writable sret(%struct.record_Put) align 8 %0, ptr noundef %1, i64 noundef %2, ptr noundef %3) #0 {
  %5 = alloca ptr, align 8
  %6 = alloca i64, align 8
  %7 = alloca ptr, align 8
  %8 = alloca %struct.record_Cell, align 8
  %9 = alloca %struct.record_Cell, align 8
  store ptr %1, ptr %5, align 8
  store i64 %2, ptr %6, align 8
  store ptr %3, ptr %7, align 8
  %10 = load ptr, ptr %5, align 8
  %11 = getelementptr inbounds nuw %struct.record_Map, ptr %10, i32 0, i32 2
  %12 = load ptr, ptr %11, align 8
  %13 = load i64, ptr %6, align 8
  %14 = getelementptr inbounds nuw %struct.record_Cell, ptr %12, i64 %13
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %8, ptr align 8 %14, i64 272, i1 false)
  %15 = load ptr, ptr %5, align 8
  %16 = getelementptr inbounds nuw %struct.record_Map, ptr %15, i32 0, i32 2
  %17 = load ptr, ptr %16, align 8
  %18 = load i64, ptr %6, align 8
  %19 = getelementptr inbounds nuw %struct.record_Cell, ptr %17, i64 %18
  %20 = getelementptr inbounds nuw %struct.record_Cell, ptr %9, i32 0, i32 0
  store i32 2, ptr %20, align 8
  %21 = getelementptr i8, ptr %9, i64 4
  call void @llvm.memset.p0.i64(ptr align 4 %21, i8 0, i64 4, i1 false)
  %22 = getelementptr inbounds nuw %struct.record_Cell, ptr %9, i32 0, i32 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %22, ptr align 8 %3, i64 264, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %19, ptr align 8 %9, i64 272, i1 false)
  %23 = getelementptr inbounds nuw %struct.record_Cell, ptr %8, i32 0, i32 0
  %24 = load i32, ptr %23, align 8
  %25 = icmp eq i32 %24, 2
  br i1 %25, label %26, label %32

26:                                               ; preds = %4
  %27 = getelementptr inbounds nuw %struct.record_Put, ptr %0, i32 0, i32 0
  store i32 1, ptr %27, align 8
  %28 = getelementptr inbounds nuw %struct.record_Put, ptr %0, i32 0, i32 1
  store i8 0, ptr %28, align 4
  %29 = getelementptr i8, ptr %0, i64 5
  call void @llvm.memset.p0.i64(ptr align 1 %29, i8 0, i64 3, i1 false)
  %30 = getelementptr inbounds nuw %struct.record_Put, ptr %0, i32 0, i32 2
  %31 = getelementptr inbounds nuw %struct.record_Cell, ptr %8, i32 0, i32 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %30, ptr align 8 %31, i64 264, i1 false)
  br label %36

32:                                               ; preds = %4
  call void @llvm.memset.p0.i64(ptr align 8 %0, i8 0, i64 272, i1 false)
  %33 = getelementptr inbounds nuw %struct.record_Put, ptr %0, i32 0, i32 0
  %34 = getelementptr inbounds nuw %struct.record_Put, ptr %0, i32 0, i32 1
  %35 = getelementptr inbounds nuw %struct.record_Put, ptr %0, i32 0, i32 2
  br label %36

36:                                               ; preds = %32, %26
  ret void
}

attributes #0 = { noinline nounwind optnone ssp uwtable(sync) "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #1 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #4 = { nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #5 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #6 = { allocsize(0) "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #7 = { noreturn "frame-pointer"="non-leaf" "no-trapping-math"="true" "probe-stack"="__chkstk_darwin" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+altnzcv,+bti,+ccdp,+ccidx,+ccpp,+complxnum,+crc,+dit,+dotprod,+flagm,+fp-armv8,+fp16fml,+fptoint,+fullfp16,+jsconv,+lse,+neon,+pauth,+perfmon,+predres,+ras,+rcpc,+rdm,+sb,+sha2,+sha3,+specrestrict,+ssbs,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a" }
attributes #8 = { allocsize(0) }
attributes #9 = { nounwind }
attributes #10 = { noreturn }

!llvm.module.flags = !{!0, !1, !2, !3, !4}
!llvm.ident = !{!5}

!0 = !{i32 2, !"SDK Version", [2 x i32] [i32 27, i32 0]}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 1}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{!"Apple clang version 21.0.0 (clang-2100.3.34.2)"}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.mustprogress"}
!8 = distinct !{!8, !7}
!9 = distinct !{!9, !7}
!10 = distinct !{!10, !7}
!11 = distinct !{!11, !7}
!12 = distinct !{!12, !7}
!13 = distinct !{!13, !7}
!14 = distinct !{!14, !7}
!15 = distinct !{!15, !7}
!16 = distinct !{!16, !7}
!17 = distinct !{!17, !7}
!18 = distinct !{!18, !7}
!19 = distinct !{!19, !7}
!20 = distinct !{!20, !7}
!21 = distinct !{!21, !7}
!22 = distinct !{!22, !7}
