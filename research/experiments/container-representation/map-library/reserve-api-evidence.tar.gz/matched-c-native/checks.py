from pathlib import Path
import collections,csv,hashlib,json,os,subprocess
D=Path(__file__).resolve().parent
assert os.environ.get('WHITEFOOT_CHECK_OWNER'), 'run through run-check.pl'
records=[]
def run(name,mode,args,diagnostic=None):
 argv=[str(D/f'matched-{mode}'),*args]
 result=subprocess.run(argv,capture_output=True,text=True)
 (D/(name+'.stdout')).write_text(result.stdout);(D/(name+'.stderr')).write_text(result.stderr)
 valid=result.returncode==0 if diagnostic is None else result.returncode!=0 and diagnostic in result.stderr
 records.append({'name':name,'argv':argv,'exit':result.returncode,'expected_diagnostic':diagnostic,'matched':valid})
 (D/'checks-status.json').write_text(json.dumps(records,indent=2)+'\n')
 assert valid,(name,result.returncode,result.stdout,result.stderr)
for mode in ('timed','account'):
 run('routing-'+mode,mode,['paired-routing-check'])
 run('reserve-check-'+mode,mode,['reserve-check'])
run('account-ledger','account',['reserve-account'])
rows=list(csv.DictReader((D/'account-ledger.stdout').open()))
base_path=D.parent/'build/ecosystem/reserve-accounting.csv'
base=list(csv.DictReader(base_path.open()))
assert len(rows)==128 and len(base)==96
as_tuple=lambda row:tuple(sorted(row.items()))
for selected,omitted in [('whitefoot-A','c-matched-reserve'),('c-matched-reserve','whitefoot-A')]:
 projected=[]
 for row in rows:
  if row['variant']==omitted:continue
  row=row.copy()
  if row['variant']==selected:row['variant']='whitefoot-hash-map'
  projected.append(row)
 assert collections.Counter(map(as_tuple,projected))==collections.Counter(map(as_tuple,base)),selected
(D/'ledger-projection.json').write_text(json.dumps({'rows':len(rows),'production_rows':len(base),'WF_and_C_projections_native_rows_exact':True,'source_sha256':hashlib.sha256(base_path.read_bytes()).hexdigest()},indent=2)+'\n')
faults={'receipt':'reserve public success result','omitted':'reserve application entry floor','payload':'reserve independent complete-owner oracle','population':'reserve prepared population','capacity':'reserve application entry floor','leak':'every allocation is reclaimed','allocation':'reserve noop has no allocation'}
for peer in range(4):
 for fault,diagnostic in faults.items():run(f'negative-{peer}-{fault}','account',['negative-reserve-api',fault,str(peer)],diagnostic)
for peer in range(2):run(f'negative-{peer}-raw-slots','account',['negative-reserve-api','raw-slots',str(peer)],'reserve future puts retain backing capacity')
for mode in ('timed','account'):
 for fault in ('step','cleanup'):run(f'negative-routing-{mode}-{fault}',mode,['negative-arm-routing',fault],'reserve distinct arm dispatch')
for fault,diagnostic in [('quantized','reserve clock quantum at most 100 ns'),('backwards','reserve clock nondecreasing')]:
 run('negative-clock-'+fault,'timed',['negative-reserve-clock',fault],diagnostic)
print(json.dumps({'commands':len(records),'positive':sum(r['exit']==0 for r in records),'expected_rejections':sum(r['exit']!=0 for r in records),'timing_run':False}))
