/* Untimed source-local witnesses for paths outside the fixed reserve panel. */
#define ACCOUNT_ONLY 1
#include "matched-reserve.c"
static uint64_t requests, releases, live;
typedef union { max_align_t alignment; uint64_t bytes; } Header;
void *wf_cost_allocate(uint64_t bytes) {
    Header *h = malloc(sizeof *h + bytes); require(h != NULL, "policy allocation");
    h->bytes = bytes; ++requests; live += bytes; return h + 1;
}
void wf_cost_release(void *pointer) {
    Header *h = (Header *)pointer - 1;
    require(live >= h->bytes, "policy release extent");
    live -= h->bytes; ++releases; free(h);
}
#define POLICY(P) \
static void P##_policy(void) { \
    Env env = {0, true}; P##_Map map = P##_new(0); \
    uint64_t before = requests; \
    P##_Put result = P##_try_put(&map, &env, (P##_Pair){9, P##_make(29)}); \
    require(result.tag == 1 && result.reason && result.pair.key == 9, "zero full refusal"); \
    require(P##_content(result.pair.key, result.pair.value) == P##_content(9, P##_make(29)), "complete refused value"); \
    require(P##_reserve(&map, 0, &env) && !P##_reserve(&map, CEILING + 1, &env) \
        && map.len == 0 && requests == before, "zero and over-ceiling no allocation"); \
    map = P##_new(3); \
    for (uint64_t i = 0; i < 3; ++i) require(P##_try_put(&map, &env, (P##_Pair){i * 2 + 1, P##_make(10 + i)}).tag == 0, "fill three"); \
    result = P##_try_put(&map, &env, (P##_Pair){9, P##_make(29)}); \
    require(result.tag == 1 && result.reason && result.pair.key == 9 \
        && P##_content(9, result.pair.value) == P##_content(9, P##_make(29)), "full complete offered owner"); \
    map.payload[0] = (P##_Cell){.tag = DELETED}; --map.length; ++map.vacated; \
    result = P##_try_put(&map, &env, (P##_Pair){5, P##_make(55)}); \
    require(result.tag == 1 && !result.reason && result.pair.key == 5 \
        && P##_content(5, result.pair.value) == P##_content(5, P##_make(12)) \
        && map.length == 2 && map.vacated == 1, "duplicate beyond tombstone preserves complete old owner"); \
    require(P##_try_put(&map, &env, (P##_Pair){7, P##_make(77)}).tag == 0 \
        && map.payload[0].pair.key == 7 && map.length == 3 && map.vacated == 0, "first tombstone reuse"); \
    P##_Cell *saved = map.payload; before = requests; \
    require(!P##_reserve(&map, CEILING + 1, &env) && map.payload == saved \
        && map.length == 3 && requests == before, "over-ceiling retains backing and population"); \
    wf_cost_release(map.payload); map = P##_new(8); \
    for (uint64_t i = 0; i < 6; ++i) require(P##_put(&map, &env, (P##_Pair){i * 2 + 1, P##_make(i)}).tag == 0, "pressure preparation"); \
    before = requests; \
    require(P##_put(&map, &env, (P##_Pair){99, P##_make(88)}).tag == 0 \
        && map.len == 16 && map.length == 7 && requests == before + 1, "ordinary pressure doubles"); \
    wf_cost_release(map.payload); map = P##_new(8); \
    require(P##_put(&map, &env, (P##_Pair){1, P##_make(10)}).tag == 0, "sparse pressure live owner"); \
    for (uint64_t i = 1; i < 6; ++i) map.payload[i].tag = DELETED; map.vacated = 5; \
    before = requests; \
    require(P##_put(&map, &env, (P##_Pair){3, P##_make(11)}).tag == 0 \
        && map.len == 8 && map.length == 2 && map.vacated == 0 && requests == before + 1, "sparse pressure rebuilds same capacity"); \
    wf_cost_release(map.payload); \
    require(live == 0 && requests == releases, "policy complete backing release"); \
}
POLICY(word)
POLICY(record)
int main(void) {
    word_policy(); record_policy();
    puts("matched C policy: both widths zero/full/over-ceiling ownership, tombstone replacement/reuse, pressure growth and same-capacity rebuild passed");
    return 0;
}
