/* Scratch C attribution for the existing isolated-reserve harness.
 * See criterion.txt and provenance.txt. No forced helper/copy attributes. */
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef ACCOUNT_ONLY
extern void *wf_cost_allocate(uint64_t bytes);
extern void wf_cost_release(void *pointer);
#else
#define wf_cost_allocate malloc
#define wf_cost_release free
#endif

enum { VACANT, DELETED, FILLED, CEILING = 16384 };
typedef struct { uint64_t words[32]; } Record;
typedef struct { uint64_t salt; bool collide; } Env;
typedef struct { uint64_t ordered, sum, parity, count; } Digest;
static _Alignas(8) unsigned char empty_anchor[8];
static void require(bool condition, const char *message) {
    if (!condition) { fprintf(stderr, "matched reserve: %s\n", message); exit(1); }
}
static uint64_t mix(uint64_t value) {
    value ^= value >> 30; value *= UINT64_C(0xbf58476d1ce4e5b9);
    value ^= value >> 27; value *= UINT64_C(0x94d049bb133111eb);
    return value ^ (value >> 31);
}
static uint64_t key_hash(const Env *env, uint64_t key) {
    return env->collide ? 0 : mix(key ^ env->salt);
}
static uint64_t slots(uint64_t total) {
    return total == 0 || total > 8192 ? 0 : 4 * (total - 1) / 3 + 1;
}
static uint64_t probe(uint64_t home, uint64_t step, uint64_t count) {
    uint64_t remaining = count - home;
    return step >= remaining ? step - remaining : home + step;
}
static uint64_t word_make(uint64_t seed) { return seed; }
static Record record_make(uint64_t seed) {
    Record result;
    for (unsigned i = 0; i < 32; ++i) result.words[i] = seed + i;
    return result;
}
static void word_damage(uint64_t *value) { ++*value; }
static void record_damage(Record *value) { ++value->words[31]; }
static uint64_t word_content(uint64_t key, uint64_t value) { return key * 131 + value; }
static uint64_t record_content(uint64_t key, Record value) {
    for (unsigned i = 0; i < 32; ++i) key = key * 131 + value.words[i];
    return key;
}
static void consume(Digest *digest, uint64_t content) {
    digest->sum += content; digest->parity ^= mix(content); ++digest->count;
}
static uint64_t digest_finish(Digest digest) {
    return mix(digest.ordered) ^ mix(digest.sum) ^ digest.parity
        ^ digest.count * UINT64_C(0x9e3779b97f4a7c15);
}

/* Typed instantiation keeps the same concrete value widths without a dynamic
 * width branch. Aggregate assignment is ordinary C; no forced swap copies. */
#define RESERVE_CONTROL(P, V, CELL_BYTES) \
typedef struct { uint64_t key; V value; } P##_Pair; \
typedef struct { uint32_t tag; P##_Pair pair; } P##_Cell; \
typedef struct { uint64_t len, cap; P##_Cell *payload; uint64_t length, vacated; } P##_Map; \
typedef struct { uint32_t tag; bool reason; P##_Pair pair; } P##_Put; \
typedef struct { P##_Map map; Env env; uint64_t seed, count; } P##_Owner; \
_Static_assert(sizeof(P##_Cell) == CELL_BYTES && offsetof(P##_Cell, pair) == 8 \
    && offsetof(P##_Pair, value) == 8, "matched enum cell layout"); \
_Static_assert(sizeof(P##_Map) == 40 && offsetof(P##_Map, payload) == 16 \
    && offsetof(P##_Map, vacated) == 32, "matched inline map layout"); \
_Static_assert(sizeof(P##_Put) == CELL_BYTES && offsetof(P##_Put, reason) == 4 \
    && offsetof(P##_Put, pair) == 8, "matched returned pair layout"); \
_Static_assert(sizeof(P##_Owner) == 72 && _Alignof(P##_Owner) <= 16, "harness owner storage"); \
static P##_Map P##_new(uint64_t capacity) { \
    require(capacity <= CEILING, "physical capacity ceiling"); \
    P##_Cell *cells = capacity ? wf_cost_allocate(capacity * sizeof *cells) : (void *)empty_anchor; \
    require(cells != NULL, "allocation"); \
    /* Fresh Vacant: tag AND payload zero; padding has no semantic role. */ \
    for (uint64_t i = 0; i < capacity; ++i) cells[i] = (P##_Cell){0}; \
    return (P##_Map){capacity, capacity, cells, 0, 0}; \
} \
static P##_Put P##_exchange(P##_Map *map, uint64_t index, P##_Pair pair) { \
    P##_Cell old = map->payload[index]; \
    map->payload[index] = (P##_Cell){.tag = FILLED, .pair = pair}; \
    if (old.tag == FILLED) return (P##_Put){.tag = 1, .reason = false, .pair = old.pair}; \
    return (P##_Put){.tag = 0}; \
} \
static P##_Put P##_try_put(P##_Map *map, const Env *env, P##_Pair pair) { \
    uint64_t hash = key_hash(env, pair.key), count = map->len, available = count; \
    if (count > 0) { \
        uint64_t index = hash % count; \
        for (uint64_t step = 0; step < count; ++step) { \
            const P##_Cell *cell = &map->payload[index]; \
            if (cell->tag == FILLED && cell->pair.key == pair.key) \
                return P##_exchange(map, index, pair); \
            if (cell->tag == VACANT) { if (available == count) available = index; break; } \
            if (cell->tag == DELETED && available == count) available = index; \
            index = index + 1 < count ? index + 1 : 0; \
        } \
    } \
    if (available < count && map->length < CEILING) { \
        ++map->length; \
        if (map->payload[available].tag == DELETED && map->vacated > 0) --map->vacated; \
        return P##_exchange(map, available, pair); \
    } \
    return (P##_Put){.tag = 1, .reason = true, .pair = pair}; \
} \
static bool P##_rebuild(P##_Map *map, uint64_t capacity, const Env *env) { \
    if (capacity > CEILING || capacity < map->len) return false; \
    if (capacity == 0) return true; \
    P##_Map fresh = P##_new(capacity); \
    P##_Cell *previous = map->payload; \
    uint64_t old_count = map->len, old_cap = map->cap; \
    map->payload = fresh.payload; map->len = fresh.len; map->cap = fresh.cap; \
    while (old_count > 0) { \
        P##_Cell old = previous[--old_count]; \
        if (old.tag != FILLED) continue; \
        P##_Pair pending = old.pair; \
        bool occupied = true; \
        while (occupied) { \
            uint64_t hash = key_hash(env, pending.key), count = map->len; \
            for (uint64_t step = 0; step < count; ++step) { \
                uint64_t index = probe(hash % count, step, count); \
                if (map->payload[index].tag != FILLED) { \
                    P##_Put exchanged = P##_exchange(map, index, pending); \
                    occupied = exchanged.tag != 0; \
                    if (occupied) pending = exchanged.pair; \
                    break; \
                } \
            } \
        } \
    } \
    if (old_cap != 0) wf_cost_release(previous); \
    map->vacated = 0; \
    return true; \
} \
static bool P##_reserve(P##_Map *map, uint64_t capacity, const Env *env) { \
    if (capacity > CEILING) return false; \
    if (capacity <= map->len) return true; \
    return P##_rebuild(map, capacity, env); \
} \
static P##_Put P##_put(P##_Map *map, const Env *env, P##_Pair pair) { \
    uint64_t buckets = map->len, limit = buckets - buckets / 4; \
    uint64_t used = UINT64_MAX - map->length < map->vacated ? UINT64_MAX : map->length + map->vacated; \
    if (used >= limit && buckets < CEILING) { \
        uint64_t target = CEILING; \
        if (map->length < limit / 2) target = buckets; \
        else if (buckets == 0) target = 1; \
        else if (buckets <= CEILING / 2) target = buckets * 2; \
        (void)P##_rebuild(map, target, env); \
    } \
    return P##_try_put(map, env, pair); \
} \
void eco_c_map_reserve_##P##_prepare(void *storage, uint64_t total, uint64_t count, uint64_t seed) { \
    P##_Owner *owner = storage; \
    *owner = (P##_Owner){P##_new(slots(total)), {seed ^ UINT64_C(0x9e3779b97f4a7c15), false}, seed, count}; \
    for (uint64_t i = 0; i < count; ++i) { \
        P##_Put result = P##_put(&owner->map, &owner->env, (P##_Pair){i * 2 + 1, P##_make(seed + i)}); \
        require(result.tag == 0, "prepared fresh insertion"); \
    } \
} \
uint64_t eco_c_map_reserve_##P##_raw(void *storage, uint64_t capacity) { \
    P##_Owner *owner = storage; \
    return P##_reserve(&owner->map, capacity, &owner->env); \
} \
uint64_t eco_c_map_reserve_##P##_step(void *storage, uint64_t total) { \
    return eco_c_map_reserve_##P##_raw(storage, slots(total)); \
} \
uint64_t eco_c_map_reserve_##P##_geometry(const void *storage) { \
    const P##_Owner *owner = storage; \
    return (owner->map.len << 32) + owner->map.length; \
} \
uint64_t eco_c_map_reserve_##P##_insert(void *storage, uint64_t index, uint64_t corrupt) { \
    P##_Owner *owner = storage; \
    V value = P##_make(owner->seed + index); \
    if (corrupt) P##_damage(&value); \
    P##_Put result = P##_put(&owner->map, &owner->env, (P##_Pair){index * 2 + 1, value}); \
    if (result.tag != 0) { \
        /* Match WF consumption of the complete returned scalar/Record owner. */ \
        (void)P##_content(result.pair.key, result.pair.value); \
        return 0; \
    } \
    return 1; \
} \
uint64_t eco_c_map_reserve_##P##_finish(void *storage) { \
    P##_Owner *owner = storage; \
    Digest digest = {owner->seed, 0, 0, 0}; \
    while (owner->map.len > 0) { \
        P##_Cell old = owner->map.payload[--owner->map.len]; \
        if (old.tag == FILLED) consume(&digest, P##_content(old.pair.key, old.pair.value)); \
    } \
    if (owner->map.cap != 0) wf_cost_release(owner->map.payload); \
    memset(owner, 0, sizeof *owner); \
    return digest_finish(digest); \
}

RESERVE_CONTROL(word, uint64_t, 24)
RESERVE_CONTROL(record, Record, 272)
#undef RESERVE_CONTROL
