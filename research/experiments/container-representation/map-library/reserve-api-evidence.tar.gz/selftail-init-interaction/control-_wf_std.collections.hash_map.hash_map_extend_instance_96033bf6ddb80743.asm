0000000000009fc4 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743>:
    9fc4: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    9fc8: a90157f6     	stp	x22, x21, [sp, #0x10]
    9fcc: a9024ff4     	stp	x20, x19, [sp, #0x20]
    9fd0: a9037bfd     	stp	x29, x30, [sp, #0x30]
    9fd4: aa0103f4     	mov	x20, x1
    9fd8: aa0003f3     	mov	x19, x0
    9fdc: a9405817     	ldp	x23, x22, [x0]
    9fe0: eb0102df     	cmp	x22, x1
    9fe4: 54000302     	b.hs	0xa044 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x80>
    9fe8: f9400a75     	ldr	x21, [x19, #0x10]
    9fec: 8b141288     	add	x8, x20, x20, lsl #4
    9ff0: d37ced01     	lsl	x1, x8, #4
    9ff4: f10002df     	cmp	x22, #0x0
    9ff8: fa5612e0     	ccmp	x23, x22, #0x0, ne
    9ffc: 540001c0     	b.eq	0xa034 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x70>
    a000: aa0103e0     	mov	x0, x1
    a004: 94000000     	bl	0xa004 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x40>
		000000000000a004:  ARM64_RELOC_BRANCH26	_malloc
    a008: b4000560     	cbz	x0, 0xa0b4 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xf0>
    a00c: b40001b6     	cbz	x22, 0xa040 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x7c>
    a010: 8b1712e8     	add	x8, x23, x23, lsl #4
    a014: d37ced02     	lsl	x2, x8, #4
    a018: aa0003f6     	mov	x22, x0
    a01c: aa1503e1     	mov	x1, x21
    a020: 94000000     	bl	0xa020 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x5c>
		000000000000a020:  ARM64_RELOC_BRANCH26	_memcpy
    a024: aa1503e0     	mov	x0, x21
    a028: 94000000     	bl	0xa028 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x64>
		000000000000a028:  ARM64_RELOC_BRANCH26	_free
    a02c: aa1603e0     	mov	x0, x22
    a030: 14000004     	b	0xa040 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x7c>
    a034: aa1503e0     	mov	x0, x21
    a038: 94000000     	bl	0xa038 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x74>
		000000000000a038:  ARM64_RELOC_BRANCH26	_realloc
    a03c: b40003c0     	cbz	x0, 0xa0b4 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xf0>
    a040: a9008274     	stp	x20, x0, [x19, #0x8]
    a044: eb1402ff     	cmp	x23, x20
    a048: 540002a2     	b.hs	0xa09c <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xd8>
    a04c: f9400a68     	ldr	x8, [x19, #0x10]
    a050: 52802209     	mov	w9, #0x110              ; =272
    a054: 9b0922e8     	madd	x8, x23, x9, x8
    a058: 91002108     	add	x8, x8, #0x8
    a05c: 6f00e400     	movi.2d	v0, #0000000000000000
    a060: b81f811f     	stur	wzr, [x8, #-0x8]
    a064: 910006f7     	add	x23, x23, #0x1
    a068: ad000100     	stp	q0, q0, [x8]
    a06c: ad010100     	stp	q0, q0, [x8, #0x20]
    a070: ad020100     	stp	q0, q0, [x8, #0x40]
    a074: ad030100     	stp	q0, q0, [x8, #0x60]
    a078: ad040100     	stp	q0, q0, [x8, #0x80]
    a07c: ad050100     	stp	q0, q0, [x8, #0xa0]
    a080: ad060100     	stp	q0, q0, [x8, #0xc0]
    a084: ad070100     	stp	q0, q0, [x8, #0xe0]
    a088: f900811f     	str	xzr, [x8, #0x100]
    a08c: 91044108     	add	x8, x8, #0x110
    a090: eb17029f     	cmp	x20, x23
    a094: 54fffe61     	b.ne	0xa060 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x9c>
    a098: f9000277     	str	x23, [x19]
    a09c: 52800000     	mov	w0, #0x0                ; =0
    a0a0: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    a0a4: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    a0a8: a94157f6     	ldp	x22, x21, [sp, #0x10]
    a0ac: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    a0b0: d65f03c0     	ret
    a0b4: 94000000     	bl	0xa0b4 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xf0>
		000000000000a0b4:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
