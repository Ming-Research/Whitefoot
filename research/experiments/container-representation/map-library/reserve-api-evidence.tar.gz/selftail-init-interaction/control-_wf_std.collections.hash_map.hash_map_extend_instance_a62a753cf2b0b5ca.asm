0000000000009630 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca>:
    9630: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    9634: a90157f6     	stp	x22, x21, [sp, #0x10]
    9638: a9024ff4     	stp	x20, x19, [sp, #0x20]
    963c: a9037bfd     	stp	x29, x30, [sp, #0x30]
    9640: aa0103f4     	mov	x20, x1
    9644: aa0003f3     	mov	x19, x0
    9648: a9405817     	ldp	x23, x22, [x0]
    964c: eb0102df     	cmp	x22, x1
    9650: 54000302     	b.hs	0x96b0 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x80>
    9654: f9400a75     	ldr	x21, [x19, #0x10]
    9658: 8b140688     	add	x8, x20, x20, lsl #1
    965c: d37df101     	lsl	x1, x8, #3
    9660: f10002df     	cmp	x22, #0x0
    9664: fa5612e0     	ccmp	x23, x22, #0x0, ne
    9668: 540001c0     	b.eq	0x96a0 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x70>
    966c: aa0103e0     	mov	x0, x1
    9670: 94000000     	bl	0x9670 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x40>
		0000000000009670:  ARM64_RELOC_BRANCH26	_malloc
    9674: b4000420     	cbz	x0, 0x96f8 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xc8>
    9678: b40001b6     	cbz	x22, 0x96ac <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x7c>
    967c: 8b1706e8     	add	x8, x23, x23, lsl #1
    9680: d37df102     	lsl	x2, x8, #3
    9684: aa0003f6     	mov	x22, x0
    9688: aa1503e1     	mov	x1, x21
    968c: 94000000     	bl	0x968c <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x5c>
		000000000000968c:  ARM64_RELOC_BRANCH26	_memcpy
    9690: aa1503e0     	mov	x0, x21
    9694: 94000000     	bl	0x9694 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x64>
		0000000000009694:  ARM64_RELOC_BRANCH26	_free
    9698: aa1603e0     	mov	x0, x22
    969c: 14000004     	b	0x96ac <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x7c>
    96a0: aa1503e0     	mov	x0, x21
    96a4: 94000000     	bl	0x96a4 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x74>
		00000000000096a4:  ARM64_RELOC_BRANCH26	_realloc
    96a8: b4000280     	cbz	x0, 0x96f8 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xc8>
    96ac: a9008274     	stp	x20, x0, [x19, #0x8]
    96b0: eb1402ff     	cmp	x23, x20
    96b4: 54000162     	b.hs	0x96e0 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xb0>
    96b8: f9400a68     	ldr	x8, [x19, #0x10]
    96bc: 52800309     	mov	w9, #0x18               ; =24
    96c0: 9b0922e8     	madd	x8, x23, x9, x8
    96c4: 91002108     	add	x8, x8, #0x8
    96c8: b81f811f     	stur	wzr, [x8, #-0x8]
    96cc: 910006f7     	add	x23, x23, #0x1
    96d0: a881fd1f     	stp	xzr, xzr, [x8], #0x18
    96d4: eb17029f     	cmp	x20, x23
    96d8: 54ffff81     	b.ne	0x96c8 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x98>
    96dc: f9000277     	str	x23, [x19]
    96e0: 52800000     	mov	w0, #0x0                ; =0
    96e4: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    96e8: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    96ec: a94157f6     	ldp	x22, x21, [sp, #0x10]
    96f0: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    96f4: d65f03c0     	ret
    96f8: 94000000     	bl	0x96f8 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xc8>
		00000000000096f8:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
