0000000000007634 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba>:
    7634: d10283ff     	sub	sp, sp, #0xa0
    7638: a9046ffc     	stp	x28, x27, [sp, #0x40]
    763c: a90567fa     	stp	x26, x25, [sp, #0x50]
    7640: a9065ff8     	stp	x24, x23, [sp, #0x60]
    7644: a90757f6     	stp	x22, x21, [sp, #0x70]
    7648: a9084ff4     	stp	x20, x19, [sp, #0x80]
    764c: a9097bfd     	stp	x29, x30, [sp, #0x90]
    7650: aa0303f4     	mov	x20, x3
    7654: aa0203f3     	mov	x19, x2
    7658: aa0003f5     	mov	x21, x0
    765c: d28f82a8     	mov	x8, #0x7c15             ; =31765
    7660: f2afe948     	movk	x8, #0x7f4a, lsl #16
    7664: f2cf3728     	movk	x8, #0x79b9, lsl #32
    7668: f2f3c6e8     	movk	x8, #0x9e37, lsl #48
    766c: 92840009     	mov	x9, #-0x2001            ; =-8193
    7670: 8b090029     	add	x9, x1, x9
    7674: b140093f     	cmn	x9, #0x2, lsl #12       ; =0x2000
    7678: 54000102     	b.hs	0x7698 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x64>
    767c: d2800001     	mov	x1, #0x0                ; =0
    7680: ca080296     	eor	x22, x20, x8
    7684: f9001bf6     	str	x22, [sp, #0x30]
    7688: 3900e3ff     	strb	wzr, [sp, #0x38]
    768c: 90000000     	adrp	x0, 0x7000 <_wf_map_cost_lookup_query$instance$4be10ff2429b6e66+0xc>
		000000000000768c:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    7690: 91000000     	add	x0, x0, #0x0
		0000000000007690:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    7694: 14000017     	b	0x76f0 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0xbc>
    7698: 531e7429     	lsl	w9, w1, #2
    769c: 51001129     	sub	w9, w9, #0x4
    76a0: 121e3529     	and	w9, w9, #0xfffc
    76a4: 5295556a     	mov	w10, #0xaaab            ; =43691
    76a8: 1b0a7d29     	mul	w9, w9, w10
    76ac: 53117d29     	lsr	w9, w9, #17
    76b0: 11000529     	add	w9, w9, #0x1
    76b4: ca080296     	eor	x22, x20, x8
    76b8: f9001bf6     	str	x22, [sp, #0x30]
    76bc: 3900e3ff     	strb	wzr, [sp, #0x38]
    76c0: aa0903f7     	mov	x23, x9
    76c4: 8b294528     	add	x8, x9, w9, uxtw #1
    76c8: d37df100     	lsl	x0, x8, #3
    76cc: 94000000     	bl	0x76cc <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x98>
		00000000000076cc:  ARM64_RELOC_BRANCH26	_malloc
    76d0: b4001040     	cbz	x0, 0x78d8 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x2a4>
    76d4: 91002008     	add	x8, x0, #0x8
    76d8: aa1703e1     	mov	x1, x23
    76dc: aa1703e9     	mov	x9, x23
    76e0: b81f811f     	stur	wzr, [x8, #-0x8]
    76e4: a881fd1f     	stp	xzr, xzr, [x8], #0x18
    76e8: f1000529     	subs	x9, x9, #0x1
    76ec: 54ffffa1     	b.ne	0x76e0 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0xac>
    76f0: a90087e1     	stp	x1, x1, [sp, #0x8]
    76f4: a9027fff     	stp	xzr, xzr, [sp, #0x20]
    76f8: f9000fe0     	str	x0, [sp, #0x18]
    76fc: b4000cf3     	cbz	x19, 0x7898 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x264>
    7700: d2800017     	mov	x23, #0x0               ; =0
    7704: 52800038     	mov	w24, #0x1               ; =1
    7708: 5280031a     	mov	w26, #0x18              ; =24
    770c: 5280005b     	mov	w27, #0x2               ; =2
    7710: d29cb73c     	mov	x28, #0xe5b9            ; =58809
    7714: f2a39c9c     	movk	x28, #0x1ce4, lsl #16
    7718: f2c8edbc     	movk	x28, #0x476d, lsl #32
    771c: f2f7eb1c     	movk	x28, #0xbf58, lsl #48
    7720: d2823d79     	mov	x25, #0x11eb            ; =4587
    7724: f2a26639     	movk	x25, #0x1331, lsl #16
    7728: f2c93779     	movk	x25, #0x49bb, lsl #32
    772c: f2f29a19     	movk	x25, #0x94d0, lsl #48
    7730: 14000006     	b	0x7748 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x114>
    7734: b900015b     	str	w27, [x10]
    7738: a900a548     	stp	x8, x9, [x10, #0x8]
    773c: 910006f7     	add	x23, x23, #0x1
    7740: eb1302ff     	cmp	x23, x19
    7744: 54000aa0     	b.eq	0x7898 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x264>
    7748: a94227e8     	ldp	x8, x9, [sp, #0x20]
    774c: ab090109     	adds	x9, x8, x9
    7750: da9f3129     	csinv	x9, x9, xzr, lo
    7754: d34efc2a     	lsr	x10, x1, #14
    7758: b500020a     	cbnz	x10, 0x7798 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x164>
    775c: cb41082a     	sub	x10, x1, x1, lsr #2
    7760: eb0a013f     	cmp	x9, x10
    7764: 540001a3     	b.lo	0x7798 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x164>
    7768: eb4a051f     	cmp	x8, x10, lsr #1
    776c: 54000103     	b.lo	0x778c <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x158>
    7770: b40000c1     	cbz	x1, 0x7788 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x154>
    7774: f140083f     	cmp	x1, #0x2, lsl #12       ; =0x2000
    7778: 52840008     	mov	w8, #0x2000             ; =8192
    777c: 9a883028     	csel	x8, x1, x8, lo
    7780: d37ff901     	lsl	x1, x8, #1
    7784: 14000002     	b	0x778c <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x158>
    7788: 52800021     	mov	w1, #0x1                ; =1
    778c: 910023e0     	add	x0, sp, #0x8
    7790: 9100c3e2     	add	x2, sp, #0x30
    7794: 94000000     	bl	0x7794 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x160>
		0000000000007794:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    7798: aa170708     	orr	x8, x24, x23, lsl #1
    779c: 3940e3e9     	ldrb	w9, [sp, #0x38]
    77a0: 360003c9     	tbz	w9, #0x0, 0x7818 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x1e4>
    77a4: d280000a     	mov	x10, #0x0               ; =0
    77a8: 8b1402e9     	add	x9, x23, x20
    77ac: f94007e1     	ldr	x1, [sp, #0x8]
    77b0: b4000461     	cbz	x1, 0x783c <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x208>
    77b4: 9ac1094b     	udiv	x11, x10, x1
    77b8: 9b01a96b     	msub	x11, x11, x1, x10
    77bc: f9400fec     	ldr	x12, [sp, #0x18]
    77c0: aa0103ed     	mov	x13, x1
    77c4: aa0103ea     	mov	x10, x1
    77c8: 14000008     	b	0x77e8 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x1b4>
    77cc: eb01015f     	cmp	x10, x1
    77d0: 9a8a016a     	csel	x10, x11, x10, eq
    77d4: 9100056e     	add	x14, x11, #0x1
    77d8: eb0101df     	cmp	x14, x1
    77dc: 9a8b27eb     	csinc	x11, xzr, x11, hs
    77e0: f10005ad     	subs	x13, x13, #0x1
    77e4: 540002e0     	b.eq	0x7840 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x20c>
    77e8: 9b1a316e     	madd	x14, x11, x26, x12
    77ec: b94001cf     	ldr	w15, [x14]
    77f0: 710005ff     	cmp	w15, #0x1
    77f4: 54fffec0     	b.eq	0x77cc <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x198>
    77f8: 710009ff     	cmp	w15, #0x2
    77fc: 54000441     	b.ne	0x7884 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x250>
    7800: f94005cf     	ldr	x15, [x14, #0x8]
    7804: eb0801ff     	cmp	x15, x8
    7808: 54fffe61     	b.ne	0x77d4 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x1a0>
    780c: b90001db     	str	w27, [x14]
    7810: f90009c9     	str	x9, [x14, #0x10]
    7814: 17ffffca     	b	0x773c <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x108>
    7818: ca160109     	eor	x9, x8, x22
    781c: ca497929     	eor	x9, x9, x9, lsr #30
    7820: 9b1c7d29     	mul	x9, x9, x28
    7824: ca496d29     	eor	x9, x9, x9, lsr #27
    7828: 9b197d29     	mul	x9, x9, x25
    782c: ca497d2a     	eor	x10, x9, x9, lsr #31
    7830: 8b1402e9     	add	x9, x23, x20
    7834: f94007e1     	ldr	x1, [sp, #0x8]
    7838: b5fffbe1     	cbnz	x1, 0x77b4 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x180>
    783c: d280000a     	mov	x10, #0x0               ; =0
    7840: eb01015f     	cmp	x10, x1
    7844: 54fff7c2     	b.hs	0x773c <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x108>
    7848: f94013eb     	ldr	x11, [sp, #0x20]
    784c: d34efd6c     	lsr	x12, x11, #14
    7850: b5fff76c     	cbnz	x12, 0x773c <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x108>
    7854: 9100056b     	add	x11, x11, #0x1
    7858: f90013eb     	str	x11, [sp, #0x20]
    785c: f9400feb     	ldr	x11, [sp, #0x18]
    7860: 9b1a2d4a     	madd	x10, x10, x26, x11
    7864: b940014b     	ldr	w11, [x10]
    7868: 7100057f     	cmp	w11, #0x1
    786c: 54fff641     	b.ne	0x7734 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x100>
    7870: f94017eb     	ldr	x11, [sp, #0x28]
    7874: f100056b     	subs	x11, x11, #0x1
    7878: 9a8b33eb     	csel	x11, xzr, x11, lo
    787c: f90017eb     	str	x11, [sp, #0x28]
    7880: 17ffffad     	b	0x7734 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x100>
    7884: eb01015f     	cmp	x10, x1
    7888: 9a8a016a     	csel	x10, x11, x10, eq
    788c: eb01015f     	cmp	x10, x1
    7890: 54fff562     	b.hs	0x773c <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x108>
    7894: 17ffffed     	b	0x7848 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x214>
    7898: 3cc083e0     	ldur	q0, [sp, #0x8]
    789c: 3cc183e1     	ldur	q1, [sp, #0x18]
    78a0: ad0006a0     	stp	q0, q1, [x21]
    78a4: f94017e8     	ldr	x8, [sp, #0x28]
    78a8: f90012a8     	str	x8, [x21, #0x20]
    78ac: 3dc00fe0     	ldr	q0, [sp, #0x30]
    78b0: 3c8282a0     	stur	q0, [x21, #0x28]
    78b4: a903ceb4     	stp	x20, x19, [x21, #0x38]
    78b8: a9497bfd     	ldp	x29, x30, [sp, #0x90]
    78bc: a9484ff4     	ldp	x20, x19, [sp, #0x80]
    78c0: a94757f6     	ldp	x22, x21, [sp, #0x70]
    78c4: a9465ff8     	ldp	x24, x23, [sp, #0x60]
    78c8: a94567fa     	ldp	x26, x25, [sp, #0x50]
    78cc: a9446ffc     	ldp	x28, x27, [sp, #0x40]
    78d0: 910283ff     	add	sp, sp, #0xa0
    78d4: d65f03c0     	ret
    78d8: 94000000     	bl	0x78d8 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x2a4>
		00000000000078d8:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
