0000000000009a0c <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca>:
    9a0c: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    9a10: a90157f6     	stp	x22, x21, [sp, #0x10]
    9a14: a9024ff4     	stp	x20, x19, [sp, #0x20]
    9a18: a9037bfd     	stp	x29, x30, [sp, #0x30]
    9a1c: aa0103f4     	mov	x20, x1
    9a20: aa0003f3     	mov	x19, x0
    9a24: a9405817     	ldp	x23, x22, [x0]
    9a28: eb0102df     	cmp	x22, x1
    9a2c: 54000302     	b.hs	0x9a8c <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x80>
    9a30: f9400a75     	ldr	x21, [x19, #0x10]
    9a34: 8b140688     	add	x8, x20, x20, lsl #1
    9a38: d37df101     	lsl	x1, x8, #3
    9a3c: f10002df     	cmp	x22, #0x0
    9a40: fa5612e0     	ccmp	x23, x22, #0x0, ne
    9a44: 540001c0     	b.eq	0x9a7c <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x70>
    9a48: aa0103e0     	mov	x0, x1
    9a4c: 94000000     	bl	0x9a4c <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x40>
		0000000000009a4c:  ARM64_RELOC_BRANCH26	_malloc
    9a50: b4000640     	cbz	x0, 0x9b18 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x10c>
    9a54: b40001b6     	cbz	x22, 0x9a88 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x7c>
    9a58: 8b1706e8     	add	x8, x23, x23, lsl #1
    9a5c: d37df102     	lsl	x2, x8, #3
    9a60: aa0003f6     	mov	x22, x0
    9a64: aa1503e1     	mov	x1, x21
    9a68: 94000000     	bl	0x9a68 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x5c>
		0000000000009a68:  ARM64_RELOC_BRANCH26	_memcpy
    9a6c: aa1503e0     	mov	x0, x21
    9a70: 94000000     	bl	0x9a70 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x64>
		0000000000009a70:  ARM64_RELOC_BRANCH26	_free
    9a74: aa1603e0     	mov	x0, x22
    9a78: 14000004     	b	0x9a88 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x7c>
    9a7c: aa1503e0     	mov	x0, x21
    9a80: 94000000     	bl	0x9a80 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x74>
		0000000000009a80:  ARM64_RELOC_BRANCH26	_realloc
    9a84: b40004a0     	cbz	x0, 0x9b18 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x10c>
    9a88: a9008274     	stp	x20, x0, [x19, #0x8]
    9a8c: eb17028a     	subs	x10, x20, x23
    9a90: 54000389     	b.ls	0x9b00 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xf4>
    9a94: f9400a69     	ldr	x9, [x19, #0x10]
    9a98: aa1703e8     	mov	x8, x23
    9a9c: f100115f     	cmp	x10, #0x4
    9aa0: 54000203     	b.lo	0x9ae0 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xd4>
    9aa4: 927ef54b     	and	x11, x10, #0xfffffffffffffffc
    9aa8: 8b0b02e8     	add	x8, x23, x11
    9aac: 5280030c     	mov	w12, #0x18              ; =24
    9ab0: 9b0c26ec     	madd	x12, x23, x12, x9
    9ab4: 9100c18c     	add	x12, x12, #0x30
    9ab8: aa0b03ed     	mov	x13, x11
    9abc: b81d019f     	stur	wzr, [x12, #-0x30]
    9ac0: b81e819f     	stur	wzr, [x12, #-0x18]
    9ac4: b900019f     	str	wzr, [x12]
    9ac8: b900199f     	str	wzr, [x12, #0x18]
    9acc: 9101818c     	add	x12, x12, #0x60
    9ad0: f10011ad     	subs	x13, x13, #0x4
    9ad4: 54ffff41     	b.ne	0x9abc <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xb0>
    9ad8: eb0b015f     	cmp	x10, x11
    9adc: 54000100     	b.eq	0x9afc <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xf0>
    9ae0: 5280030a     	mov	w10, #0x18              ; =24
    9ae4: 9b0a2509     	madd	x9, x8, x10, x9
    9ae8: cb08028a     	sub	x10, x20, x8
    9aec: b801853f     	str	wzr, [x9], #0x18
    9af0: 91000508     	add	x8, x8, #0x1
    9af4: f100054a     	subs	x10, x10, #0x1
    9af8: 54ffffa1     	b.ne	0x9aec <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xe0>
    9afc: f9000268     	str	x8, [x19]
    9b00: 52800000     	mov	w0, #0x0                ; =0
    9b04: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    9b08: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    9b0c: a94157f6     	ldp	x22, x21, [sp, #0x10]
    9b10: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    9b14: d65f03c0     	ret
    9b18: 94000000     	bl	0x9b18 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x10c>
		0000000000009b18:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
