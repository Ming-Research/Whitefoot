000000000000a844 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374>:
    a844: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    a848: a90157f6     	stp	x22, x21, [sp, #0x10]
    a84c: a9024ff4     	stp	x20, x19, [sp, #0x20]
    a850: a9037bfd     	stp	x29, x30, [sp, #0x30]
    a854: aa0103f4     	mov	x20, x1
    a858: aa0003f3     	mov	x19, x0
    a85c: a9405817     	ldp	x23, x22, [x0]
    a860: eb0102df     	cmp	x22, x1
    a864: 54000302     	b.hs	0xa8c4 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x80>
    a868: f9400a75     	ldr	x21, [x19, #0x10]
    a86c: 8b141288     	add	x8, x20, x20, lsl #4
    a870: d37ced01     	lsl	x1, x8, #4
    a874: f10002df     	cmp	x22, #0x0
    a878: fa5612e0     	ccmp	x23, x22, #0x0, ne
    a87c: 540001c0     	b.eq	0xa8b4 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x70>
    a880: aa0103e0     	mov	x0, x1
    a884: 94000000     	bl	0xa884 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x40>
		000000000000a884:  ARM64_RELOC_BRANCH26	_malloc
    a888: b4000640     	cbz	x0, 0xa950 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x10c>
    a88c: b40001b6     	cbz	x22, 0xa8c0 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x7c>
    a890: 8b1712e8     	add	x8, x23, x23, lsl #4
    a894: d37ced02     	lsl	x2, x8, #4
    a898: aa0003f6     	mov	x22, x0
    a89c: aa1503e1     	mov	x1, x21
    a8a0: 94000000     	bl	0xa8a0 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x5c>
		000000000000a8a0:  ARM64_RELOC_BRANCH26	_memcpy
    a8a4: aa1503e0     	mov	x0, x21
    a8a8: 94000000     	bl	0xa8a8 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x64>
		000000000000a8a8:  ARM64_RELOC_BRANCH26	_free
    a8ac: aa1603e0     	mov	x0, x22
    a8b0: 14000004     	b	0xa8c0 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x7c>
    a8b4: aa1503e0     	mov	x0, x21
    a8b8: 94000000     	bl	0xa8b8 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x74>
		000000000000a8b8:  ARM64_RELOC_BRANCH26	_realloc
    a8bc: b40004a0     	cbz	x0, 0xa950 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x10c>
    a8c0: a9008274     	stp	x20, x0, [x19, #0x8]
    a8c4: eb17028a     	subs	x10, x20, x23
    a8c8: 54000389     	b.ls	0xa938 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xf4>
    a8cc: f9400a69     	ldr	x9, [x19, #0x10]
    a8d0: aa1703e8     	mov	x8, x23
    a8d4: f100115f     	cmp	x10, #0x4
    a8d8: 540001e3     	b.lo	0xa914 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xd0>
    a8dc: 927ef54b     	and	x11, x10, #0xfffffffffffffffc
    a8e0: 8b0b02e8     	add	x8, x23, x11
    a8e4: 5280220c     	mov	w12, #0x110             ; =272
    a8e8: 9b0c26ec     	madd	x12, x23, x12, x9
    a8ec: aa0b03ed     	mov	x13, x11
    a8f0: b900019f     	str	wzr, [x12]
    a8f4: b901119f     	str	wzr, [x12, #0x110]
    a8f8: b902219f     	str	wzr, [x12, #0x220]
    a8fc: b903319f     	str	wzr, [x12, #0x330]
    a900: 9111018c     	add	x12, x12, #0x440
    a904: f10011ad     	subs	x13, x13, #0x4
    a908: 54ffff41     	b.ne	0xa8f0 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xac>
    a90c: eb0b015f     	cmp	x10, x11
    a910: 54000120     	b.eq	0xa934 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xf0>
    a914: 5280220a     	mov	w10, #0x110             ; =272
    a918: 9b0a2509     	madd	x9, x8, x10, x9
    a91c: cb08028a     	sub	x10, x20, x8
    a920: b900013f     	str	wzr, [x9]
    a924: 91000508     	add	x8, x8, #0x1
    a928: 91044129     	add	x9, x9, #0x110
    a92c: f100054a     	subs	x10, x10, #0x1
    a930: 54ffff81     	b.ne	0xa920 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xdc>
    a934: f9000268     	str	x8, [x19]
    a938: 52800000     	mov	w0, #0x0                ; =0
    a93c: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    a940: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    a944: a94157f6     	ldp	x22, x21, [sp, #0x10]
    a948: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    a94c: d65f03c0     	ret
    a950: 94000000     	bl	0xa950 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x10c>
		000000000000a950:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
