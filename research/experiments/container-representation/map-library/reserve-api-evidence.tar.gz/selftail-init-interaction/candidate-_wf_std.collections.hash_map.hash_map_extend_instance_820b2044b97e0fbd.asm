0000000000009e74 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd>:
    9e74: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    9e78: a90157f6     	stp	x22, x21, [sp, #0x10]
    9e7c: a9024ff4     	stp	x20, x19, [sp, #0x20]
    9e80: a9037bfd     	stp	x29, x30, [sp, #0x30]
    9e84: aa0103f4     	mov	x20, x1
    9e88: aa0003f3     	mov	x19, x0
    9e8c: a9405817     	ldp	x23, x22, [x0]
    9e90: eb0102df     	cmp	x22, x1
    9e94: 54000302     	b.hs	0x9ef4 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x80>
    9e98: f9400a75     	ldr	x21, [x19, #0x10]
    9e9c: 8b140688     	add	x8, x20, x20, lsl #1
    9ea0: d37df101     	lsl	x1, x8, #3
    9ea4: f10002df     	cmp	x22, #0x0
    9ea8: fa5612e0     	ccmp	x23, x22, #0x0, ne
    9eac: 540001c0     	b.eq	0x9ee4 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x70>
    9eb0: aa0103e0     	mov	x0, x1
    9eb4: 94000000     	bl	0x9eb4 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x40>
		0000000000009eb4:  ARM64_RELOC_BRANCH26	_malloc
    9eb8: b4000640     	cbz	x0, 0x9f80 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x10c>
    9ebc: b40001b6     	cbz	x22, 0x9ef0 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x7c>
    9ec0: 8b1706e8     	add	x8, x23, x23, lsl #1
    9ec4: d37df102     	lsl	x2, x8, #3
    9ec8: aa0003f6     	mov	x22, x0
    9ecc: aa1503e1     	mov	x1, x21
    9ed0: 94000000     	bl	0x9ed0 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x5c>
		0000000000009ed0:  ARM64_RELOC_BRANCH26	_memcpy
    9ed4: aa1503e0     	mov	x0, x21
    9ed8: 94000000     	bl	0x9ed8 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x64>
		0000000000009ed8:  ARM64_RELOC_BRANCH26	_free
    9edc: aa1603e0     	mov	x0, x22
    9ee0: 14000004     	b	0x9ef0 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x7c>
    9ee4: aa1503e0     	mov	x0, x21
    9ee8: 94000000     	bl	0x9ee8 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x74>
		0000000000009ee8:  ARM64_RELOC_BRANCH26	_realloc
    9eec: b40004a0     	cbz	x0, 0x9f80 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x10c>
    9ef0: a9008274     	stp	x20, x0, [x19, #0x8]
    9ef4: eb17028a     	subs	x10, x20, x23
    9ef8: 54000389     	b.ls	0x9f68 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xf4>
    9efc: f9400a69     	ldr	x9, [x19, #0x10]
    9f00: aa1703e8     	mov	x8, x23
    9f04: f100115f     	cmp	x10, #0x4
    9f08: 54000203     	b.lo	0x9f48 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xd4>
    9f0c: 927ef54b     	and	x11, x10, #0xfffffffffffffffc
    9f10: 8b0b02e8     	add	x8, x23, x11
    9f14: 5280030c     	mov	w12, #0x18              ; =24
    9f18: 9b0c26ec     	madd	x12, x23, x12, x9
    9f1c: 9100c18c     	add	x12, x12, #0x30
    9f20: aa0b03ed     	mov	x13, x11
    9f24: b81d019f     	stur	wzr, [x12, #-0x30]
    9f28: b81e819f     	stur	wzr, [x12, #-0x18]
    9f2c: b900019f     	str	wzr, [x12]
    9f30: b900199f     	str	wzr, [x12, #0x18]
    9f34: 9101818c     	add	x12, x12, #0x60
    9f38: f10011ad     	subs	x13, x13, #0x4
    9f3c: 54ffff41     	b.ne	0x9f24 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xb0>
    9f40: eb0b015f     	cmp	x10, x11
    9f44: 54000100     	b.eq	0x9f64 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xf0>
    9f48: 5280030a     	mov	w10, #0x18              ; =24
    9f4c: 9b0a2509     	madd	x9, x8, x10, x9
    9f50: cb08028a     	sub	x10, x20, x8
    9f54: b801853f     	str	wzr, [x9], #0x18
    9f58: 91000508     	add	x8, x8, #0x1
    9f5c: f100054a     	subs	x10, x10, #0x1
    9f60: 54ffffa1     	b.ne	0x9f54 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xe0>
    9f64: f9000268     	str	x8, [x19]
    9f68: 52800000     	mov	w0, #0x0                ; =0
    9f6c: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    9f70: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    9f74: a94157f6     	ldp	x22, x21, [sp, #0x10]
    9f78: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    9f7c: d65f03c0     	ret
    9f80: 94000000     	bl	0x9f80 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x10c>
		0000000000009f80:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
