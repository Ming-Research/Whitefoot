0000000000007a30 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66>:
    7a30: a9ba6ffc     	stp	x28, x27, [sp, #-0x60]!
    7a34: a90167fa     	stp	x26, x25, [sp, #0x10]
    7a38: a9025ff8     	stp	x24, x23, [sp, #0x20]
    7a3c: a90357f6     	stp	x22, x21, [sp, #0x30]
    7a40: a9044ff4     	stp	x20, x19, [sp, #0x40]
    7a44: a9057bfd     	stp	x29, x30, [sp, #0x50]
    7a48: d10f43ff     	sub	sp, sp, #0x3d0
    7a4c: aa0303f4     	mov	x20, x3
    7a50: aa0203f3     	mov	x19, x2
    7a54: aa0003f5     	mov	x21, x0
    7a58: 92840008     	mov	x8, #-0x2001            ; =-8193
    7a5c: 8b080028     	add	x8, x1, x8
    7a60: b140091f     	cmn	x8, #0x2, lsl #12       ; =0x2000
    7a64: 54000182     	b.hs	0x7a94 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x64>
    7a68: d2800016     	mov	x22, #0x0               ; =0
    7a6c: d28f82a8     	mov	x8, #0x7c15             ; =31765
    7a70: f2afe948     	movk	x8, #0x7f4a, lsl #16
    7a74: f2cf3728     	movk	x8, #0x79b9, lsl #32
    7a78: f2f3c6e8     	movk	x8, #0x9e37, lsl #48
    7a7c: ca080288     	eor	x8, x20, x8
    7a80: f9009be8     	str	x8, [sp, #0x130]
    7a84: 3904e3ff     	strb	wzr, [sp, #0x138]
    7a88: 90000000     	adrp	x0, 0x7000 <_wf_map_cost_lookup_query$instance$4be10ff2429b6e66+0xc>
		0000000000007a88:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    7a8c: 91000000     	add	x0, x0, #0x0
		0000000000007a8c:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    7a90: 14000023     	b	0x7b1c <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0xec>
    7a94: 531e7428     	lsl	w8, w1, #2
    7a98: 51001108     	sub	w8, w8, #0x4
    7a9c: 121e3508     	and	w8, w8, #0xfffc
    7aa0: 52955569     	mov	w9, #0xaaab             ; =43691
    7aa4: 1b097d08     	mul	w8, w8, w9
    7aa8: 53117d08     	lsr	w8, w8, #17
    7aac: 11000516     	add	w22, w8, #0x1
    7ab0: d28f82a8     	mov	x8, #0x7c15             ; =31765
    7ab4: f2afe948     	movk	x8, #0x7f4a, lsl #16
    7ab8: f2cf3728     	movk	x8, #0x79b9, lsl #32
    7abc: f2f3c6e8     	movk	x8, #0x9e37, lsl #48
    7ac0: ca080288     	eor	x8, x20, x8
    7ac4: f9009be8     	str	x8, [sp, #0x130]
    7ac8: 3904e3ff     	strb	wzr, [sp, #0x138]
    7acc: 8b3652c8     	add	x8, x22, w22, uxtw #4
    7ad0: d37ced00     	lsl	x0, x8, #4
    7ad4: 94000000     	bl	0x7ad4 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0xa4>
		0000000000007ad4:  ARM64_RELOC_BRANCH26	_malloc
    7ad8: b4001800     	cbz	x0, 0x7dd8 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x3a8>
    7adc: 91002008     	add	x8, x0, #0x8
    7ae0: 6f00e400     	movi.2d	v0, #0000000000000000
    7ae4: aa1603e9     	mov	x9, x22
    7ae8: b81f811f     	stur	wzr, [x8, #-0x8]
    7aec: ad000100     	stp	q0, q0, [x8]
    7af0: ad010100     	stp	q0, q0, [x8, #0x20]
    7af4: ad020100     	stp	q0, q0, [x8, #0x40]
    7af8: ad030100     	stp	q0, q0, [x8, #0x60]
    7afc: ad040100     	stp	q0, q0, [x8, #0x80]
    7b00: ad050100     	stp	q0, q0, [x8, #0xa0]
    7b04: ad060100     	stp	q0, q0, [x8, #0xc0]
    7b08: ad070100     	stp	q0, q0, [x8, #0xe0]
    7b0c: f900811f     	str	xzr, [x8, #0x100]
    7b10: 91044108     	add	x8, x8, #0x110
    7b14: f1000529     	subs	x9, x9, #0x1
    7b18: 54fffe81     	b.ne	0x7ae8 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0xb8>
    7b1c: a910dbf6     	stp	x22, x22, [sp, #0x108]
    7b20: a9127fff     	stp	xzr, xzr, [sp, #0x120]
    7b24: f9008fe0     	str	x0, [sp, #0x118]
    7b28: b4001353     	cbz	x19, 0x7d90 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x360>
    7b2c: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$4be10ff2429b6e66+0xc>
		0000000000007b2c:  ARM64_RELOC_PAGE21	lCPI65_0
    7b30: 3dc00100     	ldr	q0, [x8]
		0000000000007b30:  ARM64_RELOC_PAGEOFF12	lCPI65_0
    7b34: 3d803fe0     	str	q0, [sp, #0xf0]
    7b38: 910943f7     	add	x23, sp, #0x250
    7b3c: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$4be10ff2429b6e66+0xc>
		0000000000007b3c:  ARM64_RELOC_PAGE21	lCPI65_1
    7b40: 3dc00100     	ldr	q0, [x8]
		0000000000007b40:  ARM64_RELOC_PAGEOFF12	lCPI65_1
    7b44: 3d803be0     	str	q0, [sp, #0xe0]
    7b48: 910943f8     	add	x24, sp, #0x250
    7b4c: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$4be10ff2429b6e66+0xc>
		0000000000007b4c:  ARM64_RELOC_PAGE21	lCPI65_2
    7b50: 3dc00100     	ldr	q0, [x8]
		0000000000007b50:  ARM64_RELOC_PAGEOFF12	lCPI65_2
    7b54: 3d8037e0     	str	q0, [sp, #0xd0]
    7b58: 9104a319     	add	x25, x24, #0x128
    7b5c: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$4be10ff2429b6e66+0xc>
		0000000000007b5c:  ARM64_RELOC_PAGE21	lCPI65_3
    7b60: 3dc00100     	ldr	q0, [x8]
		0000000000007b60:  ARM64_RELOC_PAGEOFF12	lCPI65_3
    7b64: 3d8033e0     	str	q0, [sp, #0xc0]
    7b68: 52800036     	mov	w22, #0x1               ; =1
    7b6c: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$4be10ff2429b6e66+0xc>
		0000000000007b6c:  ARM64_RELOC_PAGE21	lCPI65_4
    7b70: 3dc00100     	ldr	q0, [x8]
		0000000000007b70:  ARM64_RELOC_PAGEOFF12	lCPI65_4
    7b74: 3d802fe0     	str	q0, [sp, #0xb0]
    7b78: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$4be10ff2429b6e66+0xc>
		0000000000007b78:  ARM64_RELOC_PAGE21	lCPI65_5
    7b7c: 3dc00100     	ldr	q0, [x8]
		0000000000007b7c:  ARM64_RELOC_PAGEOFF12	lCPI65_5
    7b80: 3d802be0     	str	q0, [sp, #0xa0]
    7b84: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$4be10ff2429b6e66+0xc>
		0000000000007b84:  ARM64_RELOC_PAGE21	lCPI65_6
    7b88: 3dc00100     	ldr	q0, [x8]
		0000000000007b88:  ARM64_RELOC_PAGEOFF12	lCPI65_6
    7b8c: 3d8027e0     	str	q0, [sp, #0x90]
    7b90: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$4be10ff2429b6e66+0xc>
		0000000000007b90:  ARM64_RELOC_PAGE21	lCPI65_7
    7b94: 3dc00100     	ldr	q0, [x8]
		0000000000007b94:  ARM64_RELOC_PAGEOFF12	lCPI65_7
    7b98: 3d8023e0     	str	q0, [sp, #0x80]
    7b9c: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$4be10ff2429b6e66+0xc>
		0000000000007b9c:  ARM64_RELOC_PAGE21	lCPI65_8
    7ba0: 3dc00100     	ldr	q0, [x8]
		0000000000007ba0:  ARM64_RELOC_PAGEOFF12	lCPI65_8
    7ba4: 3d801fe0     	str	q0, [sp, #0x70]
    7ba8: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$4be10ff2429b6e66+0xc>
		0000000000007ba8:  ARM64_RELOC_PAGE21	lCPI65_9
    7bac: 3dc00100     	ldr	q0, [x8]
		0000000000007bac:  ARM64_RELOC_PAGEOFF12	lCPI65_9
    7bb0: 3d801be0     	str	q0, [sp, #0x60]
    7bb4: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$4be10ff2429b6e66+0xc>
		0000000000007bb4:  ARM64_RELOC_PAGE21	lCPI65_10
    7bb8: 3dc00100     	ldr	q0, [x8]
		0000000000007bb8:  ARM64_RELOC_PAGEOFF12	lCPI65_10
    7bbc: 3d8017e0     	str	q0, [sp, #0x50]
    7bc0: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$4be10ff2429b6e66+0xc>
		0000000000007bc0:  ARM64_RELOC_PAGE21	lCPI65_11
    7bc4: 3dc00100     	ldr	q0, [x8]
		0000000000007bc4:  ARM64_RELOC_PAGEOFF12	lCPI65_11
    7bc8: 3d8013e0     	str	q0, [sp, #0x40]
    7bcc: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$4be10ff2429b6e66+0xc>
		0000000000007bcc:  ARM64_RELOC_PAGE21	lCPI65_12
    7bd0: 3dc00100     	ldr	q0, [x8]
		0000000000007bd0:  ARM64_RELOC_PAGEOFF12	lCPI65_12
    7bd4: 3d800fe0     	str	q0, [sp, #0x30]
    7bd8: 5284001a     	mov	w26, #0x2000            ; =8192
    7bdc: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$4be10ff2429b6e66+0xc>
		0000000000007bdc:  ARM64_RELOC_PAGE21	lCPI65_13
    7be0: 3dc00100     	ldr	q0, [x8]
		0000000000007be0:  ARM64_RELOC_PAGEOFF12	lCPI65_13
    7be4: 3d800be0     	str	q0, [sp, #0x20]
    7be8: aa1303fb     	mov	x27, x19
    7bec: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$4be10ff2429b6e66+0xc>
		0000000000007bec:  ARM64_RELOC_PAGE21	lCPI65_14
    7bf0: 3dc00100     	ldr	q0, [x8]
		0000000000007bf0:  ARM64_RELOC_PAGEOFF12	lCPI65_14
    7bf4: 3d8007e0     	str	q0, [sp, #0x10]
    7bf8: aa1403fc     	mov	x28, x20
    7bfc: 14000014     	b	0x7c4c <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x21c>
    7c00: f140083f     	cmp	x1, #0x2, lsl #12       ; =0x2000
    7c04: 9a9a3028     	csel	x8, x1, x26, lo
    7c08: d37ff901     	lsl	x1, x8, #1
    7c0c: 910423e0     	add	x0, sp, #0x108
    7c10: 9104c3e2     	add	x2, sp, #0x130
    7c14: 94000000     	bl	0x7c14 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x1e4>
		0000000000007c14:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    7c18: b903cbe0     	str	w0, [sp, #0x3c8]
    7c1c: 390f33e1     	strb	w1, [sp, #0x3cc]
    7c20: 390f37e2     	strb	w2, [sp, #0x3cd]
    7c24: 910503e0     	add	x0, sp, #0x140
    7c28: 910423e1     	add	x1, sp, #0x108
    7c2c: 910943e3     	add	x3, sp, #0x250
    7c30: 9104c3e4     	add	x4, sp, #0x130
    7c34: aa1603e2     	mov	x2, x22
    7c38: 94000000     	bl	0x7c38 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x208>
		0000000000007c38:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
    7c3c: 9100079c     	add	x28, x28, #0x1
    7c40: 91000ad6     	add	x22, x22, #0x2
    7c44: f100077b     	subs	x27, x27, #0x1
    7c48: 54000a40     	b.eq	0x7d90 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x360>
    7c4c: 4e080f80     	dup.2d	v0, x28
    7c50: 91007f88     	add	x8, x28, #0x1f
    7c54: 3dc03fe1     	ldr	q1, [sp, #0xf0]
    7c58: 4ee18401     	add.2d	v1, v0, v1
    7c5c: 3c8082e1     	stur	q1, [x23, #0x8]
    7c60: 3dc03be1     	ldr	q1, [sp, #0xe0]
    7c64: 4ee18401     	add.2d	v1, v0, v1
    7c68: 3c8182e1     	stur	q1, [x23, #0x18]
    7c6c: 3dc037e1     	ldr	q1, [sp, #0xd0]
    7c70: 4ee18401     	add.2d	v1, v0, v1
    7c74: 3c8282e1     	stur	q1, [x23, #0x28]
    7c78: 3dc033e1     	ldr	q1, [sp, #0xc0]
    7c7c: 4ee18401     	add.2d	v1, v0, v1
    7c80: 3c8382e1     	stur	q1, [x23, #0x38]
    7c84: 3dc02fe1     	ldr	q1, [sp, #0xb0]
    7c88: 4ee18401     	add.2d	v1, v0, v1
    7c8c: 3c8482e1     	stur	q1, [x23, #0x48]
    7c90: 3dc02be1     	ldr	q1, [sp, #0xa0]
    7c94: 4ee18401     	add.2d	v1, v0, v1
    7c98: 3c8582e1     	stur	q1, [x23, #0x58]
    7c9c: 3dc027e1     	ldr	q1, [sp, #0x90]
    7ca0: 4ee18401     	add.2d	v1, v0, v1
    7ca4: 3c8682e1     	stur	q1, [x23, #0x68]
    7ca8: 3dc023e1     	ldr	q1, [sp, #0x80]
    7cac: 4ee18401     	add.2d	v1, v0, v1
    7cb0: 3c8782e1     	stur	q1, [x23, #0x78]
    7cb4: 3dc01fe1     	ldr	q1, [sp, #0x70]
    7cb8: 4ee18401     	add.2d	v1, v0, v1
    7cbc: 3c8882e1     	stur	q1, [x23, #0x88]
    7cc0: 3dc01be1     	ldr	q1, [sp, #0x60]
    7cc4: 4ee18401     	add.2d	v1, v0, v1
    7cc8: 3c8982e1     	stur	q1, [x23, #0x98]
    7ccc: 3dc017e1     	ldr	q1, [sp, #0x50]
    7cd0: 4ee18401     	add.2d	v1, v0, v1
    7cd4: 3c8a82e1     	stur	q1, [x23, #0xa8]
    7cd8: 3dc013e1     	ldr	q1, [sp, #0x40]
    7cdc: 4ee18401     	add.2d	v1, v0, v1
    7ce0: 3c8b82e1     	stur	q1, [x23, #0xb8]
    7ce4: 3dc00fe1     	ldr	q1, [sp, #0x30]
    7ce8: 4ee18401     	add.2d	v1, v0, v1
    7cec: 3c8c82e1     	stur	q1, [x23, #0xc8]
    7cf0: 3dc00be1     	ldr	q1, [sp, #0x20]
    7cf4: 4ee18401     	add.2d	v1, v0, v1
    7cf8: 3c8d82e1     	stur	q1, [x23, #0xd8]
    7cfc: 3dc007e1     	ldr	q1, [sp, #0x10]
    7d00: 4ee18400     	add.2d	v0, v0, v1
    7d04: 3c8e82e0     	stur	q0, [x23, #0xe8]
    7d08: f9012bfc     	str	x28, [sp, #0x250]
    7d0c: f901a7e8     	str	x8, [sp, #0x348]
    7d10: f94087e1     	ldr	x1, [sp, #0x108]
    7d14: f94097e8     	ldr	x8, [sp, #0x128]
    7d18: f9009308     	str	x8, [x24, #0x120]
    7d1c: 910067e9     	add	x9, sp, #0x19
    7d20: 3ccff120     	ldur	q0, [x9, #0xff]
    7d24: 910027e9     	add	x9, sp, #0x9
    7d28: 3ccff121     	ldur	q1, [x9, #0xff]
    7d2c: ad080301     	stp	q1, q0, [x24, #0x100]
    7d30: f9001328     	str	x8, [x25, #0x20]
    7d34: f941b7e8     	ldr	x8, [sp, #0x368]
    7d38: f941cfe9     	ldr	x9, [sp, #0x398]
    7d3c: ab090108     	adds	x8, x8, x9
    7d40: da9f3109     	csinv	x9, x8, xzr, lo
    7d44: d34efc28     	lsr	x8, x1, #14
    7d48: ad000321     	stp	q1, q0, [x25]
    7d4c: b5fff6c8     	cbnz	x8, 0x7c24 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x1f4>
    7d50: cb410828     	sub	x8, x1, x1, lsr #2
    7d54: eb08013f     	cmp	x9, x8
    7d58: 54fff663     	b.lo	0x7c24 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x1f4>
    7d5c: f94097e9     	ldr	x9, [sp, #0x128]
    7d60: f900bb09     	str	x9, [x24, #0x170]
    7d64: 910067e9     	add	x9, sp, #0x19
    7d68: 3ccff120     	ldur	q0, [x9, #0xff]
    7d6c: 910027e9     	add	x9, sp, #0x9
    7d70: 3ccff121     	ldur	q1, [x9, #0xff]
    7d74: ad0a8301     	stp	q1, q0, [x24, #0x150]
    7d78: f941dfe9     	ldr	x9, [sp, #0x3b8]
    7d7c: eb48053f     	cmp	x9, x8, lsr #1
    7d80: 54fff463     	b.lo	0x7c0c <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x1dc>
    7d84: b5fff3e1     	cbnz	x1, 0x7c00 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x1d0>
    7d88: 52800021     	mov	w1, #0x1                ; =1
    7d8c: 17ffffa0     	b	0x7c0c <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x1dc>
    7d90: 910027e8     	add	x8, sp, #0x9
    7d94: 3ccff100     	ldur	q0, [x8, #0xff]
    7d98: 910067e8     	add	x8, sp, #0x19
    7d9c: 3ccff101     	ldur	q1, [x8, #0xff]
    7da0: ad0006a0     	stp	q0, q1, [x21]
    7da4: f94097e8     	ldr	x8, [sp, #0x128]
    7da8: f90012a8     	str	x8, [x21, #0x20]
    7dac: 3dc04fe0     	ldr	q0, [sp, #0x130]
    7db0: 3c8282a0     	stur	q0, [x21, #0x28]
    7db4: a903ceb4     	stp	x20, x19, [x21, #0x38]
    7db8: 910f43ff     	add	sp, sp, #0x3d0
    7dbc: a9457bfd     	ldp	x29, x30, [sp, #0x50]
    7dc0: a9444ff4     	ldp	x20, x19, [sp, #0x40]
    7dc4: a94357f6     	ldp	x22, x21, [sp, #0x30]
    7dc8: a9425ff8     	ldp	x24, x23, [sp, #0x20]
    7dcc: a94167fa     	ldp	x26, x25, [sp, #0x10]
    7dd0: a8c66ffc     	ldp	x28, x27, [sp], #0x60
    7dd4: d65f03c0     	ret
    7dd8: 94000000     	bl	0x7dd8 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x3a8>
		0000000000007dd8:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
