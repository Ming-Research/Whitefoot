0000000000009a58 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd>:
    9a58: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    9a5c: a90157f6     	stp	x22, x21, [sp, #0x10]
    9a60: a9024ff4     	stp	x20, x19, [sp, #0x20]
    9a64: a9037bfd     	stp	x29, x30, [sp, #0x30]
    9a68: aa0103f4     	mov	x20, x1
    9a6c: aa0003f3     	mov	x19, x0
    9a70: a9405817     	ldp	x23, x22, [x0]
    9a74: eb0102df     	cmp	x22, x1
    9a78: 54000302     	b.hs	0x9ad8 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x80>
    9a7c: f9400a75     	ldr	x21, [x19, #0x10]
    9a80: 8b140688     	add	x8, x20, x20, lsl #1
    9a84: d37df101     	lsl	x1, x8, #3
    9a88: f10002df     	cmp	x22, #0x0
    9a8c: fa5612e0     	ccmp	x23, x22, #0x0, ne
    9a90: 540001c0     	b.eq	0x9ac8 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x70>
    9a94: aa0103e0     	mov	x0, x1
    9a98: 94000000     	bl	0x9a98 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x40>
		0000000000009a98:  ARM64_RELOC_BRANCH26	_malloc
    9a9c: b4000420     	cbz	x0, 0x9b20 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xc8>
    9aa0: b40001b6     	cbz	x22, 0x9ad4 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x7c>
    9aa4: 8b1706e8     	add	x8, x23, x23, lsl #1
    9aa8: d37df102     	lsl	x2, x8, #3
    9aac: aa0003f6     	mov	x22, x0
    9ab0: aa1503e1     	mov	x1, x21
    9ab4: 94000000     	bl	0x9ab4 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x5c>
		0000000000009ab4:  ARM64_RELOC_BRANCH26	_memcpy
    9ab8: aa1503e0     	mov	x0, x21
    9abc: 94000000     	bl	0x9abc <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x64>
		0000000000009abc:  ARM64_RELOC_BRANCH26	_free
    9ac0: aa1603e0     	mov	x0, x22
    9ac4: 14000004     	b	0x9ad4 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x7c>
    9ac8: aa1503e0     	mov	x0, x21
    9acc: 94000000     	bl	0x9acc <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x74>
		0000000000009acc:  ARM64_RELOC_BRANCH26	_realloc
    9ad0: b4000280     	cbz	x0, 0x9b20 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xc8>
    9ad4: a9008274     	stp	x20, x0, [x19, #0x8]
    9ad8: eb1402ff     	cmp	x23, x20
    9adc: 54000162     	b.hs	0x9b08 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xb0>
    9ae0: f9400a68     	ldr	x8, [x19, #0x10]
    9ae4: 52800309     	mov	w9, #0x18               ; =24
    9ae8: 9b0922e8     	madd	x8, x23, x9, x8
    9aec: 91002108     	add	x8, x8, #0x8
    9af0: b81f811f     	stur	wzr, [x8, #-0x8]
    9af4: 910006f7     	add	x23, x23, #0x1
    9af8: a881fd1f     	stp	xzr, xzr, [x8], #0x18
    9afc: eb17029f     	cmp	x20, x23
    9b00: 54ffff81     	b.ne	0x9af0 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x98>
    9b04: f9000277     	str	x23, [x19]
    9b08: 52800000     	mov	w0, #0x0                ; =0
    9b0c: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    9b10: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    9b14: a94157f6     	ldp	x22, x21, [sp, #0x10]
    9b18: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    9b1c: d65f03c0     	ret
    9b20: 94000000     	bl	0x9b20 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xc8>
		0000000000009b20:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
