000000000000ad48 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6>:
    ad48: 3940206a     	ldrb	w10, [x3, #0x8]
    ad4c: f9400008     	ldr	x8, [x0]
    ad50: b40001a8     	cbz	x8, 0xad84 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x3c>
    ad54: f9400809     	ldr	x9, [x0, #0x10]
    ad58: 360001ca     	tbz	w10, #0x0, 0xad90 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x48>
    ad5c: d280000b     	mov	x11, #0x0               ; =0
    ad60: aa0903ea     	mov	x10, x9
    ad64: b940014c     	ldr	w12, [x10]
    ad68: 7100099f     	cmp	w12, #0x2
    ad6c: 54000523     	b.lo	0xae10 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0xc8>
    ad70: 9100056b     	add	x11, x11, #0x1
    ad74: 9100614a     	add	x10, x10, #0x18
    ad78: eb0b011f     	cmp	x8, x11
    ad7c: 54ffff41     	b.ne	0xad64 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x1c>
    ad80: 17fffff7     	b	0xad5c <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x14>
    ad84: 3600004a     	tbz	w10, #0x0, 0xad8c <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x44>
    ad88: 14000000     	b	0xad88 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x40>
    ad8c: 14000000     	b	0xad8c <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x44>
    ad90: f940006a     	ldr	x10, [x3]
    ad94: ca01014a     	eor	x10, x10, x1
    ad98: ca4a794a     	eor	x10, x10, x10, lsr #30
    ad9c: d29cb72b     	mov	x11, #0xe5b9            ; =58809
    ada0: f2a39c8b     	movk	x11, #0x1ce4, lsl #16
    ada4: f2c8edab     	movk	x11, #0x476d, lsl #32
    ada8: f2f7eb0b     	movk	x11, #0xbf58, lsl #48
    adac: 9b0b7d4a     	mul	x10, x10, x11
    adb0: ca4a6d4a     	eor	x10, x10, x10, lsr #27
    adb4: d2823d6b     	mov	x11, #0x11eb            ; =4587
    adb8: f2a2662b     	movk	x11, #0x1331, lsl #16
    adbc: f2c9376b     	movk	x11, #0x49bb, lsl #32
    adc0: f2f29a0b     	movk	x11, #0x94d0, lsl #48
    adc4: 9b0b7d4a     	mul	x10, x10, x11
    adc8: ca4a7d4a     	eor	x10, x10, x10, lsr #31
    adcc: 9ac8094b     	udiv	x11, x10, x8
    add0: 9b08a96b     	msub	x11, x11, x8, x10
    add4: cb0b010c     	sub	x12, x8, x11
    add8: cb0c03ed     	neg	x13, x12
    addc: 5280030e     	mov	w14, #0x18              ; =24
    ade0: d280000f     	mov	x15, #0x0               ; =0
    ade4: eb0c01ff     	cmp	x15, x12
    ade8: 9a8d316a     	csel	x10, x11, x13, lo
    adec: 8b0f014a     	add	x10, x10, x15
    adf0: 9b0e254a     	madd	x10, x10, x14, x9
    adf4: b9400150     	ldr	w16, [x10]
    adf8: 71000a1f     	cmp	w16, #0x2
    adfc: 540000a3     	b.lo	0xae10 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0xc8>
    ae00: 910005ef     	add	x15, x15, #0x1
    ae04: eb0f011f     	cmp	x8, x15
    ae08: 54fffee1     	b.ne	0xade4 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x9c>
    ae0c: 17fffff5     	b	0xade0 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x98>
    ae10: 52800048     	mov	w8, #0x2                ; =2
    ae14: b9000148     	str	w8, [x10]
    ae18: a9008941     	stp	x1, x2, [x10, #0x8]
    ae1c: 52800000     	mov	w0, #0x0                ; =0
    ae20: d65f03c0     	ret
