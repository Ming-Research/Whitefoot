0000000000007d18 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66>:
    7d18: a9ba6ffc     	stp	x28, x27, [sp, #-0x60]!
    7d1c: a90167fa     	stp	x26, x25, [sp, #0x10]
    7d20: a9025ff8     	stp	x24, x23, [sp, #0x20]
    7d24: a90357f6     	stp	x22, x21, [sp, #0x30]
    7d28: a9044ff4     	stp	x20, x19, [sp, #0x40]
    7d2c: a9057bfd     	stp	x29, x30, [sp, #0x50]
    7d30: d10f43ff     	sub	sp, sp, #0x3d0
    7d34: aa0303f4     	mov	x20, x3
    7d38: aa0203f3     	mov	x19, x2
    7d3c: aa0003f5     	mov	x21, x0
    7d40: 92840008     	mov	x8, #-0x2001            ; =-8193
    7d44: 8b080028     	add	x8, x1, x8
    7d48: b140091f     	cmn	x8, #0x2, lsl #12       ; =0x2000
    7d4c: 54000182     	b.hs	0x7d7c <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x64>
    7d50: d2800016     	mov	x22, #0x0               ; =0
    7d54: d28f82a8     	mov	x8, #0x7c15             ; =31765
    7d58: f2afe948     	movk	x8, #0x7f4a, lsl #16
    7d5c: f2cf3728     	movk	x8, #0x79b9, lsl #32
    7d60: f2f3c6e8     	movk	x8, #0x9e37, lsl #48
    7d64: ca080288     	eor	x8, x20, x8
    7d68: f9009be8     	str	x8, [sp, #0x130]
    7d6c: 3904e3ff     	strb	wzr, [sp, #0x138]
    7d70: 90000000     	adrp	x0, 0x7000 <_wf_map_cost_lookup_query$instance$9333f784ff449eba+0x94>
		0000000000007d70:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    7d74: 91000000     	add	x0, x0, #0x0
		0000000000007d74:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    7d78: 14000030     	b	0x7e38 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x120>
    7d7c: 531e7428     	lsl	w8, w1, #2
    7d80: 51001117     	sub	w23, w8, #0x4
    7d84: 121e36e8     	and	w8, w23, #0xfffc
    7d88: 52955569     	mov	w9, #0xaaab             ; =43691
    7d8c: 1b097d08     	mul	w8, w8, w9
    7d90: 53117d08     	lsr	w8, w8, #17
    7d94: 11000516     	add	w22, w8, #0x1
    7d98: d28f82a8     	mov	x8, #0x7c15             ; =31765
    7d9c: f2afe948     	movk	x8, #0x7f4a, lsl #16
    7da0: f2cf3728     	movk	x8, #0x79b9, lsl #32
    7da4: f2f3c6e8     	movk	x8, #0x9e37, lsl #48
    7da8: ca080288     	eor	x8, x20, x8
    7dac: f9009be8     	str	x8, [sp, #0x130]
    7db0: 3904e3ff     	strb	wzr, [sp, #0x138]
    7db4: 8b3652c8     	add	x8, x22, w22, uxtw #4
    7db8: d37ced00     	lsl	x0, x8, #4
    7dbc: 94000000     	bl	0x7dbc <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0xa4>
		0000000000007dbc:  ARM64_RELOC_BRANCH26	_malloc
    7dc0: b40019a0     	cbz	x0, 0x80f4 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x3dc>
    7dc4: 12003ee8     	and	w8, w23, #0xffff
    7dc8: 7100251f     	cmp	w8, #0x9
    7dcc: 54000062     	b.hs	0x7dd8 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0xc0>
    7dd0: d2800008     	mov	x8, #0x0                ; =0
    7dd4: 1400000d     	b	0x7e08 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0xf0>
    7dd8: 927e32c8     	and	x8, x22, #0x7ffc
    7ddc: aa0003e9     	mov	x9, x0
    7de0: aa0803ea     	mov	x10, x8
    7de4: b900013f     	str	wzr, [x9]
    7de8: b901113f     	str	wzr, [x9, #0x110]
    7dec: b902213f     	str	wzr, [x9, #0x220]
    7df0: b903313f     	str	wzr, [x9, #0x330]
    7df4: 91110129     	add	x9, x9, #0x440
    7df8: f100114a     	subs	x10, x10, #0x4
    7dfc: 54ffff41     	b.ne	0x7de4 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0xcc>
    7e00: eb16011f     	cmp	x8, x22
    7e04: 540001a0     	b.eq	0x7e38 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x120>
    7e08: 92403ee9     	and	x9, x23, #0xffff
    7e0c: b200f3ea     	mov	x10, #0x5555555555555555 ; =6148914691236517205
    7e10: f28aaaca     	movk	x10, #0x5556
    7e14: 9bca7d29     	umulh	x9, x9, x10
    7e18: aa2903e9     	mvn	x9, x9
    7e1c: 8b080129     	add	x9, x9, x8
    7e20: 8b081108     	add	x8, x8, x8, lsl #4
    7e24: d37ced08     	lsl	x8, x8, #4
    7e28: b828681f     	str	wzr, [x0, x8]
    7e2c: 91044108     	add	x8, x8, #0x110
    7e30: b1000529     	adds	x9, x9, #0x1
    7e34: 54ffffa3     	b.lo	0x7e28 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x110>
    7e38: a910dbf6     	stp	x22, x22, [sp, #0x108]
    7e3c: a9127fff     	stp	xzr, xzr, [sp, #0x120]
    7e40: f9008fe0     	str	x0, [sp, #0x118]
    7e44: b4001353     	cbz	x19, 0x80ac <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x394>
    7e48: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$9333f784ff449eba+0x94>
		0000000000007e48:  ARM64_RELOC_PAGE21	lCPI65_0
    7e4c: 3dc00100     	ldr	q0, [x8]
		0000000000007e4c:  ARM64_RELOC_PAGEOFF12	lCPI65_0
    7e50: 3d803fe0     	str	q0, [sp, #0xf0]
    7e54: 910943f7     	add	x23, sp, #0x250
    7e58: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$9333f784ff449eba+0x94>
		0000000000007e58:  ARM64_RELOC_PAGE21	lCPI65_1
    7e5c: 3dc00100     	ldr	q0, [x8]
		0000000000007e5c:  ARM64_RELOC_PAGEOFF12	lCPI65_1
    7e60: 3d803be0     	str	q0, [sp, #0xe0]
    7e64: 910943f8     	add	x24, sp, #0x250
    7e68: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$9333f784ff449eba+0x94>
		0000000000007e68:  ARM64_RELOC_PAGE21	lCPI65_2
    7e6c: 3dc00100     	ldr	q0, [x8]
		0000000000007e6c:  ARM64_RELOC_PAGEOFF12	lCPI65_2
    7e70: 3d8037e0     	str	q0, [sp, #0xd0]
    7e74: 9104a319     	add	x25, x24, #0x128
    7e78: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$9333f784ff449eba+0x94>
		0000000000007e78:  ARM64_RELOC_PAGE21	lCPI65_3
    7e7c: 3dc00100     	ldr	q0, [x8]
		0000000000007e7c:  ARM64_RELOC_PAGEOFF12	lCPI65_3
    7e80: 3d8033e0     	str	q0, [sp, #0xc0]
    7e84: 52800036     	mov	w22, #0x1               ; =1
    7e88: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$9333f784ff449eba+0x94>
		0000000000007e88:  ARM64_RELOC_PAGE21	lCPI65_4
    7e8c: 3dc00100     	ldr	q0, [x8]
		0000000000007e8c:  ARM64_RELOC_PAGEOFF12	lCPI65_4
    7e90: 3d802fe0     	str	q0, [sp, #0xb0]
    7e94: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$9333f784ff449eba+0x94>
		0000000000007e94:  ARM64_RELOC_PAGE21	lCPI65_5
    7e98: 3dc00100     	ldr	q0, [x8]
		0000000000007e98:  ARM64_RELOC_PAGEOFF12	lCPI65_5
    7e9c: 3d802be0     	str	q0, [sp, #0xa0]
    7ea0: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$9333f784ff449eba+0x94>
		0000000000007ea0:  ARM64_RELOC_PAGE21	lCPI65_6
    7ea4: 3dc00100     	ldr	q0, [x8]
		0000000000007ea4:  ARM64_RELOC_PAGEOFF12	lCPI65_6
    7ea8: 3d8027e0     	str	q0, [sp, #0x90]
    7eac: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$9333f784ff449eba+0x94>
		0000000000007eac:  ARM64_RELOC_PAGE21	lCPI65_7
    7eb0: 3dc00100     	ldr	q0, [x8]
		0000000000007eb0:  ARM64_RELOC_PAGEOFF12	lCPI65_7
    7eb4: 3d8023e0     	str	q0, [sp, #0x80]
    7eb8: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$9333f784ff449eba+0x94>
		0000000000007eb8:  ARM64_RELOC_PAGE21	lCPI65_8
    7ebc: 3dc00100     	ldr	q0, [x8]
		0000000000007ebc:  ARM64_RELOC_PAGEOFF12	lCPI65_8
    7ec0: 3d801fe0     	str	q0, [sp, #0x70]
    7ec4: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$9333f784ff449eba+0x94>
		0000000000007ec4:  ARM64_RELOC_PAGE21	lCPI65_9
    7ec8: 3dc00100     	ldr	q0, [x8]
		0000000000007ec8:  ARM64_RELOC_PAGEOFF12	lCPI65_9
    7ecc: 3d801be0     	str	q0, [sp, #0x60]
    7ed0: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$9333f784ff449eba+0x94>
		0000000000007ed0:  ARM64_RELOC_PAGE21	lCPI65_10
    7ed4: 3dc00100     	ldr	q0, [x8]
		0000000000007ed4:  ARM64_RELOC_PAGEOFF12	lCPI65_10
    7ed8: 3d8017e0     	str	q0, [sp, #0x50]
    7edc: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$9333f784ff449eba+0x94>
		0000000000007edc:  ARM64_RELOC_PAGE21	lCPI65_11
    7ee0: 3dc00100     	ldr	q0, [x8]
		0000000000007ee0:  ARM64_RELOC_PAGEOFF12	lCPI65_11
    7ee4: 3d8013e0     	str	q0, [sp, #0x40]
    7ee8: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$9333f784ff449eba+0x94>
		0000000000007ee8:  ARM64_RELOC_PAGE21	lCPI65_12
    7eec: 3dc00100     	ldr	q0, [x8]
		0000000000007eec:  ARM64_RELOC_PAGEOFF12	lCPI65_12
    7ef0: 3d800fe0     	str	q0, [sp, #0x30]
    7ef4: 5284001a     	mov	w26, #0x2000            ; =8192
    7ef8: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$9333f784ff449eba+0x94>
		0000000000007ef8:  ARM64_RELOC_PAGE21	lCPI65_13
    7efc: 3dc00100     	ldr	q0, [x8]
		0000000000007efc:  ARM64_RELOC_PAGEOFF12	lCPI65_13
    7f00: 3d800be0     	str	q0, [sp, #0x20]
    7f04: aa1303fb     	mov	x27, x19
    7f08: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_query$instance$9333f784ff449eba+0x94>
		0000000000007f08:  ARM64_RELOC_PAGE21	lCPI65_14
    7f0c: 3dc00100     	ldr	q0, [x8]
		0000000000007f0c:  ARM64_RELOC_PAGEOFF12	lCPI65_14
    7f10: 3d8007e0     	str	q0, [sp, #0x10]
    7f14: aa1403fc     	mov	x28, x20
    7f18: 14000014     	b	0x7f68 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x250>
    7f1c: f140083f     	cmp	x1, #0x2, lsl #12       ; =0x2000
    7f20: 9a9a3028     	csel	x8, x1, x26, lo
    7f24: d37ff901     	lsl	x1, x8, #1
    7f28: 910423e0     	add	x0, sp, #0x108
    7f2c: 9104c3e2     	add	x2, sp, #0x130
    7f30: 94000000     	bl	0x7f30 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x218>
		0000000000007f30:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    7f34: b903cbe0     	str	w0, [sp, #0x3c8]
    7f38: 390f33e1     	strb	w1, [sp, #0x3cc]
    7f3c: 390f37e2     	strb	w2, [sp, #0x3cd]
    7f40: 910503e0     	add	x0, sp, #0x140
    7f44: 910423e1     	add	x1, sp, #0x108
    7f48: 910943e3     	add	x3, sp, #0x250
    7f4c: 9104c3e4     	add	x4, sp, #0x130
    7f50: aa1603e2     	mov	x2, x22
    7f54: 94000000     	bl	0x7f54 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x23c>
		0000000000007f54:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
    7f58: 9100079c     	add	x28, x28, #0x1
    7f5c: 91000ad6     	add	x22, x22, #0x2
    7f60: f100077b     	subs	x27, x27, #0x1
    7f64: 54000a40     	b.eq	0x80ac <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x394>
    7f68: 4e080f80     	dup.2d	v0, x28
    7f6c: 91007f88     	add	x8, x28, #0x1f
    7f70: 3dc03fe1     	ldr	q1, [sp, #0xf0]
    7f74: 4ee18401     	add.2d	v1, v0, v1
    7f78: 3c8082e1     	stur	q1, [x23, #0x8]
    7f7c: 3dc03be1     	ldr	q1, [sp, #0xe0]
    7f80: 4ee18401     	add.2d	v1, v0, v1
    7f84: 3c8182e1     	stur	q1, [x23, #0x18]
    7f88: 3dc037e1     	ldr	q1, [sp, #0xd0]
    7f8c: 4ee18401     	add.2d	v1, v0, v1
    7f90: 3c8282e1     	stur	q1, [x23, #0x28]
    7f94: 3dc033e1     	ldr	q1, [sp, #0xc0]
    7f98: 4ee18401     	add.2d	v1, v0, v1
    7f9c: 3c8382e1     	stur	q1, [x23, #0x38]
    7fa0: 3dc02fe1     	ldr	q1, [sp, #0xb0]
    7fa4: 4ee18401     	add.2d	v1, v0, v1
    7fa8: 3c8482e1     	stur	q1, [x23, #0x48]
    7fac: 3dc02be1     	ldr	q1, [sp, #0xa0]
    7fb0: 4ee18401     	add.2d	v1, v0, v1
    7fb4: 3c8582e1     	stur	q1, [x23, #0x58]
    7fb8: 3dc027e1     	ldr	q1, [sp, #0x90]
    7fbc: 4ee18401     	add.2d	v1, v0, v1
    7fc0: 3c8682e1     	stur	q1, [x23, #0x68]
    7fc4: 3dc023e1     	ldr	q1, [sp, #0x80]
    7fc8: 4ee18401     	add.2d	v1, v0, v1
    7fcc: 3c8782e1     	stur	q1, [x23, #0x78]
    7fd0: 3dc01fe1     	ldr	q1, [sp, #0x70]
    7fd4: 4ee18401     	add.2d	v1, v0, v1
    7fd8: 3c8882e1     	stur	q1, [x23, #0x88]
    7fdc: 3dc01be1     	ldr	q1, [sp, #0x60]
    7fe0: 4ee18401     	add.2d	v1, v0, v1
    7fe4: 3c8982e1     	stur	q1, [x23, #0x98]
    7fe8: 3dc017e1     	ldr	q1, [sp, #0x50]
    7fec: 4ee18401     	add.2d	v1, v0, v1
    7ff0: 3c8a82e1     	stur	q1, [x23, #0xa8]
    7ff4: 3dc013e1     	ldr	q1, [sp, #0x40]
    7ff8: 4ee18401     	add.2d	v1, v0, v1
    7ffc: 3c8b82e1     	stur	q1, [x23, #0xb8]
    8000: 3dc00fe1     	ldr	q1, [sp, #0x30]
    8004: 4ee18401     	add.2d	v1, v0, v1
    8008: 3c8c82e1     	stur	q1, [x23, #0xc8]
    800c: 3dc00be1     	ldr	q1, [sp, #0x20]
    8010: 4ee18401     	add.2d	v1, v0, v1
    8014: 3c8d82e1     	stur	q1, [x23, #0xd8]
    8018: 3dc007e1     	ldr	q1, [sp, #0x10]
    801c: 4ee18400     	add.2d	v0, v0, v1
    8020: 3c8e82e0     	stur	q0, [x23, #0xe8]
    8024: f9012bfc     	str	x28, [sp, #0x250]
    8028: f901a7e8     	str	x8, [sp, #0x348]
    802c: f94087e1     	ldr	x1, [sp, #0x108]
    8030: f94097e8     	ldr	x8, [sp, #0x128]
    8034: f9009308     	str	x8, [x24, #0x120]
    8038: 910067e9     	add	x9, sp, #0x19
    803c: 3ccff120     	ldur	q0, [x9, #0xff]
    8040: 910027e9     	add	x9, sp, #0x9
    8044: 3ccff121     	ldur	q1, [x9, #0xff]
    8048: ad080301     	stp	q1, q0, [x24, #0x100]
    804c: f9001328     	str	x8, [x25, #0x20]
    8050: f941b7e8     	ldr	x8, [sp, #0x368]
    8054: f941cfe9     	ldr	x9, [sp, #0x398]
    8058: ab090108     	adds	x8, x8, x9
    805c: da9f3109     	csinv	x9, x8, xzr, lo
    8060: d34efc28     	lsr	x8, x1, #14
    8064: ad000321     	stp	q1, q0, [x25]
    8068: b5fff6c8     	cbnz	x8, 0x7f40 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x228>
    806c: cb410828     	sub	x8, x1, x1, lsr #2
    8070: eb08013f     	cmp	x9, x8
    8074: 54fff663     	b.lo	0x7f40 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x228>
    8078: f94097e9     	ldr	x9, [sp, #0x128]
    807c: f900bb09     	str	x9, [x24, #0x170]
    8080: 910067e9     	add	x9, sp, #0x19
    8084: 3ccff120     	ldur	q0, [x9, #0xff]
    8088: 910027e9     	add	x9, sp, #0x9
    808c: 3ccff121     	ldur	q1, [x9, #0xff]
    8090: ad0a8301     	stp	q1, q0, [x24, #0x150]
    8094: f941dfe9     	ldr	x9, [sp, #0x3b8]
    8098: eb48053f     	cmp	x9, x8, lsr #1
    809c: 54fff463     	b.lo	0x7f28 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x210>
    80a0: b5fff3e1     	cbnz	x1, 0x7f1c <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x204>
    80a4: 52800021     	mov	w1, #0x1                ; =1
    80a8: 17ffffa0     	b	0x7f28 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x210>
    80ac: 910027e8     	add	x8, sp, #0x9
    80b0: 3ccff100     	ldur	q0, [x8, #0xff]
    80b4: 910067e8     	add	x8, sp, #0x19
    80b8: 3ccff101     	ldur	q1, [x8, #0xff]
    80bc: ad0006a0     	stp	q0, q1, [x21]
    80c0: f94097e8     	ldr	x8, [sp, #0x128]
    80c4: f90012a8     	str	x8, [x21, #0x20]
    80c8: 3dc04fe0     	ldr	q0, [sp, #0x130]
    80cc: 3c8282a0     	stur	q0, [x21, #0x28]
    80d0: a903ceb4     	stp	x20, x19, [x21, #0x38]
    80d4: 910f43ff     	add	sp, sp, #0x3d0
    80d8: a9457bfd     	ldp	x29, x30, [sp, #0x50]
    80dc: a9444ff4     	ldp	x20, x19, [sp, #0x40]
    80e0: a94357f6     	ldp	x22, x21, [sp, #0x30]
    80e4: a9425ff8     	ldp	x24, x23, [sp, #0x20]
    80e8: a94167fa     	ldp	x26, x25, [sp, #0x10]
    80ec: a8c66ffc     	ldp	x28, x27, [sp], #0x60
    80f0: d65f03c0     	ret
    80f4: 94000000     	bl	0x80f4 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x3dc>
		00000000000080f4:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
