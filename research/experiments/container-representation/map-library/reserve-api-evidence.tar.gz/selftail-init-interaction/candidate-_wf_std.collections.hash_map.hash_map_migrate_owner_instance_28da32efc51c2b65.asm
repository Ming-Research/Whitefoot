000000000000b234 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65>:
    b234: 3940206a     	ldrb	w10, [x3, #0x8]
    b238: f9400008     	ldr	x8, [x0]
    b23c: b40002a8     	cbz	x8, 0xb290 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65+0x5c>
    b240: ad400440     	ldp	q0, q1, [x2]
    b244: ad410c42     	ldp	q2, q3, [x2, #0x20]
    b248: ad421444     	ldp	q4, q5, [x2, #0x40]
    b24c: ad431c46     	ldp	q6, q7, [x2, #0x60]
    b250: ad444450     	ldp	q16, q17, [x2, #0x80]
    b254: ad454c52     	ldp	q18, q19, [x2, #0xa0]
    b258: ad465454     	ldp	q20, q21, [x2, #0xc0]
    b25c: ad475c56     	ldp	q22, q23, [x2, #0xe0]
    b260: f9400809     	ldr	x9, [x0, #0x10]
    b264: 360001ca     	tbz	w10, #0x0, 0xb29c <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65+0x68>
    b268: d280000b     	mov	x11, #0x0               ; =0
    b26c: aa0903ea     	mov	x10, x9
    b270: b940014c     	ldr	w12, [x10]
    b274: 7100099f     	cmp	w12, #0x2
    b278: 54000523     	b.lo	0xb31c <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65+0xe8>
    b27c: 9100056b     	add	x11, x11, #0x1
    b280: 9104414a     	add	x10, x10, #0x110
    b284: eb0b011f     	cmp	x8, x11
    b288: 54ffff41     	b.ne	0xb270 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65+0x3c>
    b28c: 17fffff7     	b	0xb268 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65+0x34>
    b290: 3600004a     	tbz	w10, #0x0, 0xb298 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65+0x64>
    b294: 14000000     	b	0xb294 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65+0x60>
    b298: 14000000     	b	0xb298 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65+0x64>
    b29c: f940006a     	ldr	x10, [x3]
    b2a0: ca01014a     	eor	x10, x10, x1
    b2a4: ca4a794a     	eor	x10, x10, x10, lsr #30
    b2a8: d29cb72b     	mov	x11, #0xe5b9            ; =58809
    b2ac: f2a39c8b     	movk	x11, #0x1ce4, lsl #16
    b2b0: f2c8edab     	movk	x11, #0x476d, lsl #32
    b2b4: f2f7eb0b     	movk	x11, #0xbf58, lsl #48
    b2b8: 9b0b7d4a     	mul	x10, x10, x11
    b2bc: ca4a6d4a     	eor	x10, x10, x10, lsr #27
    b2c0: d2823d6b     	mov	x11, #0x11eb            ; =4587
    b2c4: f2a2662b     	movk	x11, #0x1331, lsl #16
    b2c8: f2c9376b     	movk	x11, #0x49bb, lsl #32
    b2cc: f2f29a0b     	movk	x11, #0x94d0, lsl #48
    b2d0: 9b0b7d4a     	mul	x10, x10, x11
    b2d4: ca4a7d4a     	eor	x10, x10, x10, lsr #31
    b2d8: 9ac8094b     	udiv	x11, x10, x8
    b2dc: 9b08a96b     	msub	x11, x11, x8, x10
    b2e0: cb0b010c     	sub	x12, x8, x11
    b2e4: cb0c03ed     	neg	x13, x12
    b2e8: 5280220e     	mov	w14, #0x110             ; =272
    b2ec: d280000f     	mov	x15, #0x0               ; =0
    b2f0: eb0c01ff     	cmp	x15, x12
    b2f4: 9a8d316a     	csel	x10, x11, x13, lo
    b2f8: 8b0f014a     	add	x10, x10, x15
    b2fc: 9b0e254a     	madd	x10, x10, x14, x9
    b300: b9400150     	ldr	w16, [x10]
    b304: 71000a1f     	cmp	w16, #0x2
    b308: 540000a3     	b.lo	0xb31c <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65+0xe8>
    b30c: 910005ef     	add	x15, x15, #0x1
    b310: eb0f011f     	cmp	x8, x15
    b314: 54fffee1     	b.ne	0xb2f0 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65+0xbc>
    b318: 17fffff5     	b	0xb2ec <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65+0xb8>
    b31c: 52800048     	mov	w8, #0x2                ; =2
    b320: b9000148     	str	w8, [x10]
    b324: f9000541     	str	x1, [x10, #0x8]
    b328: ad008540     	stp	q0, q1, [x10, #0x10]
    b32c: ad018d42     	stp	q2, q3, [x10, #0x30]
    b330: ad029544     	stp	q4, q5, [x10, #0x50]
    b334: ad039d46     	stp	q6, q7, [x10, #0x70]
    b338: ad04c550     	stp	q16, q17, [x10, #0x90]
    b33c: ad05cd52     	stp	q18, q19, [x10, #0xb0]
    b340: ad06d554     	stp	q20, q21, [x10, #0xd0]
    b344: ad07dd56     	stp	q22, q23, [x10, #0xf0]
    b348: 52800000     	mov	w0, #0x0                ; =0
    b34c: d65f03c0     	ret
