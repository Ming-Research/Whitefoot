000000000000a954 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65>:
    a954: d10543ff     	sub	sp, sp, #0x150
    a958: a9106ffc     	stp	x28, x27, [sp, #0x100]
    a95c: a9115ff8     	stp	x24, x23, [sp, #0x110]
    a960: a91257f6     	stp	x22, x21, [sp, #0x120]
    a964: a9134ff4     	stp	x20, x19, [sp, #0x130]
    a968: a9147bfd     	stp	x29, x30, [sp, #0x140]
    a96c: f140103f     	cmp	x1, #0x4, lsl #12       ; =0x4000
    a970: 540000a8     	b.hi	0xa984 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x30>
    a974: aa0003f3     	mov	x19, x0
    a978: f9400016     	ldr	x22, [x0]
    a97c: eb16003f     	cmp	x1, x22
    a980: 54000162     	b.hs	0xa9ac <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x58>
    a984: 52800020     	mov	w0, #0x1                ; =1
    a988: 52800001     	mov	w1, #0x0                ; =0
    a98c: 52800002     	mov	w2, #0x0                ; =0
    a990: a9547bfd     	ldp	x29, x30, [sp, #0x140]
    a994: a9534ff4     	ldp	x20, x19, [sp, #0x130]
    a998: a95257f6     	ldp	x22, x21, [sp, #0x120]
    a99c: a9515ff8     	ldp	x24, x23, [sp, #0x110]
    a9a0: a9506ffc     	ldp	x28, x27, [sp, #0x100]
    a9a4: 910543ff     	add	sp, sp, #0x150
    a9a8: d65f03c0     	ret
    a9ac: b4000181     	cbz	x1, 0xa9dc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x88>
    a9b0: aa0203f4     	mov	x20, x2
    a9b4: aa0103f5     	mov	x21, x1
    a9b8: 8b011028     	add	x8, x1, x1, lsl #4
    a9bc: d37ced00     	lsl	x0, x8, #4
    a9c0: 94000000     	bl	0xa9c0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x6c>
		000000000000a9c0:  ARM64_RELOC_BRANCH26	_malloc
    a9c4: b40008c0     	cbz	x0, 0xaadc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x188>
    a9c8: aa1503e8     	mov	x8, x21
    a9cc: f10012bf     	cmp	x21, #0x4
    a9d0: 540000a2     	b.hs	0xa9e4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x90>
    a9d4: d2800009     	mov	x9, #0x0                ; =0
    a9d8: 14000010     	b	0xaa18 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xc4>
    a9dc: 52800000     	mov	w0, #0x0                ; =0
    a9e0: 17ffffea     	b	0xa988 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x34>
    a9e4: d280000a     	mov	x10, #0x0               ; =0
    a9e8: 927e3109     	and	x9, x8, #0x7ffc
    a9ec: aa0003eb     	mov	x11, x0
    a9f0: b900017f     	str	wzr, [x11]
    a9f4: b901117f     	str	wzr, [x11, #0x110]
    a9f8: b902217f     	str	wzr, [x11, #0x220]
    a9fc: b903317f     	str	wzr, [x11, #0x330]
    aa00: 9100114a     	add	x10, x10, #0x4
    aa04: 9111016b     	add	x11, x11, #0x440
    aa08: eb0a013f     	cmp	x9, x10
    aa0c: 54ffff21     	b.ne	0xa9f0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x9c>
    aa10: eb09011f     	cmp	x8, x9
    aa14: 54000100     	b.eq	0xaa34 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xe0>
    aa18: 5280220a     	mov	w10, #0x110             ; =272
    aa1c: 9baa012a     	umaddl	x10, w9, w10, x0
    aa20: b900015f     	str	wzr, [x10]
    aa24: 91000529     	add	x9, x9, #0x1
    aa28: 9104414a     	add	x10, x10, #0x110
    aa2c: eb09011f     	cmp	x8, x9
    aa30: 54ffff81     	b.ne	0xaa20 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xcc>
    aa34: a940d677     	ldp	x23, x21, [x19, #0x8]
    aa38: a9002268     	stp	x8, x8, [x19]
    aa3c: f9000a60     	str	x0, [x19, #0x10]
    aa40: b4000436     	cbz	x22, 0xaac4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x170>
    aa44: 52802208     	mov	w8, #0x110              ; =272
    aa48: 9b0856c8     	madd	x8, x22, x8, x21
    aa4c: d1044118     	sub	x24, x8, #0x110
    aa50: 14000004     	b	0xaa60 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x10c>
    aa54: d1044318     	sub	x24, x24, #0x110
    aa58: d10006d6     	sub	x22, x22, #0x1
    aa5c: b4000356     	cbz	x22, 0xaac4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x170>
    aa60: b9400308     	ldr	w8, [x24]
    aa64: 7100051f     	cmp	w8, #0x1
    aa68: 54ffff69     	b.ls	0xaa54 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x100>
    aa6c: f9400701     	ldr	x1, [x24, #0x8]
    aa70: ad468700     	ldp	q0, q1, [x24, #0xd0]
    aa74: ad0607e0     	stp	q0, q1, [sp, #0xc0]
    aa78: ad478700     	ldp	q0, q1, [x24, #0xf0]
    aa7c: ad0707e0     	stp	q0, q1, [sp, #0xe0]
    aa80: ad448700     	ldp	q0, q1, [x24, #0x90]
    aa84: ad0407e0     	stp	q0, q1, [sp, #0x80]
    aa88: ad458700     	ldp	q0, q1, [x24, #0xb0]
    aa8c: ad0507e0     	stp	q0, q1, [sp, #0xa0]
    aa90: ad428700     	ldp	q0, q1, [x24, #0x50]
    aa94: ad0207e0     	stp	q0, q1, [sp, #0x40]
    aa98: ad438700     	ldp	q0, q1, [x24, #0x70]
    aa9c: ad0307e0     	stp	q0, q1, [sp, #0x60]
    aaa0: ad408700     	ldp	q0, q1, [x24, #0x10]
    aaa4: ad0007e0     	stp	q0, q1, [sp]
    aaa8: ad418700     	ldp	q0, q1, [x24, #0x30]
    aaac: ad0107e0     	stp	q0, q1, [sp, #0x20]
    aab0: 910003e2     	mov	x2, sp
    aab4: aa1303e0     	mov	x0, x19
    aab8: aa1403e3     	mov	x3, x20
    aabc: 94000000     	bl	0xaabc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x168>
		000000000000aabc:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65
    aac0: 17ffffe5     	b	0xaa54 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x100>
    aac4: b4000077     	cbz	x23, 0xaad0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x17c>
    aac8: aa1503e0     	mov	x0, x21
    aacc: 94000000     	bl	0xaacc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x178>
		000000000000aacc:  ARM64_RELOC_BRANCH26	_free
    aad0: 52800000     	mov	w0, #0x0                ; =0
    aad4: f900127f     	str	xzr, [x19, #0x20]
    aad8: 17ffffac     	b	0xa988 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x34>
    aadc: 94000000     	bl	0xaadc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x188>
		000000000000aadc:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
