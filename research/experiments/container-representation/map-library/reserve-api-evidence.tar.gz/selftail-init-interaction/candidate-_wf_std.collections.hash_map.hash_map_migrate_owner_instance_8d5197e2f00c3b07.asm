000000000000af84 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07>:
    af84: 3940206a     	ldrb	w10, [x3, #0x8]
    af88: f9400008     	ldr	x8, [x0]
    af8c: b40002a8     	cbz	x8, 0xafe0 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0x5c>
    af90: ad400440     	ldp	q0, q1, [x2]
    af94: ad410c42     	ldp	q2, q3, [x2, #0x20]
    af98: ad421444     	ldp	q4, q5, [x2, #0x40]
    af9c: ad431c46     	ldp	q6, q7, [x2, #0x60]
    afa0: ad444450     	ldp	q16, q17, [x2, #0x80]
    afa4: ad454c52     	ldp	q18, q19, [x2, #0xa0]
    afa8: ad465454     	ldp	q20, q21, [x2, #0xc0]
    afac: ad475c56     	ldp	q22, q23, [x2, #0xe0]
    afb0: f9400809     	ldr	x9, [x0, #0x10]
    afb4: 360001ca     	tbz	w10, #0x0, 0xafec <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0x68>
    afb8: d280000b     	mov	x11, #0x0               ; =0
    afbc: aa0903ea     	mov	x10, x9
    afc0: b940014c     	ldr	w12, [x10]
    afc4: 7100099f     	cmp	w12, #0x2
    afc8: 54000523     	b.lo	0xb06c <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0xe8>
    afcc: 9100056b     	add	x11, x11, #0x1
    afd0: 9104414a     	add	x10, x10, #0x110
    afd4: eb0b011f     	cmp	x8, x11
    afd8: 54ffff41     	b.ne	0xafc0 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0x3c>
    afdc: 17fffff7     	b	0xafb8 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0x34>
    afe0: 3600004a     	tbz	w10, #0x0, 0xafe8 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0x64>
    afe4: 14000000     	b	0xafe4 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0x60>
    afe8: 14000000     	b	0xafe8 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0x64>
    afec: f940006a     	ldr	x10, [x3]
    aff0: ca01014a     	eor	x10, x10, x1
    aff4: ca4a794a     	eor	x10, x10, x10, lsr #30
    aff8: d29cb72b     	mov	x11, #0xe5b9            ; =58809
    affc: f2a39c8b     	movk	x11, #0x1ce4, lsl #16
    b000: f2c8edab     	movk	x11, #0x476d, lsl #32
    b004: f2f7eb0b     	movk	x11, #0xbf58, lsl #48
    b008: 9b0b7d4a     	mul	x10, x10, x11
    b00c: ca4a6d4a     	eor	x10, x10, x10, lsr #27
    b010: d2823d6b     	mov	x11, #0x11eb            ; =4587
    b014: f2a2662b     	movk	x11, #0x1331, lsl #16
    b018: f2c9376b     	movk	x11, #0x49bb, lsl #32
    b01c: f2f29a0b     	movk	x11, #0x94d0, lsl #48
    b020: 9b0b7d4a     	mul	x10, x10, x11
    b024: ca4a7d4a     	eor	x10, x10, x10, lsr #31
    b028: 9ac8094b     	udiv	x11, x10, x8
    b02c: 9b08a96b     	msub	x11, x11, x8, x10
    b030: cb0b010c     	sub	x12, x8, x11
    b034: cb0c03ed     	neg	x13, x12
    b038: 5280220e     	mov	w14, #0x110             ; =272
    b03c: d280000f     	mov	x15, #0x0               ; =0
    b040: eb0c01ff     	cmp	x15, x12
    b044: 9a8d316a     	csel	x10, x11, x13, lo
    b048: 8b0f014a     	add	x10, x10, x15
    b04c: 9b0e254a     	madd	x10, x10, x14, x9
    b050: b9400150     	ldr	w16, [x10]
    b054: 71000a1f     	cmp	w16, #0x2
    b058: 540000a3     	b.lo	0xb06c <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0xe8>
    b05c: 910005ef     	add	x15, x15, #0x1
    b060: eb0f011f     	cmp	x8, x15
    b064: 54fffee1     	b.ne	0xb040 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0xbc>
    b068: 17fffff5     	b	0xb03c <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0xb8>
    b06c: 52800048     	mov	w8, #0x2                ; =2
    b070: b9000148     	str	w8, [x10]
    b074: f9000541     	str	x1, [x10, #0x8]
    b078: ad008540     	stp	q0, q1, [x10, #0x10]
    b07c: ad018d42     	stp	q2, q3, [x10, #0x30]
    b080: ad029544     	stp	q4, q5, [x10, #0x50]
    b084: ad039d46     	stp	q6, q7, [x10, #0x70]
    b088: ad04c550     	stp	q16, q17, [x10, #0x90]
    b08c: ad05cd52     	stp	q18, q19, [x10, #0xb0]
    b090: ad06d554     	stp	q20, q21, [x10, #0xd0]
    b094: ad07dd56     	stp	q22, q23, [x10, #0xf0]
    b098: 52800000     	mov	w0, #0x0                ; =0
    b09c: d65f03c0     	ret
