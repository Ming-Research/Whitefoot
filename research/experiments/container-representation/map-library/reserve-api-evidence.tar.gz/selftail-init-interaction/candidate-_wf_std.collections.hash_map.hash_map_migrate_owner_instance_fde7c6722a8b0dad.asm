000000000000aea8 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad>:
    aea8: 3940206a     	ldrb	w10, [x3, #0x8]
    aeac: f9400008     	ldr	x8, [x0]
    aeb0: b40001a8     	cbz	x8, 0xaee4 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x3c>
    aeb4: f9400809     	ldr	x9, [x0, #0x10]
    aeb8: 360001ca     	tbz	w10, #0x0, 0xaef0 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x48>
    aebc: d280000b     	mov	x11, #0x0               ; =0
    aec0: aa0903ea     	mov	x10, x9
    aec4: b940014c     	ldr	w12, [x10]
    aec8: 7100099f     	cmp	w12, #0x2
    aecc: 54000523     	b.lo	0xaf70 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0xc8>
    aed0: 9100056b     	add	x11, x11, #0x1
    aed4: 9100614a     	add	x10, x10, #0x18
    aed8: eb0b011f     	cmp	x8, x11
    aedc: 54ffff41     	b.ne	0xaec4 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x1c>
    aee0: 17fffff7     	b	0xaebc <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x14>
    aee4: 3600004a     	tbz	w10, #0x0, 0xaeec <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x44>
    aee8: 14000000     	b	0xaee8 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x40>
    aeec: 14000000     	b	0xaeec <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x44>
    aef0: f940006a     	ldr	x10, [x3]
    aef4: ca01014a     	eor	x10, x10, x1
    aef8: ca4a794a     	eor	x10, x10, x10, lsr #30
    aefc: d29cb72b     	mov	x11, #0xe5b9            ; =58809
    af00: f2a39c8b     	movk	x11, #0x1ce4, lsl #16
    af04: f2c8edab     	movk	x11, #0x476d, lsl #32
    af08: f2f7eb0b     	movk	x11, #0xbf58, lsl #48
    af0c: 9b0b7d4a     	mul	x10, x10, x11
    af10: ca4a6d4a     	eor	x10, x10, x10, lsr #27
    af14: d2823d6b     	mov	x11, #0x11eb            ; =4587
    af18: f2a2662b     	movk	x11, #0x1331, lsl #16
    af1c: f2c9376b     	movk	x11, #0x49bb, lsl #32
    af20: f2f29a0b     	movk	x11, #0x94d0, lsl #48
    af24: 9b0b7d4a     	mul	x10, x10, x11
    af28: ca4a7d4a     	eor	x10, x10, x10, lsr #31
    af2c: 9ac8094b     	udiv	x11, x10, x8
    af30: 9b08a96b     	msub	x11, x11, x8, x10
    af34: cb0b010c     	sub	x12, x8, x11
    af38: cb0c03ed     	neg	x13, x12
    af3c: 5280030e     	mov	w14, #0x18              ; =24
    af40: d280000f     	mov	x15, #0x0               ; =0
    af44: eb0c01ff     	cmp	x15, x12
    af48: 9a8d316a     	csel	x10, x11, x13, lo
    af4c: 8b0f014a     	add	x10, x10, x15
    af50: 9b0e254a     	madd	x10, x10, x14, x9
    af54: b9400150     	ldr	w16, [x10]
    af58: 71000a1f     	cmp	w16, #0x2
    af5c: 540000a3     	b.lo	0xaf70 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0xc8>
    af60: 910005ef     	add	x15, x15, #0x1
    af64: eb0f011f     	cmp	x8, x15
    af68: 54fffee1     	b.ne	0xaf44 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x9c>
    af6c: 17fffff5     	b	0xaf40 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x98>
    af70: 52800048     	mov	w8, #0x2                ; =2
    af74: b9000148     	str	w8, [x10]
    af78: a9008941     	stp	x1, x2, [x10, #0x8]
    af7c: 52800000     	mov	w0, #0x0                ; =0
    af80: d65f03c0     	ret
