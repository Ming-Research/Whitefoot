000000000000a470 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743>:
    a470: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    a474: a90157f6     	stp	x22, x21, [sp, #0x10]
    a478: a9024ff4     	stp	x20, x19, [sp, #0x20]
    a47c: a9037bfd     	stp	x29, x30, [sp, #0x30]
    a480: aa0103f4     	mov	x20, x1
    a484: aa0003f3     	mov	x19, x0
    a488: a9405817     	ldp	x23, x22, [x0]
    a48c: eb0102df     	cmp	x22, x1
    a490: 54000302     	b.hs	0xa4f0 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x80>
    a494: f9400a75     	ldr	x21, [x19, #0x10]
    a498: 8b141288     	add	x8, x20, x20, lsl #4
    a49c: d37ced01     	lsl	x1, x8, #4
    a4a0: f10002df     	cmp	x22, #0x0
    a4a4: fa5612e0     	ccmp	x23, x22, #0x0, ne
    a4a8: 540001c0     	b.eq	0xa4e0 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x70>
    a4ac: aa0103e0     	mov	x0, x1
    a4b0: 94000000     	bl	0xa4b0 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x40>
		000000000000a4b0:  ARM64_RELOC_BRANCH26	_malloc
    a4b4: b4000640     	cbz	x0, 0xa57c <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x10c>
    a4b8: b40001b6     	cbz	x22, 0xa4ec <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x7c>
    a4bc: 8b1712e8     	add	x8, x23, x23, lsl #4
    a4c0: d37ced02     	lsl	x2, x8, #4
    a4c4: aa0003f6     	mov	x22, x0
    a4c8: aa1503e1     	mov	x1, x21
    a4cc: 94000000     	bl	0xa4cc <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x5c>
		000000000000a4cc:  ARM64_RELOC_BRANCH26	_memcpy
    a4d0: aa1503e0     	mov	x0, x21
    a4d4: 94000000     	bl	0xa4d4 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x64>
		000000000000a4d4:  ARM64_RELOC_BRANCH26	_free
    a4d8: aa1603e0     	mov	x0, x22
    a4dc: 14000004     	b	0xa4ec <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x7c>
    a4e0: aa1503e0     	mov	x0, x21
    a4e4: 94000000     	bl	0xa4e4 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x74>
		000000000000a4e4:  ARM64_RELOC_BRANCH26	_realloc
    a4e8: b40004a0     	cbz	x0, 0xa57c <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x10c>
    a4ec: a9008274     	stp	x20, x0, [x19, #0x8]
    a4f0: eb17028a     	subs	x10, x20, x23
    a4f4: 54000389     	b.ls	0xa564 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xf4>
    a4f8: f9400a69     	ldr	x9, [x19, #0x10]
    a4fc: aa1703e8     	mov	x8, x23
    a500: f100115f     	cmp	x10, #0x4
    a504: 540001e3     	b.lo	0xa540 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xd0>
    a508: 927ef54b     	and	x11, x10, #0xfffffffffffffffc
    a50c: 8b0b02e8     	add	x8, x23, x11
    a510: 5280220c     	mov	w12, #0x110             ; =272
    a514: 9b0c26ec     	madd	x12, x23, x12, x9
    a518: aa0b03ed     	mov	x13, x11
    a51c: b900019f     	str	wzr, [x12]
    a520: b901119f     	str	wzr, [x12, #0x110]
    a524: b902219f     	str	wzr, [x12, #0x220]
    a528: b903319f     	str	wzr, [x12, #0x330]
    a52c: 9111018c     	add	x12, x12, #0x440
    a530: f10011ad     	subs	x13, x13, #0x4
    a534: 54ffff41     	b.ne	0xa51c <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xac>
    a538: eb0b015f     	cmp	x10, x11
    a53c: 54000120     	b.eq	0xa560 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xf0>
    a540: 5280220a     	mov	w10, #0x110             ; =272
    a544: 9b0a2509     	madd	x9, x8, x10, x9
    a548: cb08028a     	sub	x10, x20, x8
    a54c: b900013f     	str	wzr, [x9]
    a550: 91000508     	add	x8, x8, #0x1
    a554: 91044129     	add	x9, x9, #0x110
    a558: f100054a     	subs	x10, x10, #0x1
    a55c: 54ffff81     	b.ne	0xa54c <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xdc>
    a560: f9000268     	str	x8, [x19]
    a564: 52800000     	mov	w0, #0x0                ; =0
    a568: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    a56c: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    a570: a94157f6     	ldp	x22, x21, [sp, #0x10]
    a574: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    a578: d65f03c0     	ret
    a57c: 94000000     	bl	0xa57c <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x10c>
		000000000000a57c:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
