00000000000078bc <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba>:
    78bc: d10283ff     	sub	sp, sp, #0xa0
    78c0: a9046ffc     	stp	x28, x27, [sp, #0x40]
    78c4: a90567fa     	stp	x26, x25, [sp, #0x50]
    78c8: a9065ff8     	stp	x24, x23, [sp, #0x60]
    78cc: a90757f6     	stp	x22, x21, [sp, #0x70]
    78d0: a9084ff4     	stp	x20, x19, [sp, #0x80]
    78d4: a9097bfd     	stp	x29, x30, [sp, #0x90]
    78d8: aa0303f4     	mov	x20, x3
    78dc: aa0203f3     	mov	x19, x2
    78e0: aa0003f5     	mov	x21, x0
    78e4: d28f82a8     	mov	x8, #0x7c15             ; =31765
    78e8: f2afe948     	movk	x8, #0x7f4a, lsl #16
    78ec: f2cf3728     	movk	x8, #0x79b9, lsl #32
    78f0: f2f3c6e8     	movk	x8, #0x9e37, lsl #48
    78f4: 92840009     	mov	x9, #-0x2001            ; =-8193
    78f8: 8b090029     	add	x9, x1, x9
    78fc: b140093f     	cmn	x9, #0x2, lsl #12       ; =0x2000
    7900: 54000102     	b.hs	0x7920 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x64>
    7904: d2800001     	mov	x1, #0x0                ; =0
    7908: ca080296     	eor	x22, x20, x8
    790c: f9001bf6     	str	x22, [sp, #0x30]
    7910: 3900e3ff     	strb	wzr, [sp, #0x38]
    7914: 90000000     	adrp	x0, 0x7000 <_wf_map_cost_lookup_query$instance$9333f784ff449eba+0x94>
		0000000000007914:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    7918: 91000000     	add	x0, x0, #0x0
		0000000000007918:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    791c: 1400002f     	b	0x79d8 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x11c>
    7920: 531e7429     	lsl	w9, w1, #2
    7924: 51001137     	sub	w23, w9, #0x4
    7928: 121e36e9     	and	w9, w23, #0xfffc
    792c: 5295556a     	mov	w10, #0xaaab            ; =43691
    7930: 1b0a7d29     	mul	w9, w9, w10
    7934: 53117d29     	lsr	w9, w9, #17
    7938: 11000529     	add	w9, w9, #0x1
    793c: ca080296     	eor	x22, x20, x8
    7940: f9001bf6     	str	x22, [sp, #0x30]
    7944: 3900e3ff     	strb	wzr, [sp, #0x38]
    7948: aa0903f8     	mov	x24, x9
    794c: 8b294528     	add	x8, x9, w9, uxtw #1
    7950: d37df100     	lsl	x0, x8, #3
    7954: 94000000     	bl	0x7954 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x98>
		0000000000007954:  ARM64_RELOC_BRANCH26	_malloc
    7958: b4001340     	cbz	x0, 0x7bc0 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x304>
    795c: 12003ee8     	and	w8, w23, #0xffff
    7960: 7100251f     	cmp	w8, #0x9
    7964: 54000082     	b.hs	0x7974 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0xb8>
    7968: d2800008     	mov	x8, #0x0                ; =0
    796c: aa1803e1     	mov	x1, x24
    7970: 1400000e     	b	0x79a8 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0xec>
    7974: aa1803e1     	mov	x1, x24
    7978: 927e3308     	and	x8, x24, #0x7ffc
    797c: 9100c009     	add	x9, x0, #0x30
    7980: aa0803ea     	mov	x10, x8
    7984: b81d013f     	stur	wzr, [x9, #-0x30]
    7988: b81e813f     	stur	wzr, [x9, #-0x18]
    798c: b900013f     	str	wzr, [x9]
    7990: b900193f     	str	wzr, [x9, #0x18]
    7994: 91018129     	add	x9, x9, #0x60
    7998: f100114a     	subs	x10, x10, #0x4
    799c: 54ffff41     	b.ne	0x7984 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0xc8>
    79a0: eb01011f     	cmp	x8, x1
    79a4: 540001a0     	b.eq	0x79d8 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x11c>
    79a8: 92403ee9     	and	x9, x23, #0xffff
    79ac: b200f3ea     	mov	x10, #0x5555555555555555 ; =6148914691236517205
    79b0: f28aaaca     	movk	x10, #0x5556
    79b4: 9bca7d29     	umulh	x9, x9, x10
    79b8: aa2903e9     	mvn	x9, x9
    79bc: 8b080129     	add	x9, x9, x8
    79c0: 8b080508     	add	x8, x8, x8, lsl #1
    79c4: d37df108     	lsl	x8, x8, #3
    79c8: b828681f     	str	wzr, [x0, x8]
    79cc: 91006108     	add	x8, x8, #0x18
    79d0: b1000529     	adds	x9, x9, #0x1
    79d4: 54ffffa3     	b.lo	0x79c8 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x10c>
    79d8: a90087e1     	stp	x1, x1, [sp, #0x8]
    79dc: a9027fff     	stp	xzr, xzr, [sp, #0x20]
    79e0: f9000fe0     	str	x0, [sp, #0x18]
    79e4: b4000cf3     	cbz	x19, 0x7b80 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x2c4>
    79e8: d2800017     	mov	x23, #0x0               ; =0
    79ec: 52800038     	mov	w24, #0x1               ; =1
    79f0: 5280031a     	mov	w26, #0x18              ; =24
    79f4: 5280005b     	mov	w27, #0x2               ; =2
    79f8: d29cb73c     	mov	x28, #0xe5b9            ; =58809
    79fc: f2a39c9c     	movk	x28, #0x1ce4, lsl #16
    7a00: f2c8edbc     	movk	x28, #0x476d, lsl #32
    7a04: f2f7eb1c     	movk	x28, #0xbf58, lsl #48
    7a08: d2823d79     	mov	x25, #0x11eb            ; =4587
    7a0c: f2a26639     	movk	x25, #0x1331, lsl #16
    7a10: f2c93779     	movk	x25, #0x49bb, lsl #32
    7a14: f2f29a19     	movk	x25, #0x94d0, lsl #48
    7a18: 14000006     	b	0x7a30 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x174>
    7a1c: b900015b     	str	w27, [x10]
    7a20: a900a548     	stp	x8, x9, [x10, #0x8]
    7a24: 910006f7     	add	x23, x23, #0x1
    7a28: eb1302ff     	cmp	x23, x19
    7a2c: 54000aa0     	b.eq	0x7b80 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x2c4>
    7a30: a94227e8     	ldp	x8, x9, [sp, #0x20]
    7a34: ab090109     	adds	x9, x8, x9
    7a38: da9f3129     	csinv	x9, x9, xzr, lo
    7a3c: d34efc2a     	lsr	x10, x1, #14
    7a40: b500020a     	cbnz	x10, 0x7a80 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x1c4>
    7a44: cb41082a     	sub	x10, x1, x1, lsr #2
    7a48: eb0a013f     	cmp	x9, x10
    7a4c: 540001a3     	b.lo	0x7a80 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x1c4>
    7a50: eb4a051f     	cmp	x8, x10, lsr #1
    7a54: 54000103     	b.lo	0x7a74 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x1b8>
    7a58: b40000c1     	cbz	x1, 0x7a70 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x1b4>
    7a5c: f140083f     	cmp	x1, #0x2, lsl #12       ; =0x2000
    7a60: 52840008     	mov	w8, #0x2000             ; =8192
    7a64: 9a883028     	csel	x8, x1, x8, lo
    7a68: d37ff901     	lsl	x1, x8, #1
    7a6c: 14000002     	b	0x7a74 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x1b8>
    7a70: 52800021     	mov	w1, #0x1                ; =1
    7a74: 910023e0     	add	x0, sp, #0x8
    7a78: 9100c3e2     	add	x2, sp, #0x30
    7a7c: 94000000     	bl	0x7a7c <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x1c0>
		0000000000007a7c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    7a80: aa170708     	orr	x8, x24, x23, lsl #1
    7a84: 3940e3e9     	ldrb	w9, [sp, #0x38]
    7a88: 360003c9     	tbz	w9, #0x0, 0x7b00 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x244>
    7a8c: d280000a     	mov	x10, #0x0               ; =0
    7a90: 8b1402e9     	add	x9, x23, x20
    7a94: f94007e1     	ldr	x1, [sp, #0x8]
    7a98: b4000461     	cbz	x1, 0x7b24 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x268>
    7a9c: 9ac1094b     	udiv	x11, x10, x1
    7aa0: 9b01a96b     	msub	x11, x11, x1, x10
    7aa4: f9400fec     	ldr	x12, [sp, #0x18]
    7aa8: aa0103ed     	mov	x13, x1
    7aac: aa0103ea     	mov	x10, x1
    7ab0: 14000008     	b	0x7ad0 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x214>
    7ab4: eb01015f     	cmp	x10, x1
    7ab8: 9a8a016a     	csel	x10, x11, x10, eq
    7abc: 9100056e     	add	x14, x11, #0x1
    7ac0: eb0101df     	cmp	x14, x1
    7ac4: 9a8b27eb     	csinc	x11, xzr, x11, hs
    7ac8: f10005ad     	subs	x13, x13, #0x1
    7acc: 540002e0     	b.eq	0x7b28 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x26c>
    7ad0: 9b1a316e     	madd	x14, x11, x26, x12
    7ad4: b94001cf     	ldr	w15, [x14]
    7ad8: 710005ff     	cmp	w15, #0x1
    7adc: 54fffec0     	b.eq	0x7ab4 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x1f8>
    7ae0: 710009ff     	cmp	w15, #0x2
    7ae4: 54000441     	b.ne	0x7b6c <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x2b0>
    7ae8: f94005cf     	ldr	x15, [x14, #0x8]
    7aec: eb0801ff     	cmp	x15, x8
    7af0: 54fffe61     	b.ne	0x7abc <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x200>
    7af4: b90001db     	str	w27, [x14]
    7af8: f90009c9     	str	x9, [x14, #0x10]
    7afc: 17ffffca     	b	0x7a24 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x168>
    7b00: ca160109     	eor	x9, x8, x22
    7b04: ca497929     	eor	x9, x9, x9, lsr #30
    7b08: 9b1c7d29     	mul	x9, x9, x28
    7b0c: ca496d29     	eor	x9, x9, x9, lsr #27
    7b10: 9b197d29     	mul	x9, x9, x25
    7b14: ca497d2a     	eor	x10, x9, x9, lsr #31
    7b18: 8b1402e9     	add	x9, x23, x20
    7b1c: f94007e1     	ldr	x1, [sp, #0x8]
    7b20: b5fffbe1     	cbnz	x1, 0x7a9c <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x1e0>
    7b24: d280000a     	mov	x10, #0x0               ; =0
    7b28: eb01015f     	cmp	x10, x1
    7b2c: 54fff7c2     	b.hs	0x7a24 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x168>
    7b30: f94013eb     	ldr	x11, [sp, #0x20]
    7b34: d34efd6c     	lsr	x12, x11, #14
    7b38: b5fff76c     	cbnz	x12, 0x7a24 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x168>
    7b3c: 9100056b     	add	x11, x11, #0x1
    7b40: f90013eb     	str	x11, [sp, #0x20]
    7b44: f9400feb     	ldr	x11, [sp, #0x18]
    7b48: 9b1a2d4a     	madd	x10, x10, x26, x11
    7b4c: b940014b     	ldr	w11, [x10]
    7b50: 7100057f     	cmp	w11, #0x1
    7b54: 54fff641     	b.ne	0x7a1c <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x160>
    7b58: f94017eb     	ldr	x11, [sp, #0x28]
    7b5c: f100056b     	subs	x11, x11, #0x1
    7b60: 9a8b33eb     	csel	x11, xzr, x11, lo
    7b64: f90017eb     	str	x11, [sp, #0x28]
    7b68: 17ffffad     	b	0x7a1c <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x160>
    7b6c: eb01015f     	cmp	x10, x1
    7b70: 9a8a016a     	csel	x10, x11, x10, eq
    7b74: eb01015f     	cmp	x10, x1
    7b78: 54fff562     	b.hs	0x7a24 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x168>
    7b7c: 17ffffed     	b	0x7b30 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x274>
    7b80: 3cc083e0     	ldur	q0, [sp, #0x8]
    7b84: 3cc183e1     	ldur	q1, [sp, #0x18]
    7b88: ad0006a0     	stp	q0, q1, [x21]
    7b8c: f94017e8     	ldr	x8, [sp, #0x28]
    7b90: f90012a8     	str	x8, [x21, #0x20]
    7b94: 3dc00fe0     	ldr	q0, [sp, #0x30]
    7b98: 3c8282a0     	stur	q0, [x21, #0x28]
    7b9c: a903ceb4     	stp	x20, x19, [x21, #0x38]
    7ba0: a9497bfd     	ldp	x29, x30, [sp, #0x90]
    7ba4: a9484ff4     	ldp	x20, x19, [sp, #0x80]
    7ba8: a94757f6     	ldp	x22, x21, [sp, #0x70]
    7bac: a9465ff8     	ldp	x24, x23, [sp, #0x60]
    7bb0: a94567fa     	ldp	x26, x25, [sp, #0x50]
    7bb4: a9446ffc     	ldp	x28, x27, [sp, #0x40]
    7bb8: 910283ff     	add	sp, sp, #0xa0
    7bbc: d65f03c0     	ret
    7bc0: 94000000     	bl	0x7bc0 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x304>
		0000000000007bc0:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
