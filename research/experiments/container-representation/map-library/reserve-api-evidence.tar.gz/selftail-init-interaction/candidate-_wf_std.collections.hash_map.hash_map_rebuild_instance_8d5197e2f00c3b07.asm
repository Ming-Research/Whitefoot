000000000000a580 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07>:
    a580: d10543ff     	sub	sp, sp, #0x150
    a584: a9106ffc     	stp	x28, x27, [sp, #0x100]
    a588: a9115ff8     	stp	x24, x23, [sp, #0x110]
    a58c: a91257f6     	stp	x22, x21, [sp, #0x120]
    a590: a9134ff4     	stp	x20, x19, [sp, #0x130]
    a594: a9147bfd     	stp	x29, x30, [sp, #0x140]
    a598: f1000c3f     	cmp	x1, #0x3
    a59c: 540000a8     	b.hi	0xa5b0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x30>
    a5a0: aa0003f3     	mov	x19, x0
    a5a4: f9400016     	ldr	x22, [x0]
    a5a8: eb16003f     	cmp	x1, x22
    a5ac: 54000162     	b.hs	0xa5d8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x58>
    a5b0: 52800020     	mov	w0, #0x1                ; =1
    a5b4: 52800001     	mov	w1, #0x0                ; =0
    a5b8: 52800002     	mov	w2, #0x0                ; =0
    a5bc: a9547bfd     	ldp	x29, x30, [sp, #0x140]
    a5c0: a9534ff4     	ldp	x20, x19, [sp, #0x130]
    a5c4: a95257f6     	ldp	x22, x21, [sp, #0x120]
    a5c8: a9515ff8     	ldp	x24, x23, [sp, #0x110]
    a5cc: a9506ffc     	ldp	x28, x27, [sp, #0x100]
    a5d0: 910543ff     	add	sp, sp, #0x150
    a5d4: d65f03c0     	ret
    a5d8: b4000721     	cbz	x1, 0xa6bc <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x13c>
    a5dc: aa0203f4     	mov	x20, x2
    a5e0: aa0103f5     	mov	x21, x1
    a5e4: 8b011028     	add	x8, x1, x1, lsl #4
    a5e8: d37ced00     	lsl	x0, x8, #4
    a5ec: 94000000     	bl	0xa5ec <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x6c>
		000000000000a5ec:  ARM64_RELOC_BRANCH26	_malloc
    a5f0: b40006a0     	cbz	x0, 0xa6c4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x144>
    a5f4: d2800008     	mov	x8, #0x0                ; =0
    a5f8: aa0003ea     	mov	x10, x0
    a5fc: aa1503e9     	mov	x9, x21
    a600: b900015f     	str	wzr, [x10]
    a604: 91000508     	add	x8, x8, #0x1
    a608: 9104414a     	add	x10, x10, #0x110
    a60c: eb08013f     	cmp	x9, x8
    a610: 54ffff81     	b.ne	0xa600 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x80>
    a614: a940d677     	ldp	x23, x21, [x19, #0x8]
    a618: a9002669     	stp	x9, x9, [x19]
    a61c: f9000a60     	str	x0, [x19, #0x10]
    a620: b4000436     	cbz	x22, 0xa6a4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x124>
    a624: 52802208     	mov	w8, #0x110              ; =272
    a628: 9b0856c8     	madd	x8, x22, x8, x21
    a62c: d1044118     	sub	x24, x8, #0x110
    a630: 14000004     	b	0xa640 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0xc0>
    a634: d1044318     	sub	x24, x24, #0x110
    a638: d10006d6     	sub	x22, x22, #0x1
    a63c: b4000356     	cbz	x22, 0xa6a4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x124>
    a640: b9400308     	ldr	w8, [x24]
    a644: 7100051f     	cmp	w8, #0x1
    a648: 54ffff69     	b.ls	0xa634 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0xb4>
    a64c: f9400701     	ldr	x1, [x24, #0x8]
    a650: ad468700     	ldp	q0, q1, [x24, #0xd0]
    a654: ad0607e0     	stp	q0, q1, [sp, #0xc0]
    a658: ad478700     	ldp	q0, q1, [x24, #0xf0]
    a65c: ad0707e0     	stp	q0, q1, [sp, #0xe0]
    a660: ad448700     	ldp	q0, q1, [x24, #0x90]
    a664: ad0407e0     	stp	q0, q1, [sp, #0x80]
    a668: ad458700     	ldp	q0, q1, [x24, #0xb0]
    a66c: ad0507e0     	stp	q0, q1, [sp, #0xa0]
    a670: ad428700     	ldp	q0, q1, [x24, #0x50]
    a674: ad0207e0     	stp	q0, q1, [sp, #0x40]
    a678: ad438700     	ldp	q0, q1, [x24, #0x70]
    a67c: ad0307e0     	stp	q0, q1, [sp, #0x60]
    a680: ad408700     	ldp	q0, q1, [x24, #0x10]
    a684: ad0007e0     	stp	q0, q1, [sp]
    a688: ad418700     	ldp	q0, q1, [x24, #0x30]
    a68c: ad0107e0     	stp	q0, q1, [sp, #0x20]
    a690: 910003e2     	mov	x2, sp
    a694: aa1303e0     	mov	x0, x19
    a698: aa1403e3     	mov	x3, x20
    a69c: 94000000     	bl	0xa69c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x11c>
		000000000000a69c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07
    a6a0: 17ffffe5     	b	0xa634 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0xb4>
    a6a4: b4000077     	cbz	x23, 0xa6b0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x130>
    a6a8: aa1503e0     	mov	x0, x21
    a6ac: 94000000     	bl	0xa6ac <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x12c>
		000000000000a6ac:  ARM64_RELOC_BRANCH26	_free
    a6b0: 52800000     	mov	w0, #0x0                ; =0
    a6b4: f900127f     	str	xzr, [x19, #0x20]
    a6b8: 17ffffbf     	b	0xa5b4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x34>
    a6bc: 52800000     	mov	w0, #0x0                ; =0
    a6c0: 17ffffbd     	b	0xa5b4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x34>
    a6c4: 94000000     	bl	0xa6c4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x144>
		000000000000a6c4:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
