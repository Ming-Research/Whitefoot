0000000000009f84 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad>:
    9f84: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    9f88: a90157f6     	stp	x22, x21, [sp, #0x10]
    9f8c: a9024ff4     	stp	x20, x19, [sp, #0x20]
    9f90: a9037bfd     	stp	x29, x30, [sp, #0x30]
    9f94: f140103f     	cmp	x1, #0x4, lsl #12       ; =0x4000
    9f98: 54000088     	b.hi	0x9fa8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x24>
    9f9c: f9400014     	ldr	x20, [x0]
    9fa0: eb14003f     	cmp	x1, x20
    9fa4: 54000122     	b.hs	0x9fc8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x44>
    9fa8: 52800020     	mov	w0, #0x1                ; =1
    9fac: 52800001     	mov	w1, #0x0                ; =0
    9fb0: 52800002     	mov	w2, #0x0                ; =0
    9fb4: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    9fb8: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    9fbc: a94157f6     	ldp	x22, x21, [sp, #0x10]
    9fc0: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    9fc4: d65f03c0     	ret
    9fc8: b40001e1     	cbz	x1, 0xa004 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x80>
    9fcc: aa0003f3     	mov	x19, x0
    9fd0: f9400055     	ldr	x21, [x2]
    9fd4: 39402056     	ldrb	w22, [x2, #0x8]
    9fd8: aa0103f7     	mov	x23, x1
    9fdc: 8b010428     	add	x8, x1, x1, lsl #1
    9fe0: d37df100     	lsl	x0, x8, #3
    9fe4: 94000000     	bl	0x9fe4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x60>
		0000000000009fe4:  ARM64_RELOC_BRANCH26	_malloc
    9fe8: b4000da0     	cbz	x0, 0xa19c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x218>
    9fec: aa1703ea     	mov	x10, x23
    9ff0: f10012ff     	cmp	x23, #0x4
    9ff4: aa1303e9     	mov	x9, x19
    9ff8: 540000a2     	b.hs	0xa00c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x88>
    9ffc: d2800008     	mov	x8, #0x0                ; =0
    a000: 14000010     	b	0xa040 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xbc>
    a004: 52800000     	mov	w0, #0x0                ; =0
    a008: 17ffffe9     	b	0x9fac <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x28>
    a00c: d280000b     	mov	x11, #0x0               ; =0
    a010: 927e3148     	and	x8, x10, #0x7ffc
    a014: 9100c00c     	add	x12, x0, #0x30
    a018: b81d019f     	stur	wzr, [x12, #-0x30]
    a01c: b81e819f     	stur	wzr, [x12, #-0x18]
    a020: b900019f     	str	wzr, [x12]
    a024: b900199f     	str	wzr, [x12, #0x18]
    a028: 9100116b     	add	x11, x11, #0x4
    a02c: 9101818c     	add	x12, x12, #0x60
    a030: eb0b011f     	cmp	x8, x11
    a034: 54ffff21     	b.ne	0xa018 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x94>
    a038: eb08015f     	cmp	x10, x8
    a03c: 540000e0     	b.eq	0xa058 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xd4>
    a040: 5280030b     	mov	w11, #0x18              ; =24
    a044: 9bab010b     	umaddl	x11, w8, w11, x0
    a048: b801857f     	str	wzr, [x11], #0x18
    a04c: 91000508     	add	x8, x8, #0x1
    a050: eb08015f     	cmp	x10, x8
    a054: 54ffffa1     	b.ne	0xa048 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xc4>
    a058: d100050c     	sub	x12, x8, #0x1
    a05c: a940a12b     	ldp	x11, x8, [x9, #0x8]
    a060: a900292a     	stp	x10, x10, [x9]
    a064: f9000920     	str	x0, [x9, #0x10]
    a068: b40008d4     	cbz	x20, 0xa180 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1fc>
    a06c: 36000316     	tbz	w22, #0x0, 0xa0cc <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x148>
    a070: 9100058a     	add	x10, x12, #0x1
    a074: 5280030c     	mov	w12, #0x18              ; =24
    a078: 5280004d     	mov	w13, #0x2               ; =2
    a07c: 14000004     	b	0xa08c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x108>
    a080: b90001ed     	str	w13, [x15]
    a084: 3c8081e0     	stur	q0, [x15, #0x8]
    a088: b40007d4     	cbz	x20, 0xa180 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1fc>
    a08c: d1000694     	sub	x20, x20, #0x1
    a090: 9b0c228e     	madd	x14, x20, x12, x8
    a094: b94001cf     	ldr	w15, [x14]
    a098: 710009ff     	cmp	w15, #0x2
    a09c: 54ffff63     	b.lo	0xa088 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x104>
    a0a0: 3cc081c0     	ldur	q0, [x14, #0x8]
    a0a4: d280000e     	mov	x14, #0x0               ; =0
    a0a8: aa0003ef     	mov	x15, x0
    a0ac: b94001f0     	ldr	w16, [x15]
    a0b0: 71000a1f     	cmp	w16, #0x2
    a0b4: 54fffe63     	b.lo	0xa080 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xfc>
    a0b8: 910005ce     	add	x14, x14, #0x1
    a0bc: 910061ef     	add	x15, x15, #0x18
    a0c0: eb0e015f     	cmp	x10, x14
    a0c4: 54ffff41     	b.ne	0xa0ac <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x128>
    a0c8: 17fffff7     	b	0xa0a4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x120>
    a0cc: 9100058c     	add	x12, x12, #0x1
    a0d0: 5280030d     	mov	w13, #0x18              ; =24
    a0d4: d29cb72e     	mov	x14, #0xe5b9            ; =58809
    a0d8: f2a39c8e     	movk	x14, #0x1ce4, lsl #16
    a0dc: f2c8edae     	movk	x14, #0x476d, lsl #32
    a0e0: f2f7eb0e     	movk	x14, #0xbf58, lsl #48
    a0e4: d2823d6f     	mov	x15, #0x11eb            ; =4587
    a0e8: f2a2662f     	movk	x15, #0x1331, lsl #16
    a0ec: f2c9376f     	movk	x15, #0x49bb, lsl #32
    a0f0: f2f29a0f     	movk	x15, #0x94d0, lsl #48
    a0f4: 52800050     	mov	w16, #0x2               ; =2
    a0f8: 14000002     	b	0xa100 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x17c>
    a0fc: b4000434     	cbz	x20, 0xa180 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1fc>
    a100: d1000694     	sub	x20, x20, #0x1
    a104: 9b0d2291     	madd	x17, x20, x13, x8
    a108: b9400221     	ldr	w1, [x17]
    a10c: 7100043f     	cmp	w1, #0x1
    a110: 54ffff69     	b.ls	0xa0fc <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x178>
    a114: 3cc08220     	ldur	q0, [x17, #0x8]
    a118: f9400631     	ldr	x17, [x17, #0x8]
    a11c: ca150231     	eor	x17, x17, x21
    a120: ca517a31     	eor	x17, x17, x17, lsr #30
    a124: 9b0e7e31     	mul	x17, x17, x14
    a128: ca516e31     	eor	x17, x17, x17, lsr #27
    a12c: 9b0f7e31     	mul	x17, x17, x15
    a130: ca517e31     	eor	x17, x17, x17, lsr #31
    a134: 9aca0a21     	udiv	x1, x17, x10
    a138: 9b0ac431     	msub	x17, x1, x10, x17
    a13c: cb110141     	sub	x1, x10, x17
    a140: cb0103e2     	neg	x2, x1
    a144: d2800003     	mov	x3, #0x0                ; =0
    a148: eb01007f     	cmp	x3, x1
    a14c: 9a823224     	csel	x4, x17, x2, lo
    a150: 8b030084     	add	x4, x4, x3
    a154: 9b0d0084     	madd	x4, x4, x13, x0
    a158: b9400085     	ldr	w5, [x4]
    a15c: 710004bf     	cmp	w5, #0x1
    a160: 540000a9     	b.ls	0xa174 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1f0>
    a164: 91000463     	add	x3, x3, #0x1
    a168: eb03019f     	cmp	x12, x3
    a16c: 54fffee1     	b.ne	0xa148 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1c4>
    a170: 17fffff5     	b	0xa144 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1c0>
    a174: b9000090     	str	w16, [x4]
    a178: 3c808080     	stur	q0, [x4, #0x8]
    a17c: b5fffc34     	cbnz	x20, 0xa100 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x17c>
    a180: b400008b     	cbz	x11, 0xa190 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x20c>
    a184: aa0803e0     	mov	x0, x8
    a188: 94000000     	bl	0xa188 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x204>
		000000000000a188:  ARM64_RELOC_BRANCH26	_free
    a18c: aa1303e9     	mov	x9, x19
    a190: 52800000     	mov	w0, #0x0                ; =0
    a194: f900113f     	str	xzr, [x9, #0x20]
    a198: 17ffff85     	b	0x9fac <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x28>
    a19c: 94000000     	bl	0xa19c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x218>
		000000000000a19c:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
