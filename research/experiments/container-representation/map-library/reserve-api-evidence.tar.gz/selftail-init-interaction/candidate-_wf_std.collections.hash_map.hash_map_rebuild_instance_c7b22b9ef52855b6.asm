0000000000009b1c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6>:
    9b1c: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    9b20: a90157f6     	stp	x22, x21, [sp, #0x10]
    9b24: a9024ff4     	stp	x20, x19, [sp, #0x20]
    9b28: a9037bfd     	stp	x29, x30, [sp, #0x30]
    9b2c: f1000c3f     	cmp	x1, #0x3
    9b30: 54000088     	b.hi	0x9b40 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x24>
    9b34: f9400014     	ldr	x20, [x0]
    9b38: eb14003f     	cmp	x1, x20
    9b3c: 54000122     	b.hs	0x9b60 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x44>
    9b40: 52800020     	mov	w0, #0x1                ; =1
    9b44: 52800001     	mov	w1, #0x0                ; =0
    9b48: 52800002     	mov	w2, #0x0                ; =0
    9b4c: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    9b50: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    9b54: a94157f6     	ldp	x22, x21, [sp, #0x10]
    9b58: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    9b5c: d65f03c0     	ret
    9b60: b4000581     	cbz	x1, 0x9c10 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xf4>
    9b64: aa0003f3     	mov	x19, x0
    9b68: f9400055     	ldr	x21, [x2]
    9b6c: 39402056     	ldrb	w22, [x2, #0x8]
    9b70: aa0103f7     	mov	x23, x1
    9b74: 8b010428     	add	x8, x1, x1, lsl #1
    9b78: d37df100     	lsl	x0, x8, #3
    9b7c: 94000000     	bl	0x9b7c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x60>
		0000000000009b7c:  ARM64_RELOC_BRANCH26	_malloc
    9b80: b4000b20     	cbz	x0, 0x9ce4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1c8>
    9b84: d2800009     	mov	x9, #0x0                ; =0
    9b88: aa0003e8     	mov	x8, x0
    9b8c: aa1303ea     	mov	x10, x19
    9b90: aa1703ec     	mov	x12, x23
    9b94: b801851f     	str	wzr, [x8], #0x18
    9b98: 91000529     	add	x9, x9, #0x1
    9b9c: eb09019f     	cmp	x12, x9
    9ba0: 54ffffa1     	b.ne	0x9b94 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x78>
    9ba4: a940a14b     	ldp	x11, x8, [x10, #0x8]
    9ba8: a900314c     	stp	x12, x12, [x10]
    9bac: f9000940     	str	x0, [x10, #0x10]
    9bb0: b40008d4     	cbz	x20, 0x9cc8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1ac>
    9bb4: 36000336     	tbz	w22, #0x0, 0x9c18 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xfc>
    9bb8: 5280030c     	mov	w12, #0x18              ; =24
    9bbc: 5280004d     	mov	w13, #0x2               ; =2
    9bc0: 14000004     	b	0x9bd0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xb4>
    9bc4: b90001ed     	str	w13, [x15]
    9bc8: 3c8081e0     	stur	q0, [x15, #0x8]
    9bcc: b40007f4     	cbz	x20, 0x9cc8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1ac>
    9bd0: d1000694     	sub	x20, x20, #0x1
    9bd4: 9b0c228e     	madd	x14, x20, x12, x8
    9bd8: b94001cf     	ldr	w15, [x14]
    9bdc: 710009ff     	cmp	w15, #0x2
    9be0: 54ffff63     	b.lo	0x9bcc <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xb0>
    9be4: 3cc081c0     	ldur	q0, [x14, #0x8]
    9be8: d280000e     	mov	x14, #0x0               ; =0
    9bec: aa0003ef     	mov	x15, x0
    9bf0: b94001f0     	ldr	w16, [x15]
    9bf4: 71000a1f     	cmp	w16, #0x2
    9bf8: 54fffe63     	b.lo	0x9bc4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xa8>
    9bfc: 910005ce     	add	x14, x14, #0x1
    9c00: 910061ef     	add	x15, x15, #0x18
    9c04: eb0e013f     	cmp	x9, x14
    9c08: 54ffff41     	b.ne	0x9bf0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xd4>
    9c0c: 17fffff7     	b	0x9be8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xcc>
    9c10: 52800000     	mov	w0, #0x0                ; =0
    9c14: 17ffffcc     	b	0x9b44 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x28>
    9c18: 5280030d     	mov	w13, #0x18              ; =24
    9c1c: d29cb72e     	mov	x14, #0xe5b9            ; =58809
    9c20: f2a39c8e     	movk	x14, #0x1ce4, lsl #16
    9c24: f2c8edae     	movk	x14, #0x476d, lsl #32
    9c28: f2f7eb0e     	movk	x14, #0xbf58, lsl #48
    9c2c: d2823d6f     	mov	x15, #0x11eb            ; =4587
    9c30: f2a2662f     	movk	x15, #0x1331, lsl #16
    9c34: f2c9376f     	movk	x15, #0x49bb, lsl #32
    9c38: f2f29a0f     	movk	x15, #0x94d0, lsl #48
    9c3c: 52800050     	mov	w16, #0x2               ; =2
    9c40: 14000002     	b	0x9c48 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x12c>
    9c44: b4000434     	cbz	x20, 0x9cc8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1ac>
    9c48: d1000694     	sub	x20, x20, #0x1
    9c4c: 9b0d2291     	madd	x17, x20, x13, x8
    9c50: b9400221     	ldr	w1, [x17]
    9c54: 7100043f     	cmp	w1, #0x1
    9c58: 54ffff69     	b.ls	0x9c44 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x128>
    9c5c: 3cc08220     	ldur	q0, [x17, #0x8]
    9c60: f9400631     	ldr	x17, [x17, #0x8]
    9c64: ca150231     	eor	x17, x17, x21
    9c68: ca517a31     	eor	x17, x17, x17, lsr #30
    9c6c: 9b0e7e31     	mul	x17, x17, x14
    9c70: ca516e31     	eor	x17, x17, x17, lsr #27
    9c74: 9b0f7e31     	mul	x17, x17, x15
    9c78: ca517e31     	eor	x17, x17, x17, lsr #31
    9c7c: 9acc0a21     	udiv	x1, x17, x12
    9c80: 9b0cc431     	msub	x17, x1, x12, x17
    9c84: cb110181     	sub	x1, x12, x17
    9c88: cb0103e2     	neg	x2, x1
    9c8c: d2800003     	mov	x3, #0x0                ; =0
    9c90: eb01007f     	cmp	x3, x1
    9c94: 9a823224     	csel	x4, x17, x2, lo
    9c98: 8b030084     	add	x4, x4, x3
    9c9c: 9b0d0084     	madd	x4, x4, x13, x0
    9ca0: b9400085     	ldr	w5, [x4]
    9ca4: 710004bf     	cmp	w5, #0x1
    9ca8: 540000a9     	b.ls	0x9cbc <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1a0>
    9cac: 91000463     	add	x3, x3, #0x1
    9cb0: eb03013f     	cmp	x9, x3
    9cb4: 54fffee1     	b.ne	0x9c90 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x174>
    9cb8: 17fffff5     	b	0x9c8c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x170>
    9cbc: b9000090     	str	w16, [x4]
    9cc0: 3c808080     	stur	q0, [x4, #0x8]
    9cc4: b5fffc34     	cbnz	x20, 0x9c48 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x12c>
    9cc8: b400008b     	cbz	x11, 0x9cd8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1bc>
    9ccc: aa0803e0     	mov	x0, x8
    9cd0: 94000000     	bl	0x9cd0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1b4>
		0000000000009cd0:  ARM64_RELOC_BRANCH26	_free
    9cd4: aa1303ea     	mov	x10, x19
    9cd8: 52800000     	mov	w0, #0x0                ; =0
    9cdc: f900115f     	str	xzr, [x10, #0x20]
    9ce0: 17ffff99     	b	0x9b44 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x28>
    9ce4: 94000000     	bl	0x9ce4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1c8>
		0000000000009ce4:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
