000000000000a3a4 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374>:
    a3a4: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    a3a8: a90157f6     	stp	x22, x21, [sp, #0x10]
    a3ac: a9024ff4     	stp	x20, x19, [sp, #0x20]
    a3b0: a9037bfd     	stp	x29, x30, [sp, #0x30]
    a3b4: aa0103f4     	mov	x20, x1
    a3b8: aa0003f3     	mov	x19, x0
    a3bc: a9405817     	ldp	x23, x22, [x0]
    a3c0: eb0102df     	cmp	x22, x1
    a3c4: 54000302     	b.hs	0xa424 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x80>
    a3c8: f9400a75     	ldr	x21, [x19, #0x10]
    a3cc: 8b141288     	add	x8, x20, x20, lsl #4
    a3d0: d37ced01     	lsl	x1, x8, #4
    a3d4: f10002df     	cmp	x22, #0x0
    a3d8: fa5612e0     	ccmp	x23, x22, #0x0, ne
    a3dc: 540001c0     	b.eq	0xa414 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x70>
    a3e0: aa0103e0     	mov	x0, x1
    a3e4: 94000000     	bl	0xa3e4 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x40>
		000000000000a3e4:  ARM64_RELOC_BRANCH26	_malloc
    a3e8: b4000560     	cbz	x0, 0xa494 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xf0>
    a3ec: b40001b6     	cbz	x22, 0xa420 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x7c>
    a3f0: 8b1712e8     	add	x8, x23, x23, lsl #4
    a3f4: d37ced02     	lsl	x2, x8, #4
    a3f8: aa0003f6     	mov	x22, x0
    a3fc: aa1503e1     	mov	x1, x21
    a400: 94000000     	bl	0xa400 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x5c>
		000000000000a400:  ARM64_RELOC_BRANCH26	_memcpy
    a404: aa1503e0     	mov	x0, x21
    a408: 94000000     	bl	0xa408 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x64>
		000000000000a408:  ARM64_RELOC_BRANCH26	_free
    a40c: aa1603e0     	mov	x0, x22
    a410: 14000004     	b	0xa420 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x7c>
    a414: aa1503e0     	mov	x0, x21
    a418: 94000000     	bl	0xa418 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x74>
		000000000000a418:  ARM64_RELOC_BRANCH26	_realloc
    a41c: b40003c0     	cbz	x0, 0xa494 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xf0>
    a420: a9008274     	stp	x20, x0, [x19, #0x8]
    a424: eb1402ff     	cmp	x23, x20
    a428: 540002a2     	b.hs	0xa47c <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xd8>
    a42c: f9400a68     	ldr	x8, [x19, #0x10]
    a430: 52802209     	mov	w9, #0x110              ; =272
    a434: 9b0922e8     	madd	x8, x23, x9, x8
    a438: 91002108     	add	x8, x8, #0x8
    a43c: 6f00e400     	movi.2d	v0, #0000000000000000
    a440: b81f811f     	stur	wzr, [x8, #-0x8]
    a444: 910006f7     	add	x23, x23, #0x1
    a448: ad000100     	stp	q0, q0, [x8]
    a44c: ad010100     	stp	q0, q0, [x8, #0x20]
    a450: ad020100     	stp	q0, q0, [x8, #0x40]
    a454: ad030100     	stp	q0, q0, [x8, #0x60]
    a458: ad040100     	stp	q0, q0, [x8, #0x80]
    a45c: ad050100     	stp	q0, q0, [x8, #0xa0]
    a460: ad060100     	stp	q0, q0, [x8, #0xc0]
    a464: ad070100     	stp	q0, q0, [x8, #0xe0]
    a468: f900811f     	str	xzr, [x8, #0x100]
    a46c: 91044108     	add	x8, x8, #0x110
    a470: eb17029f     	cmp	x20, x23
    a474: 54fffe61     	b.ne	0xa440 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x9c>
    a478: f9000277     	str	x23, [x19]
    a47c: 52800000     	mov	w0, #0x0                ; =0
    a480: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    a484: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    a488: a94157f6     	ldp	x22, x21, [sp, #0x10]
    a48c: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    a490: d65f03c0     	ret
    a494: 94000000     	bl	0xa494 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xf0>
		000000000000a494:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
