from pathlib import Path
import csv,json,statistics,re,hashlib
D=Path(__file__).resolve().parent
arms=('control','candidate');peers=('whitefoot-hash-map','rust-hash-map','cpp-unordered-map');groups={};rows=[];runs={}
for arm in arms:
 for cohort in (0,1):
  label=arm+str(cohort);part=list(csv.DictReader((D/(label+'.csv')).open()));assert len(part)==22032
  keys=[tuple(r.items()) for r in part];assert len(set(keys))==len(keys)
  err=(D/(label+'.stderr')).read_text();clock=int(re.search(r'maximum_empty_ns=(\d+)',err)[1]);quantum=int(re.search(r'minimum_nonzero_ns=(\d+)',err)[1]);empty=re.findall(r'^\d+,(\d+)$',err,re.M);assert len(empty)==1024
  status=json.loads((D/(label+'-status.json')).read_text());assert status['exit'] in (0,1)
  if status['exit']==1:assert err.rstrip().endswith('map ecosystem: reserve fixed-panel instrument qualification')
  runs[label]={'status':status,'rows':len(part),'clock_max_ns':clock,'clock_quantum_ns':quantum,'sha256':hashlib.sha256((D/(label+'.csv')).read_bytes()).hexdigest()}
  for r in part:
   assert int(r['cohort'])==cohort
   elapsed=int(r['elapsed_ns']);control=int(r['control'])
   key=(r['series'],int(r['element_bytes']),int(r['initial_floor']),r['path']);g=groups.setdefault(key,{})
   a=g.setdefault((arm,cohort,r['variant']),{'real':[],'control':[],'batches':[],'valid':True})
   if r['row_kind']=='sample':
    a['control' if control else 'real'].append(elapsed/int(r['calls']))
    if not control:
     a.setdefault('sample_ns',[]).append(elapsed);a['valid'] &= bool(int(r['instrument_valid'])) and elapsed>=1000000
   elif not control:
    assert bool(int(r['instrument_valid']))==(elapsed//100>=clock)
    a['batches'].append(elapsed);a['valid'] &= elapsed//100>=clock
   rows.append({'arm':arm,**r})
# Preserve all exact textual source field values, adding only arm provenance.
with (D/'samples.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
result=[];table=[]
spread=lambda a,b:max(a,b)/min(a,b)-1
for key,g in sorted(groups.items()):
 series,width,size,path=key;c={'series':series,'element_bytes':width,'initial_floor':size,'path':path,'arms':{},'cohort_pairs':[]}
 med={}
 for arm in arms:
  c['arms'][arm]=[]
  for cohort in (0,1):
   pr={}
   for peer in peers:
    a=g[arm,cohort,peer];assert len(a['real'])==len(a['control'])==9
    pr[peer]={'median':statistics.median(a['real']),'min':min(a['real']),'max':max(a['real']),'minimum_real_sample_ns':min(a['sample_ns']),'minimum_batch_ns':min(a['batches']),'maximum_batch_ns':max(a['batches']),'instrument_pass':a['valid']}
    med[arm,cohort,peer]=pr[peer]['median']
   slow=max(peers[1:],key=lambda p:pr[p]['median']);wf=pr[peers[0]]
   directions={peer:('WF faster' if wf['max']<pr[peer]['min'] else 'WF slower' if wf['min']>pr[peer]['max'] else 'overlap') for peer in peers[1:]}
   c['arms'][arm].append({'cohort':cohort,'peers':pr,'selected_slower_peer':slow,'directions':directions,'raw_peer_target_pass':wf['max']<pr[slow]['min']})
 for cohort in (0,1):
  a=c['arms']['control'][cohort]['peers'][peers[0]];b=c['arms']['candidate'][cohort]['peers'][peers[0]]
  direction='gain' if b['max']<a['min'] else 'loss' if b['min']>a['max'] else 'overlap'
  drift={p:spread(med['control',cohort,p],med['candidate',cohort,p]) for p in peers[1:]}
  c['cohort_pairs'].append({'cohort':cohort,'direction':direction,'candidate_control_ratio':b['median']/a['median'],'unchanged_peer_drift':drift})
 c['cohort_spreads']={arm:{peer:spread(med[arm,0,peer],med[arm,1,peer]) for peer in peers} for arm in arms}
 c['paired_ratio_spread']=spread(*[x['candidate_control_ratio'] for x in c['cohort_pairs']])
 c['instrument_pass']=all(g[a,k,p]['valid'] for a in arms for k in (0,1) for p in peers)
 c['stability_pass']=c['paired_ratio_spread']<=.1 and all(v<=.1 for a in c['cohort_spreads'].values() for v in a.values()) and all(v<=.1 for a in c['cohort_pairs'] for v in a['unchanged_peer_drift'].values())
 c['qualified_gain']=c['instrument_pass'] and c['stability_pass'] and all(x['direction']=='gain' for x in c['cohort_pairs'])
 c['qualified_loss']=c['instrument_pass'] and c['stability_pass'] and all(x['direction']=='loss' for x in c['cohort_pairs'])
 c['primary']=series=='aligned-hash' and width==256 and path=='grow'
 result.append(c)
 table.append(f"{series} {width}B S{size} {path}: pair {[x['direction'] for x in c['cohort_pairs']]}; instrument={c['instrument_pass']}; stability={c['stability_pass']}; gain={c['qualified_gain']}; ratio spread={100*c['paired_ratio_spread']:.3f}%")
 for arm in arms:
  for row in c['arms'][arm]:
   pr=row['peers'];table.append('  '+arm+str(row['cohort'])+' '+ '; '.join(f"{p}: {pr[p]['median']:.3f} [{pr[p]['min']:.3f},{pr[p]['max']:.3f}]" for p in peers)+'; '+str(row['directions']))
summary={'rows':len(rows),'real_sample_rows':sum(r['row_kind']=='sample' and r['control']=='0' for r in rows),'runs':runs,'cells':result,'primary_both_qualified_gain':all(c['qualified_gain'] for c in result if c['primary']),'all_cell_instrument_pass':all(c['instrument_pass'] for c in result),'selection':'No production selection; selftail-v2 fresh-Vacant initialization interaction floor'}
(D/'reduction.json').write_text(json.dumps(summary,indent=2)+'\n');(D/'reduction.txt').write_text('\n'.join(table)+'\n');print(json.dumps({'rows':len(rows),'primary':[{k:c[k] for k in ['initial_floor','cohort_pairs','instrument_pass','stability_pass','qualified_gain']} for c in result if c['primary']],'all_cell_instrument_pass':summary['all_cell_instrument_pass']},indent=2))
