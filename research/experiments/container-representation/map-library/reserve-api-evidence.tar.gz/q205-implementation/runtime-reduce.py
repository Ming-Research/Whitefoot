# Bounded adaptation of owner-argument-floor/timing/reduce.py.
# Caller: runtime-commands.txt. Input rows are never rewritten or filtered.
from pathlib import Path
import csv,json,statistics,re,hashlib
D=Path(__file__).resolve().parent
arms=('control','candidate');peers=('whitefoot-hash-map','rust-hash-map','cpp-unordered-map');groups={};rows=[];runs={}
for arm in arms:
 for cohort in (0,1):
  label=arm+str(cohort);part=list(csv.DictReader((D/('runtime-'+label+'.csv')).open()));assert len(part)==84240
  keys=[tuple(r.items()) for r in part];assert len(set(keys))==len(keys)
  err=(D/('runtime-'+label+'.stderr')).read_text();clock=int(re.search(r'maximum_empty_ns=(\d+)',err)[1]);quantum=int(re.search(r'minimum_nonzero_ns=(\d+)',err)[1]);empty=re.findall(r'^\d+,(\d+)$',err,re.M);assert len(empty)==1024;assert max(map(int,empty))==clock;assert 0<quantum<=100
  status=json.loads((D/('runtime-'+label+'-status.json')).read_text());assert status['exit'] in (0,1)
  if status['exit']==1:assert err.rstrip().endswith('map ecosystem: reserve fixed-panel instrument qualification')
  runs[label]={'status':status,'rows':len(part),'clock_max_ns':clock,'clock_quantum_ns':quantum,'sha256':hashlib.sha256((D/('runtime-'+label+'.csv')).read_bytes()).hexdigest()}
  hierarchy={}
  for r in part:
   assert int(r['cohort'])==cohort
   elapsed=int(r['elapsed_ns']);control=int(r['control'])
   size=int(r['initial_floor']);grow=r['path']=='grow';contexts=256 if size==64 else 8
   calls=(65536 if size==64 else 1024) if grow else 4194304
   batches=calls//contexts if grow else 1
   assert int(r['contexts'])==contexts and int(r['initial_count'])==size//2
   assert int(r['target_floor'])==(2*size if grow else size)
   assert int(r['calls'])==(calls if r['row_kind']=='sample' else contexts if grow else calls)
   assert int(r['batch_or_batches'])==batches if r['row_kind']=='sample' else 0<=int(r['batch_or_batches'])<batches
   hkey=tuple(r[k] for k in ('element_bytes','series','variant','path','initial_floor','sample','control'))
   hierarchy.setdefault(hkey,[]).append(r)
   key=(r['series'],int(r['element_bytes']),int(r['initial_floor']),r['path']);g=groups.setdefault(key,{})
   a=g.setdefault((arm,cohort,r['variant']),{'real':[],'control':[],'batches':[],'valid':True})
   if r['row_kind']=='sample':
    a['control' if control else 'real'].append(elapsed/int(r['calls']))
    if not control:
     a.setdefault('sample_ns',[]).append(elapsed);a['valid'] &= bool(int(r['instrument_valid'])) and elapsed>=1000000
   elif not control:
    assert bool(int(r['instrument_valid']))==(elapsed//100>=clock)
    a['batches'].append(elapsed);a['valid'] &= elapsed//100>=clock
   rows.append({'arm':arm,**r})
  for hkey,partrows in hierarchy.items():
   aggregate=[r for r in partrows if r['row_kind']=='sample'];raw=[r for r in partrows if r['row_kind']=='batch']
   assert len(aggregate)==1
   aggregate=aggregate[0];assert len(raw)==int(aggregate['batch_or_batches'])
   assert sorted(int(r['batch_or_batches']) for r in raw)==list(range(len(raw)))
   assert sum(int(r['elapsed_ns']) for r in raw)==int(aggregate['elapsed_ns'])
   assert sum(int(r['receipt']) for r in raw)%(1<<64)==int(aggregate['receipt'])
   checksum=0
   for r in raw:checksum^=int(r['cleanup_checksum'])
   assert checksum==int(aggregate['cleanup_checksum'])
   if hkey[-1]=='0':
    expected=int(aggregate['elapsed_ns'])>=1000000 and all(int(r['elapsed_ns'])//100>=clock for r in raw)
    assert bool(int(aggregate['instrument_valid']))==expected
    assert all(int(r['receipt'])==int(r['calls']) for r in raw)
  runs[label]['hierarchy_checks']=len(hierarchy)
result=[];table=[]
spread=lambda a,b:max(a,b)/min(a,b)-1
for key,g in sorted(groups.items()):
 series,width,size,path=key;c={'series':series,'element_bytes':width,'initial_floor':size,'path':path,'arms':{},'cohort_pairs':[]}
 med={}
 for arm in arms:
  c['arms'][arm]=[]
  for cohort in (0,1):
   pr={}
   for peer in peers:
    a=g[arm,cohort,peer];assert len(a['real'])==len(a['control'])==9
    pr[peer]={'median':statistics.median(a['real']),'min':min(a['real']),'max':max(a['real']),'minimum_real_sample_ns':min(a['sample_ns']),'minimum_batch_ns':min(a['batches']),'maximum_batch_ns':max(a['batches']),'instrument_pass':a['valid']}
    med[arm,cohort,peer]=pr[peer]['median']
   slow=max(peers[1:],key=lambda p:pr[p]['median']);wf=pr[peers[0]]
   directions={peer:('WF faster' if wf['max']<pr[peer]['min'] else 'WF slower' if wf['min']>pr[peer]['max'] else 'overlap') for peer in peers[1:]}
   c['arms'][arm].append({'cohort':cohort,'peers':pr,'selected_slower_peer':slow,'directions':directions,'raw_peer_target_pass':wf['max']<pr[slow]['min']})
 for cohort in (0,1):
  a=c['arms']['control'][cohort]['peers'][peers[0]];b=c['arms']['candidate'][cohort]['peers'][peers[0]]
  direction='gain' if b['max']<a['min'] else 'loss' if b['min']>a['max'] else 'overlap'
  drift={p:spread(med['control',cohort,p],med['candidate',cohort,p]) for p in peers[1:]}
  c['cohort_pairs'].append({'cohort':cohort,'direction':direction,'candidate_control_ratio':b['median']/a['median'],'unchanged_peer_drift':drift})
 c['cohort_spreads']={arm:{peer:spread(med[arm,0,peer],med[arm,1,peer]) for peer in peers} for arm in arms}
 c['paired_ratio_spread']=spread(*[x['candidate_control_ratio'] for x in c['cohort_pairs']])
 c['instrument_pass']=all(g[a,k,p]['valid'] for a in arms for k in (0,1) for p in peers)
 c['stability_pass']=c['paired_ratio_spread']<=.1 and all(v<=.1 for a in c['cohort_spreads'].values() for v in a.values()) and all(v<=.1 for a in c['cohort_pairs'] for v in a['unchanged_peer_drift'].values())
 c['issues']=[]
 for arm in arms:
  for peer in peers:
   if not all(g[arm,k,peer]['valid'] for k in (0,1)):c['issues'].append(arm+'/'+peer+':instrument')
   if c['cohort_spreads'][arm][peer]>.1:c['issues'].append(arm+'/'+peer+':cohort-drift')
 for pair in c['cohort_pairs']:
  for peer,drift in pair['unchanged_peer_drift'].items():
   if drift>.1:c['issues'].append('cohort'+str(pair['cohort'])+'/'+peer+':paired-drift')
 if c['paired_ratio_spread']>.1:c['issues'].append('wf-ratio-drift')
 c['qualified_gain']=c['instrument_pass'] and c['stability_pass'] and all(x['direction']=='gain' for x in c['cohort_pairs'])
 c['qualified_loss']=c['instrument_pass'] and c['stability_pass'] and all(x['direction']=='loss' for x in c['cohort_pairs'])
 c['candidate_peer_targets']={peer:{'raw_both_cohorts':all(c['arms']['candidate'][k]['directions'][peer]=='WF faster' for k in (0,1)),
     'qualified':c['instrument_pass'] and c['stability_pass'] and all(c['arms']['candidate'][k]['directions'][peer]=='WF faster' for k in (0,1))} for peer in peers[1:]}
 c['candidate_selected_peer_target']={'raw_both_cohorts':all(row['raw_peer_target_pass'] for row in c['arms']['candidate']),
     'qualified':c['instrument_pass'] and c['stability_pass'] and all(row['raw_peer_target_pass'] for row in c['arms']['candidate'])}
 c['verdict']='unqualified' if not(c['instrument_pass'] and c['stability_pass']) else 'gain' if c['qualified_gain'] else 'loss' if c['qualified_loss'] else 'overlap'
 c['primary']=series=='aligned-hash' and width==256 and path=='grow'
 result.append(c)
 table.append(f"{series} {width}B S{size} {path}: pair {[x['direction'] for x in c['cohort_pairs']]}; instrument={c['instrument_pass']}; stability={c['stability_pass']}; gain={c['qualified_gain']}; ratio spread={100*c['paired_ratio_spread']:.3f}%")
 for arm in arms:
  for row in c['arms'][arm]:
   pr=row['peers'];table.append('  '+arm+str(row['cohort'])+' '+ '; '.join(f"{p}: {pr[p]['median']:.3f} [{pr[p]['min']:.3f},{pr[p]['max']:.3f}]" for p in peers)+'; '+str(row['directions']))
summary={'rows':len(rows),'real_sample_rows':sum(r['row_kind']=='sample' and r['control']=='0' for r in rows),'runs':runs,'cells':result,'primary_both_qualified_gain':all(c['qualified_gain'] for c in result if c['primary']),'all_cell_instrument_pass':all(c['instrument_pass'] for c in result),'selection':'Generic constructor implementation with native collateral; no qualified growth benefit, all raw adverse observations retained'}
(D/'runtime-reduction.json').write_text(json.dumps(summary,indent=2)+'\n');(D/'runtime-reduction.txt').write_text('\n'.join(table)+'\n');print(json.dumps({'rows':len(rows),'primary':[{k:c[k] for k in ['initial_floor','cohort_pairs','instrument_pass','stability_pass','qualified_gain']} for c in result if c['primary']],'all_cell_instrument_pass':summary['all_cell_instrument_pass']},indent=2))

root=json.loads((D/'runtime-root-reduction.json').read_text());discrepancies=[]
lookup={(c['element_bytes'],c['series'],c['path'],c['initial_floor']):c for c in result}
assert root['rows']==summary['rows'] and root['hierarchy_checks']==sum(r['hierarchy_checks'] for r in runs.values())
for r in root['cells']:
 c=lookup[tuple(r['cell'])]
 if sorted(c['issues'])!=sorted(r['issues']):discrepancies.append([r['cell'],'issues',c['issues'],r['issues']])
 for direction,field in [('gain','gain_ranges'),('loss','loss_ranges')]:
  if all(pair['direction']==direction for pair in c['cohort_pairs'])!=r[field]:discrepancies.append([r['cell'],field])
 for field in ['verdict']:
  if c[field]!=r[field]:discrepancies.append([r['cell'],field,c[field],r[field]])
 for cohort in (0,1):
  if c['cohort_pairs'][cohort]['candidate_control_ratio']!=r['ratios'][cohort]:discrepancies.append([r['cell'],'ratio',cohort])
 for arm in arms:
  for cohort in (0,1):
   for peer in peers:
    a=c['arms'][arm][cohort]['peers'][peer];b=r['samples'][arm+str(cohort)+'/'+peer]
    for af,bf in [('median','median_ns'),('min','min_ns'),('max','max_ns'),('instrument_pass','instrument')]:
     if a[af]!=b[bf]:discrepancies.append([r['cell'],arm,cohort,peer,af,a[af],b[bf]])
comparison={'root_sha256':hashlib.sha256((D/'runtime-root-reduction.json').read_bytes()).hexdigest(),
 'rows':summary['rows'],'hierarchy_checks':sum(r['hierarchy_checks'] for r in runs.values()),'discrepancies':discrepancies,
 'input_sha256':{label:r['sha256'] for label,r in runs.items()}}
(D/'runtime-reduction-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
assert not discrepancies,discrepancies
print('Independent direct-three-peer reduction agrees with root on every range, median, ratio, instrument flag and cell verdict.')

primary=['Primary aligned-hash wide growth; all values ns/call. Raw, unqualified ranges.',
 'S | cohort | arm | WF median[min,max] | Rust median[min,max] | C++ median[min,max]']
for c in result:
 if not c['primary']:continue
 for k in (0,1):
  for arm in arms:
   row=c['arms'][arm][k]
   def fmt(peer):
    p=row['peers'][peer];return f"{p['median']:.6f}[{p['min']:.6f},{p['max']:.6f}]"
   primary.append(f"{c['initial_floor']} | {k} | {arm} | "+' | '.join(fmt(p) for p in peers))
 primary.append('  ratios='+str([x['candidate_control_ratio'] for x in c['cohort_pairs']])+'; issues='+str(c['issues'])+'; candidate_selected_peer_target='+str(c['candidate_selected_peer_target']))
(D/'runtime-primary-ranges.txt').write_text('\n'.join(primary)+'\n')
names=['runtime-reduce.py','runtime-reduction.json','runtime-reduction.txt','runtime-reduction-comparison.json','runtime-primary-ranges.txt']
(D/'runtime-reduction-pins.json').write_text(json.dumps({name:hashlib.sha256((D/name).read_bytes()).hexdigest() for name in names},indent=2)+'\n')
