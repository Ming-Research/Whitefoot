000000000000a870 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6>:
    a870: 3940206a     	ldrb	w10, [x3, #0x8]
    a874: f9400008     	ldr	x8, [x0]
    a878: b40001a8     	cbz	x8, 0xa8ac <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x3c>
    a87c: f9400809     	ldr	x9, [x0, #0x10]
    a880: 360001ca     	tbz	w10, #0x0, 0xa8b8 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x48>
    a884: d280000b     	mov	x11, #0x0               ; =0
    a888: aa0903ea     	mov	x10, x9
    a88c: b940014c     	ldr	w12, [x10]
    a890: 7100099f     	cmp	w12, #0x2
    a894: 54000523     	b.lo	0xa938 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0xc8>
    a898: 9100056b     	add	x11, x11, #0x1
    a89c: 9100614a     	add	x10, x10, #0x18
    a8a0: eb0b011f     	cmp	x8, x11
    a8a4: 54ffff41     	b.ne	0xa88c <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x1c>
    a8a8: 17fffff7     	b	0xa884 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x14>
    a8ac: 3600004a     	tbz	w10, #0x0, 0xa8b4 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x44>
    a8b0: 14000000     	b	0xa8b0 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x40>
    a8b4: 14000000     	b	0xa8b4 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x44>
    a8b8: f940006a     	ldr	x10, [x3]
    a8bc: ca01014a     	eor	x10, x10, x1
    a8c0: ca4a794a     	eor	x10, x10, x10, lsr #30
    a8c4: d29cb72b     	mov	x11, #0xe5b9            ; =58809
    a8c8: f2a39c8b     	movk	x11, #0x1ce4, lsl #16
    a8cc: f2c8edab     	movk	x11, #0x476d, lsl #32
    a8d0: f2f7eb0b     	movk	x11, #0xbf58, lsl #48
    a8d4: 9b0b7d4a     	mul	x10, x10, x11
    a8d8: ca4a6d4a     	eor	x10, x10, x10, lsr #27
    a8dc: d2823d6b     	mov	x11, #0x11eb            ; =4587
    a8e0: f2a2662b     	movk	x11, #0x1331, lsl #16
    a8e4: f2c9376b     	movk	x11, #0x49bb, lsl #32
    a8e8: f2f29a0b     	movk	x11, #0x94d0, lsl #48
    a8ec: 9b0b7d4a     	mul	x10, x10, x11
    a8f0: ca4a7d4a     	eor	x10, x10, x10, lsr #31
    a8f4: 9ac8094b     	udiv	x11, x10, x8
    a8f8: 9b08a96b     	msub	x11, x11, x8, x10
    a8fc: cb0b010c     	sub	x12, x8, x11
    a900: cb0c03ed     	neg	x13, x12
    a904: 5280030e     	mov	w14, #0x18              ; =24
    a908: d280000f     	mov	x15, #0x0               ; =0
    a90c: eb0c01ff     	cmp	x15, x12
    a910: 9a8d316a     	csel	x10, x11, x13, lo
    a914: 8b0f014a     	add	x10, x10, x15
    a918: 9b0e254a     	madd	x10, x10, x14, x9
    a91c: b9400150     	ldr	w16, [x10]
    a920: 71000a1f     	cmp	w16, #0x2
    a924: 540000a3     	b.lo	0xa938 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0xc8>
    a928: 910005ef     	add	x15, x15, #0x1
    a92c: eb0f011f     	cmp	x8, x15
    a930: 54fffee1     	b.ne	0xa90c <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x9c>
    a934: 17fffff5     	b	0xa908 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x98>
    a938: 52800048     	mov	w8, #0x2                ; =2
    a93c: b9000148     	str	w8, [x10]
    a940: a9008941     	stp	x1, x2, [x10, #0x8]
    a944: 52800000     	mov	w0, #0x0                ; =0
    a948: d65f03c0     	ret
