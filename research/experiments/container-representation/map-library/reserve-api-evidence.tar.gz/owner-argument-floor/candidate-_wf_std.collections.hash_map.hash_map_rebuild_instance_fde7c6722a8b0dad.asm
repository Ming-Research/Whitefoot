0000000000009b40 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad>:
    9b40: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    9b44: a90157f6     	stp	x22, x21, [sp, #0x10]
    9b48: a9024ff4     	stp	x20, x19, [sp, #0x20]
    9b4c: a9037bfd     	stp	x29, x30, [sp, #0x30]
    9b50: f140103f     	cmp	x1, #0x4, lsl #12       ; =0x4000
    9b54: 54000088     	b.hi	0x9b64 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x24>
    9b58: f9400014     	ldr	x20, [x0]
    9b5c: eb14003f     	cmp	x1, x20
    9b60: 54000122     	b.hs	0x9b84 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x44>
    9b64: 52800020     	mov	w0, #0x1                ; =1
    9b68: 52800001     	mov	w1, #0x0                ; =0
    9b6c: 52800002     	mov	w2, #0x0                ; =0
    9b70: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    9b74: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    9b78: a94157f6     	ldp	x22, x21, [sp, #0x10]
    9b7c: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    9b80: d65f03c0     	ret
    9b84: b40005a1     	cbz	x1, 0x9c38 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xf8>
    9b88: aa0003f3     	mov	x19, x0
    9b8c: f9400055     	ldr	x21, [x2]
    9b90: 39402056     	ldrb	w22, [x2, #0x8]
    9b94: aa0103f7     	mov	x23, x1
    9b98: 8b010428     	add	x8, x1, x1, lsl #1
    9b9c: d37df100     	lsl	x0, x8, #3
    9ba0: 94000000     	bl	0x9ba0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x60>
		0000000000009ba0:  ARM64_RELOC_BRANCH26	_malloc
    9ba4: b4000b40     	cbz	x0, 0x9d0c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1cc>
    9ba8: d2800009     	mov	x9, #0x0                ; =0
    9bac: 91002008     	add	x8, x0, #0x8
    9bb0: aa1303ea     	mov	x10, x19
    9bb4: aa1703ec     	mov	x12, x23
    9bb8: b81f811f     	stur	wzr, [x8, #-0x8]
    9bbc: 91000529     	add	x9, x9, #0x1
    9bc0: a881fd1f     	stp	xzr, xzr, [x8], #0x18
    9bc4: eb09019f     	cmp	x12, x9
    9bc8: 54ffff81     	b.ne	0x9bb8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x78>
    9bcc: a940a14b     	ldp	x11, x8, [x10, #0x8]
    9bd0: a900314c     	stp	x12, x12, [x10]
    9bd4: f9000940     	str	x0, [x10, #0x10]
    9bd8: b40008d4     	cbz	x20, 0x9cf0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1b0>
    9bdc: 36000336     	tbz	w22, #0x0, 0x9c40 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x100>
    9be0: 5280030c     	mov	w12, #0x18              ; =24
    9be4: 5280004d     	mov	w13, #0x2               ; =2
    9be8: 14000004     	b	0x9bf8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xb8>
    9bec: b90001ed     	str	w13, [x15]
    9bf0: 3c8081e0     	stur	q0, [x15, #0x8]
    9bf4: b40007f4     	cbz	x20, 0x9cf0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1b0>
    9bf8: d1000694     	sub	x20, x20, #0x1
    9bfc: 9b0c228e     	madd	x14, x20, x12, x8
    9c00: b94001cf     	ldr	w15, [x14]
    9c04: 710009ff     	cmp	w15, #0x2
    9c08: 54ffff63     	b.lo	0x9bf4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xb4>
    9c0c: 3cc081c0     	ldur	q0, [x14, #0x8]
    9c10: d280000e     	mov	x14, #0x0               ; =0
    9c14: aa0003ef     	mov	x15, x0
    9c18: b94001f0     	ldr	w16, [x15]
    9c1c: 71000a1f     	cmp	w16, #0x2
    9c20: 54fffe63     	b.lo	0x9bec <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xac>
    9c24: 910005ce     	add	x14, x14, #0x1
    9c28: 910061ef     	add	x15, x15, #0x18
    9c2c: eb0e013f     	cmp	x9, x14
    9c30: 54ffff41     	b.ne	0x9c18 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xd8>
    9c34: 17fffff7     	b	0x9c10 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xd0>
    9c38: 52800000     	mov	w0, #0x0                ; =0
    9c3c: 17ffffcb     	b	0x9b68 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x28>
    9c40: 5280030d     	mov	w13, #0x18              ; =24
    9c44: d29cb72e     	mov	x14, #0xe5b9            ; =58809
    9c48: f2a39c8e     	movk	x14, #0x1ce4, lsl #16
    9c4c: f2c8edae     	movk	x14, #0x476d, lsl #32
    9c50: f2f7eb0e     	movk	x14, #0xbf58, lsl #48
    9c54: d2823d6f     	mov	x15, #0x11eb            ; =4587
    9c58: f2a2662f     	movk	x15, #0x1331, lsl #16
    9c5c: f2c9376f     	movk	x15, #0x49bb, lsl #32
    9c60: f2f29a0f     	movk	x15, #0x94d0, lsl #48
    9c64: 52800050     	mov	w16, #0x2               ; =2
    9c68: 14000002     	b	0x9c70 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x130>
    9c6c: b4000434     	cbz	x20, 0x9cf0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1b0>
    9c70: d1000694     	sub	x20, x20, #0x1
    9c74: 9b0d2291     	madd	x17, x20, x13, x8
    9c78: b9400221     	ldr	w1, [x17]
    9c7c: 7100043f     	cmp	w1, #0x1
    9c80: 54ffff69     	b.ls	0x9c6c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x12c>
    9c84: 3cc08220     	ldur	q0, [x17, #0x8]
    9c88: f9400631     	ldr	x17, [x17, #0x8]
    9c8c: ca150231     	eor	x17, x17, x21
    9c90: ca517a31     	eor	x17, x17, x17, lsr #30
    9c94: 9b0e7e31     	mul	x17, x17, x14
    9c98: ca516e31     	eor	x17, x17, x17, lsr #27
    9c9c: 9b0f7e31     	mul	x17, x17, x15
    9ca0: ca517e31     	eor	x17, x17, x17, lsr #31
    9ca4: 9acc0a21     	udiv	x1, x17, x12
    9ca8: 9b0cc431     	msub	x17, x1, x12, x17
    9cac: cb110181     	sub	x1, x12, x17
    9cb0: cb0103e2     	neg	x2, x1
    9cb4: d2800003     	mov	x3, #0x0                ; =0
    9cb8: eb01007f     	cmp	x3, x1
    9cbc: 9a823224     	csel	x4, x17, x2, lo
    9cc0: 8b030084     	add	x4, x4, x3
    9cc4: 9b0d0084     	madd	x4, x4, x13, x0
    9cc8: b9400085     	ldr	w5, [x4]
    9ccc: 710004bf     	cmp	w5, #0x1
    9cd0: 540000a9     	b.ls	0x9ce4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1a4>
    9cd4: 91000463     	add	x3, x3, #0x1
    9cd8: eb03013f     	cmp	x9, x3
    9cdc: 54fffee1     	b.ne	0x9cb8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x178>
    9ce0: 17fffff5     	b	0x9cb4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x174>
    9ce4: b9000090     	str	w16, [x4]
    9ce8: 3c808080     	stur	q0, [x4, #0x8]
    9cec: b5fffc34     	cbnz	x20, 0x9c70 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x130>
    9cf0: b400008b     	cbz	x11, 0x9d00 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1c0>
    9cf4: aa0803e0     	mov	x0, x8
    9cf8: 94000000     	bl	0x9cf8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1b8>
		0000000000009cf8:  ARM64_RELOC_BRANCH26	_free
    9cfc: aa1303ea     	mov	x10, x19
    9d00: 52800000     	mov	w0, #0x0                ; =0
    9d04: f900115f     	str	xzr, [x10, #0x20]
    9d08: 17ffff98     	b	0x9b68 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x28>
    9d0c: 94000000     	bl	0x9d0c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1cc>
		0000000000009d0c:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
