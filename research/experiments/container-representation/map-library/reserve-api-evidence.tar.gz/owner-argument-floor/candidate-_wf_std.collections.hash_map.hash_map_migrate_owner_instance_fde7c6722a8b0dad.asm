000000000000a99c <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad>:
    a99c: 3940206a     	ldrb	w10, [x3, #0x8]
    a9a0: f9400008     	ldr	x8, [x0]
    a9a4: b40001a8     	cbz	x8, 0xa9d8 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x3c>
    a9a8: f9400809     	ldr	x9, [x0, #0x10]
    a9ac: 360001ca     	tbz	w10, #0x0, 0xa9e4 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x48>
    a9b0: d280000b     	mov	x11, #0x0               ; =0
    a9b4: aa0903ea     	mov	x10, x9
    a9b8: b940014c     	ldr	w12, [x10]
    a9bc: 7100099f     	cmp	w12, #0x2
    a9c0: 54000523     	b.lo	0xaa64 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0xc8>
    a9c4: 9100056b     	add	x11, x11, #0x1
    a9c8: 9100614a     	add	x10, x10, #0x18
    a9cc: eb0b011f     	cmp	x8, x11
    a9d0: 54ffff41     	b.ne	0xa9b8 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x1c>
    a9d4: 17fffff7     	b	0xa9b0 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x14>
    a9d8: 3600004a     	tbz	w10, #0x0, 0xa9e0 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x44>
    a9dc: 14000000     	b	0xa9dc <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x40>
    a9e0: 14000000     	b	0xa9e0 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x44>
    a9e4: f940006a     	ldr	x10, [x3]
    a9e8: ca01014a     	eor	x10, x10, x1
    a9ec: ca4a794a     	eor	x10, x10, x10, lsr #30
    a9f0: d29cb72b     	mov	x11, #0xe5b9            ; =58809
    a9f4: f2a39c8b     	movk	x11, #0x1ce4, lsl #16
    a9f8: f2c8edab     	movk	x11, #0x476d, lsl #32
    a9fc: f2f7eb0b     	movk	x11, #0xbf58, lsl #48
    aa00: 9b0b7d4a     	mul	x10, x10, x11
    aa04: ca4a6d4a     	eor	x10, x10, x10, lsr #27
    aa08: d2823d6b     	mov	x11, #0x11eb            ; =4587
    aa0c: f2a2662b     	movk	x11, #0x1331, lsl #16
    aa10: f2c9376b     	movk	x11, #0x49bb, lsl #32
    aa14: f2f29a0b     	movk	x11, #0x94d0, lsl #48
    aa18: 9b0b7d4a     	mul	x10, x10, x11
    aa1c: ca4a7d4a     	eor	x10, x10, x10, lsr #31
    aa20: 9ac8094b     	udiv	x11, x10, x8
    aa24: 9b08a96b     	msub	x11, x11, x8, x10
    aa28: cb0b010c     	sub	x12, x8, x11
    aa2c: cb0c03ed     	neg	x13, x12
    aa30: 5280030e     	mov	w14, #0x18              ; =24
    aa34: d280000f     	mov	x15, #0x0               ; =0
    aa38: eb0c01ff     	cmp	x15, x12
    aa3c: 9a8d316a     	csel	x10, x11, x13, lo
    aa40: 8b0f014a     	add	x10, x10, x15
    aa44: 9b0e254a     	madd	x10, x10, x14, x9
    aa48: b9400150     	ldr	w16, [x10]
    aa4c: 71000a1f     	cmp	w16, #0x2
    aa50: 540000a3     	b.lo	0xaa64 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0xc8>
    aa54: 910005ef     	add	x15, x15, #0x1
    aa58: eb0f011f     	cmp	x8, x15
    aa5c: 54fffee1     	b.ne	0xaa38 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x9c>
    aa60: 17fffff5     	b	0xaa34 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x98>
    aa64: 52800048     	mov	w8, #0x2                ; =2
    aa68: b9000148     	str	w8, [x10]
    aa6c: a9008941     	stp	x1, x2, [x10, #0x8]
    aa70: 52800000     	mov	w0, #0x0                ; =0
    aa74: d65f03c0     	ret
