from pathlib import Path
import subprocess,time,json,hashlib,os,sys
D=Path(__file__).resolve().parent;P=D.parent
assert os.environ.get('WHITEFOOT_CHECK_OWNER')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins=json.loads((D/'pins.json').read_text())
for path,h in pins.items():assert sha(Path(path))==h,'changedpin '+path
statuses=[]
for side,cohort in [('control',0),('candidate',0),('candidate',1),('control',1)]:
 label=side+str(cohort);args=[str(P/(side+'-timed')),'reserve-measure',str(cohort)];start=time.monotonic()
 with (D/(label+'.csv')).open('wb') as out,(D/(label+'.stderr')).open('wb') as err:
  p=subprocess.Popen(args,stdout=out,stderr=err);print(label+' pid='+str(p.pid),flush=True);rc=p.wait()
 row={'label':label,'argv':args,'pid':p.pid,'exit':rc,'wall_s':time.monotonic()-start};statuses.append(row);(D/(label+'-status.json')).write_text(json.dumps(row,indent=2)+'\n');(D/'statuses.json').write_text(json.dumps(statuses,indent=2)+'\n');print(json.dumps(row),flush=True)
for path,h in pins.items():assert sha(Path(path))==h,'changedpin '+path
(D/'postrun-pins.json').write_text(json.dumps({path:sha(Path(path)) for path in pins},indent=2)+'\n')
sys.exit(1 if any(s['exit'] for s in statuses) else 0)
