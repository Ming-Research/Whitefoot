00000000000096fc <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6>:
    96fc: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    9700: a90157f6     	stp	x22, x21, [sp, #0x10]
    9704: a9024ff4     	stp	x20, x19, [sp, #0x20]
    9708: a9037bfd     	stp	x29, x30, [sp, #0x30]
    970c: f1000c3f     	cmp	x1, #0x3
    9710: 54000088     	b.hi	0x9720 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x24>
    9714: f9400014     	ldr	x20, [x0]
    9718: eb14003f     	cmp	x1, x20
    971c: 54000122     	b.hs	0x9740 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x44>
    9720: 52800020     	mov	w0, #0x1                ; =1
    9724: 52800001     	mov	w1, #0x0                ; =0
    9728: 52800002     	mov	w2, #0x0                ; =0
    972c: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    9730: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    9734: a94157f6     	ldp	x22, x21, [sp, #0x10]
    9738: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    973c: d65f03c0     	ret
    9740: b40005a1     	cbz	x1, 0x97f4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xf8>
    9744: aa0003f3     	mov	x19, x0
    9748: f9400055     	ldr	x21, [x2]
    974c: 39402056     	ldrb	w22, [x2, #0x8]
    9750: aa0103f7     	mov	x23, x1
    9754: 8b010428     	add	x8, x1, x1, lsl #1
    9758: d37df100     	lsl	x0, x8, #3
    975c: 94000000     	bl	0x975c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x60>
		000000000000975c:  ARM64_RELOC_BRANCH26	_malloc
    9760: b4000b40     	cbz	x0, 0x98c8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1cc>
    9764: d2800009     	mov	x9, #0x0                ; =0
    9768: 91002008     	add	x8, x0, #0x8
    976c: aa1303ea     	mov	x10, x19
    9770: aa1703ec     	mov	x12, x23
    9774: b81f811f     	stur	wzr, [x8, #-0x8]
    9778: 91000529     	add	x9, x9, #0x1
    977c: a881fd1f     	stp	xzr, xzr, [x8], #0x18
    9780: eb09019f     	cmp	x12, x9
    9784: 54ffff81     	b.ne	0x9774 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x78>
    9788: a940a14b     	ldp	x11, x8, [x10, #0x8]
    978c: a900314c     	stp	x12, x12, [x10]
    9790: f9000940     	str	x0, [x10, #0x10]
    9794: b40008d4     	cbz	x20, 0x98ac <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1b0>
    9798: 36000336     	tbz	w22, #0x0, 0x97fc <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x100>
    979c: 5280030c     	mov	w12, #0x18              ; =24
    97a0: 5280004d     	mov	w13, #0x2               ; =2
    97a4: 14000004     	b	0x97b4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xb8>
    97a8: b90001ed     	str	w13, [x15]
    97ac: 3c8081e0     	stur	q0, [x15, #0x8]
    97b0: b40007f4     	cbz	x20, 0x98ac <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1b0>
    97b4: d1000694     	sub	x20, x20, #0x1
    97b8: 9b0c228e     	madd	x14, x20, x12, x8
    97bc: b94001cf     	ldr	w15, [x14]
    97c0: 710009ff     	cmp	w15, #0x2
    97c4: 54ffff63     	b.lo	0x97b0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xb4>
    97c8: 3cc081c0     	ldur	q0, [x14, #0x8]
    97cc: d280000e     	mov	x14, #0x0               ; =0
    97d0: aa0003ef     	mov	x15, x0
    97d4: b94001f0     	ldr	w16, [x15]
    97d8: 71000a1f     	cmp	w16, #0x2
    97dc: 54fffe63     	b.lo	0x97a8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xac>
    97e0: 910005ce     	add	x14, x14, #0x1
    97e4: 910061ef     	add	x15, x15, #0x18
    97e8: eb0e013f     	cmp	x9, x14
    97ec: 54ffff41     	b.ne	0x97d4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xd8>
    97f0: 17fffff7     	b	0x97cc <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xd0>
    97f4: 52800000     	mov	w0, #0x0                ; =0
    97f8: 17ffffcb     	b	0x9724 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x28>
    97fc: 5280030d     	mov	w13, #0x18              ; =24
    9800: d29cb72e     	mov	x14, #0xe5b9            ; =58809
    9804: f2a39c8e     	movk	x14, #0x1ce4, lsl #16
    9808: f2c8edae     	movk	x14, #0x476d, lsl #32
    980c: f2f7eb0e     	movk	x14, #0xbf58, lsl #48
    9810: d2823d6f     	mov	x15, #0x11eb            ; =4587
    9814: f2a2662f     	movk	x15, #0x1331, lsl #16
    9818: f2c9376f     	movk	x15, #0x49bb, lsl #32
    981c: f2f29a0f     	movk	x15, #0x94d0, lsl #48
    9820: 52800050     	mov	w16, #0x2               ; =2
    9824: 14000002     	b	0x982c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x130>
    9828: b4000434     	cbz	x20, 0x98ac <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1b0>
    982c: d1000694     	sub	x20, x20, #0x1
    9830: 9b0d2291     	madd	x17, x20, x13, x8
    9834: b9400221     	ldr	w1, [x17]
    9838: 7100043f     	cmp	w1, #0x1
    983c: 54ffff69     	b.ls	0x9828 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x12c>
    9840: 3cc08220     	ldur	q0, [x17, #0x8]
    9844: f9400631     	ldr	x17, [x17, #0x8]
    9848: ca150231     	eor	x17, x17, x21
    984c: ca517a31     	eor	x17, x17, x17, lsr #30
    9850: 9b0e7e31     	mul	x17, x17, x14
    9854: ca516e31     	eor	x17, x17, x17, lsr #27
    9858: 9b0f7e31     	mul	x17, x17, x15
    985c: ca517e31     	eor	x17, x17, x17, lsr #31
    9860: 9acc0a21     	udiv	x1, x17, x12
    9864: 9b0cc431     	msub	x17, x1, x12, x17
    9868: cb110181     	sub	x1, x12, x17
    986c: cb0103e2     	neg	x2, x1
    9870: d2800003     	mov	x3, #0x0                ; =0
    9874: eb01007f     	cmp	x3, x1
    9878: 9a823224     	csel	x4, x17, x2, lo
    987c: 8b030084     	add	x4, x4, x3
    9880: 9b0d0084     	madd	x4, x4, x13, x0
    9884: b9400085     	ldr	w5, [x4]
    9888: 710004bf     	cmp	w5, #0x1
    988c: 540000a9     	b.ls	0x98a0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1a4>
    9890: 91000463     	add	x3, x3, #0x1
    9894: eb03013f     	cmp	x9, x3
    9898: 54fffee1     	b.ne	0x9874 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x178>
    989c: 17fffff5     	b	0x9870 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x174>
    98a0: b9000090     	str	w16, [x4]
    98a4: 3c808080     	stur	q0, [x4, #0x8]
    98a8: b5fffc34     	cbnz	x20, 0x982c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x130>
    98ac: b400008b     	cbz	x11, 0x98bc <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1c0>
    98b0: aa0803e0     	mov	x0, x8
    98b4: 94000000     	bl	0x98b4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1b8>
		00000000000098b4:  ARM64_RELOC_BRANCH26	_free
    98b8: aa1303ea     	mov	x10, x19
    98bc: 52800000     	mov	w0, #0x0                ; =0
    98c0: f900115f     	str	xzr, [x10, #0x20]
    98c4: 17ffff98     	b	0x9724 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x28>
    98c8: 94000000     	bl	0x98c8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1cc>
		00000000000098c8:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
