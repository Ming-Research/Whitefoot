000000000000a83c <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6>:
    a83c: 3940206a     	ldrb	w10, [x3, #0x8]
    a840: f9400008     	ldr	x8, [x0]
    a844: b40001a8     	cbz	x8, 0xa878 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x3c>
    a848: f9400809     	ldr	x9, [x0, #0x10]
    a84c: 360001ca     	tbz	w10, #0x0, 0xa884 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x48>
    a850: d280000b     	mov	x11, #0x0               ; =0
    a854: aa0903ea     	mov	x10, x9
    a858: b940014c     	ldr	w12, [x10]
    a85c: 7100099f     	cmp	w12, #0x2
    a860: 54000523     	b.lo	0xa904 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0xc8>
    a864: 9100056b     	add	x11, x11, #0x1
    a868: 9100614a     	add	x10, x10, #0x18
    a86c: eb0b011f     	cmp	x8, x11
    a870: 54ffff41     	b.ne	0xa858 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x1c>
    a874: 17fffff7     	b	0xa850 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x14>
    a878: 3600004a     	tbz	w10, #0x0, 0xa880 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x44>
    a87c: 14000000     	b	0xa87c <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x40>
    a880: 14000000     	b	0xa880 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x44>
    a884: f940006a     	ldr	x10, [x3]
    a888: ca01014a     	eor	x10, x10, x1
    a88c: ca4a794a     	eor	x10, x10, x10, lsr #30
    a890: d29cb72b     	mov	x11, #0xe5b9            ; =58809
    a894: f2a39c8b     	movk	x11, #0x1ce4, lsl #16
    a898: f2c8edab     	movk	x11, #0x476d, lsl #32
    a89c: f2f7eb0b     	movk	x11, #0xbf58, lsl #48
    a8a0: 9b0b7d4a     	mul	x10, x10, x11
    a8a4: ca4a6d4a     	eor	x10, x10, x10, lsr #27
    a8a8: d2823d6b     	mov	x11, #0x11eb            ; =4587
    a8ac: f2a2662b     	movk	x11, #0x1331, lsl #16
    a8b0: f2c9376b     	movk	x11, #0x49bb, lsl #32
    a8b4: f2f29a0b     	movk	x11, #0x94d0, lsl #48
    a8b8: 9b0b7d4a     	mul	x10, x10, x11
    a8bc: ca4a7d4a     	eor	x10, x10, x10, lsr #31
    a8c0: 9ac8094b     	udiv	x11, x10, x8
    a8c4: 9b08a96b     	msub	x11, x11, x8, x10
    a8c8: cb0b010c     	sub	x12, x8, x11
    a8cc: cb0c03ed     	neg	x13, x12
    a8d0: 5280030e     	mov	w14, #0x18              ; =24
    a8d4: d280000f     	mov	x15, #0x0               ; =0
    a8d8: eb0c01ff     	cmp	x15, x12
    a8dc: 9a8d316a     	csel	x10, x11, x13, lo
    a8e0: 8b0f014a     	add	x10, x10, x15
    a8e4: 9b0e254a     	madd	x10, x10, x14, x9
    a8e8: b9400150     	ldr	w16, [x10]
    a8ec: 71000a1f     	cmp	w16, #0x2
    a8f0: 540000a3     	b.lo	0xa904 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0xc8>
    a8f4: 910005ef     	add	x15, x15, #0x1
    a8f8: eb0f011f     	cmp	x8, x15
    a8fc: 54fffee1     	b.ne	0xa8d8 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x9c>
    a900: 17fffff5     	b	0xa8d4 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$c7b22b9ef52855b6+0x98>
    a904: 52800048     	mov	w8, #0x2                ; =2
    a908: b9000148     	str	w8, [x10]
    a90c: a9008941     	stp	x1, x2, [x10, #0x8]
    a910: 52800000     	mov	w0, #0x0                ; =0
    a914: d65f03c0     	ret
