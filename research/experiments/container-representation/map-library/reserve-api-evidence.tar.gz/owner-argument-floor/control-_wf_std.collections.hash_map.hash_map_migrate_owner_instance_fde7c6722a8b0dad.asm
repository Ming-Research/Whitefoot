000000000000a9d0 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad>:
    a9d0: 3940206a     	ldrb	w10, [x3, #0x8]
    a9d4: f9400008     	ldr	x8, [x0]
    a9d8: b40001a8     	cbz	x8, 0xaa0c <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x3c>
    a9dc: f9400809     	ldr	x9, [x0, #0x10]
    a9e0: 360001ca     	tbz	w10, #0x0, 0xaa18 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x48>
    a9e4: d280000b     	mov	x11, #0x0               ; =0
    a9e8: aa0903ea     	mov	x10, x9
    a9ec: b940014c     	ldr	w12, [x10]
    a9f0: 7100099f     	cmp	w12, #0x2
    a9f4: 54000523     	b.lo	0xaa98 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0xc8>
    a9f8: 9100056b     	add	x11, x11, #0x1
    a9fc: 9100614a     	add	x10, x10, #0x18
    aa00: eb0b011f     	cmp	x8, x11
    aa04: 54ffff41     	b.ne	0xa9ec <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x1c>
    aa08: 17fffff7     	b	0xa9e4 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x14>
    aa0c: 3600004a     	tbz	w10, #0x0, 0xaa14 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x44>
    aa10: 14000000     	b	0xaa10 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x40>
    aa14: 14000000     	b	0xaa14 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x44>
    aa18: f940006a     	ldr	x10, [x3]
    aa1c: ca01014a     	eor	x10, x10, x1
    aa20: ca4a794a     	eor	x10, x10, x10, lsr #30
    aa24: d29cb72b     	mov	x11, #0xe5b9            ; =58809
    aa28: f2a39c8b     	movk	x11, #0x1ce4, lsl #16
    aa2c: f2c8edab     	movk	x11, #0x476d, lsl #32
    aa30: f2f7eb0b     	movk	x11, #0xbf58, lsl #48
    aa34: 9b0b7d4a     	mul	x10, x10, x11
    aa38: ca4a6d4a     	eor	x10, x10, x10, lsr #27
    aa3c: d2823d6b     	mov	x11, #0x11eb            ; =4587
    aa40: f2a2662b     	movk	x11, #0x1331, lsl #16
    aa44: f2c9376b     	movk	x11, #0x49bb, lsl #32
    aa48: f2f29a0b     	movk	x11, #0x94d0, lsl #48
    aa4c: 9b0b7d4a     	mul	x10, x10, x11
    aa50: ca4a7d4a     	eor	x10, x10, x10, lsr #31
    aa54: 9ac8094b     	udiv	x11, x10, x8
    aa58: 9b08a96b     	msub	x11, x11, x8, x10
    aa5c: cb0b010c     	sub	x12, x8, x11
    aa60: cb0c03ed     	neg	x13, x12
    aa64: 5280030e     	mov	w14, #0x18              ; =24
    aa68: d280000f     	mov	x15, #0x0               ; =0
    aa6c: eb0c01ff     	cmp	x15, x12
    aa70: 9a8d316a     	csel	x10, x11, x13, lo
    aa74: 8b0f014a     	add	x10, x10, x15
    aa78: 9b0e254a     	madd	x10, x10, x14, x9
    aa7c: b9400150     	ldr	w16, [x10]
    aa80: 71000a1f     	cmp	w16, #0x2
    aa84: 540000a3     	b.lo	0xaa98 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0xc8>
    aa88: 910005ef     	add	x15, x15, #0x1
    aa8c: eb0f011f     	cmp	x8, x15
    aa90: 54fffee1     	b.ne	0xaa6c <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x9c>
    aa94: 17fffff5     	b	0xaa68 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$fde7c6722a8b0dad+0x98>
    aa98: 52800048     	mov	w8, #0x2                ; =2
    aa9c: b9000148     	str	w8, [x10]
    aaa0: a9008941     	stp	x1, x2, [x10, #0x8]
    aaa4: 52800000     	mov	w0, #0x0                ; =0
    aaa8: d65f03c0     	ret
