define internal void @wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  %wf.slot.1 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.2 = alloca { i64, i64, ptr }, align 8
  %v29 = alloca { i64, i64, ptr }, align 8
  %v3 = select i1 true, i64 16384, i64 16384
  %v4 = icmp ugt i64 %v1, %v3
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb3 ]
  %v7 = phi ptr [ %v2, %bb3 ]
  %t0 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v5, i32 0, i32 0
  %v10 = getelementptr i8, ptr %t0, i64 0
  %v11 = getelementptr i8, ptr %v10, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v11, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v12 = add i64 %t1, 0
  %v13 = icmp ult i64 %v6, %v12
  switch i1 %v13, label %invalid.tag.b1 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v8 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t3 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t3
  %t4 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v8, ptr %t4
  ret void
bb3:
  br label %bb1
bb4:
  %v14 = phi ptr [ %v5, %bb6 ]
  %v15 = phi i64 [ %v6, %bb6 ]
  %v16 = phi ptr [ %v7, %bb6 ]
  %v17 = phi i64 [ %v12, %bb6 ]
  %v20 = select i1 true, i64 0, i64 0
  %v21 = icmp eq i64 %v15, %v20
  switch i1 %v21, label %invalid.tag.b4 [
    i1 1, label %bb8
    i1 0, label %bb9
  ]
invalid.tag.b4:
  unreachable
bb5:
  %v18 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t5 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t5
  %t6 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v18, ptr %t6
  ret void
bb6:
  br label %bb4
bb7:
  %v22 = phi ptr [ %v14, %bb9 ]
  %v23 = phi i64 [ %v15, %bb9 ]
  %v24 = phi ptr [ %v16, %bb9 ]
  %v25 = phi i64 [ %v17, %bb9 ]
  %v28 = call { i64, i64, ptr } @wf_box_slots_new$instance$9eabc50a9cce2251(i64 %v23)
  store { i64, i64, ptr } %v28, ptr %v29
  %v30 = call i8 @wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374(ptr %v29, i64 %v23)
  %t7 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v22, i32 0, i32 0
  %v31 = getelementptr i8, ptr %t7, i64 0
  %v32 = call i8 @wf_swap$instance$d692d011b23a4a18(ptr %v31, ptr %v29)
  br label %bb10
bb8:
  %v26 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t8 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t8
  %t9 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v26, ptr %t9
  ret void
bb9:
  br label %bb7
bb10:
  %v33 = phi ptr [ %v22, %bb7 ], [ %v54, %bb15 ]
  %v34 = phi i64 [ %v23, %bb7 ], [ %v55, %bb15 ]
  %v35 = phi ptr [ %v24, %bb7 ], [ %v56, %bb15 ]
  %v36 = phi i64 [ %v25, %bb7 ], [ %v57, %bb15 ]
  %v37 = phi ptr [ %v29, %bb7 ], [ %v58, %bb15 ]
  %v43 = getelementptr i8, ptr %v37, i64 0
  %t11 = getelementptr inbounds { i64, i64, ptr }, ptr %v43, i32 0, i32 0
  %t10 = load i64, ptr %t11
  %v44 = add i64 %t10, 0
  %v45 = select i1 true, i64 0, i64 0
  %v46 = icmp eq i64 %v44, %v45
  switch i1 %v46, label %invalid.tag.b10 [
    i1 1, label %bb13
    i1 0, label %bb14
  ]
invalid.tag.b10:
  unreachable
bb11:
  %v38 = phi ptr [ %v33, %bb13 ]
  %v39 = phi i64 [ %v34, %bb13 ]
  %v40 = phi ptr [ %v35, %bb13 ]
  %v41 = phi i64 [ %v36, %bb13 ]
  %v42 = phi ptr [ %v37, %bb13 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %v42, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  %v64 = call i8 @wf_free_empty$instance$d692d011b23a4a18(ptr %wf.slot.2)
  %t12 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v38, i32 0, i32 2
  %v65 = getelementptr i8, ptr %t12, i64 0
  %v66 = select i1 true, i64 0, i64 0
  store i64 %v66, ptr %v65
  %v67 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t13 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t13
  %t14 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v67, ptr %t14
  ret void
bb12:
  %v47 = phi ptr [ %v33, %bb14 ]
  %v48 = phi i64 [ %v34, %bb14 ]
  %v49 = phi ptr [ %v35, %bb14 ]
  %v50 = phi i64 [ %v36, %bb14 ]
  %v51 = phi ptr [ %v37, %bb14 ]
  %v52 = getelementptr i8, ptr %v51, i64 0
  %floor.owner.data.slot = getelementptr { i64, i64, ptr }, ptr %v52, i32 0, i32 2
  %floor.owner.data = load ptr, ptr %floor.owner.data.slot
  %floor.owner.index = sub i64 %v44, 1
  %floor.owner.element = getelementptr %wf.t.dceb7b9db1c9ad1d, ptr %floor.owner.data, i64 %floor.owner.index
  %floor.owner.payload = getelementptr %wf.t.dceb7b9db1c9ad1d, ptr %floor.owner.element, i32 0, i32 2
  call void @wf_take_back$instance$d5bb00f00cd669fb(ptr %wf.slot.0, ptr %v52)
  %t15 = load %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.0
  %t16 = extractvalue %wf.t.dceb7b9db1c9ad1d %t15, 0
  switch i32 %t16, label %invalid.tag.b12 [
    i32 0, label %bb16
    i32 1, label %bb17
    i32 2, label %bb18
  ]
invalid.tag.b12:
  unreachable
bb13:
  br label %bb11
bb14:
  br label %bb12
bb15:
  %v54 = phi ptr [ %v47, %bb16 ], [ %v47, %bb17 ], [ %v47, %bb18 ]
  %v55 = phi i64 [ %v48, %bb16 ], [ %v48, %bb17 ], [ %v48, %bb18 ]
  %v56 = phi ptr [ %v49, %bb16 ], [ %v49, %bb17 ], [ %v49, %bb18 ]
  %v57 = phi i64 [ %v50, %bb16 ], [ %v50, %bb17 ], [ %v50, %bb18 ]
  %v58 = phi ptr [ %v51, %bb16 ], [ %v51, %bb17 ], [ %v51, %bb18 ]
  br label %bb10
bb16:
  br label %bb15
bb17:
  br label %bb15
bb18:
  %t17 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.0, i32 0, i32 1
  %v60 = load i64, ptr %t17
  %v62 = call i8 @wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65(ptr %v47, i64 %v60, ptr %floor.owner.payload, ptr %v49)
  br label %bb15
}
