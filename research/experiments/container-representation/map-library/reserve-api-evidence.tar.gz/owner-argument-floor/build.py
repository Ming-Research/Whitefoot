from pathlib import Path
import subprocess,time,json,hashlib,os
D=Path(__file__).resolve().parent
assert os.environ.get('WHITEFOOT_CHECK_OWNER')
records=[]
for side in ('control','candidate'):
 for stage,args in [('native',['clang','-O3','-Wno-override-module','-c',str(D/(side+'.ll')),'-o',str(D/(side+'.o'))]),('disassembly',['<llvm-root>/bin/llvm-objdump','--disassemble','--reloc',str(D/(side+'.o'))])]:
  name=side+'-'+stage;t=time.monotonic()
  with (D/(name+'.stdout')).open('wb') as out,(D/(name+'.stderr')).open('wb') as err:p=subprocess.run(args,stdout=out,stderr=err)
  rec={'stage':name,'argv':args,'exit':p.returncode,'wall_s':time.monotonic()-t};records.append(rec);(D/'build-statuses.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(rec),flush=True)
  if p.returncode:raise SystemExit(p.returncode)
pins={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in D.iterdir() if p.is_file() and p.suffix in ('.ll','.o','.patch','.txt','.py')}
(D/'native-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
