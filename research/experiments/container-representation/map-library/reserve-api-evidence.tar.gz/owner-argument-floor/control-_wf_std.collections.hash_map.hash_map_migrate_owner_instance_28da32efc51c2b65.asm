000000000000ad5c <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65>:
    ad5c: 3940206a     	ldrb	w10, [x3, #0x8]
    ad60: f9400008     	ldr	x8, [x0]
    ad64: b40002a8     	cbz	x8, 0xadb8 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65+0x5c>
    ad68: ad400440     	ldp	q0, q1, [x2]
    ad6c: ad410c42     	ldp	q2, q3, [x2, #0x20]
    ad70: ad421444     	ldp	q4, q5, [x2, #0x40]
    ad74: ad431c46     	ldp	q6, q7, [x2, #0x60]
    ad78: ad444450     	ldp	q16, q17, [x2, #0x80]
    ad7c: ad454c52     	ldp	q18, q19, [x2, #0xa0]
    ad80: ad465454     	ldp	q20, q21, [x2, #0xc0]
    ad84: ad475c56     	ldp	q22, q23, [x2, #0xe0]
    ad88: f9400809     	ldr	x9, [x0, #0x10]
    ad8c: 360001ca     	tbz	w10, #0x0, 0xadc4 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65+0x68>
    ad90: d280000b     	mov	x11, #0x0               ; =0
    ad94: aa0903ea     	mov	x10, x9
    ad98: b940014c     	ldr	w12, [x10]
    ad9c: 7100099f     	cmp	w12, #0x2
    ada0: 54000523     	b.lo	0xae44 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65+0xe8>
    ada4: 9100056b     	add	x11, x11, #0x1
    ada8: 9104414a     	add	x10, x10, #0x110
    adac: eb0b011f     	cmp	x8, x11
    adb0: 54ffff41     	b.ne	0xad98 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65+0x3c>
    adb4: 17fffff7     	b	0xad90 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65+0x34>
    adb8: 3600004a     	tbz	w10, #0x0, 0xadc0 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65+0x64>
    adbc: 14000000     	b	0xadbc <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65+0x60>
    adc0: 14000000     	b	0xadc0 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65+0x64>
    adc4: f940006a     	ldr	x10, [x3]
    adc8: ca01014a     	eor	x10, x10, x1
    adcc: ca4a794a     	eor	x10, x10, x10, lsr #30
    add0: d29cb72b     	mov	x11, #0xe5b9            ; =58809
    add4: f2a39c8b     	movk	x11, #0x1ce4, lsl #16
    add8: f2c8edab     	movk	x11, #0x476d, lsl #32
    addc: f2f7eb0b     	movk	x11, #0xbf58, lsl #48
    ade0: 9b0b7d4a     	mul	x10, x10, x11
    ade4: ca4a6d4a     	eor	x10, x10, x10, lsr #27
    ade8: d2823d6b     	mov	x11, #0x11eb            ; =4587
    adec: f2a2662b     	movk	x11, #0x1331, lsl #16
    adf0: f2c9376b     	movk	x11, #0x49bb, lsl #32
    adf4: f2f29a0b     	movk	x11, #0x94d0, lsl #48
    adf8: 9b0b7d4a     	mul	x10, x10, x11
    adfc: ca4a7d4a     	eor	x10, x10, x10, lsr #31
    ae00: 9ac8094b     	udiv	x11, x10, x8
    ae04: 9b08a96b     	msub	x11, x11, x8, x10
    ae08: cb0b010c     	sub	x12, x8, x11
    ae0c: cb0c03ed     	neg	x13, x12
    ae10: 5280220e     	mov	w14, #0x110             ; =272
    ae14: d280000f     	mov	x15, #0x0               ; =0
    ae18: eb0c01ff     	cmp	x15, x12
    ae1c: 9a8d316a     	csel	x10, x11, x13, lo
    ae20: 8b0f014a     	add	x10, x10, x15
    ae24: 9b0e254a     	madd	x10, x10, x14, x9
    ae28: b9400150     	ldr	w16, [x10]
    ae2c: 71000a1f     	cmp	w16, #0x2
    ae30: 540000a3     	b.lo	0xae44 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65+0xe8>
    ae34: 910005ef     	add	x15, x15, #0x1
    ae38: eb0f011f     	cmp	x8, x15
    ae3c: 54fffee1     	b.ne	0xae18 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65+0xbc>
    ae40: 17fffff5     	b	0xae14 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65+0xb8>
    ae44: 52800048     	mov	w8, #0x2                ; =2
    ae48: b9000148     	str	w8, [x10]
    ae4c: f9000541     	str	x1, [x10, #0x8]
    ae50: ad008540     	stp	q0, q1, [x10, #0x10]
    ae54: ad018d42     	stp	q2, q3, [x10, #0x30]
    ae58: ad029544     	stp	q4, q5, [x10, #0x50]
    ae5c: ad039d46     	stp	q6, q7, [x10, #0x70]
    ae60: ad04c550     	stp	q16, q17, [x10, #0x90]
    ae64: ad05cd52     	stp	q18, q19, [x10, #0xb0]
    ae68: ad06d554     	stp	q20, q21, [x10, #0xd0]
    ae6c: ad07dd56     	stp	q22, q23, [x10, #0xf0]
    ae70: 52800000     	mov	w0, #0x0                ; =0
    ae74: d65f03c0     	ret
