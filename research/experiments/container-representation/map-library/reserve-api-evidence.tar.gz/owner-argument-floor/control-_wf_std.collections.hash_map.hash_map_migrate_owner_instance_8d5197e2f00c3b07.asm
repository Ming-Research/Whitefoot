000000000000aaac <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07>:
    aaac: 3940206a     	ldrb	w10, [x3, #0x8]
    aab0: f9400008     	ldr	x8, [x0]
    aab4: b40002a8     	cbz	x8, 0xab08 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0x5c>
    aab8: ad400440     	ldp	q0, q1, [x2]
    aabc: ad410c42     	ldp	q2, q3, [x2, #0x20]
    aac0: ad421444     	ldp	q4, q5, [x2, #0x40]
    aac4: ad431c46     	ldp	q6, q7, [x2, #0x60]
    aac8: ad444450     	ldp	q16, q17, [x2, #0x80]
    aacc: ad454c52     	ldp	q18, q19, [x2, #0xa0]
    aad0: ad465454     	ldp	q20, q21, [x2, #0xc0]
    aad4: ad475c56     	ldp	q22, q23, [x2, #0xe0]
    aad8: f9400809     	ldr	x9, [x0, #0x10]
    aadc: 360001ca     	tbz	w10, #0x0, 0xab14 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0x68>
    aae0: d280000b     	mov	x11, #0x0               ; =0
    aae4: aa0903ea     	mov	x10, x9
    aae8: b940014c     	ldr	w12, [x10]
    aaec: 7100099f     	cmp	w12, #0x2
    aaf0: 54000523     	b.lo	0xab94 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0xe8>
    aaf4: 9100056b     	add	x11, x11, #0x1
    aaf8: 9104414a     	add	x10, x10, #0x110
    aafc: eb0b011f     	cmp	x8, x11
    ab00: 54ffff41     	b.ne	0xaae8 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0x3c>
    ab04: 17fffff7     	b	0xaae0 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0x34>
    ab08: 3600004a     	tbz	w10, #0x0, 0xab10 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0x64>
    ab0c: 14000000     	b	0xab0c <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0x60>
    ab10: 14000000     	b	0xab10 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0x64>
    ab14: f940006a     	ldr	x10, [x3]
    ab18: ca01014a     	eor	x10, x10, x1
    ab1c: ca4a794a     	eor	x10, x10, x10, lsr #30
    ab20: d29cb72b     	mov	x11, #0xe5b9            ; =58809
    ab24: f2a39c8b     	movk	x11, #0x1ce4, lsl #16
    ab28: f2c8edab     	movk	x11, #0x476d, lsl #32
    ab2c: f2f7eb0b     	movk	x11, #0xbf58, lsl #48
    ab30: 9b0b7d4a     	mul	x10, x10, x11
    ab34: ca4a6d4a     	eor	x10, x10, x10, lsr #27
    ab38: d2823d6b     	mov	x11, #0x11eb            ; =4587
    ab3c: f2a2662b     	movk	x11, #0x1331, lsl #16
    ab40: f2c9376b     	movk	x11, #0x49bb, lsl #32
    ab44: f2f29a0b     	movk	x11, #0x94d0, lsl #48
    ab48: 9b0b7d4a     	mul	x10, x10, x11
    ab4c: ca4a7d4a     	eor	x10, x10, x10, lsr #31
    ab50: 9ac8094b     	udiv	x11, x10, x8
    ab54: 9b08a96b     	msub	x11, x11, x8, x10
    ab58: cb0b010c     	sub	x12, x8, x11
    ab5c: cb0c03ed     	neg	x13, x12
    ab60: 5280220e     	mov	w14, #0x110             ; =272
    ab64: d280000f     	mov	x15, #0x0               ; =0
    ab68: eb0c01ff     	cmp	x15, x12
    ab6c: 9a8d316a     	csel	x10, x11, x13, lo
    ab70: 8b0f014a     	add	x10, x10, x15
    ab74: 9b0e254a     	madd	x10, x10, x14, x9
    ab78: b9400150     	ldr	w16, [x10]
    ab7c: 71000a1f     	cmp	w16, #0x2
    ab80: 540000a3     	b.lo	0xab94 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0xe8>
    ab84: 910005ef     	add	x15, x15, #0x1
    ab88: eb0f011f     	cmp	x8, x15
    ab8c: 54fffee1     	b.ne	0xab68 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0xbc>
    ab90: 17fffff5     	b	0xab64 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0xb8>
    ab94: 52800048     	mov	w8, #0x2                ; =2
    ab98: b9000148     	str	w8, [x10]
    ab9c: f9000541     	str	x1, [x10, #0x8]
    aba0: ad008540     	stp	q0, q1, [x10, #0x10]
    aba4: ad018d42     	stp	q2, q3, [x10, #0x30]
    aba8: ad029544     	stp	q4, q5, [x10, #0x50]
    abac: ad039d46     	stp	q6, q7, [x10, #0x70]
    abb0: ad04c550     	stp	q16, q17, [x10, #0x90]
    abb4: ad05cd52     	stp	q18, q19, [x10, #0xb0]
    abb8: ad06d554     	stp	q20, q21, [x10, #0xd0]
    abbc: ad07dd56     	stp	q22, q23, [x10, #0xf0]
    abc0: 52800000     	mov	w0, #0x0                ; =0
    abc4: d65f03c0     	ret
