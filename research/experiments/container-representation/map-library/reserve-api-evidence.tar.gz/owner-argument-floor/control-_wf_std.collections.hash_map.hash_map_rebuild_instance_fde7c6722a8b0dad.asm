0000000000009b24 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad>:
    9b24: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    9b28: a90157f6     	stp	x22, x21, [sp, #0x10]
    9b2c: a9024ff4     	stp	x20, x19, [sp, #0x20]
    9b30: a9037bfd     	stp	x29, x30, [sp, #0x30]
    9b34: f140103f     	cmp	x1, #0x4, lsl #12       ; =0x4000
    9b38: 54000088     	b.hi	0x9b48 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x24>
    9b3c: f9400014     	ldr	x20, [x0]
    9b40: eb14003f     	cmp	x1, x20
    9b44: 54000122     	b.hs	0x9b68 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x44>
    9b48: 52800020     	mov	w0, #0x1                ; =1
    9b4c: 52800001     	mov	w1, #0x0                ; =0
    9b50: 52800002     	mov	w2, #0x0                ; =0
    9b54: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    9b58: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    9b5c: a94157f6     	ldp	x22, x21, [sp, #0x10]
    9b60: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    9b64: d65f03c0     	ret
    9b68: b40005a1     	cbz	x1, 0x9c1c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xf8>
    9b6c: aa0003f3     	mov	x19, x0
    9b70: f9400055     	ldr	x21, [x2]
    9b74: 39402056     	ldrb	w22, [x2, #0x8]
    9b78: aa0103f7     	mov	x23, x1
    9b7c: 8b010428     	add	x8, x1, x1, lsl #1
    9b80: d37df100     	lsl	x0, x8, #3
    9b84: 94000000     	bl	0x9b84 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x60>
		0000000000009b84:  ARM64_RELOC_BRANCH26	_malloc
    9b88: b4000b40     	cbz	x0, 0x9cf0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1cc>
    9b8c: d2800009     	mov	x9, #0x0                ; =0
    9b90: 91002008     	add	x8, x0, #0x8
    9b94: aa1303ea     	mov	x10, x19
    9b98: aa1703ec     	mov	x12, x23
    9b9c: b81f811f     	stur	wzr, [x8, #-0x8]
    9ba0: 91000529     	add	x9, x9, #0x1
    9ba4: a881fd1f     	stp	xzr, xzr, [x8], #0x18
    9ba8: eb09019f     	cmp	x12, x9
    9bac: 54ffff81     	b.ne	0x9b9c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x78>
    9bb0: a940a14b     	ldp	x11, x8, [x10, #0x8]
    9bb4: a900314c     	stp	x12, x12, [x10]
    9bb8: f9000940     	str	x0, [x10, #0x10]
    9bbc: b40008d4     	cbz	x20, 0x9cd4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1b0>
    9bc0: 36000336     	tbz	w22, #0x0, 0x9c24 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x100>
    9bc4: 5280030c     	mov	w12, #0x18              ; =24
    9bc8: 5280004d     	mov	w13, #0x2               ; =2
    9bcc: 14000004     	b	0x9bdc <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xb8>
    9bd0: b90001ed     	str	w13, [x15]
    9bd4: 3c8081e0     	stur	q0, [x15, #0x8]
    9bd8: b40007f4     	cbz	x20, 0x9cd4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1b0>
    9bdc: d1000694     	sub	x20, x20, #0x1
    9be0: 9b0c228e     	madd	x14, x20, x12, x8
    9be4: b94001cf     	ldr	w15, [x14]
    9be8: 710009ff     	cmp	w15, #0x2
    9bec: 54ffff63     	b.lo	0x9bd8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xb4>
    9bf0: 3cc081c0     	ldur	q0, [x14, #0x8]
    9bf4: d280000e     	mov	x14, #0x0               ; =0
    9bf8: aa0003ef     	mov	x15, x0
    9bfc: b94001f0     	ldr	w16, [x15]
    9c00: 71000a1f     	cmp	w16, #0x2
    9c04: 54fffe63     	b.lo	0x9bd0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xac>
    9c08: 910005ce     	add	x14, x14, #0x1
    9c0c: 910061ef     	add	x15, x15, #0x18
    9c10: eb0e013f     	cmp	x9, x14
    9c14: 54ffff41     	b.ne	0x9bfc <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xd8>
    9c18: 17fffff7     	b	0x9bf4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xd0>
    9c1c: 52800000     	mov	w0, #0x0                ; =0
    9c20: 17ffffcb     	b	0x9b4c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x28>
    9c24: 5280030d     	mov	w13, #0x18              ; =24
    9c28: d29cb72e     	mov	x14, #0xe5b9            ; =58809
    9c2c: f2a39c8e     	movk	x14, #0x1ce4, lsl #16
    9c30: f2c8edae     	movk	x14, #0x476d, lsl #32
    9c34: f2f7eb0e     	movk	x14, #0xbf58, lsl #48
    9c38: d2823d6f     	mov	x15, #0x11eb            ; =4587
    9c3c: f2a2662f     	movk	x15, #0x1331, lsl #16
    9c40: f2c9376f     	movk	x15, #0x49bb, lsl #32
    9c44: f2f29a0f     	movk	x15, #0x94d0, lsl #48
    9c48: 52800050     	mov	w16, #0x2               ; =2
    9c4c: 14000002     	b	0x9c54 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x130>
    9c50: b4000434     	cbz	x20, 0x9cd4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1b0>
    9c54: d1000694     	sub	x20, x20, #0x1
    9c58: 9b0d2291     	madd	x17, x20, x13, x8
    9c5c: b9400221     	ldr	w1, [x17]
    9c60: 7100043f     	cmp	w1, #0x1
    9c64: 54ffff69     	b.ls	0x9c50 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x12c>
    9c68: 3cc08220     	ldur	q0, [x17, #0x8]
    9c6c: f9400631     	ldr	x17, [x17, #0x8]
    9c70: ca150231     	eor	x17, x17, x21
    9c74: ca517a31     	eor	x17, x17, x17, lsr #30
    9c78: 9b0e7e31     	mul	x17, x17, x14
    9c7c: ca516e31     	eor	x17, x17, x17, lsr #27
    9c80: 9b0f7e31     	mul	x17, x17, x15
    9c84: ca517e31     	eor	x17, x17, x17, lsr #31
    9c88: 9acc0a21     	udiv	x1, x17, x12
    9c8c: 9b0cc431     	msub	x17, x1, x12, x17
    9c90: cb110181     	sub	x1, x12, x17
    9c94: cb0103e2     	neg	x2, x1
    9c98: d2800003     	mov	x3, #0x0                ; =0
    9c9c: eb01007f     	cmp	x3, x1
    9ca0: 9a823224     	csel	x4, x17, x2, lo
    9ca4: 8b030084     	add	x4, x4, x3
    9ca8: 9b0d0084     	madd	x4, x4, x13, x0
    9cac: b9400085     	ldr	w5, [x4]
    9cb0: 710004bf     	cmp	w5, #0x1
    9cb4: 540000a9     	b.ls	0x9cc8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1a4>
    9cb8: 91000463     	add	x3, x3, #0x1
    9cbc: eb03013f     	cmp	x9, x3
    9cc0: 54fffee1     	b.ne	0x9c9c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x178>
    9cc4: 17fffff5     	b	0x9c98 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x174>
    9cc8: b9000090     	str	w16, [x4]
    9ccc: 3c808080     	stur	q0, [x4, #0x8]
    9cd0: b5fffc34     	cbnz	x20, 0x9c54 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x130>
    9cd4: b400008b     	cbz	x11, 0x9ce4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1c0>
    9cd8: aa0803e0     	mov	x0, x8
    9cdc: 94000000     	bl	0x9cdc <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1b8>
		0000000000009cdc:  ARM64_RELOC_BRANCH26	_free
    9ce0: aa1303ea     	mov	x10, x19
    9ce4: 52800000     	mov	w0, #0x0                ; =0
    9ce8: f900115f     	str	xzr, [x10, #0x20]
    9cec: 17ffff98     	b	0x9b4c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x28>
    9cf0: 94000000     	bl	0x9cf0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1cc>
		0000000000009cf0:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
