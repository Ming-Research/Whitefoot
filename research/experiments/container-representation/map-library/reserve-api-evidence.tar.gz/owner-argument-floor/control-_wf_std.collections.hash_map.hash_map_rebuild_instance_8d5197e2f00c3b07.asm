000000000000a0b8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07>:
    a0b8: d10543ff     	sub	sp, sp, #0x150
    a0bc: a9106ffc     	stp	x28, x27, [sp, #0x100]
    a0c0: a9115ff8     	stp	x24, x23, [sp, #0x110]
    a0c4: a91257f6     	stp	x22, x21, [sp, #0x120]
    a0c8: a9134ff4     	stp	x20, x19, [sp, #0x130]
    a0cc: a9147bfd     	stp	x29, x30, [sp, #0x140]
    a0d0: f1000c3f     	cmp	x1, #0x3
    a0d4: 540000a8     	b.hi	0xa0e8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x30>
    a0d8: aa0003f3     	mov	x19, x0
    a0dc: f9400016     	ldr	x22, [x0]
    a0e0: eb16003f     	cmp	x1, x22
    a0e4: 54000162     	b.hs	0xa110 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x58>
    a0e8: 52800020     	mov	w0, #0x1                ; =1
    a0ec: 52800001     	mov	w1, #0x0                ; =0
    a0f0: 52800002     	mov	w2, #0x0                ; =0
    a0f4: a9547bfd     	ldp	x29, x30, [sp, #0x140]
    a0f8: a9534ff4     	ldp	x20, x19, [sp, #0x130]
    a0fc: a95257f6     	ldp	x22, x21, [sp, #0x120]
    a100: a9515ff8     	ldp	x24, x23, [sp, #0x110]
    a104: a9506ffc     	ldp	x28, x27, [sp, #0x100]
    a108: 910543ff     	add	sp, sp, #0x150
    a10c: d65f03c0     	ret
    a110: b4000861     	cbz	x1, 0xa21c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x164>
    a114: aa0203f4     	mov	x20, x2
    a118: aa0103f5     	mov	x21, x1
    a11c: 8b011028     	add	x8, x1, x1, lsl #4
    a120: d37ced00     	lsl	x0, x8, #4
    a124: 94000000     	bl	0xa124 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x6c>
		000000000000a124:  ARM64_RELOC_BRANCH26	_malloc
    a128: b40007e0     	cbz	x0, 0xa224 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x16c>
    a12c: d2800008     	mov	x8, #0x0                ; =0
    a130: 91002009     	add	x9, x0, #0x8
    a134: 6f00e400     	movi.2d	v0, #0000000000000000
    a138: aa1503ea     	mov	x10, x21
    a13c: b81f813f     	stur	wzr, [x9, #-0x8]
    a140: 91000508     	add	x8, x8, #0x1
    a144: ad000120     	stp	q0, q0, [x9]
    a148: ad010120     	stp	q0, q0, [x9, #0x20]
    a14c: ad020120     	stp	q0, q0, [x9, #0x40]
    a150: ad030120     	stp	q0, q0, [x9, #0x60]
    a154: ad040120     	stp	q0, q0, [x9, #0x80]
    a158: ad050120     	stp	q0, q0, [x9, #0xa0]
    a15c: ad060120     	stp	q0, q0, [x9, #0xc0]
    a160: ad070120     	stp	q0, q0, [x9, #0xe0]
    a164: f900813f     	str	xzr, [x9, #0x100]
    a168: 91044129     	add	x9, x9, #0x110
    a16c: eb08015f     	cmp	x10, x8
    a170: 54fffe61     	b.ne	0xa13c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x84>
    a174: a940d677     	ldp	x23, x21, [x19, #0x8]
    a178: a9002a6a     	stp	x10, x10, [x19]
    a17c: f9000a60     	str	x0, [x19, #0x10]
    a180: b4000436     	cbz	x22, 0xa204 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x14c>
    a184: 52802208     	mov	w8, #0x110              ; =272
    a188: 9b0856c8     	madd	x8, x22, x8, x21
    a18c: d1044118     	sub	x24, x8, #0x110
    a190: 14000004     	b	0xa1a0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0xe8>
    a194: d1044318     	sub	x24, x24, #0x110
    a198: d10006d6     	sub	x22, x22, #0x1
    a19c: b4000356     	cbz	x22, 0xa204 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x14c>
    a1a0: b9400308     	ldr	w8, [x24]
    a1a4: 7100051f     	cmp	w8, #0x1
    a1a8: 54ffff69     	b.ls	0xa194 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0xdc>
    a1ac: f9400701     	ldr	x1, [x24, #0x8]
    a1b0: ad468700     	ldp	q0, q1, [x24, #0xd0]
    a1b4: ad0607e0     	stp	q0, q1, [sp, #0xc0]
    a1b8: ad478700     	ldp	q0, q1, [x24, #0xf0]
    a1bc: ad0707e0     	stp	q0, q1, [sp, #0xe0]
    a1c0: ad448700     	ldp	q0, q1, [x24, #0x90]
    a1c4: ad0407e0     	stp	q0, q1, [sp, #0x80]
    a1c8: ad458700     	ldp	q0, q1, [x24, #0xb0]
    a1cc: ad0507e0     	stp	q0, q1, [sp, #0xa0]
    a1d0: ad428700     	ldp	q0, q1, [x24, #0x50]
    a1d4: ad0207e0     	stp	q0, q1, [sp, #0x40]
    a1d8: ad438700     	ldp	q0, q1, [x24, #0x70]
    a1dc: ad0307e0     	stp	q0, q1, [sp, #0x60]
    a1e0: ad408700     	ldp	q0, q1, [x24, #0x10]
    a1e4: ad0007e0     	stp	q0, q1, [sp]
    a1e8: ad418700     	ldp	q0, q1, [x24, #0x30]
    a1ec: ad0107e0     	stp	q0, q1, [sp, #0x20]
    a1f0: 910003e2     	mov	x2, sp
    a1f4: aa1303e0     	mov	x0, x19
    a1f8: aa1403e3     	mov	x3, x20
    a1fc: 94000000     	bl	0xa1fc <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x144>
		000000000000a1fc:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07
    a200: 17ffffe5     	b	0xa194 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0xdc>
    a204: b4000077     	cbz	x23, 0xa210 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x158>
    a208: aa1503e0     	mov	x0, x21
    a20c: 94000000     	bl	0xa20c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x154>
		000000000000a20c:  ARM64_RELOC_BRANCH26	_free
    a210: 52800000     	mov	w0, #0x0                ; =0
    a214: f900127f     	str	xzr, [x19, #0x20]
    a218: 17ffffb5     	b	0xa0ec <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x34>
    a21c: 52800000     	mov	w0, #0x0                ; =0
    a220: 17ffffb3     	b	0xa0ec <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x34>
    a224: 94000000     	bl	0xa224 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x16c>
		000000000000a224:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
