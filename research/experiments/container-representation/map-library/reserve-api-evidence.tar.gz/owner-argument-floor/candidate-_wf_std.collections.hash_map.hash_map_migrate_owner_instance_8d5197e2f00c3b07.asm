000000000000aa78 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07>:
    aa78: 3940206a     	ldrb	w10, [x3, #0x8]
    aa7c: f9400008     	ldr	x8, [x0]
    aa80: b40002a8     	cbz	x8, 0xaad4 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0x5c>
    aa84: ad400440     	ldp	q0, q1, [x2]
    aa88: ad410c42     	ldp	q2, q3, [x2, #0x20]
    aa8c: ad421444     	ldp	q4, q5, [x2, #0x40]
    aa90: ad431c46     	ldp	q6, q7, [x2, #0x60]
    aa94: ad444450     	ldp	q16, q17, [x2, #0x80]
    aa98: ad454c52     	ldp	q18, q19, [x2, #0xa0]
    aa9c: ad465454     	ldp	q20, q21, [x2, #0xc0]
    aaa0: ad475c56     	ldp	q22, q23, [x2, #0xe0]
    aaa4: f9400809     	ldr	x9, [x0, #0x10]
    aaa8: 360001ca     	tbz	w10, #0x0, 0xaae0 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0x68>
    aaac: d280000b     	mov	x11, #0x0               ; =0
    aab0: aa0903ea     	mov	x10, x9
    aab4: b940014c     	ldr	w12, [x10]
    aab8: 7100099f     	cmp	w12, #0x2
    aabc: 54000523     	b.lo	0xab60 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0xe8>
    aac0: 9100056b     	add	x11, x11, #0x1
    aac4: 9104414a     	add	x10, x10, #0x110
    aac8: eb0b011f     	cmp	x8, x11
    aacc: 54ffff41     	b.ne	0xaab4 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0x3c>
    aad0: 17fffff7     	b	0xaaac <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0x34>
    aad4: 3600004a     	tbz	w10, #0x0, 0xaadc <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0x64>
    aad8: 14000000     	b	0xaad8 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0x60>
    aadc: 14000000     	b	0xaadc <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0x64>
    aae0: f940006a     	ldr	x10, [x3]
    aae4: ca01014a     	eor	x10, x10, x1
    aae8: ca4a794a     	eor	x10, x10, x10, lsr #30
    aaec: d29cb72b     	mov	x11, #0xe5b9            ; =58809
    aaf0: f2a39c8b     	movk	x11, #0x1ce4, lsl #16
    aaf4: f2c8edab     	movk	x11, #0x476d, lsl #32
    aaf8: f2f7eb0b     	movk	x11, #0xbf58, lsl #48
    aafc: 9b0b7d4a     	mul	x10, x10, x11
    ab00: ca4a6d4a     	eor	x10, x10, x10, lsr #27
    ab04: d2823d6b     	mov	x11, #0x11eb            ; =4587
    ab08: f2a2662b     	movk	x11, #0x1331, lsl #16
    ab0c: f2c9376b     	movk	x11, #0x49bb, lsl #32
    ab10: f2f29a0b     	movk	x11, #0x94d0, lsl #48
    ab14: 9b0b7d4a     	mul	x10, x10, x11
    ab18: ca4a7d4a     	eor	x10, x10, x10, lsr #31
    ab1c: 9ac8094b     	udiv	x11, x10, x8
    ab20: 9b08a96b     	msub	x11, x11, x8, x10
    ab24: cb0b010c     	sub	x12, x8, x11
    ab28: cb0c03ed     	neg	x13, x12
    ab2c: 5280220e     	mov	w14, #0x110             ; =272
    ab30: d280000f     	mov	x15, #0x0               ; =0
    ab34: eb0c01ff     	cmp	x15, x12
    ab38: 9a8d316a     	csel	x10, x11, x13, lo
    ab3c: 8b0f014a     	add	x10, x10, x15
    ab40: 9b0e254a     	madd	x10, x10, x14, x9
    ab44: b9400150     	ldr	w16, [x10]
    ab48: 71000a1f     	cmp	w16, #0x2
    ab4c: 540000a3     	b.lo	0xab60 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0xe8>
    ab50: 910005ef     	add	x15, x15, #0x1
    ab54: eb0f011f     	cmp	x8, x15
    ab58: 54fffee1     	b.ne	0xab34 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0xbc>
    ab5c: 17fffff5     	b	0xab30 <_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07+0xb8>
    ab60: 52800048     	mov	w8, #0x2                ; =2
    ab64: b9000148     	str	w8, [x10]
    ab68: f9000541     	str	x1, [x10, #0x8]
    ab6c: ad008540     	stp	q0, q1, [x10, #0x10]
    ab70: ad018d42     	stp	q2, q3, [x10, #0x30]
    ab74: ad029544     	stp	q4, q5, [x10, #0x50]
    ab78: ad039d46     	stp	q6, q7, [x10, #0x70]
    ab7c: ad04c550     	stp	q16, q17, [x10, #0x90]
    ab80: ad05cd52     	stp	q18, q19, [x10, #0xb0]
    ab84: ad06d554     	stp	q20, q21, [x10, #0xd0]
    ab88: ad07dd56     	stp	q22, q23, [x10, #0xf0]
    ab8c: 52800000     	mov	w0, #0x0                ; =0
    ab90: d65f03c0     	ret
