000000000000a4b4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65>:
    a4b4: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    a4b8: a90157f6     	stp	x22, x21, [sp, #0x10]
    a4bc: a9024ff4     	stp	x20, x19, [sp, #0x20]
    a4c0: a9037bfd     	stp	x29, x30, [sp, #0x30]
    a4c4: f140103f     	cmp	x1, #0x4, lsl #12       ; =0x4000
    a4c8: 540000a8     	b.hi	0xa4dc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x28>
    a4cc: aa0003f3     	mov	x19, x0
    a4d0: f9400016     	ldr	x22, [x0]
    a4d4: eb16003f     	cmp	x1, x22
    a4d8: 54000122     	b.hs	0xa4fc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x48>
    a4dc: 52800020     	mov	w0, #0x1                ; =1
    a4e0: 52800001     	mov	w1, #0x0                ; =0
    a4e4: 52800002     	mov	w2, #0x0                ; =0
    a4e8: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    a4ec: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    a4f0: a94157f6     	ldp	x22, x21, [sp, #0x10]
    a4f4: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    a4f8: d65f03c0     	ret
    a4fc: b4000661     	cbz	x1, 0xa5c8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x114>
    a500: aa0203f4     	mov	x20, x2
    a504: aa0103f5     	mov	x21, x1
    a508: 8b011028     	add	x8, x1, x1, lsl #4
    a50c: d37ced00     	lsl	x0, x8, #4
    a510: 94000000     	bl	0xa510 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x5c>
		000000000000a510:  ARM64_RELOC_BRANCH26	_malloc
    a514: b40005e0     	cbz	x0, 0xa5d0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x11c>
    a518: d2800008     	mov	x8, #0x0                ; =0
    a51c: 91002009     	add	x9, x0, #0x8
    a520: 6f00e400     	movi.2d	v0, #0000000000000000
    a524: aa1503ea     	mov	x10, x21
    a528: b81f813f     	stur	wzr, [x9, #-0x8]
    a52c: 91000508     	add	x8, x8, #0x1
    a530: ad000120     	stp	q0, q0, [x9]
    a534: ad010120     	stp	q0, q0, [x9, #0x20]
    a538: ad020120     	stp	q0, q0, [x9, #0x40]
    a53c: ad030120     	stp	q0, q0, [x9, #0x60]
    a540: ad040120     	stp	q0, q0, [x9, #0x80]
    a544: ad050120     	stp	q0, q0, [x9, #0xa0]
    a548: ad060120     	stp	q0, q0, [x9, #0xc0]
    a54c: ad070120     	stp	q0, q0, [x9, #0xe0]
    a550: f900813f     	str	xzr, [x9, #0x100]
    a554: 91044129     	add	x9, x9, #0x110
    a558: eb08015f     	cmp	x10, x8
    a55c: 54fffe61     	b.ne	0xa528 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x74>
    a560: a940d677     	ldp	x23, x21, [x19, #0x8]
    a564: a9002a6a     	stp	x10, x10, [x19]
    a568: f9000a60     	str	x0, [x19, #0x10]
    a56c: b4000236     	cbz	x22, 0xa5b0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xfc>
    a570: 52802208     	mov	w8, #0x110              ; =272
    a574: 9b0856c8     	madd	x8, x22, x8, x21
    a578: d1044118     	sub	x24, x8, #0x110
    a57c: 14000004     	b	0xa58c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xd8>
    a580: d1044318     	sub	x24, x24, #0x110
    a584: d10006d6     	sub	x22, x22, #0x1
    a588: b4000156     	cbz	x22, 0xa5b0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xfc>
    a58c: b9400308     	ldr	w8, [x24]
    a590: 7100051f     	cmp	w8, #0x1
    a594: 54ffff69     	b.ls	0xa580 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xcc>
    a598: f9400701     	ldr	x1, [x24, #0x8]
    a59c: 91004302     	add	x2, x24, #0x10
    a5a0: aa1303e0     	mov	x0, x19
    a5a4: aa1403e3     	mov	x3, x20
    a5a8: 94000000     	bl	0xa5a8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xf4>
		000000000000a5a8:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65
    a5ac: 17fffff5     	b	0xa580 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xcc>
    a5b0: b4000077     	cbz	x23, 0xa5bc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x108>
    a5b4: aa1503e0     	mov	x0, x21
    a5b8: 94000000     	bl	0xa5b8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x104>
		000000000000a5b8:  ARM64_RELOC_BRANCH26	_free
    a5bc: 52800000     	mov	w0, #0x0                ; =0
    a5c0: f900127f     	str	xzr, [x19, #0x20]
    a5c4: 17ffffc7     	b	0xa4e0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x2c>
    a5c8: 52800000     	mov	w0, #0x0                ; =0
    a5cc: 17ffffc5     	b	0xa4e0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x2c>
    a5d0: 94000000     	bl	0xa5d0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x11c>
		000000000000a5d0:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
