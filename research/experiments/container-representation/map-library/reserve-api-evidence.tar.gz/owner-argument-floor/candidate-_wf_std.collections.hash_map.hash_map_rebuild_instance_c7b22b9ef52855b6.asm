0000000000009718 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6>:
    9718: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    971c: a90157f6     	stp	x22, x21, [sp, #0x10]
    9720: a9024ff4     	stp	x20, x19, [sp, #0x20]
    9724: a9037bfd     	stp	x29, x30, [sp, #0x30]
    9728: f1000c3f     	cmp	x1, #0x3
    972c: 54000088     	b.hi	0x973c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x24>
    9730: f9400014     	ldr	x20, [x0]
    9734: eb14003f     	cmp	x1, x20
    9738: 54000122     	b.hs	0x975c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x44>
    973c: 52800020     	mov	w0, #0x1                ; =1
    9740: 52800001     	mov	w1, #0x0                ; =0
    9744: 52800002     	mov	w2, #0x0                ; =0
    9748: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    974c: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    9750: a94157f6     	ldp	x22, x21, [sp, #0x10]
    9754: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    9758: d65f03c0     	ret
    975c: b40005a1     	cbz	x1, 0x9810 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xf8>
    9760: aa0003f3     	mov	x19, x0
    9764: f9400055     	ldr	x21, [x2]
    9768: 39402056     	ldrb	w22, [x2, #0x8]
    976c: aa0103f7     	mov	x23, x1
    9770: 8b010428     	add	x8, x1, x1, lsl #1
    9774: d37df100     	lsl	x0, x8, #3
    9778: 94000000     	bl	0x9778 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x60>
		0000000000009778:  ARM64_RELOC_BRANCH26	_malloc
    977c: b4000b40     	cbz	x0, 0x98e4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1cc>
    9780: d2800009     	mov	x9, #0x0                ; =0
    9784: 91002008     	add	x8, x0, #0x8
    9788: aa1303ea     	mov	x10, x19
    978c: aa1703ec     	mov	x12, x23
    9790: b81f811f     	stur	wzr, [x8, #-0x8]
    9794: 91000529     	add	x9, x9, #0x1
    9798: a881fd1f     	stp	xzr, xzr, [x8], #0x18
    979c: eb09019f     	cmp	x12, x9
    97a0: 54ffff81     	b.ne	0x9790 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x78>
    97a4: a940a14b     	ldp	x11, x8, [x10, #0x8]
    97a8: a900314c     	stp	x12, x12, [x10]
    97ac: f9000940     	str	x0, [x10, #0x10]
    97b0: b40008d4     	cbz	x20, 0x98c8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1b0>
    97b4: 36000336     	tbz	w22, #0x0, 0x9818 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x100>
    97b8: 5280030c     	mov	w12, #0x18              ; =24
    97bc: 5280004d     	mov	w13, #0x2               ; =2
    97c0: 14000004     	b	0x97d0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xb8>
    97c4: b90001ed     	str	w13, [x15]
    97c8: 3c8081e0     	stur	q0, [x15, #0x8]
    97cc: b40007f4     	cbz	x20, 0x98c8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1b0>
    97d0: d1000694     	sub	x20, x20, #0x1
    97d4: 9b0c228e     	madd	x14, x20, x12, x8
    97d8: b94001cf     	ldr	w15, [x14]
    97dc: 710009ff     	cmp	w15, #0x2
    97e0: 54ffff63     	b.lo	0x97cc <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xb4>
    97e4: 3cc081c0     	ldur	q0, [x14, #0x8]
    97e8: d280000e     	mov	x14, #0x0               ; =0
    97ec: aa0003ef     	mov	x15, x0
    97f0: b94001f0     	ldr	w16, [x15]
    97f4: 71000a1f     	cmp	w16, #0x2
    97f8: 54fffe63     	b.lo	0x97c4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xac>
    97fc: 910005ce     	add	x14, x14, #0x1
    9800: 910061ef     	add	x15, x15, #0x18
    9804: eb0e013f     	cmp	x9, x14
    9808: 54ffff41     	b.ne	0x97f0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xd8>
    980c: 17fffff7     	b	0x97e8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xd0>
    9810: 52800000     	mov	w0, #0x0                ; =0
    9814: 17ffffcb     	b	0x9740 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x28>
    9818: 5280030d     	mov	w13, #0x18              ; =24
    981c: d29cb72e     	mov	x14, #0xe5b9            ; =58809
    9820: f2a39c8e     	movk	x14, #0x1ce4, lsl #16
    9824: f2c8edae     	movk	x14, #0x476d, lsl #32
    9828: f2f7eb0e     	movk	x14, #0xbf58, lsl #48
    982c: d2823d6f     	mov	x15, #0x11eb            ; =4587
    9830: f2a2662f     	movk	x15, #0x1331, lsl #16
    9834: f2c9376f     	movk	x15, #0x49bb, lsl #32
    9838: f2f29a0f     	movk	x15, #0x94d0, lsl #48
    983c: 52800050     	mov	w16, #0x2               ; =2
    9840: 14000002     	b	0x9848 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x130>
    9844: b4000434     	cbz	x20, 0x98c8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1b0>
    9848: d1000694     	sub	x20, x20, #0x1
    984c: 9b0d2291     	madd	x17, x20, x13, x8
    9850: b9400221     	ldr	w1, [x17]
    9854: 7100043f     	cmp	w1, #0x1
    9858: 54ffff69     	b.ls	0x9844 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x12c>
    985c: 3cc08220     	ldur	q0, [x17, #0x8]
    9860: f9400631     	ldr	x17, [x17, #0x8]
    9864: ca150231     	eor	x17, x17, x21
    9868: ca517a31     	eor	x17, x17, x17, lsr #30
    986c: 9b0e7e31     	mul	x17, x17, x14
    9870: ca516e31     	eor	x17, x17, x17, lsr #27
    9874: 9b0f7e31     	mul	x17, x17, x15
    9878: ca517e31     	eor	x17, x17, x17, lsr #31
    987c: 9acc0a21     	udiv	x1, x17, x12
    9880: 9b0cc431     	msub	x17, x1, x12, x17
    9884: cb110181     	sub	x1, x12, x17
    9888: cb0103e2     	neg	x2, x1
    988c: d2800003     	mov	x3, #0x0                ; =0
    9890: eb01007f     	cmp	x3, x1
    9894: 9a823224     	csel	x4, x17, x2, lo
    9898: 8b030084     	add	x4, x4, x3
    989c: 9b0d0084     	madd	x4, x4, x13, x0
    98a0: b9400085     	ldr	w5, [x4]
    98a4: 710004bf     	cmp	w5, #0x1
    98a8: 540000a9     	b.ls	0x98bc <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1a4>
    98ac: 91000463     	add	x3, x3, #0x1
    98b0: eb03013f     	cmp	x9, x3
    98b4: 54fffee1     	b.ne	0x9890 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x178>
    98b8: 17fffff5     	b	0x988c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x174>
    98bc: b9000090     	str	w16, [x4]
    98c0: 3c808080     	stur	q0, [x4, #0x8]
    98c4: b5fffc34     	cbnz	x20, 0x9848 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x130>
    98c8: b400008b     	cbz	x11, 0x98d8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1c0>
    98cc: aa0803e0     	mov	x0, x8
    98d0: 94000000     	bl	0x98d0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1b8>
		00000000000098d0:  ARM64_RELOC_BRANCH26	_free
    98d4: aa1303ea     	mov	x10, x19
    98d8: 52800000     	mov	w0, #0x0                ; =0
    98dc: f900115f     	str	xzr, [x10, #0x20]
    98e0: 17ffff98     	b	0x9740 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x28>
    98e4: 94000000     	bl	0x98e4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1cc>
		00000000000098e4:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
