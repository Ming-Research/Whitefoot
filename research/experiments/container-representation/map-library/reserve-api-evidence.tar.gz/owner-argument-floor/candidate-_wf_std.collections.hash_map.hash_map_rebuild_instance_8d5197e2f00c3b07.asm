000000000000a0d4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07>:
    a0d4: d10543ff     	sub	sp, sp, #0x150
    a0d8: a9106ffc     	stp	x28, x27, [sp, #0x100]
    a0dc: a9115ff8     	stp	x24, x23, [sp, #0x110]
    a0e0: a91257f6     	stp	x22, x21, [sp, #0x120]
    a0e4: a9134ff4     	stp	x20, x19, [sp, #0x130]
    a0e8: a9147bfd     	stp	x29, x30, [sp, #0x140]
    a0ec: f1000c3f     	cmp	x1, #0x3
    a0f0: 540000a8     	b.hi	0xa104 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x30>
    a0f4: aa0003f3     	mov	x19, x0
    a0f8: f9400016     	ldr	x22, [x0]
    a0fc: eb16003f     	cmp	x1, x22
    a100: 54000162     	b.hs	0xa12c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x58>
    a104: 52800020     	mov	w0, #0x1                ; =1
    a108: 52800001     	mov	w1, #0x0                ; =0
    a10c: 52800002     	mov	w2, #0x0                ; =0
    a110: a9547bfd     	ldp	x29, x30, [sp, #0x140]
    a114: a9534ff4     	ldp	x20, x19, [sp, #0x130]
    a118: a95257f6     	ldp	x22, x21, [sp, #0x120]
    a11c: a9515ff8     	ldp	x24, x23, [sp, #0x110]
    a120: a9506ffc     	ldp	x28, x27, [sp, #0x100]
    a124: 910543ff     	add	sp, sp, #0x150
    a128: d65f03c0     	ret
    a12c: b4000861     	cbz	x1, 0xa238 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x164>
    a130: aa0203f4     	mov	x20, x2
    a134: aa0103f5     	mov	x21, x1
    a138: 8b011028     	add	x8, x1, x1, lsl #4
    a13c: d37ced00     	lsl	x0, x8, #4
    a140: 94000000     	bl	0xa140 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x6c>
		000000000000a140:  ARM64_RELOC_BRANCH26	_malloc
    a144: b40007e0     	cbz	x0, 0xa240 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x16c>
    a148: d2800008     	mov	x8, #0x0                ; =0
    a14c: 91002009     	add	x9, x0, #0x8
    a150: 6f00e400     	movi.2d	v0, #0000000000000000
    a154: aa1503ea     	mov	x10, x21
    a158: b81f813f     	stur	wzr, [x9, #-0x8]
    a15c: 91000508     	add	x8, x8, #0x1
    a160: ad000120     	stp	q0, q0, [x9]
    a164: ad010120     	stp	q0, q0, [x9, #0x20]
    a168: ad020120     	stp	q0, q0, [x9, #0x40]
    a16c: ad030120     	stp	q0, q0, [x9, #0x60]
    a170: ad040120     	stp	q0, q0, [x9, #0x80]
    a174: ad050120     	stp	q0, q0, [x9, #0xa0]
    a178: ad060120     	stp	q0, q0, [x9, #0xc0]
    a17c: ad070120     	stp	q0, q0, [x9, #0xe0]
    a180: f900813f     	str	xzr, [x9, #0x100]
    a184: 91044129     	add	x9, x9, #0x110
    a188: eb08015f     	cmp	x10, x8
    a18c: 54fffe61     	b.ne	0xa158 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x84>
    a190: a940d677     	ldp	x23, x21, [x19, #0x8]
    a194: a9002a6a     	stp	x10, x10, [x19]
    a198: f9000a60     	str	x0, [x19, #0x10]
    a19c: b4000436     	cbz	x22, 0xa220 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x14c>
    a1a0: 52802208     	mov	w8, #0x110              ; =272
    a1a4: 9b0856c8     	madd	x8, x22, x8, x21
    a1a8: d1044118     	sub	x24, x8, #0x110
    a1ac: 14000004     	b	0xa1bc <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0xe8>
    a1b0: d1044318     	sub	x24, x24, #0x110
    a1b4: d10006d6     	sub	x22, x22, #0x1
    a1b8: b4000356     	cbz	x22, 0xa220 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x14c>
    a1bc: b9400308     	ldr	w8, [x24]
    a1c0: 7100051f     	cmp	w8, #0x1
    a1c4: 54ffff69     	b.ls	0xa1b0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0xdc>
    a1c8: f9400701     	ldr	x1, [x24, #0x8]
    a1cc: ad468700     	ldp	q0, q1, [x24, #0xd0]
    a1d0: ad0607e0     	stp	q0, q1, [sp, #0xc0]
    a1d4: ad478700     	ldp	q0, q1, [x24, #0xf0]
    a1d8: ad0707e0     	stp	q0, q1, [sp, #0xe0]
    a1dc: ad448700     	ldp	q0, q1, [x24, #0x90]
    a1e0: ad0407e0     	stp	q0, q1, [sp, #0x80]
    a1e4: ad458700     	ldp	q0, q1, [x24, #0xb0]
    a1e8: ad0507e0     	stp	q0, q1, [sp, #0xa0]
    a1ec: ad428700     	ldp	q0, q1, [x24, #0x50]
    a1f0: ad0207e0     	stp	q0, q1, [sp, #0x40]
    a1f4: ad438700     	ldp	q0, q1, [x24, #0x70]
    a1f8: ad0307e0     	stp	q0, q1, [sp, #0x60]
    a1fc: ad408700     	ldp	q0, q1, [x24, #0x10]
    a200: ad0007e0     	stp	q0, q1, [sp]
    a204: ad418700     	ldp	q0, q1, [x24, #0x30]
    a208: ad0107e0     	stp	q0, q1, [sp, #0x20]
    a20c: 910003e2     	mov	x2, sp
    a210: aa1303e0     	mov	x0, x19
    a214: aa1403e3     	mov	x3, x20
    a218: 94000000     	bl	0xa218 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x144>
		000000000000a218:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_migrate_owner$instance$8d5197e2f00c3b07
    a21c: 17ffffe5     	b	0xa1b0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0xdc>
    a220: b4000077     	cbz	x23, 0xa22c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x158>
    a224: aa1503e0     	mov	x0, x21
    a228: 94000000     	bl	0xa228 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x154>
		000000000000a228:  ARM64_RELOC_BRANCH26	_free
    a22c: 52800000     	mov	w0, #0x0                ; =0
    a230: f900127f     	str	xzr, [x19, #0x20]
    a234: 17ffffb5     	b	0xa108 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x34>
    a238: 52800000     	mov	w0, #0x0                ; =0
    a23c: 17ffffb3     	b	0xa108 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x34>
    a240: 94000000     	bl	0xa240 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x16c>
		000000000000a240:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
