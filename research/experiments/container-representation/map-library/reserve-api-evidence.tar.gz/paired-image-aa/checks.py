from pathlib import Path
import subprocess,json,os,csv,hashlib,collections
D=Path(__file__).resolve().parent
assert os.environ.get('WHITEFOOT_CHECK_OWNER')
records=[]
def run(name,mode,args,diagnostic=None):
 p=subprocess.run([str(D/f'paired-{mode}'),*args],capture_output=True,text=True)
 (D/(name+'.stdout')).write_text(p.stdout);(D/(name+'.stderr')).write_text(p.stderr)
 valid=(p.returncode==0 if diagnostic is None else p.returncode!=0 and diagnostic in p.stderr)
 records.append({'name':name,'argv':[str(D/f'paired-{mode}'),*args],'exit':p.returncode,'expected_diagnostic':diagnostic,'matched':valid})
 (D/'checks-status.json').write_text(json.dumps(records,indent=2)+'\n')
 assert valid,(name,p.returncode,p.stdout,p.stderr)
for mode in ('timed','account'):run('routing-'+mode,mode,['paired-routing-check'])
run('account-ledger','account',['reserve-account'])
rows=list(csv.DictReader((D/'account-ledger.stdout').open()));base=list(csv.DictReader((D.parent/'build/ecosystem/reserve-accounting.csv').open()))
assert len(rows)==128 and len(base)==96
as_tuple=lambda row:tuple(sorted(row.items()))
for arm in ('A','B'):
 projected=[]
 for row in rows:
  if row['variant']=='whitefoot-'+({'A':'B','B':'A'}[arm]):continue
  row=row.copy()
  if row['variant']=='whitefoot-'+arm:row['variant']='whitefoot-hash-map'
  projected.append(row)
 assert collections.Counter(map(as_tuple,projected))==collections.Counter(map(as_tuple,base)),arm
(D/'ledger-projection.json').write_text(json.dumps({'paired_rows':len(rows),'production_rows':len(base),'both_WF_projections_and_native_peer_rows_exact':True,'source_ledger_sha256':hashlib.sha256((D.parent/'build/ecosystem/reserve-accounting.csv').read_bytes()).hexdigest()},indent=2)+'\n')
faults={'receipt':'reserve public success result','omitted':'reserve application entry floor','payload':'reserve independent complete-owner oracle','population':'reserve prepared population','capacity':'reserve application entry floor','leak':'every allocation is reclaimed','allocation':'reserve noop has no allocation'}
for peer in range(4):
 for fault,diagnostic in faults.items():run(f'negative-{peer}-{fault}','account',['negative-reserve-api',fault,str(peer)],diagnostic)
for peer in range(2):run(f'negative-{peer}-raw-slots','account',['negative-reserve-api','raw-slots',str(peer)],'reserve future puts retain backing capacity')
for mode in ('timed','account'):
 for fault in ('step','cleanup'):run(f'negative-routing-{mode}-{fault}',mode,['negative-arm-routing',fault],'reserve distinct arm dispatch')
for fault,diagnostic in [('quantized','reserve clock quantum at most 100 ns'),('backwards','reserve clock nondecreasing')]:run('negative-clock-'+fault,'timed',['negative-reserve-clock',fault],diagnostic)
print(json.dumps({'commands':len(records),'positive':sum(r['exit']==0 for r in records),'expected_rejections':sum(r['exit']!=0 for r in records),'ledger_projection':'both arms and native peers exact','timing_run':False}))
