from pathlib import Path
import subprocess,json,time,hashlib,shlex,os,struct,platform
D=Path(__file__).resolve().parent; H=D.parents[2]; B=D.parent/'build/ecosystem'
LLVM=Path('<llvm-toolchain-root>/bin')
assert os.environ.get('WHITEFOOT_CHECK_OWNER')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records=[]
def run(name,args):
 t=time.monotonic()
 with (D/(name+'.stdout')).open('wb') as out,(D/(name+'.stderr')).open('wb') as err:p=subprocess.run(args,cwd=H,stdout=out,stderr=err)
 row={'stage':name,'argv':args,'exit':p.returncode,'wall_s':time.monotonic()-t};records.append(row);(D/'build-statuses.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert p.returncode==0,name
 return (D/(name+'.stdout')).read_text()
def macho(path):
 data=path.read_bytes();assert struct.unpack_from('<I',data)[0]==0xfeedfacf
 ncmd=struct.unpack_from('<I',data,16)[0];pos=32;secs=[];symtab=None
 for _ in range(ncmd):
  cmd,size=struct.unpack_from('<II',data,pos)
  if cmd==2:symtab=struct.unpack_from('<IIII',data,pos+8)
  if cmd==0x19:
   nsec=struct.unpack_from('<I',data,pos+64)[0]
   for i in range(nsec):
    p=pos+72+i*80;name=data[p:p+16].split(b'\0')[0].decode();seg=data[p+16:p+32].split(b'\0')[0].decode()
    addr,sz,off,align,reloff,nrel,flags=struct.unpack_from('<QQIIIII',data,p+32)
    raw=b'' if flags&255 in (1,12,18) else data[off:off+sz]
    reloc=[struct.unpack_from('<II',data,reloff+j*8) for j in range(nrel)]
    secs.append({'name':seg+','+name,'address':addr,'size':sz,'align':align,'flags':flags,'bytes':raw.hex(),'relocations':reloc})
  pos+=size
 assert symtab
 off,count,stroff,strsize=symtab;syms=[]
 for i in range(count):
  st,t,se,desc,value=struct.unpack_from('<IBBHQ',data,off+i*16)
  end=data.find(b'\0',stroff+st);name=data[stroff+st:end].decode()
  syms.append({'name':name,'type':t,'section':se,'desc':desc,'value':value})
 return {'sections':secs,'symbols':syms}
base={}
for line in (D.parent/'build-10.log').read_text().splitlines():
 if line.startswith('clang++ -O3 '):
  args=shlex.split(line);mode='account' if 'map-account' in args[-1] else 'timed'
  base[mode]=[str(H/a) if a.startswith('.build/') else a for a in args]
inputs={a:sha(Path(a)) for args in base.values() for a in args[1:-2] if a.endswith(('.o','.a'))}
inputs.update({str(p):sha(p) for p in [D/'criterion.txt',D/'driver.c',H/'map-oracle.h']})
(D/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
metadata={'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'platform':platform.platform(),'machine':platform.machine(),'unrelated_host_load':'Parent observed ordinary browser/interactive load before build; no causal inference and no process manipulation. No local heavy job reported.','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=H,text=True).strip(),'clang':subprocess.check_output(['clang','--version'],text=True),'objcopy':subprocess.check_output([str(LLVM/'llvm-objcopy'),'--version'],text=True)}
(D/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
audit={};links={}
for mode in ['timed','account']:
 original=macho(B/f'wf-{mode}.o')
 for arm in ['a','b']:
  out=D/f'wf-{arm}-{mode}.o'
  run(f'namespace-{arm}-{mode}',[str(LLVM/'llvm-objcopy'),'--redefine-syms='+str(D/f'{arm}-{mode}.symbols'),str(B/f'wf-{mode}.o'),str(out)])
  renamed=macho(out);mapping=dict(line.split() for line in (D/f'{arm}-{mode}.symbols').read_text().splitlines());reverse={b:a for a,b in mapping.items()}
  for sym in renamed['symbols']:sym['name']=reverse.get(sym['name'],sym['name'])
  assert original==renamed,'object sections/symbols/relocations changed beyond names'
  audit[arm+'-'+mode]={'source_sha256':sha(B/f'wf-{mode}.o'),'output_sha256':sha(out),'renamed_symbols':len(mapping),'sections':len(original['sections']),'relocations':sum(len(s['relocations']) for s in original['sections']),'exact_sections_symbols_relocations_after_name_reversal':True,'undefined_names_unchanged':True}
 run('driver-'+mode,['clang','-O3','-std=c11','-Wall','-Wextra','-Werror','-I',str(H)]+(['-DACCOUNT_ONLY'] if mode=='account' else [])+['-c',str(D/'driver.c'),'-o',str(D/f'driver-{mode}.o')])
 args=base[mode].copy();args[args.index(str(B/f'driver-{mode}.o'))]=str(D/f'driver-{mode}.o');i=args.index(str(B/f'wf-{mode}.o'));args[i:i+1]=[str(D/f'wf-a-{mode}.o'),str(D/f'wf-b-{mode}.o')];args.insert(1,'-Wl,-no_deduplicate');args.insert(2,'-Wl,-alias,_pair_a_wf__main_body,_wf__main_body');args[-1]=str(D/f'paired-{mode}');links[mode]=args
 run('link-'+mode,args)
(D/'object-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
(D/'link-commands.json').write_text(json.dumps({'baseline':base,'paired':links},indent=2)+'\n')
run('native',[str(LLVM/'llvm-objdump'),'--disassemble','--no-show-raw-insn',str(D/'paired-timed')])
run('symbols',[str(LLVM/'llvm-nm'),'-n',str(D/'paired-timed')])
for p,h in inputs.items():assert sha(Path(p))==h,'input mutated'
(D/'images.json').write_text(json.dumps({mode:sha(D/f'paired-{mode}') for mode in ['timed','account']},indent=2)+'\n')
print('BUILD COMPLETE; object bytes/relocations exact; no correctness or timing run',flush=True)
