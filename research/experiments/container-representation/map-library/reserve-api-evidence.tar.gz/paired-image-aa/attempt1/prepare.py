from pathlib import Path
import subprocess,re,json,hashlib,difflib
D=Path(__file__).resolve().parent; H=D.parents[2]; B=D.parent/'build/ecosystem'
LLVM=Path('<llvm-toolchain-root>/bin')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins={str(p):sha(p) for p in [H/'map-ecosystem.c',H/'map-oracle.h',B/'wf-timed.o',B/'wf-account.o',D/'criterion.txt']}
for mode in ['timed','account']:
    names=[]
    out=subprocess.check_output([str(LLVM/'llvm-nm'),'--defined-only','--extern-only',str(B/f'wf-{mode}.o')],text=True)
    for line in out.splitlines():
        name=line.split()[-1]; assert name.startswith('_wf'),name; names.append(name)
    for arm in ['a','b']:
        (D/f'{arm}-{mode}.symbols').write_text(''.join(f'{n} _pair_{arm}{n}\n' for n in names))
    if mode=='timed':
        macros=''.join(f'#define {n[1:]} pair_a{n}\n' for n in names if re.fullmatch(r'_[A-Za-z_][A-Za-z0-9_]*',n))
original=(H/'map-ecosystem.c').read_text(); s=original
s=s.replace('#include "map-oracle.h"',macros+'\n#include "map-oracle.h"')
# The original declarations precede the oracle include: apply the namespace
# macros at file start, before every declaration and use.
s=s.replace(macros+'\n#include "map-oracle.h"','#include "map-oracle.h"')
s=macros+'\n'+s
at='static const ReserveApi reserve_apis[] = {'
bdecl=''
for w in ['word','record']:
    bdecl+=f'''extern void pair_b_wf_map_cost_reserve_{w}_prepare(void *, uint64_t, uint64_t, uint64_t);
extern uint64_t pair_b_wf_map_cost_reserve_{w}_step(void *, uint64_t);
extern uint64_t pair_b_wf_map_cost_reserve_{w}_raw(void *, uint64_t);
extern uint64_t pair_b_wf_map_cost_reserve_{w}_insert(void *, uint64_t, uint64_t);
extern uint64_t pair_b_wf_map_cost_lookup_{w}_geometry(const void *);
extern uint64_t pair_b_wf_map_cost_lookup_{w}_finish(void *);
'''
s=s.replace(at,bdecl+at)
s=s.replace('#define RESERVE_WF_ENTRY(W,B,S) {"whitefoot-hash-map"','#define RESERVE_WF_ENTRY(W,B,S) {"whitefoot-A"')
s=s.replace('#define RESERVE_ENTRIES(W,B,S,H) \\\n    RESERVE_WF_ENTRY(W,B,S), \\', '#define RESERVE_ENTRIES(W,B,S,H) \\\n    RESERVE_WF_ENTRY(W,B,S), \\\n    {"whitefoot-B",0,S,B,pair_b_wf_map_cost_reserve_##W##_prepare,pair_b_wf_map_cost_reserve_##W##_step,pair_b_wf_map_cost_lookup_##W##_geometry,NULL,pair_b_wf_map_cost_reserve_##W##_insert,pair_b_wf_map_cost_lookup_##W##_finish}, \\')
assert '{"whitefoot-B"' in s
s=s.replace('RESERVE_CAPACITY, RESERVE_LEAK, RESERVE_ALLOCATION };','RESERVE_CAPACITY, RESERVE_LEAK, RESERVE_ALLOCATION, RESERVE_RECEIPT };')
s=s.replace('receipt = api->wide ? wf_map_cost_reserve_record_raw(owner.bytes, target)\n                            : wf_map_cost_reserve_word_raw(owner.bytes, target);','''bool arm_b = api->step == pair_b_wf_map_cost_reserve_word_step ||
                     api->step == pair_b_wf_map_cost_reserve_record_step;
        receipt = arm_b
            ? (api->wide ? pair_b_wf_map_cost_reserve_record_raw(owner.bytes,target)
                         : pair_b_wf_map_cost_reserve_word_raw(owner.bytes,target))
            : (api->wide ? wf_map_cost_reserve_record_raw(owner.bytes,target)
                         : wf_map_cost_reserve_word_raw(owner.bytes,target));''')
s=s.replace('    require(receipt == 1, "reserve public success result");','    if (fault == RESERVE_RECEIPT) receipt ^= 1;\n    require(receipt == 1, "reserve public success result");')
s=s.replace('require(peer < 3, "reserve negative peer 0..2");','require(peer < 4, "reserve negative participant 0..3");')
s=s.replace('if (!strcmp(fault,"omitted")) kind = RESERVE_OMIT;','if (!strcmp(fault,"receipt")) kind = RESERVE_RECEIPT;\n    else if (!strcmp(fault,"omitted")) kind = RESERVE_OMIT;')
s=s.replace('require(peer == 0, "raw-slots is WF only")','require(peer < 2, "raw-slots is WF only")')
s=s.replace('reserve_case(&reserve_apis[6 + peer],','reserve_case(&reserve_apis[8 + peer],')
s=s.replace("argv[3][0] <= '2', \"reserve negative fault peer\"","argv[3][0] <= '3', \"reserve negative fault peer\"")
# Separate function identity observer. The deliberate fault changes an actual
# dispatch pointer; identical output checks alone cannot detect an A/A misroute.
routing='''static void reserve_routing(unsigned fault) {
    for (unsigned wide=0; wide<2; ++wide) for (unsigned series=0; series<2; ++series) {
        const ReserveApi *a=&reserve_apis[wide*8+series*4];
        ReserveApi b=a[1];
        if (fault == 1) b.step=a->step;
        if (fault == 2) b.finish=a->finish;
        require(a->prepare != b.prepare && a->step != b.step &&
                a->geometry != b.geometry && a->insert != b.insert &&
                a->finish != b.finish,"reserve distinct arm dispatch");
        require(b.step == (wide ? pair_b_wf_map_cost_reserve_record_step : pair_b_wf_map_cost_reserve_word_step),
                "reserve B dispatch target");
        require(b.finish == (wide ? pair_b_wf_map_cost_lookup_record_finish : pair_b_wf_map_cost_lookup_word_finish),
                "reserve B cleanup target");
        require(a->step == (wide ? wf_map_cost_reserve_record_step : wf_map_cost_reserve_word_step),
                "reserve A dispatch target");
        require(a[2].peer == 1 && a[3].peer == 2,"reserve native peer identity");
    }
}
static unsigned reserve_order(unsigned sample, uint64_t batch, unsigned turn, unsigned cohort) {
    static const unsigned order[4][4]={{0,1,2,3},{1,0,3,2},{2,3,0,1},{3,2,1,0}};
    return order[(sample+batch)%4][cohort ? 3-turn : turn];
}
static void reserve_schedule_check(void) {
    for (unsigned cohort=0;cohort<2;++cohort) for (unsigned batch=0;batch<256;++batch) {
        unsigned positions[4][4]={{0}};
        for (unsigned sample=0;sample<12;++sample) {
            unsigned mask=0, apos=4,bpos=4;
            for (unsigned turn=0;turn<4;++turn) {
                unsigned p=reserve_order(sample,batch,turn,cohort);
                require(p<4 && !(mask&(1u<<p)),"reserve schedule visits each participant once");
                mask|=1u<<p; ++positions[p][turn];
                if (p==0) apos=turn;
                if (p==1) bpos=turn;
            }
            require(mask==15 && (apos+1==bpos || bpos+1==apos),"reserve adjacent WF schedule");
        }
        for (unsigned p=0;p<4;++p) for (unsigned pos=0;pos<4;++pos)
            require(positions[p][pos]==3,"reserve balanced participant positions");
    }
}
'''
s=s.replace('static void reserve_check(bool print) {',routing+'\nstatic void reserve_check(bool print) {\n    reserve_routing(0); reserve_schedule_check();')
# Preserve the exact existing per-batch preparation/timed-operation/control/
# geometry/cleanup sequence; move only its outer participant scheduling.
start=s.index('static bool reserve_sample('); end=s.index('\n#endif\n\nstatic void occupancy_check',start)
body=s[s.index('        for (uint64_t i = 0; i < contexts; ++i) {\n            api->prepare',start):s.index('        cleanup ^= record->cleanup;',start)+len('        cleanup ^= record->cleanup;')]
body=body.replace('valid = valid && record->overhead_ok','valid[peer] = valid[peer] && record->overhead_ok').replace('elapsed[c] +=','elapsed[peer][c] +=').replace('receipts[c] +=','receipts[peer][c] +=').replace('cleanup ^=','cleanup[peer] ^=')
new='''static bool reserve_sample_group(unsigned group, unsigned cohort, uint64_t initial,
                                 bool grow, unsigned sample, uint64_t clock_cost) {
    uint64_t contexts=initial==64 ? 256 : 8;
    uint64_t calls=grow ? (initial==64 ? 65536 : 1024) : UINT64_C(4194304);
    uint64_t batches=grow ? calls/contexts : 1, repeats=grow ? 1 : calls/contexts;
    uint64_t target=grow ? initial*2 : initial, count=initial/2;
    LookupStorage owners[256];
    ReserveInterval records[4][256]={0};
    uint64_t elapsed[4][2]={{0}}, receipts[4][2]={{0}}, cleanup[4]={0};
    bool valid[4]={true,true,true,true};
    for (uint64_t batch=0;batch<batches;++batch) for (unsigned turn=0;turn<4;++turn) {
        unsigned peer=reserve_order(sample,batch,turn,cohort);
        const ReserveApi *api=&reserve_apis[group+peer];
        ReserveInterval *record=&records[peer][batch];
        uint64_t first_seed=101+sample+batch*contexts;
'''+body+'''
    }
    bool all_valid=true;
    for (unsigned peer=0;peer<4;++peer) {
        const ReserveApi *api=&reserve_apis[group+peer];
        valid[peer]=valid[peer] && elapsed[peer][0]>=UINT64_C(1000000);
        all_valid=all_valid && valid[peer];
        for (uint64_t b=0;b<batches;++b) for (unsigned c=0;c<2;++c)
            reserve_row(api,cohort,initial,grow,sample,c,"batch",b,contexts,contexts*repeats,
                records[peer][b].elapsed[c],records[peer][b].receipt[c],records[peer][b].cleanup,
                records[peer][b].oldcap,records[peer][b].newcap,records[peer][b].overhead_ok);
        for (unsigned c=0;c<2;++c)
            reserve_row(api,cohort,initial,grow,sample,c,"sample",batches,contexts,calls,
                elapsed[peer][c],receipts[peer][c],cleanup[peer],records[peer][0].oldcap,
                records[peer][0].newcap,valid[peer]);
        observed^=cleanup[peer]^receipts[peer][0]^receipts[peer][1];
    }
    return all_valid;
}
static void reserve_measure(unsigned cohort) {
    reserve_routing(0); reserve_schedule_check();
    uint64_t clock_cost=reserve_clock_check(0,true);
    bool valid=true;
    puts("contract,cohort,element_bytes,series,variant,path,initial_floor,initial_count,target_floor,sample,control,row_kind,batch_or_batches,contexts,calls,elapsed_ns,receipt,cleanup_checksum,old_capacity,new_capacity,instrument_valid");
    for (unsigned wide=0;wide<2;++wide) for (unsigned series=0;series<2;++series)
      for (unsigned size=0;size<2;++size) for (unsigned op=0;op<2;++op)
        for (unsigned sample=0;sample<12;++sample) {
            uint64_t initial=(size^cohort) ? 4096 : 64;
            bool passed=reserve_sample_group(wide*8+series*4,cohort,initial,op!=0,sample,clock_cost);
            valid=valid && passed;
        }
    require(valid,"reserve fixed-panel instrument qualification");
}
'''
s=s[:start]+new+s[end:]
s=s.replace('    if (strcmp(argv[1], "check") == 0) {','''    if (strcmp(argv[1], "paired-routing-check") == 0) {
        require(argc==2,"paired routing args"); reserve_routing(0); reserve_schedule_check();
        puts("paired reserve: distinct arms and balanced schedule passed");
    } else if (strcmp(argv[1], "negative-arm-routing") == 0) {
        require(argc==3 && (strcmp(argv[2],"step")==0 || strcmp(argv[2],"cleanup")==0),"arm routing fault");
        reserve_routing(strcmp(argv[2],"step")==0 ? 1 : 2);
        puts("paired reserve: routing fault escaped");
    } else if (strcmp(argv[1], "check") == 0) {''')
(D/'driver.c').write_text(s)
(D/'driver.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='map-ecosystem.c',tofile='paired-image/driver.c')))
(D/'preparation.json').write_text(json.dumps({'inputs':pins,'driver_sha256':sha(D/'driver.c'),'namespacing':'defined global WF symbols only; object code not recompiled','timing_run':False},indent=2)+'\n')
print('prepared',sha(D/'driver.c'))
