"""One fixed two-cohort A/A panel; execute only after explicit root authorization."""
from pathlib import Path
import subprocess,json,hashlib,os,sys,time
D=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sys.argv[1:]==['--authorized-aa'],'Requires explicit timing authorization'
assert os.environ.get('WHITEFOOT_CHECK_OWNER'),'Run through repository host guard'
pins=json.loads((D/'timing-pins.json').read_text())
def snapshot():return {p:sha(D/p) for p in pins['sha256']}
assert snapshot()==pins['sha256'],'Prepared input changed; no timing started'
status={'expected':pins['expected'],'cohorts':[],'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'retries':0}
status_path=D/'timing-status.json'
# Exclusive creation makes re-running this panel an error rather than a retry.
with status_path.open('x') as f:json.dump(status,f,indent=2)
for cohort in (0,1):
 pre=snapshot();assert pre==pins['sha256'],'Input mutation before cohort'
 argv=[str(D/'paired-timed'),'reserve-measure',str(cohort)]
 start=time.monotonic()
 with (D/f'cohort-{cohort}.csv').open('xb') as out,(D/f'cohort-{cohort}.stderr').open('xb') as err:
  result=subprocess.run(argv,stdout=out,stderr=err)
 post=snapshot()
 row={'cohort':cohort,'argv':argv,'exit':result.returncode,'wall_seconds':time.monotonic()-start,'pre_sha256':pre,'post_sha256':post,'hashes_unchanged':pre==post,'stdout_sha256':sha(D/f'cohort-{cohort}.csv'),'stderr_sha256':sha(D/f'cohort-{cohort}.stderr')}
 status['cohorts'].append(row);status_path.write_text(json.dumps(status,indent=2)+'\n');print(json.dumps({k:v for k,v in row.items() if k not in ('pre_sha256','post_sha256')}),flush=True)
 assert pre==post,'Input mutation after cohort; captured data retained'
 # An invalid first cohort does not suppress the second preregistered cohort.
p=subprocess.run([sys.executable,str(D/'timing-reduce.py')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
(D/'timing-reduce.stdout').write_text(p.stdout);(D/'timing-reduce.stderr').write_text(p.stderr)
status['reduction_exit']=p.returncode;status_path.write_text(json.dumps(status,indent=2)+'\n')
print(p.stdout,end='');print(p.stderr,end='',file=sys.stderr)
sys.exit(0 if p.returncode==0 and all(x['exit']==0 for x in status['cohorts']) else 1)
