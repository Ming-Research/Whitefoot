"""Tiny independently specified growth hierarchy; never runs the benchmark."""
from pathlib import Path
import ast,json,copy
D=Path(__file__).resolve().parent
module=ast.parse((D/'timing-reduce.py').read_text())
function=next(n for n in module.body if isinstance(n,ast.FunctionDef) and n.name=='fixed_row_geometry')
ns={};exec(compile(ast.Module(body=[function],type_ignores=[]),'timing-reduce.py','exec'),ns)
check=ns['fixed_row_geometry']
# One representative batch has 256 single growth calls. Its summary covers
# 256 such batches, totaling 65,536 calls; their metadata must differ here.
valid=[{'row_kind':'batch','contexts':256,'initial_count':32,'target_floor':128,'calls':256},
       {'row_kind':'sample','contexts':256,'initial_count':32,'target_floor':128,'calls':65536}]
wrong_batch=copy.deepcopy(valid);wrong_batch[0]['calls']=65536
wrong_summary=copy.deepcopy(valid);wrong_summary[1]['calls']=256
results=[]
for name,rows,expected in [('valid-growth-hierarchy',valid,True),('wrong-batch-calls',wrong_batch,False),('wrong-summary-calls',wrong_summary,False)]:
 actual=check(rows,256,64,'grow',65536,256)
 results.append({'case':name,'rows':rows,'expected':expected,'actual':actual})
 assert actual is expected,name
(D/'reducer-fixture-results.json').write_text(json.dumps(results,indent=2)+'\n')
print('reducer geometry fixture: valid hierarchy accepted; wrong batch and summary calls independently rejected')
