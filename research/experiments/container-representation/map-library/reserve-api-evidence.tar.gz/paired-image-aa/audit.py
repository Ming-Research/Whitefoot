from pathlib import Path
import struct,json,hashlib,re
D=Path(__file__).resolve().parent;B=D.parent/'build/ecosystem'
# Reuse only the bounded Mach-O reader, not the build runner.
s=(D/'build.py').read_text(); ns={'struct':struct};exec(s[s.index('def macho('):s.index('\nbase={}')],ns);macho=ns['macho']
obj=macho(B/'wf-timed.o');linked=macho(D/'paired-timed')
osyms=obj['symbols'];lsyms={x['name']:x for x in linked['symbols']};textsec=next(x for x in obj['sections'] if x['name']=='__TEXT,__text');textid=obj['sections'].index(textsec)+1
osecbytes=bytes.fromhex(textsec['bytes']); reloc={a:b for a,b in textsec['relocations']}
def read(address,size):
 for sec in linked['sections']:
  if sec['address']<=address and address+size<=sec['address']+sec['size']:
   off=address-sec['address'];return bytes.fromhex(sec['bytes'])[off:off+size]
 raise AssertionError(hex(address))
def norm(name):return re.sub(r'^_pair_[ab]_','_',name)
starts=sorted({x['value'] for x in osyms if x['section']==textid}|{textsec['address']+textsec['size']})
report=[];mismatch=[];branchchecks=[];maskedtypes={};local_targets={};weak_stubs=[]
for sym in osyms:
 if sym['section']!=textid or not (sym['type']&1):continue
 name=sym['name'];start=sym['value'];end=next(x for x in starts if x>start);size=end-start
 aa=lsyms['_pair_a'+name]['value'];bb=lsyms['_pair_b'+name]['value'];assert aa!=bb
 av=read(aa,size);bv=read(bb,size);source=osecbytes[start-textsec['address']:end-textsec['address']]
 for offset in range(0,size,4):
  r=reloc.get(start-textsec['address']+offset)
  words=[int.from_bytes(v[offset:offset+4],'little') for v in [source,av,bv]]
  if r is None:
   if len(set(words))!=1:mismatch.append([name,offset,'nonrelocation',words])
  else:
   rt=r>>28;ext=(r>>27)&1;idx=r&0xffffff;maskedtypes[str(rt)]=maskedtypes.get(str(rt),0)+1
   masks={2:0x03ffffff,3:0x60ffffe0,4:0x003ffc00,5:0x60ffffe0,6:0x003ffc00}
   if rt not in masks:raise AssertionError(('unknown relocation',name,offset,rt))
   if len({w&~masks[rt] for w in words})!=1:mismatch.append([name,offset,'opcode',words])
   if rt==2 and ext:
    target=osyms[idx]['name'];defined=(osyms[idx]['type']&0xe)==0xe
    for arm,address,w in [('a',aa,words[1]),('b',bb,words[2])]:
     imm=w&0x3ffffff;imm=imm-(1<<26) if imm&(1<<25) else imm;actual=address+offset+imm*4
     if defined:
      mapping=dict(line.split() for line in (D/f'{arm}-timed.symbols').read_text().splitlines())
      if target in mapping:
       expect=lsyms[mapping[target]]['value']
       if actual!=expect:
        assert osyms[idx]['desc']&128,(name,arm,target,hex(actual),hex(expect))
        weak_stubs.append({'from':name,'target':target,'arm':arm,'stub':hex(actual)})
      else:
       # The linker strips these unchanged local names. Check consistent direct
       # destinations and their original instruction bytes below, not a made-up namespace.
       assert target in ('l_wf_resource_abort','l_wf_resource_record_abort'),target
       key=(arm,target);assert key not in local_targets or local_targets[key]==actual
       local_targets[key]=actual
     else:
      # Imports must resolve to the same stub/address in both arms.
      if arm=='a':import_a=actual
      else:assert actual==import_a,(name,target,actual,import_a)
     branchchecks.append({'from':name,'offset':offset,'arm':arm,'target':target,'defined_in_wf':defined,'address':hex(actual)})
 report.append({'symbol':name,'bytes':size,'A':hex(aa),'B':hex(bb),'distinct_addresses':True})
# Both local abort functions are present but stripped from the final symbol table.
# Their destinations come from every checked caller, and their instruction bodies
# are compared to the frozen object with only real relocation fields masked.
local_report=[]
for target in ('l_wf_resource_abort','l_wf_resource_record_abort'):
 sym=next(x for x in osyms if x['name']==target);start=sym['value'];end=next(x for x in starts if x>start)
 source=osecbytes[start-textsec['address']:end-textsec['address']]
 aa=local_targets['a',target];bb=local_targets['b',target];assert aa!=bb
 av=read(aa,end-start);bv=read(bb,end-start)
 for offset in range(0,end-start,4):
  r=reloc.get(start-textsec['address']+offset);words=[int.from_bytes(v[offset:offset+4],'little') for v in (source,av,bv)]
  mask=0 if r is None else {2:0x03ffffff,3:0x60ffffe0,4:0x003ffc00,5:0x60ffffe0,6:0x003ffc00}[r>>28]
  assert len({w&~mask for w in words})==1,(target,offset,'local opcode')
  if r is not None and r>>28==2 and r&(1<<27):
   destination=osyms[r&0xffffff];actuals=[]
   for arm,address,w in [('a',aa,words[1]),('b',bb,words[2])]:
    imm=w&0x3ffffff;imm=imm-(1<<26) if imm&(1<<25) else imm;actual=address+offset+imm*4;actuals.append(actual)
    if (destination['type']&0xe)==0xe:
     key=(arm,destination['name']);assert key not in local_targets or actual==local_targets[key];local_targets[key]=actual
   if (destination['type']&0xe)!=0xe:assert actuals[0]==actuals[1]
 local_report.append({'symbol':target,'bytes':end-start,'A':hex(aa),'B':hex(bb),'identical_nonrelocation_and_opcode_bits':True})
assert not mismatch,mismatch[:5]
# Static ReserveApi layout: name@0, peer@8, series@12, bool wide@16,
# prepare@24, step@32, geometry@40, load_factor@48, insert@56, finish@64; size72.
base=lsyms['_reserve_apis']['value'];tables=[]
def ptr_at(addr):
 raw=int.from_bytes(read(addr,8),'little')
 if raw in {x['value'] for x in linked['symbols']}:return raw
 # Mach-O DYLD_CHAINED_PTR_64_OFFSET rebases encode target offset in36bits.
 assert not (raw>>63),'unexpected bind'
 return 0x100000000+(raw&((1<<36)-1))
for width in range(2):
 w=['word','record'][width]
 for series in range(2):
  for arm in range(2):
   i=width*8+series*4+arm;checks={}
   for field,off,fam in [('prepare',24,'reserve'),('step',32,'reserve'),('geometry',40,'lookup'),('insert',56,'reserve'),('finish',64,'lookup')]:
    name=f'_pair_{["a","b"][arm]}_wf_map_cost_{fam}_{w}_{field}';actual=ptr_at(base+i*72+off);expected=lsyms[name]['value'];assert actual==expected,(i,field,hex(actual),hex(expected));checks[field]=name
   tables.append({'index':i,'width':w,'series':series,'callbacks':checks})
# Runtime entry alias only; no WF function reachable from reservation may call it.
alias=lsyms['_wf__main_body']['value'];assert alias==lsyms['_pair_a_wf__main_body']['value']
adjacency={r['symbol']:set() for r in report}
for edge in branchchecks:
 if edge['defined_in_wf']:adjacency[edge['from']].add(edge['target'])
roots={norm(name) for row in tables for name in row['callbacks'].values()};seen=set();todo=list(roots)
while todo:
 f=todo.pop()
 if f in seen:continue
 seen.add(f);todo.extend(adjacency.get(f,()))
assert '_wf__main_body' not in seen
assert not any(x['from'] in seen for x in weak_stubs)
result={'all_defined_functions_compared':len(report),'nonrelocated_code_exact_vs_original':True,'relocation_opcode_bits_exact':True,'relocation_types':maskedtypes,'branch_observations':len(branchchecks),'direct_branch_targets_verified':len(branchchecks)-len(weak_stubs),'same_runtime_import_targets':True,'function_addresses':report,'reserve_table':tables,'main_alias_not_reached':True,'reserve_reachable_functions':sorted(seen),'main_alias_address':hex(alias),'stripped_local_abort_paths':local_report,'weak_stubs_outside_reserve_reachability':weak_stubs,'limitations':'PAGE21/PAGEOFF12 opcode bits and original relocation symbol identities verified; linked PAGE21/PAGEOFF12 immediate targets are not independently decoded. Ordinary linker semantics are trusted for these unchanged relocations. Local abort identities are checked by consistent branch destinations and original instruction bodies, not stripped names.'}
(D/'native-audit.json').write_text(json.dumps(result,indent=2)+'\n');(D/'branch-audit.json').write_text(json.dumps(branchchecks,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['function_addresses','reserve_table','reserve_reachable_functions']},indent=2))
