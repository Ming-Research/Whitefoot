"""Independent reduction of emitted rows; never invokes the benchmark."""
from pathlib import Path
import csv,json,re,statistics,itertools,sys
D=Path(__file__).resolve().parent
EXPECTED_BATCH=148224;EXPECTED_SAMPLE=1536;U64=(1<<64)-1
PARTICIPANTS=('whitefoot-A','whitefoot-B','rust-hash-map','cpp-unordered-map')
CELLS=list(itertools.product((8,256),('native-default','aligned-hash'),(64,4096),('noop','grow')))
issues=[];clocks=[];cell_data={};totals=[]
def check(condition,issue):
 if not condition:issues.append(issue)
def fixed_row_geometry(entries,contexts,initial,path,calls,n_batches):
 return all(r['contexts']==contexts and r['initial_count']==initial//2 and
            r['target_floor']==initial*(2 if path=='grow' else 1) and
            r['calls']==(calls if r['row_kind']=='sample' else calls//n_batches)
            for r in entries)
def xor(values):
 result=0
 for value in values:result^=value
 return result
for cohort in (0,1):
 stderr=(D/f'cohort-{cohort}.stderr').read_text();rows=list(csv.DictReader((D/f'cohort-{cohort}.csv').open()))
 quantum=re.findall(r'minimum_nonzero_ns=(\d+) fault=0',stderr);maximum=re.findall(r'maximum_empty_ns=(\d+)',stderr)
 empty=[int(v) for _,v in re.findall(r'^(\d+),(\d+)$',stderr,re.M)]
 check(len(quantum)==len(maximum)==1 and len(empty)==1024,{'cohort':cohort,'issue':'complete clock evidence'})
 if not quantum or not maximum:continue
 quantum=int(quantum[0]);clock_cost=int(maximum[0]);check(quantum<=100,{'cohort':cohort,'issue':'clock quantum','ns':quantum});check(empty and max(empty)==clock_cost,{'cohort':cohort,'issue':'empty interval maximum'})
 clocks.append({'cohort':cohort,'quantum_ns':quantum,'maximum_empty_ns':clock_cost})
 groups={};counts={'batch':0,'sample':0}
 for row in rows:
  try:
   for k in ('cohort','element_bytes','initial_floor','initial_count','target_floor','sample','control','batch_or_batches','contexts','calls','elapsed_ns','receipt','cleanup_checksum','old_capacity','new_capacity','instrument_valid'):row[k]=int(row[k])
   cell=(row['element_bytes'],row['series'],row['initial_floor'],row['path'])
   check(row['contract']=='isolated-reserve' and row['cohort']==cohort and cell in CELLS and row['variant'] in PARTICIPANTS and 0<=row['sample']<12 and row['control'] in (0,1),{'cohort':cohort,'issue':'row domain'})
   key=(cell,row['variant'],row['sample'],row['control']);groups.setdefault(key,[]).append(row);counts[row['row_kind']]+=1
  except (ValueError,KeyError) as e:issues.append({'cohort':cohort,'issue':'row parse','detail':str(e)})
 check(counts=={'batch':EXPECTED_BATCH,'sample':EXPECTED_SAMPLE},{'cohort':cohort,'issue':'row counts','observed':counts});totals.append({'cohort':cohort,**counts})
 bad_overhead=0;short_aggregate=0
 for cell,participant,sample,control in itertools.product(CELLS,PARTICIPANTS,range(12),(0,1)):
  key=(cell,participant,sample,control);entries=groups.get(key,[]);batch=sorted((r for r in entries if r['row_kind']=='batch'),key=lambda r:r['batch_or_batches']);summaries=[r for r in entries if r['row_kind']=='sample']
  width,series,initial,path=cell;contexts=256 if initial==64 else 8;calls=(65536 if initial==64 else 1024) if path=='grow' else 4194304;n_batches=calls//contexts if path=='grow' else 1
  label={'cohort':cohort,'cell':cell,'participant':participant,'sample':sample,'control':control}
  check(len(summaries)==1 and len(batch)==n_batches and [r['batch_or_batches'] for r in batch]==list(range(n_batches)),{**label,'issue':'complete batch/sample coverage'})
  if len(summaries)!=1 or len(batch)!=n_batches:continue
  s=summaries[0]
  for field in ('calls','elapsed_ns','receipt'):
   check(s[field]==sum(r[field] for r in batch)&U64,{**label,'issue':'independent batch sum','field':field})
  check(s['cleanup_checksum']==xor(r['cleanup_checksum'] for r in batch),{**label,'issue':'independent cleanup xor'})
  check(s['calls']==calls and s['batch_or_batches']==n_batches,{**label,'issue':'fixed work'})
  check(fixed_row_geometry(entries,contexts,initial,path,calls,n_batches),{**label,'issue':'fixed row geometry'})
  if control==0:
   overhead=[r['elapsed_ns']>=100*clock_cost for r in batch];bad_overhead+=sum(not x for x in overhead);short_aggregate+=s['elapsed_ns']<1000000
   check(all(r['receipt']==r['calls'] for r in entries),{**label,'issue':'success receipt totals'})
   check(all(r['instrument_valid']==int(ok) for r,ok in zip(batch,overhead)) and s['instrument_valid']==int(all(overhead) and s['elapsed_ns']>=1000000),{**label,'issue':'independent validity flags'})
   cell_data.setdefault((cohort,cell,participant),[]).append(s['elapsed_ns']/calls)
  else:
   check(all(r['receipt']==(((r['new_capacity']<<32)|r['initial_count'])*r['calls'])&U64 for r in batch),{**label,'issue':'snapshot receipt totals'})
   real=groups.get((cell,participant,sample,0),[]);check(len(real)==len(entries) and all(a['cleanup_checksum']==b['cleanup_checksum'] and a['old_capacity']==b['old_capacity'] and a['new_capacity']==b['new_capacity'] and a['instrument_valid']==b['instrument_valid'] for a,b in zip(entries,real)),{**label,'issue':'control and real observation consistency'})
 check(bad_overhead==0,{'cohort':cohort,'issue':'overhead exceeds 1 percent','batches':bad_overhead});check(short_aggregate==0,{'cohort':cohort,'issue':'real aggregate below 1 ms','samples':short_aggregate})
summary=[]
for cell in CELLS:
 distributions={};cohort_ratios=[]
 for participant in PARTICIPANTS:
  pair=[]
  for cohort in (0,1):
   values=cell_data.get((cohort,cell,participant),[])
   if len(values)!=12:continue
   d={'cohort':cohort,'minimum_ns_per_call':min(values),'median_ns_per_call':statistics.median(values),'maximum_ns_per_call':max(values),'all_samples_ns_per_call':values};pair.append(d)
  distributions[participant]=pair
  if len(pair)==2:
   medians=[d['median_ns_per_call'] for d in pair];spread=max(medians)/min(medians)-1
   check(spread<=0.10,{'cell':cell,'participant':participant,'issue':'cohort median spread exceeds 10 percent','spread':spread})
 for cohort in (0,1):
  a=cell_data.get((cohort,cell,'whitefoot-A'),[]);b=cell_data.get((cohort,cell,'whitefoot-B'),[])
  if len(a)==len(b)==12:
   check(max(min(a),min(b))<=min(max(a),max(b)),{'cell':cell,'cohort':cohort,'issue':'separated A/A full ranges'})
   cohort_ratios.append(statistics.median(b)/statistics.median(a))
 if len(cohort_ratios)==2:
  spread=max(cohort_ratios)/min(cohort_ratios)-1;check(spread<=0.10,{'cell':cell,'issue':'B/A cohort ratio spread exceeds 10 percent','spread':spread})
 summary.append({'cell':cell,'participants':distributions,'B_over_A_cohort_median_ratios':cohort_ratios})
status=json.loads((D/'timing-status.json').read_text());check(len(status['cohorts'])==2 and all(r['exit']==0 and r['hashes_unchanged'] for r in status['cohorts']),{'issue':'both direct exits zero and inputs unchanged'})
result={'qualified':not issues,'expected_per_cohort':{'batch_rows':EXPECTED_BATCH,'sample_rows':EXPECTED_SAMPLE,'data_rows':EXPECTED_BATCH+EXPECTED_SAMPLE},'observed_rows':totals,'clocks':clocks,'issues':issues,'cells':summary}
(D/'timing-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('cells','issues')}));print('adverse_observations',len(issues));sys.exit(0 if not issues else 1)
