00000000000098f4 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743>:
    98f4: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    98f8: a90157f6     	stp	x22, x21, [sp, #0x10]
    98fc: a9024ff4     	stp	x20, x19, [sp, #0x20]
    9900: a9037bfd     	stp	x29, x30, [sp, #0x30]
    9904: aa0103f4     	mov	x20, x1
    9908: aa0003f3     	mov	x19, x0
    990c: a9405817     	ldp	x23, x22, [x0]
    9910: eb0102df     	cmp	x22, x1
    9914: 54000302     	b.hs	0x9974 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x80>
    9918: f9400a75     	ldr	x21, [x19, #0x10]
    991c: 8b141288     	add	x8, x20, x20, lsl #4
    9920: d37ced01     	lsl	x1, x8, #4
    9924: f10002df     	cmp	x22, #0x0
    9928: fa5612e0     	ccmp	x23, x22, #0x0, ne
    992c: 540001c0     	b.eq	0x9964 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x70>
    9930: aa0103e0     	mov	x0, x1
    9934: 94000000     	bl	0x9934 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x40>
		0000000000009934:  ARM64_RELOC_BRANCH26	_malloc
    9938: b4000560     	cbz	x0, 0x99e4 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xf0>
    993c: b40001b6     	cbz	x22, 0x9970 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x7c>
    9940: 8b1712e8     	add	x8, x23, x23, lsl #4
    9944: d37ced02     	lsl	x2, x8, #4
    9948: aa0003f6     	mov	x22, x0
    994c: aa1503e1     	mov	x1, x21
    9950: 94000000     	bl	0x9950 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x5c>
		0000000000009950:  ARM64_RELOC_BRANCH26	_memcpy
    9954: aa1503e0     	mov	x0, x21
    9958: 94000000     	bl	0x9958 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x64>
		0000000000009958:  ARM64_RELOC_BRANCH26	_free
    995c: aa1603e0     	mov	x0, x22
    9960: 14000004     	b	0x9970 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x7c>
    9964: aa1503e0     	mov	x0, x21
    9968: 94000000     	bl	0x9968 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x74>
		0000000000009968:  ARM64_RELOC_BRANCH26	_realloc
    996c: b40003c0     	cbz	x0, 0x99e4 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xf0>
    9970: a9008274     	stp	x20, x0, [x19, #0x8]
    9974: eb1402ff     	cmp	x23, x20
    9978: 540002a2     	b.hs	0x99cc <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xd8>
    997c: f9400a68     	ldr	x8, [x19, #0x10]
    9980: 52802209     	mov	w9, #0x110              ; =272
    9984: 9b0922e8     	madd	x8, x23, x9, x8
    9988: 91002108     	add	x8, x8, #0x8
    998c: 6f00e400     	movi.2d	v0, #0000000000000000
    9990: b81f811f     	stur	wzr, [x8, #-0x8]
    9994: 910006f7     	add	x23, x23, #0x1
    9998: ad000100     	stp	q0, q0, [x8]
    999c: ad010100     	stp	q0, q0, [x8, #0x20]
    99a0: ad020100     	stp	q0, q0, [x8, #0x40]
    99a4: ad030100     	stp	q0, q0, [x8, #0x60]
    99a8: ad040100     	stp	q0, q0, [x8, #0x80]
    99ac: ad050100     	stp	q0, q0, [x8, #0xa0]
    99b0: ad060100     	stp	q0, q0, [x8, #0xc0]
    99b4: ad070100     	stp	q0, q0, [x8, #0xe0]
    99b8: f900811f     	str	xzr, [x8, #0x100]
    99bc: 91044108     	add	x8, x8, #0x110
    99c0: eb17029f     	cmp	x20, x23
    99c4: 54fffe61     	b.ne	0x9990 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x9c>
    99c8: f9000277     	str	x23, [x19]
    99cc: 52800000     	mov	w0, #0x0                ; =0
    99d0: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    99d4: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    99d8: a94157f6     	ldp	x22, x21, [sp, #0x10]
    99dc: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    99e0: d65f03c0     	ret
    99e4: 94000000     	bl	0x99e4 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xf0>
		00000000000099e4:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

