000000000000736c <_wf_map_cost_reserve_step$instance$e194368921a477a7>:
    736c: 92840008     	mov	x8, #-0x2001            ; =-8193
    7370: 8b080028     	add	x8, x1, x8
    7374: b140091f     	cmn	x8, #0x2, lsl #12       ; =0x2000
    7378: 54000243     	b.lo	0x73c0 <_wf_map_cost_reserve_step$instance$e194368921a477a7+0x54>
    737c: 531e7428     	lsl	w8, w1, #2
    7380: 51001108     	sub	w8, w8, #0x4
    7384: 121e3508     	and	w8, w8, #0xfffc
    7388: 52955569     	mov	w9, #0xaaab             ; =43691
    738c: 1b097d08     	mul	w8, w8, w9
    7390: 53117d08     	lsr	w8, w8, #17
    7394: 11000501     	add	w1, w8, #0x1
    7398: f9400008     	ldr	x8, [x0]
    739c: eb01011f     	cmp	x8, x1
    73a0: 54000102     	b.hs	0x73c0 <_wf_map_cost_reserve_step$instance$e194368921a477a7+0x54>
    73a4: a9bf7bfd     	stp	x29, x30, [sp, #-0x10]!
    73a8: 9100a002     	add	x2, x0, #0x28
    73ac: 94000000     	bl	0x73ac <_wf_map_cost_reserve_step$instance$e194368921a477a7+0x40>
		00000000000073ac:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    73b0: a8c17bfd     	ldp	x29, x30, [sp], #0x10
    73b4: 34000060     	cbz	w0, 0x73c0 <_wf_map_cost_reserve_step$instance$e194368921a477a7+0x54>
    73b8: d2800000     	mov	x0, #0x0                ; =0
    73bc: d65f03c0     	ret
    73c0: 52800020     	mov	w0, #0x1                ; =1
    73c4: d65f03c0     	ret

