0000000000008ed8 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca>:
    8ed8: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    8edc: a90157f6     	stp	x22, x21, [sp, #0x10]
    8ee0: a9024ff4     	stp	x20, x19, [sp, #0x20]
    8ee4: a9037bfd     	stp	x29, x30, [sp, #0x30]
    8ee8: aa0103f4     	mov	x20, x1
    8eec: aa0003f3     	mov	x19, x0
    8ef0: a9405817     	ldp	x23, x22, [x0]
    8ef4: eb0102df     	cmp	x22, x1
    8ef8: 54000302     	b.hs	0x8f58 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x80>
    8efc: f9400a75     	ldr	x21, [x19, #0x10]
    8f00: 8b140688     	add	x8, x20, x20, lsl #1
    8f04: d37df101     	lsl	x1, x8, #3
    8f08: f10002df     	cmp	x22, #0x0
    8f0c: fa5612e0     	ccmp	x23, x22, #0x0, ne
    8f10: 540001c0     	b.eq	0x8f48 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x70>
    8f14: aa0103e0     	mov	x0, x1
    8f18: 94000000     	bl	0x8f18 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x40>
		0000000000008f18:  ARM64_RELOC_BRANCH26	_malloc
    8f1c: b4000420     	cbz	x0, 0x8fa0 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xc8>
    8f20: b40001b6     	cbz	x22, 0x8f54 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x7c>
    8f24: 8b1706e8     	add	x8, x23, x23, lsl #1
    8f28: d37df102     	lsl	x2, x8, #3
    8f2c: aa0003f6     	mov	x22, x0
    8f30: aa1503e1     	mov	x1, x21
    8f34: 94000000     	bl	0x8f34 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x5c>
		0000000000008f34:  ARM64_RELOC_BRANCH26	_memcpy
    8f38: aa1503e0     	mov	x0, x21
    8f3c: 94000000     	bl	0x8f3c <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x64>
		0000000000008f3c:  ARM64_RELOC_BRANCH26	_free
    8f40: aa1603e0     	mov	x0, x22
    8f44: 14000004     	b	0x8f54 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x7c>
    8f48: aa1503e0     	mov	x0, x21
    8f4c: 94000000     	bl	0x8f4c <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x74>
		0000000000008f4c:  ARM64_RELOC_BRANCH26	_realloc
    8f50: b4000280     	cbz	x0, 0x8fa0 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xc8>
    8f54: a9008274     	stp	x20, x0, [x19, #0x8]
    8f58: eb1402ff     	cmp	x23, x20
    8f5c: 54000162     	b.hs	0x8f88 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xb0>
    8f60: f9400a68     	ldr	x8, [x19, #0x10]
    8f64: 52800309     	mov	w9, #0x18               ; =24
    8f68: 9b0922e8     	madd	x8, x23, x9, x8
    8f6c: 91002108     	add	x8, x8, #0x8
    8f70: b81f811f     	stur	wzr, [x8, #-0x8]
    8f74: 910006f7     	add	x23, x23, #0x1
    8f78: a881fd1f     	stp	xzr, xzr, [x8], #0x18
    8f7c: eb17029f     	cmp	x20, x23
    8f80: 54ffff81     	b.ne	0x8f70 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x98>
    8f84: f9000277     	str	x23, [x19]
    8f88: 52800000     	mov	w0, #0x0                ; =0
    8f8c: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    8f90: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    8f94: a94157f6     	ldp	x22, x21, [sp, #0x10]
    8f98: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    8f9c: d65f03c0     	ret
    8fa0: 94000000     	bl	0x8fa0 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xc8>
		0000000000008fa0:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

