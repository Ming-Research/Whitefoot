0000000000009660 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd>:
    9660: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    9664: a90157f6     	stp	x22, x21, [sp, #0x10]
    9668: a9024ff4     	stp	x20, x19, [sp, #0x20]
    966c: a9037bfd     	stp	x29, x30, [sp, #0x30]
    9670: aa0103f4     	mov	x20, x1
    9674: aa0003f3     	mov	x19, x0
    9678: a9405817     	ldp	x23, x22, [x0]
    967c: eb0102df     	cmp	x22, x1
    9680: 54000302     	b.hs	0x96e0 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x80>
    9684: f9400a75     	ldr	x21, [x19, #0x10]
    9688: 8b140688     	add	x8, x20, x20, lsl #1
    968c: d37df101     	lsl	x1, x8, #3
    9690: f10002df     	cmp	x22, #0x0
    9694: fa5612e0     	ccmp	x23, x22, #0x0, ne
    9698: 540001c0     	b.eq	0x96d0 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x70>
    969c: aa0103e0     	mov	x0, x1
    96a0: 94000000     	bl	0x96a0 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x40>
		00000000000096a0:  ARM64_RELOC_BRANCH26	_malloc
    96a4: b4000640     	cbz	x0, 0x976c <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x10c>
    96a8: b40001b6     	cbz	x22, 0x96dc <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x7c>
    96ac: 8b1706e8     	add	x8, x23, x23, lsl #1
    96b0: d37df102     	lsl	x2, x8, #3
    96b4: aa0003f6     	mov	x22, x0
    96b8: aa1503e1     	mov	x1, x21
    96bc: 94000000     	bl	0x96bc <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x5c>
		00000000000096bc:  ARM64_RELOC_BRANCH26	_memcpy
    96c0: aa1503e0     	mov	x0, x21
    96c4: 94000000     	bl	0x96c4 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x64>
		00000000000096c4:  ARM64_RELOC_BRANCH26	_free
    96c8: aa1603e0     	mov	x0, x22
    96cc: 14000004     	b	0x96dc <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x7c>
    96d0: aa1503e0     	mov	x0, x21
    96d4: 94000000     	bl	0x96d4 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x74>
		00000000000096d4:  ARM64_RELOC_BRANCH26	_realloc
    96d8: b40004a0     	cbz	x0, 0x976c <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x10c>
    96dc: a9008274     	stp	x20, x0, [x19, #0x8]
    96e0: eb17028a     	subs	x10, x20, x23
    96e4: 54000389     	b.ls	0x9754 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xf4>
    96e8: f9400a69     	ldr	x9, [x19, #0x10]
    96ec: aa1703e8     	mov	x8, x23
    96f0: f100115f     	cmp	x10, #0x4
    96f4: 54000203     	b.lo	0x9734 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xd4>
    96f8: 927ef54b     	and	x11, x10, #0xfffffffffffffffc
    96fc: 8b0b02e8     	add	x8, x23, x11
    9700: 5280030c     	mov	w12, #0x18              ; =24
    9704: 9b0c26ec     	madd	x12, x23, x12, x9
    9708: 9100c18c     	add	x12, x12, #0x30
    970c: aa0b03ed     	mov	x13, x11
    9710: b81d019f     	stur	wzr, [x12, #-0x30]
    9714: b81e819f     	stur	wzr, [x12, #-0x18]
    9718: b900019f     	str	wzr, [x12]
    971c: b900199f     	str	wzr, [x12, #0x18]
    9720: 9101818c     	add	x12, x12, #0x60
    9724: f10011ad     	subs	x13, x13, #0x4
    9728: 54ffff41     	b.ne	0x9710 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xb0>
    972c: eb0b015f     	cmp	x10, x11
    9730: 54000100     	b.eq	0x9750 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xf0>
    9734: 5280030a     	mov	w10, #0x18              ; =24
    9738: 9b0a2509     	madd	x9, x8, x10, x9
    973c: cb08028a     	sub	x10, x20, x8
    9740: b801853f     	str	wzr, [x9], #0x18
    9744: 91000508     	add	x8, x8, #0x1
    9748: f100054a     	subs	x10, x10, #0x1
    974c: 54ffffa1     	b.ne	0x9740 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xe0>
    9750: f9000268     	str	x8, [x19]
    9754: 52800000     	mov	w0, #0x0                ; =0
    9758: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    975c: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    9760: a94157f6     	ldp	x22, x21, [sp, #0x10]
    9764: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    9768: d65f03c0     	ret
    976c: 94000000     	bl	0x976c <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x10c>
		000000000000976c:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

