0000000000009344 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd>:
    9344: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    9348: a90157f6     	stp	x22, x21, [sp, #0x10]
    934c: a9024ff4     	stp	x20, x19, [sp, #0x20]
    9350: a9037bfd     	stp	x29, x30, [sp, #0x30]
    9354: aa0103f4     	mov	x20, x1
    9358: aa0003f3     	mov	x19, x0
    935c: a9405817     	ldp	x23, x22, [x0]
    9360: eb0102df     	cmp	x22, x1
    9364: 54000302     	b.hs	0x93c4 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x80>
    9368: f9400a75     	ldr	x21, [x19, #0x10]
    936c: 8b140688     	add	x8, x20, x20, lsl #1
    9370: d37df101     	lsl	x1, x8, #3
    9374: f10002df     	cmp	x22, #0x0
    9378: fa5612e0     	ccmp	x23, x22, #0x0, ne
    937c: 540001c0     	b.eq	0x93b4 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x70>
    9380: aa0103e0     	mov	x0, x1
    9384: 94000000     	bl	0x9384 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x40>
		0000000000009384:  ARM64_RELOC_BRANCH26	_malloc
    9388: b4000420     	cbz	x0, 0x940c <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xc8>
    938c: b40001b6     	cbz	x22, 0x93c0 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x7c>
    9390: 8b1706e8     	add	x8, x23, x23, lsl #1
    9394: d37df102     	lsl	x2, x8, #3
    9398: aa0003f6     	mov	x22, x0
    939c: aa1503e1     	mov	x1, x21
    93a0: 94000000     	bl	0x93a0 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x5c>
		00000000000093a0:  ARM64_RELOC_BRANCH26	_memcpy
    93a4: aa1503e0     	mov	x0, x21
    93a8: 94000000     	bl	0x93a8 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x64>
		00000000000093a8:  ARM64_RELOC_BRANCH26	_free
    93ac: aa1603e0     	mov	x0, x22
    93b0: 14000004     	b	0x93c0 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x7c>
    93b4: aa1503e0     	mov	x0, x21
    93b8: 94000000     	bl	0x93b8 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x74>
		00000000000093b8:  ARM64_RELOC_BRANCH26	_realloc
    93bc: b4000280     	cbz	x0, 0x940c <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xc8>
    93c0: a9008274     	stp	x20, x0, [x19, #0x8]
    93c4: eb1402ff     	cmp	x23, x20
    93c8: 54000162     	b.hs	0x93f4 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xb0>
    93cc: f9400a68     	ldr	x8, [x19, #0x10]
    93d0: 52800309     	mov	w9, #0x18               ; =24
    93d4: 9b0922e8     	madd	x8, x23, x9, x8
    93d8: 91002108     	add	x8, x8, #0x8
    93dc: b81f811f     	stur	wzr, [x8, #-0x8]
    93e0: 910006f7     	add	x23, x23, #0x1
    93e4: a881fd1f     	stp	xzr, xzr, [x8], #0x18
    93e8: eb17029f     	cmp	x20, x23
    93ec: 54ffff81     	b.ne	0x93dc <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x98>
    93f0: f9000277     	str	x23, [x19]
    93f4: 52800000     	mov	w0, #0x0                ; =0
    93f8: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    93fc: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    9400: a94157f6     	ldp	x22, x21, [sp, #0x10]
    9404: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    9408: d65f03c0     	ret
    940c: 94000000     	bl	0x940c <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xc8>
		000000000000940c:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

