00000000000072d8 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66>:
    72d8: a9ba6ffc     	stp	x28, x27, [sp, #-0x60]!
    72dc: a90167fa     	stp	x26, x25, [sp, #0x10]
    72e0: a9025ff8     	stp	x24, x23, [sp, #0x20]
    72e4: a90357f6     	stp	x22, x21, [sp, #0x30]
    72e8: a9044ff4     	stp	x20, x19, [sp, #0x40]
    72ec: a9057bfd     	stp	x29, x30, [sp, #0x50]
    72f0: d10f43ff     	sub	sp, sp, #0x3d0
    72f4: aa0303f4     	mov	x20, x3
    72f8: aa0203f3     	mov	x19, x2
    72fc: aa0003f5     	mov	x21, x0
    7300: 92840008     	mov	x8, #-0x2001            ; =-8193
    7304: 8b080028     	add	x8, x1, x8
    7308: b140091f     	cmn	x8, #0x2, lsl #12       ; =0x2000
    730c: 54000182     	b.hs	0x733c <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x64>
    7310: d2800016     	mov	x22, #0x0               ; =0
    7314: d28f82a8     	mov	x8, #0x7c15             ; =31765
    7318: f2afe948     	movk	x8, #0x7f4a, lsl #16
    731c: f2cf3728     	movk	x8, #0x79b9, lsl #32
    7320: f2f3c6e8     	movk	x8, #0x9e37, lsl #48
    7324: ca080288     	eor	x8, x20, x8
    7328: f9009be8     	str	x8, [sp, #0x130]
    732c: 3904e3ff     	strb	wzr, [sp, #0x138]
    7330: 90000000     	adrp	x0, 0x7000 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x124>
		0000000000007330:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    7334: 91000000     	add	x0, x0, #0x0
		0000000000007334:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    7338: 14000023     	b	0x73c4 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0xec>
    733c: 531e7428     	lsl	w8, w1, #2
    7340: 51001108     	sub	w8, w8, #0x4
    7344: 121e3508     	and	w8, w8, #0xfffc
    7348: 52955569     	mov	w9, #0xaaab             ; =43691
    734c: 1b097d08     	mul	w8, w8, w9
    7350: 53117d08     	lsr	w8, w8, #17
    7354: 11000516     	add	w22, w8, #0x1
    7358: d28f82a8     	mov	x8, #0x7c15             ; =31765
    735c: f2afe948     	movk	x8, #0x7f4a, lsl #16
    7360: f2cf3728     	movk	x8, #0x79b9, lsl #32
    7364: f2f3c6e8     	movk	x8, #0x9e37, lsl #48
    7368: ca080288     	eor	x8, x20, x8
    736c: f9009be8     	str	x8, [sp, #0x130]
    7370: 3904e3ff     	strb	wzr, [sp, #0x138]
    7374: 8b3652c8     	add	x8, x22, w22, uxtw #4
    7378: d37ced00     	lsl	x0, x8, #4
    737c: 94000000     	bl	0x737c <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0xa4>
		000000000000737c:  ARM64_RELOC_BRANCH26	_malloc
    7380: b4001800     	cbz	x0, 0x7680 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x3a8>
    7384: 91002008     	add	x8, x0, #0x8
    7388: 6f00e400     	movi.2d	v0, #0000000000000000
    738c: aa1603e9     	mov	x9, x22
    7390: b81f811f     	stur	wzr, [x8, #-0x8]
    7394: ad000100     	stp	q0, q0, [x8]
    7398: ad010100     	stp	q0, q0, [x8, #0x20]
    739c: ad020100     	stp	q0, q0, [x8, #0x40]
    73a0: ad030100     	stp	q0, q0, [x8, #0x60]
    73a4: ad040100     	stp	q0, q0, [x8, #0x80]
    73a8: ad050100     	stp	q0, q0, [x8, #0xa0]
    73ac: ad060100     	stp	q0, q0, [x8, #0xc0]
    73b0: ad070100     	stp	q0, q0, [x8, #0xe0]
    73b4: f900811f     	str	xzr, [x8, #0x100]
    73b8: 91044108     	add	x8, x8, #0x110
    73bc: f1000529     	subs	x9, x9, #0x1
    73c0: 54fffe81     	b.ne	0x7390 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0xb8>
    73c4: a910dbf6     	stp	x22, x22, [sp, #0x108]
    73c8: a9127fff     	stp	xzr, xzr, [sp, #0x120]
    73cc: f9008fe0     	str	x0, [sp, #0x118]
    73d0: b4001353     	cbz	x19, 0x7638 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x360>
    73d4: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x124>
		00000000000073d4:  ARM64_RELOC_PAGE21	lCPI65_0
    73d8: 3dc00100     	ldr	q0, [x8]
		00000000000073d8:  ARM64_RELOC_PAGEOFF12	lCPI65_0
    73dc: 3d803fe0     	str	q0, [sp, #0xf0]
    73e0: 910943f7     	add	x23, sp, #0x250
    73e4: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x124>
		00000000000073e4:  ARM64_RELOC_PAGE21	lCPI65_1
    73e8: 3dc00100     	ldr	q0, [x8]
		00000000000073e8:  ARM64_RELOC_PAGEOFF12	lCPI65_1
    73ec: 3d803be0     	str	q0, [sp, #0xe0]
    73f0: 910943f8     	add	x24, sp, #0x250
    73f4: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x124>
		00000000000073f4:  ARM64_RELOC_PAGE21	lCPI65_2
    73f8: 3dc00100     	ldr	q0, [x8]
		00000000000073f8:  ARM64_RELOC_PAGEOFF12	lCPI65_2
    73fc: 3d8037e0     	str	q0, [sp, #0xd0]
    7400: 9104a319     	add	x25, x24, #0x128
    7404: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x124>
		0000000000007404:  ARM64_RELOC_PAGE21	lCPI65_3
    7408: 3dc00100     	ldr	q0, [x8]
		0000000000007408:  ARM64_RELOC_PAGEOFF12	lCPI65_3
    740c: 3d8033e0     	str	q0, [sp, #0xc0]
    7410: 52800036     	mov	w22, #0x1               ; =1
    7414: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x124>
		0000000000007414:  ARM64_RELOC_PAGE21	lCPI65_4
    7418: 3dc00100     	ldr	q0, [x8]
		0000000000007418:  ARM64_RELOC_PAGEOFF12	lCPI65_4
    741c: 3d802fe0     	str	q0, [sp, #0xb0]
    7420: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x124>
		0000000000007420:  ARM64_RELOC_PAGE21	lCPI65_5
    7424: 3dc00100     	ldr	q0, [x8]
		0000000000007424:  ARM64_RELOC_PAGEOFF12	lCPI65_5
    7428: 3d802be0     	str	q0, [sp, #0xa0]
    742c: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x124>
		000000000000742c:  ARM64_RELOC_PAGE21	lCPI65_6
    7430: 3dc00100     	ldr	q0, [x8]
		0000000000007430:  ARM64_RELOC_PAGEOFF12	lCPI65_6
    7434: 3d8027e0     	str	q0, [sp, #0x90]
    7438: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x124>
		0000000000007438:  ARM64_RELOC_PAGE21	lCPI65_7
    743c: 3dc00100     	ldr	q0, [x8]
		000000000000743c:  ARM64_RELOC_PAGEOFF12	lCPI65_7
    7440: 3d8023e0     	str	q0, [sp, #0x80]
    7444: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x124>
		0000000000007444:  ARM64_RELOC_PAGE21	lCPI65_8
    7448: 3dc00100     	ldr	q0, [x8]
		0000000000007448:  ARM64_RELOC_PAGEOFF12	lCPI65_8
    744c: 3d801fe0     	str	q0, [sp, #0x70]
    7450: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x124>
		0000000000007450:  ARM64_RELOC_PAGE21	lCPI65_9
    7454: 3dc00100     	ldr	q0, [x8]
		0000000000007454:  ARM64_RELOC_PAGEOFF12	lCPI65_9
    7458: 3d801be0     	str	q0, [sp, #0x60]
    745c: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x124>
		000000000000745c:  ARM64_RELOC_PAGE21	lCPI65_10
    7460: 3dc00100     	ldr	q0, [x8]
		0000000000007460:  ARM64_RELOC_PAGEOFF12	lCPI65_10
    7464: 3d8017e0     	str	q0, [sp, #0x50]
    7468: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x124>
		0000000000007468:  ARM64_RELOC_PAGE21	lCPI65_11
    746c: 3dc00100     	ldr	q0, [x8]
		000000000000746c:  ARM64_RELOC_PAGEOFF12	lCPI65_11
    7470: 3d8013e0     	str	q0, [sp, #0x40]
    7474: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x124>
		0000000000007474:  ARM64_RELOC_PAGE21	lCPI65_12
    7478: 3dc00100     	ldr	q0, [x8]
		0000000000007478:  ARM64_RELOC_PAGEOFF12	lCPI65_12
    747c: 3d800fe0     	str	q0, [sp, #0x30]
    7480: 5284001a     	mov	w26, #0x2000            ; =8192
    7484: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x124>
		0000000000007484:  ARM64_RELOC_PAGE21	lCPI65_13
    7488: 3dc00100     	ldr	q0, [x8]
		0000000000007488:  ARM64_RELOC_PAGEOFF12	lCPI65_13
    748c: 3d800be0     	str	q0, [sp, #0x20]
    7490: aa1303fb     	mov	x27, x19
    7494: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x124>
		0000000000007494:  ARM64_RELOC_PAGE21	lCPI65_14
    7498: 3dc00100     	ldr	q0, [x8]
		0000000000007498:  ARM64_RELOC_PAGEOFF12	lCPI65_14
    749c: 3d8007e0     	str	q0, [sp, #0x10]
    74a0: aa1403fc     	mov	x28, x20
    74a4: 14000014     	b	0x74f4 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x21c>
    74a8: f140083f     	cmp	x1, #0x2, lsl #12       ; =0x2000
    74ac: 9a9a3028     	csel	x8, x1, x26, lo
    74b0: d37ff901     	lsl	x1, x8, #1
    74b4: 910423e0     	add	x0, sp, #0x108
    74b8: 9104c3e2     	add	x2, sp, #0x130
    74bc: 94000000     	bl	0x74bc <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x1e4>
		00000000000074bc:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    74c0: b903cbe0     	str	w0, [sp, #0x3c8]
    74c4: 390f33e1     	strb	w1, [sp, #0x3cc]
    74c8: 390f37e2     	strb	w2, [sp, #0x3cd]
    74cc: 910503e0     	add	x0, sp, #0x140
    74d0: 910423e1     	add	x1, sp, #0x108
    74d4: 910943e3     	add	x3, sp, #0x250
    74d8: 9104c3e4     	add	x4, sp, #0x130
    74dc: aa1603e2     	mov	x2, x22
    74e0: 94000000     	bl	0x74e0 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x208>
		00000000000074e0:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
    74e4: 9100079c     	add	x28, x28, #0x1
    74e8: 91000ad6     	add	x22, x22, #0x2
    74ec: f100077b     	subs	x27, x27, #0x1
    74f0: 54000a40     	b.eq	0x7638 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x360>
    74f4: 4e080f80     	dup.2d	v0, x28
    74f8: 91007f88     	add	x8, x28, #0x1f
    74fc: 3dc03fe1     	ldr	q1, [sp, #0xf0]
    7500: 4ee18401     	add.2d	v1, v0, v1
    7504: 3c8082e1     	stur	q1, [x23, #0x8]
    7508: 3dc03be1     	ldr	q1, [sp, #0xe0]
    750c: 4ee18401     	add.2d	v1, v0, v1
    7510: 3c8182e1     	stur	q1, [x23, #0x18]
    7514: 3dc037e1     	ldr	q1, [sp, #0xd0]
    7518: 4ee18401     	add.2d	v1, v0, v1
    751c: 3c8282e1     	stur	q1, [x23, #0x28]
    7520: 3dc033e1     	ldr	q1, [sp, #0xc0]
    7524: 4ee18401     	add.2d	v1, v0, v1
    7528: 3c8382e1     	stur	q1, [x23, #0x38]
    752c: 3dc02fe1     	ldr	q1, [sp, #0xb0]
    7530: 4ee18401     	add.2d	v1, v0, v1
    7534: 3c8482e1     	stur	q1, [x23, #0x48]
    7538: 3dc02be1     	ldr	q1, [sp, #0xa0]
    753c: 4ee18401     	add.2d	v1, v0, v1
    7540: 3c8582e1     	stur	q1, [x23, #0x58]
    7544: 3dc027e1     	ldr	q1, [sp, #0x90]
    7548: 4ee18401     	add.2d	v1, v0, v1
    754c: 3c8682e1     	stur	q1, [x23, #0x68]
    7550: 3dc023e1     	ldr	q1, [sp, #0x80]
    7554: 4ee18401     	add.2d	v1, v0, v1
    7558: 3c8782e1     	stur	q1, [x23, #0x78]
    755c: 3dc01fe1     	ldr	q1, [sp, #0x70]
    7560: 4ee18401     	add.2d	v1, v0, v1
    7564: 3c8882e1     	stur	q1, [x23, #0x88]
    7568: 3dc01be1     	ldr	q1, [sp, #0x60]
    756c: 4ee18401     	add.2d	v1, v0, v1
    7570: 3c8982e1     	stur	q1, [x23, #0x98]
    7574: 3dc017e1     	ldr	q1, [sp, #0x50]
    7578: 4ee18401     	add.2d	v1, v0, v1
    757c: 3c8a82e1     	stur	q1, [x23, #0xa8]
    7580: 3dc013e1     	ldr	q1, [sp, #0x40]
    7584: 4ee18401     	add.2d	v1, v0, v1
    7588: 3c8b82e1     	stur	q1, [x23, #0xb8]
    758c: 3dc00fe1     	ldr	q1, [sp, #0x30]
    7590: 4ee18401     	add.2d	v1, v0, v1
    7594: 3c8c82e1     	stur	q1, [x23, #0xc8]
    7598: 3dc00be1     	ldr	q1, [sp, #0x20]
    759c: 4ee18401     	add.2d	v1, v0, v1
    75a0: 3c8d82e1     	stur	q1, [x23, #0xd8]
    75a4: 3dc007e1     	ldr	q1, [sp, #0x10]
    75a8: 4ee18400     	add.2d	v0, v0, v1
    75ac: 3c8e82e0     	stur	q0, [x23, #0xe8]
    75b0: f9012bfc     	str	x28, [sp, #0x250]
    75b4: f901a7e8     	str	x8, [sp, #0x348]
    75b8: f94087e1     	ldr	x1, [sp, #0x108]
    75bc: f94097e8     	ldr	x8, [sp, #0x128]
    75c0: f9009308     	str	x8, [x24, #0x120]
    75c4: 910067e9     	add	x9, sp, #0x19
    75c8: 3ccff120     	ldur	q0, [x9, #0xff]
    75cc: 910027e9     	add	x9, sp, #0x9
    75d0: 3ccff121     	ldur	q1, [x9, #0xff]
    75d4: ad080301     	stp	q1, q0, [x24, #0x100]
    75d8: f9001328     	str	x8, [x25, #0x20]
    75dc: f941b7e8     	ldr	x8, [sp, #0x368]
    75e0: f941cfe9     	ldr	x9, [sp, #0x398]
    75e4: ab090108     	adds	x8, x8, x9
    75e8: da9f3109     	csinv	x9, x8, xzr, lo
    75ec: d34efc28     	lsr	x8, x1, #14
    75f0: ad000321     	stp	q1, q0, [x25]
    75f4: b5fff6c8     	cbnz	x8, 0x74cc <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x1f4>
    75f8: cb410828     	sub	x8, x1, x1, lsr #2
    75fc: eb08013f     	cmp	x9, x8
    7600: 54fff663     	b.lo	0x74cc <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x1f4>
    7604: f94097e9     	ldr	x9, [sp, #0x128]
    7608: f900bb09     	str	x9, [x24, #0x170]
    760c: 910067e9     	add	x9, sp, #0x19
    7610: 3ccff120     	ldur	q0, [x9, #0xff]
    7614: 910027e9     	add	x9, sp, #0x9
    7618: 3ccff121     	ldur	q1, [x9, #0xff]
    761c: ad0a8301     	stp	q1, q0, [x24, #0x150]
    7620: f941dfe9     	ldr	x9, [sp, #0x3b8]
    7624: eb48053f     	cmp	x9, x8, lsr #1
    7628: 54fff463     	b.lo	0x74b4 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x1dc>
    762c: b5fff3e1     	cbnz	x1, 0x74a8 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x1d0>
    7630: 52800021     	mov	w1, #0x1                ; =1
    7634: 17ffffa0     	b	0x74b4 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x1dc>
    7638: 910027e8     	add	x8, sp, #0x9
    763c: 3ccff100     	ldur	q0, [x8, #0xff]
    7640: 910067e8     	add	x8, sp, #0x19
    7644: 3ccff101     	ldur	q1, [x8, #0xff]
    7648: ad0006a0     	stp	q0, q1, [x21]
    764c: f94097e8     	ldr	x8, [sp, #0x128]
    7650: f90012a8     	str	x8, [x21, #0x20]
    7654: 3dc04fe0     	ldr	q0, [sp, #0x130]
    7658: 3c8282a0     	stur	q0, [x21, #0x28]
    765c: a903ceb4     	stp	x20, x19, [x21, #0x38]
    7660: 910f43ff     	add	sp, sp, #0x3d0
    7664: a9457bfd     	ldp	x29, x30, [sp, #0x50]
    7668: a9444ff4     	ldp	x20, x19, [sp, #0x40]
    766c: a94357f6     	ldp	x22, x21, [sp, #0x30]
    7670: a9425ff8     	ldp	x24, x23, [sp, #0x20]
    7674: a94167fa     	ldp	x26, x25, [sp, #0x10]
    7678: a8c66ffc     	ldp	x28, x27, [sp], #0x60
    767c: d65f03c0     	ret
    7680: 94000000     	bl	0x7680 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x3a8>
		0000000000007680:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

