0000000000007064 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba>:
    7064: d10283ff     	sub	sp, sp, #0xa0
    7068: a9046ffc     	stp	x28, x27, [sp, #0x40]
    706c: a90567fa     	stp	x26, x25, [sp, #0x50]
    7070: a9065ff8     	stp	x24, x23, [sp, #0x60]
    7074: a90757f6     	stp	x22, x21, [sp, #0x70]
    7078: a9084ff4     	stp	x20, x19, [sp, #0x80]
    707c: a9097bfd     	stp	x29, x30, [sp, #0x90]
    7080: aa0303f4     	mov	x20, x3
    7084: aa0203f3     	mov	x19, x2
    7088: aa0003f5     	mov	x21, x0
    708c: d28f82a8     	mov	x8, #0x7c15             ; =31765
    7090: f2afe948     	movk	x8, #0x7f4a, lsl #16
    7094: f2cf3728     	movk	x8, #0x79b9, lsl #32
    7098: f2f3c6e8     	movk	x8, #0x9e37, lsl #48
    709c: 92840009     	mov	x9, #-0x2001            ; =-8193
    70a0: 8b090029     	add	x9, x1, x9
    70a4: b140093f     	cmn	x9, #0x2, lsl #12       ; =0x2000
    70a8: 54000102     	b.hs	0x70c8 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x64>
    70ac: d2800001     	mov	x1, #0x0                ; =0
    70b0: ca080296     	eor	x22, x20, x8
    70b4: f9001bf6     	str	x22, [sp, #0x30]
    70b8: 3900e3ff     	strb	wzr, [sp, #0x38]
    70bc: 90000000     	adrp	x0, 0x7000 <_wf_map_cost_lookup_finish$instance$4be10ff2429b6e66+0x48>
		00000000000070bc:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    70c0: 91000000     	add	x0, x0, #0x0
		00000000000070c0:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    70c4: 1400002f     	b	0x7180 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x11c>
    70c8: 531e7429     	lsl	w9, w1, #2
    70cc: 51001137     	sub	w23, w9, #0x4
    70d0: 121e36e9     	and	w9, w23, #0xfffc
    70d4: 5295556a     	mov	w10, #0xaaab            ; =43691
    70d8: 1b0a7d29     	mul	w9, w9, w10
    70dc: 53117d29     	lsr	w9, w9, #17
    70e0: 11000529     	add	w9, w9, #0x1
    70e4: ca080296     	eor	x22, x20, x8
    70e8: f9001bf6     	str	x22, [sp, #0x30]
    70ec: 3900e3ff     	strb	wzr, [sp, #0x38]
    70f0: aa0903f8     	mov	x24, x9
    70f4: 8b294528     	add	x8, x9, w9, uxtw #1
    70f8: d37df100     	lsl	x0, x8, #3
    70fc: 94000000     	bl	0x70fc <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x98>
		00000000000070fc:  ARM64_RELOC_BRANCH26	_malloc
    7100: b4001340     	cbz	x0, 0x7368 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x304>
    7104: 12003ee8     	and	w8, w23, #0xffff
    7108: 7100251f     	cmp	w8, #0x9
    710c: 54000082     	b.hs	0x711c <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0xb8>
    7110: d2800008     	mov	x8, #0x0                ; =0
    7114: aa1803e1     	mov	x1, x24
    7118: 1400000e     	b	0x7150 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0xec>
    711c: aa1803e1     	mov	x1, x24
    7120: 927e3308     	and	x8, x24, #0x7ffc
    7124: 9100c009     	add	x9, x0, #0x30
    7128: aa0803ea     	mov	x10, x8
    712c: b81d013f     	stur	wzr, [x9, #-0x30]
    7130: b81e813f     	stur	wzr, [x9, #-0x18]
    7134: b900013f     	str	wzr, [x9]
    7138: b900193f     	str	wzr, [x9, #0x18]
    713c: 91018129     	add	x9, x9, #0x60
    7140: f100114a     	subs	x10, x10, #0x4
    7144: 54ffff41     	b.ne	0x712c <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0xc8>
    7148: eb01011f     	cmp	x8, x1
    714c: 540001a0     	b.eq	0x7180 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x11c>
    7150: 92403ee9     	and	x9, x23, #0xffff
    7154: b200f3ea     	mov	x10, #0x5555555555555555 ; =6148914691236517205
    7158: f28aaaca     	movk	x10, #0x5556
    715c: 9bca7d29     	umulh	x9, x9, x10
    7160: aa2903e9     	mvn	x9, x9
    7164: 8b080129     	add	x9, x9, x8
    7168: 8b080508     	add	x8, x8, x8, lsl #1
    716c: d37df108     	lsl	x8, x8, #3
    7170: b828681f     	str	wzr, [x0, x8]
    7174: 91006108     	add	x8, x8, #0x18
    7178: b1000529     	adds	x9, x9, #0x1
    717c: 54ffffa3     	b.lo	0x7170 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x10c>
    7180: a90087e1     	stp	x1, x1, [sp, #0x8]
    7184: a9027fff     	stp	xzr, xzr, [sp, #0x20]
    7188: f9000fe0     	str	x0, [sp, #0x18]
    718c: b4000cf3     	cbz	x19, 0x7328 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x2c4>
    7190: d2800017     	mov	x23, #0x0               ; =0
    7194: 52800038     	mov	w24, #0x1               ; =1
    7198: 5280031a     	mov	w26, #0x18              ; =24
    719c: 5280005b     	mov	w27, #0x2               ; =2
    71a0: d29cb73c     	mov	x28, #0xe5b9            ; =58809
    71a4: f2a39c9c     	movk	x28, #0x1ce4, lsl #16
    71a8: f2c8edbc     	movk	x28, #0x476d, lsl #32
    71ac: f2f7eb1c     	movk	x28, #0xbf58, lsl #48
    71b0: d2823d79     	mov	x25, #0x11eb            ; =4587
    71b4: f2a26639     	movk	x25, #0x1331, lsl #16
    71b8: f2c93779     	movk	x25, #0x49bb, lsl #32
    71bc: f2f29a19     	movk	x25, #0x94d0, lsl #48
    71c0: 14000006     	b	0x71d8 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x174>
    71c4: b900015b     	str	w27, [x10]
    71c8: a900a548     	stp	x8, x9, [x10, #0x8]
    71cc: 910006f7     	add	x23, x23, #0x1
    71d0: eb1302ff     	cmp	x23, x19
    71d4: 54000aa0     	b.eq	0x7328 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x2c4>
    71d8: a94227e8     	ldp	x8, x9, [sp, #0x20]
    71dc: ab090109     	adds	x9, x8, x9
    71e0: da9f3129     	csinv	x9, x9, xzr, lo
    71e4: d34efc2a     	lsr	x10, x1, #14
    71e8: b500020a     	cbnz	x10, 0x7228 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x1c4>
    71ec: cb41082a     	sub	x10, x1, x1, lsr #2
    71f0: eb0a013f     	cmp	x9, x10
    71f4: 540001a3     	b.lo	0x7228 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x1c4>
    71f8: eb4a051f     	cmp	x8, x10, lsr #1
    71fc: 54000103     	b.lo	0x721c <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x1b8>
    7200: b40000c1     	cbz	x1, 0x7218 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x1b4>
    7204: f140083f     	cmp	x1, #0x2, lsl #12       ; =0x2000
    7208: 52840008     	mov	w8, #0x2000             ; =8192
    720c: 9a883028     	csel	x8, x1, x8, lo
    7210: d37ff901     	lsl	x1, x8, #1
    7214: 14000002     	b	0x721c <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x1b8>
    7218: 52800021     	mov	w1, #0x1                ; =1
    721c: 910023e0     	add	x0, sp, #0x8
    7220: 9100c3e2     	add	x2, sp, #0x30
    7224: 94000000     	bl	0x7224 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x1c0>
		0000000000007224:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    7228: aa170708     	orr	x8, x24, x23, lsl #1
    722c: 3940e3e9     	ldrb	w9, [sp, #0x38]
    7230: 360003c9     	tbz	w9, #0x0, 0x72a8 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x244>
    7234: d280000a     	mov	x10, #0x0               ; =0
    7238: 8b1402e9     	add	x9, x23, x20
    723c: f94007e1     	ldr	x1, [sp, #0x8]
    7240: b4000461     	cbz	x1, 0x72cc <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x268>
    7244: 9ac1094b     	udiv	x11, x10, x1
    7248: 9b01a96b     	msub	x11, x11, x1, x10
    724c: f9400fec     	ldr	x12, [sp, #0x18]
    7250: aa0103ed     	mov	x13, x1
    7254: aa0103ea     	mov	x10, x1
    7258: 14000008     	b	0x7278 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x214>
    725c: eb01015f     	cmp	x10, x1
    7260: 9a8a016a     	csel	x10, x11, x10, eq
    7264: 9100056e     	add	x14, x11, #0x1
    7268: eb0101df     	cmp	x14, x1
    726c: 9a8b27eb     	csinc	x11, xzr, x11, hs
    7270: f10005ad     	subs	x13, x13, #0x1
    7274: 540002e0     	b.eq	0x72d0 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x26c>
    7278: 9b1a316e     	madd	x14, x11, x26, x12
    727c: b94001cf     	ldr	w15, [x14]
    7280: 710005ff     	cmp	w15, #0x1
    7284: 54fffec0     	b.eq	0x725c <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x1f8>
    7288: 710009ff     	cmp	w15, #0x2
    728c: 54000441     	b.ne	0x7314 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x2b0>
    7290: f94005cf     	ldr	x15, [x14, #0x8]
    7294: eb0801ff     	cmp	x15, x8
    7298: 54fffe61     	b.ne	0x7264 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x200>
    729c: b90001db     	str	w27, [x14]
    72a0: f90009c9     	str	x9, [x14, #0x10]
    72a4: 17ffffca     	b	0x71cc <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x168>
    72a8: ca160109     	eor	x9, x8, x22
    72ac: ca497929     	eor	x9, x9, x9, lsr #30
    72b0: 9b1c7d29     	mul	x9, x9, x28
    72b4: ca496d29     	eor	x9, x9, x9, lsr #27
    72b8: 9b197d29     	mul	x9, x9, x25
    72bc: ca497d2a     	eor	x10, x9, x9, lsr #31
    72c0: 8b1402e9     	add	x9, x23, x20
    72c4: f94007e1     	ldr	x1, [sp, #0x8]
    72c8: b5fffbe1     	cbnz	x1, 0x7244 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x1e0>
    72cc: d280000a     	mov	x10, #0x0               ; =0
    72d0: eb01015f     	cmp	x10, x1
    72d4: 54fff7c2     	b.hs	0x71cc <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x168>
    72d8: f94013eb     	ldr	x11, [sp, #0x20]
    72dc: d34efd6c     	lsr	x12, x11, #14
    72e0: b5fff76c     	cbnz	x12, 0x71cc <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x168>
    72e4: 9100056b     	add	x11, x11, #0x1
    72e8: f90013eb     	str	x11, [sp, #0x20]
    72ec: f9400feb     	ldr	x11, [sp, #0x18]
    72f0: 9b1a2d4a     	madd	x10, x10, x26, x11
    72f4: b940014b     	ldr	w11, [x10]
    72f8: 7100057f     	cmp	w11, #0x1
    72fc: 54fff641     	b.ne	0x71c4 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x160>
    7300: f94017eb     	ldr	x11, [sp, #0x28]
    7304: f100056b     	subs	x11, x11, #0x1
    7308: 9a8b33eb     	csel	x11, xzr, x11, lo
    730c: f90017eb     	str	x11, [sp, #0x28]
    7310: 17ffffad     	b	0x71c4 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x160>
    7314: eb01015f     	cmp	x10, x1
    7318: 9a8a016a     	csel	x10, x11, x10, eq
    731c: eb01015f     	cmp	x10, x1
    7320: 54fff562     	b.hs	0x71cc <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x168>
    7324: 17ffffed     	b	0x72d8 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x274>
    7328: 3cc083e0     	ldur	q0, [sp, #0x8]
    732c: 3cc183e1     	ldur	q1, [sp, #0x18]
    7330: ad0006a0     	stp	q0, q1, [x21]
    7334: f94017e8     	ldr	x8, [sp, #0x28]
    7338: f90012a8     	str	x8, [x21, #0x20]
    733c: 3dc00fe0     	ldr	q0, [sp, #0x30]
    7340: 3c8282a0     	stur	q0, [x21, #0x28]
    7344: a903ceb4     	stp	x20, x19, [x21, #0x38]
    7348: a9497bfd     	ldp	x29, x30, [sp, #0x90]
    734c: a9484ff4     	ldp	x20, x19, [sp, #0x80]
    7350: a94757f6     	ldp	x22, x21, [sp, #0x70]
    7354: a9465ff8     	ldp	x24, x23, [sp, #0x60]
    7358: a94567fa     	ldp	x26, x25, [sp, #0x50]
    735c: a9446ffc     	ldp	x28, x27, [sp, #0x40]
    7360: 910283ff     	add	sp, sp, #0xa0
    7364: d65f03c0     	ret
    7368: 94000000     	bl	0x7368 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x304>
		0000000000007368:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

