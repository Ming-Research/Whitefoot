0000000000006edc <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba>:
    6edc: d10283ff     	sub	sp, sp, #0xa0
    6ee0: a9046ffc     	stp	x28, x27, [sp, #0x40]
    6ee4: a90567fa     	stp	x26, x25, [sp, #0x50]
    6ee8: a9065ff8     	stp	x24, x23, [sp, #0x60]
    6eec: a90757f6     	stp	x22, x21, [sp, #0x70]
    6ef0: a9084ff4     	stp	x20, x19, [sp, #0x80]
    6ef4: a9097bfd     	stp	x29, x30, [sp, #0x90]
    6ef8: aa0303f4     	mov	x20, x3
    6efc: aa0203f3     	mov	x19, x2
    6f00: aa0003f5     	mov	x21, x0
    6f04: d28f82a8     	mov	x8, #0x7c15             ; =31765
    6f08: f2afe948     	movk	x8, #0x7f4a, lsl #16
    6f0c: f2cf3728     	movk	x8, #0x79b9, lsl #32
    6f10: f2f3c6e8     	movk	x8, #0x9e37, lsl #48
    6f14: 92840009     	mov	x9, #-0x2001            ; =-8193
    6f18: 8b090029     	add	x9, x1, x9
    6f1c: b140093f     	cmn	x9, #0x2, lsl #12       ; =0x2000
    6f20: 54000102     	b.hs	0x6f40 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x64>
    6f24: d2800001     	mov	x1, #0x0                ; =0
    6f28: ca080296     	eor	x22, x20, x8
    6f2c: f9001bf6     	str	x22, [sp, #0x30]
    6f30: 3900e3ff     	strb	wzr, [sp, #0x38]
    6f34: 90000000     	adrp	x0, 0x6000 <_wf_map_cost_lookup_prepare$instance$9333f784ff449eba+0x78>
		0000000000006f34:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    6f38: 91000000     	add	x0, x0, #0x0
		0000000000006f38:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    6f3c: 14000017     	b	0x6f98 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0xbc>
    6f40: 531e7429     	lsl	w9, w1, #2
    6f44: 51001129     	sub	w9, w9, #0x4
    6f48: 121e3529     	and	w9, w9, #0xfffc
    6f4c: 5295556a     	mov	w10, #0xaaab            ; =43691
    6f50: 1b0a7d29     	mul	w9, w9, w10
    6f54: 53117d29     	lsr	w9, w9, #17
    6f58: 11000529     	add	w9, w9, #0x1
    6f5c: ca080296     	eor	x22, x20, x8
    6f60: f9001bf6     	str	x22, [sp, #0x30]
    6f64: 3900e3ff     	strb	wzr, [sp, #0x38]
    6f68: aa0903f7     	mov	x23, x9
    6f6c: 8b294528     	add	x8, x9, w9, uxtw #1
    6f70: d37df100     	lsl	x0, x8, #3
    6f74: 94000000     	bl	0x6f74 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x98>
		0000000000006f74:  ARM64_RELOC_BRANCH26	_malloc
    6f78: b4001040     	cbz	x0, 0x7180 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x2a4>
    6f7c: 91002008     	add	x8, x0, #0x8
    6f80: aa1703e1     	mov	x1, x23
    6f84: aa1703e9     	mov	x9, x23
    6f88: b81f811f     	stur	wzr, [x8, #-0x8]
    6f8c: a881fd1f     	stp	xzr, xzr, [x8], #0x18
    6f90: f1000529     	subs	x9, x9, #0x1
    6f94: 54ffffa1     	b.ne	0x6f88 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0xac>
    6f98: a90087e1     	stp	x1, x1, [sp, #0x8]
    6f9c: a9027fff     	stp	xzr, xzr, [sp, #0x20]
    6fa0: f9000fe0     	str	x0, [sp, #0x18]
    6fa4: b4000cf3     	cbz	x19, 0x7140 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x264>
    6fa8: d2800017     	mov	x23, #0x0               ; =0
    6fac: 52800038     	mov	w24, #0x1               ; =1
    6fb0: 5280031a     	mov	w26, #0x18              ; =24
    6fb4: 5280005b     	mov	w27, #0x2               ; =2
    6fb8: d29cb73c     	mov	x28, #0xe5b9            ; =58809
    6fbc: f2a39c9c     	movk	x28, #0x1ce4, lsl #16
    6fc0: f2c8edbc     	movk	x28, #0x476d, lsl #32
    6fc4: f2f7eb1c     	movk	x28, #0xbf58, lsl #48
    6fc8: d2823d79     	mov	x25, #0x11eb            ; =4587
    6fcc: f2a26639     	movk	x25, #0x1331, lsl #16
    6fd0: f2c93779     	movk	x25, #0x49bb, lsl #32
    6fd4: f2f29a19     	movk	x25, #0x94d0, lsl #48
    6fd8: 14000006     	b	0x6ff0 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x114>
    6fdc: b900015b     	str	w27, [x10]
    6fe0: a900a548     	stp	x8, x9, [x10, #0x8]
    6fe4: 910006f7     	add	x23, x23, #0x1
    6fe8: eb1302ff     	cmp	x23, x19
    6fec: 54000aa0     	b.eq	0x7140 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x264>
    6ff0: a94227e8     	ldp	x8, x9, [sp, #0x20]
    6ff4: ab090109     	adds	x9, x8, x9
    6ff8: da9f3129     	csinv	x9, x9, xzr, lo
    6ffc: d34efc2a     	lsr	x10, x1, #14
    7000: b500020a     	cbnz	x10, 0x7040 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x164>
    7004: cb41082a     	sub	x10, x1, x1, lsr #2
    7008: eb0a013f     	cmp	x9, x10
    700c: 540001a3     	b.lo	0x7040 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x164>
    7010: eb4a051f     	cmp	x8, x10, lsr #1
    7014: 54000103     	b.lo	0x7034 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x158>
    7018: b40000c1     	cbz	x1, 0x7030 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x154>
    701c: f140083f     	cmp	x1, #0x2, lsl #12       ; =0x2000
    7020: 52840008     	mov	w8, #0x2000             ; =8192
    7024: 9a883028     	csel	x8, x1, x8, lo
    7028: d37ff901     	lsl	x1, x8, #1
    702c: 14000002     	b	0x7034 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x158>
    7030: 52800021     	mov	w1, #0x1                ; =1
    7034: 910023e0     	add	x0, sp, #0x8
    7038: 9100c3e2     	add	x2, sp, #0x30
    703c: 94000000     	bl	0x703c <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x160>
		000000000000703c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    7040: aa170708     	orr	x8, x24, x23, lsl #1
    7044: 3940e3e9     	ldrb	w9, [sp, #0x38]
    7048: 360003c9     	tbz	w9, #0x0, 0x70c0 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x1e4>
    704c: d280000a     	mov	x10, #0x0               ; =0
    7050: 8b1402e9     	add	x9, x23, x20
    7054: f94007e1     	ldr	x1, [sp, #0x8]
    7058: b4000461     	cbz	x1, 0x70e4 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x208>
    705c: 9ac1094b     	udiv	x11, x10, x1
    7060: 9b01a96b     	msub	x11, x11, x1, x10
    7064: f9400fec     	ldr	x12, [sp, #0x18]
    7068: aa0103ed     	mov	x13, x1
    706c: aa0103ea     	mov	x10, x1
    7070: 14000008     	b	0x7090 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x1b4>
    7074: eb01015f     	cmp	x10, x1
    7078: 9a8a016a     	csel	x10, x11, x10, eq
    707c: 9100056e     	add	x14, x11, #0x1
    7080: eb0101df     	cmp	x14, x1
    7084: 9a8b27eb     	csinc	x11, xzr, x11, hs
    7088: f10005ad     	subs	x13, x13, #0x1
    708c: 540002e0     	b.eq	0x70e8 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x20c>
    7090: 9b1a316e     	madd	x14, x11, x26, x12
    7094: b94001cf     	ldr	w15, [x14]
    7098: 710005ff     	cmp	w15, #0x1
    709c: 54fffec0     	b.eq	0x7074 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x198>
    70a0: 710009ff     	cmp	w15, #0x2
    70a4: 54000441     	b.ne	0x712c <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x250>
    70a8: f94005cf     	ldr	x15, [x14, #0x8]
    70ac: eb0801ff     	cmp	x15, x8
    70b0: 54fffe61     	b.ne	0x707c <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x1a0>
    70b4: b90001db     	str	w27, [x14]
    70b8: f90009c9     	str	x9, [x14, #0x10]
    70bc: 17ffffca     	b	0x6fe4 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x108>
    70c0: ca160109     	eor	x9, x8, x22
    70c4: ca497929     	eor	x9, x9, x9, lsr #30
    70c8: 9b1c7d29     	mul	x9, x9, x28
    70cc: ca496d29     	eor	x9, x9, x9, lsr #27
    70d0: 9b197d29     	mul	x9, x9, x25
    70d4: ca497d2a     	eor	x10, x9, x9, lsr #31
    70d8: 8b1402e9     	add	x9, x23, x20
    70dc: f94007e1     	ldr	x1, [sp, #0x8]
    70e0: b5fffbe1     	cbnz	x1, 0x705c <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x180>
    70e4: d280000a     	mov	x10, #0x0               ; =0
    70e8: eb01015f     	cmp	x10, x1
    70ec: 54fff7c2     	b.hs	0x6fe4 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x108>
    70f0: f94013eb     	ldr	x11, [sp, #0x20]
    70f4: d34efd6c     	lsr	x12, x11, #14
    70f8: b5fff76c     	cbnz	x12, 0x6fe4 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x108>
    70fc: 9100056b     	add	x11, x11, #0x1
    7100: f90013eb     	str	x11, [sp, #0x20]
    7104: f9400feb     	ldr	x11, [sp, #0x18]
    7108: 9b1a2d4a     	madd	x10, x10, x26, x11
    710c: b940014b     	ldr	w11, [x10]
    7110: 7100057f     	cmp	w11, #0x1
    7114: 54fff641     	b.ne	0x6fdc <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x100>
    7118: f94017eb     	ldr	x11, [sp, #0x28]
    711c: f100056b     	subs	x11, x11, #0x1
    7120: 9a8b33eb     	csel	x11, xzr, x11, lo
    7124: f90017eb     	str	x11, [sp, #0x28]
    7128: 17ffffad     	b	0x6fdc <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x100>
    712c: eb01015f     	cmp	x10, x1
    7130: 9a8a016a     	csel	x10, x11, x10, eq
    7134: eb01015f     	cmp	x10, x1
    7138: 54fff562     	b.hs	0x6fe4 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x108>
    713c: 17ffffed     	b	0x70f0 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x214>
    7140: 3cc083e0     	ldur	q0, [sp, #0x8]
    7144: 3cc183e1     	ldur	q1, [sp, #0x18]
    7148: ad0006a0     	stp	q0, q1, [x21]
    714c: f94017e8     	ldr	x8, [sp, #0x28]
    7150: f90012a8     	str	x8, [x21, #0x20]
    7154: 3dc00fe0     	ldr	q0, [sp, #0x30]
    7158: 3c8282a0     	stur	q0, [x21, #0x28]
    715c: a903ceb4     	stp	x20, x19, [x21, #0x38]
    7160: a9497bfd     	ldp	x29, x30, [sp, #0x90]
    7164: a9484ff4     	ldp	x20, x19, [sp, #0x80]
    7168: a94757f6     	ldp	x22, x21, [sp, #0x70]
    716c: a9465ff8     	ldp	x24, x23, [sp, #0x60]
    7170: a94567fa     	ldp	x26, x25, [sp, #0x50]
    7174: a9446ffc     	ldp	x28, x27, [sp, #0x40]
    7178: 910283ff     	add	sp, sp, #0xa0
    717c: d65f03c0     	ret
    7180: 94000000     	bl	0x7180 <_wf_map_cost_reserve_prepare$instance$9333f784ff449eba+0x2a4>
		0000000000007180:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

