0000000000009c94 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743>:
    9c94: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    9c98: a90157f6     	stp	x22, x21, [sp, #0x10]
    9c9c: a9024ff4     	stp	x20, x19, [sp, #0x20]
    9ca0: a9037bfd     	stp	x29, x30, [sp, #0x30]
    9ca4: aa0103f4     	mov	x20, x1
    9ca8: aa0003f3     	mov	x19, x0
    9cac: a9405817     	ldp	x23, x22, [x0]
    9cb0: eb0102df     	cmp	x22, x1
    9cb4: 54000302     	b.hs	0x9d14 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x80>
    9cb8: f9400a75     	ldr	x21, [x19, #0x10]
    9cbc: 8b141288     	add	x8, x20, x20, lsl #4
    9cc0: d37ced01     	lsl	x1, x8, #4
    9cc4: f10002df     	cmp	x22, #0x0
    9cc8: fa5612e0     	ccmp	x23, x22, #0x0, ne
    9ccc: 540001c0     	b.eq	0x9d04 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x70>
    9cd0: aa0103e0     	mov	x0, x1
    9cd4: 94000000     	bl	0x9cd4 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x40>
		0000000000009cd4:  ARM64_RELOC_BRANCH26	_malloc
    9cd8: b4000640     	cbz	x0, 0x9da0 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x10c>
    9cdc: b40001b6     	cbz	x22, 0x9d10 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x7c>
    9ce0: 8b1712e8     	add	x8, x23, x23, lsl #4
    9ce4: d37ced02     	lsl	x2, x8, #4
    9ce8: aa0003f6     	mov	x22, x0
    9cec: aa1503e1     	mov	x1, x21
    9cf0: 94000000     	bl	0x9cf0 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x5c>
		0000000000009cf0:  ARM64_RELOC_BRANCH26	_memcpy
    9cf4: aa1503e0     	mov	x0, x21
    9cf8: 94000000     	bl	0x9cf8 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x64>
		0000000000009cf8:  ARM64_RELOC_BRANCH26	_free
    9cfc: aa1603e0     	mov	x0, x22
    9d00: 14000004     	b	0x9d10 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x7c>
    9d04: aa1503e0     	mov	x0, x21
    9d08: 94000000     	bl	0x9d08 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x74>
		0000000000009d08:  ARM64_RELOC_BRANCH26	_realloc
    9d0c: b40004a0     	cbz	x0, 0x9da0 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x10c>
    9d10: a9008274     	stp	x20, x0, [x19, #0x8]
    9d14: eb17028a     	subs	x10, x20, x23
    9d18: 54000389     	b.ls	0x9d88 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xf4>
    9d1c: f9400a69     	ldr	x9, [x19, #0x10]
    9d20: aa1703e8     	mov	x8, x23
    9d24: f100115f     	cmp	x10, #0x4
    9d28: 540001e3     	b.lo	0x9d64 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xd0>
    9d2c: 927ef54b     	and	x11, x10, #0xfffffffffffffffc
    9d30: 8b0b02e8     	add	x8, x23, x11
    9d34: 5280220c     	mov	w12, #0x110             ; =272
    9d38: 9b0c26ec     	madd	x12, x23, x12, x9
    9d3c: aa0b03ed     	mov	x13, x11
    9d40: b900019f     	str	wzr, [x12]
    9d44: b901119f     	str	wzr, [x12, #0x110]
    9d48: b902219f     	str	wzr, [x12, #0x220]
    9d4c: b903319f     	str	wzr, [x12, #0x330]
    9d50: 9111018c     	add	x12, x12, #0x440
    9d54: f10011ad     	subs	x13, x13, #0x4
    9d58: 54ffff41     	b.ne	0x9d40 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xac>
    9d5c: eb0b015f     	cmp	x10, x11
    9d60: 54000120     	b.eq	0x9d84 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xf0>
    9d64: 5280220a     	mov	w10, #0x110             ; =272
    9d68: 9b0a2509     	madd	x9, x8, x10, x9
    9d6c: cb08028a     	sub	x10, x20, x8
    9d70: b900013f     	str	wzr, [x9]
    9d74: 91000508     	add	x8, x8, #0x1
    9d78: 91044129     	add	x9, x9, #0x110
    9d7c: f100054a     	subs	x10, x10, #0x1
    9d80: 54ffff81     	b.ne	0x9d70 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xdc>
    9d84: f9000268     	str	x8, [x19]
    9d88: 52800000     	mov	w0, #0x0                ; =0
    9d8c: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    9d90: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    9d94: a94157f6     	ldp	x22, x21, [sp, #0x10]
    9d98: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    9d9c: d65f03c0     	ret
    9da0: 94000000     	bl	0x9da0 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x10c>
		0000000000009da0:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

