0000000000007184 <_wf_map_cost_reserve_step$instance$e194368921a477a7>:
    7184: 92840008     	mov	x8, #-0x2001            ; =-8193
    7188: 8b080028     	add	x8, x1, x8
    718c: b140091f     	cmn	x8, #0x2, lsl #12       ; =0x2000
    7190: 54000243     	b.lo	0x71d8 <_wf_map_cost_reserve_step$instance$e194368921a477a7+0x54>
    7194: 531e7428     	lsl	w8, w1, #2
    7198: 51001108     	sub	w8, w8, #0x4
    719c: 121e3508     	and	w8, w8, #0xfffc
    71a0: 52955569     	mov	w9, #0xaaab             ; =43691
    71a4: 1b097d08     	mul	w8, w8, w9
    71a8: 53117d08     	lsr	w8, w8, #17
    71ac: 11000501     	add	w1, w8, #0x1
    71b0: f9400008     	ldr	x8, [x0]
    71b4: eb01011f     	cmp	x8, x1
    71b8: 54000102     	b.hs	0x71d8 <_wf_map_cost_reserve_step$instance$e194368921a477a7+0x54>
    71bc: a9bf7bfd     	stp	x29, x30, [sp, #-0x10]!
    71c0: 9100a002     	add	x2, x0, #0x28
    71c4: 94000000     	bl	0x71c4 <_wf_map_cost_reserve_step$instance$e194368921a477a7+0x40>
		00000000000071c4:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    71c8: a8c17bfd     	ldp	x29, x30, [sp], #0x10
    71cc: 34000060     	cbz	w0, 0x71d8 <_wf_map_cost_reserve_step$instance$e194368921a477a7+0x54>
    71d0: d2800000     	mov	x0, #0x0                ; =0
    71d4: d65f03c0     	ret
    71d8: 52800020     	mov	w0, #0x1                ; =1
    71dc: d65f03c0     	ret

