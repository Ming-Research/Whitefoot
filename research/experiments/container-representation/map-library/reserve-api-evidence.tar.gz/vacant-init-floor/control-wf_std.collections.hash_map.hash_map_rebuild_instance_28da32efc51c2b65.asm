0000000000009f8c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65>:
    9f8c: a9ba6ffc     	stp	x28, x27, [sp, #-0x60]!
    9f90: a90167fa     	stp	x26, x25, [sp, #0x10]
    9f94: a9025ff8     	stp	x24, x23, [sp, #0x20]
    9f98: a90357f6     	stp	x22, x21, [sp, #0x30]
    9f9c: a9044ff4     	stp	x20, x19, [sp, #0x40]
    9fa0: a9057bfd     	stp	x29, x30, [sp, #0x50]
    9fa4: d10943ff     	sub	sp, sp, #0x250
    9fa8: f140103f     	cmp	x1, #0x4, lsl #12       ; =0x4000
    9fac: 540000c8     	b.hi	0x9fc4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x38>
    9fb0: aa0103f4     	mov	x20, x1
    9fb4: aa0003f3     	mov	x19, x0
    9fb8: f9400016     	ldr	x22, [x0]
    9fbc: eb16003f     	cmp	x1, x22
    9fc0: 54000182     	b.hs	0x9ff0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x64>
    9fc4: 52800020     	mov	w0, #0x1                ; =1
    9fc8: 52800001     	mov	w1, #0x0                ; =0
    9fcc: 52800002     	mov	w2, #0x0                ; =0
    9fd0: 910943ff     	add	sp, sp, #0x250
    9fd4: a9457bfd     	ldp	x29, x30, [sp, #0x50]
    9fd8: a9444ff4     	ldp	x20, x19, [sp, #0x40]
    9fdc: a94357f6     	ldp	x22, x21, [sp, #0x30]
    9fe0: a9425ff8     	ldp	x24, x23, [sp, #0x20]
    9fe4: a94167fa     	ldp	x26, x25, [sp, #0x10]
    9fe8: a8c66ffc     	ldp	x28, x27, [sp], #0x60
    9fec: d65f03c0     	ret
    9ff0: b4001634     	cbz	x20, 0xa2b4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x328>
    9ff4: f9400059     	ldr	x25, [x2]
    9ff8: 39402048     	ldrb	w8, [x2, #0x8]
    9ffc: b9001fe8     	str	w8, [sp, #0x1c]
    a000: 8b141288     	add	x8, x20, x20, lsl #4
    a004: d37ced00     	lsl	x0, x8, #4
    a008: 94000000     	bl	0xa008 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x7c>
		000000000000a008:  ARM64_RELOC_BRANCH26	_malloc
    a00c: b4001580     	cbz	x0, 0xa2bc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x330>
    a010: aa0003f5     	mov	x21, x0
    a014: d2800008     	mov	x8, #0x0                ; =0
    a018: 91002009     	add	x9, x0, #0x8
    a01c: 6f00e400     	movi.2d	v0, #0000000000000000
    a020: b81f813f     	stur	wzr, [x9, #-0x8]
    a024: 91000508     	add	x8, x8, #0x1
    a028: ad000120     	stp	q0, q0, [x9]
    a02c: ad010120     	stp	q0, q0, [x9, #0x20]
    a030: ad020120     	stp	q0, q0, [x9, #0x40]
    a034: ad030120     	stp	q0, q0, [x9, #0x60]
    a038: ad040120     	stp	q0, q0, [x9, #0x80]
    a03c: ad050120     	stp	q0, q0, [x9, #0xa0]
    a040: ad060120     	stp	q0, q0, [x9, #0xc0]
    a044: ad070120     	stp	q0, q0, [x9, #0xe0]
    a048: f900813f     	str	xzr, [x9, #0x100]
    a04c: 91044129     	add	x9, x9, #0x110
    a050: eb08029f     	cmp	x20, x8
    a054: 54fffe61     	b.ne	0xa020 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x94>
    a058: a940a269     	ldp	x9, x8, [x19, #0x8]
    a05c: f9000be9     	str	x9, [sp, #0x10]
    a060: f90013e8     	str	x8, [sp, #0x20]
    a064: a9005274     	stp	x20, x20, [x19]
    a068: f9000a75     	str	x21, [x19, #0x10]
    a06c: b4001176     	cbz	x22, 0xa298 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x30c>
    a070: 5280221a     	mov	w26, #0x110             ; =272
    a074: 9100c3fb     	add	x27, sp, #0x30
    a078: d2823d78     	mov	x24, #0x11eb            ; =4587
    a07c: f2a26638     	movk	x24, #0x1331, lsl #16
    a080: f2c93778     	movk	x24, #0x49bb, lsl #32
    a084: f2f29a18     	movk	x24, #0x94d0, lsl #48
    a088: 14000003     	b	0xa094 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x108>
    a08c: f94017f6     	ldr	x22, [sp, #0x28]
    a090: b4001056     	cbz	x22, 0xa298 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x30c>
    a094: d10006d6     	sub	x22, x22, #0x1
    a098: f90017f6     	str	x22, [sp, #0x28]
    a09c: f94013e8     	ldr	x8, [sp, #0x20]
    a0a0: 9b1a22c8     	madd	x8, x22, x26, x8
    a0a4: b9400109     	ldr	w9, [x8]
    a0a8: 7100053f     	cmp	w9, #0x1
    a0ac: 54ffff09     	b.ls	0xa08c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x100>
    a0b0: f9408509     	ldr	x9, [x8, #0x108]
    a0b4: 3cc08100     	ldur	q0, [x8, #0x8]
    a0b8: 3c8383e0     	stur	q0, [sp, #0x38]
    a0bc: 3cc18100     	ldur	q0, [x8, #0x18]
    a0c0: 3c8483e0     	stur	q0, [sp, #0x48]
    a0c4: 3cc28100     	ldur	q0, [x8, #0x28]
    a0c8: 3c8583e0     	stur	q0, [sp, #0x58]
    a0cc: 3cc38100     	ldur	q0, [x8, #0x38]
    a0d0: 3c8683e0     	stur	q0, [sp, #0x68]
    a0d4: 3cc48100     	ldur	q0, [x8, #0x48]
    a0d8: 3c8783e0     	stur	q0, [sp, #0x78]
    a0dc: 3cc58100     	ldur	q0, [x8, #0x58]
    a0e0: 3c8883e0     	stur	q0, [sp, #0x88]
    a0e4: 3cc68100     	ldur	q0, [x8, #0x68]
    a0e8: 3c8983e0     	stur	q0, [sp, #0x98]
    a0ec: 3cc78100     	ldur	q0, [x8, #0x78]
    a0f0: 3c8a83e0     	stur	q0, [sp, #0xa8]
    a0f4: 3cc88100     	ldur	q0, [x8, #0x88]
    a0f8: 9100c3ea     	add	x10, sp, #0x30
    a0fc: 3c888140     	stur	q0, [x10, #0x88]
    a100: 3cc98100     	ldur	q0, [x8, #0x98]
    a104: 3c898140     	stur	q0, [x10, #0x98]
    a108: 3cca8100     	ldur	q0, [x8, #0xa8]
    a10c: 3c8a8140     	stur	q0, [x10, #0xa8]
    a110: 3ccb8100     	ldur	q0, [x8, #0xb8]
    a114: 3c8b8140     	stur	q0, [x10, #0xb8]
    a118: 3ccc8100     	ldur	q0, [x8, #0xc8]
    a11c: 3c8c8140     	stur	q0, [x10, #0xc8]
    a120: 3ccd8100     	ldur	q0, [x8, #0xd8]
    a124: 3c8d8140     	stur	q0, [x10, #0xd8]
    a128: 3cce8100     	ldur	q0, [x8, #0xe8]
    a12c: 3c8e8140     	stur	q0, [x10, #0xe8]
    a130: 3ccf8100     	ldur	q0, [x8, #0xf8]
    a134: 3c8f8140     	stur	q0, [x10, #0xf8]
    a138: f9009fe9     	str	x9, [sp, #0x138]
    a13c: 52800028     	mov	w8, #0x1                ; =1
    a140: f9001be8     	str	x8, [sp, #0x30]
    a144: b9401fe8     	ldr	w8, [sp, #0x1c]
    a148: 36000448     	tbz	w8, #0x0, 0xa1d0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x244>
    a14c: 5280003c     	mov	w28, #0x1               ; =1
    a150: 14000013     	b	0xa19c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x210>
    a154: d1000796     	sub	x22, x28, #0x1
    a158: f9001bf6     	str	x22, [sp, #0x30]
    a15c: 52802108     	mov	w8, #0x108              ; =264
    a160: 9b086f97     	madd	x23, x28, x8, x27
    a164: f8500ee3     	ldr	x3, [x23, #-0x100]!
    a168: 910503e0     	add	x0, sp, #0x140
    a16c: 910022e4     	add	x4, x23, #0x8
    a170: aa1303e1     	mov	x1, x19
    a174: 94000000     	bl	0xa174 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x1e8>
		000000000000a174:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    a178: b94143e8     	ldr	w8, [sp, #0x140]
    a17c: 34000248     	cbz	w8, 0xa1c4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x238>
    a180: 910503e8     	add	x8, sp, #0x140
    a184: 91002101     	add	x1, x8, #0x8
    a188: aa1703e0     	mov	x0, x23
    a18c: 52802102     	mov	w2, #0x108              ; =264
    a190: 94000000     	bl	0xa190 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x204>
		000000000000a190:  ARM64_RELOC_BRANCH26	_memcpy
    a194: f9001bfc     	str	x28, [sp, #0x30]
    a198: b4fff7bc     	cbz	x28, 0xa08c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x100>
    a19c: d2800002     	mov	x2, #0x0                ; =0
    a1a0: aa1503e8     	mov	x8, x21
    a1a4: b9400109     	ldr	w9, [x8]
    a1a8: 7100093f     	cmp	w9, #0x2
    a1ac: 54fffd43     	b.lo	0xa154 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x1c8>
    a1b0: 91044108     	add	x8, x8, #0x110
    a1b4: 91000442     	add	x2, x2, #0x1
    a1b8: eb02029f     	cmp	x20, x2
    a1bc: 54ffff41     	b.ne	0xa1a4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x218>
    a1c0: 17fffff6     	b	0xa198 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x20c>
    a1c4: aa1603fc     	mov	x28, x22
    a1c8: b5fffeb6     	cbnz	x22, 0xa19c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x210>
    a1cc: 17ffffb0     	b	0xa08c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x100>
    a1d0: 52800036     	mov	w22, #0x1               ; =1
    a1d4: 14000013     	b	0xa220 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x294>
    a1d8: d10006dc     	sub	x28, x22, #0x1
    a1dc: f9001bfc     	str	x28, [sp, #0x30]
    a1e0: 52802108     	mov	w8, #0x108              ; =264
    a1e4: 9b086ed7     	madd	x23, x22, x8, x27
    a1e8: f8500ee3     	ldr	x3, [x23, #-0x100]!
    a1ec: 910503e0     	add	x0, sp, #0x140
    a1f0: 910022e4     	add	x4, x23, #0x8
    a1f4: aa1303e1     	mov	x1, x19
    a1f8: 94000000     	bl	0xa1f8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x26c>
		000000000000a1f8:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    a1fc: b94143e8     	ldr	w8, [sp, #0x140]
    a200: 34000468     	cbz	w8, 0xa28c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x300>
    a204: 910503e8     	add	x8, sp, #0x140
    a208: 91002101     	add	x1, x8, #0x8
    a20c: aa1703e0     	mov	x0, x23
    a210: 52802102     	mov	w2, #0x108              ; =264
    a214: 94000000     	bl	0xa214 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x288>
		000000000000a214:  ARM64_RELOC_BRANCH26	_memcpy
    a218: f9001bf6     	str	x22, [sp, #0x30]
    a21c: b4fff396     	cbz	x22, 0xa08c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x100>
    a220: d2800008     	mov	x8, #0x0                ; =0
    a224: f9401fe9     	ldr	x9, [sp, #0x38]
    a228: ca190129     	eor	x9, x9, x25
    a22c: ca497929     	eor	x9, x9, x9, lsr #30
    a230: d29cb72a     	mov	x10, #0xe5b9            ; =58809
    a234: f2a39c8a     	movk	x10, #0x1ce4, lsl #16
    a238: f2c8edaa     	movk	x10, #0x476d, lsl #32
    a23c: f2f7eb0a     	movk	x10, #0xbf58, lsl #48
    a240: 9b0a7d29     	mul	x9, x9, x10
    a244: ca496d29     	eor	x9, x9, x9, lsr #27
    a248: 9b187d29     	mul	x9, x9, x24
    a24c: ca497d29     	eor	x9, x9, x9, lsr #31
    a250: 9ad4092a     	udiv	x10, x9, x20
    a254: 9b14a549     	msub	x9, x10, x20, x9
    a258: cb09028a     	sub	x10, x20, x9
    a25c: cb0a03eb     	neg	x11, x10
    a260: eb0a011f     	cmp	x8, x10
    a264: 9a8b312c     	csel	x12, x9, x11, lo
    a268: 8b080182     	add	x2, x12, x8
    a26c: 9b1a7c4c     	mul	x12, x2, x26
    a270: b86c6aac     	ldr	w12, [x21, x12]
    a274: 7100099f     	cmp	w12, #0x2
    a278: 54fffb03     	b.lo	0xa1d8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x24c>
    a27c: 91000508     	add	x8, x8, #0x1
    a280: eb08029f     	cmp	x20, x8
    a284: 54fffee1     	b.ne	0xa260 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x2d4>
    a288: 17ffffe5     	b	0xa21c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x290>
    a28c: aa1c03f6     	mov	x22, x28
    a290: b5fffc9c     	cbnz	x28, 0xa220 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x294>
    a294: 17ffff7e     	b	0xa08c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x100>
    a298: f9400be8     	ldr	x8, [sp, #0x10]
    a29c: b4000068     	cbz	x8, 0xa2a8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x31c>
    a2a0: f94013e0     	ldr	x0, [sp, #0x20]
    a2a4: 94000000     	bl	0xa2a4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x318>
		000000000000a2a4:  ARM64_RELOC_BRANCH26	_free
    a2a8: 52800000     	mov	w0, #0x0                ; =0
    a2ac: f900127f     	str	xzr, [x19, #0x20]
    a2b0: 17ffff46     	b	0x9fc8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x3c>
    a2b4: 52800000     	mov	w0, #0x0                ; =0
    a2b8: 17ffff44     	b	0x9fc8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x3c>
    a2bc: 94000000     	bl	0xa2bc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x330>
		000000000000a2bc:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

