0000000000007684 <_wf_map_cost_reserve_step$instance$9fed7d4c5d7cc122>:
    7684: 92840008     	mov	x8, #-0x2001            ; =-8193
    7688: 8b080028     	add	x8, x1, x8
    768c: b140091f     	cmn	x8, #0x2, lsl #12       ; =0x2000
    7690: 54000243     	b.lo	0x76d8 <_wf_map_cost_reserve_step$instance$9fed7d4c5d7cc122+0x54>
    7694: 531e7428     	lsl	w8, w1, #2
    7698: 51001108     	sub	w8, w8, #0x4
    769c: 121e3508     	and	w8, w8, #0xfffc
    76a0: 52955569     	mov	w9, #0xaaab             ; =43691
    76a4: 1b097d08     	mul	w8, w8, w9
    76a8: 53117d08     	lsr	w8, w8, #17
    76ac: 11000501     	add	w1, w8, #0x1
    76b0: f9400008     	ldr	x8, [x0]
    76b4: eb01011f     	cmp	x8, x1
    76b8: 54000102     	b.hs	0x76d8 <_wf_map_cost_reserve_step$instance$9fed7d4c5d7cc122+0x54>
    76bc: a9bf7bfd     	stp	x29, x30, [sp, #-0x10]!
    76c0: 9100a002     	add	x2, x0, #0x28
    76c4: 94000000     	bl	0x76c4 <_wf_map_cost_reserve_step$instance$9fed7d4c5d7cc122+0x40>
		00000000000076c4:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    76c8: a8c17bfd     	ldp	x29, x30, [sp], #0x10
    76cc: 34000060     	cbz	w0, 0x76d8 <_wf_map_cost_reserve_step$instance$9fed7d4c5d7cc122+0x54>
    76d0: d2800000     	mov	x0, #0x0                ; =0
    76d4: d65f03c0     	ret
    76d8: 52800020     	mov	w0, #0x1                ; =1
    76dc: d65f03c0     	ret

