00000000000074c0 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66>:
    74c0: a9ba6ffc     	stp	x28, x27, [sp, #-0x60]!
    74c4: a90167fa     	stp	x26, x25, [sp, #0x10]
    74c8: a9025ff8     	stp	x24, x23, [sp, #0x20]
    74cc: a90357f6     	stp	x22, x21, [sp, #0x30]
    74d0: a9044ff4     	stp	x20, x19, [sp, #0x40]
    74d4: a9057bfd     	stp	x29, x30, [sp, #0x50]
    74d8: d10f43ff     	sub	sp, sp, #0x3d0
    74dc: aa0303f4     	mov	x20, x3
    74e0: aa0203f3     	mov	x19, x2
    74e4: aa0003f5     	mov	x21, x0
    74e8: 92840008     	mov	x8, #-0x2001            ; =-8193
    74ec: 8b080028     	add	x8, x1, x8
    74f0: b140091f     	cmn	x8, #0x2, lsl #12       ; =0x2000
    74f4: 54000182     	b.hs	0x7524 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x64>
    74f8: d2800016     	mov	x22, #0x0               ; =0
    74fc: d28f82a8     	mov	x8, #0x7c15             ; =31765
    7500: f2afe948     	movk	x8, #0x7f4a, lsl #16
    7504: f2cf3728     	movk	x8, #0x79b9, lsl #32
    7508: f2f3c6e8     	movk	x8, #0x9e37, lsl #48
    750c: ca080288     	eor	x8, x20, x8
    7510: f9009be8     	str	x8, [sp, #0x130]
    7514: 3904e3ff     	strb	wzr, [sp, #0x138]
    7518: 90000000     	adrp	x0, 0x7000 <_wf_map_cost_lookup_finish$instance$4be10ff2429b6e66+0x48>
		0000000000007518:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    751c: 91000000     	add	x0, x0, #0x0
		000000000000751c:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    7520: 14000030     	b	0x75e0 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x120>
    7524: 531e7428     	lsl	w8, w1, #2
    7528: 51001117     	sub	w23, w8, #0x4
    752c: 121e36e8     	and	w8, w23, #0xfffc
    7530: 52955569     	mov	w9, #0xaaab             ; =43691
    7534: 1b097d08     	mul	w8, w8, w9
    7538: 53117d08     	lsr	w8, w8, #17
    753c: 11000516     	add	w22, w8, #0x1
    7540: d28f82a8     	mov	x8, #0x7c15             ; =31765
    7544: f2afe948     	movk	x8, #0x7f4a, lsl #16
    7548: f2cf3728     	movk	x8, #0x79b9, lsl #32
    754c: f2f3c6e8     	movk	x8, #0x9e37, lsl #48
    7550: ca080288     	eor	x8, x20, x8
    7554: f9009be8     	str	x8, [sp, #0x130]
    7558: 3904e3ff     	strb	wzr, [sp, #0x138]
    755c: 8b3652c8     	add	x8, x22, w22, uxtw #4
    7560: d37ced00     	lsl	x0, x8, #4
    7564: 94000000     	bl	0x7564 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0xa4>
		0000000000007564:  ARM64_RELOC_BRANCH26	_malloc
    7568: b40019a0     	cbz	x0, 0x789c <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x3dc>
    756c: 12003ee8     	and	w8, w23, #0xffff
    7570: 7100251f     	cmp	w8, #0x9
    7574: 54000062     	b.hs	0x7580 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0xc0>
    7578: d2800008     	mov	x8, #0x0                ; =0
    757c: 1400000d     	b	0x75b0 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0xf0>
    7580: 927e32c8     	and	x8, x22, #0x7ffc
    7584: aa0003e9     	mov	x9, x0
    7588: aa0803ea     	mov	x10, x8
    758c: b900013f     	str	wzr, [x9]
    7590: b901113f     	str	wzr, [x9, #0x110]
    7594: b902213f     	str	wzr, [x9, #0x220]
    7598: b903313f     	str	wzr, [x9, #0x330]
    759c: 91110129     	add	x9, x9, #0x440
    75a0: f100114a     	subs	x10, x10, #0x4
    75a4: 54ffff41     	b.ne	0x758c <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0xcc>
    75a8: eb16011f     	cmp	x8, x22
    75ac: 540001a0     	b.eq	0x75e0 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x120>
    75b0: 92403ee9     	and	x9, x23, #0xffff
    75b4: b200f3ea     	mov	x10, #0x5555555555555555 ; =6148914691236517205
    75b8: f28aaaca     	movk	x10, #0x5556
    75bc: 9bca7d29     	umulh	x9, x9, x10
    75c0: aa2903e9     	mvn	x9, x9
    75c4: 8b080129     	add	x9, x9, x8
    75c8: 8b081108     	add	x8, x8, x8, lsl #4
    75cc: d37ced08     	lsl	x8, x8, #4
    75d0: b828681f     	str	wzr, [x0, x8]
    75d4: 91044108     	add	x8, x8, #0x110
    75d8: b1000529     	adds	x9, x9, #0x1
    75dc: 54ffffa3     	b.lo	0x75d0 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x110>
    75e0: a910dbf6     	stp	x22, x22, [sp, #0x108]
    75e4: a9127fff     	stp	xzr, xzr, [sp, #0x120]
    75e8: f9008fe0     	str	x0, [sp, #0x118]
    75ec: b4001353     	cbz	x19, 0x7854 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x394>
    75f0: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_finish$instance$4be10ff2429b6e66+0x48>
		00000000000075f0:  ARM64_RELOC_PAGE21	lCPI65_0
    75f4: 3dc00100     	ldr	q0, [x8]
		00000000000075f4:  ARM64_RELOC_PAGEOFF12	lCPI65_0
    75f8: 3d803fe0     	str	q0, [sp, #0xf0]
    75fc: 910943f7     	add	x23, sp, #0x250
    7600: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_finish$instance$4be10ff2429b6e66+0x48>
		0000000000007600:  ARM64_RELOC_PAGE21	lCPI65_1
    7604: 3dc00100     	ldr	q0, [x8]
		0000000000007604:  ARM64_RELOC_PAGEOFF12	lCPI65_1
    7608: 3d803be0     	str	q0, [sp, #0xe0]
    760c: 910943f8     	add	x24, sp, #0x250
    7610: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_finish$instance$4be10ff2429b6e66+0x48>
		0000000000007610:  ARM64_RELOC_PAGE21	lCPI65_2
    7614: 3dc00100     	ldr	q0, [x8]
		0000000000007614:  ARM64_RELOC_PAGEOFF12	lCPI65_2
    7618: 3d8037e0     	str	q0, [sp, #0xd0]
    761c: 9104a319     	add	x25, x24, #0x128
    7620: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_finish$instance$4be10ff2429b6e66+0x48>
		0000000000007620:  ARM64_RELOC_PAGE21	lCPI65_3
    7624: 3dc00100     	ldr	q0, [x8]
		0000000000007624:  ARM64_RELOC_PAGEOFF12	lCPI65_3
    7628: 3d8033e0     	str	q0, [sp, #0xc0]
    762c: 52800036     	mov	w22, #0x1               ; =1
    7630: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_finish$instance$4be10ff2429b6e66+0x48>
		0000000000007630:  ARM64_RELOC_PAGE21	lCPI65_4
    7634: 3dc00100     	ldr	q0, [x8]
		0000000000007634:  ARM64_RELOC_PAGEOFF12	lCPI65_4
    7638: 3d802fe0     	str	q0, [sp, #0xb0]
    763c: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_finish$instance$4be10ff2429b6e66+0x48>
		000000000000763c:  ARM64_RELOC_PAGE21	lCPI65_5
    7640: 3dc00100     	ldr	q0, [x8]
		0000000000007640:  ARM64_RELOC_PAGEOFF12	lCPI65_5
    7644: 3d802be0     	str	q0, [sp, #0xa0]
    7648: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_finish$instance$4be10ff2429b6e66+0x48>
		0000000000007648:  ARM64_RELOC_PAGE21	lCPI65_6
    764c: 3dc00100     	ldr	q0, [x8]
		000000000000764c:  ARM64_RELOC_PAGEOFF12	lCPI65_6
    7650: 3d8027e0     	str	q0, [sp, #0x90]
    7654: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_finish$instance$4be10ff2429b6e66+0x48>
		0000000000007654:  ARM64_RELOC_PAGE21	lCPI65_7
    7658: 3dc00100     	ldr	q0, [x8]
		0000000000007658:  ARM64_RELOC_PAGEOFF12	lCPI65_7
    765c: 3d8023e0     	str	q0, [sp, #0x80]
    7660: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_finish$instance$4be10ff2429b6e66+0x48>
		0000000000007660:  ARM64_RELOC_PAGE21	lCPI65_8
    7664: 3dc00100     	ldr	q0, [x8]
		0000000000007664:  ARM64_RELOC_PAGEOFF12	lCPI65_8
    7668: 3d801fe0     	str	q0, [sp, #0x70]
    766c: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_finish$instance$4be10ff2429b6e66+0x48>
		000000000000766c:  ARM64_RELOC_PAGE21	lCPI65_9
    7670: 3dc00100     	ldr	q0, [x8]
		0000000000007670:  ARM64_RELOC_PAGEOFF12	lCPI65_9
    7674: 3d801be0     	str	q0, [sp, #0x60]
    7678: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_finish$instance$4be10ff2429b6e66+0x48>
		0000000000007678:  ARM64_RELOC_PAGE21	lCPI65_10
    767c: 3dc00100     	ldr	q0, [x8]
		000000000000767c:  ARM64_RELOC_PAGEOFF12	lCPI65_10
    7680: 3d8017e0     	str	q0, [sp, #0x50]
    7684: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_finish$instance$4be10ff2429b6e66+0x48>
		0000000000007684:  ARM64_RELOC_PAGE21	lCPI65_11
    7688: 3dc00100     	ldr	q0, [x8]
		0000000000007688:  ARM64_RELOC_PAGEOFF12	lCPI65_11
    768c: 3d8013e0     	str	q0, [sp, #0x40]
    7690: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_finish$instance$4be10ff2429b6e66+0x48>
		0000000000007690:  ARM64_RELOC_PAGE21	lCPI65_12
    7694: 3dc00100     	ldr	q0, [x8]
		0000000000007694:  ARM64_RELOC_PAGEOFF12	lCPI65_12
    7698: 3d800fe0     	str	q0, [sp, #0x30]
    769c: 5284001a     	mov	w26, #0x2000            ; =8192
    76a0: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_finish$instance$4be10ff2429b6e66+0x48>
		00000000000076a0:  ARM64_RELOC_PAGE21	lCPI65_13
    76a4: 3dc00100     	ldr	q0, [x8]
		00000000000076a4:  ARM64_RELOC_PAGEOFF12	lCPI65_13
    76a8: 3d800be0     	str	q0, [sp, #0x20]
    76ac: aa1303fb     	mov	x27, x19
    76b0: 90000008     	adrp	x8, 0x7000 <_wf_map_cost_lookup_finish$instance$4be10ff2429b6e66+0x48>
		00000000000076b0:  ARM64_RELOC_PAGE21	lCPI65_14
    76b4: 3dc00100     	ldr	q0, [x8]
		00000000000076b4:  ARM64_RELOC_PAGEOFF12	lCPI65_14
    76b8: 3d8007e0     	str	q0, [sp, #0x10]
    76bc: aa1403fc     	mov	x28, x20
    76c0: 14000014     	b	0x7710 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x250>
    76c4: f140083f     	cmp	x1, #0x2, lsl #12       ; =0x2000
    76c8: 9a9a3028     	csel	x8, x1, x26, lo
    76cc: d37ff901     	lsl	x1, x8, #1
    76d0: 910423e0     	add	x0, sp, #0x108
    76d4: 9104c3e2     	add	x2, sp, #0x130
    76d8: 94000000     	bl	0x76d8 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x218>
		00000000000076d8:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    76dc: b903cbe0     	str	w0, [sp, #0x3c8]
    76e0: 390f33e1     	strb	w1, [sp, #0x3cc]
    76e4: 390f37e2     	strb	w2, [sp, #0x3cd]
    76e8: 910503e0     	add	x0, sp, #0x140
    76ec: 910423e1     	add	x1, sp, #0x108
    76f0: 910943e3     	add	x3, sp, #0x250
    76f4: 9104c3e4     	add	x4, sp, #0x130
    76f8: aa1603e2     	mov	x2, x22
    76fc: 94000000     	bl	0x76fc <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x23c>
		00000000000076fc:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
    7700: 9100079c     	add	x28, x28, #0x1
    7704: 91000ad6     	add	x22, x22, #0x2
    7708: f100077b     	subs	x27, x27, #0x1
    770c: 54000a40     	b.eq	0x7854 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x394>
    7710: 4e080f80     	dup.2d	v0, x28
    7714: 91007f88     	add	x8, x28, #0x1f
    7718: 3dc03fe1     	ldr	q1, [sp, #0xf0]
    771c: 4ee18401     	add.2d	v1, v0, v1
    7720: 3c8082e1     	stur	q1, [x23, #0x8]
    7724: 3dc03be1     	ldr	q1, [sp, #0xe0]
    7728: 4ee18401     	add.2d	v1, v0, v1
    772c: 3c8182e1     	stur	q1, [x23, #0x18]
    7730: 3dc037e1     	ldr	q1, [sp, #0xd0]
    7734: 4ee18401     	add.2d	v1, v0, v1
    7738: 3c8282e1     	stur	q1, [x23, #0x28]
    773c: 3dc033e1     	ldr	q1, [sp, #0xc0]
    7740: 4ee18401     	add.2d	v1, v0, v1
    7744: 3c8382e1     	stur	q1, [x23, #0x38]
    7748: 3dc02fe1     	ldr	q1, [sp, #0xb0]
    774c: 4ee18401     	add.2d	v1, v0, v1
    7750: 3c8482e1     	stur	q1, [x23, #0x48]
    7754: 3dc02be1     	ldr	q1, [sp, #0xa0]
    7758: 4ee18401     	add.2d	v1, v0, v1
    775c: 3c8582e1     	stur	q1, [x23, #0x58]
    7760: 3dc027e1     	ldr	q1, [sp, #0x90]
    7764: 4ee18401     	add.2d	v1, v0, v1
    7768: 3c8682e1     	stur	q1, [x23, #0x68]
    776c: 3dc023e1     	ldr	q1, [sp, #0x80]
    7770: 4ee18401     	add.2d	v1, v0, v1
    7774: 3c8782e1     	stur	q1, [x23, #0x78]
    7778: 3dc01fe1     	ldr	q1, [sp, #0x70]
    777c: 4ee18401     	add.2d	v1, v0, v1
    7780: 3c8882e1     	stur	q1, [x23, #0x88]
    7784: 3dc01be1     	ldr	q1, [sp, #0x60]
    7788: 4ee18401     	add.2d	v1, v0, v1
    778c: 3c8982e1     	stur	q1, [x23, #0x98]
    7790: 3dc017e1     	ldr	q1, [sp, #0x50]
    7794: 4ee18401     	add.2d	v1, v0, v1
    7798: 3c8a82e1     	stur	q1, [x23, #0xa8]
    779c: 3dc013e1     	ldr	q1, [sp, #0x40]
    77a0: 4ee18401     	add.2d	v1, v0, v1
    77a4: 3c8b82e1     	stur	q1, [x23, #0xb8]
    77a8: 3dc00fe1     	ldr	q1, [sp, #0x30]
    77ac: 4ee18401     	add.2d	v1, v0, v1
    77b0: 3c8c82e1     	stur	q1, [x23, #0xc8]
    77b4: 3dc00be1     	ldr	q1, [sp, #0x20]
    77b8: 4ee18401     	add.2d	v1, v0, v1
    77bc: 3c8d82e1     	stur	q1, [x23, #0xd8]
    77c0: 3dc007e1     	ldr	q1, [sp, #0x10]
    77c4: 4ee18400     	add.2d	v0, v0, v1
    77c8: 3c8e82e0     	stur	q0, [x23, #0xe8]
    77cc: f9012bfc     	str	x28, [sp, #0x250]
    77d0: f901a7e8     	str	x8, [sp, #0x348]
    77d4: f94087e1     	ldr	x1, [sp, #0x108]
    77d8: f94097e8     	ldr	x8, [sp, #0x128]
    77dc: f9009308     	str	x8, [x24, #0x120]
    77e0: 910067e9     	add	x9, sp, #0x19
    77e4: 3ccff120     	ldur	q0, [x9, #0xff]
    77e8: 910027e9     	add	x9, sp, #0x9
    77ec: 3ccff121     	ldur	q1, [x9, #0xff]
    77f0: ad080301     	stp	q1, q0, [x24, #0x100]
    77f4: f9001328     	str	x8, [x25, #0x20]
    77f8: f941b7e8     	ldr	x8, [sp, #0x368]
    77fc: f941cfe9     	ldr	x9, [sp, #0x398]
    7800: ab090108     	adds	x8, x8, x9
    7804: da9f3109     	csinv	x9, x8, xzr, lo
    7808: d34efc28     	lsr	x8, x1, #14
    780c: ad000321     	stp	q1, q0, [x25]
    7810: b5fff6c8     	cbnz	x8, 0x76e8 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x228>
    7814: cb410828     	sub	x8, x1, x1, lsr #2
    7818: eb08013f     	cmp	x9, x8
    781c: 54fff663     	b.lo	0x76e8 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x228>
    7820: f94097e9     	ldr	x9, [sp, #0x128]
    7824: f900bb09     	str	x9, [x24, #0x170]
    7828: 910067e9     	add	x9, sp, #0x19
    782c: 3ccff120     	ldur	q0, [x9, #0xff]
    7830: 910027e9     	add	x9, sp, #0x9
    7834: 3ccff121     	ldur	q1, [x9, #0xff]
    7838: ad0a8301     	stp	q1, q0, [x24, #0x150]
    783c: f941dfe9     	ldr	x9, [sp, #0x3b8]
    7840: eb48053f     	cmp	x9, x8, lsr #1
    7844: 54fff463     	b.lo	0x76d0 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x210>
    7848: b5fff3e1     	cbnz	x1, 0x76c4 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x204>
    784c: 52800021     	mov	w1, #0x1                ; =1
    7850: 17ffffa0     	b	0x76d0 <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x210>
    7854: 910027e8     	add	x8, sp, #0x9
    7858: 3ccff100     	ldur	q0, [x8, #0xff]
    785c: 910067e8     	add	x8, sp, #0x19
    7860: 3ccff101     	ldur	q1, [x8, #0xff]
    7864: ad0006a0     	stp	q0, q1, [x21]
    7868: f94097e8     	ldr	x8, [sp, #0x128]
    786c: f90012a8     	str	x8, [x21, #0x20]
    7870: 3dc04fe0     	ldr	q0, [sp, #0x130]
    7874: 3c8282a0     	stur	q0, [x21, #0x28]
    7878: a903ceb4     	stp	x20, x19, [x21, #0x38]
    787c: 910f43ff     	add	sp, sp, #0x3d0
    7880: a9457bfd     	ldp	x29, x30, [sp, #0x50]
    7884: a9444ff4     	ldp	x20, x19, [sp, #0x40]
    7888: a94357f6     	ldp	x22, x21, [sp, #0x30]
    788c: a9425ff8     	ldp	x24, x23, [sp, #0x20]
    7890: a94167fa     	ldp	x26, x25, [sp, #0x10]
    7894: a8c66ffc     	ldp	x28, x27, [sp], #0x60
    7898: d65f03c0     	ret
    789c: 94000000     	bl	0x789c <_wf_map_cost_reserve_prepare$instance$4be10ff2429b6e66+0x3dc>
		000000000000789c:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

