000000000000a914 <_wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3>:
    a914: f9400828     	ldr	x8, [x1, #0x10]
    a918: 52800309     	mov	w9, #0x18               ; =24
    a91c: 9b092049     	madd	x9, x2, x9, x8
    a920: b9400128     	ldr	w8, [x9]
    a924: 3cc08120     	ldur	q0, [x9, #0x8]
    a928: 5280004a     	mov	w10, #0x2               ; =2
    a92c: b900012a     	str	w10, [x9]
    a930: a9009123     	stp	x3, x4, [x9, #0x8]
    a934: 34000068     	cbz	w8, 0xa940 <_wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3+0x2c>
    a938: 7100051f     	cmp	w8, #0x1
    a93c: 54000081     	b.ne	0xa94c <_wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3+0x38>
    a940: a9007c1f     	stp	xzr, xzr, [x0]
    a944: f900081f     	str	xzr, [x0, #0x10]
    a948: d65f03c0     	ret
    a94c: f900001f     	str	xzr, [x0]
    a950: 52800028     	mov	w8, #0x1                ; =1
    a954: b9000008     	str	w8, [x0]
    a958: 3c808000     	stur	q0, [x0, #0x8]
    a95c: d65f03c0     	ret

