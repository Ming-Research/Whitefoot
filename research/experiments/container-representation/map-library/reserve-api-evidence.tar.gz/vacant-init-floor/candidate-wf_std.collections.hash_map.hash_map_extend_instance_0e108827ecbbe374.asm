000000000000a22c <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374>:
    a22c: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    a230: a90157f6     	stp	x22, x21, [sp, #0x10]
    a234: a9024ff4     	stp	x20, x19, [sp, #0x20]
    a238: a9037bfd     	stp	x29, x30, [sp, #0x30]
    a23c: aa0103f4     	mov	x20, x1
    a240: aa0003f3     	mov	x19, x0
    a244: a9405817     	ldp	x23, x22, [x0]
    a248: eb0102df     	cmp	x22, x1
    a24c: 54000302     	b.hs	0xa2ac <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x80>
    a250: f9400a75     	ldr	x21, [x19, #0x10]
    a254: 8b141288     	add	x8, x20, x20, lsl #4
    a258: d37ced01     	lsl	x1, x8, #4
    a25c: f10002df     	cmp	x22, #0x0
    a260: fa5612e0     	ccmp	x23, x22, #0x0, ne
    a264: 540001c0     	b.eq	0xa29c <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x70>
    a268: aa0103e0     	mov	x0, x1
    a26c: 94000000     	bl	0xa26c <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x40>
		000000000000a26c:  ARM64_RELOC_BRANCH26	_malloc
    a270: b4000640     	cbz	x0, 0xa338 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x10c>
    a274: b40001b6     	cbz	x22, 0xa2a8 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x7c>
    a278: 8b1712e8     	add	x8, x23, x23, lsl #4
    a27c: d37ced02     	lsl	x2, x8, #4
    a280: aa0003f6     	mov	x22, x0
    a284: aa1503e1     	mov	x1, x21
    a288: 94000000     	bl	0xa288 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x5c>
		000000000000a288:  ARM64_RELOC_BRANCH26	_memcpy
    a28c: aa1503e0     	mov	x0, x21
    a290: 94000000     	bl	0xa290 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x64>
		000000000000a290:  ARM64_RELOC_BRANCH26	_free
    a294: aa1603e0     	mov	x0, x22
    a298: 14000004     	b	0xa2a8 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x7c>
    a29c: aa1503e0     	mov	x0, x21
    a2a0: 94000000     	bl	0xa2a0 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x74>
		000000000000a2a0:  ARM64_RELOC_BRANCH26	_realloc
    a2a4: b40004a0     	cbz	x0, 0xa338 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x10c>
    a2a8: a9008274     	stp	x20, x0, [x19, #0x8]
    a2ac: eb17028a     	subs	x10, x20, x23
    a2b0: 54000389     	b.ls	0xa320 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xf4>
    a2b4: f9400a69     	ldr	x9, [x19, #0x10]
    a2b8: aa1703e8     	mov	x8, x23
    a2bc: f100115f     	cmp	x10, #0x4
    a2c0: 540001e3     	b.lo	0xa2fc <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xd0>
    a2c4: 927ef54b     	and	x11, x10, #0xfffffffffffffffc
    a2c8: 8b0b02e8     	add	x8, x23, x11
    a2cc: 5280220c     	mov	w12, #0x110             ; =272
    a2d0: 9b0c26ec     	madd	x12, x23, x12, x9
    a2d4: aa0b03ed     	mov	x13, x11
    a2d8: b900019f     	str	wzr, [x12]
    a2dc: b901119f     	str	wzr, [x12, #0x110]
    a2e0: b902219f     	str	wzr, [x12, #0x220]
    a2e4: b903319f     	str	wzr, [x12, #0x330]
    a2e8: 9111018c     	add	x12, x12, #0x440
    a2ec: f10011ad     	subs	x13, x13, #0x4
    a2f0: 54ffff41     	b.ne	0xa2d8 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xac>
    a2f4: eb0b015f     	cmp	x10, x11
    a2f8: 54000120     	b.eq	0xa31c <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xf0>
    a2fc: 5280220a     	mov	w10, #0x110             ; =272
    a300: 9b0a2509     	madd	x9, x8, x10, x9
    a304: cb08028a     	sub	x10, x20, x8
    a308: b900013f     	str	wzr, [x9]
    a30c: 91000508     	add	x8, x8, #0x1
    a310: 91044129     	add	x9, x9, #0x110
    a314: f100054a     	subs	x10, x10, #0x1
    a318: 54ffff81     	b.ne	0xa308 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xdc>
    a31c: f9000268     	str	x8, [x19]
    a320: 52800000     	mov	w0, #0x0                ; =0
    a324: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    a328: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    a32c: a94157f6     	ldp	x22, x21, [sp, #0x10]
    a330: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    a334: d65f03c0     	ret
    a338: 94000000     	bl	0xa338 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x10c>
		000000000000a338:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

