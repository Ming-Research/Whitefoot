0000000000009da4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07>:
    9da4: a9ba6ffc     	stp	x28, x27, [sp, #-0x60]!
    9da8: a90167fa     	stp	x26, x25, [sp, #0x10]
    9dac: a9025ff8     	stp	x24, x23, [sp, #0x20]
    9db0: a90357f6     	stp	x22, x21, [sp, #0x30]
    9db4: a9044ff4     	stp	x20, x19, [sp, #0x40]
    9db8: a9057bfd     	stp	x29, x30, [sp, #0x50]
    9dbc: d10943ff     	sub	sp, sp, #0x250
    9dc0: f1000c3f     	cmp	x1, #0x3
    9dc4: 540000c8     	b.hi	0x9ddc <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x38>
    9dc8: aa0103f4     	mov	x20, x1
    9dcc: aa0003f3     	mov	x19, x0
    9dd0: f9400016     	ldr	x22, [x0]
    9dd4: eb16003f     	cmp	x1, x22
    9dd8: 54000182     	b.hs	0x9e08 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x64>
    9ddc: 52800020     	mov	w0, #0x1                ; =1
    9de0: 52800001     	mov	w1, #0x0                ; =0
    9de4: 52800002     	mov	w2, #0x0                ; =0
    9de8: 910943ff     	add	sp, sp, #0x250
    9dec: a9457bfd     	ldp	x29, x30, [sp, #0x50]
    9df0: a9444ff4     	ldp	x20, x19, [sp, #0x40]
    9df4: a94357f6     	ldp	x22, x21, [sp, #0x30]
    9df8: a9425ff8     	ldp	x24, x23, [sp, #0x20]
    9dfc: a94167fa     	ldp	x26, x25, [sp, #0x10]
    9e00: a8c66ffc     	ldp	x28, x27, [sp], #0x60
    9e04: d65f03c0     	ret
    9e08: b40014f4     	cbz	x20, 0xa0a4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x300>
    9e0c: f9400059     	ldr	x25, [x2]
    9e10: 39402048     	ldrb	w8, [x2, #0x8]
    9e14: b9001fe8     	str	w8, [sp, #0x1c]
    9e18: 8b141288     	add	x8, x20, x20, lsl #4
    9e1c: d37ced00     	lsl	x0, x8, #4
    9e20: 94000000     	bl	0x9e20 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x7c>
		0000000000009e20:  ARM64_RELOC_BRANCH26	_malloc
    9e24: b4001440     	cbz	x0, 0xa0ac <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x308>
    9e28: aa0003f5     	mov	x21, x0
    9e2c: d2800008     	mov	x8, #0x0                ; =0
    9e30: aa0003e9     	mov	x9, x0
    9e34: b900013f     	str	wzr, [x9]
    9e38: 91000508     	add	x8, x8, #0x1
    9e3c: 91044129     	add	x9, x9, #0x110
    9e40: eb08029f     	cmp	x20, x8
    9e44: 54ffff81     	b.ne	0x9e34 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x90>
    9e48: a940a269     	ldp	x9, x8, [x19, #0x8]
    9e4c: f9000be9     	str	x9, [sp, #0x10]
    9e50: f90013e8     	str	x8, [sp, #0x20]
    9e54: a9005274     	stp	x20, x20, [x19]
    9e58: f9000a75     	str	x21, [x19, #0x10]
    9e5c: b4001176     	cbz	x22, 0xa088 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x2e4>
    9e60: 5280221a     	mov	w26, #0x110             ; =272
    9e64: 9100c3fb     	add	x27, sp, #0x30
    9e68: d2823d78     	mov	x24, #0x11eb            ; =4587
    9e6c: f2a26638     	movk	x24, #0x1331, lsl #16
    9e70: f2c93778     	movk	x24, #0x49bb, lsl #32
    9e74: f2f29a18     	movk	x24, #0x94d0, lsl #48
    9e78: 14000003     	b	0x9e84 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0xe0>
    9e7c: f94017f6     	ldr	x22, [sp, #0x28]
    9e80: b4001056     	cbz	x22, 0xa088 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x2e4>
    9e84: d10006d6     	sub	x22, x22, #0x1
    9e88: f90017f6     	str	x22, [sp, #0x28]
    9e8c: f94013e8     	ldr	x8, [sp, #0x20]
    9e90: 9b1a22c8     	madd	x8, x22, x26, x8
    9e94: b9400109     	ldr	w9, [x8]
    9e98: 7100053f     	cmp	w9, #0x1
    9e9c: 54ffff09     	b.ls	0x9e7c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0xd8>
    9ea0: f9408509     	ldr	x9, [x8, #0x108]
    9ea4: 3cc08100     	ldur	q0, [x8, #0x8]
    9ea8: 3c8383e0     	stur	q0, [sp, #0x38]
    9eac: 3cc18100     	ldur	q0, [x8, #0x18]
    9eb0: 3c8483e0     	stur	q0, [sp, #0x48]
    9eb4: 3cc28100     	ldur	q0, [x8, #0x28]
    9eb8: 3c8583e0     	stur	q0, [sp, #0x58]
    9ebc: 3cc38100     	ldur	q0, [x8, #0x38]
    9ec0: 3c8683e0     	stur	q0, [sp, #0x68]
    9ec4: 3cc48100     	ldur	q0, [x8, #0x48]
    9ec8: 3c8783e0     	stur	q0, [sp, #0x78]
    9ecc: 3cc58100     	ldur	q0, [x8, #0x58]
    9ed0: 3c8883e0     	stur	q0, [sp, #0x88]
    9ed4: 3cc68100     	ldur	q0, [x8, #0x68]
    9ed8: 3c8983e0     	stur	q0, [sp, #0x98]
    9edc: 3cc78100     	ldur	q0, [x8, #0x78]
    9ee0: 3c8a83e0     	stur	q0, [sp, #0xa8]
    9ee4: 3cc88100     	ldur	q0, [x8, #0x88]
    9ee8: 9100c3ea     	add	x10, sp, #0x30
    9eec: 3c888140     	stur	q0, [x10, #0x88]
    9ef0: 3cc98100     	ldur	q0, [x8, #0x98]
    9ef4: 3c898140     	stur	q0, [x10, #0x98]
    9ef8: 3cca8100     	ldur	q0, [x8, #0xa8]
    9efc: 3c8a8140     	stur	q0, [x10, #0xa8]
    9f00: 3ccb8100     	ldur	q0, [x8, #0xb8]
    9f04: 3c8b8140     	stur	q0, [x10, #0xb8]
    9f08: 3ccc8100     	ldur	q0, [x8, #0xc8]
    9f0c: 3c8c8140     	stur	q0, [x10, #0xc8]
    9f10: 3ccd8100     	ldur	q0, [x8, #0xd8]
    9f14: 3c8d8140     	stur	q0, [x10, #0xd8]
    9f18: 3cce8100     	ldur	q0, [x8, #0xe8]
    9f1c: 3c8e8140     	stur	q0, [x10, #0xe8]
    9f20: 3ccf8100     	ldur	q0, [x8, #0xf8]
    9f24: 3c8f8140     	stur	q0, [x10, #0xf8]
    9f28: f9009fe9     	str	x9, [sp, #0x138]
    9f2c: 52800028     	mov	w8, #0x1                ; =1
    9f30: f9001be8     	str	x8, [sp, #0x30]
    9f34: b9401fe8     	ldr	w8, [sp, #0x1c]
    9f38: 36000448     	tbz	w8, #0x0, 0x9fc0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x21c>
    9f3c: 5280003c     	mov	w28, #0x1               ; =1
    9f40: 14000013     	b	0x9f8c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x1e8>
    9f44: d1000796     	sub	x22, x28, #0x1
    9f48: f9001bf6     	str	x22, [sp, #0x30]
    9f4c: 52802108     	mov	w8, #0x108              ; =264
    9f50: 9b086f97     	madd	x23, x28, x8, x27
    9f54: f8500ee3     	ldr	x3, [x23, #-0x100]!
    9f58: 910503e0     	add	x0, sp, #0x140
    9f5c: 910022e4     	add	x4, x23, #0x8
    9f60: aa1303e1     	mov	x1, x19
    9f64: 94000000     	bl	0x9f64 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x1c0>
		0000000000009f64:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    9f68: b94143e8     	ldr	w8, [sp, #0x140]
    9f6c: 34000248     	cbz	w8, 0x9fb4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x210>
    9f70: 910503e8     	add	x8, sp, #0x140
    9f74: 91002101     	add	x1, x8, #0x8
    9f78: aa1703e0     	mov	x0, x23
    9f7c: 52802102     	mov	w2, #0x108              ; =264
    9f80: 94000000     	bl	0x9f80 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x1dc>
		0000000000009f80:  ARM64_RELOC_BRANCH26	_memcpy
    9f84: f9001bfc     	str	x28, [sp, #0x30]
    9f88: b4fff7bc     	cbz	x28, 0x9e7c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0xd8>
    9f8c: d2800002     	mov	x2, #0x0                ; =0
    9f90: aa1503e8     	mov	x8, x21
    9f94: b9400109     	ldr	w9, [x8]
    9f98: 7100093f     	cmp	w9, #0x2
    9f9c: 54fffd43     	b.lo	0x9f44 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x1a0>
    9fa0: 91044108     	add	x8, x8, #0x110
    9fa4: 91000442     	add	x2, x2, #0x1
    9fa8: eb02029f     	cmp	x20, x2
    9fac: 54ffff41     	b.ne	0x9f94 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x1f0>
    9fb0: 17fffff6     	b	0x9f88 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x1e4>
    9fb4: aa1603fc     	mov	x28, x22
    9fb8: b5fffeb6     	cbnz	x22, 0x9f8c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x1e8>
    9fbc: 17ffffb0     	b	0x9e7c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0xd8>
    9fc0: 52800036     	mov	w22, #0x1               ; =1
    9fc4: 14000013     	b	0xa010 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x26c>
    9fc8: d10006dc     	sub	x28, x22, #0x1
    9fcc: f9001bfc     	str	x28, [sp, #0x30]
    9fd0: 52802108     	mov	w8, #0x108              ; =264
    9fd4: 9b086ed7     	madd	x23, x22, x8, x27
    9fd8: f8500ee3     	ldr	x3, [x23, #-0x100]!
    9fdc: 910503e0     	add	x0, sp, #0x140
    9fe0: 910022e4     	add	x4, x23, #0x8
    9fe4: aa1303e1     	mov	x1, x19
    9fe8: 94000000     	bl	0x9fe8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x244>
		0000000000009fe8:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    9fec: b94143e8     	ldr	w8, [sp, #0x140]
    9ff0: 34000468     	cbz	w8, 0xa07c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x2d8>
    9ff4: 910503e8     	add	x8, sp, #0x140
    9ff8: 91002101     	add	x1, x8, #0x8
    9ffc: aa1703e0     	mov	x0, x23
    a000: 52802102     	mov	w2, #0x108              ; =264
    a004: 94000000     	bl	0xa004 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x260>
		000000000000a004:  ARM64_RELOC_BRANCH26	_memcpy
    a008: f9001bf6     	str	x22, [sp, #0x30]
    a00c: b4fff396     	cbz	x22, 0x9e7c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0xd8>
    a010: d2800008     	mov	x8, #0x0                ; =0
    a014: f9401fe9     	ldr	x9, [sp, #0x38]
    a018: ca190129     	eor	x9, x9, x25
    a01c: ca497929     	eor	x9, x9, x9, lsr #30
    a020: d29cb72a     	mov	x10, #0xe5b9            ; =58809
    a024: f2a39c8a     	movk	x10, #0x1ce4, lsl #16
    a028: f2c8edaa     	movk	x10, #0x476d, lsl #32
    a02c: f2f7eb0a     	movk	x10, #0xbf58, lsl #48
    a030: 9b0a7d29     	mul	x9, x9, x10
    a034: ca496d29     	eor	x9, x9, x9, lsr #27
    a038: 9b187d29     	mul	x9, x9, x24
    a03c: ca497d29     	eor	x9, x9, x9, lsr #31
    a040: 9ad4092a     	udiv	x10, x9, x20
    a044: 9b14a549     	msub	x9, x10, x20, x9
    a048: cb09028a     	sub	x10, x20, x9
    a04c: cb0a03eb     	neg	x11, x10
    a050: eb0a011f     	cmp	x8, x10
    a054: 9a8b312c     	csel	x12, x9, x11, lo
    a058: 8b080182     	add	x2, x12, x8
    a05c: 9b1a7c4c     	mul	x12, x2, x26
    a060: b86c6aac     	ldr	w12, [x21, x12]
    a064: 7100099f     	cmp	w12, #0x2
    a068: 54fffb03     	b.lo	0x9fc8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x224>
    a06c: 91000508     	add	x8, x8, #0x1
    a070: eb08029f     	cmp	x20, x8
    a074: 54fffee1     	b.ne	0xa050 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x2ac>
    a078: 17ffffe5     	b	0xa00c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x268>
    a07c: aa1c03f6     	mov	x22, x28
    a080: b5fffc9c     	cbnz	x28, 0xa010 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x26c>
    a084: 17ffff7e     	b	0x9e7c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0xd8>
    a088: f9400be8     	ldr	x8, [sp, #0x10]
    a08c: b4000068     	cbz	x8, 0xa098 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x2f4>
    a090: f94013e0     	ldr	x0, [sp, #0x20]
    a094: 94000000     	bl	0xa094 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x2f0>
		000000000000a094:  ARM64_RELOC_BRANCH26	_free
    a098: 52800000     	mov	w0, #0x0                ; =0
    a09c: f900127f     	str	xzr, [x19, #0x20]
    a0a0: 17ffff50     	b	0x9de0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x3c>
    a0a4: 52800000     	mov	w0, #0x0                ; =0
    a0a8: 17ffff4e     	b	0x9de0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x3c>
    a0ac: 94000000     	bl	0xa0ac <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x308>
		000000000000a0ac:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

