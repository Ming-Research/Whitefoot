00000000000091b4 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca>:
    91b4: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    91b8: a90157f6     	stp	x22, x21, [sp, #0x10]
    91bc: a9024ff4     	stp	x20, x19, [sp, #0x20]
    91c0: a9037bfd     	stp	x29, x30, [sp, #0x30]
    91c4: aa0103f4     	mov	x20, x1
    91c8: aa0003f3     	mov	x19, x0
    91cc: a9405817     	ldp	x23, x22, [x0]
    91d0: eb0102df     	cmp	x22, x1
    91d4: 54000302     	b.hs	0x9234 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x80>
    91d8: f9400a75     	ldr	x21, [x19, #0x10]
    91dc: 8b140688     	add	x8, x20, x20, lsl #1
    91e0: d37df101     	lsl	x1, x8, #3
    91e4: f10002df     	cmp	x22, #0x0
    91e8: fa5612e0     	ccmp	x23, x22, #0x0, ne
    91ec: 540001c0     	b.eq	0x9224 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x70>
    91f0: aa0103e0     	mov	x0, x1
    91f4: 94000000     	bl	0x91f4 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x40>
		00000000000091f4:  ARM64_RELOC_BRANCH26	_malloc
    91f8: b4000640     	cbz	x0, 0x92c0 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x10c>
    91fc: b40001b6     	cbz	x22, 0x9230 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x7c>
    9200: 8b1706e8     	add	x8, x23, x23, lsl #1
    9204: d37df102     	lsl	x2, x8, #3
    9208: aa0003f6     	mov	x22, x0
    920c: aa1503e1     	mov	x1, x21
    9210: 94000000     	bl	0x9210 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x5c>
		0000000000009210:  ARM64_RELOC_BRANCH26	_memcpy
    9214: aa1503e0     	mov	x0, x21
    9218: 94000000     	bl	0x9218 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x64>
		0000000000009218:  ARM64_RELOC_BRANCH26	_free
    921c: aa1603e0     	mov	x0, x22
    9220: 14000004     	b	0x9230 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x7c>
    9224: aa1503e0     	mov	x0, x21
    9228: 94000000     	bl	0x9228 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x74>
		0000000000009228:  ARM64_RELOC_BRANCH26	_realloc
    922c: b40004a0     	cbz	x0, 0x92c0 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x10c>
    9230: a9008274     	stp	x20, x0, [x19, #0x8]
    9234: eb17028a     	subs	x10, x20, x23
    9238: 54000389     	b.ls	0x92a8 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xf4>
    923c: f9400a69     	ldr	x9, [x19, #0x10]
    9240: aa1703e8     	mov	x8, x23
    9244: f100115f     	cmp	x10, #0x4
    9248: 54000203     	b.lo	0x9288 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xd4>
    924c: 927ef54b     	and	x11, x10, #0xfffffffffffffffc
    9250: 8b0b02e8     	add	x8, x23, x11
    9254: 5280030c     	mov	w12, #0x18              ; =24
    9258: 9b0c26ec     	madd	x12, x23, x12, x9
    925c: 9100c18c     	add	x12, x12, #0x30
    9260: aa0b03ed     	mov	x13, x11
    9264: b81d019f     	stur	wzr, [x12, #-0x30]
    9268: b81e819f     	stur	wzr, [x12, #-0x18]
    926c: b900019f     	str	wzr, [x12]
    9270: b900199f     	str	wzr, [x12, #0x18]
    9274: 9101818c     	add	x12, x12, #0x60
    9278: f10011ad     	subs	x13, x13, #0x4
    927c: 54ffff41     	b.ne	0x9264 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xb0>
    9280: eb0b015f     	cmp	x10, x11
    9284: 54000100     	b.eq	0x92a4 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xf0>
    9288: 5280030a     	mov	w10, #0x18              ; =24
    928c: 9b0a2509     	madd	x9, x8, x10, x9
    9290: cb08028a     	sub	x10, x20, x8
    9294: b801853f     	str	wzr, [x9], #0x18
    9298: 91000508     	add	x8, x8, #0x1
    929c: f100054a     	subs	x10, x10, #0x1
    92a0: 54ffffa1     	b.ne	0x9294 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xe0>
    92a4: f9000268     	str	x8, [x19]
    92a8: 52800000     	mov	w0, #0x0                ; =0
    92ac: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    92b0: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    92b4: a94157f6     	ldp	x22, x21, [sp, #0x10]
    92b8: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    92bc: d65f03c0     	ret
    92c0: 94000000     	bl	0x92c0 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x10c>
		00000000000092c0:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

