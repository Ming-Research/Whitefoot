00000000000078a0 <_wf_map_cost_reserve_step$instance$9fed7d4c5d7cc122>:
    78a0: 92840008     	mov	x8, #-0x2001            ; =-8193
    78a4: 8b080028     	add	x8, x1, x8
    78a8: b140091f     	cmn	x8, #0x2, lsl #12       ; =0x2000
    78ac: 54000243     	b.lo	0x78f4 <_wf_map_cost_reserve_step$instance$9fed7d4c5d7cc122+0x54>
    78b0: 531e7428     	lsl	w8, w1, #2
    78b4: 51001108     	sub	w8, w8, #0x4
    78b8: 121e3508     	and	w8, w8, #0xfffc
    78bc: 52955569     	mov	w9, #0xaaab             ; =43691
    78c0: 1b097d08     	mul	w8, w8, w9
    78c4: 53117d08     	lsr	w8, w8, #17
    78c8: 11000501     	add	w1, w8, #0x1
    78cc: f9400008     	ldr	x8, [x0]
    78d0: eb01011f     	cmp	x8, x1
    78d4: 54000102     	b.hs	0x78f4 <_wf_map_cost_reserve_step$instance$9fed7d4c5d7cc122+0x54>
    78d8: a9bf7bfd     	stp	x29, x30, [sp, #-0x10]!
    78dc: 9100a002     	add	x2, x0, #0x28
    78e0: 94000000     	bl	0x78e0 <_wf_map_cost_reserve_step$instance$9fed7d4c5d7cc122+0x40>
		00000000000078e0:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    78e4: a8c17bfd     	ldp	x29, x30, [sp], #0x10
    78e8: 34000060     	cbz	w0, 0x78f4 <_wf_map_cost_reserve_step$instance$9fed7d4c5d7cc122+0x54>
    78ec: d2800000     	mov	x0, #0x0                ; =0
    78f0: d65f03c0     	ret
    78f4: 52800020     	mov	w0, #0x1                ; =1
    78f8: d65f03c0     	ret

