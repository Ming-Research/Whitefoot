0000000000008fa4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6>:
    8fa4: d10183ff     	sub	sp, sp, #0x60
    8fa8: a9025ff8     	stp	x24, x23, [sp, #0x20]
    8fac: a90357f6     	stp	x22, x21, [sp, #0x30]
    8fb0: a9044ff4     	stp	x20, x19, [sp, #0x40]
    8fb4: a9057bfd     	stp	x29, x30, [sp, #0x50]
    8fb8: f1000c3f     	cmp	x1, #0x3
    8fbc: 54000088     	b.hi	0x8fcc <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x28>
    8fc0: f9400014     	ldr	x20, [x0]
    8fc4: eb14003f     	cmp	x1, x20
    8fc8: 54000142     	b.hs	0x8ff0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x4c>
    8fcc: 52800020     	mov	w0, #0x1                ; =1
    8fd0: 52800001     	mov	w1, #0x0                ; =0
    8fd4: 52800002     	mov	w2, #0x0                ; =0
    8fd8: a9457bfd     	ldp	x29, x30, [sp, #0x50]
    8fdc: a9444ff4     	ldp	x20, x19, [sp, #0x40]
    8fe0: a94357f6     	ldp	x22, x21, [sp, #0x30]
    8fe4: a9425ff8     	ldp	x24, x23, [sp, #0x20]
    8fe8: 910183ff     	add	sp, sp, #0x60
    8fec: d65f03c0     	ret
    8ff0: b40006a1     	cbz	x1, 0x90c4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x120>
    8ff4: aa0003f3     	mov	x19, x0
    8ff8: f9400055     	ldr	x21, [x2]
    8ffc: 39402056     	ldrb	w22, [x2, #0x8]
    9000: aa0103f7     	mov	x23, x1
    9004: 8b010428     	add	x8, x1, x1, lsl #1
    9008: d37df100     	lsl	x0, x8, #3
    900c: 94000000     	bl	0x900c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x68>
		000000000000900c:  ARM64_RELOC_BRANCH26	_malloc
    9010: b4000d20     	cbz	x0, 0x91b4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x210>
    9014: d2800008     	mov	x8, #0x0                ; =0
    9018: 9100200b     	add	x11, x0, #0x8
    901c: aa1303e9     	mov	x9, x19
    9020: aa1703ea     	mov	x10, x23
    9024: b81f817f     	stur	wzr, [x11, #-0x8]
    9028: 91000508     	add	x8, x8, #0x1
    902c: a881fd7f     	stp	xzr, xzr, [x11], #0x18
    9030: eb08015f     	cmp	x10, x8
    9034: 54ffff81     	b.ne	0x9024 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x80>
    9038: a940a12b     	ldp	x11, x8, [x9, #0x8]
    903c: a900292a     	stp	x10, x10, [x9]
    9040: f9000920     	str	x0, [x9, #0x10]
    9044: b4000ab4     	cbz	x20, 0x9198 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1f4>
    9048: 5280030c     	mov	w12, #0x18              ; =24
    904c: 36000416     	tbz	w22, #0x0, 0x90cc <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x128>
    9050: 910023ed     	add	x13, sp, #0x8
    9054: 5280004e     	mov	w14, #0x2               ; =2
    9058: 14000002     	b	0x9060 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xbc>
    905c: b40009f4     	cbz	x20, 0x9198 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1f4>
    9060: d1000694     	sub	x20, x20, #0x1
    9064: 9b0c228f     	madd	x15, x20, x12, x8
    9068: b94001f0     	ldr	w16, [x15]
    906c: 71000a1f     	cmp	w16, #0x2
    9070: 54ffff63     	b.lo	0x905c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xb8>
    9074: 3cc081e0     	ldur	q0, [x15, #0x8]
    9078: 3c8103e0     	stur	q0, [sp, #0x10]
    907c: 5280002f     	mov	w15, #0x1               ; =1
    9080: 14000008     	b	0x90a0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xfc>
    9084: d10005ef     	sub	x15, x15, #0x1
    9088: 8b0f11b1     	add	x17, x13, x15, lsl #4
    908c: f90007ef     	str	x15, [sp, #0x8]
    9090: b900020e     	str	w14, [x16]
    9094: 3cc08220     	ldur	q0, [x17, #0x8]
    9098: 3c808200     	stur	q0, [x16, #0x8]
    909c: b4fffe0f     	cbz	x15, 0x905c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xb8>
    90a0: aa0003f0     	mov	x16, x0
    90a4: aa0a03f1     	mov	x17, x10
    90a8: b9400201     	ldr	w1, [x16]
    90ac: 7100043f     	cmp	w1, #0x1
    90b0: 54fffea9     	b.ls	0x9084 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xe0>
    90b4: 91006210     	add	x16, x16, #0x18
    90b8: f1000631     	subs	x17, x17, #0x1
    90bc: 54ffff61     	b.ne	0x90a8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x104>
    90c0: 17fffff7     	b	0x909c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xf8>
    90c4: 52800000     	mov	w0, #0x0                ; =0
    90c8: 17ffffc2     	b	0x8fd0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x2c>
    90cc: d29cb72d     	mov	x13, #0xe5b9            ; =58809
    90d0: f2a39c8d     	movk	x13, #0x1ce4, lsl #16
    90d4: f2c8edad     	movk	x13, #0x476d, lsl #32
    90d8: f2f7eb0d     	movk	x13, #0xbf58, lsl #48
    90dc: d2823d6e     	mov	x14, #0x11eb            ; =4587
    90e0: f2a2662e     	movk	x14, #0x1331, lsl #16
    90e4: f2c9376e     	movk	x14, #0x49bb, lsl #32
    90e8: f2f29a0e     	movk	x14, #0x94d0, lsl #48
    90ec: 910023ef     	add	x15, sp, #0x8
    90f0: 52800050     	mov	w16, #0x2               ; =2
    90f4: 14000002     	b	0x90fc <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x158>
    90f8: b4000514     	cbz	x20, 0x9198 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1f4>
    90fc: d1000694     	sub	x20, x20, #0x1
    9100: 9b0c2291     	madd	x17, x20, x12, x8
    9104: b9400221     	ldr	w1, [x17]
    9108: 7100043f     	cmp	w1, #0x1
    910c: 54ffff69     	b.ls	0x90f8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x154>
    9110: 3cc08220     	ldur	q0, [x17, #0x8]
    9114: f9400631     	ldr	x17, [x17, #0x8]
    9118: 3c8103e0     	stur	q0, [sp, #0x10]
    911c: ca150231     	eor	x17, x17, x21
    9120: ca517a31     	eor	x17, x17, x17, lsr #30
    9124: 9b0d7e31     	mul	x17, x17, x13
    9128: ca516e31     	eor	x17, x17, x17, lsr #27
    912c: 9b0e7e31     	mul	x17, x17, x14
    9130: ca517e31     	eor	x17, x17, x17, lsr #31
    9134: 9aca0a21     	udiv	x1, x17, x10
    9138: 9b0ac431     	msub	x17, x1, x10, x17
    913c: cb110141     	sub	x1, x10, x17
    9140: cb0103e2     	neg	x2, x1
    9144: 52800023     	mov	w3, #0x1                ; =1
    9148: 14000008     	b	0x9168 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1c4>
    914c: d1000463     	sub	x3, x3, #0x1
    9150: 8b0311e4     	add	x4, x15, x3, lsl #4
    9154: f90007e3     	str	x3, [sp, #0x8]
    9158: b90000b0     	str	w16, [x5]
    915c: 3cc08080     	ldur	q0, [x4, #0x8]
    9160: 3c8080a0     	stur	q0, [x5, #0x8]
    9164: b4fffca3     	cbz	x3, 0x90f8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x154>
    9168: d2800004     	mov	x4, #0x0                ; =0
    916c: eb01009f     	cmp	x4, x1
    9170: 9a823225     	csel	x5, x17, x2, lo
    9174: 8b0400a5     	add	x5, x5, x4
    9178: 9b0c00a5     	madd	x5, x5, x12, x0
    917c: b94000a6     	ldr	w6, [x5]
    9180: 710008df     	cmp	w6, #0x2
    9184: 54fffe43     	b.lo	0x914c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1a8>
    9188: 91000484     	add	x4, x4, #0x1
    918c: eb04015f     	cmp	x10, x4
    9190: 54fffee1     	b.ne	0x916c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1c8>
    9194: 17fffff4     	b	0x9164 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1c0>
    9198: b400008b     	cbz	x11, 0x91a8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x204>
    919c: aa0803e0     	mov	x0, x8
    91a0: 94000000     	bl	0x91a0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1fc>
		00000000000091a0:  ARM64_RELOC_BRANCH26	_free
    91a4: aa1303e9     	mov	x9, x19
    91a8: 52800000     	mov	w0, #0x0                ; =0
    91ac: f900113f     	str	xzr, [x9, #0x20]
    91b0: 17ffff88     	b	0x8fd0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x2c>
    91b4: 94000000     	bl	0x91b4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x210>
		00000000000091b4:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

