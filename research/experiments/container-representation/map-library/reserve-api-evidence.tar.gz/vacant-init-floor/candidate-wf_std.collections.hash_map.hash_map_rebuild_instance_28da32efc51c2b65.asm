000000000000a33c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65>:
    a33c: a9ba6ffc     	stp	x28, x27, [sp, #-0x60]!
    a340: a90167fa     	stp	x26, x25, [sp, #0x10]
    a344: a9025ff8     	stp	x24, x23, [sp, #0x20]
    a348: a90357f6     	stp	x22, x21, [sp, #0x30]
    a34c: a9044ff4     	stp	x20, x19, [sp, #0x40]
    a350: a9057bfd     	stp	x29, x30, [sp, #0x50]
    a354: d10943ff     	sub	sp, sp, #0x250
    a358: f140103f     	cmp	x1, #0x4, lsl #12       ; =0x4000
    a35c: 540000c8     	b.hi	0xa374 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x38>
    a360: aa0103f4     	mov	x20, x1
    a364: aa0003f3     	mov	x19, x0
    a368: f9400016     	ldr	x22, [x0]
    a36c: eb16003f     	cmp	x1, x22
    a370: 54000182     	b.hs	0xa3a0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x64>
    a374: 52800020     	mov	w0, #0x1                ; =1
    a378: 52800001     	mov	w1, #0x0                ; =0
    a37c: 52800002     	mov	w2, #0x0                ; =0
    a380: 910943ff     	add	sp, sp, #0x250
    a384: a9457bfd     	ldp	x29, x30, [sp, #0x50]
    a388: a9444ff4     	ldp	x20, x19, [sp, #0x40]
    a38c: a94357f6     	ldp	x22, x21, [sp, #0x30]
    a390: a9425ff8     	ldp	x24, x23, [sp, #0x20]
    a394: a94167fa     	ldp	x26, x25, [sp, #0x10]
    a398: a8c66ffc     	ldp	x28, x27, [sp], #0x60
    a39c: d65f03c0     	ret
    a3a0: b40001b4     	cbz	x20, 0xa3d4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x98>
    a3a4: f9400059     	ldr	x25, [x2]
    a3a8: 39402048     	ldrb	w8, [x2, #0x8]
    a3ac: b9001fe8     	str	w8, [sp, #0x1c]
    a3b0: 8b141288     	add	x8, x20, x20, lsl #4
    a3b4: d37ced00     	lsl	x0, x8, #4
    a3b8: 94000000     	bl	0xa3b8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x7c>
		000000000000a3b8:  ARM64_RELOC_BRANCH26	_malloc
    a3bc: b4001660     	cbz	x0, 0xa688 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x34c>
    a3c0: aa0003f5     	mov	x21, x0
    a3c4: f100129f     	cmp	x20, #0x4
    a3c8: 540000a2     	b.hs	0xa3dc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xa0>
    a3cc: d2800008     	mov	x8, #0x0                ; =0
    a3d0: 14000010     	b	0xa410 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xd4>
    a3d4: 52800000     	mov	w0, #0x0                ; =0
    a3d8: 17ffffe8     	b	0xa378 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x3c>
    a3dc: d2800009     	mov	x9, #0x0                ; =0
    a3e0: 927e3288     	and	x8, x20, #0x7ffc
    a3e4: aa1503ea     	mov	x10, x21
    a3e8: b900015f     	str	wzr, [x10]
    a3ec: b901115f     	str	wzr, [x10, #0x110]
    a3f0: b902215f     	str	wzr, [x10, #0x220]
    a3f4: b903315f     	str	wzr, [x10, #0x330]
    a3f8: 91001129     	add	x9, x9, #0x4
    a3fc: 9111014a     	add	x10, x10, #0x440
    a400: eb09011f     	cmp	x8, x9
    a404: 54ffff21     	b.ne	0xa3e8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xac>
    a408: eb08029f     	cmp	x20, x8
    a40c: 54000100     	b.eq	0xa42c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xf0>
    a410: 52802209     	mov	w9, #0x110              ; =272
    a414: 9ba95509     	umaddl	x9, w8, w9, x21
    a418: b900013f     	str	wzr, [x9]
    a41c: 91000508     	add	x8, x8, #0x1
    a420: 91044129     	add	x9, x9, #0x110
    a424: eb08029f     	cmp	x20, x8
    a428: 54ffff81     	b.ne	0xa418 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xdc>
    a42c: a940a269     	ldp	x9, x8, [x19, #0x8]
    a430: f9000be9     	str	x9, [sp, #0x10]
    a434: f90013e8     	str	x8, [sp, #0x20]
    a438: a9005274     	stp	x20, x20, [x19]
    a43c: f9000a75     	str	x21, [x19, #0x10]
    a440: b4001176     	cbz	x22, 0xa66c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x330>
    a444: 5280221a     	mov	w26, #0x110             ; =272
    a448: 9100c3fc     	add	x28, sp, #0x30
    a44c: d2823d78     	mov	x24, #0x11eb            ; =4587
    a450: f2a26638     	movk	x24, #0x1331, lsl #16
    a454: f2c93778     	movk	x24, #0x49bb, lsl #32
    a458: f2f29a18     	movk	x24, #0x94d0, lsl #48
    a45c: 14000003     	b	0xa468 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x12c>
    a460: f94017f6     	ldr	x22, [sp, #0x28]
    a464: b4001056     	cbz	x22, 0xa66c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x330>
    a468: d10006d6     	sub	x22, x22, #0x1
    a46c: f90017f6     	str	x22, [sp, #0x28]
    a470: f94013e8     	ldr	x8, [sp, #0x20]
    a474: 9b1a22c8     	madd	x8, x22, x26, x8
    a478: b9400109     	ldr	w9, [x8]
    a47c: 7100053f     	cmp	w9, #0x1
    a480: 54ffff09     	b.ls	0xa460 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x124>
    a484: f9408509     	ldr	x9, [x8, #0x108]
    a488: 3cc08100     	ldur	q0, [x8, #0x8]
    a48c: 3c8383e0     	stur	q0, [sp, #0x38]
    a490: 3cc18100     	ldur	q0, [x8, #0x18]
    a494: 3c8483e0     	stur	q0, [sp, #0x48]
    a498: 3cc28100     	ldur	q0, [x8, #0x28]
    a49c: 3c8583e0     	stur	q0, [sp, #0x58]
    a4a0: 3cc38100     	ldur	q0, [x8, #0x38]
    a4a4: 3c8683e0     	stur	q0, [sp, #0x68]
    a4a8: 3cc48100     	ldur	q0, [x8, #0x48]
    a4ac: 3c8783e0     	stur	q0, [sp, #0x78]
    a4b0: 3cc58100     	ldur	q0, [x8, #0x58]
    a4b4: 3c8883e0     	stur	q0, [sp, #0x88]
    a4b8: 3cc68100     	ldur	q0, [x8, #0x68]
    a4bc: 3c8983e0     	stur	q0, [sp, #0x98]
    a4c0: 3cc78100     	ldur	q0, [x8, #0x78]
    a4c4: 3c8a83e0     	stur	q0, [sp, #0xa8]
    a4c8: 3cc88100     	ldur	q0, [x8, #0x88]
    a4cc: 9100c3ea     	add	x10, sp, #0x30
    a4d0: 3c888140     	stur	q0, [x10, #0x88]
    a4d4: 3cc98100     	ldur	q0, [x8, #0x98]
    a4d8: 3c898140     	stur	q0, [x10, #0x98]
    a4dc: 3cca8100     	ldur	q0, [x8, #0xa8]
    a4e0: 3c8a8140     	stur	q0, [x10, #0xa8]
    a4e4: 3ccb8100     	ldur	q0, [x8, #0xb8]
    a4e8: 3c8b8140     	stur	q0, [x10, #0xb8]
    a4ec: 3ccc8100     	ldur	q0, [x8, #0xc8]
    a4f0: 3c8c8140     	stur	q0, [x10, #0xc8]
    a4f4: 3ccd8100     	ldur	q0, [x8, #0xd8]
    a4f8: 3c8d8140     	stur	q0, [x10, #0xd8]
    a4fc: 3cce8100     	ldur	q0, [x8, #0xe8]
    a500: 3c8e8140     	stur	q0, [x10, #0xe8]
    a504: 3ccf8100     	ldur	q0, [x8, #0xf8]
    a508: 3c8f8140     	stur	q0, [x10, #0xf8]
    a50c: f9009fe9     	str	x9, [sp, #0x138]
    a510: 52800028     	mov	w8, #0x1                ; =1
    a514: f9001be8     	str	x8, [sp, #0x30]
    a518: b9401fe8     	ldr	w8, [sp, #0x1c]
    a51c: 36000448     	tbz	w8, #0x0, 0xa5a4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x268>
    a520: 5280003b     	mov	w27, #0x1               ; =1
    a524: 14000013     	b	0xa570 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x234>
    a528: d1000776     	sub	x22, x27, #0x1
    a52c: f9001bf6     	str	x22, [sp, #0x30]
    a530: 52802108     	mov	w8, #0x108              ; =264
    a534: 9b087377     	madd	x23, x27, x8, x28
    a538: f8500ee3     	ldr	x3, [x23, #-0x100]!
    a53c: 910503e0     	add	x0, sp, #0x140
    a540: 910022e4     	add	x4, x23, #0x8
    a544: aa1303e1     	mov	x1, x19
    a548: 94000000     	bl	0xa548 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x20c>
		000000000000a548:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    a54c: b94143e8     	ldr	w8, [sp, #0x140]
    a550: 34000248     	cbz	w8, 0xa598 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x25c>
    a554: 910503e8     	add	x8, sp, #0x140
    a558: 91002101     	add	x1, x8, #0x8
    a55c: aa1703e0     	mov	x0, x23
    a560: 52802102     	mov	w2, #0x108              ; =264
    a564: 94000000     	bl	0xa564 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x228>
		000000000000a564:  ARM64_RELOC_BRANCH26	_memcpy
    a568: f9001bfb     	str	x27, [sp, #0x30]
    a56c: b4fff7bb     	cbz	x27, 0xa460 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x124>
    a570: d2800002     	mov	x2, #0x0                ; =0
    a574: aa1503e8     	mov	x8, x21
    a578: b9400109     	ldr	w9, [x8]
    a57c: 7100093f     	cmp	w9, #0x2
    a580: 54fffd43     	b.lo	0xa528 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x1ec>
    a584: 91044108     	add	x8, x8, #0x110
    a588: 91000442     	add	x2, x2, #0x1
    a58c: eb02029f     	cmp	x20, x2
    a590: 54ffff41     	b.ne	0xa578 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x23c>
    a594: 17fffff6     	b	0xa56c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x230>
    a598: aa1603fb     	mov	x27, x22
    a59c: b5fffeb6     	cbnz	x22, 0xa570 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x234>
    a5a0: 17ffffb0     	b	0xa460 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x124>
    a5a4: 52800036     	mov	w22, #0x1               ; =1
    a5a8: 14000013     	b	0xa5f4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x2b8>
    a5ac: d10006db     	sub	x27, x22, #0x1
    a5b0: f9001bfb     	str	x27, [sp, #0x30]
    a5b4: 52802108     	mov	w8, #0x108              ; =264
    a5b8: 9b0872d7     	madd	x23, x22, x8, x28
    a5bc: f8500ee3     	ldr	x3, [x23, #-0x100]!
    a5c0: 910503e0     	add	x0, sp, #0x140
    a5c4: 910022e4     	add	x4, x23, #0x8
    a5c8: aa1303e1     	mov	x1, x19
    a5cc: 94000000     	bl	0xa5cc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x290>
		000000000000a5cc:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    a5d0: b94143e8     	ldr	w8, [sp, #0x140]
    a5d4: 34000468     	cbz	w8, 0xa660 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x324>
    a5d8: 910503e8     	add	x8, sp, #0x140
    a5dc: 91002101     	add	x1, x8, #0x8
    a5e0: aa1703e0     	mov	x0, x23
    a5e4: 52802102     	mov	w2, #0x108              ; =264
    a5e8: 94000000     	bl	0xa5e8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x2ac>
		000000000000a5e8:  ARM64_RELOC_BRANCH26	_memcpy
    a5ec: f9001bf6     	str	x22, [sp, #0x30]
    a5f0: b4fff396     	cbz	x22, 0xa460 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x124>
    a5f4: d2800008     	mov	x8, #0x0                ; =0
    a5f8: f9401fe9     	ldr	x9, [sp, #0x38]
    a5fc: ca190129     	eor	x9, x9, x25
    a600: ca497929     	eor	x9, x9, x9, lsr #30
    a604: d29cb72a     	mov	x10, #0xe5b9            ; =58809
    a608: f2a39c8a     	movk	x10, #0x1ce4, lsl #16
    a60c: f2c8edaa     	movk	x10, #0x476d, lsl #32
    a610: f2f7eb0a     	movk	x10, #0xbf58, lsl #48
    a614: 9b0a7d29     	mul	x9, x9, x10
    a618: ca496d29     	eor	x9, x9, x9, lsr #27
    a61c: 9b187d29     	mul	x9, x9, x24
    a620: ca497d29     	eor	x9, x9, x9, lsr #31
    a624: 9ad4092a     	udiv	x10, x9, x20
    a628: 9b14a549     	msub	x9, x10, x20, x9
    a62c: cb09028a     	sub	x10, x20, x9
    a630: cb0a03eb     	neg	x11, x10
    a634: eb0a011f     	cmp	x8, x10
    a638: 9a8b312c     	csel	x12, x9, x11, lo
    a63c: 8b080182     	add	x2, x12, x8
    a640: 9b1a7c4c     	mul	x12, x2, x26
    a644: b86c6aac     	ldr	w12, [x21, x12]
    a648: 7100099f     	cmp	w12, #0x2
    a64c: 54fffb03     	b.lo	0xa5ac <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x270>
    a650: 91000508     	add	x8, x8, #0x1
    a654: eb08029f     	cmp	x20, x8
    a658: 54fffee1     	b.ne	0xa634 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x2f8>
    a65c: 17ffffe5     	b	0xa5f0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x2b4>
    a660: aa1b03f6     	mov	x22, x27
    a664: b5fffc9b     	cbnz	x27, 0xa5f4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x2b8>
    a668: 17ffff7e     	b	0xa460 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x124>
    a66c: f9400be8     	ldr	x8, [sp, #0x10]
    a670: b4000068     	cbz	x8, 0xa67c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x340>
    a674: f94013e0     	ldr	x0, [sp, #0x20]
    a678: 94000000     	bl	0xa678 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x33c>
		000000000000a678:  ARM64_RELOC_BRANCH26	_free
    a67c: 52800000     	mov	w0, #0x0                ; =0
    a680: f900127f     	str	xzr, [x19, #0x20]
    a684: 17ffff3d     	b	0xa378 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x3c>
    a688: 94000000     	bl	0xa688 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x34c>
		000000000000a688:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

