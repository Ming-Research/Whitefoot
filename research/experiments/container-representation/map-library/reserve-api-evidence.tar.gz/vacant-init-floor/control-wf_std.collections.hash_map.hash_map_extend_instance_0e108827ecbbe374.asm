0000000000009e98 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374>:
    9e98: a9bc5ff8     	stp	x24, x23, [sp, #-0x40]!
    9e9c: a90157f6     	stp	x22, x21, [sp, #0x10]
    9ea0: a9024ff4     	stp	x20, x19, [sp, #0x20]
    9ea4: a9037bfd     	stp	x29, x30, [sp, #0x30]
    9ea8: aa0103f4     	mov	x20, x1
    9eac: aa0003f3     	mov	x19, x0
    9eb0: a9405817     	ldp	x23, x22, [x0]
    9eb4: eb0102df     	cmp	x22, x1
    9eb8: 54000302     	b.hs	0x9f18 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x80>
    9ebc: f9400a75     	ldr	x21, [x19, #0x10]
    9ec0: 8b141288     	add	x8, x20, x20, lsl #4
    9ec4: d37ced01     	lsl	x1, x8, #4
    9ec8: f10002df     	cmp	x22, #0x0
    9ecc: fa5612e0     	ccmp	x23, x22, #0x0, ne
    9ed0: 540001c0     	b.eq	0x9f08 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x70>
    9ed4: aa0103e0     	mov	x0, x1
    9ed8: 94000000     	bl	0x9ed8 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x40>
		0000000000009ed8:  ARM64_RELOC_BRANCH26	_malloc
    9edc: b4000560     	cbz	x0, 0x9f88 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xf0>
    9ee0: b40001b6     	cbz	x22, 0x9f14 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x7c>
    9ee4: 8b1712e8     	add	x8, x23, x23, lsl #4
    9ee8: d37ced02     	lsl	x2, x8, #4
    9eec: aa0003f6     	mov	x22, x0
    9ef0: aa1503e1     	mov	x1, x21
    9ef4: 94000000     	bl	0x9ef4 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x5c>
		0000000000009ef4:  ARM64_RELOC_BRANCH26	_memcpy
    9ef8: aa1503e0     	mov	x0, x21
    9efc: 94000000     	bl	0x9efc <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x64>
		0000000000009efc:  ARM64_RELOC_BRANCH26	_free
    9f00: aa1603e0     	mov	x0, x22
    9f04: 14000004     	b	0x9f14 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x7c>
    9f08: aa1503e0     	mov	x0, x21
    9f0c: 94000000     	bl	0x9f0c <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x74>
		0000000000009f0c:  ARM64_RELOC_BRANCH26	_realloc
    9f10: b40003c0     	cbz	x0, 0x9f88 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xf0>
    9f14: a9008274     	stp	x20, x0, [x19, #0x8]
    9f18: eb1402ff     	cmp	x23, x20
    9f1c: 540002a2     	b.hs	0x9f70 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xd8>
    9f20: f9400a68     	ldr	x8, [x19, #0x10]
    9f24: 52802209     	mov	w9, #0x110              ; =272
    9f28: 9b0922e8     	madd	x8, x23, x9, x8
    9f2c: 91002108     	add	x8, x8, #0x8
    9f30: 6f00e400     	movi.2d	v0, #0000000000000000
    9f34: b81f811f     	stur	wzr, [x8, #-0x8]
    9f38: 910006f7     	add	x23, x23, #0x1
    9f3c: ad000100     	stp	q0, q0, [x8]
    9f40: ad010100     	stp	q0, q0, [x8, #0x20]
    9f44: ad020100     	stp	q0, q0, [x8, #0x40]
    9f48: ad030100     	stp	q0, q0, [x8, #0x60]
    9f4c: ad040100     	stp	q0, q0, [x8, #0x80]
    9f50: ad050100     	stp	q0, q0, [x8, #0xa0]
    9f54: ad060100     	stp	q0, q0, [x8, #0xc0]
    9f58: ad070100     	stp	q0, q0, [x8, #0xe0]
    9f5c: f900811f     	str	xzr, [x8, #0x100]
    9f60: 91044108     	add	x8, x8, #0x110
    9f64: eb17029f     	cmp	x20, x23
    9f68: 54fffe61     	b.ne	0x9f34 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x9c>
    9f6c: f9000277     	str	x23, [x19]
    9f70: 52800000     	mov	w0, #0x0                ; =0
    9f74: a9437bfd     	ldp	x29, x30, [sp, #0x30]
    9f78: a9424ff4     	ldp	x20, x19, [sp, #0x20]
    9f7c: a94157f6     	ldp	x22, x21, [sp, #0x10]
    9f80: a8c45ff8     	ldp	x24, x23, [sp], #0x40
    9f84: d65f03c0     	ret
    9f88: 94000000     	bl	0x9f88 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xf0>
		0000000000009f88:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

