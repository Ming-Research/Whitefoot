0000000000009770 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad>:
    9770: d10183ff     	sub	sp, sp, #0x60
    9774: a9025ff8     	stp	x24, x23, [sp, #0x20]
    9778: a90357f6     	stp	x22, x21, [sp, #0x30]
    977c: a9044ff4     	stp	x20, x19, [sp, #0x40]
    9780: a9057bfd     	stp	x29, x30, [sp, #0x50]
    9784: f140103f     	cmp	x1, #0x4, lsl #12       ; =0x4000
    9788: 54000088     	b.hi	0x9798 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x28>
    978c: f9400014     	ldr	x20, [x0]
    9790: eb14003f     	cmp	x1, x20
    9794: 54000142     	b.hs	0x97bc <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x4c>
    9798: 52800020     	mov	w0, #0x1                ; =1
    979c: 52800001     	mov	w1, #0x0                ; =0
    97a0: 52800002     	mov	w2, #0x0                ; =0
    97a4: a9457bfd     	ldp	x29, x30, [sp, #0x50]
    97a8: a9444ff4     	ldp	x20, x19, [sp, #0x40]
    97ac: a94357f6     	ldp	x22, x21, [sp, #0x30]
    97b0: a9425ff8     	ldp	x24, x23, [sp, #0x20]
    97b4: 910183ff     	add	sp, sp, #0x60
    97b8: d65f03c0     	ret
    97bc: b40001e1     	cbz	x1, 0x97f8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x88>
    97c0: aa0003f3     	mov	x19, x0
    97c4: f9400055     	ldr	x21, [x2]
    97c8: 39402056     	ldrb	w22, [x2, #0x8]
    97cc: aa0103f7     	mov	x23, x1
    97d0: 8b010428     	add	x8, x1, x1, lsl #1
    97d4: d37df100     	lsl	x0, x8, #3
    97d8: 94000000     	bl	0x97d8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x68>
		00000000000097d8:  ARM64_RELOC_BRANCH26	_malloc
    97dc: b4000f20     	cbz	x0, 0x99c0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x250>
    97e0: aa1703ea     	mov	x10, x23
    97e4: f10012ff     	cmp	x23, #0x4
    97e8: aa1303e9     	mov	x9, x19
    97ec: 540000a2     	b.hs	0x9800 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x90>
    97f0: d2800008     	mov	x8, #0x0                ; =0
    97f4: 14000010     	b	0x9834 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xc4>
    97f8: 52800000     	mov	w0, #0x0                ; =0
    97fc: 17ffffe8     	b	0x979c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x2c>
    9800: d280000b     	mov	x11, #0x0               ; =0
    9804: 927e3148     	and	x8, x10, #0x7ffc
    9808: 9100c00c     	add	x12, x0, #0x30
    980c: b81d019f     	stur	wzr, [x12, #-0x30]
    9810: b81e819f     	stur	wzr, [x12, #-0x18]
    9814: b900019f     	str	wzr, [x12]
    9818: b900199f     	str	wzr, [x12, #0x18]
    981c: 9100116b     	add	x11, x11, #0x4
    9820: 9101818c     	add	x12, x12, #0x60
    9824: eb0b011f     	cmp	x8, x11
    9828: 54ffff21     	b.ne	0x980c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x9c>
    982c: eb08015f     	cmp	x10, x8
    9830: 540000e0     	b.eq	0x984c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xdc>
    9834: 5280030b     	mov	w11, #0x18              ; =24
    9838: 9bab010b     	umaddl	x11, w8, w11, x0
    983c: b801857f     	str	wzr, [x11], #0x18
    9840: 91000508     	add	x8, x8, #0x1
    9844: eb08015f     	cmp	x10, x8
    9848: 54ffffa1     	b.ne	0x983c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xcc>
    984c: a940a12b     	ldp	x11, x8, [x9, #0x8]
    9850: a900292a     	stp	x10, x10, [x9]
    9854: f9000920     	str	x0, [x9, #0x10]
    9858: b4000a74     	cbz	x20, 0x99a4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x234>
    985c: 5280030c     	mov	w12, #0x18              ; =24
    9860: 360003d6     	tbz	w22, #0x0, 0x98d8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x168>
    9864: 910023ed     	add	x13, sp, #0x8
    9868: 5280004e     	mov	w14, #0x2               ; =2
    986c: 14000002     	b	0x9874 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x104>
    9870: b40009b4     	cbz	x20, 0x99a4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x234>
    9874: d1000694     	sub	x20, x20, #0x1
    9878: 9b0c228f     	madd	x15, x20, x12, x8
    987c: b94001f0     	ldr	w16, [x15]
    9880: 71000a1f     	cmp	w16, #0x2
    9884: 54ffff63     	b.lo	0x9870 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x100>
    9888: 3cc081e0     	ldur	q0, [x15, #0x8]
    988c: 3c8103e0     	stur	q0, [sp, #0x10]
    9890: 5280002f     	mov	w15, #0x1               ; =1
    9894: 14000008     	b	0x98b4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x144>
    9898: d10005ef     	sub	x15, x15, #0x1
    989c: 8b0f11b1     	add	x17, x13, x15, lsl #4
    98a0: f90007ef     	str	x15, [sp, #0x8]
    98a4: b900020e     	str	w14, [x16]
    98a8: 3cc08220     	ldur	q0, [x17, #0x8]
    98ac: 3c808200     	stur	q0, [x16, #0x8]
    98b0: b4fffe0f     	cbz	x15, 0x9870 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x100>
    98b4: aa0003f0     	mov	x16, x0
    98b8: aa0a03f1     	mov	x17, x10
    98bc: b9400201     	ldr	w1, [x16]
    98c0: 7100043f     	cmp	w1, #0x1
    98c4: 54fffea9     	b.ls	0x9898 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x128>
    98c8: 91006210     	add	x16, x16, #0x18
    98cc: f1000631     	subs	x17, x17, #0x1
    98d0: 54ffff61     	b.ne	0x98bc <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x14c>
    98d4: 17fffff7     	b	0x98b0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x140>
    98d8: d29cb72d     	mov	x13, #0xe5b9            ; =58809
    98dc: f2a39c8d     	movk	x13, #0x1ce4, lsl #16
    98e0: f2c8edad     	movk	x13, #0x476d, lsl #32
    98e4: f2f7eb0d     	movk	x13, #0xbf58, lsl #48
    98e8: d2823d6e     	mov	x14, #0x11eb            ; =4587
    98ec: f2a2662e     	movk	x14, #0x1331, lsl #16
    98f0: f2c9376e     	movk	x14, #0x49bb, lsl #32
    98f4: f2f29a0e     	movk	x14, #0x94d0, lsl #48
    98f8: 910023ef     	add	x15, sp, #0x8
    98fc: 52800050     	mov	w16, #0x2               ; =2
    9900: 14000002     	b	0x9908 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x198>
    9904: b4000514     	cbz	x20, 0x99a4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x234>
    9908: d1000694     	sub	x20, x20, #0x1
    990c: 9b0c2291     	madd	x17, x20, x12, x8
    9910: b9400221     	ldr	w1, [x17]
    9914: 7100043f     	cmp	w1, #0x1
    9918: 54ffff69     	b.ls	0x9904 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x194>
    991c: 3cc08220     	ldur	q0, [x17, #0x8]
    9920: f9400631     	ldr	x17, [x17, #0x8]
    9924: 3c8103e0     	stur	q0, [sp, #0x10]
    9928: ca150231     	eor	x17, x17, x21
    992c: ca517a31     	eor	x17, x17, x17, lsr #30
    9930: 9b0d7e31     	mul	x17, x17, x13
    9934: ca516e31     	eor	x17, x17, x17, lsr #27
    9938: 9b0e7e31     	mul	x17, x17, x14
    993c: ca517e31     	eor	x17, x17, x17, lsr #31
    9940: 9aca0a21     	udiv	x1, x17, x10
    9944: 9b0ac431     	msub	x17, x1, x10, x17
    9948: cb110141     	sub	x1, x10, x17
    994c: cb0103e2     	neg	x2, x1
    9950: 52800023     	mov	w3, #0x1                ; =1
    9954: 14000008     	b	0x9974 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x204>
    9958: d1000463     	sub	x3, x3, #0x1
    995c: 8b0311e4     	add	x4, x15, x3, lsl #4
    9960: f90007e3     	str	x3, [sp, #0x8]
    9964: b90000b0     	str	w16, [x5]
    9968: 3cc08080     	ldur	q0, [x4, #0x8]
    996c: 3c8080a0     	stur	q0, [x5, #0x8]
    9970: b4fffca3     	cbz	x3, 0x9904 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x194>
    9974: d2800004     	mov	x4, #0x0                ; =0
    9978: eb01009f     	cmp	x4, x1
    997c: 9a823225     	csel	x5, x17, x2, lo
    9980: 8b0400a5     	add	x5, x5, x4
    9984: 9b0c00a5     	madd	x5, x5, x12, x0
    9988: b94000a6     	ldr	w6, [x5]
    998c: 710008df     	cmp	w6, #0x2
    9990: 54fffe43     	b.lo	0x9958 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1e8>
    9994: 91000484     	add	x4, x4, #0x1
    9998: eb04015f     	cmp	x10, x4
    999c: 54fffee1     	b.ne	0x9978 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x208>
    99a0: 17fffff4     	b	0x9970 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x200>
    99a4: b400008b     	cbz	x11, 0x99b4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x244>
    99a8: aa0803e0     	mov	x0, x8
    99ac: 94000000     	bl	0x99ac <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x23c>
		00000000000099ac:  ARM64_RELOC_BRANCH26	_free
    99b0: aa1303e9     	mov	x9, x19
    99b4: 52800000     	mov	w0, #0x0                ; =0
    99b8: f900113f     	str	xzr, [x9, #0x20]
    99bc: 17ffff78     	b	0x979c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x2c>
    99c0: 94000000     	bl	0x99c0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x250>
		00000000000099c0:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

