000000000000a548 <_wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3>:
    a548: f9400828     	ldr	x8, [x1, #0x10]
    a54c: 52800309     	mov	w9, #0x18               ; =24
    a550: 9b092049     	madd	x9, x2, x9, x8
    a554: b9400128     	ldr	w8, [x9]
    a558: 3cc08120     	ldur	q0, [x9, #0x8]
    a55c: 5280004a     	mov	w10, #0x2               ; =2
    a560: b900012a     	str	w10, [x9]
    a564: a9009123     	stp	x3, x4, [x9, #0x8]
    a568: 34000068     	cbz	w8, 0xa574 <_wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3+0x2c>
    a56c: 7100051f     	cmp	w8, #0x1
    a570: 54000081     	b.ne	0xa580 <_wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3+0x38>
    a574: a9007c1f     	stp	xzr, xzr, [x0]
    a578: f900081f     	str	xzr, [x0, #0x10]
    a57c: d65f03c0     	ret
    a580: f900001f     	str	xzr, [x0]
    a584: 52800028     	mov	w8, #0x1                ; =1
    a588: b9000008     	str	w8, [x0]
    a58c: 3c808000     	stur	q0, [x0, #0x8]
    a590: d65f03c0     	ret
