define i8 @wf_std.collections.hash_map.hash_map_migrate_owner$instance$28da32efc51c2b65(ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr %wf.arg.v2, ptr noalias nonnull captures(none) dereferenceable(16) %v3) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.1 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  %wf.slot.2 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  %v8 = alloca i64, align 8
  %v48 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v2, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  br label %bb1
bb1:
  %v4 = phi ptr [ %v0, %entry ], [ %v23, %bb5 ], [ %v14, %bb11 ]
  %v5 = phi i64 [ %v1, %entry ], [ %v69, %bb5 ], [ %v56, %bb11 ]
  %v7 = phi ptr [ %v3, %entry ], [ %v26, %bb5 ], [ %v17, %bb11 ]
  store i64 %v5, ptr %v8
  %v9 = call i64 @wf_map_cost_hash(ptr %v7, ptr %v8)
  %t0 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v4, i32 0, i32 0
  %v10 = getelementptr i8, ptr %t0, i64 0
  %v11 = getelementptr i8, ptr %v10, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v11, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v12 = add i64 %t1, 0
  %v13 = select i1 true, i64 0, i64 0
  br label %bb2
bb2:
  %v14 = phi ptr [ %v4, %bb1 ], [ %v58, %bb12 ]
  %v15 = phi ptr [ %v8, %bb1 ], [ %v59, %bb12 ]
  %v17 = phi ptr [ %v7, %bb1 ], [ %v61, %bb12 ]
  %v18 = phi i64 [ %v9, %bb1 ], [ %v62, %bb12 ]
  %v19 = phi i64 [ %v12, %bb1 ], [ %v63, %bb12 ]
  %v20 = phi i64 [ %v13, %bb1 ], [ %v64, %bb12 ]
  %v21 = phi i64 [ %v12, %bb1 ], [ %v65, %bb12 ]
  %v22 = phi i64 [ %v13, %bb1 ], [ %v68, %bb12 ]
  %v29 = icmp ult i64 %v22, %v21
  switch i1 %v29, label %invalid.tag.b2 [
    i1 1, label %bb3
    i1 0, label %bb4
  ]
invalid.tag.b2:
  unreachable
bb3:
  %v30 = urem i64 %v18, %v19
  %v31 = call i64 @wf_std.collections.hash_map.hash_map_probe(i64 %v30, i64 %v22, i64 %v19)
  %t3 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v14, i32 0, i32 0
  %v32 = getelementptr i8, ptr %t3, i64 0
  %v33 = getelementptr i8, ptr %v32, i64 0
  %t5 = getelementptr inbounds { i64, i64, ptr }, ptr %v33, i32 0, i32 2
  %t6 = load ptr, ptr %t5
  %t4.nonnegative = icmp sge i64 %v31, 0
  call void @llvm.assume(i1 %t4.nonnegative)
  %t4 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %t6, i64 %v31
  %v34 = getelementptr i8, ptr %t4, i64 0
  %v35 = call i1 @wf_std.collections.hash_map.hash_map_is_available$instance$d7a1a90c27bba449(ptr %v34)
  switch i1 %v35, label %invalid.tag.b3 [
    i1 1, label %bb7
    i1 0, label %bb8
  ]
invalid.tag.b3:
  unreachable
bb4:
  br label %bb5
bb5:
  %v23 = phi ptr [ %v14, %bb4 ]
  %v24 = phi ptr [ %v15, %bb4 ]
  %v26 = phi ptr [ %v17, %bb4 ]
  %v27 = phi i64 [ %v18, %bb4 ]
  %v28 = phi i64 [ %v19, %bb4 ]
  %v69 = load i64, ptr %v24
  br label %bb1
bb6:
  %v36 = phi ptr [ %v14, %bb8 ]
  %v37 = phi ptr [ %v15, %bb8 ]
  %v39 = phi ptr [ %v17, %bb8 ]
  %v40 = phi i64 [ %v18, %bb8 ]
  %v41 = phi i64 [ %v19, %bb8 ]
  %v42 = phi i64 [ %v22, %bb8 ]
  %v43 = phi i64 [ %v30, %bb8 ]
  %v44 = phi i64 [ %v31, %bb8 ]
  %v45 = phi i1 [ %v35, %bb8 ]
  br label %bb12
bb7:
  %v46 = load i64, ptr %v15
  store %wf.t.dceb7b9db1c9ad1d zeroinitializer, ptr %wf.slot.1
  %t7 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.1, i32 0, i32 0
  store i32 2, ptr %t7
  %t8 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.1, i32 0, i32 1
  store i64 %v46, ptr %t8
  %t9 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.1, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t9, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %v48, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i32 1) to i64), i1 false)
  %t10 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v14, i32 0, i32 0
  %v49 = getelementptr i8, ptr %t10, i64 0
  %v50 = getelementptr i8, ptr %v49, i64 0
  %t12 = getelementptr inbounds { i64, i64, ptr }, ptr %v50, i32 0, i32 2
  %t13 = load ptr, ptr %t12
  %t11.nonnegative = icmp sge i64 %v31, 0
  call void @llvm.assume(i1 %t11.nonnegative)
  %t11 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %t13, i64 %v31
  %v51 = getelementptr i8, ptr %t11, i64 0
  %v52 = call i8 @wf_swap$instance$9eabc50a9cce2251(ptr %v51, ptr %v48)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %v48, i64 ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i32 1) to i64), i1 false)
  %t14 = load %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.2
  %t15 = extractvalue %wf.t.dceb7b9db1c9ad1d %t14, 0
  switch i32 %t15, label %invalid.tag.b7 [
    i32 0, label %bb9
    i32 1, label %bb10
    i32 2, label %bb11
  ]
invalid.tag.b7:
  unreachable
bb8:
  br label %bb6
bb9:
  %v54 = select i1 true, i8 0, i8 0
  ret i8 %v54
bb10:
  %v55 = select i1 true, i8 0, i8 0
  ret i8 %v55
bb11:
  %t16 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.2, i32 0, i32 1
  %v56 = load i64, ptr %t16
  %t17 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.2, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %t17, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  br label %bb1
bb12:
  %v58 = phi ptr [ %v36, %bb6 ]
  %v59 = phi ptr [ %v37, %bb6 ]
  %v61 = phi ptr [ %v39, %bb6 ]
  %v62 = phi i64 [ %v40, %bb6 ]
  %v63 = phi i64 [ %v41, %bb6 ]
  %v64 = phi i64 [ %v20, %bb6 ]
  %v65 = phi i64 [ %v21, %bb6 ]
  %v66 = phi i64 [ %v22, %bb6 ]
  %v67 = select i1 true, i64 1, i64 1
  %v68 = add i64 %v66, %v67
  br label %bb2
}
