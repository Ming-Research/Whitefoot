0000000000009410 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad>:
    9410: d10183ff     	sub	sp, sp, #0x60
    9414: a9025ff8     	stp	x24, x23, [sp, #0x20]
    9418: a90357f6     	stp	x22, x21, [sp, #0x30]
    941c: a9044ff4     	stp	x20, x19, [sp, #0x40]
    9420: a9057bfd     	stp	x29, x30, [sp, #0x50]
    9424: f140103f     	cmp	x1, #0x4, lsl #12       ; =0x4000
    9428: 54000088     	b.hi	0x9438 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x28>
    942c: f9400014     	ldr	x20, [x0]
    9430: eb14003f     	cmp	x1, x20
    9434: 54000142     	b.hs	0x945c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x4c>
    9438: 52800020     	mov	w0, #0x1                ; =1
    943c: 52800001     	mov	w1, #0x0                ; =0
    9440: 52800002     	mov	w2, #0x0                ; =0
    9444: a9457bfd     	ldp	x29, x30, [sp, #0x50]
    9448: a9444ff4     	ldp	x20, x19, [sp, #0x40]
    944c: a94357f6     	ldp	x22, x21, [sp, #0x30]
    9450: a9425ff8     	ldp	x24, x23, [sp, #0x20]
    9454: 910183ff     	add	sp, sp, #0x60
    9458: d65f03c0     	ret
    945c: b40006a1     	cbz	x1, 0x9530 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x120>
    9460: aa0003f3     	mov	x19, x0
    9464: f9400055     	ldr	x21, [x2]
    9468: 39402056     	ldrb	w22, [x2, #0x8]
    946c: aa0103f7     	mov	x23, x1
    9470: 8b010428     	add	x8, x1, x1, lsl #1
    9474: d37df100     	lsl	x0, x8, #3
    9478: 94000000     	bl	0x9478 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x68>
    947c: b4000d20     	cbz	x0, 0x9620 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x210>
    9480: d2800008     	mov	x8, #0x0                ; =0
    9484: 9100200b     	add	x11, x0, #0x8
    9488: aa1303e9     	mov	x9, x19
    948c: aa1703ea     	mov	x10, x23
    9490: b81f817f     	stur	wzr, [x11, #-0x8]
    9494: 91000508     	add	x8, x8, #0x1
    9498: a881fd7f     	stp	xzr, xzr, [x11], #0x18
    949c: eb08015f     	cmp	x10, x8
    94a0: 54ffff81     	b.ne	0x9490 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x80>
    94a4: a940a12b     	ldp	x11, x8, [x9, #0x8]
    94a8: a900292a     	stp	x10, x10, [x9]
    94ac: f9000920     	str	x0, [x9, #0x10]
    94b0: b4000ab4     	cbz	x20, 0x9604 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1f4>
    94b4: 5280030c     	mov	w12, #0x18              ; =24
    94b8: 36000416     	tbz	w22, #0x0, 0x9538 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x128>
    94bc: 910023ed     	add	x13, sp, #0x8
    94c0: 5280004e     	mov	w14, #0x2               ; =2
    94c4: 14000002     	b	0x94cc <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xbc>
    94c8: b40009f4     	cbz	x20, 0x9604 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1f4>
    94cc: d1000694     	sub	x20, x20, #0x1
    94d0: 9b0c228f     	madd	x15, x20, x12, x8
    94d4: b94001f0     	ldr	w16, [x15]
    94d8: 71000a1f     	cmp	w16, #0x2
    94dc: 54ffff63     	b.lo	0x94c8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xb8>
    94e0: 3cc081e0     	ldur	q0, [x15, #0x8]
    94e4: 3c8103e0     	stur	q0, [sp, #0x10]
    94e8: 5280002f     	mov	w15, #0x1               ; =1
    94ec: 14000008     	b	0x950c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xfc>
    94f0: d10005ef     	sub	x15, x15, #0x1
    94f4: 8b0f11b1     	add	x17, x13, x15, lsl #4
    94f8: f90007ef     	str	x15, [sp, #0x8]
    94fc: b900020e     	str	w14, [x16]
    9500: 3cc08220     	ldur	q0, [x17, #0x8]
    9504: 3c808200     	stur	q0, [x16, #0x8]
    9508: b4fffe0f     	cbz	x15, 0x94c8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xb8>
    950c: aa0003f0     	mov	x16, x0
    9510: aa0a03f1     	mov	x17, x10
    9514: b9400201     	ldr	w1, [x16]
    9518: 7100043f     	cmp	w1, #0x1
    951c: 54fffea9     	b.ls	0x94f0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xe0>
    9520: 91006210     	add	x16, x16, #0x18
    9524: f1000631     	subs	x17, x17, #0x1
    9528: 54ffff61     	b.ne	0x9514 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x104>
    952c: 17fffff7     	b	0x9508 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xf8>
    9530: 52800000     	mov	w0, #0x0                ; =0
    9534: 17ffffc2     	b	0x943c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x2c>
    9538: d29cb72d     	mov	x13, #0xe5b9            ; =58809
    953c: f2a39c8d     	movk	x13, #0x1ce4, lsl #16
    9540: f2c8edad     	movk	x13, #0x476d, lsl #32
    9544: f2f7eb0d     	movk	x13, #0xbf58, lsl #48
    9548: d2823d6e     	mov	x14, #0x11eb            ; =4587
    954c: f2a2662e     	movk	x14, #0x1331, lsl #16
    9550: f2c9376e     	movk	x14, #0x49bb, lsl #32
    9554: f2f29a0e     	movk	x14, #0x94d0, lsl #48
    9558: 910023ef     	add	x15, sp, #0x8
    955c: 52800050     	mov	w16, #0x2               ; =2
    9560: 14000002     	b	0x9568 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x158>
    9564: b4000514     	cbz	x20, 0x9604 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1f4>
    9568: d1000694     	sub	x20, x20, #0x1
    956c: 9b0c2291     	madd	x17, x20, x12, x8
    9570: b9400221     	ldr	w1, [x17]
    9574: 7100043f     	cmp	w1, #0x1
    9578: 54ffff69     	b.ls	0x9564 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x154>
    957c: 3cc08220     	ldur	q0, [x17, #0x8]
    9580: f9400631     	ldr	x17, [x17, #0x8]
    9584: 3c8103e0     	stur	q0, [sp, #0x10]
    9588: ca150231     	eor	x17, x17, x21
    958c: ca517a31     	eor	x17, x17, x17, lsr #30
    9590: 9b0d7e31     	mul	x17, x17, x13
    9594: ca516e31     	eor	x17, x17, x17, lsr #27
    9598: 9b0e7e31     	mul	x17, x17, x14
    959c: ca517e31     	eor	x17, x17, x17, lsr #31
    95a0: 9aca0a21     	udiv	x1, x17, x10
    95a4: 9b0ac431     	msub	x17, x1, x10, x17
    95a8: cb110141     	sub	x1, x10, x17
    95ac: cb0103e2     	neg	x2, x1
    95b0: 52800023     	mov	w3, #0x1                ; =1
    95b4: 14000008     	b	0x95d4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1c4>
    95b8: d1000463     	sub	x3, x3, #0x1
    95bc: 8b0311e4     	add	x4, x15, x3, lsl #4
    95c0: f90007e3     	str	x3, [sp, #0x8]
    95c4: b90000b0     	str	w16, [x5]
    95c8: 3cc08080     	ldur	q0, [x4, #0x8]
    95cc: 3c8080a0     	stur	q0, [x5, #0x8]
    95d0: b4fffca3     	cbz	x3, 0x9564 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x154>
    95d4: d2800004     	mov	x4, #0x0                ; =0
    95d8: eb01009f     	cmp	x4, x1
    95dc: 9a823225     	csel	x5, x17, x2, lo
    95e0: 8b0400a5     	add	x5, x5, x4
    95e4: 9b0c00a5     	madd	x5, x5, x12, x0
    95e8: b94000a6     	ldr	w6, [x5]
    95ec: 710008df     	cmp	w6, #0x2
    95f0: 54fffe43     	b.lo	0x95b8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1a8>
    95f4: 91000484     	add	x4, x4, #0x1
    95f8: eb04015f     	cmp	x10, x4
    95fc: 54fffee1     	b.ne	0x95d8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1c8>
    9600: 17fffff4     	b	0x95d0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1c0>
    9604: b400008b     	cbz	x11, 0x9614 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x204>
    9608: aa0803e0     	mov	x0, x8
    960c: 94000000     	bl	0x960c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1fc>
    9610: aa1303e9     	mov	x9, x19
    9614: 52800000     	mov	w0, #0x0                ; =0
    9618: f900113f     	str	xzr, [x9, #0x20]
    961c: 17ffff88     	b	0x943c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x2c>
    9620: 94000000     	bl	0x9620 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x210>
