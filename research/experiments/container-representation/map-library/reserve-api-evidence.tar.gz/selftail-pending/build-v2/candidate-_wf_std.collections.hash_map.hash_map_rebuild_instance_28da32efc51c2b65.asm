000000000000a498 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65>:
    a498: d10543ff     	sub	sp, sp, #0x150
    a49c: a9106ffc     	stp	x28, x27, [sp, #0x100]
    a4a0: a9115ff8     	stp	x24, x23, [sp, #0x110]
    a4a4: a91257f6     	stp	x22, x21, [sp, #0x120]
    a4a8: a9134ff4     	stp	x20, x19, [sp, #0x130]
    a4ac: a9147bfd     	stp	x29, x30, [sp, #0x140]
    a4b0: f140103f     	cmp	x1, #0x4, lsl #12       ; =0x4000
    a4b4: 540000a8     	b.hi	0xa4c8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x30>
    a4b8: aa0003f3     	mov	x19, x0
    a4bc: f9400016     	ldr	x22, [x0]
    a4c0: eb16003f     	cmp	x1, x22
    a4c4: 54000162     	b.hs	0xa4f0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x58>
    a4c8: 52800020     	mov	w0, #0x1                ; =1
    a4cc: 52800001     	mov	w1, #0x0                ; =0
    a4d0: 52800002     	mov	w2, #0x0                ; =0
    a4d4: a9547bfd     	ldp	x29, x30, [sp, #0x140]
    a4d8: a9534ff4     	ldp	x20, x19, [sp, #0x130]
    a4dc: a95257f6     	ldp	x22, x21, [sp, #0x120]
    a4e0: a9515ff8     	ldp	x24, x23, [sp, #0x110]
    a4e4: a9506ffc     	ldp	x28, x27, [sp, #0x100]
    a4e8: 910543ff     	add	sp, sp, #0x150
    a4ec: d65f03c0     	ret
    a4f0: b4000861     	cbz	x1, 0xa5fc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x164>
    a4f4: aa0203f4     	mov	x20, x2
    a4f8: aa0103f5     	mov	x21, x1
    a4fc: 8b011028     	add	x8, x1, x1, lsl #4
    a500: d37ced00     	lsl	x0, x8, #4
    a504: 94000000     	bl	0xa504 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x6c>
    a508: b40007e0     	cbz	x0, 0xa604 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x16c>
    a50c: d2800008     	mov	x8, #0x0                ; =0
    a510: 91002009     	add	x9, x0, #0x8
    a514: 6f00e400     	movi.2d	v0, #0000000000000000
    a518: aa1503ea     	mov	x10, x21
    a51c: b81f813f     	stur	wzr, [x9, #-0x8]
    a520: 91000508     	add	x8, x8, #0x1
    a524: ad000120     	stp	q0, q0, [x9]
    a528: ad010120     	stp	q0, q0, [x9, #0x20]
    a52c: ad020120     	stp	q0, q0, [x9, #0x40]
    a530: ad030120     	stp	q0, q0, [x9, #0x60]
    a534: ad040120     	stp	q0, q0, [x9, #0x80]
    a538: ad050120     	stp	q0, q0, [x9, #0xa0]
    a53c: ad060120     	stp	q0, q0, [x9, #0xc0]
    a540: ad070120     	stp	q0, q0, [x9, #0xe0]
    a544: f900813f     	str	xzr, [x9, #0x100]
    a548: 91044129     	add	x9, x9, #0x110
    a54c: eb08015f     	cmp	x10, x8
    a550: 54fffe61     	b.ne	0xa51c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x84>
    a554: a940d677     	ldp	x23, x21, [x19, #0x8]
    a558: a9002a6a     	stp	x10, x10, [x19]
    a55c: f9000a60     	str	x0, [x19, #0x10]
    a560: b4000436     	cbz	x22, 0xa5e4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x14c>
    a564: 52802208     	mov	w8, #0x110              ; =272
    a568: 9b0856c8     	madd	x8, x22, x8, x21
    a56c: d1044118     	sub	x24, x8, #0x110
    a570: 14000004     	b	0xa580 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xe8>
    a574: d1044318     	sub	x24, x24, #0x110
    a578: d10006d6     	sub	x22, x22, #0x1
    a57c: b4000356     	cbz	x22, 0xa5e4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x14c>
    a580: b9400308     	ldr	w8, [x24]
    a584: 7100051f     	cmp	w8, #0x1
    a588: 54ffff69     	b.ls	0xa574 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xdc>
    a58c: f9400701     	ldr	x1, [x24, #0x8]
    a590: ad468700     	ldp	q0, q1, [x24, #0xd0]
    a594: ad0607e0     	stp	q0, q1, [sp, #0xc0]
    a598: ad478700     	ldp	q0, q1, [x24, #0xf0]
    a59c: ad0707e0     	stp	q0, q1, [sp, #0xe0]
    a5a0: ad448700     	ldp	q0, q1, [x24, #0x90]
    a5a4: ad0407e0     	stp	q0, q1, [sp, #0x80]
    a5a8: ad458700     	ldp	q0, q1, [x24, #0xb0]
    a5ac: ad0507e0     	stp	q0, q1, [sp, #0xa0]
    a5b0: ad428700     	ldp	q0, q1, [x24, #0x50]
    a5b4: ad0207e0     	stp	q0, q1, [sp, #0x40]
    a5b8: ad438700     	ldp	q0, q1, [x24, #0x70]
    a5bc: ad0307e0     	stp	q0, q1, [sp, #0x60]
    a5c0: ad408700     	ldp	q0, q1, [x24, #0x10]
    a5c4: ad0007e0     	stp	q0, q1, [sp]
    a5c8: ad418700     	ldp	q0, q1, [x24, #0x30]
    a5cc: ad0107e0     	stp	q0, q1, [sp, #0x20]
    a5d0: 910003e2     	mov	x2, sp
    a5d4: aa1303e0     	mov	x0, x19
    a5d8: aa1403e3     	mov	x3, x20
    a5dc: 94000000     	bl	0xa5dc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x144>
    a5e0: 17ffffe5     	b	0xa574 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xdc>
    a5e4: b4000077     	cbz	x23, 0xa5f0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x158>
    a5e8: aa1503e0     	mov	x0, x21
    a5ec: 94000000     	bl	0xa5ec <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x154>
    a5f0: 52800000     	mov	w0, #0x0                ; =0
    a5f4: f900127f     	str	xzr, [x19, #0x20]
    a5f8: 17ffffb5     	b	0xa4cc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x34>
    a5fc: 52800000     	mov	w0, #0x0                ; =0
    a600: 17ffffb3     	b	0xa4cc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x34>
    a604: 94000000     	bl	0xa604 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x16c>
