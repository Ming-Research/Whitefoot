000000000000a974 <_wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3>:
    a974: f9400828     	ldr	x8, [x1, #0x10]
    a978: 52800309     	mov	w9, #0x18               ; =24
    a97c: 9b092049     	madd	x9, x2, x9, x8
    a980: b9400128     	ldr	w8, [x9]
    a984: 3cc08120     	ldur	q0, [x9, #0x8]
    a988: 5280004a     	mov	w10, #0x2               ; =2
    a98c: b900012a     	str	w10, [x9]
    a990: a9009123     	stp	x3, x4, [x9, #0x8]
    a994: 34000068     	cbz	w8, 0xa9a0 <_wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3+0x2c>
    a998: 7100051f     	cmp	w8, #0x1
    a99c: 54000081     	b.ne	0xa9ac <_wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3+0x38>
    a9a0: a9007c1f     	stp	xzr, xzr, [x0]
    a9a4: f900081f     	str	xzr, [x0, #0x10]
    a9a8: d65f03c0     	ret
    a9ac: f900001f     	str	xzr, [x0]
    a9b0: 52800028     	mov	w8, #0x1                ; =1
    a9b4: b9000008     	str	w8, [x0]
    a9b8: 3c808000     	stur	q0, [x0, #0x8]
    a9bc: d65f03c0     	ret
