from pathlib import Path
import subprocess,time,json,hashlib,shlex,os
D=Path(__file__).resolve().parent; B=D.parent/'build/ecosystem'; H=D.parents[2]
assert os.environ.get('WHITEFOOT_CHECK_OWNER')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records=[];links={}
def run(name,args,expected=0):
 t=time.monotonic()
 with (D/(name+'.stdout')).open('wb') as out,(D/(name+'.stderr')).open('wb') as err:p=subprocess.run(args,cwd=H,stdout=out,stderr=err)
 row={'stage':name,'argv':args,'exit':p.returncode,'expected':expected,'wall_s':time.monotonic()-t};records.append(row);(D/'check-statuses.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert p.returncode==expected,(name,p.returncode,expected)
 return (D/(name+'.stdout')).read_bytes(),(D/(name+'.stderr')).read_bytes()
basecommands={}
for line in (D.parent/'build-10.log').read_text().splitlines():
 if line.startswith('clang++ -O3 '):
  args=shlex.split(line); mode='account' if 'map-account' in args[-1] else 'timed'
  basecommands[mode]=[str(H/a) if a.startswith('.build/') else a for a in args]
assert set(basecommands)=={'timed','account'}
inputs={a:sha(Path(a)) for args in basecommands.values() for a in args[1:-2] if a.endswith(('.o','.a'))}
inputs[str(B/'reserve-accounting.csv')]=sha(B/'reserve-accounting.csv')
(D/'check-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
for side in ('control','candidate'):
 raw=(D/(side+'.raw.ll')).read_bytes()
 account=raw.replace(b'@malloc(',b'@wf_cost_allocate(').replace(b'@free(',b'@wf_cost_release(').replace(b'@main(',b'@wf_fixture_main(')
 (D/(side+'-account.ll')).write_bytes(account)
 run(side+'-account-build',['clang','-O3','-Wno-override-module','-c',str(D/(side+'-account.ll')),'-o',str(D/(side+'-account.o'))])
 for mode in ('timed','account'):
  args=basecommands[mode].copy();i=args.index(str(B/('wf-'+mode+'.o')));args[i]=str(D/(side+('.o' if mode=='timed' else '-account.o')));args[-1]=str(D/(side+'-'+mode));links[side+'-'+mode]=args;run(side+'-'+mode+'-link',args)
(D/'link-commands.json').write_text(json.dumps({'baseline':basecommands,'matched':links},indent=2)+'\n')
for side in ('control','candidate'):
 timed=str(D/(side+'-timed'));account=str(D/(side+'-account'))
 run(side+'-clock',[timed,'reserve-clock-check'])
 for mode,exe in [('timed',timed),('account',account)]:run(side+'-'+mode+'-reserve',[exe,'reserve-check'])
 for peer in range(3):
  for fault in ('omitted','payload','population','capacity','leak','allocation'):
   exe=account if fault in ('leak','allocation') else timed
   out,err=run(side+'-negative-'+str(peer)+'-'+fault,[exe,'negative-reserve-api',fault,str(peer)],1)
   expected={'omitted':'reserve application entry floor','capacity':'reserve application entry floor','payload':'reserve independent complete-owner oracle','population':'reserve prepared population','leak':'every allocation is reclaimed','allocation':'reserve noop has no allocation'}[fault]
   assert out==b'' and err==('map ecosystem: '+expected+'\n').encode()
 out,err=run(side+'-negative-raw-slots',[timed,'negative-reserve-api','raw-slots','0'],1)
 assert out==b'' and err==b'reserve headroom first growth at insertion 97 of 128\nmap ecosystem: reserve future puts retain backing capacity\n'
 for fault,expected in [('quantized','reserve clock quantum at most 100 ns'),('backwards','reserve clock nondecreasing')]:
  out,err=run(side+'-negative-clock-'+fault,[timed,'negative-reserve-clock',fault],1)
  assert out==b'' and err.splitlines()[-1]==('map ecosystem: '+expected).encode()
 out,err=run(side+'-ledger',[account,'reserve-account'])
 assert out==(B/'reserve-accounting.csv').read_bytes(),'ledger mismatch'
 assert len(out.splitlines())==97,'expected96rows'
 for mode,exe in [('timed',timed),('account',account)]:
  run(side+'-'+mode+'-lookup',[exe,'lookup-check']);run(side+'-'+mode+'-whole',[exe,'check'])
# Reuse maintained program outputs and its formal allocation observer unchanged.
R=H.parents[3]
native=[a for a in basecommands['timed'] if '/build/native/' in a and a.endswith('.o')]
assert len(native)==12
observer=R/'tests/programs/containers/container-allocation-observer.c'
inputs[str(observer)]=sha(observer)
for mode in ('normal','parallel'):
 raw=(D/'build-v2'/('maintained-'+mode+'.ll')).read_bytes()
 for observed in (False,True):
  label='maintained-'+mode+('-observed' if observed else '-ordinary')
  ir=D/(label+'.ll');obj=D/(label+'.o');exe=D/label
  if observed:raw2=raw.replace(b'@malloc(',b'@wf_observe_allocate(').replace(b'@realloc(',b'@wf_observe_reallocate(').replace(b'@free(',b'@wf_observe_release(').replace(b'@main(',b'@wf_fixture_main(')
  else:raw2=raw
  ir.write_bytes(raw2)
  run(label+'-compile',['clang','-O3','-Wno-override-module','-c',str(ir),'-o',str(obj)])
  args=['clang','-O3','-std=c11','-Wall','-Wextra','-Werror','-Wno-override-module','-I'+str(R/'runtime'),str(obj)]
  if observed:args+=[str(observer)]
  args+=native+['-pthread','-lm','-o',str(exe)]
  run(label+'-link',args)
  out,err=run(label+'-run',[str(exe)])
  assert err==b''
  assert out==(b'container allocation observer: 36 allocations, each released exactly once\n' if observed else b'')
for side in ('control','candidate'):
 for mode in ('timed','account'):
  for stage,message in [('reserve','map reserve: 288 ordinary reserve/owner/headroom cases passed'),('lookup','map lookup: 96 isolated owner/query/cleanup cases passed'),('whole','map ecosystem: 18390 oracle-checked traces passed')]:
   assert (D/(side+'-'+mode+'-'+stage+'.stdout')).read_text()==message+'\n'
for name,h in inputs.items():assert sha(Path(name))==h,'changed input '+name
(D/'check-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
(D/'checked-images.json').write_text(json.dumps({side+'-'+mode:sha(D/(side+'-'+mode)) for side in ('control','candidate') for mode in ('timed','account')},indent=2)+'\n')
print('ALL CHECKS PASSED; both96row ledgers equal frozen baseline; no timing',flush=True)
