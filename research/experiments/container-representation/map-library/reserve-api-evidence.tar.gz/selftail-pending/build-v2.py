#!/usr/bin/env python3
# One-shot source-candidate build/restore and native admission; never times programs.
from pathlib import Path
import hashlib, json, os, shutil, subprocess, time
R=Path(__file__).resolve().parents[7]
D=Path(__file__).resolve().parent
O=D/'build-v2'
L=R/'lib/std/collections/hash_map/hash-map.wf'
A=R/'research/experiments/container-representation/map-library/map-library.wf'
B=D.parent/'build/ecosystem'
P=Path('<production-cli-home>/whitefootc')
sha=lambda b: hashlib.sha256(b).hexdigest()
assert os.environ.get('WHITEFOOT_CHECK_OWNER'), 'host guard required'
assert not O.exists(), 'preserve previous attempt'
O.mkdir()
records=[]
def run(name,args):
    start=time.monotonic()
    with (O/(name+'.stdout')).open('wb') as out, (O/(name+'.stderr')).open('wb') as err:
        p=subprocess.run(args,cwd=R,stdout=out,stderr=err)
    rec=dict(stage=name,argv=list(map(str,args)),exit=p.returncode,wall_s=time.monotonic()-start)
    records.append(rec); (O/'statuses.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(rec),flush=True)
    if p.returncode: raise RuntimeError(name+' failed')
def clean():
    return subprocess.check_output(['git','diff','--name-only','HEAD','--','compiler'],cwd=R)==b''
original=L.read_bytes(); candidate=(D/'candidate-v2.wf').read_bytes()
assert sha(original)=='bd482f345505ab2c1a30b323f5d0667839febbb6c57c06f82e3675b628e20a89'
assert sha(candidate)=='1135cca708aad30b098613195af84afa5672e59347ce1ed49021b032fe789eed'
assert clean()
assert sha(P.read_bytes())=='c12b2b2a6c9694fd2bc1b7be0004d582ae9628951422def849f4cf6a3ac02f77'
adapter=A.read_bytes()
(O/'production-library.wf').write_bytes(original)
(O/'candidate-library.wf').write_bytes(candidate)
(O/'map-library.wf').write_bytes(adapter)
shutil.copy2(D/'source-v2.patch',O/'source.patch')
pins={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'production_library_sha256':sha(original),'candidate_library_sha256':sha(candidate),'adapter_sha256':sha(adapter),'patch_sha256':sha((O/'source.patch').read_bytes()),'compiler_sources_equal_HEAD':True,'production_cli_sha256':sha(P.read_bytes()),'baseline_raw_sha256':sha((B/'map.raw.ll').read_bytes()),'baseline_object_sha256':sha((B/'wf-timed.o').read_bytes())}
(O/'inputs.json').write_text(json.dumps(pins,indent=2)+'\n')
try:
    L.write_bytes(candidate)
    run('cli-build',['cargo','build','--manifest-path','compiler/Cargo.toml','--profile','gate','--locked','--offline','--bin','whitefootc'])
    shutil.copy2(R/'compiler/target/gate/whitefootc',O/'whitefootc')
    pins['candidate_cli_sha256']=sha((O/'whitefootc').read_bytes())
finally:
    if L.read_bytes()!=candidate: raise RuntimeError('concurrent library edit; refusing overwrite')
    L.write_bytes(original)
    pins['restored_library_sha256']=sha(L.read_bytes())
    pins['compiler_sources_still_equal_HEAD']=clean()
    (O/'inputs.json').write_text(json.dumps(pins,indent=2)+'\n')
assert clean() and L.read_bytes()==original
fixture=R/'tests/programs/containers/hash-map-program.wf'
for mode in ('normal','parallel'):
    args=[str(O/'whitefootc'),'--emit-llvm',str(fixture),'-o',str(O/('maintained-'+mode+'.ll'))]
    if mode=='parallel': args.insert(1,'--par')
    run('maintained-'+mode+'-admission',args)
# Same input path and ordinary pipeline as the baseline adapter build.
run('control-emit',[str(P),'--emit-llvm',str(A),'-o',str(O/'control.raw.ll')])
assert (O/'control.raw.ll').read_bytes()==(B/'map.raw.ll').read_bytes(), 'baseline exact raw mismatch'
run('candidate-emit',[str(O/'whitefootc'),'--emit-llvm',str(A),'-o',str(O/'map.raw.ll')])
raw=(O/'map.raw.ll').read_bytes()
(O/'wf-timed.ll').write_bytes(raw.replace(b'@main(',b'@wf_fixture_main('))
run('candidate-native',['clang','-O3','-Wno-override-module','-c',str(O/'wf-timed.ll'),'-o',str(O/'wf-timed.o')])
objdump='<LLVM_OBJDUMP>'
run('control-native-disassembly',[objdump,'--disassemble',str(B/'wf-timed.o')])
run('candidate-native-disassembly',[objdump,'--disassemble',str(O/'wf-timed.o')])
assert A.read_bytes()==adapter and L.read_bytes()==original and clean()
pins['output_sha256']={p.name:sha(p.read_bytes()) for p in (O/'whitefootc',O/'map.raw.ll',O/'wf-timed.o',O/'maintained-normal.ll',O/'maintained-parallel.ll')}
(O/'inputs.json').write_text(json.dumps(pins,indent=2)+'\n')
print('COMPLETE: source restored, no timing performed',flush=True)
