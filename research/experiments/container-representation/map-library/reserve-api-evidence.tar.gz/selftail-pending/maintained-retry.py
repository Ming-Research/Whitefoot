from pathlib import Path
import subprocess,time,json,hashlib,shlex,os
D=Path(__file__).resolve().parent; B=D.parent/'build/ecosystem'; H=D.parents[2]
assert os.environ.get('WHITEFOOT_CHECK_OWNER')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records=[];links={}
def run(name,args,expected=0):
 t=time.monotonic()
 with (D/(name+'.stdout')).open('wb') as out,(D/(name+'.stderr')).open('wb') as err:p=subprocess.run(args,cwd=H,stdout=out,stderr=err)
 row={'stage':name,'argv':args,'exit':p.returncode,'expected':expected,'wall_s':time.monotonic()-t};records.append(row);(D/'maintained-retry-statuses.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert p.returncode==expected,(name,p.returncode,expected)
 return (D/(name+'.stdout')).read_bytes(),(D/(name+'.stderr')).read_bytes()

old=json.loads((D/'check-statuses.json').read_text())
args=old[-1]['argv'];assert old[-1]['stage']=='maintained-normal-observed-link'
R=D.parents[6]
args=[('-I'+str(R/'compiler/src/backend')) if a.startswith('-I') else a for a in args]
run('maintained-normal-observed-link-retry',args)
out,err=run('maintained-normal-observed-run',[str(D/'maintained-normal-observed')])
assert out==b'container allocation observer: 36 allocations, each released exactly once\n' and err==b''
native=[a for a in args if '/build/native/' in a and a.endswith('.o')]
observer=R/'tests/programs/containers/container-allocation-observer.c'
raw=(D/'build-v2/maintained-parallel.ll').read_bytes()
for observed in (False,True):
 label='maintained-parallel'+('-observed' if observed else '-ordinary')
 ir=D/(label+'.ll');obj=D/(label+'.o');exe=D/label
 data=raw
 if observed:data=raw.replace(b'@malloc(',b'@wf_observe_allocate(').replace(b'@realloc(',b'@wf_observe_reallocate(').replace(b'@free(',b'@wf_observe_release(').replace(b'@main(',b'@wf_fixture_main(')
 ir.write_bytes(data)
 run(label+'-compile',['clang','-O3','-Wno-override-module','-c',str(ir),'-o',str(obj)])
 args=['clang','-O3','-std=c11','-Wall','-Wextra','-Werror','-Wno-override-module','-I'+str(R/'compiler/src/backend'),str(obj)]
 if observed:args+=[str(observer)]
 args+=native+['-pthread','-lm','-o',str(exe)]
 run(label+'-link',args)
 out,err=run(label+'-run',[str(exe)])
 assert err==b'' and out==(b'container allocation observer: 36 allocations, each released exactly once\n' if observed else b'')
for side in ('control','candidate'):
 for mode in ('timed','account'):
  for stage,message in [('reserve','map reserve: 288 ordinary reserve/owner/headroom cases passed'),('lookup','map lookup: 96 isolated owner/query/cleanup cases passed'),('whole','map ecosystem: 18390 oracle-checked traces passed')]:
   assert (D/(side+'-'+mode+'-'+stage+'.stdout')).read_text()==message+'\n'
 assert (D/(side+'-ledger.stdout')).read_bytes()==(B/'reserve-accounting.csv').read_bytes()
for p,h in json.loads((D/'check-inputs.json').read_text()).items():assert sha(Path(p))==h
(D/'checked-images.json').write_text(json.dumps({side+'-'+mode:sha(D/(side+'-'+mode)) for side in ('control','candidate') for mode in ('timed','account')},indent=2)+'\n')
print('Remaining maintained checks passed; expected36 allocations in both modes; original image/ledger/output checks retained')
