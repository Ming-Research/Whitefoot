00000000000099e8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07>:
    99e8: a9ba6ffc     	stp	x28, x27, [sp, #-0x60]!
    99ec: a90167fa     	stp	x26, x25, [sp, #0x10]
    99f0: a9025ff8     	stp	x24, x23, [sp, #0x20]
    99f4: a90357f6     	stp	x22, x21, [sp, #0x30]
    99f8: a9044ff4     	stp	x20, x19, [sp, #0x40]
    99fc: a9057bfd     	stp	x29, x30, [sp, #0x50]
    9a00: d10943ff     	sub	sp, sp, #0x250
    9a04: f1000c3f     	cmp	x1, #0x3
    9a08: 540000c8     	b.hi	0x9a20 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x38>
    9a0c: aa0103f4     	mov	x20, x1
    9a10: aa0003f3     	mov	x19, x0
    9a14: f9400016     	ldr	x22, [x0]
    9a18: eb16003f     	cmp	x1, x22
    9a1c: 54000182     	b.hs	0x9a4c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x64>
    9a20: 52800020     	mov	w0, #0x1                ; =1
    9a24: 52800001     	mov	w1, #0x0                ; =0
    9a28: 52800002     	mov	w2, #0x0                ; =0
    9a2c: 910943ff     	add	sp, sp, #0x250
    9a30: a9457bfd     	ldp	x29, x30, [sp, #0x50]
    9a34: a9444ff4     	ldp	x20, x19, [sp, #0x40]
    9a38: a94357f6     	ldp	x22, x21, [sp, #0x30]
    9a3c: a9425ff8     	ldp	x24, x23, [sp, #0x20]
    9a40: a94167fa     	ldp	x26, x25, [sp, #0x10]
    9a44: a8c66ffc     	ldp	x28, x27, [sp], #0x60
    9a48: d65f03c0     	ret
    9a4c: b4001634     	cbz	x20, 0x9d10 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x328>
    9a50: f9400059     	ldr	x25, [x2]
    9a54: 39402048     	ldrb	w8, [x2, #0x8]
    9a58: b9001fe8     	str	w8, [sp, #0x1c]
    9a5c: 8b141288     	add	x8, x20, x20, lsl #4
    9a60: d37ced00     	lsl	x0, x8, #4
    9a64: 94000000     	bl	0x9a64 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x7c>
    9a68: b4001580     	cbz	x0, 0x9d18 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x330>
    9a6c: aa0003f5     	mov	x21, x0
    9a70: d2800008     	mov	x8, #0x0                ; =0
    9a74: 91002009     	add	x9, x0, #0x8
    9a78: 6f00e400     	movi.2d	v0, #0000000000000000
    9a7c: b81f813f     	stur	wzr, [x9, #-0x8]
    9a80: 91000508     	add	x8, x8, #0x1
    9a84: ad000120     	stp	q0, q0, [x9]
    9a88: ad010120     	stp	q0, q0, [x9, #0x20]
    9a8c: ad020120     	stp	q0, q0, [x9, #0x40]
    9a90: ad030120     	stp	q0, q0, [x9, #0x60]
    9a94: ad040120     	stp	q0, q0, [x9, #0x80]
    9a98: ad050120     	stp	q0, q0, [x9, #0xa0]
    9a9c: ad060120     	stp	q0, q0, [x9, #0xc0]
    9aa0: ad070120     	stp	q0, q0, [x9, #0xe0]
    9aa4: f900813f     	str	xzr, [x9, #0x100]
    9aa8: 91044129     	add	x9, x9, #0x110
    9aac: eb08029f     	cmp	x20, x8
    9ab0: 54fffe61     	b.ne	0x9a7c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x94>
    9ab4: a940a269     	ldp	x9, x8, [x19, #0x8]
    9ab8: f9000be9     	str	x9, [sp, #0x10]
    9abc: f90013e8     	str	x8, [sp, #0x20]
    9ac0: a9005274     	stp	x20, x20, [x19]
    9ac4: f9000a75     	str	x21, [x19, #0x10]
    9ac8: b4001176     	cbz	x22, 0x9cf4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x30c>
    9acc: 5280221a     	mov	w26, #0x110             ; =272
    9ad0: 9100c3fb     	add	x27, sp, #0x30
    9ad4: d2823d78     	mov	x24, #0x11eb            ; =4587
    9ad8: f2a26638     	movk	x24, #0x1331, lsl #16
    9adc: f2c93778     	movk	x24, #0x49bb, lsl #32
    9ae0: f2f29a18     	movk	x24, #0x94d0, lsl #48
    9ae4: 14000003     	b	0x9af0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x108>
    9ae8: f94017f6     	ldr	x22, [sp, #0x28]
    9aec: b4001056     	cbz	x22, 0x9cf4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x30c>
    9af0: d10006d6     	sub	x22, x22, #0x1
    9af4: f90017f6     	str	x22, [sp, #0x28]
    9af8: f94013e8     	ldr	x8, [sp, #0x20]
    9afc: 9b1a22c8     	madd	x8, x22, x26, x8
    9b00: b9400109     	ldr	w9, [x8]
    9b04: 7100053f     	cmp	w9, #0x1
    9b08: 54ffff09     	b.ls	0x9ae8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x100>
    9b0c: f9408509     	ldr	x9, [x8, #0x108]
    9b10: 3cc08100     	ldur	q0, [x8, #0x8]
    9b14: 3c8383e0     	stur	q0, [sp, #0x38]
    9b18: 3cc18100     	ldur	q0, [x8, #0x18]
    9b1c: 3c8483e0     	stur	q0, [sp, #0x48]
    9b20: 3cc28100     	ldur	q0, [x8, #0x28]
    9b24: 3c8583e0     	stur	q0, [sp, #0x58]
    9b28: 3cc38100     	ldur	q0, [x8, #0x38]
    9b2c: 3c8683e0     	stur	q0, [sp, #0x68]
    9b30: 3cc48100     	ldur	q0, [x8, #0x48]
    9b34: 3c8783e0     	stur	q0, [sp, #0x78]
    9b38: 3cc58100     	ldur	q0, [x8, #0x58]
    9b3c: 3c8883e0     	stur	q0, [sp, #0x88]
    9b40: 3cc68100     	ldur	q0, [x8, #0x68]
    9b44: 3c8983e0     	stur	q0, [sp, #0x98]
    9b48: 3cc78100     	ldur	q0, [x8, #0x78]
    9b4c: 3c8a83e0     	stur	q0, [sp, #0xa8]
    9b50: 3cc88100     	ldur	q0, [x8, #0x88]
    9b54: 9100c3ea     	add	x10, sp, #0x30
    9b58: 3c888140     	stur	q0, [x10, #0x88]
    9b5c: 3cc98100     	ldur	q0, [x8, #0x98]
    9b60: 3c898140     	stur	q0, [x10, #0x98]
    9b64: 3cca8100     	ldur	q0, [x8, #0xa8]
    9b68: 3c8a8140     	stur	q0, [x10, #0xa8]
    9b6c: 3ccb8100     	ldur	q0, [x8, #0xb8]
    9b70: 3c8b8140     	stur	q0, [x10, #0xb8]
    9b74: 3ccc8100     	ldur	q0, [x8, #0xc8]
    9b78: 3c8c8140     	stur	q0, [x10, #0xc8]
    9b7c: 3ccd8100     	ldur	q0, [x8, #0xd8]
    9b80: 3c8d8140     	stur	q0, [x10, #0xd8]
    9b84: 3cce8100     	ldur	q0, [x8, #0xe8]
    9b88: 3c8e8140     	stur	q0, [x10, #0xe8]
    9b8c: 3ccf8100     	ldur	q0, [x8, #0xf8]
    9b90: 3c8f8140     	stur	q0, [x10, #0xf8]
    9b94: f9009fe9     	str	x9, [sp, #0x138]
    9b98: 52800028     	mov	w8, #0x1                ; =1
    9b9c: f9001be8     	str	x8, [sp, #0x30]
    9ba0: b9401fe8     	ldr	w8, [sp, #0x1c]
    9ba4: 36000448     	tbz	w8, #0x0, 0x9c2c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x244>
    9ba8: 5280003c     	mov	w28, #0x1               ; =1
    9bac: 14000013     	b	0x9bf8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x210>
    9bb0: d1000796     	sub	x22, x28, #0x1
    9bb4: f9001bf6     	str	x22, [sp, #0x30]
    9bb8: 52802108     	mov	w8, #0x108              ; =264
    9bbc: 9b086f97     	madd	x23, x28, x8, x27
    9bc0: f8500ee3     	ldr	x3, [x23, #-0x100]!
    9bc4: 910503e0     	add	x0, sp, #0x140
    9bc8: 910022e4     	add	x4, x23, #0x8
    9bcc: aa1303e1     	mov	x1, x19
    9bd0: 94000000     	bl	0x9bd0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x1e8>
    9bd4: b94143e8     	ldr	w8, [sp, #0x140]
    9bd8: 34000248     	cbz	w8, 0x9c20 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x238>
    9bdc: 910503e8     	add	x8, sp, #0x140
    9be0: 91002101     	add	x1, x8, #0x8
    9be4: aa1703e0     	mov	x0, x23
    9be8: 52802102     	mov	w2, #0x108              ; =264
    9bec: 94000000     	bl	0x9bec <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x204>
    9bf0: f9001bfc     	str	x28, [sp, #0x30]
    9bf4: b4fff7bc     	cbz	x28, 0x9ae8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x100>
    9bf8: d2800002     	mov	x2, #0x0                ; =0
    9bfc: aa1503e8     	mov	x8, x21
    9c00: b9400109     	ldr	w9, [x8]
    9c04: 7100093f     	cmp	w9, #0x2
    9c08: 54fffd43     	b.lo	0x9bb0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x1c8>
    9c0c: 91044108     	add	x8, x8, #0x110
    9c10: 91000442     	add	x2, x2, #0x1
    9c14: eb02029f     	cmp	x20, x2
    9c18: 54ffff41     	b.ne	0x9c00 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x218>
    9c1c: 17fffff6     	b	0x9bf4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x20c>
    9c20: aa1603fc     	mov	x28, x22
    9c24: b5fffeb6     	cbnz	x22, 0x9bf8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x210>
    9c28: 17ffffb0     	b	0x9ae8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x100>
    9c2c: 52800036     	mov	w22, #0x1               ; =1
    9c30: 14000013     	b	0x9c7c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x294>
    9c34: d10006dc     	sub	x28, x22, #0x1
    9c38: f9001bfc     	str	x28, [sp, #0x30]
    9c3c: 52802108     	mov	w8, #0x108              ; =264
    9c40: 9b086ed7     	madd	x23, x22, x8, x27
    9c44: f8500ee3     	ldr	x3, [x23, #-0x100]!
    9c48: 910503e0     	add	x0, sp, #0x140
    9c4c: 910022e4     	add	x4, x23, #0x8
    9c50: aa1303e1     	mov	x1, x19
    9c54: 94000000     	bl	0x9c54 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x26c>
    9c58: b94143e8     	ldr	w8, [sp, #0x140]
    9c5c: 34000468     	cbz	w8, 0x9ce8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x300>
    9c60: 910503e8     	add	x8, sp, #0x140
    9c64: 91002101     	add	x1, x8, #0x8
    9c68: aa1703e0     	mov	x0, x23
    9c6c: 52802102     	mov	w2, #0x108              ; =264
    9c70: 94000000     	bl	0x9c70 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x288>
    9c74: f9001bf6     	str	x22, [sp, #0x30]
    9c78: b4fff396     	cbz	x22, 0x9ae8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x100>
    9c7c: d2800008     	mov	x8, #0x0                ; =0
    9c80: f9401fe9     	ldr	x9, [sp, #0x38]
    9c84: ca190129     	eor	x9, x9, x25
    9c88: ca497929     	eor	x9, x9, x9, lsr #30
    9c8c: d29cb72a     	mov	x10, #0xe5b9            ; =58809
    9c90: f2a39c8a     	movk	x10, #0x1ce4, lsl #16
    9c94: f2c8edaa     	movk	x10, #0x476d, lsl #32
    9c98: f2f7eb0a     	movk	x10, #0xbf58, lsl #48
    9c9c: 9b0a7d29     	mul	x9, x9, x10
    9ca0: ca496d29     	eor	x9, x9, x9, lsr #27
    9ca4: 9b187d29     	mul	x9, x9, x24
    9ca8: ca497d29     	eor	x9, x9, x9, lsr #31
    9cac: 9ad4092a     	udiv	x10, x9, x20
    9cb0: 9b14a549     	msub	x9, x10, x20, x9
    9cb4: cb09028a     	sub	x10, x20, x9
    9cb8: cb0a03eb     	neg	x11, x10
    9cbc: eb0a011f     	cmp	x8, x10
    9cc0: 9a8b312c     	csel	x12, x9, x11, lo
    9cc4: 8b080182     	add	x2, x12, x8
    9cc8: 9b1a7c4c     	mul	x12, x2, x26
    9ccc: b86c6aac     	ldr	w12, [x21, x12]
    9cd0: 7100099f     	cmp	w12, #0x2
    9cd4: 54fffb03     	b.lo	0x9c34 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x24c>
    9cd8: 91000508     	add	x8, x8, #0x1
    9cdc: eb08029f     	cmp	x20, x8
    9ce0: 54fffee1     	b.ne	0x9cbc <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x2d4>
    9ce4: 17ffffe5     	b	0x9c78 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x290>
    9ce8: aa1c03f6     	mov	x22, x28
    9cec: b5fffc9c     	cbnz	x28, 0x9c7c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x294>
    9cf0: 17ffff7e     	b	0x9ae8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x100>
    9cf4: f9400be8     	ldr	x8, [sp, #0x10]
    9cf8: b4000068     	cbz	x8, 0x9d04 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x31c>
    9cfc: f94013e0     	ldr	x0, [sp, #0x20]
    9d00: 94000000     	bl	0x9d00 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x318>
    9d04: 52800000     	mov	w0, #0x0                ; =0
    9d08: f900127f     	str	xzr, [x19, #0x20]
    9d0c: 17ffff46     	b	0x9a24 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x3c>
    9d10: 52800000     	mov	w0, #0x0                ; =0
    9d14: 17ffff44     	b	0x9a24 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x3c>
    9d18: 94000000     	bl	0x9d18 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x330>

