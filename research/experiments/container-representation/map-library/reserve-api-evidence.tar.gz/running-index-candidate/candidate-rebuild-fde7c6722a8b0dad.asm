0000000000009410 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad>:
    9410: d10183ff     	sub	sp, sp, #0x60
    9414: a9025ff8     	stp	x24, x23, [sp, #0x20]
    9418: a90357f6     	stp	x22, x21, [sp, #0x30]
    941c: a9044ff4     	stp	x20, x19, [sp, #0x40]
    9420: a9057bfd     	stp	x29, x30, [sp, #0x50]
    9424: f140103f     	cmp	x1, #0x4, lsl #12       ; =0x4000
    9428: 54000088     	b.hi	0x9438 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x28>
    942c: f9400014     	ldr	x20, [x0]
    9430: eb14003f     	cmp	x1, x20
    9434: 54000142     	b.hs	0x945c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x4c>
    9438: 52800020     	mov	w0, #0x1                ; =1
    943c: 52800001     	mov	w1, #0x0                ; =0
    9440: 52800002     	mov	w2, #0x0                ; =0
    9444: a9457bfd     	ldp	x29, x30, [sp, #0x50]
    9448: a9444ff4     	ldp	x20, x19, [sp, #0x40]
    944c: a94357f6     	ldp	x22, x21, [sp, #0x30]
    9450: a9425ff8     	ldp	x24, x23, [sp, #0x20]
    9454: 910183ff     	add	sp, sp, #0x60
    9458: d65f03c0     	ret
    945c: b4000701     	cbz	x1, 0x953c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x12c>
    9460: aa0003f3     	mov	x19, x0
    9464: f9400055     	ldr	x21, [x2]
    9468: 39402056     	ldrb	w22, [x2, #0x8]
    946c: aa0103f7     	mov	x23, x1
    9470: 8b010428     	add	x8, x1, x1, lsl #1
    9474: d37df100     	lsl	x0, x8, #3
    9478: 94000000     	bl	0x9478 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x68>
    947c: b4000d20     	cbz	x0, 0x9620 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x210>
    9480: d280000c     	mov	x12, #0x0               ; =0
    9484: 91002008     	add	x8, x0, #0x8
    9488: aa1303e9     	mov	x9, x19
    948c: aa1703ea     	mov	x10, x23
    9490: b81f811f     	stur	wzr, [x8, #-0x8]
    9494: 9100058c     	add	x12, x12, #0x1
    9498: a881fd1f     	stp	xzr, xzr, [x8], #0x18
    949c: eb0c015f     	cmp	x10, x12
    94a0: 54ffff81     	b.ne	0x9490 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x80>
    94a4: a940a12b     	ldp	x11, x8, [x9, #0x8]
    94a8: a900292a     	stp	x10, x10, [x9]
    94ac: f9000920     	str	x0, [x9, #0x10]
    94b0: b4000ab4     	cbz	x20, 0x9604 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1f4>
    94b4: d100058c     	sub	x12, x12, #0x1
    94b8: 5280030d     	mov	w13, #0x18              ; =24
    94bc: 36000456     	tbz	w22, #0x0, 0x9544 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x134>
    94c0: 910023ee     	add	x14, sp, #0x8
    94c4: 5280004f     	mov	w15, #0x2               ; =2
    94c8: 14000002     	b	0x94d0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xc0>
    94cc: b40009d4     	cbz	x20, 0x9604 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1f4>
    94d0: d1000694     	sub	x20, x20, #0x1
    94d4: 9b0d2290     	madd	x16, x20, x13, x8
    94d8: b9400211     	ldr	w17, [x16]
    94dc: 71000a3f     	cmp	w17, #0x2
    94e0: 54ffff63     	b.lo	0x94cc <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xbc>
    94e4: 3cc08200     	ldur	q0, [x16, #0x8]
    94e8: 3c8103e0     	stur	q0, [sp, #0x10]
    94ec: 52800030     	mov	w16, #0x1               ; =1
    94f0: 14000008     	b	0x9510 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x100>
    94f4: d1000610     	sub	x16, x16, #0x1
    94f8: 8b1011d1     	add	x17, x14, x16, lsl #4
    94fc: f90007f0     	str	x16, [sp, #0x8]
    9500: b900004f     	str	w15, [x2]
    9504: 3cc08220     	ldur	q0, [x17, #0x8]
    9508: 3c808040     	stur	q0, [x2, #0x8]
    950c: b4fffe10     	cbz	x16, 0x94cc <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xbc>
    9510: d2800011     	mov	x17, #0x0               ; =0
    9514: aa0a03e1     	mov	x1, x10
    9518: 9b0d0222     	madd	x2, x17, x13, x0
    951c: b9400043     	ldr	w3, [x2]
    9520: 7100087f     	cmp	w3, #0x2
    9524: 54fffe83     	b.lo	0x94f4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xe4>
    9528: eb0c023f     	cmp	x17, x12
    952c: 9a9127f1     	csinc	x17, xzr, x17, hs
    9530: f1000421     	subs	x1, x1, #0x1
    9534: 54ffff21     	b.ne	0x9518 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x108>
    9538: 17fffff5     	b	0x950c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xfc>
    953c: 52800000     	mov	w0, #0x0                ; =0
    9540: 17ffffbf     	b	0x943c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x2c>
    9544: d29cb72e     	mov	x14, #0xe5b9            ; =58809
    9548: f2a39c8e     	movk	x14, #0x1ce4, lsl #16
    954c: f2c8edae     	movk	x14, #0x476d, lsl #32
    9550: f2f7eb0e     	movk	x14, #0xbf58, lsl #48
    9554: d2823d6f     	mov	x15, #0x11eb            ; =4587
    9558: f2a2662f     	movk	x15, #0x1331, lsl #16
    955c: f2c9376f     	movk	x15, #0x49bb, lsl #32
    9560: f2f29a0f     	movk	x15, #0x94d0, lsl #48
    9564: 910023f0     	add	x16, sp, #0x8
    9568: 52800051     	mov	w17, #0x2               ; =2
    956c: 14000002     	b	0x9574 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x164>
    9570: b40004b4     	cbz	x20, 0x9604 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1f4>
    9574: d1000694     	sub	x20, x20, #0x1
    9578: 9b0d2281     	madd	x1, x20, x13, x8
    957c: b9400022     	ldr	w2, [x1]
    9580: 7100045f     	cmp	w2, #0x1
    9584: 54ffff69     	b.ls	0x9570 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x160>
    9588: 3cc08020     	ldur	q0, [x1, #0x8]
    958c: f9400421     	ldr	x1, [x1, #0x8]
    9590: 3c8103e0     	stur	q0, [sp, #0x10]
    9594: ca150021     	eor	x1, x1, x21
    9598: ca417821     	eor	x1, x1, x1, lsr #30
    959c: 9b0e7c21     	mul	x1, x1, x14
    95a0: ca416c21     	eor	x1, x1, x1, lsr #27
    95a4: 9b0f7c21     	mul	x1, x1, x15
    95a8: ca417c21     	eor	x1, x1, x1, lsr #31
    95ac: 9aca0822     	udiv	x2, x1, x10
    95b0: 9b0a8441     	msub	x1, x2, x10, x1
    95b4: 52800022     	mov	w2, #0x1                ; =1
    95b8: 14000008     	b	0x95d8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1c8>
    95bc: d1000442     	sub	x2, x2, #0x1
    95c0: 8b021203     	add	x3, x16, x2, lsl #4
    95c4: f90007e2     	str	x2, [sp, #0x8]
    95c8: b90000b1     	str	w17, [x5]
    95cc: 3cc08060     	ldur	q0, [x3, #0x8]
    95d0: 3c8080a0     	stur	q0, [x5, #0x8]
    95d4: b4fffce2     	cbz	x2, 0x9570 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x160>
    95d8: aa0a03e3     	mov	x3, x10
    95dc: aa0103e4     	mov	x4, x1
    95e0: 9b0d0085     	madd	x5, x4, x13, x0
    95e4: b94000a6     	ldr	w6, [x5]
    95e8: 710004df     	cmp	w6, #0x1
    95ec: 54fffe89     	b.ls	0x95bc <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1ac>
    95f0: eb0c009f     	cmp	x4, x12
    95f4: 9a8427e4     	csinc	x4, xzr, x4, hs
    95f8: f1000463     	subs	x3, x3, #0x1
    95fc: 54ffff21     	b.ne	0x95e0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1d0>
    9600: 17fffff5     	b	0x95d4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1c4>
    9604: b400008b     	cbz	x11, 0x9614 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x204>
    9608: aa0803e0     	mov	x0, x8
    960c: 94000000     	bl	0x960c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1fc>
    9610: aa1303e9     	mov	x9, x19
    9614: 52800000     	mov	w0, #0x0                ; =0
    9618: f900113f     	str	xzr, [x9, #0x20]
    961c: 17ffff88     	b	0x943c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x2c>
    9620: 94000000     	bl	0x9620 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x210>

