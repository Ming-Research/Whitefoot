0000000000008fa4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6>:
    8fa4: d10183ff     	sub	sp, sp, #0x60
    8fa8: a9025ff8     	stp	x24, x23, [sp, #0x20]
    8fac: a90357f6     	stp	x22, x21, [sp, #0x30]
    8fb0: a9044ff4     	stp	x20, x19, [sp, #0x40]
    8fb4: a9057bfd     	stp	x29, x30, [sp, #0x50]
    8fb8: f1000c3f     	cmp	x1, #0x3
    8fbc: 54000088     	b.hi	0x8fcc <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x28>
    8fc0: f9400014     	ldr	x20, [x0]
    8fc4: eb14003f     	cmp	x1, x20
    8fc8: 54000142     	b.hs	0x8ff0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x4c>
    8fcc: 52800020     	mov	w0, #0x1                ; =1
    8fd0: 52800001     	mov	w1, #0x0                ; =0
    8fd4: 52800002     	mov	w2, #0x0                ; =0
    8fd8: a9457bfd     	ldp	x29, x30, [sp, #0x50]
    8fdc: a9444ff4     	ldp	x20, x19, [sp, #0x40]
    8fe0: a94357f6     	ldp	x22, x21, [sp, #0x30]
    8fe4: a9425ff8     	ldp	x24, x23, [sp, #0x20]
    8fe8: 910183ff     	add	sp, sp, #0x60
    8fec: d65f03c0     	ret
    8ff0: b4000701     	cbz	x1, 0x90d0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x12c>
    8ff4: aa0003f3     	mov	x19, x0
    8ff8: f9400055     	ldr	x21, [x2]
    8ffc: 39402056     	ldrb	w22, [x2, #0x8]
    9000: aa0103f7     	mov	x23, x1
    9004: 8b010428     	add	x8, x1, x1, lsl #1
    9008: d37df100     	lsl	x0, x8, #3
    900c: 94000000     	bl	0x900c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x68>
    9010: b4000d20     	cbz	x0, 0x91b4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x210>
    9014: d280000c     	mov	x12, #0x0               ; =0
    9018: 91002008     	add	x8, x0, #0x8
    901c: aa1303e9     	mov	x9, x19
    9020: aa1703ea     	mov	x10, x23
    9024: b81f811f     	stur	wzr, [x8, #-0x8]
    9028: 9100058c     	add	x12, x12, #0x1
    902c: a881fd1f     	stp	xzr, xzr, [x8], #0x18
    9030: eb0c015f     	cmp	x10, x12
    9034: 54ffff81     	b.ne	0x9024 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x80>
    9038: a940a12b     	ldp	x11, x8, [x9, #0x8]
    903c: a900292a     	stp	x10, x10, [x9]
    9040: f9000920     	str	x0, [x9, #0x10]
    9044: b4000ab4     	cbz	x20, 0x9198 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1f4>
    9048: d100058c     	sub	x12, x12, #0x1
    904c: 5280030d     	mov	w13, #0x18              ; =24
    9050: 36000456     	tbz	w22, #0x0, 0x90d8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x134>
    9054: 910023ee     	add	x14, sp, #0x8
    9058: 5280004f     	mov	w15, #0x2               ; =2
    905c: 14000002     	b	0x9064 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xc0>
    9060: b40009d4     	cbz	x20, 0x9198 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1f4>
    9064: d1000694     	sub	x20, x20, #0x1
    9068: 9b0d2290     	madd	x16, x20, x13, x8
    906c: b9400211     	ldr	w17, [x16]
    9070: 71000a3f     	cmp	w17, #0x2
    9074: 54ffff63     	b.lo	0x9060 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xbc>
    9078: 3cc08200     	ldur	q0, [x16, #0x8]
    907c: 3c8103e0     	stur	q0, [sp, #0x10]
    9080: 52800030     	mov	w16, #0x1               ; =1
    9084: 14000008     	b	0x90a4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x100>
    9088: d1000610     	sub	x16, x16, #0x1
    908c: 8b1011d1     	add	x17, x14, x16, lsl #4
    9090: f90007f0     	str	x16, [sp, #0x8]
    9094: b900004f     	str	w15, [x2]
    9098: 3cc08220     	ldur	q0, [x17, #0x8]
    909c: 3c808040     	stur	q0, [x2, #0x8]
    90a0: b4fffe10     	cbz	x16, 0x9060 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xbc>
    90a4: d2800011     	mov	x17, #0x0               ; =0
    90a8: aa0a03e1     	mov	x1, x10
    90ac: 9b0d0222     	madd	x2, x17, x13, x0
    90b0: b9400043     	ldr	w3, [x2]
    90b4: 7100087f     	cmp	w3, #0x2
    90b8: 54fffe83     	b.lo	0x9088 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xe4>
    90bc: eb0c023f     	cmp	x17, x12
    90c0: 9a9127f1     	csinc	x17, xzr, x17, hs
    90c4: f1000421     	subs	x1, x1, #0x1
    90c8: 54ffff21     	b.ne	0x90ac <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x108>
    90cc: 17fffff5     	b	0x90a0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xfc>
    90d0: 52800000     	mov	w0, #0x0                ; =0
    90d4: 17ffffbf     	b	0x8fd0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x2c>
    90d8: d29cb72e     	mov	x14, #0xe5b9            ; =58809
    90dc: f2a39c8e     	movk	x14, #0x1ce4, lsl #16
    90e0: f2c8edae     	movk	x14, #0x476d, lsl #32
    90e4: f2f7eb0e     	movk	x14, #0xbf58, lsl #48
    90e8: d2823d6f     	mov	x15, #0x11eb            ; =4587
    90ec: f2a2662f     	movk	x15, #0x1331, lsl #16
    90f0: f2c9376f     	movk	x15, #0x49bb, lsl #32
    90f4: f2f29a0f     	movk	x15, #0x94d0, lsl #48
    90f8: 910023f0     	add	x16, sp, #0x8
    90fc: 52800051     	mov	w17, #0x2               ; =2
    9100: 14000002     	b	0x9108 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x164>
    9104: b40004b4     	cbz	x20, 0x9198 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1f4>
    9108: d1000694     	sub	x20, x20, #0x1
    910c: 9b0d2281     	madd	x1, x20, x13, x8
    9110: b9400022     	ldr	w2, [x1]
    9114: 7100045f     	cmp	w2, #0x1
    9118: 54ffff69     	b.ls	0x9104 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x160>
    911c: 3cc08020     	ldur	q0, [x1, #0x8]
    9120: f9400421     	ldr	x1, [x1, #0x8]
    9124: 3c8103e0     	stur	q0, [sp, #0x10]
    9128: ca150021     	eor	x1, x1, x21
    912c: ca417821     	eor	x1, x1, x1, lsr #30
    9130: 9b0e7c21     	mul	x1, x1, x14
    9134: ca416c21     	eor	x1, x1, x1, lsr #27
    9138: 9b0f7c21     	mul	x1, x1, x15
    913c: ca417c21     	eor	x1, x1, x1, lsr #31
    9140: 9aca0822     	udiv	x2, x1, x10
    9144: 9b0a8441     	msub	x1, x2, x10, x1
    9148: 52800022     	mov	w2, #0x1                ; =1
    914c: 14000008     	b	0x916c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1c8>
    9150: d1000442     	sub	x2, x2, #0x1
    9154: 8b021203     	add	x3, x16, x2, lsl #4
    9158: f90007e2     	str	x2, [sp, #0x8]
    915c: b90000b1     	str	w17, [x5]
    9160: 3cc08060     	ldur	q0, [x3, #0x8]
    9164: 3c8080a0     	stur	q0, [x5, #0x8]
    9168: b4fffce2     	cbz	x2, 0x9104 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x160>
    916c: aa0a03e3     	mov	x3, x10
    9170: aa0103e4     	mov	x4, x1
    9174: 9b0d0085     	madd	x5, x4, x13, x0
    9178: b94000a6     	ldr	w6, [x5]
    917c: 710004df     	cmp	w6, #0x1
    9180: 54fffe89     	b.ls	0x9150 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1ac>
    9184: eb0c009f     	cmp	x4, x12
    9188: 9a8427e4     	csinc	x4, xzr, x4, hs
    918c: f1000463     	subs	x3, x3, #0x1
    9190: 54ffff21     	b.ne	0x9174 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1d0>
    9194: 17fffff5     	b	0x9168 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1c4>
    9198: b400008b     	cbz	x11, 0x91a8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x204>
    919c: aa0803e0     	mov	x0, x8
    91a0: 94000000     	bl	0x91a0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1fc>
    91a4: aa1303e9     	mov	x9, x19
    91a8: 52800000     	mov	w0, #0x0                ; =0
    91ac: f900113f     	str	xzr, [x9, #0x20]
    91b0: 17ffff88     	b	0x8fd0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x2c>
    91b4: 94000000     	bl	0x91b4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x210>

