00000000000099e8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07>:
    99e8: a9ba6ffc     	stp	x28, x27, [sp, #-0x60]!
    99ec: a90167fa     	stp	x26, x25, [sp, #0x10]
    99f0: a9025ff8     	stp	x24, x23, [sp, #0x20]
    99f4: a90357f6     	stp	x22, x21, [sp, #0x30]
    99f8: a9044ff4     	stp	x20, x19, [sp, #0x40]
    99fc: a9057bfd     	stp	x29, x30, [sp, #0x50]
    9a00: d10943ff     	sub	sp, sp, #0x250
    9a04: f1000c3f     	cmp	x1, #0x3
    9a08: 540000c8     	b.hi	0x9a20 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x38>
    9a0c: aa0103f4     	mov	x20, x1
    9a10: aa0003f3     	mov	x19, x0
    9a14: f9400017     	ldr	x23, [x0]
    9a18: eb17003f     	cmp	x1, x23
    9a1c: 54000182     	b.hs	0x9a4c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x64>
    9a20: 52800020     	mov	w0, #0x1                ; =1
    9a24: 52800001     	mov	w1, #0x0                ; =0
    9a28: 52800002     	mov	w2, #0x0                ; =0
    9a2c: 910943ff     	add	sp, sp, #0x250
    9a30: a9457bfd     	ldp	x29, x30, [sp, #0x50]
    9a34: a9444ff4     	ldp	x20, x19, [sp, #0x40]
    9a38: a94357f6     	ldp	x22, x21, [sp, #0x30]
    9a3c: a9425ff8     	ldp	x24, x23, [sp, #0x20]
    9a40: a94167fa     	ldp	x26, x25, [sp, #0x10]
    9a44: a8c66ffc     	ldp	x28, x27, [sp], #0x60
    9a48: d65f03c0     	ret
    9a4c: b40015f4     	cbz	x20, 0x9d08 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x320>
    9a50: f9400059     	ldr	x25, [x2]
    9a54: 39402048     	ldrb	w8, [x2, #0x8]
    9a58: b9001fe8     	str	w8, [sp, #0x1c]
    9a5c: 8b141288     	add	x8, x20, x20, lsl #4
    9a60: d37ced00     	lsl	x0, x8, #4
    9a64: 94000000     	bl	0x9a64 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x7c>
    9a68: b4001540     	cbz	x0, 0x9d10 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x328>
    9a6c: aa0003f5     	mov	x21, x0
    9a70: d2800008     	mov	x8, #0x0                ; =0
    9a74: 91002009     	add	x9, x0, #0x8
    9a78: 6f00e400     	movi.2d	v0, #0000000000000000
    9a7c: b81f813f     	stur	wzr, [x9, #-0x8]
    9a80: 91000508     	add	x8, x8, #0x1
    9a84: ad000120     	stp	q0, q0, [x9]
    9a88: ad010120     	stp	q0, q0, [x9, #0x20]
    9a8c: ad020120     	stp	q0, q0, [x9, #0x40]
    9a90: ad030120     	stp	q0, q0, [x9, #0x60]
    9a94: ad040120     	stp	q0, q0, [x9, #0x80]
    9a98: ad050120     	stp	q0, q0, [x9, #0xa0]
    9a9c: ad060120     	stp	q0, q0, [x9, #0xc0]
    9aa0: ad070120     	stp	q0, q0, [x9, #0xe0]
    9aa4: f900813f     	str	xzr, [x9, #0x100]
    9aa8: 91044129     	add	x9, x9, #0x110
    9aac: eb08029f     	cmp	x20, x8
    9ab0: 54fffe61     	b.ne	0x9a7c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x94>
    9ab4: a940a66a     	ldp	x10, x9, [x19, #0x8]
    9ab8: f9000bea     	str	x10, [sp, #0x10]
    9abc: f90013e9     	str	x9, [sp, #0x20]
    9ac0: a9005274     	stp	x20, x20, [x19]
    9ac4: f9000a75     	str	x21, [x19, #0x10]
    9ac8: b4001137     	cbz	x23, 0x9cec <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x304>
    9acc: d100051c     	sub	x28, x8, #0x1
    9ad0: 52802216     	mov	w22, #0x110             ; =272
    9ad4: 9100c3fa     	add	x26, sp, #0x30
    9ad8: 14000003     	b	0x9ae4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0xfc>
    9adc: f94017f7     	ldr	x23, [sp, #0x28]
    9ae0: b4001077     	cbz	x23, 0x9cec <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x304>
    9ae4: d10006f7     	sub	x23, x23, #0x1
    9ae8: f90017f7     	str	x23, [sp, #0x28]
    9aec: f94013e8     	ldr	x8, [sp, #0x20]
    9af0: 9b1622e8     	madd	x8, x23, x22, x8
    9af4: b9400109     	ldr	w9, [x8]
    9af8: 7100053f     	cmp	w9, #0x1
    9afc: 54ffff09     	b.ls	0x9adc <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0xf4>
    9b00: f9408509     	ldr	x9, [x8, #0x108]
    9b04: 3cc08100     	ldur	q0, [x8, #0x8]
    9b08: 3c8383e0     	stur	q0, [sp, #0x38]
    9b0c: 3cc18100     	ldur	q0, [x8, #0x18]
    9b10: 3c8483e0     	stur	q0, [sp, #0x48]
    9b14: 3cc28100     	ldur	q0, [x8, #0x28]
    9b18: 3c8583e0     	stur	q0, [sp, #0x58]
    9b1c: 3cc38100     	ldur	q0, [x8, #0x38]
    9b20: 3c8683e0     	stur	q0, [sp, #0x68]
    9b24: 3cc48100     	ldur	q0, [x8, #0x48]
    9b28: 3c8783e0     	stur	q0, [sp, #0x78]
    9b2c: 3cc58100     	ldur	q0, [x8, #0x58]
    9b30: 3c8883e0     	stur	q0, [sp, #0x88]
    9b34: 3cc68100     	ldur	q0, [x8, #0x68]
    9b38: 3c8983e0     	stur	q0, [sp, #0x98]
    9b3c: 3cc78100     	ldur	q0, [x8, #0x78]
    9b40: 3c8a83e0     	stur	q0, [sp, #0xa8]
    9b44: 3cc88100     	ldur	q0, [x8, #0x88]
    9b48: 9100c3ea     	add	x10, sp, #0x30
    9b4c: 3c888140     	stur	q0, [x10, #0x88]
    9b50: 3cc98100     	ldur	q0, [x8, #0x98]
    9b54: 3c898140     	stur	q0, [x10, #0x98]
    9b58: 3cca8100     	ldur	q0, [x8, #0xa8]
    9b5c: 3c8a8140     	stur	q0, [x10, #0xa8]
    9b60: 3ccb8100     	ldur	q0, [x8, #0xb8]
    9b64: 3c8b8140     	stur	q0, [x10, #0xb8]
    9b68: 3ccc8100     	ldur	q0, [x8, #0xc8]
    9b6c: 3c8c8140     	stur	q0, [x10, #0xc8]
    9b70: 3ccd8100     	ldur	q0, [x8, #0xd8]
    9b74: 3c8d8140     	stur	q0, [x10, #0xd8]
    9b78: 3cce8100     	ldur	q0, [x8, #0xe8]
    9b7c: 3c8e8140     	stur	q0, [x10, #0xe8]
    9b80: 3ccf8100     	ldur	q0, [x8, #0xf8]
    9b84: 3c8f8140     	stur	q0, [x10, #0xf8]
    9b88: f9009fe9     	str	x9, [sp, #0x138]
    9b8c: 52800028     	mov	w8, #0x1                ; =1
    9b90: f9001be8     	str	x8, [sp, #0x30]
    9b94: b9401fe8     	ldr	w8, [sp, #0x1c]
    9b98: 36000468     	tbz	w8, #0x0, 0x9c24 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x23c>
    9b9c: 5280003b     	mov	w27, #0x1               ; =1
    9ba0: 14000013     	b	0x9bec <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x204>
    9ba4: d1000778     	sub	x24, x27, #0x1
    9ba8: f9001bf8     	str	x24, [sp, #0x30]
    9bac: 52802108     	mov	w8, #0x108              ; =264
    9bb0: 9b086b77     	madd	x23, x27, x8, x26
    9bb4: f8500ee3     	ldr	x3, [x23, #-0x100]!
    9bb8: 910503e0     	add	x0, sp, #0x140
    9bbc: 910022e4     	add	x4, x23, #0x8
    9bc0: aa1303e1     	mov	x1, x19
    9bc4: 94000000     	bl	0x9bc4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x1dc>
    9bc8: b94143e8     	ldr	w8, [sp, #0x140]
    9bcc: 34000268     	cbz	w8, 0x9c18 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x230>
    9bd0: 910503e8     	add	x8, sp, #0x140
    9bd4: 91002101     	add	x1, x8, #0x8
    9bd8: aa1703e0     	mov	x0, x23
    9bdc: 52802102     	mov	w2, #0x108              ; =264
    9be0: 94000000     	bl	0x9be0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x1f8>
    9be4: f9001bfb     	str	x27, [sp, #0x30]
    9be8: b4fff7bb     	cbz	x27, 0x9adc <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0xf4>
    9bec: d2800002     	mov	x2, #0x0                ; =0
    9bf0: aa1403e8     	mov	x8, x20
    9bf4: 9b167c49     	mul	x9, x2, x22
    9bf8: b8696aa9     	ldr	w9, [x21, x9]
    9bfc: 7100093f     	cmp	w9, #0x2
    9c00: 54fffd23     	b.lo	0x9ba4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x1bc>
    9c04: eb1c005f     	cmp	x2, x28
    9c08: 9a8227e2     	csinc	x2, xzr, x2, hs
    9c0c: f1000508     	subs	x8, x8, #0x1
    9c10: 54ffff21     	b.ne	0x9bf4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x20c>
    9c14: 17fffff5     	b	0x9be8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x200>
    9c18: aa1803fb     	mov	x27, x24
    9c1c: b5fffe98     	cbnz	x24, 0x9bec <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x204>
    9c20: 17ffffaf     	b	0x9adc <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0xf4>
    9c24: 52800038     	mov	w24, #0x1               ; =1
    9c28: 14000013     	b	0x9c74 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x28c>
    9c2c: d100071b     	sub	x27, x24, #0x1
    9c30: f9001bfb     	str	x27, [sp, #0x30]
    9c34: 52802108     	mov	w8, #0x108              ; =264
    9c38: 9b086b17     	madd	x23, x24, x8, x26
    9c3c: f8500ee3     	ldr	x3, [x23, #-0x100]!
    9c40: 910503e0     	add	x0, sp, #0x140
    9c44: 910022e4     	add	x4, x23, #0x8
    9c48: aa1303e1     	mov	x1, x19
    9c4c: 94000000     	bl	0x9c4c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x264>
    9c50: b94143e8     	ldr	w8, [sp, #0x140]
    9c54: 34000468     	cbz	w8, 0x9ce0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x2f8>
    9c58: 910503e8     	add	x8, sp, #0x140
    9c5c: 91002101     	add	x1, x8, #0x8
    9c60: aa1703e0     	mov	x0, x23
    9c64: 52802102     	mov	w2, #0x108              ; =264
    9c68: 94000000     	bl	0x9c68 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x280>
    9c6c: f9001bf8     	str	x24, [sp, #0x30]
    9c70: b4fff378     	cbz	x24, 0x9adc <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0xf4>
    9c74: f9401fe8     	ldr	x8, [sp, #0x38]
    9c78: ca190108     	eor	x8, x8, x25
    9c7c: ca487908     	eor	x8, x8, x8, lsr #30
    9c80: d29cb729     	mov	x9, #0xe5b9             ; =58809
    9c84: f2a39c89     	movk	x9, #0x1ce4, lsl #16
    9c88: f2c8eda9     	movk	x9, #0x476d, lsl #32
    9c8c: f2f7eb09     	movk	x9, #0xbf58, lsl #48
    9c90: 9b097d08     	mul	x8, x8, x9
    9c94: ca486d08     	eor	x8, x8, x8, lsr #27
    9c98: d2823d69     	mov	x9, #0x11eb             ; =4587
    9c9c: f2a26629     	movk	x9, #0x1331, lsl #16
    9ca0: f2c93769     	movk	x9, #0x49bb, lsl #32
    9ca4: f2f29a09     	movk	x9, #0x94d0, lsl #48
    9ca8: 9b097d08     	mul	x8, x8, x9
    9cac: ca487d08     	eor	x8, x8, x8, lsr #31
    9cb0: 9ad40909     	udiv	x9, x8, x20
    9cb4: 9b14a122     	msub	x2, x9, x20, x8
    9cb8: aa1403e8     	mov	x8, x20
    9cbc: 9b167c49     	mul	x9, x2, x22
    9cc0: b8696aa9     	ldr	w9, [x21, x9]
    9cc4: 7100053f     	cmp	w9, #0x1
    9cc8: 54fffb29     	b.ls	0x9c2c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x244>
    9ccc: eb1c005f     	cmp	x2, x28
    9cd0: 9a8227e2     	csinc	x2, xzr, x2, hs
    9cd4: f1000508     	subs	x8, x8, #0x1
    9cd8: 54ffff21     	b.ne	0x9cbc <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x2d4>
    9cdc: 17ffffe5     	b	0x9c70 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x288>
    9ce0: aa1b03f8     	mov	x24, x27
    9ce4: b5fffc9b     	cbnz	x27, 0x9c74 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x28c>
    9ce8: 17ffff7d     	b	0x9adc <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0xf4>
    9cec: f9400be8     	ldr	x8, [sp, #0x10]
    9cf0: b4000068     	cbz	x8, 0x9cfc <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x314>
    9cf4: f94013e0     	ldr	x0, [sp, #0x20]
    9cf8: 94000000     	bl	0x9cf8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x310>
    9cfc: 52800000     	mov	w0, #0x0                ; =0
    9d00: f900127f     	str	xzr, [x19, #0x20]
    9d04: 17ffff48     	b	0x9a24 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x3c>
    9d08: 52800000     	mov	w0, #0x0                ; =0
    9d0c: 17ffff46     	b	0x9a24 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x3c>
    9d10: 94000000     	bl	0x9d10 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x328>

