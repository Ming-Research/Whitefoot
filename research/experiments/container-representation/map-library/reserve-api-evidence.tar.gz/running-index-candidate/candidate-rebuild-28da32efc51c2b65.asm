0000000000009f84 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65>:
    9f84: a9ba6ffc     	stp	x28, x27, [sp, #-0x60]!
    9f88: a90167fa     	stp	x26, x25, [sp, #0x10]
    9f8c: a9025ff8     	stp	x24, x23, [sp, #0x20]
    9f90: a90357f6     	stp	x22, x21, [sp, #0x30]
    9f94: a9044ff4     	stp	x20, x19, [sp, #0x40]
    9f98: a9057bfd     	stp	x29, x30, [sp, #0x50]
    9f9c: d10943ff     	sub	sp, sp, #0x250
    9fa0: f140103f     	cmp	x1, #0x4, lsl #12       ; =0x4000
    9fa4: 540000c8     	b.hi	0x9fbc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x38>
    9fa8: aa0103f4     	mov	x20, x1
    9fac: aa0003f3     	mov	x19, x0
    9fb0: f9400017     	ldr	x23, [x0]
    9fb4: eb17003f     	cmp	x1, x23
    9fb8: 54000182     	b.hs	0x9fe8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x64>
    9fbc: 52800020     	mov	w0, #0x1                ; =1
    9fc0: 52800001     	mov	w1, #0x0                ; =0
    9fc4: 52800002     	mov	w2, #0x0                ; =0
    9fc8: 910943ff     	add	sp, sp, #0x250
    9fcc: a9457bfd     	ldp	x29, x30, [sp, #0x50]
    9fd0: a9444ff4     	ldp	x20, x19, [sp, #0x40]
    9fd4: a94357f6     	ldp	x22, x21, [sp, #0x30]
    9fd8: a9425ff8     	ldp	x24, x23, [sp, #0x20]
    9fdc: a94167fa     	ldp	x26, x25, [sp, #0x10]
    9fe0: a8c66ffc     	ldp	x28, x27, [sp], #0x60
    9fe4: d65f03c0     	ret
    9fe8: b40015f4     	cbz	x20, 0xa2a4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x320>
    9fec: f9400059     	ldr	x25, [x2]
    9ff0: 39402048     	ldrb	w8, [x2, #0x8]
    9ff4: b9001fe8     	str	w8, [sp, #0x1c]
    9ff8: 8b141288     	add	x8, x20, x20, lsl #4
    9ffc: d37ced00     	lsl	x0, x8, #4
    a000: 94000000     	bl	0xa000 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x7c>
    a004: b4001540     	cbz	x0, 0xa2ac <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x328>
    a008: aa0003f5     	mov	x21, x0
    a00c: d2800008     	mov	x8, #0x0                ; =0
    a010: 91002009     	add	x9, x0, #0x8
    a014: 6f00e400     	movi.2d	v0, #0000000000000000
    a018: b81f813f     	stur	wzr, [x9, #-0x8]
    a01c: 91000508     	add	x8, x8, #0x1
    a020: ad000120     	stp	q0, q0, [x9]
    a024: ad010120     	stp	q0, q0, [x9, #0x20]
    a028: ad020120     	stp	q0, q0, [x9, #0x40]
    a02c: ad030120     	stp	q0, q0, [x9, #0x60]
    a030: ad040120     	stp	q0, q0, [x9, #0x80]
    a034: ad050120     	stp	q0, q0, [x9, #0xa0]
    a038: ad060120     	stp	q0, q0, [x9, #0xc0]
    a03c: ad070120     	stp	q0, q0, [x9, #0xe0]
    a040: f900813f     	str	xzr, [x9, #0x100]
    a044: 91044129     	add	x9, x9, #0x110
    a048: eb08029f     	cmp	x20, x8
    a04c: 54fffe61     	b.ne	0xa018 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x94>
    a050: a940a66a     	ldp	x10, x9, [x19, #0x8]
    a054: f9000bea     	str	x10, [sp, #0x10]
    a058: f90013e9     	str	x9, [sp, #0x20]
    a05c: a9005274     	stp	x20, x20, [x19]
    a060: f9000a75     	str	x21, [x19, #0x10]
    a064: b4001137     	cbz	x23, 0xa288 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x304>
    a068: d100051c     	sub	x28, x8, #0x1
    a06c: 52802216     	mov	w22, #0x110             ; =272
    a070: 9100c3fa     	add	x26, sp, #0x30
    a074: 14000003     	b	0xa080 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xfc>
    a078: f94017f7     	ldr	x23, [sp, #0x28]
    a07c: b4001077     	cbz	x23, 0xa288 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x304>
    a080: d10006f7     	sub	x23, x23, #0x1
    a084: f90017f7     	str	x23, [sp, #0x28]
    a088: f94013e8     	ldr	x8, [sp, #0x20]
    a08c: 9b1622e8     	madd	x8, x23, x22, x8
    a090: b9400109     	ldr	w9, [x8]
    a094: 7100053f     	cmp	w9, #0x1
    a098: 54ffff09     	b.ls	0xa078 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xf4>
    a09c: f9408509     	ldr	x9, [x8, #0x108]
    a0a0: 3cc08100     	ldur	q0, [x8, #0x8]
    a0a4: 3c8383e0     	stur	q0, [sp, #0x38]
    a0a8: 3cc18100     	ldur	q0, [x8, #0x18]
    a0ac: 3c8483e0     	stur	q0, [sp, #0x48]
    a0b0: 3cc28100     	ldur	q0, [x8, #0x28]
    a0b4: 3c8583e0     	stur	q0, [sp, #0x58]
    a0b8: 3cc38100     	ldur	q0, [x8, #0x38]
    a0bc: 3c8683e0     	stur	q0, [sp, #0x68]
    a0c0: 3cc48100     	ldur	q0, [x8, #0x48]
    a0c4: 3c8783e0     	stur	q0, [sp, #0x78]
    a0c8: 3cc58100     	ldur	q0, [x8, #0x58]
    a0cc: 3c8883e0     	stur	q0, [sp, #0x88]
    a0d0: 3cc68100     	ldur	q0, [x8, #0x68]
    a0d4: 3c8983e0     	stur	q0, [sp, #0x98]
    a0d8: 3cc78100     	ldur	q0, [x8, #0x78]
    a0dc: 3c8a83e0     	stur	q0, [sp, #0xa8]
    a0e0: 3cc88100     	ldur	q0, [x8, #0x88]
    a0e4: 9100c3ea     	add	x10, sp, #0x30
    a0e8: 3c888140     	stur	q0, [x10, #0x88]
    a0ec: 3cc98100     	ldur	q0, [x8, #0x98]
    a0f0: 3c898140     	stur	q0, [x10, #0x98]
    a0f4: 3cca8100     	ldur	q0, [x8, #0xa8]
    a0f8: 3c8a8140     	stur	q0, [x10, #0xa8]
    a0fc: 3ccb8100     	ldur	q0, [x8, #0xb8]
    a100: 3c8b8140     	stur	q0, [x10, #0xb8]
    a104: 3ccc8100     	ldur	q0, [x8, #0xc8]
    a108: 3c8c8140     	stur	q0, [x10, #0xc8]
    a10c: 3ccd8100     	ldur	q0, [x8, #0xd8]
    a110: 3c8d8140     	stur	q0, [x10, #0xd8]
    a114: 3cce8100     	ldur	q0, [x8, #0xe8]
    a118: 3c8e8140     	stur	q0, [x10, #0xe8]
    a11c: 3ccf8100     	ldur	q0, [x8, #0xf8]
    a120: 3c8f8140     	stur	q0, [x10, #0xf8]
    a124: f9009fe9     	str	x9, [sp, #0x138]
    a128: 52800028     	mov	w8, #0x1                ; =1
    a12c: f9001be8     	str	x8, [sp, #0x30]
    a130: b9401fe8     	ldr	w8, [sp, #0x1c]
    a134: 36000468     	tbz	w8, #0x0, 0xa1c0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x23c>
    a138: 5280003b     	mov	w27, #0x1               ; =1
    a13c: 14000013     	b	0xa188 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x204>
    a140: d1000778     	sub	x24, x27, #0x1
    a144: f9001bf8     	str	x24, [sp, #0x30]
    a148: 52802108     	mov	w8, #0x108              ; =264
    a14c: 9b086b77     	madd	x23, x27, x8, x26
    a150: f8500ee3     	ldr	x3, [x23, #-0x100]!
    a154: 910503e0     	add	x0, sp, #0x140
    a158: 910022e4     	add	x4, x23, #0x8
    a15c: aa1303e1     	mov	x1, x19
    a160: 94000000     	bl	0xa160 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x1dc>
    a164: b94143e8     	ldr	w8, [sp, #0x140]
    a168: 34000268     	cbz	w8, 0xa1b4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x230>
    a16c: 910503e8     	add	x8, sp, #0x140
    a170: 91002101     	add	x1, x8, #0x8
    a174: aa1703e0     	mov	x0, x23
    a178: 52802102     	mov	w2, #0x108              ; =264
    a17c: 94000000     	bl	0xa17c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x1f8>
    a180: f9001bfb     	str	x27, [sp, #0x30]
    a184: b4fff7bb     	cbz	x27, 0xa078 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xf4>
    a188: d2800002     	mov	x2, #0x0                ; =0
    a18c: aa1403e8     	mov	x8, x20
    a190: 9b167c49     	mul	x9, x2, x22
    a194: b8696aa9     	ldr	w9, [x21, x9]
    a198: 7100093f     	cmp	w9, #0x2
    a19c: 54fffd23     	b.lo	0xa140 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x1bc>
    a1a0: eb1c005f     	cmp	x2, x28
    a1a4: 9a8227e2     	csinc	x2, xzr, x2, hs
    a1a8: f1000508     	subs	x8, x8, #0x1
    a1ac: 54ffff21     	b.ne	0xa190 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x20c>
    a1b0: 17fffff5     	b	0xa184 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x200>
    a1b4: aa1803fb     	mov	x27, x24
    a1b8: b5fffe98     	cbnz	x24, 0xa188 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x204>
    a1bc: 17ffffaf     	b	0xa078 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xf4>
    a1c0: 52800038     	mov	w24, #0x1               ; =1
    a1c4: 14000013     	b	0xa210 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x28c>
    a1c8: d100071b     	sub	x27, x24, #0x1
    a1cc: f9001bfb     	str	x27, [sp, #0x30]
    a1d0: 52802108     	mov	w8, #0x108              ; =264
    a1d4: 9b086b17     	madd	x23, x24, x8, x26
    a1d8: f8500ee3     	ldr	x3, [x23, #-0x100]!
    a1dc: 910503e0     	add	x0, sp, #0x140
    a1e0: 910022e4     	add	x4, x23, #0x8
    a1e4: aa1303e1     	mov	x1, x19
    a1e8: 94000000     	bl	0xa1e8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x264>
    a1ec: b94143e8     	ldr	w8, [sp, #0x140]
    a1f0: 34000468     	cbz	w8, 0xa27c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x2f8>
    a1f4: 910503e8     	add	x8, sp, #0x140
    a1f8: 91002101     	add	x1, x8, #0x8
    a1fc: aa1703e0     	mov	x0, x23
    a200: 52802102     	mov	w2, #0x108              ; =264
    a204: 94000000     	bl	0xa204 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x280>
    a208: f9001bf8     	str	x24, [sp, #0x30]
    a20c: b4fff378     	cbz	x24, 0xa078 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xf4>
    a210: f9401fe8     	ldr	x8, [sp, #0x38]
    a214: ca190108     	eor	x8, x8, x25
    a218: ca487908     	eor	x8, x8, x8, lsr #30
    a21c: d29cb729     	mov	x9, #0xe5b9             ; =58809
    a220: f2a39c89     	movk	x9, #0x1ce4, lsl #16
    a224: f2c8eda9     	movk	x9, #0x476d, lsl #32
    a228: f2f7eb09     	movk	x9, #0xbf58, lsl #48
    a22c: 9b097d08     	mul	x8, x8, x9
    a230: ca486d08     	eor	x8, x8, x8, lsr #27
    a234: d2823d69     	mov	x9, #0x11eb             ; =4587
    a238: f2a26629     	movk	x9, #0x1331, lsl #16
    a23c: f2c93769     	movk	x9, #0x49bb, lsl #32
    a240: f2f29a09     	movk	x9, #0x94d0, lsl #48
    a244: 9b097d08     	mul	x8, x8, x9
    a248: ca487d08     	eor	x8, x8, x8, lsr #31
    a24c: 9ad40909     	udiv	x9, x8, x20
    a250: 9b14a122     	msub	x2, x9, x20, x8
    a254: aa1403e8     	mov	x8, x20
    a258: 9b167c49     	mul	x9, x2, x22
    a25c: b8696aa9     	ldr	w9, [x21, x9]
    a260: 7100053f     	cmp	w9, #0x1
    a264: 54fffb29     	b.ls	0xa1c8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x244>
    a268: eb1c005f     	cmp	x2, x28
    a26c: 9a8227e2     	csinc	x2, xzr, x2, hs
    a270: f1000508     	subs	x8, x8, #0x1
    a274: 54ffff21     	b.ne	0xa258 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x2d4>
    a278: 17ffffe5     	b	0xa20c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x288>
    a27c: aa1b03f8     	mov	x24, x27
    a280: b5fffc9b     	cbnz	x27, 0xa210 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x28c>
    a284: 17ffff7d     	b	0xa078 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0xf4>
    a288: f9400be8     	ldr	x8, [sp, #0x10]
    a28c: b4000068     	cbz	x8, 0xa298 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x314>
    a290: f94013e0     	ldr	x0, [sp, #0x20]
    a294: 94000000     	bl	0xa294 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x310>
    a298: 52800000     	mov	w0, #0x0                ; =0
    a29c: f900127f     	str	xzr, [x19, #0x20]
    a2a0: 17ffff48     	b	0x9fc0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x3c>
    a2a4: 52800000     	mov	w0, #0x0                ; =0
    a2a8: 17ffff46     	b	0x9fc0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x3c>
    a2ac: 94000000     	bl	0xa2ac <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x328>

