000000000000a548 <_wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3>:
    a548: f9400828     	ldr	x8, [x1, #0x10]
    a54c: 52800309     	mov	w9, #0x18               ; =24
    a550: 9b092049     	madd	x9, x2, x9, x8
    a554: b9400128     	ldr	w8, [x9]
    a558: 3cc08120     	ldur	q0, [x9, #0x8]
    a55c: 5280004a     	mov	w10, #0x2               ; =2
    a560: b900012a     	str	w10, [x9]
    a564: a9009123     	stp	x3, x4, [x9, #0x8]
    a568: 34000068     	cbz	w8, 0xa574 <_wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3+0x2c>
    a56c: 7100051f     	cmp	w8, #0x1
    a570: 54000081     	b.ne	0xa580 <_wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3+0x38>
    a574: a9007c1f     	stp	xzr, xzr, [x0]
    a578: f900081f     	str	xzr, [x0, #0x10]
    a57c: d65f03c0     	ret
    a580: f900001f     	str	xzr, [x0]
    a584: 52800028     	mov	w8, #0x1                ; =1
    a588: b9000008     	str	w8, [x0]
    a58c: 3c808000     	stur	q0, [x0, #0x8]
    a590: d65f03c0     	ret


000000000000a608 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449>:
    a608: 6dbc3bef     	stp	d15, d14, [sp, #-0x40]!
    a60c: 6d0133ed     	stp	d13, d12, [sp, #0x10]
    a610: 6d022beb     	stp	d11, d10, [sp, #0x20]
    a614: 6d0323e9     	stp	d9, d8, [sp, #0x30]
    a618: f9400828     	ldr	x8, [x1, #0x10]
    a61c: 52802209     	mov	w9, #0x110              ; =272
    a620: 9b09204a     	madd	x10, x2, x9, x8
    a624: b9400149     	ldr	w9, [x10]
    a628: 3cc08140     	ldur	q0, [x10, #0x8]
    a62c: 3cc18141     	ldur	q1, [x10, #0x18]
    a630: 3cc28142     	ldur	q2, [x10, #0x28]
    a634: 3cc38143     	ldur	q3, [x10, #0x38]
    a638: 3cc48144     	ldur	q4, [x10, #0x48]
    a63c: 3cc58145     	ldur	q5, [x10, #0x58]
    a640: 3cc68146     	ldur	q6, [x10, #0x68]
    a644: 3cc78147     	ldur	q7, [x10, #0x78]
    a648: 3cc88150     	ldur	q16, [x10, #0x88]
    a64c: 3cc98151     	ldur	q17, [x10, #0x98]
    a650: 3cca8152     	ldur	q18, [x10, #0xa8]
    a654: 3ccb8153     	ldur	q19, [x10, #0xb8]
    a658: 3ccc8154     	ldur	q20, [x10, #0xc8]
    a65c: 3ccd8155     	ldur	q21, [x10, #0xd8]
    a660: 3cce8156     	ldur	q22, [x10, #0xe8]
    a664: 3ccf8157     	ldur	q23, [x10, #0xf8]
    a668: f9408548     	ldr	x8, [x10, #0x108]
    a66c: ad406498     	ldp	q24, q25, [x4]
    a670: ad416c9a     	ldp	q26, q27, [x4, #0x20]
    a674: ad42749c     	ldp	q28, q29, [x4, #0x40]
    a678: ad437c9e     	ldp	q30, q31, [x4, #0x60]
    a67c: ad442488     	ldp	q8, q9, [x4, #0x80]
    a680: ad452c8a     	ldp	q10, q11, [x4, #0xa0]
    a684: ad46348c     	ldp	q12, q13, [x4, #0xc0]
    a688: ad473c8e     	ldp	q14, q15, [x4, #0xe0]
    a68c: 5280004b     	mov	w11, #0x2               ; =2
    a690: b900014b     	str	w11, [x10]
    a694: f9000543     	str	x3, [x10, #0x8]
    a698: ad00e558     	stp	q24, q25, [x10, #0x10]
    a69c: ad01ed5a     	stp	q26, q27, [x10, #0x30]
    a6a0: ad02f55c     	stp	q28, q29, [x10, #0x50]
    a6a4: ad03fd5e     	stp	q30, q31, [x10, #0x70]
    a6a8: ad04a548     	stp	q8, q9, [x10, #0x90]
    a6ac: ad05ad4a     	stp	q10, q11, [x10, #0xb0]
    a6b0: ad06b54c     	stp	q12, q13, [x10, #0xd0]
    a6b4: ad07bd4e     	stp	q14, q15, [x10, #0xf0]
    a6b8: 34000069     	cbz	w9, 0xa6c4 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449+0xbc>
    a6bc: 7100053f     	cmp	w9, #0x1
    a6c0: 54000201     	b.ne	0xa700 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449+0xf8>
    a6c4: 6f00e400     	movi.2d	v0, #0000000000000000
    a6c8: ad078000     	stp	q0, q0, [x0, #0xf0]
    a6cc: ad068000     	stp	q0, q0, [x0, #0xd0]
    a6d0: ad058000     	stp	q0, q0, [x0, #0xb0]
    a6d4: ad048000     	stp	q0, q0, [x0, #0x90]
    a6d8: ad038000     	stp	q0, q0, [x0, #0x70]
    a6dc: ad028000     	stp	q0, q0, [x0, #0x50]
    a6e0: ad018000     	stp	q0, q0, [x0, #0x30]
    a6e4: ad008000     	stp	q0, q0, [x0, #0x10]
    a6e8: 3d800000     	str	q0, [x0]
    a6ec: 6d4323e9     	ldp	d9, d8, [sp, #0x30]
    a6f0: 6d422beb     	ldp	d11, d10, [sp, #0x20]
    a6f4: 6d4133ed     	ldp	d13, d12, [sp, #0x10]
    a6f8: 6cc43bef     	ldp	d15, d14, [sp], #0x40
    a6fc: d65f03c0     	ret
    a700: f900001f     	str	xzr, [x0]
    a704: 52800029     	mov	w9, #0x1                ; =1
    a708: b9000009     	str	w9, [x0]
    a70c: 3c808000     	stur	q0, [x0, #0x8]
    a710: 3c818001     	stur	q1, [x0, #0x18]
    a714: 3c828002     	stur	q2, [x0, #0x28]
    a718: 3c838003     	stur	q3, [x0, #0x38]
    a71c: 3c848004     	stur	q4, [x0, #0x48]
    a720: 3c858005     	stur	q5, [x0, #0x58]
    a724: 3c868006     	stur	q6, [x0, #0x68]
    a728: 3c878007     	stur	q7, [x0, #0x78]
    a72c: 3c888010     	stur	q16, [x0, #0x88]
    a730: 3c898011     	stur	q17, [x0, #0x98]
    a734: 3c8a8012     	stur	q18, [x0, #0xa8]
    a738: 3c8b8013     	stur	q19, [x0, #0xb8]
    a73c: 3c8c8014     	stur	q20, [x0, #0xc8]
    a740: 3c8d8015     	stur	q21, [x0, #0xd8]
    a744: 3c8e8016     	stur	q22, [x0, #0xe8]
    a748: 3c8f8017     	stur	q23, [x0, #0xf8]
    a74c: f9008408     	str	x8, [x0, #0x108]
    a750: 6d4323e9     	ldp	d9, d8, [sp, #0x30]
    a754: 6d422beb     	ldp	d11, d10, [sp, #0x20]
    a758: 6d4133ed     	ldp	d13, d12, [sp, #0x10]
    a75c: 6cc43bef     	ldp	d15, d14, [sp], #0x40
    a760: d65f03c0     	ret

