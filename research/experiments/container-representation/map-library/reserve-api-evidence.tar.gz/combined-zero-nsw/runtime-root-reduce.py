from pathlib import Path
import csv, json, statistics, re, hashlib
from collections import defaultdict
P=Path(__file__).resolve().parent
labels=['control0','candidate0','candidate1','control1']
peers=['whitefoot-hash-map','rust-hash-map','cpp-unordered-map']
data=defaultdict(lambda:defaultdict(list)); validity=defaultdict(dict); hierarchy_count=0;total_rows=0;run_summary={}
for label in labels:
 rows=list(csv.DictReader((P/f'runtime-{label}.csv').open()));assert len(rows)==84240
 err=(P/f'runtime-{label}.stderr').read_text(); clocks=list(map(int,re.findall(r'^\d+,(\d+)$',err,re.M)));assert len(clocks)==1024
 clock=int(re.search(r'maximum_empty_ns=(\d+)',err)[1]);assert max(clocks)==clock
 quantum=int(re.search(r'minimum_nonzero_ns=(\d+)',err)[1]);assert 0<quantum<=100
 status=json.loads((P/f'runtime-{label}-status.json').read_text());assert status['exit'] in (0,1) and not status['timed_out']
 groups=defaultdict(list)
 for row in rows:
  cell=(int(row['element_bytes']),row['series'],row['path'],int(row['initial_floor']))
  groups[(cell,row['variant'],int(row['sample']),int(row['control']))].append(row)
 for (cell,peer,sample,control),rs in groups.items():
  ag=[x for x in rs if x['row_kind']=='sample'];bs=[x for x in rs if x['row_kind']=='batch'];assert len(ag)==1
  a=ag[0];size=cell[-1];grow=cell[2]=='grow';ctx=256 if size==64 else 8;calls=(65536 if size==64 else 1024) if grow else 4194304;nb=calls//ctx if grow else 1
  assert len(bs)==nb and int(a['calls'])==calls and int(a['batch_or_batches'])==nb
  assert sorted(int(x['batch_or_batches']) for x in bs)==list(range(nb))
  assert sum(int(x['elapsed_ns']) for x in bs)==int(a['elapsed_ns'])
  assert sum(int(x['receipt']) for x in bs)%(1<<64)==int(a['receipt'])
  xor=0
  for x in bs:
   assert int(x['calls'])==(ctx if grow else calls)
   xor^=int(x['cleanup_checksum'])
  assert xor==int(a['cleanup_checksum'])
  for x in rs:
   assert int(x['cohort'])==int(label[-1]) and int(x['contexts'])==ctx and int(x['initial_count'])==size//2
   assert int(x['target_floor'])==(2*size if grow else size)
  if not control:
   valid=int(a['elapsed_ns'])>=1000000
   for b in bs:
    good=int(b['elapsed_ns'])//100>=clock
    assert bool(int(b['instrument_valid']))==good
    assert int(b['receipt'])==int(b['calls'])
    valid &= good
   assert bool(int(a['instrument_valid']))==valid
   key=label+'/'+peer;data[cell][key].append(int(a['elapsed_ns'])/calls)
   validity[cell][key]=validity[cell].get(key,True) and valid
  hierarchy_count+=1
 total_rows+=len(rows);run_summary[label]={'rows':len(rows),'exit':status['exit'],'clock_max_ns':clock,'quantum_ns':quantum,'sha256':hashlib.sha256((P/f'runtime-{label}.csv').read_bytes()).hexdigest()}
spread=lambda a,b:max(a,b)/min(a,b)-1
out=[]
for cell,ss in sorted(data.items()):
 samples={}
 for k,v in ss.items():
  assert len(v)==9
  samples[k]={'median_ns':statistics.median(v),'min_ns':min(v),'max_ns':max(v),'instrument':validity[cell][k]}
 median=lambda a,c,p:samples[a+str(c)+'/'+p]['median_ns']
 issues=[]
 for arm in ('control','candidate'):
  for peer in peers:
   if not all(validity[cell][arm+str(c)+'/'+peer] for c in (0,1)):issues.append(arm+'/'+peer+':instrument')
   if spread(median(arm,0,peer),median(arm,1,peer))>.1:issues.append(arm+'/'+peer+':cohort-drift')
 for c in (0,1):
  for peer in peers[1:]:
   if spread(median('control',c,peer),median('candidate',c,peer))>.1:issues.append('cohort'+str(c)+'/'+peer+':paired-drift')
 ratios=[median('candidate',c,peers[0])/median('control',c,peers[0]) for c in (0,1)]
 if spread(*ratios)>.1:issues.append('wf-ratio-drift')
 gain=all(samples['candidate'+str(c)+'/'+peers[0]]['max_ns']<samples['control'+str(c)+'/'+peers[0]]['min_ns'] for c in (0,1))
 loss=all(samples['candidate'+str(c)+'/'+peers[0]]['min_ns']>samples['control'+str(c)+'/'+peers[0]]['max_ns'] for c in (0,1))
 verdict='unqualified' if issues else 'gain' if gain else 'loss' if loss else 'overlap'
 out.append({'cell':cell,'samples':samples,'ratios':ratios,'issues':issues,'gain_ranges':gain,'loss_ranges':loss,'verdict':verdict})
result={'rows':total_rows,'hierarchy_checks':hierarchy_count,'runs':run_summary,'cells':out}
(P/'runtime-root-reduction.json').write_text(json.dumps(result,indent=2)+'\n')
print('rows',total_rows,'hierarchies',hierarchy_count)
for c in out:
 print(c['cell'],c['verdict'],'ratios',c['ratios'],'issues',c['issues'])
 if c['cell'][0]==256 and c['cell'][1]=='aligned-hash' and c['cell'][2]=='grow':
  for k,v in c['samples'].items():print(' ',k,v)
