00000001000a7cac <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e>:
1000a7cac:     	ldrb	w8, [x4, #0x8]
1000a7cb0:     	tbz	w8, #0x0, 0x1000a7cd8 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x2c>
1000a7cb4:     	mov	x9, #0x0                ; =0
1000a7cb8:     	ldr	x8, [x1]
1000a7cbc:     	cbz	x8, 0x1000a7d1c <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x70>
1000a7cc0:     	sub	x10, x8, #0x1
1000a7cc4:     	tst	x8, x10
1000a7cc8:     	b.eq	0x1000a7d24 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x78>
1000a7ccc:     	udiv	x10, x9, x8
1000a7cd0:     	msub	x10, x10, x8, x9
1000a7cd4:     	b	0x1000a7d28 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x7c>
1000a7cd8:     	ldr	x8, [x4]
1000a7cdc:     	eor	x8, x8, x2
1000a7ce0:     	eor	x8, x8, x8, lsr #30
1000a7ce4:     	mov	x9, #0xe5b9             ; =58809
1000a7ce8:     	movk	x9, #0x1ce4, lsl #16
1000a7cec:     	movk	x9, #0x476d, lsl #32
1000a7cf0:     	movk	x9, #0xbf58, lsl #48
1000a7cf4:     	mul	x8, x8, x9
1000a7cf8:     	eor	x8, x8, x8, lsr #27
1000a7cfc:     	mov	x9, #0x11eb             ; =4587
1000a7d00:     	movk	x9, #0x1331, lsl #16
1000a7d04:     	movk	x9, #0x49bb, lsl #32
1000a7d08:     	movk	x9, #0x94d0, lsl #48
1000a7d0c:     	mul	x8, x8, x9
1000a7d10:     	eor	x9, x8, x8, lsr #31
1000a7d14:     	ldr	x8, [x1]
1000a7d18:     	cbnz	x8, 0x1000a7cc0 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x14>
1000a7d1c:     	mov	x9, #0x0                ; =0
1000a7d20:     	b	0x1000a7da4 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0xf8>
1000a7d24:     	and	x10, x10, x9
1000a7d28:     	ldr	x11, [x1, #0x10]
1000a7d2c:     	mov	w12, #0x18              ; =24
1000a7d30:     	mov	x13, x8
1000a7d34:     	mov	x9, x8
1000a7d38:     	b	0x1000a7d58 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0xac>
1000a7d3c:     	cmp	x9, x8
1000a7d40:     	csel	x9, x10, x9, eq
1000a7d44:     	add	x14, x10, #0x1
1000a7d48:     	cmp	x14, x8
1000a7d4c:     	csinc	x10, xzr, x10, hs
1000a7d50:     	subs	x13, x13, #0x1
1000a7d54:     	b.eq	0x1000a7da4 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0xf8>
1000a7d58:     	madd	x14, x10, x12, x11
1000a7d5c:     	ldr	w15, [x14]
1000a7d60:     	cmp	w15, #0x1
1000a7d64:     	b.eq	0x1000a7d3c <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x90>
1000a7d68:     	cmp	w15, #0x2
1000a7d6c:     	b.ne	0x1000a7d9c <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0xf0>
1000a7d70:     	ldr	x15, [x14, #0x8]
1000a7d74:     	cmp	x15, x2
1000a7d78:     	b.ne	0x1000a7d44 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x98>
1000a7d7c:     	ldr	x8, [x14, #0x10]
1000a7d80:     	mov	w9, #0x2                ; =2
1000a7d84:     	str	w9, [x14]
1000a7d88:     	str	x3, [x14, #0x10]
1000a7d8c:     	mov	w9, #0x1                ; =1
1000a7d90:     	stp	x9, x2, [x0]
1000a7d94:     	str	x8, [x0, #0x10]
1000a7d98:     	ret
1000a7d9c:     	cmp	x9, x8
1000a7da0:     	csel	x9, x10, x9, eq
1000a7da4:     	cmp	x9, x8
1000a7da8:     	b.hs	0x1000a7e00 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x154>
1000a7dac:     	ldr	x8, [x1, #0x18]
1000a7db0:     	lsr	x10, x8, #13
1000a7db4:     	cbnz	x10, 0x1000a7e00 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x154>
1000a7db8:     	add	x8, x8, #0x1
1000a7dbc:     	str	x8, [x1, #0x18]
1000a7dc0:     	ldr	x8, [x1, #0x10]
1000a7dc4:     	mov	w10, #0x18              ; =24
1000a7dc8:     	madd	x8, x9, x10, x8
1000a7dcc:     	ldr	w9, [x8]
1000a7dd0:     	cmp	w9, #0x1
1000a7dd4:     	b.ne	0x1000a7e18 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x16c>
1000a7dd8:     	ldr	x9, [x1, #0x20]
1000a7ddc:     	subs	x9, x9, #0x1
1000a7de0:     	csel	x9, xzr, x9, lo
1000a7de4:     	str	x9, [x1, #0x20]
1000a7de8:     	mov	w9, #0x2                ; =2
1000a7dec:     	str	w9, [x8]
1000a7df0:     	stp	x2, x3, [x8, #0x8]
1000a7df4:     	stp	xzr, xzr, [x0, #0x8]
1000a7df8:     	str	xzr, [x0]
1000a7dfc:     	ret
1000a7e00:     	stp	xzr, x2, [x0]
1000a7e04:     	mov	w8, #0x1                ; =1
1000a7e08:     	str	w8, [x0]
1000a7e0c:     	strb	w8, [x0, #0x4]
1000a7e10:     	str	x3, [x0, #0x10]
1000a7e14:     	ret
1000a7e18:     	ldur	q0, [x8, #0x8]
1000a7e1c:     	mov	w10, #0x2               ; =2
1000a7e20:     	str	w10, [x8]
1000a7e24:     	stp	x2, x3, [x8, #0x8]
1000a7e28:     	cbz	w9, 0x1000a7e3c <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x190>
1000a7e2c:     	mov	w8, #0x1                ; =1
1000a7e30:     	str	x8, [x0]
1000a7e34:     	stur	q0, [x0, #0x8]
1000a7e38:     	ret
1000a7e3c:     	stp	xzr, xzr, [x0]
1000a7e40:     	str	xzr, [x0, #0x10]
1000a7e44:     	ret

