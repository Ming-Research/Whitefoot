00000001000a8220 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e>:
1000a8220:     	ldrb	w8, [x4, #0x8]
1000a8224:     	tbz	w8, #0x0, 0x1000a82b0 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x90>
1000a8228:     	mov	x9, #0x0                ; =0
1000a822c:     	ldr	x8, [x1]
1000a8230:     	cbz	x8, 0x1000a82f4 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0xd4>
1000a8234:     	udiv	x10, x9, x8
1000a8238:     	msub	x10, x10, x8, x9
1000a823c:     	ldr	x11, [x1, #0x10]
1000a8240:     	mov	w12, #0x18              ; =24
1000a8244:     	mov	x13, x8
1000a8248:     	mov	x9, x8
1000a824c:     	b	0x1000a826c <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x4c>
1000a8250:     	cmp	x9, x8
1000a8254:     	csel	x9, x10, x9, eq
1000a8258:     	add	x14, x10, #0x1
1000a825c:     	cmp	x14, x8
1000a8260:     	csinc	x10, xzr, x10, hs
1000a8264:     	subs	x13, x13, #0x1
1000a8268:     	b.eq	0x1000a82f8 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0xd8>
1000a826c:     	madd	x14, x10, x12, x11
1000a8270:     	ldr	w15, [x14]
1000a8274:     	cmp	w15, #0x1
1000a8278:     	b.eq	0x1000a8250 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x30>
1000a827c:     	cmp	w15, #0x2
1000a8280:     	b.ne	0x1000a8354 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x134>
1000a8284:     	ldr	x15, [x14, #0x8]
1000a8288:     	cmp	x15, x2
1000a828c:     	b.ne	0x1000a8258 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x38>
1000a8290:     	ldr	x8, [x14, #0x10]
1000a8294:     	mov	w9, #0x2                ; =2
1000a8298:     	str	w9, [x14]
1000a829c:     	str	x3, [x14, #0x10]
1000a82a0:     	mov	w9, #0x1                ; =1
1000a82a4:     	stp	x9, x2, [x0]
1000a82a8:     	str	x8, [x0, #0x10]
1000a82ac:     	ret
1000a82b0:     	ldr	x8, [x4]
1000a82b4:     	eor	x8, x8, x2
1000a82b8:     	eor	x8, x8, x8, lsr #30
1000a82bc:     	mov	x9, #0xe5b9             ; =58809
1000a82c0:     	movk	x9, #0x1ce4, lsl #16
1000a82c4:     	movk	x9, #0x476d, lsl #32
1000a82c8:     	movk	x9, #0xbf58, lsl #48
1000a82cc:     	mul	x8, x8, x9
1000a82d0:     	eor	x8, x8, x8, lsr #27
1000a82d4:     	mov	x9, #0x11eb             ; =4587
1000a82d8:     	movk	x9, #0x1331, lsl #16
1000a82dc:     	movk	x9, #0x49bb, lsl #32
1000a82e0:     	movk	x9, #0x94d0, lsl #48
1000a82e4:     	mul	x8, x8, x9
1000a82e8:     	eor	x9, x8, x8, lsr #31
1000a82ec:     	ldr	x8, [x1]
1000a82f0:     	cbnz	x8, 0x1000a8234 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x14>
1000a82f4:     	mov	x9, #0x0                ; =0
1000a82f8:     	cmp	x9, x8
1000a82fc:     	b.hs	0x1000a8364 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x144>
1000a8300:     	ldr	x8, [x1, #0x18]
1000a8304:     	lsr	x10, x8, #13
1000a8308:     	cbnz	x10, 0x1000a8364 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x144>
1000a830c:     	add	x8, x8, #0x1
1000a8310:     	str	x8, [x1, #0x18]
1000a8314:     	ldr	x8, [x1, #0x10]
1000a8318:     	mov	w10, #0x18              ; =24
1000a831c:     	madd	x8, x9, x10, x8
1000a8320:     	ldr	w9, [x8]
1000a8324:     	cmp	w9, #0x1
1000a8328:     	b.ne	0x1000a837c <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x15c>
1000a832c:     	ldr	x9, [x1, #0x20]
1000a8330:     	subs	x9, x9, #0x1
1000a8334:     	csel	x9, xzr, x9, lo
1000a8338:     	str	x9, [x1, #0x20]
1000a833c:     	mov	w9, #0x2                ; =2
1000a8340:     	str	w9, [x8]
1000a8344:     	stp	x2, x3, [x8, #0x8]
1000a8348:     	stp	xzr, xzr, [x0, #0x8]
1000a834c:     	str	xzr, [x0]
1000a8350:     	ret
1000a8354:     	cmp	x9, x8
1000a8358:     	csel	x9, x10, x9, eq
1000a835c:     	cmp	x9, x8
1000a8360:     	b.lo	0x1000a8300 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0xe0>
1000a8364:     	stp	xzr, x2, [x0]
1000a8368:     	mov	w8, #0x1                ; =1
1000a836c:     	str	w8, [x0]
1000a8370:     	strb	w8, [x0, #0x4]
1000a8374:     	str	x3, [x0, #0x10]
1000a8378:     	ret
1000a837c:     	ldur	q0, [x8, #0x8]
1000a8380:     	mov	w10, #0x2               ; =2
1000a8384:     	str	w10, [x8]
1000a8388:     	stp	x2, x3, [x8, #0x8]
1000a838c:     	cbz	w9, 0x1000a83a0 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x180>
1000a8390:     	mov	w8, #0x1                ; =1
1000a8394:     	str	x8, [x0]
1000a8398:     	stur	q0, [x0, #0x8]
1000a839c:     	ret
1000a83a0:     	stp	xzr, xzr, [x0]
1000a83a4:     	str	xzr, [x0, #0x10]
1000a83a8:     	ret

