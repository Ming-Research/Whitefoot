00000001000a4638 <_wf_flat_mutation_batch$instance$4250cb78d3f44027>:
1000a4638:     	stp	x28, x27, [sp, #-0x60]!
1000a463c:     	stp	x26, x25, [sp, #0x10]
1000a4640:     	stp	x24, x23, [sp, #0x20]
1000a4644:     	stp	x22, x21, [sp, #0x30]
1000a4648:     	stp	x20, x19, [sp, #0x40]
1000a464c:     	stp	x29, x30, [sp, #0x50]
1000a4650:     	sub	sp, sp, #0x3a0
1000a4654:     	ldr	x24, [x0, #0x38]
1000a4658:     	str	x1, [sp, #0x8]
1000a465c:     	cbz	x1, 0x1000a4bec <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x5b4>
1000a4660:     	mov	x19, x0
1000a4664:     	ldr	x26, [x0, #0x40]
1000a4668:     	cbz	x26, 0x1000a4bdc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x5a4>
1000a466c:     	mov	x21, x2
1000a4670:     	str	xzr, [sp, #0x18]
1000a4674:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xbbc>
1000a4678:     	ldr	q0, [x8, #0x3e0]
1000a467c:     	str	q0, [sp, #0x180]
1000a4680:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xbbc>
1000a4684:     	ldr	q0, [x8, #0x190]
1000a4688:     	str	q0, [sp, #0x170]
1000a468c:     	add	x27, sp, #0x2a0
1000a4690:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xbbc>
1000a4694:     	ldr	q0, [x8, #0x180]
1000a4698:     	str	q0, [sp, #0x160]
1000a469c:     	mov	w28, #0x1               ; =1
1000a46a0:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xbbc>
1000a46a4:     	ldr	q0, [x8, #0x1b0]
1000a46a8:     	str	q0, [sp, #0x150]
1000a46ac:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xbbc>
1000a46b0:     	ldr	q0, [x8, #0x1a0]
1000a46b4:     	str	q0, [sp, #0x140]
1000a46b8:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xbbc>
1000a46bc:     	ldr	q0, [x8, #0x1d0]
1000a46c0:     	str	q0, [sp, #0x130]
1000a46c4:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xbbc>
1000a46c8:     	ldr	q0, [x8, #0x1c0]
1000a46cc:     	str	q0, [sp, #0x120]
1000a46d0:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xbbc>
1000a46d4:     	ldr	q0, [x8, #0x1f0]
1000a46d8:     	str	q0, [sp, #0x110]
1000a46dc:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xbbc>
1000a46e0:     	ldr	q0, [x8, #0x1e0]
1000a46e4:     	str	q0, [sp, #0x100]
1000a46e8:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xbbc>
1000a46ec:     	ldr	q0, [x8, #0x210]
1000a46f0:     	str	q0, [sp, #0xf0]
1000a46f4:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xbbc>
1000a46f8:     	ldr	q0, [x8, #0x200]
1000a46fc:     	str	q0, [sp, #0xe0]
1000a4700:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xbbc>
1000a4704:     	ldr	q0, [x8, #0x230]
1000a4708:     	str	q0, [sp, #0xd0]
1000a470c:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xbbc>
1000a4710:     	ldr	q0, [x8, #0x220]
1000a4714:     	str	q0, [sp, #0xc0]
1000a4718:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xbbc>
1000a471c:     	ldr	q0, [x8, #0x250]
1000a4720:     	str	q0, [sp, #0xb0]
1000a4724:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xbbc>
1000a4728:     	ldr	q0, [x8, #0x240]
1000a472c:     	str	q0, [sp, #0xa0]
1000a4730:     	mov	w20, #0x83              ; =131
1000a4734:     	mov	w22, #0x110             ; =272
1000a4738:     	ldr	x10, [x19, #0x48]
1000a473c:     	add	x10, x10, #0x1
1000a4740:     	str	x10, [sp, #0x10]
1000a4744:     	cbz	x26, 0x1000a4bb0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x578>
1000a4748:     	mov	x23, #0x0               ; =0
1000a474c:     	ldr	x8, [x19, #0x38]
1000a4750:     	madd	x25, x10, x26, x8
1000a4754:     	b	0x1000a4860 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x228>
1000a4758:     	ldrb	w8, [sp, #0x194]
1000a475c:     	tst	w8, #0x1
1000a4760:     	ldp	x9, x8, [sp, #0x198]
1000a4764:     	madd	x8, x9, x20, x8
1000a4768:     	ldp	x10, x9, [sp, #0x1a8]
1000a476c:     	madd	x8, x8, x20, x10
1000a4770:     	madd	x8, x8, x20, x9
1000a4774:     	ldp	x10, x9, [sp, #0x1b8]
1000a4778:     	madd	x8, x8, x20, x10
1000a477c:     	madd	x8, x8, x20, x9
1000a4780:     	ldp	x10, x9, [sp, #0x1c8]
1000a4784:     	madd	x8, x8, x20, x10
1000a4788:     	madd	x8, x8, x20, x9
1000a478c:     	ldp	x10, x9, [sp, #0x1d8]
1000a4790:     	madd	x8, x8, x20, x10
1000a4794:     	madd	x8, x8, x20, x9
1000a4798:     	ldp	x10, x9, [sp, #0x1e8]
1000a479c:     	madd	x8, x8, x20, x10
1000a47a0:     	madd	x8, x8, x20, x9
1000a47a4:     	ldp	x10, x9, [sp, #0x1f8]
1000a47a8:     	madd	x8, x8, x20, x10
1000a47ac:     	madd	x8, x8, x20, x9
1000a47b0:     	ldr	x9, [sp, #0x208]
1000a47b4:     	madd	x8, x8, x20, x9
1000a47b8:     	ldr	x9, [sp, #0x210]
1000a47bc:     	madd	x8, x8, x20, x9
1000a47c0:     	ldr	x9, [sp, #0x218]
1000a47c4:     	madd	x8, x8, x20, x9
1000a47c8:     	ldr	x9, [sp, #0x220]
1000a47cc:     	madd	x8, x8, x20, x9
1000a47d0:     	ldr	x9, [sp, #0x228]
1000a47d4:     	madd	x8, x8, x20, x9
1000a47d8:     	ldr	x9, [sp, #0x230]
1000a47dc:     	madd	x8, x8, x20, x9
1000a47e0:     	ldr	x9, [sp, #0x238]
1000a47e4:     	madd	x8, x8, x20, x9
1000a47e8:     	ldr	x9, [sp, #0x240]
1000a47ec:     	madd	x8, x8, x20, x9
1000a47f0:     	ldr	x9, [sp, #0x248]
1000a47f4:     	madd	x8, x8, x20, x9
1000a47f8:     	ldr	x9, [sp, #0x250]
1000a47fc:     	madd	x8, x8, x20, x9
1000a4800:     	ldr	x9, [sp, #0x258]
1000a4804:     	madd	x8, x8, x20, x9
1000a4808:     	ldr	x9, [sp, #0x260]
1000a480c:     	madd	x8, x8, x20, x9
1000a4810:     	ldr	x9, [sp, #0x268]
1000a4814:     	madd	x8, x8, x20, x9
1000a4818:     	ldr	x9, [sp, #0x270]
1000a481c:     	madd	x8, x8, x20, x9
1000a4820:     	ldr	x9, [sp, #0x278]
1000a4824:     	madd	x8, x8, x20, x9
1000a4828:     	ldr	x9, [sp, #0x280]
1000a482c:     	madd	x8, x8, x20, x9
1000a4830:     	ldr	x9, [sp, #0x288]
1000a4834:     	add	x9, x9, x24
1000a4838:     	ldr	x10, [sp, #0x290]
1000a483c:     	madd	x8, x8, x20, x9
1000a4840:     	cinc	x9, x28, ne
1000a4844:     	add	x9, x9, x10
1000a4848:     	madd	x8, x8, x20, x9
1000a484c:     	ldr	x9, [sp, #0x298]
1000a4850:     	madd	x24, x8, x20, x9
1000a4854:     	add	x23, x23, #0x1
1000a4858:     	cmp	x23, x26
1000a485c:     	b.eq	0x1000a4bb0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x578>
1000a4860:     	orr	x2, x28, x23, lsl #1
1000a4864:     	cbz	x21, 0x1000a4abc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x484>
1000a4868:     	ldr	x8, [x19, #0x18]
1000a486c:     	cbz	x8, 0x1000a4ab8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x480>
1000a4870:     	ldrb	w9, [x19, #0x30]
1000a4874:     	tbz	w9, #0x0, 0x1000a4888 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x250>
1000a4878:     	mov	x9, #0x0                ; =0
1000a487c:     	ldr	x10, [x19]
1000a4880:     	cbnz	x10, 0x1000a48cc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x294>
1000a4884:     	b	0x1000a4ab8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x480>
1000a4888:     	ldr	x9, [x19, #0x28]
1000a488c:     	eor	x9, x9, x2
1000a4890:     	eor	x9, x9, x9, lsr #30
1000a4894:     	mov	x10, #0xe5b9            ; =58809
1000a4898:     	movk	x10, #0x1ce4, lsl #16
1000a489c:     	movk	x10, #0x476d, lsl #32
1000a48a0:     	movk	x10, #0xbf58, lsl #48
1000a48a4:     	mul	x9, x9, x10
1000a48a8:     	eor	x9, x9, x9, lsr #27
1000a48ac:     	mov	x10, #0x11eb            ; =4587
1000a48b0:     	movk	x10, #0x1331, lsl #16
1000a48b4:     	movk	x10, #0x49bb, lsl #32
1000a48b8:     	movk	x10, #0x94d0, lsl #48
1000a48bc:     	mul	x9, x9, x10
1000a48c0:     	eor	x9, x9, x9, lsr #31
1000a48c4:     	ldr	x10, [x19]
1000a48c8:     	cbz	x10, 0x1000a4ab8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x480>
1000a48cc:     	sub	x11, x10, #0x1
1000a48d0:     	tst	x10, x11
1000a48d4:     	b.eq	0x1000a48e4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2ac>
1000a48d8:     	udiv	x11, x9, x10
1000a48dc:     	msub	x11, x11, x10, x9
1000a48e0:     	b	0x1000a48e8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2b0>
1000a48e4:     	and	x11, x11, x9
1000a48e8:     	ldr	x12, [x19, #0x10]
1000a48ec:     	mov	x13, x10
1000a48f0:     	b	0x1000a4908 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2d0>
1000a48f4:     	add	x9, x11, #0x1
1000a48f8:     	cmp	x9, x10
1000a48fc:     	csinc	x11, xzr, x11, hs
1000a4900:     	subs	x13, x13, #0x1
1000a4904:     	b.eq	0x1000a4ab8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x480>
1000a4908:     	madd	x9, x11, x22, x12
1000a490c:     	ldr	w14, [x9]
1000a4910:     	cmp	w14, #0x1
1000a4914:     	b.eq	0x1000a48f4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2bc>
1000a4918:     	cmp	w14, #0x2
1000a491c:     	b.ne	0x1000a4ab8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x480>
1000a4920:     	ldr	x14, [x9, #0x8]
1000a4924:     	cmp	x14, x2
1000a4928:     	b.ne	0x1000a48f4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2bc>
1000a492c:     	ldp	x11, x10, [x9, #0x10]
1000a4930:     	stp	x10, x11, [sp, #0x90]
1000a4934:     	ldp	x11, x10, [x9, #0x20]
1000a4938:     	stp	x10, x11, [sp, #0x80]
1000a493c:     	ldp	x14, x15, [x9, #0x30]
1000a4940:     	ldp	x16, x17, [x9, #0x40]
1000a4944:     	ldp	x0, x1, [x9, #0x50]
1000a4948:     	ldp	x3, x4, [x9, #0x60]
1000a494c:     	ldp	x5, x6, [x9, #0x70]
1000a4950:     	ldp	x7, x30, [x9, #0x80]
1000a4954:     	ldp	x11, x10, [x9, #0x90]
1000a4958:     	stp	x10, x11, [sp, #0x70]
1000a495c:     	ldp	x11, x10, [x9, #0xa0]
1000a4960:     	stp	x10, x11, [sp, #0x60]
1000a4964:     	ldp	x11, x10, [x9, #0xb0]
1000a4968:     	stp	x10, x11, [sp, #0x50]
1000a496c:     	ldp	x11, x10, [x9, #0xc0]
1000a4970:     	stp	x10, x11, [sp, #0x40]
1000a4974:     	ldp	x11, x10, [x9, #0xd0]
1000a4978:     	stp	x10, x11, [sp, #0x30]
1000a497c:     	ldp	x11, x10, [x9, #0xe0]
1000a4980:     	stp	x10, x11, [sp, #0x20]
1000a4984:     	str	w28, [x9]
1000a4988:     	movi.2d	v0, #0000000000000000
1000a498c:     	stur	q0, [x9, #0x8]
1000a4990:     	stur	q0, [x9, #0x18]
1000a4994:     	stur	q0, [x9, #0x28]
1000a4998:     	stur	q0, [x9, #0x38]
1000a499c:     	stur	q0, [x9, #0x48]
1000a49a0:     	stur	q0, [x9, #0x58]
1000a49a4:     	stur	q0, [x9, #0x68]
1000a49a8:     	stur	q0, [x9, #0x78]
1000a49ac:     	stur	q0, [x9, #0x88]
1000a49b0:     	stur	q0, [x9, #0x98]
1000a49b4:     	stur	q0, [x9, #0xa8]
1000a49b8:     	stur	q0, [x9, #0xb8]
1000a49bc:     	stur	q0, [x9, #0xc8]
1000a49c0:     	stur	q0, [x9, #0xd8]
1000a49c4:     	ldp	x12, x13, [x9, #0xf0]
1000a49c8:     	stur	q0, [x9, #0xe8]
1000a49cc:     	ldp	x10, x11, [x9, #0x100]
1000a49d0:     	stur	q0, [x9, #0xf8]
1000a49d4:     	str	xzr, [x9, #0x108]
1000a49d8:     	sub	x8, x8, #0x1
1000a49dc:     	ldr	x9, [x19, #0x20]
1000a49e0:     	adds	x9, x9, #0x1
1000a49e4:     	csinv	x9, x9, xzr, lo
1000a49e8:     	stp	x8, x9, [x19, #0x18]
1000a49ec:     	ldp	x9, x8, [sp, #0x90]
1000a49f0:     	madd	x8, x2, x20, x8
1000a49f4:     	madd	x8, x8, x20, x9
1000a49f8:     	ldr	x9, [sp, #0x88]
1000a49fc:     	madd	x8, x8, x20, x9
1000a4a00:     	ldr	x9, [sp, #0x80]
1000a4a04:     	madd	x8, x8, x20, x9
1000a4a08:     	madd	x8, x8, x20, x14
1000a4a0c:     	madd	x8, x8, x20, x15
1000a4a10:     	madd	x8, x8, x20, x16
1000a4a14:     	madd	x8, x8, x20, x17
1000a4a18:     	madd	x8, x8, x20, x0
1000a4a1c:     	madd	x8, x8, x20, x1
1000a4a20:     	madd	x8, x8, x20, x3
1000a4a24:     	madd	x8, x8, x20, x4
1000a4a28:     	madd	x8, x8, x20, x5
1000a4a2c:     	madd	x8, x8, x20, x6
1000a4a30:     	madd	x8, x8, x20, x7
1000a4a34:     	madd	x8, x8, x20, x30
1000a4a38:     	ldr	x9, [sp, #0x78]
1000a4a3c:     	madd	x8, x8, x20, x9
1000a4a40:     	ldr	x9, [sp, #0x70]
1000a4a44:     	madd	x8, x8, x20, x9
1000a4a48:     	ldr	x9, [sp, #0x68]
1000a4a4c:     	madd	x8, x8, x20, x9
1000a4a50:     	ldr	x9, [sp, #0x60]
1000a4a54:     	madd	x8, x8, x20, x9
1000a4a58:     	ldr	x9, [sp, #0x58]
1000a4a5c:     	madd	x8, x8, x20, x9
1000a4a60:     	ldr	x9, [sp, #0x50]
1000a4a64:     	madd	x8, x8, x20, x9
1000a4a68:     	ldr	x9, [sp, #0x48]
1000a4a6c:     	madd	x8, x8, x20, x9
1000a4a70:     	ldr	x9, [sp, #0x40]
1000a4a74:     	madd	x8, x8, x20, x9
1000a4a78:     	ldr	x9, [sp, #0x38]
1000a4a7c:     	madd	x8, x8, x20, x9
1000a4a80:     	ldr	x9, [sp, #0x30]
1000a4a84:     	madd	x8, x8, x20, x9
1000a4a88:     	ldr	x9, [sp, #0x28]
1000a4a8c:     	madd	x8, x8, x20, x9
1000a4a90:     	ldr	x9, [sp, #0x20]
1000a4a94:     	madd	x8, x8, x20, x9
1000a4a98:     	madd	x8, x8, x20, x12
1000a4a9c:     	madd	x8, x8, x20, x13
1000a4aa0:     	madd	x8, x8, x20, x10
1000a4aa4:     	mov	w9, #0x4309             ; =17161
1000a4aa8:     	madd	x9, x24, x9, x11
1000a4aac:     	madd	x8, x8, x20, x9
1000a4ab0:     	add	x24, x8, #0x83
1000a4ab4:     	b	0x1000a4abc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x484>
1000a4ab8:     	mul	x24, x24, x20
1000a4abc:     	add	x8, x25, x23
1000a4ac0:     	dup.2d	v0, x8
1000a4ac4:     	ldr	q1, [sp, #0x180]
1000a4ac8:     	add.2d	v1, v0, v1
1000a4acc:     	stur	q1, [x27, #0x8]
1000a4ad0:     	add	x9, x8, #0x1f
1000a4ad4:     	ldr	q1, [sp, #0x170]
1000a4ad8:     	add.2d	v1, v0, v1
1000a4adc:     	stur	q1, [x27, #0x18]
1000a4ae0:     	ldr	q1, [sp, #0x160]
1000a4ae4:     	add.2d	v1, v0, v1
1000a4ae8:     	stur	q1, [x27, #0x28]
1000a4aec:     	ldr	q1, [sp, #0x150]
1000a4af0:     	add.2d	v1, v0, v1
1000a4af4:     	stur	q1, [x27, #0x38]
1000a4af8:     	ldr	q1, [sp, #0x140]
1000a4afc:     	add.2d	v1, v0, v1
1000a4b00:     	stur	q1, [x27, #0x48]
1000a4b04:     	ldr	q1, [sp, #0x130]
1000a4b08:     	add.2d	v1, v0, v1
1000a4b0c:     	stur	q1, [x27, #0x58]
1000a4b10:     	ldr	q1, [sp, #0x120]
1000a4b14:     	add.2d	v1, v0, v1
1000a4b18:     	stur	q1, [x27, #0x68]
1000a4b1c:     	ldr	q1, [sp, #0x110]
1000a4b20:     	add.2d	v1, v0, v1
1000a4b24:     	stur	q1, [x27, #0x78]
1000a4b28:     	ldr	q1, [sp, #0x100]
1000a4b2c:     	add.2d	v1, v0, v1
1000a4b30:     	stur	q1, [x27, #0x88]
1000a4b34:     	ldr	q1, [sp, #0xf0]
1000a4b38:     	add.2d	v1, v0, v1
1000a4b3c:     	stur	q1, [x27, #0x98]
1000a4b40:     	ldr	q1, [sp, #0xe0]
1000a4b44:     	add.2d	v1, v0, v1
1000a4b48:     	stur	q1, [x27, #0xa8]
1000a4b4c:     	ldr	q1, [sp, #0xd0]
1000a4b50:     	add.2d	v1, v0, v1
1000a4b54:     	stur	q1, [x27, #0xb8]
1000a4b58:     	ldr	q1, [sp, #0xc0]
1000a4b5c:     	add.2d	v1, v0, v1
1000a4b60:     	stur	q1, [x27, #0xc8]
1000a4b64:     	ldr	q1, [sp, #0xb0]
1000a4b68:     	add.2d	v1, v0, v1
1000a4b6c:     	stur	q1, [x27, #0xd8]
1000a4b70:     	ldr	q1, [sp, #0xa0]
1000a4b74:     	add.2d	v0, v0, v1
1000a4b78:     	stur	q0, [x27, #0xe8]
1000a4b7c:     	str	x8, [sp, #0x2a0]
1000a4b80:     	str	x9, [sp, #0x398]
1000a4b84:     	add	x0, sp, #0x190
1000a4b88:     	add	x3, sp, #0x2a0
1000a4b8c:     	add	x4, x19, #0x28
1000a4b90:     	mov	x1, x19
1000a4b94:     	bl	0x1000a8308 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d>
1000a4b98:     	ldr	w8, [sp, #0x190]
1000a4b9c:     	cbnz	w8, 0x1000a4758 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x120>
1000a4ba0:     	mul	x24, x24, x20
1000a4ba4:     	add	x23, x23, #0x1
1000a4ba8:     	cmp	x23, x26
1000a4bac:     	b.ne	0x1000a4860 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x228>
1000a4bb0:     	ldp	x10, x9, [sp, #0x10]
1000a4bb4:     	str	x10, [x19, #0x48]
1000a4bb8:     	add	x9, x9, #0x1
1000a4bbc:     	ldr	x8, [sp, #0x8]
1000a4bc0:     	cmp	x9, x8
1000a4bc4:     	b.eq	0x1000a4bec <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x5b4>
1000a4bc8:     	ldr	x26, [x19, #0x40]
1000a4bcc:     	add	x10, x10, #0x1
1000a4bd0:     	stp	x10, x9, [sp, #0x10]
1000a4bd4:     	cbnz	x26, 0x1000a4748 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x110>
1000a4bd8:     	b	0x1000a4bb0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x578>
1000a4bdc:     	ldr	x8, [x19, #0x48]
1000a4be0:     	ldr	x9, [sp, #0x8]
1000a4be4:     	add	x8, x8, x9
1000a4be8:     	str	x8, [x19, #0x48]
1000a4bec:     	eor	x8, x24, x24, lsr #30
1000a4bf0:     	mov	x9, #0xe5b9             ; =58809
1000a4bf4:     	movk	x9, #0x1ce4, lsl #16
1000a4bf8:     	movk	x9, #0x476d, lsl #32
1000a4bfc:     	movk	x9, #0xbf58, lsl #48
1000a4c00:     	mul	x8, x8, x9
1000a4c04:     	eor	x8, x8, x8, lsr #27
1000a4c08:     	mov	x9, #0x11eb             ; =4587
1000a4c0c:     	movk	x9, #0x1331, lsl #16
1000a4c10:     	movk	x9, #0x49bb, lsl #32
1000a4c14:     	movk	x9, #0x94d0, lsl #48
1000a4c18:     	mul	x8, x8, x9
1000a4c1c:     	eor	x0, x8, x8, lsr #31
1000a4c20:     	add	sp, sp, #0x3a0
1000a4c24:     	ldp	x29, x30, [sp, #0x50]
1000a4c28:     	ldp	x20, x19, [sp, #0x40]
1000a4c2c:     	ldp	x22, x21, [sp, #0x30]
1000a4c30:     	ldp	x24, x23, [sp, #0x20]
1000a4c34:     	ldp	x26, x25, [sp, #0x10]
1000a4c38:     	ldp	x28, x27, [sp], #0x60
1000a4c3c:     	ret

