#!/usr/bin/env python3
"""One-shot mutation home-mask experiment. Root runs under the host guard.
No timing mode; build stops for native review. Remove with the recorded trial.
"""
import argparse, difflib, hashlib, json, os, pathlib, shutil, signal, subprocess, time
ROOT = pathlib.Path('/private/tmp/whitefoot-container-recovery-20261001')
OUT = pathlib.Path('/private/tmp/whitefoot-mutation-home-mask')
D = ROOT / 'research/experiments/container-representation/map-library/.build/lookup-api/mutation-screen'
LIB = ROOT / 'lib/std/collections/hash_map/hash-map.wf'
SOURCE = ROOT / 'research/experiments/container-representation/map-library/.build/lookup-chain-probe/mutation-complete.wf'
BASE = pathlib.Path('/private/tmp/whitefoot-entry-forward-final-proof/whitefootc')
CAND = OUT / 'whitefootc-mask'
OBJDUMP = os.environ['LLVM_OBJDUMP']  # Measured instrument: LLVM22.1.8.
EXPECTED = '09cb4c4ea979d9dedb46dbc2bcb267d984d472777f0a69f4af86df68ede57b41'
def sha(path): return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def absolute(arg):
    p = pathlib.Path(arg)
    return p if p.is_absolute() else ROOT / p
parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=['prepare', 'build', 'check'])
mode = parser.parse_args().mode
links = {r['label'].split()[0]: r['command'] for r in json.loads(pathlib.Path('/private/tmp/whitefoot-entry-forward-images.json').read_text()) if r['label'].endswith(' link')}
if mode == 'prepare':
    original = (OUT / 'hash-map.original.wf').read_bytes()
    assert LIB.read_bytes() == original
    candidate = original.decode()
    for name, indent in [('hash_map_find', '  '), ('hash_map_try_put', '    ')]:
        start = candidate.index('fn ' + name + '<')
        end = candidate.find('\nfn ', start + 3)
        if end < 0: end = len(candidate)
        body = candidate[start:end]
        old = indent + 'let index = hash % count;'
        assert body.count(old) == 1
        replacement = '\n'.join(indent + line for line in [
            'let mask = count - 1_u64;', 'let index = iand(hash, mask);',
            'let non_power = iand(count, mask);', 'if non_power != 0_u64 {',
            '  set index = hash % count;', '}'])
        body = body.replace(old, replacement, 1)
        candidate = candidate[:start] + body + candidate[end:]
    (OUT / 'hash-map.candidate.wf').write_text(candidate)
    patch = ''.join(difflib.unified_diff(original.decode().splitlines(True), candidate.splitlines(True), fromfile='a/lib/std/collections/hash_map/hash-map.wf', tofile='b/lib/std/collections/hash_map/hash-map.wf'))
    (OUT / 'source.patch').write_text(patch)
    paths = {BASE, SOURCE, LIB, pathlib.Path(__file__), OUT / 'hash-map.original.wf', OUT / 'hash-map.candidate.wf', OUT / 'source.patch', OUT / 'criterion.txt', ROOT / 'tests/programs/containers/hash-map-program.wf'}
    for command in links.values():
        for arg in command[1:command.index('-o')]:
            if arg.endswith(('.o', '.a')): paths.add(absolute(arg))
    # Pin build inputs too; a changed compiler would not isolate the library edit.
    paths.update((ROOT / 'compiler/src').rglob('*.rs'))
    paths.update([ROOT / 'compiler/build.rs', ROOT / 'compiler/Cargo.toml', ROOT / 'compiler/Cargo.lock'])
    paths.update(p for p in (ROOT / 'lib').rglob('*') if p.is_file())
    (OUT / 'pins.json').write_text(json.dumps({str(p): sha(p) for p in sorted(paths)}, indent=2) + '\n')
    (OUT / 'link-commands.json').write_text(json.dumps(links, indent=2) + '\n')
    print('Prepared the exact two-home patch, four-space inner indentation and input pins.')
    raise SystemExit(0)
assert os.environ.get('WHITEFOOT_CHECK_OWNER'), 'Use perl .github/run-check.pl'
for path, expected in json.loads((OUT / 'pins.json').read_text()).items():
    assert sha(path) == expected, 'Changed input: ' + path
records = []
def run(label, argv, expected=0, message=None):
    argv = list(map(str, argv)); start = time.monotonic()
    # Keep build logs even if the process is interrupted.
    with (OUT / (label + '.stdout')).open('w') as stdout, (OUT / (label + '.stderr')).open('w') as stderr:
        process = subprocess.Popen(argv, cwd=ROOT, stdout=stdout, stderr=stderr)
        try:
            code = process.wait()
        except BaseException:
            if process.poll() is None:
                process.terminate()
                try: process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill(); process.wait()
            records.append(dict(label=label, argv=argv, exit=process.returncode, seconds=time.monotonic()-start, interrupted=True))
            (OUT / (mode + '-statuses.json')).write_text(json.dumps(records, indent=2) + '\n')
            raise
    row = dict(label=label, argv=argv, exit=code, seconds=time.monotonic()-start)
    records.append(row); (OUT / (mode + '-statuses.json')).write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    assert code == expected, row
    err = (OUT / (label + '.stderr')).read_text()
    if message is not None: assert err.strip() == 'mutation: ' + message, err
    return (OUT / (label + '.stdout')).read_text()
def interrupted(signum, frame): raise KeyboardInterrupt('Signal ' + str(signum))
for signum in [signal.SIGTERM, signal.SIGHUP, signal.SIGINT]: signal.signal(signum, interrupted)
if mode == 'build':
    assert not CAND.exists(), 'Preserve prior candidate; do not silently rebuild'
    run('control-emit', [BASE, '--emit-llvm', SOURCE, '-o', OUT / 'control.raw.ll'])
    assert sha(OUT / 'control.raw.ll') == EXPECTED, 'Baseline identity failed'
    original = (OUT / 'hash-map.original.wf').read_bytes()
    candidate = (OUT / 'hash-map.candidate.wf').read_bytes()
    assert LIB.read_bytes() == original
    try:
        LIB.write_bytes(candidate)
        assert LIB.read_bytes() == candidate
        os.environ['CARGO_BUILD_JOBS'] = '2'
        run('candidate-compiler-build', ['make', '-C', 'compiler', '-j2', 'build'])
        assert LIB.read_bytes() == candidate
        shutil.copy2(ROOT / 'compiler/target/gate/whitefootc', CAND)
        (OUT / 'compiler-identity.json').write_text(json.dumps(dict(baseline=sha(BASE), candidate=sha(CAND), original_library=hashlib.sha256(original).hexdigest(), candidate_library=hashlib.sha256(candidate).hexdigest()), indent=2) + '\n')
    finally:
        # Root grants exclusive ownership of this exact file for the staging step.
        observed = sha(LIB)
        LIB.write_bytes(original)
        restored = LIB.read_bytes() == original
        (OUT / 'restoration.json').write_text(json.dumps(dict(before_restore_sha256=observed, restored=restored, restored_sha256=sha(LIB)), indent=2) + '\n')
        assert restored, 'Original library restoration failed'
    run('candidate-emit', [CAND, '--emit-llvm', SOURCE, '-o', OUT / 'candidate.raw.ll'])
    for arm in ['control', 'candidate']:
        raw = (OUT / (arm + '.raw.ll')).read_text()
        for kind, original_command in links.items():
            text = raw.replace('define i32 @main(', 'define i32 @mutation_unused_main(')
            if kind == 'account':
                for old, new in [('@malloc(', '@wf_cost_allocate('), ('@realloc(', '@wf_cost_reallocate('), ('@free(', '@wf_cost_release(')]: text = text.replace(old, new)
            src = OUT / (arm + '-wf-' + kind + '.ll'); src.write_text(text); obj = src.with_suffix('.o')
            run(arm + '-' + kind + '-object', ['/usr/bin/clang', '-O3', '-Wno-override-module', '-x', 'ir', '-c', src, '-o', obj])
            command = list(original_command); old_obj = str(D / ('entry-forward-wf-' + kind + '.o'))
            assert command.count(old_obj) == 1
            command[command.index(old_obj)] = str(obj); command[-1] = str(OUT / (arm + '-' + kind))
            run(arm + '-' + kind + '-link', command)
        run(arm + '-native', [OBJDUMP, '-dr', '--no-show-raw-insn', OUT / (arm + '-timed')])
    images = [OUT / (a + '-' + k) for a in ['control', 'candidate'] for k in ['timed', 'account']]
    (OUT / 'images.json').write_text(json.dumps({str(p): sha(p) for p in images}, indent=2) + '\n')
    print('STOP for native gate. Library restored. No correctness or timing run.')
else:
    for path, expected in json.loads((OUT / 'images.json').read_text()).items(): assert sha(path) == expected, path
    identities = json.loads((OUT / 'compiler-identity.json').read_text())
    assert sha(CAND) == identities['candidate'] and sha(BASE) == identities['baseline']
    faults = {'wrong-batch-checksum': 'negative wrong batch checksum', 'stale-generation': 'negative stale generation', 'corrupt-last-word': 'negative corrupt last word full-content', 'cleanup': 'negative cleanup checksum', 'ledger-leak': 'negative ledger leak', 'filled-allocation': 'negative filled allocation'}
    ledgers = []
    for arm, cli in [('control', BASE), ('candidate', CAND)]:
        for kind in ['timed', 'account']:
            exe = OUT / (arm + '-' + kind)
            run(arm + '-' + kind + '-check', [exe, 'check'])
            for fault, message in faults.items():
                if kind == 'timed' and fault in ['ledger-leak', 'filled-allocation']: continue
                run(arm + '-' + kind + '-' + fault, [exe, 'negative', fault], 1, message)
        ledgers.append(run(arm + '-ledger', [OUT / (arm + '-account'), 'account']))
        # Original maintained public-library program, including capacity-three,
        # zero, full-cycle, hostile equality, owners and exact cleanup checks.
        fixture = ROOT / 'tests/programs/containers/hash-map-program.wf'
        exe = OUT / (arm + '-hash-map-program')
        run(arm + '-maintained-build', [cli, fixture, '-o', exe])
        run(arm + '-maintained-execute', [exe])
    assert ledgers[0] == ledgers[1], 'Allocation ledger mismatch'
    print('Broad controls and maintained program passed; no timing launched.')
