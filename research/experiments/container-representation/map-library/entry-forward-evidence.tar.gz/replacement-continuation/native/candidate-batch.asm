00000001000a5934 <_wf_flat_mutation_batch$instance$4250cb78d3f44027>:
1000a5934:     	sub	sp, sp, #0x1c0
1000a5938:     	stp	x28, x27, [sp, #0x160]
1000a593c:     	stp	x26, x25, [sp, #0x170]
1000a5940:     	stp	x24, x23, [sp, #0x180]
1000a5944:     	stp	x22, x21, [sp, #0x190]
1000a5948:     	stp	x20, x19, [sp, #0x1a0]
1000a594c:     	stp	x29, x30, [sp, #0x1b0]
1000a5950:     	str	x2, [sp, #0xa8]
1000a5954:     	ldr	x9, [x0, #0x38]
1000a5958:     	str	x1, [sp, #0x18]
1000a595c:     	cbz	x1, 0x1000a61e8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x8b4>
1000a5960:     	ldp	x8, x10, [x0, #0x40]
1000a5964:     	str	x8, [sp, #0xb8]
1000a5968:     	cbz	x8, 0x1000a61dc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x8a8>
1000a596c:     	mov	x11, #0x0               ; =0
1000a5970:     	ldr	x8, [x0, #0x20]
1000a5974:     	str	x8, [sp, #0x38]
1000a5978:     	ldr	x8, [x0, #0x18]
1000a597c:     	str	x8, [sp, #0xf0]
1000a5980:     	mov	w17, #0x110             ; =272
1000a5984:     	ldr	x8, [x0, #0x28]
1000a5988:     	str	x8, [sp, #0x98]
1000a598c:     	mov	w5, #0x83               ; =131
1000a5990:     	movi.2d	v0, #0000000000000000
1000a5994:     	ldrb	w8, [x0, #0x30]
1000a5998:     	str	w8, [sp, #0xc4]
1000a599c:     	mov	x15, x9
1000a59a0:     	str	x0, [sp, #0xc8]
1000a59a4:     	str	x9, [sp, #0x10]
1000a59a8:     	b	0x1000a59c4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x90>
1000a59ac:     	ldp	x11, x10, [sp, #0x20]
1000a59b0:     	str	x10, [x0, #0x48]
1000a59b4:     	add	x11, x11, #0x1
1000a59b8:     	ldp	x9, x8, [sp, #0x10]
1000a59bc:     	cmp	x11, x8
1000a59c0:     	b.eq	0x1000a61ec <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x8b8>
1000a59c4:     	mov	x20, #0x0               ; =0
1000a59c8:     	add	x10, x10, #0x1
1000a59cc:     	stp	x11, x10, [sp, #0x20]
1000a59d0:     	ldr	x8, [sp, #0xb8]
1000a59d4:     	madd	x8, x10, x8, x9
1000a59d8:     	str	x8, [sp, #0xb0]
1000a59dc:     	mov	w11, #0x1               ; =1
1000a59e0:     	b	0x1000a5acc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x198>
1000a59e4:     	mov	w11, #0x1               ; =1
1000a59e8:     	strb	w11, [sp, #0x15c]
1000a59ec:     	ldp	x0, x13, [sp, #0xc8]
1000a59f0:     	ldp	x3, x1, [sp, #0xe0]
1000a59f4:     	ldr	x22, [sp, #0xd8]
1000a59f8:     	madd	x8, x24, x5, x10
1000a59fc:     	madd	x8, x8, x5, x6
1000a5a00:     	madd	x8, x8, x5, x30
1000a5a04:     	ldrb	w9, [sp, #0x15c]
1000a5a08:     	tst	w9, #0x1
1000a5a0c:     	madd	x8, x8, x5, x28
1000a5a10:     	cinc	x9, x11, ne
1000a5a14:     	madd	x8, x8, x5, x27
1000a5a18:     	madd	x8, x8, x5, x26
1000a5a1c:     	madd	x8, x8, x5, x4
1000a5a20:     	madd	x8, x8, x5, x25
1000a5a24:     	madd	x8, x8, x5, x19
1000a5a28:     	madd	x8, x8, x5, x14
1000a5a2c:     	madd	x8, x8, x5, x7
1000a5a30:     	madd	x8, x8, x5, x16
1000a5a34:     	madd	x8, x8, x5, x21
1000a5a38:     	madd	x8, x8, x5, x2
1000a5a3c:     	madd	x8, x8, x5, x12
1000a5a40:     	madd	x8, x8, x5, x23
1000a5a44:     	madd	x8, x8, x5, x15
1000a5a48:     	ldr	x10, [sp, #0xf8]
1000a5a4c:     	madd	x8, x8, x5, x10
1000a5a50:     	ldr	x10, [sp, #0x100]
1000a5a54:     	madd	x8, x8, x5, x10
1000a5a58:     	ldr	x10, [sp, #0x108]
1000a5a5c:     	madd	x8, x8, x5, x10
1000a5a60:     	ldr	x10, [sp, #0x110]
1000a5a64:     	madd	x8, x8, x5, x10
1000a5a68:     	ldr	x10, [sp, #0x118]
1000a5a6c:     	madd	x8, x8, x5, x10
1000a5a70:     	ldr	x10, [sp, #0x120]
1000a5a74:     	madd	x8, x8, x5, x10
1000a5a78:     	ldr	x10, [sp, #0x128]
1000a5a7c:     	madd	x8, x8, x5, x10
1000a5a80:     	ldr	x10, [sp, #0x130]
1000a5a84:     	madd	x8, x8, x5, x10
1000a5a88:     	ldr	x10, [sp, #0x138]
1000a5a8c:     	madd	x8, x8, x5, x10
1000a5a90:     	ldr	x10, [sp, #0x140]
1000a5a94:     	madd	x8, x8, x5, x10
1000a5a98:     	ldr	x10, [sp, #0x148]
1000a5a9c:     	madd	x8, x8, x5, x10
1000a5aa0:     	ldr	x10, [sp, #0x150]
1000a5aa4:     	madd	x8, x8, x5, x10
1000a5aa8:     	add	x10, x22, x13
1000a5aac:     	madd	x8, x8, x5, x10
1000a5ab0:     	add	x9, x9, x3
1000a5ab4:     	madd	x8, x8, x5, x9
1000a5ab8:     	madd	x15, x8, x5, x1
1000a5abc:     	add	x20, x20, #0x1
1000a5ac0:     	ldr	x8, [sp, #0xb8]
1000a5ac4:     	cmp	x20, x8
1000a5ac8:     	b.eq	0x1000a59ac <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x78>
1000a5acc:     	mov	w14, #0x1               ; =1
1000a5ad0:     	orr	x24, x11, x20, lsl #1
1000a5ad4:     	ldr	x8, [sp, #0xa8]
1000a5ad8:     	cbz	x8, 0x1000a5cf0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x3bc>
1000a5adc:     	ldr	x8, [sp, #0xf0]
1000a5ae0:     	cbz	x8, 0x1000a5d04 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x3d0>
1000a5ae4:     	ldr	w8, [sp, #0xc4]
1000a5ae8:     	tbz	w8, #0x0, 0x1000a5afc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x1c8>
1000a5aec:     	mov	x8, #0x0                ; =0
1000a5af0:     	ldr	x9, [x0]
1000a5af4:     	cbnz	x9, 0x1000a5b40 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x20c>
1000a5af8:     	b	0x1000a5d04 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x3d0>
1000a5afc:     	ldr	x8, [sp, #0x98]
1000a5b00:     	eor	x8, x24, x8
1000a5b04:     	eor	x8, x8, x8, lsr #30
1000a5b08:     	mov	x9, #0xe5b9             ; =58809
1000a5b0c:     	movk	x9, #0x1ce4, lsl #16
1000a5b10:     	movk	x9, #0x476d, lsl #32
1000a5b14:     	movk	x9, #0xbf58, lsl #48
1000a5b18:     	mul	x8, x8, x9
1000a5b1c:     	eor	x8, x8, x8, lsr #27
1000a5b20:     	mov	x9, #0x11eb             ; =4587
1000a5b24:     	movk	x9, #0x1331, lsl #16
1000a5b28:     	movk	x9, #0x49bb, lsl #32
1000a5b2c:     	movk	x9, #0x94d0, lsl #48
1000a5b30:     	mul	x8, x8, x9
1000a5b34:     	eor	x8, x8, x8, lsr #31
1000a5b38:     	ldr	x9, [x0]
1000a5b3c:     	cbz	x9, 0x1000a5d04 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x3d0>
1000a5b40:     	udiv	x10, x8, x9
1000a5b44:     	msub	x10, x10, x9, x8
1000a5b48:     	ldr	x11, [x0, #0x10]
1000a5b4c:     	mov	x12, x9
1000a5b50:     	b	0x1000a5b68 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x234>
1000a5b54:     	add	x8, x10, #0x1
1000a5b58:     	cmp	x8, x9
1000a5b5c:     	csinc	x10, xzr, x10, hs
1000a5b60:     	subs	x12, x12, #0x1
1000a5b64:     	b.eq	0x1000a5d04 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x3d0>
1000a5b68:     	madd	x8, x10, x17, x11
1000a5b6c:     	ldr	w13, [x8]
1000a5b70:     	cmp	w13, #0x1
1000a5b74:     	b.eq	0x1000a5b54 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x220>
1000a5b78:     	cmp	w13, #0x2
1000a5b7c:     	b.ne	0x1000a5d04 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x3d0>
1000a5b80:     	ldr	x13, [x8, #0x8]
1000a5b84:     	cmp	x13, x24
1000a5b88:     	b.ne	0x1000a5b54 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x220>
1000a5b8c:     	ldp	x10, x9, [x8, #0x10]
1000a5b90:     	stp	x9, x10, [sp, #0x148]
1000a5b94:     	ldp	x10, x9, [x8, #0x20]
1000a5b98:     	stp	x9, x10, [sp, #0x138]
1000a5b9c:     	ldp	x13, x10, [x8, #0x30]
1000a5ba0:     	ldp	x9, x16, [x8, #0x40]
1000a5ba4:     	stp	x9, x10, [sp, #0x128]
1000a5ba8:     	ldp	x0, x1, [x8, #0x50]
1000a5bac:     	ldp	x2, x3, [x8, #0x60]
1000a5bb0:     	ldp	x4, x6, [x8, #0x70]
1000a5bb4:     	ldp	x7, x19, [x8, #0x80]
1000a5bb8:     	ldp	x21, x22, [x8, #0x90]
1000a5bbc:     	ldp	x23, x25, [x8, #0xa0]
1000a5bc0:     	ldp	x26, x27, [x8, #0xb0]
1000a5bc4:     	ldp	x28, x30, [x8, #0xc0]
1000a5bc8:     	ldp	x10, x9, [x8, #0xd0]
1000a5bcc:     	stp	x9, x10, [sp, #0x118]
1000a5bd0:     	ldp	x10, x9, [x8, #0xe0]
1000a5bd4:     	stp	x9, x10, [sp, #0x108]
1000a5bd8:     	str	w14, [x8]
1000a5bdc:     	stur	q0, [x8, #0x8]
1000a5be0:     	stur	q0, [x8, #0x18]
1000a5be4:     	stur	q0, [x8, #0x28]
1000a5be8:     	stur	q0, [x8, #0x38]
1000a5bec:     	stur	q0, [x8, #0x48]
1000a5bf0:     	stur	q0, [x8, #0x58]
1000a5bf4:     	stur	q0, [x8, #0x68]
1000a5bf8:     	stur	q0, [x8, #0x78]
1000a5bfc:     	stur	q0, [x8, #0x88]
1000a5c00:     	stur	q0, [x8, #0x98]
1000a5c04:     	stur	q0, [x8, #0xa8]
1000a5c08:     	stur	q0, [x8, #0xb8]
1000a5c0c:     	stur	q0, [x8, #0xc8]
1000a5c10:     	stur	q0, [x8, #0xd8]
1000a5c14:     	ldp	x11, x12, [x8, #0xf0]
1000a5c18:     	stur	q0, [x8, #0xe8]
1000a5c1c:     	ldp	x9, x10, [x8, #0x100]
1000a5c20:     	stur	q0, [x8, #0xf8]
1000a5c24:     	str	xzr, [x8, #0x108]
1000a5c28:     	ldp	x14, x8, [sp, #0x148]
1000a5c2c:     	madd	x8, x24, x5, x8
1000a5c30:     	madd	x8, x8, x5, x14
1000a5c34:     	ldr	x14, [sp, #0x140]
1000a5c38:     	madd	x8, x8, x5, x14
1000a5c3c:     	ldr	x14, [sp, #0x138]
1000a5c40:     	madd	x8, x8, x5, x14
1000a5c44:     	madd	x8, x8, x5, x13
1000a5c48:     	ldp	x13, x14, [sp, #0x128]
1000a5c4c:     	madd	x8, x8, x5, x14
1000a5c50:     	madd	x8, x8, x5, x13
1000a5c54:     	madd	x8, x8, x5, x16
1000a5c58:     	madd	x8, x8, x5, x0
1000a5c5c:     	madd	x8, x8, x5, x1
1000a5c60:     	madd	x8, x8, x5, x2
1000a5c64:     	madd	x8, x8, x5, x3
1000a5c68:     	madd	x8, x8, x5, x4
1000a5c6c:     	madd	x8, x8, x5, x6
1000a5c70:     	madd	x8, x8, x5, x7
1000a5c74:     	madd	x8, x8, x5, x19
1000a5c78:     	madd	x8, x8, x5, x21
1000a5c7c:     	madd	x8, x8, x5, x22
1000a5c80:     	ldr	x0, [sp, #0xc8]
1000a5c84:     	madd	x8, x8, x5, x23
1000a5c88:     	madd	x8, x8, x5, x25
1000a5c8c:     	madd	x8, x8, x5, x26
1000a5c90:     	madd	x8, x8, x5, x27
1000a5c94:     	madd	x8, x8, x5, x28
1000a5c98:     	madd	x8, x8, x5, x30
1000a5c9c:     	ldp	x13, x14, [sp, #0x118]
1000a5ca0:     	madd	x8, x8, x5, x14
1000a5ca4:     	madd	x8, x8, x5, x13
1000a5ca8:     	ldp	x13, x14, [sp, #0x108]
1000a5cac:     	madd	x8, x8, x5, x14
1000a5cb0:     	madd	x8, x8, x5, x13
1000a5cb4:     	madd	x8, x8, x5, x11
1000a5cb8:     	madd	x8, x8, x5, x12
1000a5cbc:     	madd	x8, x8, x5, x9
1000a5cc0:     	mov	w9, #0x4309             ; =17161
1000a5cc4:     	madd	x9, x15, x9, x10
1000a5cc8:     	madd	x8, x8, x5, x9
1000a5ccc:     	ldr	x10, [sp, #0xf0]
1000a5cd0:     	sub	x10, x10, #0x1
1000a5cd4:     	ldr	x9, [sp, #0x38]
1000a5cd8:     	adds	x9, x9, #0x1
1000a5cdc:     	csinv	x9, x9, xzr, lo
1000a5ce0:     	str	x10, [sp, #0xf0]
1000a5ce4:     	stp	x10, x9, [x0, #0x18]
1000a5ce8:     	str	x9, [sp, #0x38]
1000a5cec:     	add	x15, x8, #0x83
1000a5cf0:     	ldr	w8, [sp, #0xc4]
1000a5cf4:     	str	x15, [sp, #0xd0]
1000a5cf8:     	tbz	w8, #0x0, 0x1000a5d14 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x3e0>
1000a5cfc:     	mov	x11, #0x0               ; =0
1000a5d00:     	b	0x1000a5d50 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x41c>
1000a5d04:     	mul	x15, x15, x5
1000a5d08:     	ldr	w8, [sp, #0xc4]
1000a5d0c:     	str	x15, [sp, #0xd0]
1000a5d10:     	tbnz	w8, #0x0, 0x1000a5cfc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x3c8>
1000a5d14:     	ldr	x8, [sp, #0x98]
1000a5d18:     	eor	x8, x24, x8
1000a5d1c:     	eor	x8, x8, x8, lsr #30
1000a5d20:     	mov	x9, #0xe5b9             ; =58809
1000a5d24:     	movk	x9, #0x1ce4, lsl #16
1000a5d28:     	movk	x9, #0x476d, lsl #32
1000a5d2c:     	movk	x9, #0xbf58, lsl #48
1000a5d30:     	mul	x8, x8, x9
1000a5d34:     	eor	x8, x8, x8, lsr #27
1000a5d38:     	mov	x9, #0x11eb             ; =4587
1000a5d3c:     	movk	x9, #0x1331, lsl #16
1000a5d40:     	movk	x9, #0x49bb, lsl #32
1000a5d44:     	movk	x9, #0x94d0, lsl #48
1000a5d48:     	mul	x8, x8, x9
1000a5d4c:     	eor	x11, x8, x8, lsr #31
1000a5d50:     	ldr	x8, [sp, #0xb0]
1000a5d54:     	add	x10, x8, x20
1000a5d58:     	add	x6, x10, #0x1
1000a5d5c:     	add	x30, x10, #0x2
1000a5d60:     	add	x28, x10, #0x3
1000a5d64:     	add	x27, x10, #0x4
1000a5d68:     	add	x26, x10, #0x5
1000a5d6c:     	add	x4, x10, #0x6
1000a5d70:     	add	x25, x10, #0x7
1000a5d74:     	add	x19, x10, #0x8
1000a5d78:     	add	x14, x10, #0x9
1000a5d7c:     	add	x7, x10, #0xa
1000a5d80:     	add	x16, x10, #0xb
1000a5d84:     	add	x21, x10, #0xc
1000a5d88:     	add	x2, x10, #0xd
1000a5d8c:     	add	x12, x10, #0xe
1000a5d90:     	add	x23, x10, #0xf
1000a5d94:     	add	x15, x10, #0x10
1000a5d98:     	add	x9, x10, #0x11
1000a5d9c:     	add	x8, x10, #0x12
1000a5da0:     	stp	x9, x8, [sp, #0xf8]
1000a5da4:     	add	x9, x10, #0x13
1000a5da8:     	add	x8, x10, #0x14
1000a5dac:     	stp	x9, x8, [sp, #0x108]
1000a5db0:     	add	x9, x10, #0x15
1000a5db4:     	add	x8, x10, #0x16
1000a5db8:     	stp	x9, x8, [sp, #0x118]
1000a5dbc:     	add	x9, x10, #0x17
1000a5dc0:     	add	x8, x10, #0x18
1000a5dc4:     	stp	x9, x8, [sp, #0x128]
1000a5dc8:     	add	x9, x10, #0x19
1000a5dcc:     	add	x8, x10, #0x1a
1000a5dd0:     	stp	x9, x8, [sp, #0x138]
1000a5dd4:     	add	x9, x10, #0x1b
1000a5dd8:     	add	x8, x10, #0x1c
1000a5ddc:     	stp	x9, x8, [sp, #0x148]
1000a5de0:     	add	x9, x10, #0x1d
1000a5de4:     	add	x8, x10, #0x1e
1000a5de8:     	stp	x9, x8, [sp, #0xd8]
1000a5dec:     	ldr	x1, [x0]
1000a5df0:     	add	x8, x10, #0x1f
1000a5df4:     	str	x8, [sp, #0xe8]
1000a5df8:     	cbz	x1, 0x1000a5ff4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x6c0>
1000a5dfc:     	udiv	x8, x11, x1
1000a5e00:     	msub	x3, x8, x1, x11
1000a5e04:     	ldr	x8, [x0, #0x10]
1000a5e08:     	mov	x13, x1
1000a5e0c:     	mov	x9, x1
1000a5e10:     	b	0x1000a5e30 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x4fc>
1000a5e14:     	cmp	x9, x1
1000a5e18:     	csel	x9, x3, x9, eq
1000a5e1c:     	add	x11, x3, #0x1
1000a5e20:     	cmp	x11, x1
1000a5e24:     	csinc	x3, xzr, x3, hs
1000a5e28:     	subs	x13, x13, #0x1
1000a5e2c:     	b.eq	0x1000a5ff8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x6c4>
1000a5e30:     	madd	x11, x3, x17, x8
1000a5e34:     	ldr	w22, [x11]
1000a5e38:     	cmp	w22, #0x1
1000a5e3c:     	b.eq	0x1000a5e14 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x4e0>
1000a5e40:     	cmp	w22, #0x2
1000a5e44:     	b.ne	0x1000a61c8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x894>
1000a5e48:     	ldr	x22, [x11, #0x8]
1000a5e4c:     	cmp	x22, x24
1000a5e50:     	b.ne	0x1000a5e1c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x4e8>
1000a5e54:     	ldp	x9, x8, [x11, #0x10]
1000a5e58:     	stp	x8, x9, [sp, #0x88]
1000a5e5c:     	stp	x10, x6, [x11, #0x10]
1000a5e60:     	ldp	x9, x8, [x11, #0x20]
1000a5e64:     	stp	x8, x9, [sp, #0x78]
1000a5e68:     	stp	x30, x28, [x11, #0x20]
1000a5e6c:     	ldp	x9, x8, [x11, #0x30]
1000a5e70:     	stp	x8, x9, [sp, #0x68]
1000a5e74:     	stp	x27, x26, [x11, #0x30]
1000a5e78:     	ldp	x9, x8, [x11, #0x40]
1000a5e7c:     	stp	x8, x9, [sp, #0x58]
1000a5e80:     	stp	x4, x25, [x11, #0x40]
1000a5e84:     	ldp	x9, x8, [x11, #0x50]
1000a5e88:     	stp	x8, x9, [sp, #0x48]
1000a5e8c:     	stp	x19, x14, [x11, #0x50]
1000a5e90:     	ldp	x27, x26, [x11, #0x60]
1000a5e94:     	stp	x7, x16, [x11, #0x60]
1000a5e98:     	ldp	x19, x25, [x11, #0x70]
1000a5e9c:     	stp	x21, x2, [x11, #0x70]
1000a5ea0:     	ldp	x7, x21, [x11, #0x80]
1000a5ea4:     	stp	x12, x23, [x11, #0x80]
1000a5ea8:     	ldp	x2, x6, [x11, #0x90]
1000a5eac:     	ldp	x9, x10, [sp, #0xf8]
1000a5eb0:     	stp	x15, x9, [x11, #0x90]
1000a5eb4:     	ldp	x1, x0, [x11, #0xa0]
1000a5eb8:     	ldp	x9, x8, [sp, #0x108]
1000a5ebc:     	stp	x10, x9, [x11, #0xa0]
1000a5ec0:     	ldp	x3, x4, [x11, #0xb0]
1000a5ec4:     	str	x8, [x11, #0xb0]
1000a5ec8:     	ldp	x9, x8, [sp, #0x118]
1000a5ecc:     	ldp	x22, x23, [x11, #0xc0]
1000a5ed0:     	stp	x9, x8, [x11, #0xb8]
1000a5ed4:     	ldp	x9, x8, [sp, #0x128]
1000a5ed8:     	ldp	x30, x15, [x11, #0xd0]
1000a5edc:     	stp	x9, x8, [x11, #0xc8]
1000a5ee0:     	ldp	x9, x8, [sp, #0x138]
1000a5ee4:     	ldp	x13, x12, [x11, #0xe0]
1000a5ee8:     	stp	x9, x8, [x11, #0xd8]
1000a5eec:     	ldp	x8, x10, [sp, #0x148]
1000a5ef0:     	str	x8, [x11, #0xe8]
1000a5ef4:     	ldp	x8, x9, [x11, #0xf0]
1000a5ef8:     	str	x10, [x11, #0xf0]
1000a5efc:     	ldp	x10, x16, [sp, #0xd8]
1000a5f00:     	str	x10, [x11, #0xf8]
1000a5f04:     	ldp	x10, x14, [x11, #0x100]
1000a5f08:     	str	x16, [x11, #0x100]
1000a5f0c:     	ldr	x16, [sp, #0xe8]
1000a5f10:     	str	x16, [x11, #0x108]
1000a5f14:     	ldr	w16, [x11, #0x4]
1000a5f18:     	ldr	w28, [sp, #0x34]
1000a5f1c:     	str	w28, [x11, #0x4]
1000a5f20:     	mov	w28, #0x2               ; =2
1000a5f24:     	str	w28, [x11]
1000a5f28:     	ldr	x11, [sp, #0x90]
1000a5f2c:     	madd	x11, x24, x5, x11
1000a5f30:     	ldr	x24, [sp, #0x88]
1000a5f34:     	madd	x11, x11, x5, x24
1000a5f38:     	ldr	x24, [sp, #0x80]
1000a5f3c:     	madd	x11, x11, x5, x24
1000a5f40:     	ldr	x24, [sp, #0x78]
1000a5f44:     	madd	x11, x11, x5, x24
1000a5f48:     	ldr	x24, [sp, #0x70]
1000a5f4c:     	madd	x11, x11, x5, x24
1000a5f50:     	ldr	x24, [sp, #0x68]
1000a5f54:     	madd	x11, x11, x5, x24
1000a5f58:     	ldr	x24, [sp, #0x60]
1000a5f5c:     	madd	x11, x11, x5, x24
1000a5f60:     	ldr	x24, [sp, #0x58]
1000a5f64:     	madd	x11, x11, x5, x24
1000a5f68:     	ldr	x24, [sp, #0x50]
1000a5f6c:     	madd	x11, x11, x5, x24
1000a5f70:     	ldr	x24, [sp, #0x48]
1000a5f74:     	madd	x11, x11, x5, x24
1000a5f78:     	madd	x11, x11, x5, x27
1000a5f7c:     	madd	x11, x11, x5, x26
1000a5f80:     	madd	x11, x11, x5, x19
1000a5f84:     	madd	x11, x11, x5, x25
1000a5f88:     	madd	x11, x11, x5, x7
1000a5f8c:     	madd	x11, x11, x5, x21
1000a5f90:     	madd	x11, x11, x5, x2
1000a5f94:     	madd	x11, x11, x5, x6
1000a5f98:     	madd	x11, x11, x5, x1
1000a5f9c:     	madd	x11, x11, x5, x0
1000a5fa0:     	madd	x11, x11, x5, x3
1000a5fa4:     	madd	x11, x11, x5, x4
1000a5fa8:     	madd	x11, x11, x5, x22
1000a5fac:     	madd	x11, x11, x5, x23
1000a5fb0:     	madd	x11, x11, x5, x30
1000a5fb4:     	madd	x11, x11, x5, x15
1000a5fb8:     	madd	x11, x11, x5, x13
1000a5fbc:     	madd	x11, x11, x5, x12
1000a5fc0:     	madd	x8, x11, x5, x8
1000a5fc4:     	ldp	x0, x11, [sp, #0xc8]
1000a5fc8:     	add	x9, x9, x11
1000a5fcc:     	madd	x8, x8, x5, x9
1000a5fd0:     	tst	wzr, #0x1
1000a5fd4:     	madd	x8, x8, x5, x10
1000a5fd8:     	mov	w11, #0x1               ; =1
1000a5fdc:     	cinc	x9, x11, ne
1000a5fe0:     	add	x8, x8, x9
1000a5fe4:     	madd	x15, x8, x5, x14
1000a5fe8:     	strb	wzr, [sp, #0x15c]
1000a5fec:     	str	w16, [sp, #0x34]
1000a5ff0:     	b	0x1000a5abc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x188>
1000a5ff4:     	mov	x9, #0x0                ; =0
1000a5ff8:     	cmp	x9, x1
1000a5ffc:     	b.hs	0x1000a59e4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0xb0>
1000a6000:     	ldr	x8, [sp, #0xf0]
1000a6004:     	cmp	x8, #0x2, lsl #12       ; =0x2000
1000a6008:     	b.hs	0x1000a59e4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0xb0>
1000a600c:     	ldr	x8, [sp, #0xf0]
1000a6010:     	add	x8, x8, #0x1
1000a6014:     	ldr	x13, [sp, #0xc8]
1000a6018:     	str	x8, [sp, #0xf0]
1000a601c:     	str	x8, [x13, #0x18]
1000a6020:     	ldr	x8, [x13, #0x10]
1000a6024:     	madd	x1, x9, x17, x8
1000a6028:     	ldr	w11, [x1]
1000a602c:     	cmp	w11, #0x1
1000a6030:     	b.ne	0x1000a6048 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x714>
1000a6034:     	ldr	x8, [sp, #0x38]
1000a6038:     	subs	x8, x8, #0x1
1000a603c:     	csel	x8, xzr, x8, lo
1000a6040:     	str	x8, [sp, #0x38]
1000a6044:     	str	x8, [x13, #0x20]
1000a6048:     	ldp	x9, x8, [x1, #0x8]
1000a604c:     	stp	x8, x9, [sp, #0x88]
1000a6050:     	stp	x24, x10, [x1, #0x8]
1000a6054:     	ldp	x9, x8, [x1, #0x18]
1000a6058:     	stp	x8, x9, [sp, #0x78]
1000a605c:     	stp	x6, x30, [x1, #0x18]
1000a6060:     	ldp	x9, x8, [x1, #0x28]
1000a6064:     	stp	x8, x9, [sp, #0x68]
1000a6068:     	stp	x28, x27, [x1, #0x28]
1000a606c:     	ldp	x9, x8, [x1, #0x38]
1000a6070:     	stp	x8, x9, [sp, #0x58]
1000a6074:     	stp	x26, x4, [x1, #0x38]
1000a6078:     	ldp	x9, x8, [x1, #0x48]
1000a607c:     	stp	x8, x9, [sp, #0x48]
1000a6080:     	stp	x25, x19, [x1, #0x48]
1000a6084:     	ldp	x8, x25, [x1, #0x58]
1000a6088:     	str	x8, [sp, #0x40]
1000a608c:     	stp	x14, x7, [x1, #0x58]
1000a6090:     	ldp	x14, x7, [x1, #0x68]
1000a6094:     	stp	x16, x21, [x1, #0x68]
1000a6098:     	ldp	x16, x21, [x1, #0x78]
1000a609c:     	stp	x2, x12, [x1, #0x78]
1000a60a0:     	ldp	x12, x2, [x1, #0x88]
1000a60a4:     	stp	x23, x15, [x1, #0x88]
1000a60a8:     	ldp	x15, x23, [x1, #0x98]
1000a60ac:     	ldp	x9, x8, [sp, #0xf8]
1000a60b0:     	stp	x9, x8, [x1, #0x98]
1000a60b4:     	ldp	x4, x22, [x1, #0xa8]
1000a60b8:     	ldp	x9, x8, [sp, #0x108]
1000a60bc:     	stp	x9, x8, [x1, #0xa8]
1000a60c0:     	ldp	x8, x9, [x1, #0xb8]
1000a60c4:     	ldr	x10, [sp, #0x118]
1000a60c8:     	str	x10, [x1, #0xb8]
1000a60cc:     	ldp	x10, x13, [sp, #0x120]
1000a60d0:     	str	x10, [x1, #0xc0]
1000a60d4:     	ldp	x3, x10, [x1, #0xc8]
1000a60d8:     	str	x13, [x1, #0xc8]
1000a60dc:     	ldr	x13, [sp, #0x130]
1000a60e0:     	str	x13, [x1, #0xd0]
1000a60e4:     	ldp	x24, x6, [x1, #0xd8]
1000a60e8:     	ldr	x13, [sp, #0x138]
1000a60ec:     	str	x13, [x1, #0xd8]
1000a60f0:     	ldr	x13, [sp, #0x140]
1000a60f4:     	str	x13, [x1, #0xe0]
1000a60f8:     	ldp	x30, x27, [x1, #0xe8]
1000a60fc:     	ldr	x13, [sp, #0x148]
1000a6100:     	str	x13, [x1, #0xe8]
1000a6104:     	ldr	x13, [sp, #0x150]
1000a6108:     	str	x13, [x1, #0xf0]
1000a610c:     	ldp	x28, x0, [x1, #0xf8]
1000a6110:     	ldr	x13, [sp, #0xd8]
1000a6114:     	str	x13, [x1, #0xf8]
1000a6118:     	ldr	x13, [sp, #0xe0]
1000a611c:     	str	x13, [x1, #0x100]
1000a6120:     	ldr	x26, [x1, #0x108]
1000a6124:     	ldr	x13, [sp, #0xe8]
1000a6128:     	str	x13, [x1, #0x108]
1000a612c:     	ldr	w13, [x1, #0x4]
1000a6130:     	ldr	w19, [sp, #0xa4]
1000a6134:     	str	w19, [x1, #0x4]
1000a6138:     	mov	w19, #0x2               ; =2
1000a613c:     	str	w19, [x1]
1000a6140:     	strb	wzr, [sp, #0x15c]
1000a6144:     	cmp	w11, #0x2
1000a6148:     	b.hs	0x1000a6160 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x82c>
1000a614c:     	ldp	x0, x15, [sp, #0xc8]
1000a6150:     	mul	x15, x15, x5
1000a6154:     	str	w13, [sp, #0xa4]
1000a6158:     	mov	w11, #0x1               ; =1
1000a615c:     	b	0x1000a5abc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x188>
1000a6160:     	mov	x1, x26
1000a6164:     	stp	x30, x27, [sp, #0x148]
1000a6168:     	stp	x24, x6, [sp, #0x138]
1000a616c:     	stp	x3, x10, [sp, #0x128]
1000a6170:     	mov	x3, x0
1000a6174:     	stp	x8, x9, [sp, #0x118]
1000a6178:     	stp	x4, x22, [sp, #0x108]
1000a617c:     	mov	x22, x28
1000a6180:     	stp	x15, x23, [sp, #0xf8]
1000a6184:     	mov	x15, x2
1000a6188:     	mov	x23, x12
1000a618c:     	mov	x12, x21
1000a6190:     	mov	x2, x16
1000a6194:     	mov	x21, x7
1000a6198:     	mov	x16, x14
1000a619c:     	mov	x7, x25
1000a61a0:     	ldp	x14, x19, [sp, #0x40]
1000a61a4:     	ldp	x25, x4, [sp, #0x50]
1000a61a8:     	ldp	x26, x27, [sp, #0x60]
1000a61ac:     	ldp	x28, x30, [sp, #0x70]
1000a61b0:     	ldp	x6, x10, [sp, #0x80]
1000a61b4:     	ldr	x24, [sp, #0x90]
1000a61b8:     	str	w13, [sp, #0xa4]
1000a61bc:     	ldp	x0, x13, [sp, #0xc8]
1000a61c0:     	mov	w11, #0x1               ; =1
1000a61c4:     	b	0x1000a59f8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0xc4>
1000a61c8:     	cmp	x9, x1
1000a61cc:     	csel	x9, x3, x9, eq
1000a61d0:     	cmp	x9, x1
1000a61d4:     	b.lo	0x1000a6000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x6cc>
1000a61d8:     	b	0x1000a59e4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0xb0>
1000a61dc:     	ldr	x8, [sp, #0x18]
1000a61e0:     	add	x8, x10, x8
1000a61e4:     	str	x8, [x0, #0x48]
1000a61e8:     	mov	x15, x9
1000a61ec:     	eor	x8, x15, x15, lsr #30
1000a61f0:     	mov	x9, #0xe5b9             ; =58809
1000a61f4:     	movk	x9, #0x1ce4, lsl #16
1000a61f8:     	movk	x9, #0x476d, lsl #32
1000a61fc:     	movk	x9, #0xbf58, lsl #48
1000a6200:     	mul	x8, x8, x9
1000a6204:     	eor	x8, x8, x8, lsr #27
1000a6208:     	mov	x9, #0x11eb             ; =4587
1000a620c:     	movk	x9, #0x1331, lsl #16
1000a6210:     	movk	x9, #0x49bb, lsl #32
1000a6214:     	movk	x9, #0x94d0, lsl #48
1000a6218:     	mul	x8, x8, x9
1000a621c:     	eor	x0, x8, x8, lsr #31
1000a6220:     	ldp	x29, x30, [sp, #0x1b0]
1000a6224:     	ldp	x20, x19, [sp, #0x1a0]
1000a6228:     	ldp	x22, x21, [sp, #0x190]
1000a622c:     	ldp	x24, x23, [sp, #0x180]
1000a6230:     	ldp	x26, x25, [sp, #0x170]
1000a6234:     	ldp	x28, x27, [sp, #0x160]
1000a6238:     	add	sp, sp, #0x1c0
1000a623c:     	ret

