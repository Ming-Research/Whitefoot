#!/usr/bin/env python3
"""One-shot CFG placement replay. Read/write only; no compile or execution."""
from pathlib import Path
import difflib, hashlib, json, re
D = Path(__file__).parent
SOURCE_SHA = 'e65bfc792c82e2e418c529ce29eef6c6ae09904a2787bea85264055aae748453'
src = (D / 'control.opt.ll').read_text()
assert hashlib.sha256(src.encode()).hexdigest() == SOURCE_SHA
symbol = 'wf_flat_mutation_batch$instance$4250cb78d3f44027'
pattern = r'^define [^\n]*@"' + re.escape(symbol) + r'"\(.*?^}\n'
match = re.search(pattern, src, re.M | re.S)
assert match
function = match.group()
label = r'(?:"[^"\n]+"|[-a-zA-Z$._0-9]+)'
headers = list(re.finditer(r'^(' + label + r'):.*\n', function, re.M))
blocks = {}
for i, header in enumerate(headers):
    end = headers[i + 1].start() if i + 1 < len(headers) else function.rindex('}')
    blocks[header[1]] = function[header.start():end]
replace_pred = '"wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449.disjoint_floor.exit"'
first = 'bb3.i120.sink.split'
second = 'bb3.i120'
exit_block = '"wf_map_cost_library_policy_result$instance$4250cb78d3f44027.exit"'
clone = 'replacement.continuation'
token = r'%(?:"[^"\n]+"|[-a-zA-Z$._0-9]+)'
phi = re.compile(r'^  (' + token + r') = phi (i[0-9]+) (.*)$')
incoming = re.compile(r'\[ ([^\[\],]+), %(' + label + r') \]')
substitutions = {}
audit = {'function': symbol, 'incoming_predecessor': replace_pred, 'cloned_blocks': [first, second], 'replacement_block': clone, 'successor': exit_block, 'phi_substitutions': [], 'renamed_definitions': {}, 'successor_phi_additions': []}
def substitute(text):
    return re.sub(token, lambda m: substitutions.get(m[0], m[0]), text)
cloned_lines = [clone + ':\n']
first_remainder = []
for block_name, predecessor in [(first, replace_pred), (second, first)]:
    body = blocks[block_name].splitlines(True)[1:]
    for line in body:
        p = phi.match(line.rstrip('\n'))
        if p:
            values = incoming.findall(p[3])
            selected = [value for value, pred in values if pred == predecessor]
            assert len(values) == 2 and len(selected) == 1
            substitutions[p[1]] = substitute(selected[0])
            audit['phi_substitutions'].append({'value': p[1], 'from_block': block_name, 'selected_predecessor': predecessor, 'replacement': substitutions[p[1]]})
            if block_name == first:
                remaining = [(value, pred) for value, pred in values if pred != predecessor]
                assert remaining[0][1] == 'bb1.i'
                first_remainder.append('  ' + p[1] + ' = phi ' + p[2] + ' ' + ', '.join('[ ' + value + ', %' + pred + ' ]' for value, pred in remaining) + '\n')
            continue
        if block_name == first:
            first_remainder.append(line)
            if line.strip() == 'br label %' + second:
                continue
        definition = re.match(r'^  (' + token + r') = ', line)
        if definition:
            old = definition[1]
            new = '%continuation.' + old[1:]
            assert new not in function
            substitutions[old] = new
            audit['renamed_definitions'][old] = new
        cloned_lines.append(substitute(line))
assert len(audit['phi_substitutions']) == 73, len(audit['phi_substitutions'])
assert cloned_lines[-2].strip() == 'br label %' + exit_block
clone_text = ''.join(cloned_lines)
# Definitions outside the cloned region may consume its old names only through
# existing successor PHIs. That check rules out a missed dominating live-out.
region_defs = set(substitutions)
for name, body in blocks.items():
    if name in [first, second, exit_block]:
        continue
    assert not (set(re.findall(token, body)) & region_defs), name
new_exit = []
for line in blocks[exit_block].splitlines(True):
    p = phi.match(line.rstrip('\n'))
    if p:
        values = incoming.findall(p[3])
        selected = [value for value, pred in values if pred == second]
        assert len(selected) == 1
        new_value = substitute(selected[0])
        line = line.rstrip('\n') + ', [ ' + new_value + ', %' + clone + ' ]\n'
        audit['successor_phi_additions'].append({'phi': p[1], 'value': new_value, 'predecessor': clone})
    new_exit.append(line)
assert len(audit['successor_phi_additions']) == 7
old_pred = blocks[replace_pred]
old_branch = '  br label %' + first + '\n'
assert old_pred.count(old_branch) == 1
new_pred = old_pred.replace(old_branch, '  br label %' + clone + '\n')
changed = function.replace(old_pred, new_pred, 1)
changed = changed.replace(blocks[first], first + ':\n' + ''.join(first_remainder), 1)
changed = changed.replace(blocks[exit_block], clone_text + ''.join(new_exit), 1)
result = src[:match.start()] + changed + src[match.end():]
assert result[:match.start()] == src[:match.start()]
assert result[match.start()+len(changed):] == src[match.end():]
# Calls, mutation/capture blocks, public signatures and metadata outside this
# single function are untouched. The clone has no calls, memcpy, or allocation.
assert not re.search(r'\b(?:call|invoke|alloca)\b', clone_text)
assert clone_text.count('  store ') == 1
assert clone_text.count(' = load ') == 1
assert clone_text.count(' = mul i64 ') == 32
assert clone_text.count(' = add i64 ') == 34
(D / 'candidate.opt.ll').write_text(result)
(D / 'continuation.patch').write_text(''.join(difflib.unified_diff(src.splitlines(True), result.splitlines(True), fromfile='control.opt.ll', tofile='candidate.opt.ll')))
audit['hashes'] = {name: hashlib.sha256((D / name).read_bytes()).hexdigest() for name in ['control.opt.ll', 'candidate.opt.ll', 'criterion.txt', 'prepare.py', 'continuation.patch']}
audit['dynamic_operations'] = 'Same store(reason), load(reason), select, 32 mul and 34 add operations; no calls. Exactly one continuation executes per incoming path.'
(D / 'transform.json').write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps({'phi_substitutions': len(audit['phi_substitutions']), 'renamed_definitions': len(audit['renamed_definitions']), 'successor_phis': len(audit['successor_phi_additions']), 'candidate_sha256': audit['hashes']['candidate.opt.ll']}, indent=2))
