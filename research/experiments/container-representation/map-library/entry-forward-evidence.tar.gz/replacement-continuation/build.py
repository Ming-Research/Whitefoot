#!/usr/bin/env python3
"""One-shot identical-pipeline native pair; no check or timing mode."""
from pathlib import Path
import hashlib,json,os,subprocess,time
assert os.environ.get('WHITEFOOT_CHECK_OWNER'), 'Repository host guard required'
ROOT=Path('/private/tmp/whitefoot-container-recovery-20261001')
D=Path(__file__).parent
PRIOR=Path('/private/tmp/whitefoot-map-replacement-disjoint-inline')
links=json.loads((PRIOR/'link-commands.json').read_text())['timed']
old=next(x for x in links if x.endswith('/entry-forward-wf-timed.o'))
assert links.count(old)==1
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(D/'control.opt.ll')=='e65bfc792c82e2e418c529ce29eef6c6ae09904a2787bea85264055aae748453'
assert sha(D/'candidate.opt.ll')=='3461fc9ca81e386ae4568f9c7e41129e34c59f4461fc93ccd6fe1b499d3a9b2a'
inputs=[D/'control.opt.ll',D/'candidate.opt.ll',D/'criterion.txt',D/'prepare.py',D/'build.py']
for x in links[1:links.index('-o')]:
 if x.endswith(('.o','.a')) and x!=old:
  p=Path(x);inputs.append(p if p.is_absolute() else ROOT/p)
(D/'build-inputs.json').write_text(json.dumps({str(p):sha(p) for p in inputs},indent=2)+'\n')
records=[]
def run(label,cmd):
 start=time.monotonic();r=subprocess.run(cmd,cwd=ROOT,capture_output=True)
 (D/(label+'.stdout')).write_bytes(r.stdout);(D/(label+'.stderr')).write_bytes(r.stderr)
 rec=dict(label=label,command=cmd,exit=r.returncode,seconds=time.monotonic()-start);records.append(rec)
 (D/'build-statuses.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(rec),flush=True)
 assert r.returncode==0
for arm in ['control','candidate']:
 obj=str(D/(arm+'.o'));exe=str(D/(arm+'-timed'))
 run(arm+'-object',['/usr/bin/clang','-O3','-Wno-override-module','-x','ir','-c',str(D/(arm+'.opt.ll')),'-o',obj])
 cmd=links.copy();cmd[cmd.index(old)]=obj;cmd[-1]=exe
 run(arm+'-link',cmd)
 run(arm+'-native',[os.environ['LLVM_OBJDUMP'],'-dr','--no-show-raw-insn',exe])
(D/'build-outputs.json').write_text(json.dumps({str(D/(a+s)):sha(D/(a+s)) for a in ['control','candidate'] for s in ['.o','-timed','-native.stdout']},indent=2)+'\n')
print('STOP: native review only; no correctness or timing executed.')
