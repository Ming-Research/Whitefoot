from pathlib import Path
import json,hashlib,subprocess,time,os
R=Path('<repository-root>');S=Path('<first-probe-retry-root>');D=Path(__file__).parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert os.environ.get('WHITEFOOT_CHECK_OWNER')
records=[]
def run(label,argv,expected=0,source=None):
 t=time.monotonic()
 with (D/f'{label}.stdout').open('wb') as out,(D/f'{label}.stderr').open('wb') as err:p=subprocess.run(argv,cwd=R,stdout=out,stderr=err)
 row=dict(label=label,argv=list(map(str,argv)),exit=p.returncode,expected=expected,seconds=time.monotonic()-t);records.append(row);(D/'check-statuses.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True);assert p.returncode==expected
 if source:
  for suffix in ['stdout','stderr']:assert (D/f'{label}.{suffix}').read_bytes()==(S/f'{source}.{suffix}').read_bytes(),(label,suffix)
inputs=json.loads((D/'inputs.json').read_text())
for p,h in inputs.items():assert sha(p)==h
old=json.loads((S/'build-statuses.json').read_text())
for arm in ['control','candidate']:
 argv=next(r['argv'] for r in old if r['label']=='control-account-link').copy();argv[-1]=str(D/f'{arm}-account');argv[1:1]=['-Wl,-order_file,'+str(D/f'{arm}.order')]
 for p in argv:
  if p.endswith(('.o','.a')):q=Path(p) if Path(p).is_absolute() else R/p;inputs[str(q)]=sha(q)
 (D/'check-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
 run(arm+'-account-link',argv)
 for row in json.loads((S/'check-statuses.json').read_text()):
  if not row['label'].startswith('control-') or 'maintained-' in row['label']:continue
  label=row['label'].replace('control-',arm+'-',1);argv=row['argv'].copy();argv[0]=str(D/(arm+'-account' if 'account' in argv[0] else arm+'-timed'))
  run(label,argv,row['exit'],row['label'])
run('maintained-source-control',[str(S/'control-hash-map-program')],0,'control-maintained-execute')
assert (D/'control-ledger.stdout').read_bytes()==(D/'candidate-ledger.stdout').read_bytes()
for p,h in inputs.items():assert sha(p)==h
images={str(D/f'{a}-{kind}'):sha(D/f'{a}-{kind}') for a in ['control','candidate'] for kind in ['timed','account']}
(D/'checked-images.json').write_text(json.dumps(images,indent=2)+'\n')
