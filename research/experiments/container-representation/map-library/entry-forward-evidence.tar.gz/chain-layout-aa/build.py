import pathlib,json,re,hashlib,struct,subprocess,time,os
R=pathlib.Path('<repository-root>')
S=pathlib.Path('<first-probe-retry-root>')
D=pathlib.Path(__file__).parent
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
raw=(S/'control-timed').read_bytes(); off=32
for _ in range(struct.unpack_from('<I',raw,16)[0]):
 cmd,size=struct.unpack_from('<II',raw,off)
 if cmd==0x19:
  for j in range(struct.unpack_from('<I',raw,off+64)[0]):
   q=off+72+j*80
   if raw[q:q+16].rstrip(b'\0')==b'__text': lo,length=struct.unpack_from('<QQ',raw,q+32)
 off+=size
syms=[(int(m[1],16),m[2]) for m in re.finditer(r'^([0-9a-f]+) <([^>]+)>:',(S/'control-native.stdout').read_text(),re.M) if lo<=int(m[1],16)<lo+length]
base=[n for _,n in syms]
chain='_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd'; moved='_wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad'
assert base.count(chain)==base.count(moved)==1
cand=base.copy();cand.remove(moved);cand.insert(cand.index(chain),moved)
for arm,names in [('control',base),('candidate',cand)]: (D/f'{arm}.order').write_text('\n'.join(names)+'\n')
original=next(x['argv'] for x in json.loads((S/'build-statuses.json').read_text()) if x['label']=='control-timed-link')
inputs={str((R/p).resolve() if not pathlib.Path(p).is_absolute() else pathlib.Path(p)):sha((R/p) if not pathlib.Path(p).is_absolute() else p) for p in original if p.endswith(('.o','.a'))}
inputs.update({str(D/'criterion.txt'):sha(D/'criterion.txt'),str(D/'build.py'):sha(D/'build.py')})
commands={}
for arm in ['control','candidate']:
 argv=original.copy();argv[-1]=str(D/f'{arm}-timed');argv[1:1]=['-Wl,-order_file,'+str(D/f'{arm}.order')]
 commands[arm]=argv;inputs[str(D/f'{arm}.order')]=sha(D/f'{arm}.order')
(D/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n');(D/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
if len(__import__('sys').argv)==1: print('Prepared',len(base),'ordered text symbols');raise SystemExit
assert os.environ.get('WHITEFOOT_CHECK_OWNER'),'guard required'
records=[]
def run(label,argv):
 start=time.monotonic()
 with (D/f'{label}.stdout').open('wb') as out,(D/f'{label}.stderr').open('wb') as err:p=subprocess.run(argv,cwd=R,stdout=out,stderr=err)
 row=dict(label=label,argv=argv,exit=p.returncode,seconds=time.monotonic()-start);records.append(row);(D/'statuses.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True);assert p.returncode==0
for arm in ['control','candidate']:
 assert not (D/f'{arm}-timed').exists()
 run(arm+'-link',commands[arm])
 run(arm+'-native',['<LLVM_OBJDUMP>','--disassemble','--no-show-raw-insn',str(D/f'{arm}-timed')])
assert all(sha(p)==v for p,v in inputs.items())
(D/'images.json').write_text(json.dumps({str(D/f'{a}-timed'):sha(D/f'{a}-timed') for a in ['control','candidate']},indent=2)+'\n')
