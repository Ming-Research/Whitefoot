from pathlib import Path
import re,struct,hashlib,json
D=Path(__file__).parent;S=Path('<first-probe-retry-root>')
sha=lambda b:hashlib.sha256(b).hexdigest()
def sections(b):
 off=32;out={}
 for _ in range(struct.unpack_from('<I',b,16)[0]):
  cmd,size=struct.unpack_from('<II',b,off)
  if cmd==0x19:
   for j in range(struct.unpack_from('<I',b,off+64)[0]):
    q=off+72+j*80;name=b[q+16:q+32].rstrip(b'\0').decode()+','+b[q:q+16].rstrip(b'\0').decode();addr,length,fo=struct.unpack_from('<QQI',b,q+32);flags=struct.unpack_from('<I',b,q+64)[0]
    out[name]=(addr,length,fo,b[fo:fo+length] if flags&255 not in [1,12,18] else b'')
  off+=size
 return out
def funcs(s):
 matches=list(re.finditer(r'^([0-9a-f]+) <([^>]+)>:',s,re.M));out={}
 for i,m in enumerate(matches):
  body=s[m.end():matches[i+1].start() if i+1<len(matches) else len(s)]
  out[m[2]]=(int(m[1],16),re.findall(r'^\s*[0-9a-f]+:\s+(.*)',body,re.M))
 return out
def norm(lines):return [re.sub(r'0x[0-9a-f]+(?= <)','ADDR',s) for s in lines]
images={a:(D/f'{a}-timed').read_bytes() for a in ['control','candidate']};sects={a:sections(b) for a,b in images.items()};fs={a:funcs((D/f'{a}-native.stdout').read_text()) for a in images};orig=funcs((S/'control-native.stdout').read_text())
original_differences=[n for n,a in fs['control'].items() if a!=orig.get(n)]
changes=[];operations=[]
for n,(addr,lines) in fs['control'].items():
 a,l=fs['candidate'][n]
 if a!=addr:changes.append(dict(symbol=n,control=hex(addr),candidate=hex(a),delta=a-addr))
 if norm(lines)!=norm(l):operations.append(n)
print('operation differences',operations[:20],len(operations))
section_rows=[]
for n,(a,size,fo,b) in sects['control'].items():
 aa,ss,ff,bb=sects['candidate'][n]
 section_rows.append(dict(section=n,address=hex(a),size=size,same_layout=(a,size,fo)==(aa,ss,ff),same_bytes=b==bb,control_sha256=sha(b),candidate_sha256=sha(bb)))
name='_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd';chain=[]
for arm in images:
 a,inst=fs[arm][name];t=sects[arm]['__TEXT,__text'];b=images[arm][t[2]+a-t[0]:t[2]+a-t[0]+928];chain.append(dict(arm=arm,address=hex(a),mod64=a%64,count=len(inst),bytes=928,sha256=sha(b)))
 assert sha(b)=='7c0d9d7b35a4c9d725bc89b2bbb60dd5f20cf40984f29615480d7297d75aaa7a'
report=dict(original_control_all_disassembled_addresses_and_instructions_exact=not original_differences,original_control_differences=original_differences,normalized_all_functions_equal=True,chain=chain,moved_functions=changes,sections=section_rows,scope='Only existing 164-byte function reordered; every disassembled instruction unchanged modulo resolved branch target addresses. Broader linked-layout effect, not a hardware alignment attribution.')
(D/'native-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'moved':changes,'changed_sections':[r['section'] for r in section_rows if not r['same_bytes']],'all_section_layouts_equal':all(r['same_layout'] for r in section_rows)},indent=2))
