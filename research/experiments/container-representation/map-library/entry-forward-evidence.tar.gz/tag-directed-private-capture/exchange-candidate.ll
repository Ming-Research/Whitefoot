define void @wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(24) %v0, i64 %v1, i64 %v2, ptr %wf.arg.v3) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.1 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  %wf.slot.2 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.3 = alloca %wf.t.d72ca22fbd302a84, align 8
  %v5 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v3, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  store %wf.t.dceb7b9db1c9ad1d zeroinitializer, ptr %v5
  %t0 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v5, i32 0, i32 0
  store i32 2, ptr %t0
  %t1 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v5, i32 0, i32 1
  store i64 %v2, ptr %t1
  %t2 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v5, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t2, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %v6 = getelementptr i8, ptr %v0, i64 0
  %t4 = getelementptr inbounds { i64, i64, ptr }, ptr %v6, i32 0, i32 2
  %t5 = load ptr, ptr %t4
  %t3.nonnegative = icmp sge i64 %v1, 0
  call void @llvm.assume(i1 %t3.nonnegative)
  %t3 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %t5, i64 %v1
  %v7 = getelementptr i8, ptr %t3, i64 0
  %capture.tag.address = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v7, i32 0, i32 0
  %t7 = load i32, ptr %capture.tag.address
  switch i32 %t7, label %invalid.tag.b0 [
    i32 0, label %commit.slot
    i32 1, label %commit.slot
    i32 2, label %capture.filled
  ]
capture.filled:
  %capture.key.source = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v7, i32 0, i32 1
  %capture.key = load i64, ptr %capture.key.source
  %capture.key.destination = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.1, i32 0, i32 1
  store i64 %capture.key, ptr %capture.key.destination
  %capture.value.source = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v7, i32 0, i32 2
  %capture.value.destination = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.1, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %capture.value.destination, ptr %capture.value.source, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  br label %commit.slot
commit.slot:
  call void @llvm.memcpy.p0.p0.i64(ptr %v7, ptr %v5, i64 ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i32 1) to i64), i1 false)
  switch i32 %t7, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
    i32 2, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  store %wf.t.114ba5754d75c8d6 zeroinitializer, ptr %wf.result
  %t8 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t8
  ret void
bb2:
  store %wf.t.114ba5754d75c8d6 zeroinitializer, ptr %wf.result
  %t9 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t9
  ret void
bb3:
  %t10 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.1, i32 0, i32 1
  %v12 = load i64, ptr %t10
  %t11 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.1, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %t11, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  store %wf.t.d72ca22fbd302a84 zeroinitializer, ptr %wf.slot.3
  %t12 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.3, i32 0, i32 0
  store i64 %v12, ptr %t12
  %t13 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.3, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %wf.slot.2, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %v15 = or i1 0, 0
  store %wf.t.114ba5754d75c8d6 zeroinitializer, ptr %wf.result
  %t14 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t14
  %t15 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.result, i32 0, i32 1
  store i1 %v15, ptr %t15
  %t16 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %wf.slot.3, i64 ptrtoint (ptr getelementptr (%wf.t.d72ca22fbd302a84, ptr null, i32 1) to i64), i1 false)
  ret void
}
