00000001000ab734 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449>:
1000ab734:     	stp	d15, d14, [sp, #-0x40]!
1000ab738:     	stp	d13, d12, [sp, #0x10]
1000ab73c:     	stp	d11, d10, [sp, #0x20]
1000ab740:     	stp	d9, d8, [sp, #0x30]
1000ab744:     	ldp	q0, q1, [x4]
1000ab748:     	ldp	q2, q3, [x4, #0x20]
1000ab74c:     	ldp	q4, q5, [x4, #0x40]
1000ab750:     	ldp	q6, q7, [x4, #0x60]
1000ab754:     	ldp	q16, q17, [x4, #0x80]
1000ab758:     	ldp	q18, q19, [x4, #0xa0]
1000ab75c:     	ldp	q20, q21, [x4, #0xc0]
1000ab760:     	ldp	q22, q23, [x4, #0xe0]
1000ab764:     	ldr	x8, [x1, #0x10]
1000ab768:     	mov	w9, #0x110              ; =272
1000ab76c:     	madd	x10, x2, x9, x8
1000ab770:     	ldr	w9, [x10]
1000ab774:     	cmp	w9, #0x2
1000ab778:     	b.hs	0x1000ab780 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449+0x4c>
1000ab77c:     	b	0x1000ab7c4 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449+0x90>
1000ab780:     	ldur	q24, [x10, #0x8]
1000ab784:     	ldur	q25, [x10, #0x18]
1000ab788:     	ldur	q26, [x10, #0x28]
1000ab78c:     	ldur	q27, [x10, #0x38]
1000ab790:     	ldur	q28, [x10, #0x48]
1000ab794:     	ldur	q29, [x10, #0x58]
1000ab798:     	ldur	q30, [x10, #0x68]
1000ab79c:     	ldur	q31, [x10, #0x78]
1000ab7a0:     	ldur	q8, [x10, #0x88]
1000ab7a4:     	ldur	q9, [x10, #0x98]
1000ab7a8:     	ldur	q10, [x10, #0xa8]
1000ab7ac:     	ldur	q11, [x10, #0xb8]
1000ab7b0:     	ldur	q12, [x10, #0xc8]
1000ab7b4:     	ldur	q13, [x10, #0xd8]
1000ab7b8:     	ldur	q14, [x10, #0xe8]
1000ab7bc:     	ldur	q15, [x10, #0xf8]
1000ab7c0:     	ldr	x8, [x10, #0x108]
1000ab7c4:     	mov	w11, #0x2               ; =2
1000ab7c8:     	str	w11, [x10]
1000ab7cc:     	str	x3, [x10, #0x8]
1000ab7d0:     	stp	q0, q1, [x10, #0x10]
1000ab7d4:     	stp	q2, q3, [x10, #0x30]
1000ab7d8:     	stp	q4, q5, [x10, #0x50]
1000ab7dc:     	stp	q6, q7, [x10, #0x70]
1000ab7e0:     	stp	q16, q17, [x10, #0x90]
1000ab7e4:     	stp	q18, q19, [x10, #0xb0]
1000ab7e8:     	stp	q20, q21, [x10, #0xd0]
1000ab7ec:     	stp	q22, q23, [x10, #0xf0]
1000ab7f0:     	cbz	w9, 0x1000ab7fc <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449+0xc8>
1000ab7f4:     	cmp	w9, #0x1
1000ab7f8:     	b.ne	0x1000ab838 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449+0x104>
1000ab7fc:     	movi.2d	v0, #0000000000000000
1000ab800:     	stp	q0, q0, [x0, #0xf0]
1000ab804:     	stp	q0, q0, [x0, #0xd0]
1000ab808:     	stp	q0, q0, [x0, #0xb0]
1000ab80c:     	stp	q0, q0, [x0, #0x90]
1000ab810:     	stp	q0, q0, [x0, #0x70]
1000ab814:     	stp	q0, q0, [x0, #0x50]
1000ab818:     	stp	q0, q0, [x0, #0x30]
1000ab81c:     	stp	q0, q0, [x0, #0x10]
1000ab820:     	str	q0, [x0]
1000ab824:     	ldp	d9, d8, [sp, #0x30]
1000ab828:     	ldp	d11, d10, [sp, #0x20]
1000ab82c:     	ldp	d13, d12, [sp, #0x10]
1000ab830:     	ldp	d15, d14, [sp], #0x40
1000ab834:     	ret
1000ab838:     	str	xzr, [x0]
1000ab83c:     	mov	w9, #0x1                ; =1
1000ab840:     	str	w9, [x0]
1000ab844:     	stur	q24, [x0, #0x8]
1000ab848:     	stur	q25, [x0, #0x18]
1000ab84c:     	stur	q26, [x0, #0x28]
1000ab850:     	stur	q27, [x0, #0x38]
1000ab854:     	stur	q28, [x0, #0x48]
1000ab858:     	stur	q29, [x0, #0x58]
1000ab85c:     	stur	q30, [x0, #0x68]
1000ab860:     	stur	q31, [x0, #0x78]
1000ab864:     	stur	q8, [x0, #0x88]
1000ab868:     	stur	q9, [x0, #0x98]
1000ab86c:     	stur	q10, [x0, #0xa8]
1000ab870:     	stur	q11, [x0, #0xb8]
1000ab874:     	stur	q12, [x0, #0xc8]
1000ab878:     	stur	q13, [x0, #0xd8]
1000ab87c:     	stur	q14, [x0, #0xe8]
1000ab880:     	stur	q15, [x0, #0xf8]
1000ab884:     	str	x8, [x0, #0x108]
1000ab888:     	ldp	d9, d8, [sp, #0x30]
1000ab88c:     	ldp	d11, d10, [sp, #0x20]
1000ab890:     	ldp	d13, d12, [sp, #0x10]
1000ab894:     	ldp	d15, d14, [sp], #0x40
1000ab898:     	ret

