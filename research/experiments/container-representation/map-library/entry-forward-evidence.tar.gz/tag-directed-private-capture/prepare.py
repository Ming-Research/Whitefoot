#!/usr/bin/env python3
"""One-shot typed swap/consume attribution replay; read/write preparation only."""
from pathlib import Path
import re,json,hashlib,difflib
D=Path(__file__).parent
SOURCE=Path('/private/tmp/whitefoot-mutation-home-mask/control.raw.ll')
EXPECTED='09cb4c4ea979d9dedb46dbc2bcb267d984d472777f0a69f4af86df68ede57b41'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(SOURCE)==EXPECTED
source=SOURCE.read_text();symbol='wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449'
m=re.search(r'^define [^\n]*@'+re.escape(symbol)+r'\([^\n]*\{\n.*?^}\n',source,re.M|re.S);assert m
old=m.group();a=old.index('  %v8 = call i8 @wf_swap$instance$9eabc50a9cce2251(');b=old.index('invalid.tag.b0:\n',a)
replacement='''  %capture.tag.address = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v7, i32 0, i32 0
  %t7 = load i32, ptr %capture.tag.address
  switch i32 %t7, label %invalid.tag.b0 [
    i32 0, label %commit.slot
    i32 1, label %commit.slot
    i32 2, label %capture.filled
  ]
capture.filled:
  %capture.key.source = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v7, i32 0, i32 1
  %capture.key = load i64, ptr %capture.key.source
  %capture.key.destination = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.1, i32 0, i32 1
  store i64 %capture.key, ptr %capture.key.destination
  %capture.value.source = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v7, i32 0, i32 2
  %capture.value.destination = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.1, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %capture.value.destination, ptr %capture.value.source, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  br label %commit.slot
commit.slot:
  call void @llvm.memcpy.p0.p0.i64(ptr %v7, ptr %v5, i64 ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i32 1) to i64), i1 false)
  switch i32 %t7, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
    i32 2, label %bb3
  ]
'''
new=old[:a]+replacement+old[b:]
assert old[:a]==new[:a] # offered capture/construction and pointer derivation
assert new[new.index('invalid.tag.b0:\n'):]==old[b:] # all result construction
assert new.splitlines()[0]==old.splitlines()[0]
assert new.count(' zeroinitializer,')==old.count(' zeroinitializer,')
assert '%wf.result' not in replacement
assert '@llvm.memcpy.p0.p0.i64' in source
candidate=source[:m.start()]+new+source[m.end():]
assert candidate[:m.start()]==source[:m.start()] and candidate[m.start()+len(new):]==source[m.end():]
(D/'control.raw.ll').write_text(source);(D/'candidate.raw.ll').write_text(candidate)
(D/'exchange-original.ll').write_text(old);(D/'exchange-candidate.ll').write_text(new)
(D/'modules.patch').write_text(''.join(difflib.unified_diff(source.splitlines(True),candidate.splitlines(True),fromfile='control.raw.ll',tofile='candidate.raw.ll')))
record={'source':str(SOURCE),'modified_function':symbol,'callers_changed':False,'signature_or_attributes_changed':False,'removed_primitive_call':'wf_swap$instance$9eabc50a9cce2251 in this function only; primitive definition unchanged','prefix_unchanged':True,'result_construction_suffix_unchanged':True,'new_external_write':'same whole272B slot memcpy as primitive, followed by unchanged result writes','capture':'tag first; tag2 key64+Record256 into private old-slot fields; tag0/1 none','hashes':{name:sha(D/name) for name in ['criterion.txt','prepare.py','control.raw.ll','candidate.raw.ll','exchange-original.ll','exchange-candidate.ll','modules.patch']}}
(D/'preparation.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
