#!/usr/bin/env python3
"""Frozen accounted twins and existing controls only; no timing."""
from pathlib import Path
import hashlib,json,os,subprocess,time
ROOT=Path('/private/tmp/whitefoot-container-recovery-20261001');D=Path(__file__).parent
assert os.environ.get('WHITEFOOT_CHECK_OWNER'), 'Repository host guard required'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p,h in json.loads((D/'native-inputs.json').read_text()).items():assert sha(p)==h,p
for p,h in json.loads((D/'native-outputs.json').read_text()).items():assert sha(D/p)==h,p
prior=Path('/private/tmp/whitefoot-map-replacement-disjoint-inline')
link=json.loads((prior/'link-commands.json').read_text())['account']
old=next(x for x in link if x.endswith('/entry-forward-wf-account.o'))
assert link.count(old)==1
inputs=[D/'account-check.py'];remaps={}
for arm in ['control','candidate']:
 text=(D/(arm+'-wf-timed.ll')).read_text();counts={}
 for oldname,newname in [('@malloc(', '@wf_cost_allocate('),('@realloc(', '@wf_cost_reallocate('),('@free(', '@wf_cost_release(')]:
  counts[oldname]=text.count(oldname);text=text.replace(oldname,newname)
 assert counts['@malloc(']>0 and counts['@free(']>0
 p=D/(arm+'-account.ll');p.write_text(text);inputs.append(p);remaps[arm]=counts
for arg in link[1:link.index('-o')]:
 if arg.endswith(('.o','.a')) and arg!=old:
  p=Path(arg);inputs.append(p if p.is_absolute() else ROOT/p)
(D/'account-inputs.json').write_text(json.dumps({'hashes':{str(p):sha(p) for p in inputs},'remaps':remaps,'preparation':'Only allocator declaration/call symbol replacements in each frozen ordinary raw module with only host-main symbol rename; identical single-O3 object stage and prior frozen account link recipe. No driver, oracle, fault or ledger source edits.'},indent=2)+'\n')
records=[]
def run(label,cmd,expected=0,message=None):
 start=time.monotonic();r=subprocess.run(cmd,cwd=ROOT,capture_output=True)
 (D/(label+'.stdout')).write_bytes(r.stdout);(D/(label+'.stderr')).write_bytes(r.stderr)
 record=dict(label=label,command=cmd,exit=r.returncode,seconds=time.monotonic()-start,expected=expected);records.append(record)
 (D/'account-check-statuses.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True)
 assert r.returncode==expected,record
 if message is not None:assert r.stderr.decode().strip()=='mutation: '+message,r.stderr
 return r.stdout
for arm in ['control','candidate']:
 obj=str(D/(arm+'-account.o'));exe=str(D/(arm+'-account'))
 run(arm+'-account-object',['/usr/bin/clang','-O3','-Wno-override-module','-x','ir','-c',str(D/(arm+'-account.ll')),'-o',obj])
 cmd=link.copy();cmd[cmd.index(old)]=obj;cmd[-1]=exe;run(arm+'-account-link',cmd)
faults={'wrong-batch-checksum':'negative wrong batch checksum','stale-generation':'negative stale generation','corrupt-last-word':'negative corrupt last word full-content','cleanup':'negative cleanup checksum','ledger-leak':'negative ledger leak','filled-allocation':'negative filled allocation'}
ledgers=[]
for arm in ['control','candidate']:
 for kind in ['timed','account']:
  exe=str(D/(arm+'-'+kind))
  out=run(arm+'-'+kind+'-check',[exe,'check'])
  assert out.decode().strip()=='mutation: 96 independent owner/three-successive-batches/verify/cleanup cases passed',out
  for fault,message in faults.items():
   if kind=='timed' and fault in ['ledger-leak','filled-allocation']:continue
   run(arm+'-'+kind+'-'+fault,[exe,'negative',fault],1,message)
 ledgers.append(run(arm+'-ledger',[str(D/(arm+'-account')),'account']))
assert ledgers[0]==ledgers[1],'Allocation ledgers differ'
# Existing previous-frozen ledger additionally provides an independent baseline.
prior_ledger=Path('/private/tmp/whitefoot-map-replacement-input-disjoint/control-ledger.stdout').read_bytes()
assert ledgers[0]==prior_ledger,'Ledger differs from prior frozen baseline'
checks=records[4:];assert len(checks)==26
summary={'build_stages':4,'check_stages':26,'positive_cases_per_image':96,'positive_images':4,'negative_exact_exits_and_diagnostics':20,'ledger_equal_to_each_other_and_prior':True,'ledger_sha256':hashlib.sha256(ledgers[0]).hexdigest(),'build_seconds':sum(x['seconds'] for x in records[:4]),'check_seconds':sum(x['seconds'] for x in checks),'images':{str(D/(a+'-'+k)):sha(D/(a+'-'+k)) for a in ['control','candidate'] for k in ['timed','account']}}
(D/'account-check-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
