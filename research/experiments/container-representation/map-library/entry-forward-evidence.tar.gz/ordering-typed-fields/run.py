#!/usr/bin/env python3
"""One-shot typed-field result-before-commit diagnostic; retire with its recorded result.
prepare is read/write only. build/check require the repository host guard.
No compiler build, source modification, or timing mode exists.
"""
import difflib, hashlib, json, os, pathlib, subprocess, sys, time
ROOT = pathlib.Path('/private/tmp/whitefoot-container-recovery-20261001')
D = ROOT / 'research/experiments/container-representation/map-library/.build/lookup-api/mutation-screen'
CONTROL = pathlib.Path('/private/tmp/whitefoot-map-replacement-disjoint')
OUT = pathlib.Path('/private/tmp/whitefoot-map-replacement-ordering-fields')
SOURCE = CONTROL / 'candidate.raw.ll'
EXPECTED = 'd8cc8d5969f211447e7069098d62ea07168349dc3f54b5b936bc8a39ca85f359'
SYMBOLS = ['wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d',
           'wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449']
OBJDUMP = os.environ['LLVM_OBJDUMP']  # Measured instrument: LLVM22.1.8.
def sha(path): return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def absolute(value):
    path = pathlib.Path(value)
    return path if path.is_absolute() else ROOT / path
mode = sys.argv[1] if len(sys.argv) == 2 else ''
assert mode in ['prepare', 'build', 'check'], 'Use prepare, build, or check; timing is not authorized.'
assert sha(SOURCE) == EXPECTED, 'Frozen input changed'
links = {r['label'].split()[0]: r['command'] for r in json.loads(pathlib.Path('/private/tmp/whitefoot-entry-forward-images.json').read_text()) if r['label'].endswith(' link')}
if mode == 'prepare':
    OUT.mkdir(exist_ok=True)
    original = SOURCE.read_text()
    import re
    def definition(text, symbol):
        matches = list(re.finditer(r'^define [^\n]*@' + re.escape(symbol) + r'\([^\n]*\{\n.*?^}\n', text, re.M | re.S))
        assert len(matches) == 1, symbol
        return matches[0].group(0)
    symbol = SYMBOLS[1] + '.disjoint_floor'
    old_body = definition(original, symbol)
    new_body = """define void @wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449.disjoint_floor(ptr noalias %wf.result, ptr noalias nonnull captures(none) dereferenceable(24) %v0, i64 %v1, i64 %v2, ptr %wf.arg.v3) #0 {
entry:
  %offered = alloca %wf.t.862971f7a971a883, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %offered, ptr %wf.arg.v3, i64 256, i1 false)
  %payload.address = getelementptr inbounds { i64, i64, ptr }, ptr %v0, i32 0, i32 2
  %payload = load ptr, ptr %payload.address
  %index.nonnegative = icmp sge i64 %v1, 0
  call void @llvm.assume(i1 %index.nonnegative)
  %slot = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %payload, i64 %v1
  %old.tag = load i32, ptr %slot
  switch i32 %old.tag, label %invalid.tag [
    i32 0, label %inserted
    i32 1, label %inserted
    i32 2, label %replaced
  ]
invalid.tag:
  unreachable
inserted:
  store %wf.t.114ba5754d75c8d6 zeroinitializer, ptr %wf.result
  br label %commit
replaced:
  store %wf.t.114ba5754d75c8d6 zeroinitializer, ptr %wf.result
  store i32 1, ptr %wf.result
  %result.reason = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.result, i32 0, i32 1
  store i1 false, ptr %result.reason
  %old.key.address = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %slot, i32 0, i32 1
  %old.key = load i64, ptr %old.key.address
  %result.pair = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.result, i32 0, i32 2
  %result.key = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %result.pair, i32 0, i32 0
  store i64 %old.key, ptr %result.key
  %old.value = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %slot, i32 0, i32 2
  %result.value = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %result.pair, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %result.value, ptr %old.value, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  br label %commit
commit:
  store %wf.t.dceb7b9db1c9ad1d zeroinitializer, ptr %slot
  store i32 2, ptr %slot
  %slot.key = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %slot, i32 0, i32 1
  store i64 %v2, ptr %slot.key
  %slot.value = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %slot, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %slot.value, ptr %offered, i64 256, i1 false)
  ret void
}
"""
    assert old_body.splitlines()[0] == new_body.splitlines()[0]
    changed = original.replace(old_body, new_body, 1)
    assert changed.replace(new_body, old_body, 1) == original
    (OUT / 'callgraph.json').write_bytes((CONTROL / 'callgraph.json').read_bytes())
    assert 'attributes #0 = { "probe-stack"="__chkstk_darwin" }' in original
    (OUT / 'candidate.raw.ll').write_text(changed)
    (OUT / 'modules.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True), changed.splitlines(True), fromfile='result-only-control.raw.ll', tofile='candidate.raw.ll')))
    paths = {SOURCE, CONTROL / 'candidate-wf-timed.o', CONTROL / 'candidate-timed', CONTROL / 'candidate-account', D / 'driver-mutation.c'}
    for kind, command in links.items():
        for arg in command[1:command.index('-o')]:
            if arg.endswith(('.o', '.a')): paths.add(absolute(arg))
        baseline = original.replace('define i32 @main(', 'define i32 @mutation_unused_main(')
        candidate = changed.replace('define i32 @main(', 'define i32 @mutation_unused_main(')
        if kind == 'account':
            for old, new in [('@malloc(', '@wf_cost_allocate('), ('@realloc(', '@wf_cost_reallocate('), ('@free(', '@wf_cost_release(')]:
                baseline, candidate = baseline.replace(old, new), candidate.replace(old, new)
        frozen = CONTROL / ('candidate-wf-' + kind + '.ll')
        assert baseline == frozen.read_text(), 'Remapping differs from measured input'
        paths.add(frozen)
        target = OUT / ('candidate-wf-' + kind + '.ll')
        target.write_text(candidate)
        paths.add(target)
    paths.add(OUT / 'candidate.raw.ll')
    paths.add(pathlib.Path(__file__))
    paths.add(OUT / 'criterion.txt')
    paths.add(OUT / 'callgraph.json')
    (OUT / 'inputs.json').write_text(json.dumps({str(p): sha(p) for p in sorted(paths)}, indent=2) + '\n')
    (OUT / 'link-commands.json').write_text(json.dumps(links, indent=2) + '\n')
    print('Prepared one cloned-body ordering patch and frozen input manifest:', OUT)
    sys.exit(0)
assert os.environ.get('WHITEFOOT_CHECK_OWNER'), 'Run through perl .github/run-check.pl'
for path, digest in json.loads((OUT / 'inputs.json').read_text()).items():
    assert sha(path) == digest, path
records = []
def run(label, command, expected=0, message=None):
    start = time.monotonic()
    result = subprocess.run([str(x) for x in command], cwd=ROOT, capture_output=True, text=True)
    (OUT / (label + '.stdout')).write_text(result.stdout)
    (OUT / (label + '.stderr')).write_text(result.stderr)
    record = dict(label=label, command=[str(x) for x in command], exit=result.returncode, seconds=time.monotonic()-start)
    records.append(record)
    (OUT / (mode + '-statuses.json')).write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    assert result.returncode == expected, record
    if message: assert result.stderr.strip() == 'mutation: ' + message, result.stderr
    return result.stdout
if mode == 'build':
    for kind, command in links.items():
        obj = OUT / ('candidate-wf-' + kind + '.o')
        run(kind + '-object', ['/usr/bin/clang', '-O3', '-Wno-override-module', '-x', 'ir', '-c', obj.with_suffix('.ll'), '-o', obj])
        command = list(command)
        old = str(D / ('entry-forward-wf-' + kind + '.o'))
        assert command.count(old) == 1
        command[command.index(old)] = str(obj)
        command[-1] = str(OUT / ('candidate-' + kind))
        run(kind + '-link', command)
    for label, path in [('control', CONTROL / 'candidate-timed'), ('candidate', OUT / 'candidate-timed')]:
        run(label + '-native', [OBJDUMP, '-dr', '--no-show-raw-insn', path])
    (OUT / 'outputs.json').write_text(json.dumps({str(p): sha(p) for p in OUT.glob('candidate-*') if p.suffix != '.ll'}, indent=2) + '\n')
    print('STOP: root must review the native gate before correctness or timing.')
else:
    faults = {'wrong-batch-checksum': 'negative wrong batch checksum', 'stale-generation': 'negative stale generation', 'corrupt-last-word': 'negative corrupt last word full-content', 'cleanup': 'negative cleanup checksum', 'ledger-leak': 'negative ledger leak', 'filled-allocation': 'negative filled allocation'}
    ledgers = []
    for arm, prefix in [('control', CONTROL / 'candidate'), ('candidate', OUT / 'candidate')]:
        for kind in ['timed', 'account']:
            exe = str(prefix) + '-' + kind
            run(arm + '-' + kind + '-check', [exe, 'check'])
            for fault, message in faults.items():
                if kind == 'timed' and fault in ['ledger-leak', 'filled-allocation']: continue
                run(arm + '-' + kind + '-' + fault, [exe, 'negative', fault], 1, message)
        ledgers.append(run(arm + '-ledger', [str(prefix) + '-account', 'account']))
    assert ledgers[0] == ledgers[1], 'Allocation ledgers differ'
    print('Existing broad controls and exact account equality passed. No timing launched.')
