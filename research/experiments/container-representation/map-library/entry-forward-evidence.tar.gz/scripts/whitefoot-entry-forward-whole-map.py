#!/usr/bin/env python3
"""One-shot current HashMap collateral replay; retire after this comparison.
Root runs this under .github/run-check.pl. No compiler build or source changes.
"""
import csv
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time

root = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
assert os.environ.get('WHITEFOOT_CHECK_OWNER'), 'Run under run-check.pl'
out.mkdir(parents=True, exist_ok=False)
v = root / 'research/experiments/container-representation/map-library'
d = v / '.build/lookup-api/mutation-screen'
shared = out / 'shared'
shared.mkdir()
config = (v / '.build/lookup-api/enum-domain/configuration.txt').read_text().splitlines()
absl_compile, absl_link = shlex.split(config[15]), shlex.split(config[16])
assert (Path(config[13]) / 'include/absl/container/flat_hash_map.h').is_file()
clis = {'control': d / 'whitefootc-running-index', 'candidate': d / 'whitefootc-entry-forward'}
runtime_root = root / 'compiler/src/backend'
runtime_names = ['ordinary_values', 'sched/core', 'sched/entry', 'completion/runtime',
                 'completion/file_adapter', 'completion/bridge', 'wf_floor', 'sched/prim_host',
                 'completion/wait_host', 'completion/file_posix', 'completion/linux_io_uring']
runtime = [shared / 'native' / (n + '.o') for n in runtime_names]
runtime.append(shared / 'native/ordinary_values_ir.o')
sources = [v / n for n in ['map-library.wf', 'map-ecosystem.c', 'map-ecosystem.rs',
                           'map-ecosystem.cpp', 'map-costs.c', 'map-oracle.h', 'Makefile']]
sources += [v.parent / n for n in ['ecosystem.mk', 'ecosystem-allocator.rs', 'ecosystem-allocator.hpp']]
sources += [root / 'compiler/runtime.mk', runtime_root / 'ordinary_values_ir.ll']
sources += [runtime_root / (n + '.c') for n in runtime_names]
sources += sorted(runtime_root.glob('*.h')) + sorted((runtime_root / 'sched').glob('*.h'))
sources += sorted((runtime_root / 'completion').glob('*.h'))
sources += sorted((root / 'lib/std/collections/hash_map').glob('*'))
sources += list(clis.values())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pins = {str(p): sha(p) for p in sources if p.is_file()}
statuses = []
metadata = {'protocol': {'work': 262144, 'samples': 11, 'cohorts': 2,
                        'cells': 84, 'rows_per_process': 4620, 'measure_deadline_s': 180,
                        'order': ['control-c0', 'candidate-c0', 'candidate-c1', 'control-c1'],
                        'paths': ['hit', 'miss', 'replace', 'churn', 'edit', 'setup', 'grow'],
                        'retained_callbacks': False, 'explicit_rehash_timing': False},
            'source_pins': pins, 'shared_inputs': 'freshly compiled once from current sources',
            'configuration_flags_source': str(v / '.build/lookup-api/enum-domain/configuration.txt'),
            'absl_compile': absl_compile, 'absl_link': absl_link}
(out / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
(out / 'map-library.wf').write_bytes((v / 'map-library.wf').read_bytes())

def save():
    (out / 'statuses.json').write_text(json.dumps(statuses, indent=2) + '\n')

def run(label, argv, limit=120, expected=0, message=None, csv_output=False):
    argv = list(map(str, argv))
    stdout = out / (label + ('.csv' if csv_output else '.stdout'))
    stderr = out / (label + '.stderr')
    started = time.monotonic()
    print('START', label, shlex.join(argv), flush=True)
    result = {'label': label, 'argv': argv, 'cwd': str(root), 'deadline_s': limit,
              'expected_exit': expected, 'stdout': str(stdout), 'stderr': str(stderr)}
    with stdout.open('wb') as so, stderr.open('wb') as se:
        try:
            process = subprocess.run(argv, cwd=root, stdout=so, stderr=se, timeout=limit)
            result['exit'] = process.returncode
        except subprocess.TimeoutExpired:
            result['exit'] = None
            result['timeout'] = True
    result['wall_s'] = time.monotonic() - started
    statuses.append(result)
    save()
    print('END', label, result.get('exit'), result['wall_s'], flush=True)
    assert result['exit'] == expected, result
    if message is not None:
        assert stdout.read_bytes() == b'', label + ': unexpected stdout'
        assert stderr.read_text().strip() == message, label + ': wrong negative diagnostic'
    return stdout

run('runtime-build', ['make', '-C', v, '-j2', 'BUILD=' + str(shared), *runtime])
for mode in ['timed', 'account']:
    account = ['-DACCOUNT_ONLY'] if mode == 'account' else []
    run('rust-' + mode, ['rustc', '--edition=2024', '-C', 'opt-level=3', '-C', 'panic=abort',
        '-D', 'warnings', '--crate-type', 'staticlib', '--crate-name', 'map_ecosystem',
        '--print', 'native-static-libs', *(['--cfg', 'account_only'] if account else []),
        v / 'map-ecosystem.rs', '-o', shared / ('rust-' + mode + '.a')])
    run('cpp-' + mode, ['clang++', '-DECOSYSTEM', '-std=c++20', '-O3', '-DNDEBUG',
        '-Wall', '-Wextra', '-Werror', *absl_compile, *account, '-c', v / 'map-ecosystem.cpp',
        '-o', shared / ('cpp-' + mode + '.o')])
    for stem, source, extra in [('driver', 'map-ecosystem.c', []),
                                ('control', 'map-costs.c', ['-DECO_MAP_CONTROL'])]:
        run(stem + '-' + mode, ['clang', '-DECOSYSTEM', '-std=c11', '-O3', '-Wall',
            '-Wextra', '-Werror', *extra, *account, '-c', v / source,
            '-o', shared / (stem + '-' + mode + '.o')])

for arm, cli in clis.items():
    home = out / arm
    home.mkdir()
    run(arm + '-emit', [cli, '--emit-llvm', v / 'map-library.wf', '-o', home / 'map.raw.ll'])
    raw = (home / 'map.raw.ll').read_text()
    for mode in ['timed', 'account']:
        text = raw.replace('@main(', '@wf_fixture_main(')
        if mode == 'account':
            text = text.replace('@malloc(', '@wf_cost_allocate(').replace('@free(', '@wf_cost_release(')
        ir, obj = home / ('wf-' + mode + '.ll'), home / ('wf-' + mode + '.o')
        ir.write_text(text)
        run(arm + '-native-' + mode, ['clang', '-O3', '-Wno-override-module', '-c', ir, '-o', obj])
        inputs = [shared / ('driver-' + mode + '.o'), shared / ('rust-' + mode + '.a'),
                  shared / ('cpp-' + mode + '.o'), shared / ('control-' + mode + '.o'), *runtime, obj]
        run(arm + '-link-' + mode, ['clang++', '-O3', *inputs, *absl_link,
            '-liconv', '-lSystem', '-lc', '-lm', '-pthread', '-lm', '-o', home / ('map-' + mode)])
    timed, account = home / 'map-timed', home / 'map-account'
    run(arm + '-check-timed', [timed, 'check'], limit=60)
    run(arm + '-check-account', [account, 'check'], limit=60)
    run(arm + '-negative-checksum', [timed, 'negative-checksum'], expected=1,
        message='map ecosystem: independent key-ID/content/outcome oracle')
    run(arm + '-negative-leak', [account, 'negative-leak'], expected=1,
        message='map ecosystem: every allocation is reclaimed')
    for variant in [0, 1, 2, 3, 5, 6, 7, 8]:
        run(arm + '-negative-reserve-' + str(variant), [timed, 'negative-reserve', str(variant)],
            expected=1, message='map ecosystem: reserve capacity floor')
    run(arm + '-account', [account, 'account', '262144'], csv_output=True)

assert all(sha(Path(p)) == value for p, value in pins.items()), 'input changed during build/check'
artifacts = sorted(shared.rglob('*.o')) + sorted(shared.glob('*.a'))
artifacts += [out / arm / ('map-' + mode) for arm in clis for mode in ['timed', 'account']]
metadata['artifact_pins_before'] = {str(p): sha(p) for p in artifacts}
(out / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
for arm, cohort in [('control', 0), ('candidate', 0), ('candidate', 1), ('control', 1)]:
    path = run(arm + '-cohort-' + str(cohort), [out / arm / 'map-timed', 'measure', str(cohort), '262144'],
               limit=180, csv_output=True)
    with path.open(newline='') as handle:
        rows = list(csv.DictReader(handle))
    assert len(rows) == 4620, (path, len(rows))
metadata['artifact_pins_after'] = {str(p): sha(p) for p in artifacts}
metadata['sources_unchanged'] = all(sha(Path(p)) == value for p, value in pins.items())
(out / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
assert metadata['artifact_pins_before'] == metadata['artifact_pins_after']
assert metadata['sources_unchanged']
print('COMPLETE: all raw measurements and direct stage statuses retained', flush=True)
