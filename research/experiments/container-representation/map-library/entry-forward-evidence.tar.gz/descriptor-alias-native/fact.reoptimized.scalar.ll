define i64 @"wf_flat_mutation_batch$instance$c7c8cd11e7f079bd"(ptr noalias nonnull captures(none) dereferenceable(80) %v0, i64 %v1, i64 %v2) local_unnamed_addr #16 {
entry:
  tail call void @llvm.experimental.noalias.scope.decl(metadata !1136)
  %wf.slot.7.sroa.0.sroa.7 = alloca i8, align 4
  %wf.slot.0.sroa.1.0.v0.sroa_idx = getelementptr inbounds nuw i8, ptr %v0, i64 56
  %wf.slot.0.sroa.1.0.copyload = load i64, ptr %wf.slot.0.sroa.1.0.v0.sroa_idx, align 1, !alias.scope !1136
  %v22.not83.not = icmp eq i64 %v1, 0
  br i1 %v22.not83.not, label %bb4, label %bb2.lr.ph

bb2.lr.ph:                                        ; preds = %entry
  %wf.slot.0.sroa.2.0.v0.sroa_idx = getelementptr inbounds nuw i8, ptr %v0, i64 64
  %wf.slot.1.sroa.1.0.v0.sroa_idx = getelementptr inbounds nuw i8, ptr %v0, i64 72
  %wf.slot.2.sroa.1.0.copyload = load i64, ptr %wf.slot.0.sroa.2.0.v0.sroa_idx, align 1, !alias.scope !1136
  %v55.not71.not = icmp eq i64 %wf.slot.2.sroa.1.0.copyload, 0
  %v59.not.not = icmp eq i64 %v2, 0
  %t13 = getelementptr inbounds nuw i8, ptr %v0, i64 40
  %v2.val.i = load i64, ptr %t13, align 1, !alias.scope !1136
  %0 = getelementptr inbounds nuw i8, ptr %v0, i64 48
  %v2.val1.i = load i8, ptr %0, align 1, !alias.scope !1136
  %wf.slot.0.sroa.1.0.v0.sroa_idx.i.i18 = getelementptr inbounds nuw i8, ptr %v0, i64 24
  %wf.slot.0.sroa.2.0.v0.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %v0, i64 32
  %1 = trunc i8 %v2.val1.i to i1
  %t7.i.i.i.i = getelementptr inbounds nuw i8, ptr %v0, i64 16
  %wf.slot.1.sroa.1.0.v0.sroa_idx.promoted = load i64, ptr %wf.slot.1.sroa.1.0.v0.sroa_idx, align 1, !alias.scope !1136
  br i1 %v55.not71.not, label %bb2.preheader, label %bb2.us.preheader

bb2.us.preheader:                                 ; preds = %bb2.lr.ph
  %wf.slot.0.sroa.2.0.v0.sroa_idx.i.i.promoted95 = load i64, ptr %wf.slot.0.sroa.2.0.v0.sroa_idx.i.i, align 1, !alias.scope !1136
  %wf.slot.0.sroa.1.0.v0.sroa_idx.i.i18.promoted88 = load i64, ptr %wf.slot.0.sroa.1.0.v0.sroa_idx.i.i18, align 1, !alias.scope !1136
  br label %bb2.us

bb2.preheader:                                    ; preds = %bb2.lr.ph
  %2 = add i64 %wf.slot.1.sroa.1.0.v0.sroa_idx.promoted, %v1
  store i64 %2, ptr %wf.slot.1.sroa.1.0.v0.sroa_idx, align 8, !alias.scope !1136
  br label %bb4

bb2.us:                                           ; preds = %bb5.bb8_crit_edge.us, %bb2.us.preheader
  %wf.slot.0.sroa.2.0.v0.sroa_idx.i.i.promoted101.us = phi i64 [ %wf.slot.0.sroa.2.0.v0.sroa_idx.i.i.promoted97.us, %bb5.bb8_crit_edge.us ], [ %wf.slot.0.sroa.2.0.v0.sroa_idx.i.i.promoted95, %bb2.us.preheader ]
  %wf.slot.0.sroa.1.0.v0.sroa_idx.i.i18.promoted94.us = phi i64 [ %wf.slot.0.sroa.1.0.v0.sroa_idx.i.i18.promoted90.us, %bb5.bb8_crit_edge.us ], [ %wf.slot.0.sroa.1.0.v0.sroa_idx.i.i18.promoted88, %bb2.us.preheader ]
  %v2687.us = phi i64 [ %v26.us, %bb5.bb8_crit_edge.us ], [ %wf.slot.1.sroa.1.0.v0.sroa_idx.promoted, %bb2.us.preheader ]
  %v1785.us = phi i64 [ %v122.us, %bb5.bb8_crit_edge.us ], [ 0, %bb2.us.preheader ]
  %v9.sroa.0.084.us = phi i64 [ %storemerge13.i.us, %bb5.bb8_crit_edge.us ], [ %wf.slot.0.sroa.1.0.copyload, %bb2.us.preheader ]
  %v26.us = add i64 %v2687.us, 1
  %v29.us = mul i64 %v26.us, %wf.slot.2.sroa.1.0.copyload
  %v32.us = add i64 %v29.us, %wf.slot.0.sroa.1.0.copyload
  br label %bb6.us

bb6.us:                                           ; preds = %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.us", %bb2.us
  %wf.slot.0.sroa.2.0.v0.sroa_idx.i.i.promoted100.us = phi i64 [ %wf.slot.0.sroa.2.0.v0.sroa_idx.i.i.promoted101.us, %bb2.us ], [ %wf.slot.0.sroa.2.0.v0.sroa_idx.i.i.promoted97.us, %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.us" ]
  %wf.slot.0.sroa.1.0.v0.sroa_idx.i.i18.promoted93.us = phi i64 [ %wf.slot.0.sroa.1.0.v0.sroa_idx.i.i18.promoted94.us, %bb2.us ], [ %wf.slot.0.sroa.1.0.v0.sroa_idx.i.i18.promoted90.us, %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.us" ]
  %v30.i.i82.us = phi i64 [ %wf.slot.0.sroa.2.0.v0.sroa_idx.i.i.promoted101.us, %bb2.us ], [ %v30.i.i79.us, %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.us" ]
  %v25.i.i78.us = phi i64 [ %wf.slot.0.sroa.1.0.v0.sroa_idx.i.i18.promoted94.us, %bb2.us ], [ %v25.i.i75.us, %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.us" ]
  %v4674.us = phi i64 [ 0, %bb2.us ], [ %v112.us, %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.us" ]
  %v9.sroa.0.172.us = phi i64 [ %v9.sroa.0.084.us, %bb2.us ], [ %storemerge13.i.us, %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.us" ]
  %v2.i.us = shl i64 %v4674.us, 1
  %v4.i.us = or disjoint i64 %v2.i.us, 1
  br i1 %v59.not.not, label %bb9.us, label %bb10.us

bb10.us:                                          ; preds = %bb6.us
  tail call void @llvm.experimental.noalias.scope.decl(metadata !1139)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !1142)
  %v6.not.i.i.us = icmp eq i64 %v25.i.i78.us, 0
  br i1 %v6.not.i.i.us, label %bb14.us, label %bb3.i.i19.us

bb3.i.i19.us:                                     ; preds = %bb10.us
  tail call void @llvm.experimental.noalias.scope.decl(metadata !1145)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !1148)
  br i1 %1, label %wf_map_cost_hash.exit.i.i.i.i.us, label %bb3.i.i.i.i.i.us

bb3.i.i.i.i.i.us:                                 ; preds = %bb3.i.i19.us
  %v10.i.i.i.i.i.us = xor i64 %v4.i.us, %v2.val.i
  %v2.i.i.i.i.i.i.us = lshr i64 %v10.i.i.i.i.i.us, 30
  %v3.i.i.i.i.i.i.us = xor i64 %v2.i.i.i.i.i.i.us, %v10.i.i.i.i.i.us
  %v5.i.i.i.i.i.i.us = mul i64 %v3.i.i.i.i.i.i.us, -4658895280553007687
  %v7.i.i.i.i.i.i.us = lshr i64 %v5.i.i.i.i.i.i.us, 27
  %v8.i.i.i.i.i.i.us = xor i64 %v7.i.i.i.i.i.i.us, %v5.i.i.i.i.i.i.us
  %v10.i.i.i.i.i.i.us = mul i64 %v8.i.i.i.i.i.i.us, -7723592293110705685
  %v12.i.i.i.i.i.i.us = lshr i64 %v10.i.i.i.i.i.i.us, 31
  %v13.i.i.i.i.i.i.us = xor i64 %v12.i.i.i.i.i.i.us, %v10.i.i.i.i.i.i.us
  br label %wf_map_cost_hash.exit.i.i.i.i.us

wf_map_cost_hash.exit.i.i.i.i.us:                 ; preds = %bb3.i.i.i.i.i.us, %bb3.i.i19.us
  %common.ret.op.i.i.i.i.i.us = phi i64 [ %v13.i.i.i.i.i.i.us, %bb3.i.i.i.i.i.us ], [ 0, %bb3.i.i19.us ]
  %t1.i.i.i.i.us = load i64, ptr %v0, align 8, !alias.scope !1151, !noalias !1152
  %v8.not.i.i.i.i.us = icmp eq i64 %t1.i.i.i.i.us, 0
  br i1 %v8.not.i.i.i.i.us, label %bb14.us, label %bb3.i.i.i.i.us

bb3.i.i.i.i.us:                                   ; preds = %wf_map_cost_hash.exit.i.i.i.i.us
  %v17.i.i.i.i.us = add i64 %t1.i.i.i.i.us, -1
  %v18.i.i.i.i.us = and i64 %v17.i.i.i.i.us, %common.ret.op.i.i.i.i.i.us
  %3 = tail call range(i64 1, 65) i64 @llvm.ctpop.i64(i64 %t1.i.i.i.i.us)
  %v21.i.i.i.i.us = icmp samesign ugt i64 %3, 1
  br i1 %v21.i.i.i.i.us, label %bb5.i.i.i.i.us, label %bb4.i.i.i.i.us

bb5.i.i.i.i.us:                                   ; preds = %bb3.i.i.i.i.us
  %v30.i.i.i.i.us = urem i64 %common.ret.op.i.i.i.i.i.us, %t1.i.i.i.i.us
  br label %bb4.i.i.i.i.us

bb4.i.i.i.i.us:                                   ; preds = %bb5.i.i.i.i.us, %bb3.i.i.i.i.us
  %v28.i.i.i.i.us = phi i64 [ %v30.i.i.i.i.us, %bb5.i.i.i.i.us ], [ %v18.i.i.i.i.us, %bb3.i.i.i.i.us ]
  %t8.i.i.i.i.us = load ptr, ptr %t7.i.i.i.i, align 8, !alias.scope !1151, !noalias !1152
  br label %bb8.i.i.i.i.us

bb8.i.i.i.i.us:                                   ; preds = %bb11.i.i.i.i.us, %bb4.i.i.i.i.us
  %v428.i.i.i.i.us = phi i64 [ 0, %bb4.i.i.i.i.us ], [ %v96.i.i.i.i.us, %bb11.i.i.i.i.us ]
  %v387.i.i.i.i.us = phi i64 [ %v28.i.i.i.i.us, %bb4.i.i.i.i.us ], [ %spec.select.i.i.i.i.us, %bb11.i.i.i.i.us ]
  %t6.i.i.i.i.us = getelementptr inbounds nuw %wf.t.a1df460b0959673f, ptr %t8.i.i.i.i.us, i64 %v387.i.i.i.i.us
  %wf.slot.0.sroa.0.0.copyload.i.i.i.i.i.us = load i32, ptr %t6.i.i.i.i.us, align 1, !alias.scope !1159, !noalias !1162
  switch i32 %wf.slot.0.sroa.0.0.copyload.i.i.i.i.i.us, label %invalid.tag.b0.i.i.i.i.i [
    i32 0, label %bb14.us
    i32 1, label %bb11.i.i.i.i.us
    i32 2, label %bb3.i4.i.i.i.i.us
  ]

bb3.i4.i.i.i.i.us:                                ; preds = %bb8.i.i.i.i.us
  %t2.i.i.i.i.i.us = getelementptr inbounds nuw i8, ptr %t6.i.i.i.i.us, i64 8
  %v3.i.i5.i.i.i.i.us = load i64, ptr %t2.i.i.i.i.i.us, align 8, !alias.scope !1164, !noalias !1167
  %v5.i.i6.i.i.i.i.us = icmp eq i64 %v3.i.i5.i.i.i.i.us, %v4.i.us
  br i1 %v5.i.i6.i.i.i.i.us, label %bb13.us, label %bb11.i.i.i.i.us

bb13.us:                                          ; preds = %bb3.i4.i.i.i.i.us
  %t2.i.i.i.i.i.us.le = getelementptr inbounds nuw i8, ptr %t6.i.i.i.i.us, i64 8
  %t7.nonnegative.i.i.us = icmp sgt i64 %v387.i.i.i.i.us, -1
  tail call void @llvm.assume(i1 %t7.nonnegative.i.i.us)
  %wf.slot.0.i.sroa.6.0.t7.sroa_idx.i.i.us = getelementptr inbounds nuw i8, ptr %t6.i.i.i.i.us, i64 16
  %wf.slot.0.i.sroa.6.0.copyload.i.i20.us = load i64, ptr %wf.slot.0.i.sroa.6.0.t7.sroa_idx.i.i.us, align 1, !noalias !1169
  store i32 1, ptr %t6.i.i.i.i.us, align 1, !noalias !1169
  %v25.i.i.us = add i64 %v25.i.i78.us, -1
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(16) %t2.i.i.i.i.i.us.le, i8 0, i64 16, i1 false), !noalias !1169
  store i64 %v25.i.i.us, ptr %wf.slot.0.sroa.1.0.v0.sroa_idx.i.i18, align 8, !alias.scope !1170, !noalias !1171
  %v30.i.i.us = tail call i64 @llvm.uadd.sat.i64(i64 %v30.i.i82.us, i64 1)
  store i64 %v30.i.i.us, ptr %wf.slot.0.sroa.2.0.v0.sroa_idx.i.i, align 8, !alias.scope !1170, !noalias !1171
  %v3.i.us = mul i64 %v4.i.us, 131
  %4 = mul i64 %v9.sroa.0.172.us, 17161
  %v4.i22.us = add i64 %4, 131
  %v5.i24.us = add i64 %v4.i22.us, %v3.i.us
  %v7.i25.us = add i64 %v5.i24.us, %wf.slot.0.i.sroa.6.0.copyload.i.i20.us
  br label %bb9.us

bb11.i.i.i.i.us:                                  ; preds = %bb3.i4.i.i.i.i.us, %bb8.i.i.i.i.us
  %v70.i.i.i.i.us = add nuw i64 %v387.i.i.i.i.us, 1
  %v71.not.i.i.i.i.us = icmp ult i64 %v70.i.i.i.i.us, %t1.i.i.i.i.us
  %spec.select.i.i.i.i.us = select i1 %v71.not.i.i.i.i.us, i64 %v70.i.i.i.i.us, i64 0
  %v96.i.i.i.i.us = add nuw i64 %v428.i.i.i.i.us, 1
  %exitcond.not.i.i.i.i.us = icmp eq i64 %v96.i.i.i.i.us, %t1.i.i.i.i.us
  br i1 %exitcond.not.i.i.i.i.us, label %bb14.us, label %bb8.i.i.i.i.us

bb14.us:                                          ; preds = %bb11.i.i.i.i.us, %bb8.i.i.i.i.us, %wf_map_cost_hash.exit.i.i.i.i.us, %bb10.us
  %v5.i27.us = mul i64 %v9.sroa.0.172.us, 131
  br label %bb9.us

bb9.us:                                           ; preds = %bb14.us, %bb13.us, %bb6.us
  %wf.slot.0.sroa.2.0.v0.sroa_idx.i.i.promoted99.us = phi i64 [ %v30.i.i.us, %bb13.us ], [ %wf.slot.0.sroa.2.0.v0.sroa_idx.i.i.promoted100.us, %bb14.us ], [ %wf.slot.0.sroa.2.0.v0.sroa_idx.i.i.promoted100.us, %bb6.us ]
  %wf.slot.0.sroa.1.0.v0.sroa_idx.i.i18.promoted92.us = phi i64 [ %v25.i.i.us, %bb13.us ], [ %wf.slot.0.sroa.1.0.v0.sroa_idx.i.i18.promoted93.us, %bb14.us ], [ %wf.slot.0.sroa.1.0.v0.sroa_idx.i.i18.promoted93.us, %bb6.us ]
  %v30.i.i81.us = phi i64 [ %v30.i.i.us, %bb13.us ], [ %v30.i.i82.us, %bb14.us ], [ %v30.i.i82.us, %bb6.us ]
  %v25.i.i77.us = phi i64 [ %v25.i.i.us, %bb13.us ], [ %v25.i.i78.us, %bb14.us ], [ %v25.i.i78.us, %bb6.us ]
  %v9.sroa.0.2.us = phi i64 [ %v7.i25.us, %bb13.us ], [ %v5.i27.us, %bb14.us ], [ %v9.sroa.0.172.us, %bb6.us ]
  %v93.us = add i64 %v32.us, %v4674.us
  tail call void @llvm.experimental.noalias.scope.decl(metadata !1172)
  br i1 %1, label %wf_map_cost_hash.exit.i.us, label %bb3.i.i.us

bb3.i.i.us:                                       ; preds = %bb9.us
  %v10.i.i6.us = xor i64 %v4.i.us, %v2.val.i
  %v2.i.i.i.us = lshr i64 %v10.i.i6.us, 30
  %v3.i.i.i.us = xor i64 %v2.i.i.i.us, %v10.i.i6.us
  %v5.i.i.i.us = mul i64 %v3.i.i.i.us, -4658895280553007687
  %v7.i.i.i.us = lshr i64 %v5.i.i.i.us, 27
  %v8.i.i.i.us = xor i64 %v7.i.i.i.us, %v5.i.i.i.us
  %v10.i.i.i.us = mul i64 %v8.i.i.i.us, -7723592293110705685
  %v12.i.i.i.us = lshr i64 %v10.i.i.i.us, 31
  %v13.i.i.i.us = xor i64 %v12.i.i.i.us, %v10.i.i.i.us
  br label %wf_map_cost_hash.exit.i.us

wf_map_cost_hash.exit.i.us:                       ; preds = %bb3.i.i.us, %bb9.us
  %common.ret.op.i.i.us = phi i64 [ %v13.i.i.i.us, %bb3.i.i.us ], [ 0, %bb9.us ]
  %t1.i.us = load i64, ptr %v0, align 8, !alias.scope !1175, !noalias !1176
  %v10.not.not.i.us = icmp eq i64 %t1.i.us, 0
  br i1 %v10.not.not.i.us, label %bb1.i.us, label %bb2.i.us

bb2.i.us:                                         ; preds = %wf_map_cost_hash.exit.i.us
  %v19.i.us = add i64 %t1.i.us, -1
  %v20.i.us = and i64 %v19.i.us, %common.ret.op.i.i.us
  %5 = tail call range(i64 1, 65) i64 @llvm.ctpop.i64(i64 %t1.i.us)
  %v23.i.us = icmp samesign ugt i64 %5, 1
  br i1 %v23.i.us, label %bb5.i.us, label %bb4.i.us

bb5.i.us:                                         ; preds = %bb2.i.us
  %v34.i.us = urem i64 %common.ret.op.i.i.us, %t1.i.us
  br label %bb4.i.us

bb4.i.us:                                         ; preds = %bb5.i.us, %bb2.i.us
  %v32.i.us = phi i64 [ %v34.i.us, %bb5.i.us ], [ %v20.i.us, %bb2.i.us ]
  %t6.i.us = load ptr, ptr %t7.i.i.i.i, align 8, !alias.scope !1175, !noalias !1176
  br label %bb8.i.us

bb8.i.us:                                         ; preds = %bb11.i.us, %bb4.i.us
  %v4855.i.us = phi i64 [ 0, %bb4.i.us ], [ %v136.i.us, %bb11.i.us ]
  %v4454.i.us = phi i64 [ %v32.i.us, %bb4.i.us ], [ %spec.select.i.us, %bb11.i.us ]
  %v4253.i.us = phi i64 [ %t1.i.us, %bb4.i.us ], [ %v70.i.us, %bb11.i.us ]
  %t4.i.us = getelementptr inbounds nuw %wf.t.a1df460b0959673f, ptr %t6.i.us, i64 %v4454.i.us
  %wf.slot.0.sroa.0.0.copyload.i.i.us = load i32, ptr %t4.i.us, align 1, !alias.scope !1178, !noalias !1181
  switch i32 %wf.slot.0.sroa.0.0.copyload.i.i.us, label %invalid.tag.b0.i.i [
    i32 0, label %bb13.i.us
    i32 1, label %bb14.i.us
    i32 2, label %bb3.i12.i.us
  ]

bb3.i12.i.us:                                     ; preds = %bb8.i.us
  %t2.i.i.us = getelementptr inbounds nuw i8, ptr %t4.i.us, i64 8
  %v3.i.i13.i.us = load i64, ptr %t2.i.i.us, align 8, !alias.scope !1183, !noalias !1186
  %v5.i.i14.i.us = icmp eq i64 %v3.i.i13.i.us, %v4.i.us
  br i1 %v5.i.i14.i.us, label %"wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3.exit.i.us", label %bb11.i.us

"wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3.exit.i.us": ; preds = %bb3.i12.i.us
  %wf.slot.0.i.sroa.6.0.t3.sroa_idx.i.i.us = getelementptr inbounds nuw i8, ptr %t4.i.us, i64 16
  %wf.slot.0.i.sroa.6.0.copyload.i.i.us = load i64, ptr %wf.slot.0.i.sroa.6.0.t3.sroa_idx.i.i.us, align 1, !noalias !1188
  store i32 2, ptr %t4.i.us, align 1, !noalias !1188
  store i64 %v93.us, ptr %wf.slot.0.i.sroa.6.0.t3.sroa_idx.i.i.us, align 1, !noalias !1188
  store i8 0, ptr %wf.slot.7.sroa.0.sroa.7, align 4, !noalias !1191
  br label %bb3.i.us

bb14.i.us:                                        ; preds = %bb8.i.us
  %v92.not.i.us = icmp eq i64 %v4253.i.us, %t1.i.us
  %spec.select9.i.us = select i1 %v92.not.i.us, i64 %v4454.i.us, i64 %v4253.i.us
  br label %bb11.i.us

bb11.i.us:                                        ; preds = %bb14.i.us, %bb3.i12.i.us
  %v70.i.us = phi i64 [ %spec.select9.i.us, %bb14.i.us ], [ %v4253.i.us, %bb3.i12.i.us ]
  %v106.i.us = add nuw i64 %v4454.i.us, 1
  %v107.not.i.us = icmp ult i64 %v106.i.us, %t1.i.us
  %spec.select.i.us = select i1 %v107.not.i.us, i64 %v106.i.us, i64 0
  %v136.i.us = add nuw i64 %v4855.i.us, 1
  %exitcond.not.i.us = icmp eq i64 %v136.i.us, %t1.i.us
  br i1 %exitcond.not.i.us, label %bb1.i.us, label %bb8.i.us

bb13.i.us:                                        ; preds = %bb8.i.us
  %v79.not.i.us = icmp eq i64 %v4253.i.us, %t1.i.us
  %spec.select7.i.us = select i1 %v79.not.i.us, i64 %v4454.i.us, i64 %v4253.i.us
  br label %bb1.i.us

bb1.i.us:                                         ; preds = %bb11.i.us, %bb13.i.us, %wf_map_cost_hash.exit.i.us
  %v17.i.us = phi i64 [ 0, %wf_map_cost_hash.exit.i.us ], [ %spec.select7.i.us, %bb13.i.us ], [ %v70.i.us, %bb11.i.us ]
  %v137.not.i.us = icmp ult i64 %v17.i.us, %t1.i.us
  %v148.i.us = icmp ult i64 %v25.i.i77.us, 8192
  %or.cond = select i1 %v137.not.i.us, i1 %v148.i.us, i1 false
  br i1 %or.cond, label %bb30.i.us, label %bb26.i.us

bb26.i.us:                                        ; preds = %bb1.i.us
  store i1 true, ptr %wf.slot.7.sroa.0.sroa.7, align 4, !noalias !1192
  %wf.slot.7.sroa.0.sroa.7.0.wf.slot.7.sroa.0.sroa.7.0.wf.slot.7.sroa.0.sroa.7.0.wf.slot.7.sroa.0.sroa.7.0.wf.slot.7.sroa.0.sroa.7.0.wf.slot.7.sroa.0.sroa.7.0.wf.slot.7.sroa.0.sroa.7.0.wf.slot.7.sroa.0.sroa.7.4.wf.slot.7.sroa.0.4..us.pre = load i8, ptr %wf.slot.7.sroa.0.sroa.7, align 4, !noalias !1193
  %extract.t = trunc i8 %wf.slot.7.sroa.0.sroa.7.0.wf.slot.7.sroa.0.sroa.7.0.wf.slot.7.sroa.0.sroa.7.0.wf.slot.7.sroa.0.sroa.7.0.wf.slot.7.sroa.0.sroa.7.0.wf.slot.7.sroa.0.sroa.7.0.wf.slot.7.sroa.0.sroa.7.0.wf.slot.7.sroa.0.sroa.7.4.wf.slot.7.sroa.0.4..us.pre to i1
  %6 = select i1 %extract.t, i64 2, i64 1
  br label %bb3.i.us

bb30.i.us:                                        ; preds = %bb1.i.us
  %v159.i.us = add nuw nsw i64 %v25.i.i77.us, 1
  store i64 %v159.i.us, ptr %wf.slot.0.sroa.1.0.v0.sroa_idx.i.i18, align 8, !alias.scope !1175, !noalias !1176
  %t18.i.us = load ptr, ptr %t7.i.i.i.i, align 8, !alias.scope !1175, !noalias !1176
  %t16.nonnegative.i.us = icmp sgt i64 %v17.i.us, -1
  tail call void @llvm.assume(i1 %t16.nonnegative.i.us)
  %t16.i.us = getelementptr inbounds nuw %wf.t.a1df460b0959673f, ptr %t18.i.us, i64 %v17.i.us
  %wf.slot.0.sroa.0.0.copyload.i19.i.us = load i32, ptr %t16.i.us, align 1, !alias.scope !1196, !noalias !1199
  %switch.i.not.i.us = icmp eq i32 %wf.slot.0.sroa.0.0.copyload.i19.i.us, 1
  br i1 %switch.i.not.i.us, label %bb32.thread.i.us, label %bb32.i.us

bb32.i.us:                                        ; preds = %bb30.i.us
  %wf.slot.0.i.sroa.5.0.t3.sroa_idx.i25.i.us = getelementptr inbounds nuw i8, ptr %t16.i.us, i64 8
  %wf.slot.0.i.sroa.5.0.copyload.i26.i.us = load i64, ptr %wf.slot.0.i.sroa.5.0.t3.sroa_idx.i25.i.us, align 1, !noalias !1200
  %wf.slot.0.i.sroa.6.0.t3.sroa_idx.i27.i.us = getelementptr inbounds nuw i8, ptr %t16.i.us, i64 16
  %wf.slot.0.i.sroa.6.0.copyload.i28.i.us = load i64, ptr %wf.slot.0.i.sroa.6.0.t3.sroa_idx.i27.i.us, align 1, !noalias !1200
  store i32 2, ptr %t16.i.us, align 1, !noalias !1200
  store i64 %v4.i.us, ptr %wf.slot.0.i.sroa.5.0.t3.sroa_idx.i25.i.us, align 1, !noalias !1200
  store i64 %v93.us, ptr %wf.slot.0.i.sroa.6.0.t3.sroa_idx.i27.i.us, align 1, !noalias !1200
  %switch.i.us = icmp eq i32 %wf.slot.0.sroa.0.0.copyload.i19.i.us, 0
  br i1 %switch.i.us, label %bb2.i15.us, label %bb3.i29.i.us

bb3.i29.i.us:                                     ; preds = %bb32.i.us
  store i8 0, ptr %wf.slot.7.sroa.0.sroa.7, align 4, !noalias !1203
  br label %bb3.i.us

bb3.i.us:                                         ; preds = %bb3.i29.i.us, %bb26.i.us, %"wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3.exit.i.us"
  %wf.slot.7.sroa.0.sroa.7.0.wf.slot.7.sroa.0.sroa.7.0.wf.slot.7.sroa.0.sroa.7.4.wf.slot.7.sroa.0.4..us.off0 = phi i64 [ 1, %"wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3.exit.i.us" ], [ %6, %bb26.i.us ], [ 1, %bb3.i29.i.us ]
  %wf.slot.0.sroa.1.0.v0.sroa_idx.i.i18.promoted91.us = phi i64 [ %wf.slot.0.sroa.1.0.v0.sroa_idx.i.i18.promoted92.us, %"wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3.exit.i.us" ], [ %wf.slot.0.sroa.1.0.v0.sroa_idx.i.i18.promoted92.us, %bb26.i.us ], [ %v159.i.us, %bb3.i29.i.us ]
  %v25.i.i76.us = phi i64 [ %v25.i.i77.us, %"wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3.exit.i.us" ], [ %v25.i.i77.us, %bb26.i.us ], [ %v159.i.us, %bb3.i29.i.us ]
  %wf.slot.7.sroa.13.2.ph.us = phi i64 [ %wf.slot.0.i.sroa.6.0.copyload.i.i.us, %"wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3.exit.i.us" ], [ %v93.us, %bb26.i.us ], [ %wf.slot.0.i.sroa.6.0.copyload.i28.i.us, %bb3.i29.i.us ]
  %wf.slot.7.sroa.9.2.ph.us = phi i64 [ %v4.i.us, %"wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3.exit.i.us" ], [ %v4.i.us, %bb26.i.us ], [ %wf.slot.0.i.sroa.5.0.copyload.i26.i.us, %bb3.i29.i.us ]
  %v5.i10.i.us = mul i64 %v9.sroa.0.2.us, 131
  %v7.i11.i.us = add i64 %wf.slot.7.sroa.0.sroa.7.0.wf.slot.7.sroa.0.sroa.7.0.wf.slot.7.sroa.0.sroa.7.4.wf.slot.7.sroa.0.4..us.off0, %v5.i10.i.us
  %reass.add.i.us = add i64 %v7.i11.i.us, %wf.slot.7.sroa.9.2.ph.us
  %reass.mul.i.us = mul i64 %reass.add.i.us, 131
  %v7.i.i13.us = add i64 %reass.mul.i.us, %wf.slot.7.sroa.13.2.ph.us
  br label %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.us"

bb32.thread.i.us:                                 ; preds = %bb30.i.us
  %v177.i.us = tail call i64 @llvm.usub.sat.i64(i64 %v30.i.i81.us, i64 1)
  store i64 %v177.i.us, ptr %wf.slot.0.sroa.2.0.v0.sroa_idx.i.i, align 8, !alias.scope !1175, !noalias !1176
  %wf.slot.0.i.sroa.5.0.t3.sroa_idx.i2565.i.us = getelementptr inbounds nuw i8, ptr %t16.i.us, i64 8
  %wf.slot.0.i.sroa.6.0.t3.sroa_idx.i2767.i.us = getelementptr inbounds nuw i8, ptr %t16.i.us, i64 16
  store i32 2, ptr %t16.i.us, align 1, !noalias !1200
  store i64 %v4.i.us, ptr %wf.slot.0.i.sroa.5.0.t3.sroa_idx.i2565.i.us, align 1, !noalias !1200
  store i64 %v93.us, ptr %wf.slot.0.i.sroa.6.0.t3.sroa_idx.i2767.i.us, align 1, !noalias !1200
  br label %bb2.i15.us

bb2.i15.us:                                       ; preds = %bb32.thread.i.us, %bb32.i.us
  %wf.slot.0.sroa.2.0.v0.sroa_idx.i.i.promoted98.us = phi i64 [ %wf.slot.0.sroa.2.0.v0.sroa_idx.i.i.promoted99.us, %bb32.i.us ], [ %v177.i.us, %bb32.thread.i.us ]
  %v30.i.i80.us = phi i64 [ %v30.i.i81.us, %bb32.i.us ], [ %v177.i.us, %bb32.thread.i.us ]
  store i8 0, ptr %wf.slot.7.sroa.0.sroa.7, align 4
  %v5.i.i17.us = mul i64 %v9.sroa.0.2.us, 131
  br label %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.us"

"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.us": ; preds = %bb2.i15.us, %bb3.i.us
  %wf.slot.0.sroa.2.0.v0.sroa_idx.i.i.promoted97.us = phi i64 [ %wf.slot.0.sroa.2.0.v0.sroa_idx.i.i.promoted99.us, %bb3.i.us ], [ %wf.slot.0.sroa.2.0.v0.sroa_idx.i.i.promoted98.us, %bb2.i15.us ]
  %wf.slot.0.sroa.1.0.v0.sroa_idx.i.i18.promoted90.us = phi i64 [ %wf.slot.0.sroa.1.0.v0.sroa_idx.i.i18.promoted91.us, %bb3.i.us ], [ %v159.i.us, %bb2.i15.us ]
  %v30.i.i79.us = phi i64 [ %v30.i.i81.us, %bb3.i.us ], [ %v30.i.i80.us, %bb2.i15.us ]
  %v25.i.i75.us = phi i64 [ %v25.i.i76.us, %bb3.i.us ], [ %v159.i.us, %bb2.i15.us ]
  %storemerge13.i.us = phi i64 [ %v7.i.i13.us, %bb3.i.us ], [ %v5.i.i17.us, %bb2.i15.us ]
  %v112.us = add nuw i64 %v4674.us, 1
  %exitcond.not = icmp eq i64 %v112.us, %wf.slot.2.sroa.1.0.copyload
  br i1 %exitcond.not, label %bb5.bb8_crit_edge.us, label %bb6.us

bb5.bb8_crit_edge.us:                             ; preds = %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.us"
  store i64 %v26.us, ptr %wf.slot.1.sroa.1.0.v0.sroa_idx, align 8, !alias.scope !1136
  %v122.us = add nuw i64 %v1785.us, 1
  %exitcond115.not = icmp eq i64 %v122.us, %v1
  br i1 %exitcond115.not, label %bb4, label %bb2.us

bb4:                                              ; preds = %bb5.bb8_crit_edge.us, %bb2.preheader, %entry
  %v9.sroa.0.0.lcssa = phi i64 [ %wf.slot.0.sroa.1.0.copyload, %entry ], [ %wf.slot.0.sroa.1.0.copyload, %bb2.preheader ], [ %storemerge13.i.us, %bb5.bb8_crit_edge.us ]
  %v2.i.i = lshr i64 %v9.sroa.0.0.lcssa, 30
  %v3.i.i = xor i64 %v2.i.i, %v9.sroa.0.0.lcssa
  %v5.i.i = mul i64 %v3.i.i, -4658895280553007687
  %v7.i.i = lshr i64 %v5.i.i, 27
  %v8.i.i = xor i64 %v7.i.i, %v5.i.i
  %v10.i.i = mul i64 %v8.i.i, -7723592293110705685
  %7 = lshr i64 %v10.i.i, 31
  %8 = xor i64 %7, %v10.i.i
  ret i64 %8

invalid.tag.b0.i.i:                               ; preds = %bb8.i.us
  unreachable

invalid.tag.b0.i.i.i.i.i:                         ; preds = %bb8.i.i.i.i.us
  unreachable
}
