import pathlib,re,json,difflib,hashlib
D=pathlib.Path('/private/tmp/whitefoot-map-descriptor-alias')
s=(D/'mask.optimized.ll').read_text()
m=re.search(r'^define [^\n]*@"wf_flat_mutation_batch\$instance\$c7c8cd11e7f079bd"[^\n]*\n.*?^}',s,re.M|re.S);assert m
f=m.group(); lines=f.splitlines(keepends=True)
# Explicit audited owner and payload roots; only GEP descendants inherit roots.
roots={'%v0':'owner','%wf.slot.7.sroa.0.sroa.7':'local'}
payload_roots={'%t8.i.i.i.i.us','%t6.i.us','%t18.i.us'}
for line in lines:
 g=re.search(r'^  (%[^ ]+) = getelementptr .*?, ptr (%[^, ]+)',line)
 if g:
  assert g[2] in roots,line
  roots[g[1]]=roots[g[2]]
 g=re.search(r'^  (%[^ ]+) = load ptr, ptr (%[^, ]+)',line)
 if g:
  assert g[1] in payload_roots and g[2]=='%t7.i.i.i.i',line
  roots[g[1]]='payload'
meta={int(k):v for k,v in re.findall(r'^!(\d+) = (.*)$',s,re.M)}
n=max(meta)+1; domain=n;scope=n+1;decl=n+2;n+=3
new=[f'!{domain} = distinct !{{!{domain}, !"prepared owner versus bucket allocation"}}',f'!{scope} = distinct !{{!{scope}, !{domain}, !"owner bytes"}}',f'!{decl} = !{{!{scope}}}']
cache={}; changes=[]; records=[]
for i,line in enumerate(lines):
 ismem=bool(re.search(r'\b(?:load|store)\b',line)) or '@llvm.memset.p0.i64(' in line
 if not ismem:continue
 ptrs=re.findall(r'ptr [^%]*?(%[^, )]+)',line)
 assert len(ptrs)==1,(line,ptrs)
 p=ptrs[0];assert p in roots,(p,line)
 kind=roots[p];records.append({'line':i+1,'kind':kind,'pointer':p,'access':line.strip()})
 if kind=='local':continue
 tag='alias.scope' if kind=='owner' else 'noalias'
 match=re.search(r'!'+re.escape(tag)+r' !(\d+)',line)
 old=int(match[1]) if match else None
 key=(tag,old)
 if key not in cache:
  contents=meta[old] if old is not None else '!{}'
  assert contents.startswith('!{') and contents.endswith('}'),contents
  members=contents[2:-1]
  cache[key]=n;new.append(f'!{n} = !{{'+(members+', ' if members else '')+f'!{scope}'+'}');n+=1
 if match:
  altered=line[:match.start()]+f'!{tag} !{cache[key]}'+line[match.end():]
 else:altered=line.rstrip('\n')+f', !{tag} !{cache[key]}\n'
 changes.append((line,altered));lines[i]=altered
call=f'  call void @llvm.experimental.noalias.scope.decl(metadata !{decl})\n'
assert lines[1]=='entry:\n';lines.insert(2,call)
fact=s[:m.start()]+''.join(lines)+s[m.end():]
suffix='\n'+'\n'.join(new)+'\n';fact+=suffix
restored=fact[:-len(suffix)].replace(call,'',1)
for before,after in changes:
 assert restored.count(after)>=1,after
 restored=restored.replace(after,before,1)
assert restored==s
(D/'mask.fact.ll').write_text(fact)
(D/'metadata.patch').write_text(''.join(difflib.unified_diff(s.splitlines(True),fact.splitlines(True),fromfile='mask.optimized.ll',tofile='mask.fact.ll')))
(D/'access-classification.json').write_text(json.dumps({'symbol':'wf_flat_mutation_batch$instance$c7c8cd11e7f079bd','roots':roots,'accesses':records,'strip_byte_equality':True,'optimized_sha256':hashlib.sha256(s.encode()).hexdigest(),'fact_sha256':hashlib.sha256(fact.encode()).hexdigest()},indent=2)+'\n')
print({k:sum(r['kind']==k for r in records) for k in ['owner','payload','local']})
