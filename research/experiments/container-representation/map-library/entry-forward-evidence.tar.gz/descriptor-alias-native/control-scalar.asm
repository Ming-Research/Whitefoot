00000001000a4948 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd>:
1000a4948:     	mov	x9, #0xe5b9             ; =58809
1000a494c:     	movk	x9, #0x1ce4, lsl #16
1000a4950:     	movk	x9, #0x476d, lsl #32
1000a4954:     	movk	x9, #0xbf58, lsl #48
1000a4958:     	mov	x8, #0x11eb             ; =4587
1000a495c:     	movk	x8, #0x1331, lsl #16
1000a4960:     	movk	x8, #0x49bb, lsl #32
1000a4964:     	movk	x8, #0x94d0, lsl #48
1000a4968:     	ldr	x10, [x0, #0x38]
1000a496c:     	cbz	x1, 0x1000a4c64 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x31c>
1000a4970:     	ldp	x12, x11, [x0, #0x40]
1000a4974:     	cbz	x12, 0x1000a4c5c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x314>
1000a4978:     	sub	sp, sp, #0x70
1000a497c:     	stp	x28, x27, [sp, #0x10]
1000a4980:     	stp	x26, x25, [sp, #0x20]
1000a4984:     	stp	x24, x23, [sp, #0x30]
1000a4988:     	stp	x22, x21, [sp, #0x40]
1000a498c:     	stp	x20, x19, [sp, #0x50]
1000a4990:     	stp	x29, x30, [sp, #0x60]
1000a4994:     	mov	x13, #0x0               ; =0
1000a4998:     	ldp	x19, x14, [x0, #0x20]
1000a499c:     	ldrb	w15, [x0, #0x30]
1000a49a0:     	mov	w16, #0x1               ; =1
1000a49a4:     	mov	w17, #0x18              ; =24
1000a49a8:     	mov	w3, #0x2                ; =2
1000a49ac:     	mov	w4, #0x83               ; =131
1000a49b0:     	mov	x6, x10
1000a49b4:     	ldr	x7, [x0, #0x18]
1000a49b8:     	b	0x1000a49cc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x84>
1000a49bc:     	str	x11, [x0, #0x48]
1000a49c0:     	add	x13, x13, #0x1
1000a49c4:     	cmp	x13, x1
1000a49c8:     	b.eq	0x1000a4c28 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2e0>
1000a49cc:     	mov	x20, #0x0               ; =0
1000a49d0:     	add	x11, x11, #0x1
1000a49d4:     	madd	x21, x11, x12, x10
1000a49d8:     	b	0x1000a4a00 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xb8>
1000a49dc:     	strb	w16, [sp, #0xc]
1000a49e0:     	tst	w16, #0x1
1000a49e4:     	cinc	x24, x16, ne
1000a49e8:     	madd	x5, x6, x4, x24
1000a49ec:     	add	x5, x5, x22
1000a49f0:     	madd	x6, x5, x4, x23
1000a49f4:     	add	x20, x20, #0x1
1000a49f8:     	cmp	x20, x12
1000a49fc:     	b.eq	0x1000a49bc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x74>
1000a4a00:     	orr	x22, x16, x20, lsl #1
1000a4a04:     	cbz	x2, 0x1000a4ad0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x188>
1000a4a08:     	cbz	x7, 0x1000a4afc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b4>
1000a4a0c:     	tbz	w15, #0x0, 0x1000a4a20 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xd8>
1000a4a10:     	mov	x24, #0x0               ; =0
1000a4a14:     	ldr	x23, [x0]
1000a4a18:     	cbnz	x23, 0x1000a4a40 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xf8>
1000a4a1c:     	b	0x1000a4afc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b4>
1000a4a20:     	eor	x5, x22, x14
1000a4a24:     	eor	x5, x5, x5, lsr #30
1000a4a28:     	mul	x5, x5, x9
1000a4a2c:     	eor	x5, x5, x5, lsr #27
1000a4a30:     	mul	x5, x5, x8
1000a4a34:     	eor	x24, x5, x5, lsr #31
1000a4a38:     	ldr	x23, [x0]
1000a4a3c:     	cbz	x23, 0x1000a4afc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b4>
1000a4a40:     	sub	x5, x23, #0x1
1000a4a44:     	tst	x23, x5
1000a4a48:     	b.eq	0x1000a4a58 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x110>
1000a4a4c:     	udiv	x5, x24, x23
1000a4a50:     	msub	x24, x5, x23, x24
1000a4a54:     	b	0x1000a4a5c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x114>
1000a4a58:     	and	x24, x5, x24
1000a4a5c:     	ldr	x25, [x0, #0x10]
1000a4a60:     	mov	x26, x23
1000a4a64:     	b	0x1000a4a7c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x134>
1000a4a68:     	add	x5, x24, #0x1
1000a4a6c:     	cmp	x5, x23
1000a4a70:     	csinc	x24, xzr, x24, hs
1000a4a74:     	subs	x26, x26, #0x1
1000a4a78:     	b.eq	0x1000a4afc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b4>
1000a4a7c:     	madd	x27, x24, x17, x25
1000a4a80:     	ldr	w28, [x27]
1000a4a84:     	cmp	w28, #0x1
1000a4a88:     	b.eq	0x1000a4a68 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x120>
1000a4a8c:     	cmp	w28, #0x2
1000a4a90:     	b.ne	0x1000a4afc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b4>
1000a4a94:     	ldr	x5, [x27, #0x8]
1000a4a98:     	cmp	x5, x22
1000a4a9c:     	b.ne	0x1000a4a68 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x120>
1000a4aa0:     	ldr	x5, [x27, #0x10]
1000a4aa4:     	str	w16, [x27]
1000a4aa8:     	sub	x7, x7, #0x1
1000a4aac:     	stp	xzr, xzr, [x27, #0x8]
1000a4ab0:     	adds	x19, x19, #0x1
1000a4ab4:     	csinv	x19, x19, xzr, lo
1000a4ab8:     	stp	x7, x19, [x0, #0x18]
1000a4abc:     	mul	x23, x22, x4
1000a4ac0:     	mov	w24, #0x4309            ; =17161
1000a4ac4:     	madd	x6, x6, x24, x23
1000a4ac8:     	add	x5, x6, x5
1000a4acc:     	add	x6, x5, #0x83
1000a4ad0:     	tbz	w15, #0x0, 0x1000a4b04 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1bc>
1000a4ad4:     	mov	x25, #0x0               ; =0
1000a4ad8:     	add	x23, x21, x20
1000a4adc:     	ldr	x24, [x0]
1000a4ae0:     	cbz	x24, 0x1000a4b28 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1e0>
1000a4ae4:     	sub	x5, x24, #0x1
1000a4ae8:     	tst	x24, x5
1000a4aec:     	b.eq	0x1000a4b30 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1e8>
1000a4af0:     	udiv	x5, x25, x24
1000a4af4:     	msub	x26, x5, x24, x25
1000a4af8:     	b	0x1000a4b34 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1ec>
1000a4afc:     	mul	x6, x6, x4
1000a4b00:     	tbnz	w15, #0x0, 0x1000a4ad4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x18c>
1000a4b04:     	eor	x5, x22, x14
1000a4b08:     	eor	x5, x5, x5, lsr #30
1000a4b0c:     	mul	x5, x5, x9
1000a4b10:     	eor	x5, x5, x5, lsr #27
1000a4b14:     	mul	x5, x5, x8
1000a4b18:     	eor	x25, x5, x5, lsr #31
1000a4b1c:     	add	x23, x21, x20
1000a4b20:     	ldr	x24, [x0]
1000a4b24:     	cbnz	x24, 0x1000a4ae4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x19c>
1000a4b28:     	mov	x25, #0x0               ; =0
1000a4b2c:     	b	0x1000a4ba8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x260>
1000a4b30:     	and	x26, x5, x25
1000a4b34:     	ldr	x27, [x0, #0x10]
1000a4b38:     	mov	x28, x24
1000a4b3c:     	mov	x25, x24
1000a4b40:     	b	0x1000a4b60 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x218>
1000a4b44:     	cmp	x25, x24
1000a4b48:     	csel	x25, x26, x25, eq
1000a4b4c:     	add	x5, x26, #0x1
1000a4b50:     	cmp	x5, x24
1000a4b54:     	csinc	x26, xzr, x26, hs
1000a4b58:     	subs	x28, x28, #0x1
1000a4b5c:     	b.eq	0x1000a4ba8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x260>
1000a4b60:     	madd	x30, x26, x17, x27
1000a4b64:     	ldr	w5, [x30]
1000a4b68:     	cmp	w5, #0x1
1000a4b6c:     	b.eq	0x1000a4b44 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
1000a4b70:     	cmp	w5, #0x2
1000a4b74:     	b.ne	0x1000a4ba0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x258>
1000a4b78:     	ldr	x5, [x30, #0x8]
1000a4b7c:     	cmp	x5, x22
1000a4b80:     	b.ne	0x1000a4b4c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x204>
1000a4b84:     	ldr	x5, [x30, #0x10]
1000a4b88:     	str	w3, [x30]
1000a4b8c:     	str	x23, [x30, #0x10]
1000a4b90:     	strb	wzr, [sp, #0xc]
1000a4b94:     	mov	w24, #0x1               ; =1
1000a4b98:     	mov	x23, x5
1000a4b9c:     	b	0x1000a49e8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xa0>
1000a4ba0:     	cmp	x25, x24
1000a4ba4:     	csel	x25, x26, x25, eq
1000a4ba8:     	cmp	x25, x24
1000a4bac:     	b.hs	0x1000a49dc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
1000a4bb0:     	cmp	x7, #0x2, lsl #12       ; =0x2000
1000a4bb4:     	b.hs	0x1000a49dc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
1000a4bb8:     	add	x7, x7, #0x1
1000a4bbc:     	str	x7, [x0, #0x18]
1000a4bc0:     	ldr	x5, [x0, #0x10]
1000a4bc4:     	madd	x24, x25, x17, x5
1000a4bc8:     	ldr	w27, [x24]
1000a4bcc:     	cmp	w27, #0x1
1000a4bd0:     	b.ne	0x1000a4bec <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2a4>
1000a4bd4:     	subs	x5, x19, #0x1
1000a4bd8:     	csel	x19, xzr, x5, lo
1000a4bdc:     	str	x19, [x0, #0x20]
1000a4be0:     	str	w3, [x24]
1000a4be4:     	stp	x22, x23, [x24, #0x8]
1000a4be8:     	b	0x1000a4c10 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2c8>
1000a4bec:     	ldp	x25, x26, [x24, #0x8]
1000a4bf0:     	str	w3, [x24]
1000a4bf4:     	stp	x22, x23, [x24, #0x8]
1000a4bf8:     	cbz	w27, 0x1000a4c10 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2c8>
1000a4bfc:     	strb	wzr, [sp, #0xc]
1000a4c00:     	mov	w24, #0x1               ; =1
1000a4c04:     	mov	x23, x26
1000a4c08:     	mov	x22, x25
1000a4c0c:     	b	0x1000a49e8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xa0>
1000a4c10:     	strb	wzr, [sp, #0xc]
1000a4c14:     	mul	x6, x6, x4
1000a4c18:     	add	x20, x20, #0x1
1000a4c1c:     	cmp	x20, x12
1000a4c20:     	b.ne	0x1000a4a00 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xb8>
1000a4c24:     	b	0x1000a49bc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x74>
1000a4c28:     	ldp	x29, x30, [sp, #0x60]
1000a4c2c:     	ldp	x20, x19, [sp, #0x50]
1000a4c30:     	ldp	x22, x21, [sp, #0x40]
1000a4c34:     	ldp	x24, x23, [sp, #0x30]
1000a4c38:     	ldp	x26, x25, [sp, #0x20]
1000a4c3c:     	ldp	x28, x27, [sp, #0x10]
1000a4c40:     	add	sp, sp, #0x70
1000a4c44:     	eor	x10, x6, x6, lsr #30
1000a4c48:     	mul	x9, x10, x9
1000a4c4c:     	eor	x9, x9, x9, lsr #27
1000a4c50:     	mul	x8, x9, x8
1000a4c54:     	eor	x0, x8, x8, lsr #31
1000a4c58:     	ret
1000a4c5c:     	add	x11, x11, x1
1000a4c60:     	str	x11, [x0, #0x48]
1000a4c64:     	eor	x10, x10, x10, lsr #30
1000a4c68:     	mul	x9, x10, x9
1000a4c6c:     	eor	x9, x9, x9, lsr #27
1000a4c70:     	mul	x8, x9, x8
1000a4c74:     	eor	x0, x8, x8, lsr #31
1000a4c78:     	ret
