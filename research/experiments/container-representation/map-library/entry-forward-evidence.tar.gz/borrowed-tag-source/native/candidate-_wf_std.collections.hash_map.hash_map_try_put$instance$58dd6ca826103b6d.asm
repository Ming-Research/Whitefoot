00000001000a8208 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d>:
1000a8208:     	mov	x9, x3
1000a820c:     	mov	x3, x2
1000a8210:     	ldrb	w8, [x4, #0x8]
1000a8214:     	tbz	w8, #0x0, 0x1000a828c <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x84>
1000a8218:     	mov	x8, #0x0                ; =0
1000a821c:     	ldr	x10, [x1]
1000a8220:     	cbz	x10, 0x1000a82d0 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xc8>
1000a8224:     	udiv	x11, x8, x10
1000a8228:     	msub	x8, x11, x10, x8
1000a822c:     	ldr	x11, [x1, #0x10]
1000a8230:     	mov	w12, #0x110             ; =272
1000a8234:     	mov	x13, x10
1000a8238:     	mov	x2, x10
1000a823c:     	b	0x1000a825c <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x54>
1000a8240:     	cmp	x2, x10
1000a8244:     	csel	x2, x8, x2, eq
1000a8248:     	add	x14, x8, #0x1
1000a824c:     	cmp	x14, x10
1000a8250:     	csinc	x8, xzr, x8, hs
1000a8254:     	subs	x13, x13, #0x1
1000a8258:     	b.eq	0x1000a82d4 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xcc>
1000a825c:     	madd	x14, x8, x12, x11
1000a8260:     	ldr	w15, [x14]
1000a8264:     	cmp	w15, #0x1
1000a8268:     	b.eq	0x1000a8240 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x38>
1000a826c:     	cmp	w15, #0x2
1000a8270:     	b.ne	0x1000a8320 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x118>
1000a8274:     	ldr	x14, [x14, #0x8]
1000a8278:     	cmp	x14, x3
1000a827c:     	b.ne	0x1000a8248 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x40>
1000a8280:     	mov	x2, x8
1000a8284:     	mov	x4, x9
1000a8288:     	b	0x1000ab0f0 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449>
1000a828c:     	ldr	x8, [x4]
1000a8290:     	eor	x8, x8, x3
1000a8294:     	eor	x8, x8, x8, lsr #30
1000a8298:     	mov	x10, #0xe5b9            ; =58809
1000a829c:     	movk	x10, #0x1ce4, lsl #16
1000a82a0:     	movk	x10, #0x476d, lsl #32
1000a82a4:     	movk	x10, #0xbf58, lsl #48
1000a82a8:     	mul	x8, x8, x10
1000a82ac:     	eor	x8, x8, x8, lsr #27
1000a82b0:     	mov	x10, #0x11eb            ; =4587
1000a82b4:     	movk	x10, #0x1331, lsl #16
1000a82b8:     	movk	x10, #0x49bb, lsl #32
1000a82bc:     	movk	x10, #0x94d0, lsl #48
1000a82c0:     	mul	x8, x8, x10
1000a82c4:     	eor	x8, x8, x8, lsr #31
1000a82c8:     	ldr	x10, [x1]
1000a82cc:     	cbnz	x10, 0x1000a8224 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x1c>
1000a82d0:     	mov	x2, #0x0                ; =0
1000a82d4:     	cmp	x2, x10
1000a82d8:     	b.hs	0x1000a8330 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x128>
1000a82dc:     	ldr	x8, [x1, #0x18]
1000a82e0:     	lsr	x10, x8, #13
1000a82e4:     	cbnz	x10, 0x1000a8330 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x128>
1000a82e8:     	add	x8, x8, #0x1
1000a82ec:     	str	x8, [x1, #0x18]
1000a82f0:     	ldr	x8, [x1, #0x10]
1000a82f4:     	mov	w10, #0x110             ; =272
1000a82f8:     	mul	x10, x2, x10
1000a82fc:     	ldr	w8, [x8, x10]
1000a8300:     	cmp	w8, #0x1
1000a8304:     	b.ne	0x1000a8318 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x110>
1000a8308:     	ldr	x8, [x1, #0x20]
1000a830c:     	subs	x8, x8, #0x1
1000a8310:     	csel	x8, xzr, x8, lo
1000a8314:     	str	x8, [x1, #0x20]
1000a8318:     	mov	x4, x9
1000a831c:     	b	0x1000ab0f0 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449>
1000a8320:     	cmp	x2, x10
1000a8324:     	csel	x2, x8, x2, eq
1000a8328:     	cmp	x2, x10
1000a832c:     	b.lo	0x1000a82dc <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xd4>
1000a8330:     	ldp	q0, q1, [x9]
1000a8334:     	ldp	q2, q3, [x9, #0x20]
1000a8338:     	ldp	q4, q5, [x9, #0x40]
1000a833c:     	ldp	q6, q7, [x9, #0x60]
1000a8340:     	ldp	q16, q17, [x9, #0x80]
1000a8344:     	ldp	q18, q19, [x9, #0xa0]
1000a8348:     	ldp	q20, q21, [x9, #0xc0]
1000a834c:     	ldp	q22, q23, [x9, #0xe0]
1000a8350:     	stp	xzr, x3, [x0]
1000a8354:     	mov	w8, #0x1                ; =1
1000a8358:     	str	w8, [x0]
1000a835c:     	strb	w8, [x0, #0x4]
1000a8360:     	stp	q0, q1, [x0, #0x10]
1000a8364:     	stp	q2, q3, [x0, #0x30]
1000a8368:     	stp	q4, q5, [x0, #0x50]
1000a836c:     	stp	q6, q7, [x0, #0x70]
1000a8370:     	stp	q16, q17, [x0, #0x90]
1000a8374:     	stp	q18, q19, [x0, #0xb0]
1000a8378:     	stp	q20, q21, [x0, #0xd0]
1000a837c:     	stp	q22, q23, [x0, #0xf0]
1000a8380:     	ret

