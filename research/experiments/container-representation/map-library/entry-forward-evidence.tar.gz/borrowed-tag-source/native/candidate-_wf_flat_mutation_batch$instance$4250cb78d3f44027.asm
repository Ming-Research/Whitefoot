00000001000a4594 <_wf_flat_mutation_batch$instance$4250cb78d3f44027>:
1000a4594:     	stp	x28, x27, [sp, #-0x60]!
1000a4598:     	stp	x26, x25, [sp, #0x10]
1000a459c:     	stp	x24, x23, [sp, #0x20]
1000a45a0:     	stp	x22, x21, [sp, #0x30]
1000a45a4:     	stp	x20, x19, [sp, #0x40]
1000a45a8:     	stp	x29, x30, [sp, #0x50]
1000a45ac:     	sub	sp, sp, #0x3a0
1000a45b0:     	ldr	x24, [x0, #0x38]
1000a45b4:     	str	x1, [sp, #0x8]
1000a45b8:     	cbz	x1, 0x1000a4b34 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x5a0>
1000a45bc:     	mov	x19, x0
1000a45c0:     	ldr	x26, [x0, #0x40]
1000a45c4:     	cbz	x26, 0x1000a4b24 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x590>
1000a45c8:     	mov	x21, x2
1000a45cc:     	str	xzr, [sp, #0x18]
1000a45d0:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xc8c>
1000a45d4:     	ldr	q0, [x8, #0x310]
1000a45d8:     	str	q0, [sp, #0x180]
1000a45dc:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xc8c>
1000a45e0:     	ldr	q0, [x8, #0xc0]
1000a45e4:     	str	q0, [sp, #0x170]
1000a45e8:     	add	x27, sp, #0x2a0
1000a45ec:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xc8c>
1000a45f0:     	ldr	q0, [x8, #0xb0]
1000a45f4:     	str	q0, [sp, #0x160]
1000a45f8:     	mov	w28, #0x1               ; =1
1000a45fc:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xc8c>
1000a4600:     	ldr	q0, [x8, #0xe0]
1000a4604:     	str	q0, [sp, #0x150]
1000a4608:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xc8c>
1000a460c:     	ldr	q0, [x8, #0xd0]
1000a4610:     	str	q0, [sp, #0x140]
1000a4614:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xc8c>
1000a4618:     	ldr	q0, [x8, #0x100]
1000a461c:     	str	q0, [sp, #0x130]
1000a4620:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xc8c>
1000a4624:     	ldr	q0, [x8, #0xf0]
1000a4628:     	str	q0, [sp, #0x120]
1000a462c:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xc8c>
1000a4630:     	ldr	q0, [x8, #0x120]
1000a4634:     	str	q0, [sp, #0x110]
1000a4638:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xc8c>
1000a463c:     	ldr	q0, [x8, #0x110]
1000a4640:     	str	q0, [sp, #0x100]
1000a4644:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xc8c>
1000a4648:     	ldr	q0, [x8, #0x140]
1000a464c:     	str	q0, [sp, #0xf0]
1000a4650:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xc8c>
1000a4654:     	ldr	q0, [x8, #0x130]
1000a4658:     	str	q0, [sp, #0xe0]
1000a465c:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xc8c>
1000a4660:     	ldr	q0, [x8, #0x160]
1000a4664:     	str	q0, [sp, #0xd0]
1000a4668:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xc8c>
1000a466c:     	ldr	q0, [x8, #0x150]
1000a4670:     	str	q0, [sp, #0xc0]
1000a4674:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xc8c>
1000a4678:     	ldr	q0, [x8, #0x180]
1000a467c:     	str	q0, [sp, #0xb0]
1000a4680:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0xc8c>
1000a4684:     	ldr	q0, [x8, #0x170]
1000a4688:     	str	q0, [sp, #0xa0]
1000a468c:     	mov	w20, #0x83              ; =131
1000a4690:     	mov	w22, #0x110             ; =272
1000a4694:     	ldr	x10, [x19, #0x48]
1000a4698:     	add	x10, x10, #0x1
1000a469c:     	str	x10, [sp, #0x10]
1000a46a0:     	cbz	x26, 0x1000a4af8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x564>
1000a46a4:     	mov	x23, #0x0               ; =0
1000a46a8:     	ldr	x8, [x19, #0x38]
1000a46ac:     	madd	x25, x10, x26, x8
1000a46b0:     	b	0x1000a47bc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x228>
1000a46b4:     	ldrb	w8, [sp, #0x194]
1000a46b8:     	tst	w8, #0x1
1000a46bc:     	ldp	x9, x8, [sp, #0x198]
1000a46c0:     	madd	x8, x9, x20, x8
1000a46c4:     	ldp	x10, x9, [sp, #0x1a8]
1000a46c8:     	madd	x8, x8, x20, x10
1000a46cc:     	madd	x8, x8, x20, x9
1000a46d0:     	ldp	x10, x9, [sp, #0x1b8]
1000a46d4:     	madd	x8, x8, x20, x10
1000a46d8:     	madd	x8, x8, x20, x9
1000a46dc:     	ldp	x10, x9, [sp, #0x1c8]
1000a46e0:     	madd	x8, x8, x20, x10
1000a46e4:     	madd	x8, x8, x20, x9
1000a46e8:     	ldp	x10, x9, [sp, #0x1d8]
1000a46ec:     	madd	x8, x8, x20, x10
1000a46f0:     	madd	x8, x8, x20, x9
1000a46f4:     	ldp	x10, x9, [sp, #0x1e8]
1000a46f8:     	madd	x8, x8, x20, x10
1000a46fc:     	madd	x8, x8, x20, x9
1000a4700:     	ldp	x10, x9, [sp, #0x1f8]
1000a4704:     	madd	x8, x8, x20, x10
1000a4708:     	madd	x8, x8, x20, x9
1000a470c:     	ldr	x9, [sp, #0x208]
1000a4710:     	madd	x8, x8, x20, x9
1000a4714:     	ldr	x9, [sp, #0x210]
1000a4718:     	madd	x8, x8, x20, x9
1000a471c:     	ldr	x9, [sp, #0x218]
1000a4720:     	madd	x8, x8, x20, x9
1000a4724:     	ldr	x9, [sp, #0x220]
1000a4728:     	madd	x8, x8, x20, x9
1000a472c:     	ldr	x9, [sp, #0x228]
1000a4730:     	madd	x8, x8, x20, x9
1000a4734:     	ldr	x9, [sp, #0x230]
1000a4738:     	madd	x8, x8, x20, x9
1000a473c:     	ldr	x9, [sp, #0x238]
1000a4740:     	madd	x8, x8, x20, x9
1000a4744:     	ldr	x9, [sp, #0x240]
1000a4748:     	madd	x8, x8, x20, x9
1000a474c:     	ldr	x9, [sp, #0x248]
1000a4750:     	madd	x8, x8, x20, x9
1000a4754:     	ldr	x9, [sp, #0x250]
1000a4758:     	madd	x8, x8, x20, x9
1000a475c:     	ldr	x9, [sp, #0x258]
1000a4760:     	madd	x8, x8, x20, x9
1000a4764:     	ldr	x9, [sp, #0x260]
1000a4768:     	madd	x8, x8, x20, x9
1000a476c:     	ldr	x9, [sp, #0x268]
1000a4770:     	madd	x8, x8, x20, x9
1000a4774:     	ldr	x9, [sp, #0x270]
1000a4778:     	madd	x8, x8, x20, x9
1000a477c:     	ldr	x9, [sp, #0x278]
1000a4780:     	madd	x8, x8, x20, x9
1000a4784:     	ldr	x9, [sp, #0x280]
1000a4788:     	madd	x8, x8, x20, x9
1000a478c:     	ldr	x9, [sp, #0x288]
1000a4790:     	add	x9, x9, x24
1000a4794:     	ldr	x10, [sp, #0x290]
1000a4798:     	madd	x8, x8, x20, x9
1000a479c:     	cinc	x9, x28, ne
1000a47a0:     	add	x9, x9, x10
1000a47a4:     	madd	x8, x8, x20, x9
1000a47a8:     	ldr	x9, [sp, #0x298]
1000a47ac:     	madd	x24, x8, x20, x9
1000a47b0:     	add	x23, x23, #0x1
1000a47b4:     	cmp	x23, x26
1000a47b8:     	b.eq	0x1000a4af8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x564>
1000a47bc:     	orr	x2, x28, x23, lsl #1
1000a47c0:     	cbz	x21, 0x1000a4a04 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x470>
1000a47c4:     	ldr	x8, [x19, #0x18]
1000a47c8:     	cbz	x8, 0x1000a4a00 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x46c>
1000a47cc:     	ldrb	w9, [x19, #0x30]
1000a47d0:     	tbz	w9, #0x0, 0x1000a47e4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x250>
1000a47d4:     	mov	x9, #0x0                ; =0
1000a47d8:     	ldr	x10, [x19]
1000a47dc:     	cbnz	x10, 0x1000a4828 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x294>
1000a47e0:     	b	0x1000a4a00 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x46c>
1000a47e4:     	ldr	x9, [x19, #0x28]
1000a47e8:     	eor	x9, x9, x2
1000a47ec:     	eor	x9, x9, x9, lsr #30
1000a47f0:     	mov	x10, #0xe5b9            ; =58809
1000a47f4:     	movk	x10, #0x1ce4, lsl #16
1000a47f8:     	movk	x10, #0x476d, lsl #32
1000a47fc:     	movk	x10, #0xbf58, lsl #48
1000a4800:     	mul	x9, x9, x10
1000a4804:     	eor	x9, x9, x9, lsr #27
1000a4808:     	mov	x10, #0x11eb            ; =4587
1000a480c:     	movk	x10, #0x1331, lsl #16
1000a4810:     	movk	x10, #0x49bb, lsl #32
1000a4814:     	movk	x10, #0x94d0, lsl #48
1000a4818:     	mul	x9, x9, x10
1000a481c:     	eor	x9, x9, x9, lsr #31
1000a4820:     	ldr	x10, [x19]
1000a4824:     	cbz	x10, 0x1000a4a00 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x46c>
1000a4828:     	udiv	x11, x9, x10
1000a482c:     	msub	x11, x11, x10, x9
1000a4830:     	ldr	x12, [x19, #0x10]
1000a4834:     	mov	x13, x10
1000a4838:     	b	0x1000a4850 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2bc>
1000a483c:     	add	x9, x11, #0x1
1000a4840:     	cmp	x9, x10
1000a4844:     	csinc	x11, xzr, x11, hs
1000a4848:     	subs	x13, x13, #0x1
1000a484c:     	b.eq	0x1000a4a00 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x46c>
1000a4850:     	madd	x9, x11, x22, x12
1000a4854:     	ldr	w14, [x9]
1000a4858:     	cmp	w14, #0x1
1000a485c:     	b.eq	0x1000a483c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2a8>
1000a4860:     	cmp	w14, #0x2
1000a4864:     	b.ne	0x1000a4a00 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x46c>
1000a4868:     	ldr	x14, [x9, #0x8]
1000a486c:     	cmp	x14, x2
1000a4870:     	b.ne	0x1000a483c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2a8>
1000a4874:     	ldp	x11, x10, [x9, #0x10]
1000a4878:     	stp	x10, x11, [sp, #0x90]
1000a487c:     	ldp	x11, x10, [x9, #0x20]
1000a4880:     	stp	x10, x11, [sp, #0x80]
1000a4884:     	ldp	x14, x15, [x9, #0x30]
1000a4888:     	ldp	x16, x17, [x9, #0x40]
1000a488c:     	ldp	x0, x1, [x9, #0x50]
1000a4890:     	ldp	x3, x4, [x9, #0x60]
1000a4894:     	ldp	x5, x6, [x9, #0x70]
1000a4898:     	ldp	x7, x30, [x9, #0x80]
1000a489c:     	ldp	x11, x10, [x9, #0x90]
1000a48a0:     	stp	x10, x11, [sp, #0x70]
1000a48a4:     	ldp	x11, x10, [x9, #0xa0]
1000a48a8:     	stp	x10, x11, [sp, #0x60]
1000a48ac:     	ldp	x11, x10, [x9, #0xb0]
1000a48b0:     	stp	x10, x11, [sp, #0x50]
1000a48b4:     	ldp	x11, x10, [x9, #0xc0]
1000a48b8:     	stp	x10, x11, [sp, #0x40]
1000a48bc:     	ldp	x11, x10, [x9, #0xd0]
1000a48c0:     	stp	x10, x11, [sp, #0x30]
1000a48c4:     	ldp	x11, x10, [x9, #0xe0]
1000a48c8:     	stp	x10, x11, [sp, #0x20]
1000a48cc:     	str	w28, [x9]
1000a48d0:     	movi.2d	v0, #0000000000000000
1000a48d4:     	stur	q0, [x9, #0x8]
1000a48d8:     	stur	q0, [x9, #0x18]
1000a48dc:     	stur	q0, [x9, #0x28]
1000a48e0:     	stur	q0, [x9, #0x38]
1000a48e4:     	stur	q0, [x9, #0x48]
1000a48e8:     	stur	q0, [x9, #0x58]
1000a48ec:     	stur	q0, [x9, #0x68]
1000a48f0:     	stur	q0, [x9, #0x78]
1000a48f4:     	stur	q0, [x9, #0x88]
1000a48f8:     	stur	q0, [x9, #0x98]
1000a48fc:     	stur	q0, [x9, #0xa8]
1000a4900:     	stur	q0, [x9, #0xb8]
1000a4904:     	stur	q0, [x9, #0xc8]
1000a4908:     	stur	q0, [x9, #0xd8]
1000a490c:     	ldp	x12, x13, [x9, #0xf0]
1000a4910:     	stur	q0, [x9, #0xe8]
1000a4914:     	ldp	x10, x11, [x9, #0x100]
1000a4918:     	stur	q0, [x9, #0xf8]
1000a491c:     	str	xzr, [x9, #0x108]
1000a4920:     	sub	x8, x8, #0x1
1000a4924:     	ldr	x9, [x19, #0x20]
1000a4928:     	adds	x9, x9, #0x1
1000a492c:     	csinv	x9, x9, xzr, lo
1000a4930:     	stp	x8, x9, [x19, #0x18]
1000a4934:     	ldp	x9, x8, [sp, #0x90]
1000a4938:     	madd	x8, x2, x20, x8
1000a493c:     	madd	x8, x8, x20, x9
1000a4940:     	ldr	x9, [sp, #0x88]
1000a4944:     	madd	x8, x8, x20, x9
1000a4948:     	ldr	x9, [sp, #0x80]
1000a494c:     	madd	x8, x8, x20, x9
1000a4950:     	madd	x8, x8, x20, x14
1000a4954:     	madd	x8, x8, x20, x15
1000a4958:     	madd	x8, x8, x20, x16
1000a495c:     	madd	x8, x8, x20, x17
1000a4960:     	madd	x8, x8, x20, x0
1000a4964:     	madd	x8, x8, x20, x1
1000a4968:     	madd	x8, x8, x20, x3
1000a496c:     	madd	x8, x8, x20, x4
1000a4970:     	madd	x8, x8, x20, x5
1000a4974:     	madd	x8, x8, x20, x6
1000a4978:     	madd	x8, x8, x20, x7
1000a497c:     	madd	x8, x8, x20, x30
1000a4980:     	ldr	x9, [sp, #0x78]
1000a4984:     	madd	x8, x8, x20, x9
1000a4988:     	ldr	x9, [sp, #0x70]
1000a498c:     	madd	x8, x8, x20, x9
1000a4990:     	ldr	x9, [sp, #0x68]
1000a4994:     	madd	x8, x8, x20, x9
1000a4998:     	ldr	x9, [sp, #0x60]
1000a499c:     	madd	x8, x8, x20, x9
1000a49a0:     	ldr	x9, [sp, #0x58]
1000a49a4:     	madd	x8, x8, x20, x9
1000a49a8:     	ldr	x9, [sp, #0x50]
1000a49ac:     	madd	x8, x8, x20, x9
1000a49b0:     	ldr	x9, [sp, #0x48]
1000a49b4:     	madd	x8, x8, x20, x9
1000a49b8:     	ldr	x9, [sp, #0x40]
1000a49bc:     	madd	x8, x8, x20, x9
1000a49c0:     	ldr	x9, [sp, #0x38]
1000a49c4:     	madd	x8, x8, x20, x9
1000a49c8:     	ldr	x9, [sp, #0x30]
1000a49cc:     	madd	x8, x8, x20, x9
1000a49d0:     	ldr	x9, [sp, #0x28]
1000a49d4:     	madd	x8, x8, x20, x9
1000a49d8:     	ldr	x9, [sp, #0x20]
1000a49dc:     	madd	x8, x8, x20, x9
1000a49e0:     	madd	x8, x8, x20, x12
1000a49e4:     	madd	x8, x8, x20, x13
1000a49e8:     	madd	x8, x8, x20, x10
1000a49ec:     	mov	w9, #0x4309             ; =17161
1000a49f0:     	madd	x9, x24, x9, x11
1000a49f4:     	madd	x8, x8, x20, x9
1000a49f8:     	add	x24, x8, #0x83
1000a49fc:     	b	0x1000a4a04 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x470>
1000a4a00:     	mul	x24, x24, x20
1000a4a04:     	add	x8, x25, x23
1000a4a08:     	dup.2d	v0, x8
1000a4a0c:     	ldr	q1, [sp, #0x180]
1000a4a10:     	add.2d	v1, v0, v1
1000a4a14:     	stur	q1, [x27, #0x8]
1000a4a18:     	add	x9, x8, #0x1f
1000a4a1c:     	ldr	q1, [sp, #0x170]
1000a4a20:     	add.2d	v1, v0, v1
1000a4a24:     	stur	q1, [x27, #0x18]
1000a4a28:     	ldr	q1, [sp, #0x160]
1000a4a2c:     	add.2d	v1, v0, v1
1000a4a30:     	stur	q1, [x27, #0x28]
1000a4a34:     	ldr	q1, [sp, #0x150]
1000a4a38:     	add.2d	v1, v0, v1
1000a4a3c:     	stur	q1, [x27, #0x38]
1000a4a40:     	ldr	q1, [sp, #0x140]
1000a4a44:     	add.2d	v1, v0, v1
1000a4a48:     	stur	q1, [x27, #0x48]
1000a4a4c:     	ldr	q1, [sp, #0x130]
1000a4a50:     	add.2d	v1, v0, v1
1000a4a54:     	stur	q1, [x27, #0x58]
1000a4a58:     	ldr	q1, [sp, #0x120]
1000a4a5c:     	add.2d	v1, v0, v1
1000a4a60:     	stur	q1, [x27, #0x68]
1000a4a64:     	ldr	q1, [sp, #0x110]
1000a4a68:     	add.2d	v1, v0, v1
1000a4a6c:     	stur	q1, [x27, #0x78]
1000a4a70:     	ldr	q1, [sp, #0x100]
1000a4a74:     	add.2d	v1, v0, v1
1000a4a78:     	stur	q1, [x27, #0x88]
1000a4a7c:     	ldr	q1, [sp, #0xf0]
1000a4a80:     	add.2d	v1, v0, v1
1000a4a84:     	stur	q1, [x27, #0x98]
1000a4a88:     	ldr	q1, [sp, #0xe0]
1000a4a8c:     	add.2d	v1, v0, v1
1000a4a90:     	stur	q1, [x27, #0xa8]
1000a4a94:     	ldr	q1, [sp, #0xd0]
1000a4a98:     	add.2d	v1, v0, v1
1000a4a9c:     	stur	q1, [x27, #0xb8]
1000a4aa0:     	ldr	q1, [sp, #0xc0]
1000a4aa4:     	add.2d	v1, v0, v1
1000a4aa8:     	stur	q1, [x27, #0xc8]
1000a4aac:     	ldr	q1, [sp, #0xb0]
1000a4ab0:     	add.2d	v1, v0, v1
1000a4ab4:     	stur	q1, [x27, #0xd8]
1000a4ab8:     	ldr	q1, [sp, #0xa0]
1000a4abc:     	add.2d	v0, v0, v1
1000a4ac0:     	stur	q0, [x27, #0xe8]
1000a4ac4:     	str	x8, [sp, #0x2a0]
1000a4ac8:     	str	x9, [sp, #0x398]
1000a4acc:     	add	x0, sp, #0x190
1000a4ad0:     	add	x3, sp, #0x2a0
1000a4ad4:     	add	x4, x19, #0x28
1000a4ad8:     	mov	x1, x19
1000a4adc:     	bl	0x1000a8208 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d>
1000a4ae0:     	ldr	w8, [sp, #0x190]
1000a4ae4:     	cbnz	w8, 0x1000a46b4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x120>
1000a4ae8:     	mul	x24, x24, x20
1000a4aec:     	add	x23, x23, #0x1
1000a4af0:     	cmp	x23, x26
1000a4af4:     	b.ne	0x1000a47bc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x228>
1000a4af8:     	ldp	x10, x9, [sp, #0x10]
1000a4afc:     	str	x10, [x19, #0x48]
1000a4b00:     	add	x9, x9, #0x1
1000a4b04:     	ldr	x8, [sp, #0x8]
1000a4b08:     	cmp	x9, x8
1000a4b0c:     	b.eq	0x1000a4b34 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x5a0>
1000a4b10:     	ldr	x26, [x19, #0x40]
1000a4b14:     	add	x10, x10, #0x1
1000a4b18:     	stp	x10, x9, [sp, #0x10]
1000a4b1c:     	cbnz	x26, 0x1000a46a4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x110>
1000a4b20:     	b	0x1000a4af8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x564>
1000a4b24:     	ldr	x8, [x19, #0x48]
1000a4b28:     	ldr	x9, [sp, #0x8]
1000a4b2c:     	add	x8, x8, x9
1000a4b30:     	str	x8, [x19, #0x48]
1000a4b34:     	eor	x8, x24, x24, lsr #30
1000a4b38:     	mov	x9, #0xe5b9             ; =58809
1000a4b3c:     	movk	x9, #0x1ce4, lsl #16
1000a4b40:     	movk	x9, #0x476d, lsl #32
1000a4b44:     	movk	x9, #0xbf58, lsl #48
1000a4b48:     	mul	x8, x8, x9
1000a4b4c:     	eor	x8, x8, x8, lsr #27
1000a4b50:     	mov	x9, #0x11eb             ; =4587
1000a4b54:     	movk	x9, #0x1331, lsl #16
1000a4b58:     	movk	x9, #0x49bb, lsl #32
1000a4b5c:     	movk	x9, #0x94d0, lsl #48
1000a4b60:     	mul	x8, x8, x9
1000a4b64:     	eor	x0, x8, x8, lsr #31
1000a4b68:     	add	sp, sp, #0x3a0
1000a4b6c:     	ldp	x29, x30, [sp, #0x50]
1000a4b70:     	ldp	x20, x19, [sp, #0x40]
1000a4b74:     	ldp	x22, x21, [sp, #0x30]
1000a4b78:     	ldp	x24, x23, [sp, #0x20]
1000a4b7c:     	ldp	x26, x25, [sp, #0x10]
1000a4b80:     	ldp	x28, x27, [sp], #0x60
1000a4b84:     	ret

