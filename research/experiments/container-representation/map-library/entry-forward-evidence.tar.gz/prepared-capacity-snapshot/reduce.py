import pathlib,csv,json,statistics,collections,hashlib
D=pathlib.Path('/private/tmp/whitefoot-map-capacity-snapshot');T=D/'timing'
meta=json.loads((T/'metadata.json').read_text());assert len(meta['stages'])==4 and all(x['exit']==0 for x in meta['stages']);assert meta['images_before']==meta['images_after']
groups=collections.defaultdict(list);allrows=[];original={}
for arm,cohort in [('control',0),('candidate',0),('candidate',1),('control',1)]:
 rows=list(csv.DictReader((T/f'{arm}-cohort-{cohort}.csv').open()));assert len(rows)==288
 original[arm,cohort]=rows
 for r in rows:
  groups[arm,cohort,r['variant'],r['width'],int(r['slots']),r['operation']].append(int(r['elapsed_ns'])/int(r['operations']))
  allrows.append({'arm':arm,**r})
for cohort in [0,1]:
 assert [{k:v for k,v in r.items() if k!='elapsed_ns'} for r in original['control',cohort]]==[{k:v for k,v in r.items() if k!='elapsed_ns'} for r in original['candidate',cohort]]
assert len(allrows)==1152 and all(len(v)==9 for v in groups.values())
with (D/'samples.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(allrows[0]));w.writeheader();w.writerows(allrows)
def stats(xs):return dict(min=min(xs),median=statistics.median(xs),max=max(xs))
def direction(a,b):return 'gain' if max(b)<min(a) else 'loss' if min(b)>max(a) else 'overlap'
variants=['whitefoot-flat','whitefoot-chain','rust-hash-map','cpp-unordered-map'];assert set(r['variant'] for r in allrows)==set(variants)
cells=[]
for width in ['word8','wide256']:
 for n in [64,4096]:
  for op in ['replace','churn']:
   cohorts=[];ratios=[]
   for c in [0,1]:
    data={v:{arm:stats(groups[arm,c,v,width,n,op]) for arm in ['control','candidate']} for v in variants}
    ratios.append(data['whitefoot-flat']['candidate']['median']/data['whitefoot-flat']['control']['median'])
    drifts={v:max(data[v]['control']['median'],data[v]['candidate']['median'])/min(data[v]['control']['median'],data[v]['candidate']['median'])-1 for v in variants[1:]}
    cohorts.append({'cohort':c,'data':data,'direction':direction(groups['control',c,'whitefoot-flat',width,n,op],groups['candidate',c,'whitefoot-flat',width,n,op]),'ratio':ratios[-1],'peer_drift':drifts})
   cells.append(dict(width=width,slots=n,operation=op,cohorts=cohorts,ratio_spread=max(ratios)/min(ratios)-1))
result={'rows':len(allrows),'minimum_elapsed_ns':min(int(r['elapsed_ns']) for r in allrows),'all_intervals_pass':all(int(r['elapsed_ns'])>=1000000 for r in allrows),'cells':cells,'max_ratio_spread':max(c['ratio_spread'] for c in cells),'max_peer_drift':max(d for cell in cells for c in cell['cohorts'] for d in c['peer_drift'].values()),'statuses':meta['stages']}
scalar=[c for c in cells if c['width']=='word8']; result['scalar_two_cohort_gains']=[(c['slots'],c['operation']) for c in scalar if all(x['direction']=='gain' for x in c['cohorts'])];result['scalar_losses']=[(c['slots'],c['operation'],x['cohort']) for c in scalar for x in c['cohorts'] if x['direction']=='loss']; result['full_criterion_pass']=bool(result['scalar_two_cohort_gains']) and not result['scalar_losses'] and result['all_intervals_pass'] and result['max_ratio_spread']<=.10 and result['max_peer_drift']<=.10
(D/'reduction.json').write_text(json.dumps(result,indent=2)+'\n')
lines=['All values ns/operation; each range contains all9samples.','width count operation cohort WFcontrol median[min,max] WFcandidate median[min,max] ratio direction chainDrift RustDrift CppDrift']
for cell in cells:
 for c in cell['cohorts']:
  fmt=lambda s:f"{s['median']:.5f}[{s['min']:.5f},{s['max']:.5f}]"
  a=c['data']['whitefoot-flat'];lines.append(f"{cell['width']} {cell['slots']} {cell['operation']} {c['cohort']} {fmt(a['control'])} {fmt(a['candidate'])} {c['ratio']:.6f} {c['direction']} "+' '.join(f'{100*x:.3f}%' for x in c['peer_drift'].values()))
  lines.append('  peers candidate '+', '.join(v+' '+fmt(c['data'][v]['candidate']) for v in variants[1:]))
lines.append(json.dumps({k:v for k,v in result.items() if k not in ['cells','statuses']},indent=2));(D/'reduction.txt').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))
