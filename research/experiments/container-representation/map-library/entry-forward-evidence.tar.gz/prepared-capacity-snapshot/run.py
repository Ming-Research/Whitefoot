import pathlib,re,json,hashlib,difflib,subprocess,time,os,sys
D=pathlib.Path('/private/tmp/whitefoot-map-capacity-snapshot')
A=pathlib.Path('/private/tmp/whitefoot-map-descriptor-alias')
R=pathlib.Path('/private/tmp/whitefoot-container-recovery-20261001')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if sys.argv[1]=='prepare':
 s=(A/'mask.optimized.ll').read_text();audit=json.loads((A/'access-classification.json').read_text())
 assert hashlib.sha256(s.encode()).hexdigest()==audit['optimized_sha256']
 m=re.search(r'^define [^\n]*@"wf_flat_mutation_batch\$instance\$c7c8cd11e7f079bd"[^\n]*\n.*?^}',s,re.M|re.S);assert m
 f=m.group();assert 'dereferenceable(80) %v0' in f
 access=[l.strip() for l in f.splitlines() if re.search(r'\b(load|store)\b',l) or '@llvm.memset.p0.i64(' in l]
 assert access==[x['access'] for x in audit['accesses']] and len(access)==42
 owner_stores=[x for x in audit['accesses'] if x['kind']=='owner' and x['access'].startswith('store ')]
 permitted={'%wf.slot.0.sroa.1.0.v0.sroa_idx.i.i18':24,'%wf.slot.0.sroa.2.0.v0.sroa_idx.i.i':32,'%wf.slot.1.sroa.1.0.v0.sroa_idx':72}
 for x in owner_stores:
  p=x['pointer'];assert p in permitted
  assert f'{p} = getelementptr inbounds nuw i8, ptr %v0, i64 {permitted[p]}' in f
 calls=[l.strip() for l in f.splitlines() if 'call ' in l]
 allowed={'llvm.experimental.noalias.scope.decl','llvm.ctpop.i64','llvm.assume','llvm.memset.p0.i64','llvm.uadd.sat.i64','llvm.usub.sat.i64'}
 for l in calls:
  c=re.search(r'@([^ (]+)\(',l);assert c and c[1] in allowed,l
 loads=re.findall(r'^  (%[^ ]+) = load i64, ptr %v0, align 8[^\n]*\n',f,re.M)
 assert loads==['%t1.i.i.i.i.us','%t1.i.us'],loads
 lines=[l for l in f.splitlines(True) if not any(l.startswith('  '+v+' = load ') for v in loads)]
 changed=''.join(lines)
 for v in loads:changed=re.sub(re.escape(v)+r'(?![-a-zA-Z0-9$._])','%capacity.snapshot',changed)
 added='  %capacity.snapshot = load i64, ptr %v0, align 8\n'
 changed=changed.replace('entry:\n','entry:\n'+added,1)
 cand=s[:m.start()]+changed+s[m.end():]
 assert cand[:m.start()]==s[:m.start()] and cand[m.start()+len(changed):]==s[m.end():]
 (D/'control.input.ll').write_text(s);(D/'candidate.input.ll').write_text(cand)
 (D/'snapshot.patch').write_text(''.join(difflib.unified_diff(s.splitlines(True),cand.splitlines(True),fromfile='control.input.ll',tofile='candidate.input.ll')))
 (D/'access-proof.json').write_text(json.dumps({'complete_inventory':audit,'owner_stores':owner_stores,'permitted_owner_offsets':permitted,'calls':calls,'replaced_loads':loads},indent=2)+'\n')
 links=json.loads(pathlib.Path('/private/tmp/whitefoot-mutation-home-mask/link-commands.json').read_text())['timed']
 pins=[A/'mask.optimized.ll',A/'access-classification.json',D/'criterion.txt',pathlib.Path(__file__),D/'control.input.ll',D/'candidate.input.ll']
 pins += [pathlib.Path(x) if x.startswith('/') else R/x for x in links if x.endswith(('.o','.a')) and not x.endswith('entry-forward-wf-timed.o')]
 (D/'pins.json').write_text(json.dumps({str(p):sha(p) for p in pins},indent=2)+'\n')
 print('Prepared exact two-load snapshot; complete42-access/call inventory verified.')
else:
 assert sys.argv[1]=='native' and os.environ.get('WHITEFOOT_CHECK_OWNER')
 for p,h in json.loads((D/'pins.json').read_text()).items():assert sha(pathlib.Path(p))==h,p
 records=[]
 def run(label,args):
  start=time.monotonic();p=subprocess.run(list(map(str,args)),cwd=R,capture_output=True,text=True)
  (D/(label+'.stdout')).write_text(p.stdout);(D/(label+'.stderr')).write_text(p.stderr)
  row=dict(label=label,argv=list(map(str,args)),exit=p.returncode,seconds=time.monotonic()-start);records.append(row)
  (D/'statuses.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True);assert p.returncode==0
 for arm in ['control','candidate']:
  s=(D/(arm+'.input.ll')).read_text();assert s.count('@main(')==1
  ll=D/(arm+'.ll');ll.write_text(s.replace('@main(', '@mutation_unused_main('))
  obj=D/(arm+'.o');run(arm+'-native',['/usr/bin/clang','-O3','-Wno-override-module','-x','ir','-c',ll,'-o',obj])
  cmd=json.loads(pathlib.Path('/private/tmp/whitefoot-mutation-home-mask/link-commands.json').read_text())['timed']
  old=[x for x in cmd if x.endswith('/entry-forward-wf-timed.o')];assert len(old)==1
  cmd[cmd.index(old[0])]=str(obj);cmd[-1]=str(D/(arm+'-timed'));run(arm+'-link',cmd)
  run(arm+'-disassembly',[os.environ['LLVM_OBJDUMP'],'-dr','--no-show-raw-insn',D/(arm+'-timed')])
 (D/'outputs.json').write_text(json.dumps({p.name:sha(p) for p in D.iterdir() if p.suffix in ['.o','.ll'] or p.name.endswith('-timed')},indent=2)+'\n')
