00000001000a4948 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd>:
1000a4948:     	sub	sp, sp, #0x70
1000a494c:     	stp	x28, x27, [sp, #0x10]
1000a4950:     	stp	x26, x25, [sp, #0x20]
1000a4954:     	stp	x24, x23, [sp, #0x30]
1000a4958:     	stp	x22, x21, [sp, #0x40]
1000a495c:     	stp	x20, x19, [sp, #0x50]
1000a4960:     	stp	x29, x30, [sp, #0x60]
1000a4964:     	mov	x9, #0xe5b9             ; =58809
1000a4968:     	movk	x9, #0x1ce4, lsl #16
1000a496c:     	movk	x9, #0x476d, lsl #32
1000a4970:     	movk	x9, #0xbf58, lsl #48
1000a4974:     	mov	x8, #0x11eb             ; =4587
1000a4978:     	movk	x8, #0x1331, lsl #16
1000a497c:     	movk	x8, #0x49bb, lsl #32
1000a4980:     	movk	x8, #0x94d0, lsl #48
1000a4984:     	ldr	x20, [x0, #0x38]
1000a4988:     	str	x1, [sp]
1000a498c:     	cbz	x1, 0x1000a4c34 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2ec>
1000a4990:     	ldp	x12, x11, [x0, #0x40]
1000a4994:     	cbz	x12, 0x1000a4c28 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2e0>
1000a4998:     	mov	x13, #0x0               ; =0
1000a499c:     	ldr	x14, [x0]
1000a49a0:     	ldp	x7, x15, [x0, #0x20]
1000a49a4:     	ldrb	w16, [x0, #0x30]
1000a49a8:     	sub	x17, x14, #0x1
1000a49ac:     	mov	w3, #0x1                ; =1
1000a49b0:     	mov	w4, #0x18               ; =24
1000a49b4:     	ldr	x5, [x0, #0x18]
1000a49b8:     	mov	w6, #0x2                ; =2
1000a49bc:     	mov	w19, #0x83              ; =131
1000a49c0:     	mov	x21, x20
1000a49c4:     	b	0x1000a49e0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x98>
1000a49c8:     	str	x11, [x0, #0x48]
1000a49cc:     	add	x13, x13, #0x1
1000a49d0:     	ldr	x10, [sp]
1000a49d4:     	cmp	x13, x10
1000a49d8:     	mov	x20, x1
1000a49dc:     	b.eq	0x1000a4c38 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2f0>
1000a49e0:     	mov	x22, #0x0               ; =0
1000a49e4:     	add	x11, x11, #0x1
1000a49e8:     	mov	x1, x20
1000a49ec:     	madd	x23, x11, x12, x20
1000a49f0:     	b	0x1000a4a18 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xd0>
1000a49f4:     	strb	w3, [sp, #0xc]
1000a49f8:     	tst	w3, #0x1
1000a49fc:     	cinc	x26, x3, ne
1000a4a00:     	madd	x10, x21, x19, x26
1000a4a04:     	add	x10, x10, x24
1000a4a08:     	madd	x21, x10, x19, x25
1000a4a0c:     	add	x22, x22, #0x1
1000a4a10:     	cmp	x22, x12
1000a4a14:     	b.eq	0x1000a49c8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x80>
1000a4a18:     	orr	x24, x3, x22, lsl #1
1000a4a1c:     	cbz	x2, 0x1000a4adc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x194>
1000a4a20:     	cbz	x5, 0x1000a4b00 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b8>
1000a4a24:     	tbz	w16, #0x0, 0x1000a4a34 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xec>
1000a4a28:     	mov	x20, #0x0               ; =0
1000a4a2c:     	cbnz	x14, 0x1000a4a50 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x108>
1000a4a30:     	b	0x1000a4b00 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b8>
1000a4a34:     	eor	x10, x24, x15
1000a4a38:     	eor	x10, x10, x10, lsr #30
1000a4a3c:     	mul	x10, x10, x9
1000a4a40:     	eor	x10, x10, x10, lsr #27
1000a4a44:     	mul	x10, x10, x8
1000a4a48:     	eor	x20, x10, x10, lsr #31
1000a4a4c:     	cbz	x14, 0x1000a4b00 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b8>
1000a4a50:     	tst	x14, x17
1000a4a54:     	b.eq	0x1000a4a64 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x11c>
1000a4a58:     	udiv	x10, x20, x14
1000a4a5c:     	msub	x25, x10, x14, x20
1000a4a60:     	b	0x1000a4a68 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x120>
1000a4a64:     	and	x25, x20, x17
1000a4a68:     	ldr	x26, [x0, #0x10]
1000a4a6c:     	mov	x27, x14
1000a4a70:     	b	0x1000a4a88 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x140>
1000a4a74:     	add	x10, x25, #0x1
1000a4a78:     	cmp	x10, x14
1000a4a7c:     	csinc	x25, xzr, x25, hs
1000a4a80:     	subs	x27, x27, #0x1
1000a4a84:     	b.eq	0x1000a4b00 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b8>
1000a4a88:     	madd	x28, x25, x4, x26
1000a4a8c:     	ldr	w20, [x28]
1000a4a90:     	cmp	w20, #0x1
1000a4a94:     	b.eq	0x1000a4a74 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x12c>
1000a4a98:     	cmp	w20, #0x2
1000a4a9c:     	b.ne	0x1000a4b00 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b8>
1000a4aa0:     	ldr	x10, [x28, #0x8]
1000a4aa4:     	cmp	x10, x24
1000a4aa8:     	b.ne	0x1000a4a74 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x12c>
1000a4aac:     	ldr	x10, [x28, #0x10]
1000a4ab0:     	str	w3, [x28]
1000a4ab4:     	sub	x5, x5, #0x1
1000a4ab8:     	stp	xzr, xzr, [x28, #0x8]
1000a4abc:     	adds	x7, x7, #0x1
1000a4ac0:     	csinv	x7, x7, xzr, lo
1000a4ac4:     	stp	x5, x7, [x0, #0x18]
1000a4ac8:     	mul	x20, x24, x19
1000a4acc:     	mov	w25, #0x4309            ; =17161
1000a4ad0:     	madd	x20, x21, x25, x20
1000a4ad4:     	add	x10, x20, x10
1000a4ad8:     	add	x21, x10, #0x83
1000a4adc:     	tbz	w16, #0x0, 0x1000a4b08 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1c0>
1000a4ae0:     	mov	x20, #0x0               ; =0
1000a4ae4:     	add	x25, x23, x22
1000a4ae8:     	cbz	x14, 0x1000a4b28 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1e0>
1000a4aec:     	tst	x14, x17
1000a4af0:     	b.eq	0x1000a4b30 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1e8>
1000a4af4:     	udiv	x10, x20, x14
1000a4af8:     	msub	x27, x10, x14, x20
1000a4afc:     	b	0x1000a4b34 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1ec>
1000a4b00:     	mul	x21, x21, x19
1000a4b04:     	tbnz	w16, #0x0, 0x1000a4ae0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x198>
1000a4b08:     	eor	x10, x24, x15
1000a4b0c:     	eor	x10, x10, x10, lsr #30
1000a4b10:     	mul	x10, x10, x9
1000a4b14:     	eor	x10, x10, x10, lsr #27
1000a4b18:     	mul	x10, x10, x8
1000a4b1c:     	eor	x20, x10, x10, lsr #31
1000a4b20:     	add	x25, x23, x22
1000a4b24:     	cbnz	x14, 0x1000a4aec <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1a4>
1000a4b28:     	mov	x26, #0x0               ; =0
1000a4b2c:     	b	0x1000a4ba8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x260>
1000a4b30:     	and	x27, x20, x17
1000a4b34:     	ldr	x28, [x0, #0x10]
1000a4b38:     	mov	x30, x14
1000a4b3c:     	mov	x26, x14
1000a4b40:     	b	0x1000a4b60 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x218>
1000a4b44:     	cmp	x26, x14
1000a4b48:     	csel	x26, x27, x26, eq
1000a4b4c:     	add	x10, x27, #0x1
1000a4b50:     	cmp	x10, x14
1000a4b54:     	csinc	x27, xzr, x27, hs
1000a4b58:     	subs	x30, x30, #0x1
1000a4b5c:     	b.eq	0x1000a4ba8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x260>
1000a4b60:     	madd	x20, x27, x4, x28
1000a4b64:     	ldr	w10, [x20]
1000a4b68:     	cmp	w10, #0x1
1000a4b6c:     	b.eq	0x1000a4b44 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
1000a4b70:     	cmp	w10, #0x2
1000a4b74:     	b.ne	0x1000a4ba0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x258>
1000a4b78:     	ldr	x10, [x20, #0x8]
1000a4b7c:     	cmp	x10, x24
1000a4b80:     	b.ne	0x1000a4b4c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x204>
1000a4b84:     	ldr	x10, [x20, #0x10]
1000a4b88:     	str	w6, [x20]
1000a4b8c:     	str	x25, [x20, #0x10]
1000a4b90:     	strb	wzr, [sp, #0xc]
1000a4b94:     	mov	w26, #0x1               ; =1
1000a4b98:     	mov	x25, x10
1000a4b9c:     	b	0x1000a4a00 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xb8>
1000a4ba0:     	cmp	x26, x14
1000a4ba4:     	csel	x26, x27, x26, eq
1000a4ba8:     	cmp	x26, x14
1000a4bac:     	b.hs	0x1000a49f4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xac>
1000a4bb0:     	cmp	x5, #0x2, lsl #12       ; =0x2000
1000a4bb4:     	b.hs	0x1000a49f4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xac>
1000a4bb8:     	add	x5, x5, #0x1
1000a4bbc:     	str	x5, [x0, #0x18]
1000a4bc0:     	ldr	x10, [x0, #0x10]
1000a4bc4:     	madd	x26, x26, x4, x10
1000a4bc8:     	ldr	w28, [x26]
1000a4bcc:     	cmp	w28, #0x1
1000a4bd0:     	b.ne	0x1000a4bec <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2a4>
1000a4bd4:     	subs	x10, x7, #0x1
1000a4bd8:     	csel	x7, xzr, x10, lo
1000a4bdc:     	str	x7, [x0, #0x20]
1000a4be0:     	str	w6, [x26]
1000a4be4:     	stp	x24, x25, [x26, #0x8]
1000a4be8:     	b	0x1000a4c10 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2c8>
1000a4bec:     	ldp	x20, x27, [x26, #0x8]
1000a4bf0:     	str	w6, [x26]
1000a4bf4:     	stp	x24, x25, [x26, #0x8]
1000a4bf8:     	cbz	w28, 0x1000a4c10 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2c8>
1000a4bfc:     	strb	wzr, [sp, #0xc]
1000a4c00:     	mov	w26, #0x1               ; =1
1000a4c04:     	mov	x25, x27
1000a4c08:     	mov	x24, x20
1000a4c0c:     	b	0x1000a4a00 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xb8>
1000a4c10:     	strb	wzr, [sp, #0xc]
1000a4c14:     	mul	x21, x21, x19
1000a4c18:     	add	x22, x22, #0x1
1000a4c1c:     	cmp	x22, x12
1000a4c20:     	b.ne	0x1000a4a18 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xd0>
1000a4c24:     	b	0x1000a49c8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x80>
1000a4c28:     	ldr	x10, [sp]
1000a4c2c:     	add	x10, x11, x10
1000a4c30:     	str	x10, [x0, #0x48]
1000a4c34:     	mov	x21, x20
1000a4c38:     	eor	x10, x21, x21, lsr #30
1000a4c3c:     	mul	x9, x10, x9
1000a4c40:     	eor	x9, x9, x9, lsr #27
1000a4c44:     	mul	x8, x9, x8
1000a4c48:     	eor	x0, x8, x8, lsr #31
1000a4c4c:     	ldp	x29, x30, [sp, #0x60]
1000a4c50:     	ldp	x20, x19, [sp, #0x50]
1000a4c54:     	ldp	x22, x21, [sp, #0x40]
1000a4c58:     	ldp	x24, x23, [sp, #0x30]
1000a4c5c:     	ldp	x26, x25, [sp, #0x20]
1000a4c60:     	ldp	x28, x27, [sp, #0x10]
1000a4c64:     	add	sp, sp, #0x70
1000a4c68:     	ret
