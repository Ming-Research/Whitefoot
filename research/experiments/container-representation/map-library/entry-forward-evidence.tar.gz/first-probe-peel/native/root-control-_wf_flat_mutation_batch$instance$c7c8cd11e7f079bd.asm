00000001000a3c2c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd>:
1000a3c2c:     	mov	x9, #0xe5b9             ; =58809
1000a3c30:     	movk	x9, #0x1ce4, lsl #16
1000a3c34:     	movk	x9, #0x476d, lsl #32
1000a3c38:     	movk	x9, #0xbf58, lsl #48
1000a3c3c:     	mov	x8, #0x11eb             ; =4587
1000a3c40:     	movk	x8, #0x1331, lsl #16
1000a3c44:     	movk	x8, #0x49bb, lsl #32
1000a3c48:     	movk	x8, #0x94d0, lsl #48
1000a3c4c:     	ldr	x10, [x0, #0x38]
1000a3c50:     	cbz	x1, 0x1000a3f48 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x31c>
1000a3c54:     	ldp	x12, x11, [x0, #0x40]
1000a3c58:     	cbz	x12, 0x1000a3f40 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x314>
1000a3c5c:     	sub	sp, sp, #0x70
1000a3c60:     	stp	x28, x27, [sp, #0x10]
1000a3c64:     	stp	x26, x25, [sp, #0x20]
1000a3c68:     	stp	x24, x23, [sp, #0x30]
1000a3c6c:     	stp	x22, x21, [sp, #0x40]
1000a3c70:     	stp	x20, x19, [sp, #0x50]
1000a3c74:     	stp	x29, x30, [sp, #0x60]
1000a3c78:     	mov	x13, #0x0               ; =0
1000a3c7c:     	ldp	x19, x14, [x0, #0x20]
1000a3c80:     	ldrb	w15, [x0, #0x30]
1000a3c84:     	mov	w16, #0x1               ; =1
1000a3c88:     	mov	w17, #0x18              ; =24
1000a3c8c:     	mov	w3, #0x2                ; =2
1000a3c90:     	mov	w4, #0x83               ; =131
1000a3c94:     	mov	x6, x10
1000a3c98:     	ldr	x7, [x0, #0x18]
1000a3c9c:     	b	0x1000a3cb0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x84>
1000a3ca0:     	str	x11, [x0, #0x48]
1000a3ca4:     	add	x13, x13, #0x1
1000a3ca8:     	cmp	x13, x1
1000a3cac:     	b.eq	0x1000a3f0c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2e0>
1000a3cb0:     	mov	x20, #0x0               ; =0
1000a3cb4:     	add	x11, x11, #0x1
1000a3cb8:     	madd	x21, x11, x12, x10
1000a3cbc:     	b	0x1000a3ce4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xb8>
1000a3cc0:     	strb	w16, [sp, #0xc]
1000a3cc4:     	tst	w16, #0x1
1000a3cc8:     	cinc	x24, x16, ne
1000a3ccc:     	madd	x5, x6, x4, x22
1000a3cd0:     	add	x5, x5, x24
1000a3cd4:     	madd	x6, x5, x4, x23
1000a3cd8:     	add	x20, x20, #0x1
1000a3cdc:     	cmp	x20, x12
1000a3ce0:     	b.eq	0x1000a3ca0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x74>
1000a3ce4:     	orr	x22, x16, x20, lsl #1
1000a3ce8:     	cbz	x2, 0x1000a3db4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x188>
1000a3cec:     	cbz	x7, 0x1000a3de0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b4>
1000a3cf0:     	tbz	w15, #0x0, 0x1000a3d04 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xd8>
1000a3cf4:     	mov	x24, #0x0               ; =0
1000a3cf8:     	ldr	x23, [x0]
1000a3cfc:     	cbnz	x23, 0x1000a3d24 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xf8>
1000a3d00:     	b	0x1000a3de0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b4>
1000a3d04:     	eor	x5, x14, x22
1000a3d08:     	eor	x5, x5, x5, lsr #30
1000a3d0c:     	mul	x5, x5, x9
1000a3d10:     	eor	x5, x5, x5, lsr #27
1000a3d14:     	mul	x5, x5, x8
1000a3d18:     	eor	x24, x5, x5, lsr #31
1000a3d1c:     	ldr	x23, [x0]
1000a3d20:     	cbz	x23, 0x1000a3de0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b4>
1000a3d24:     	sub	x5, x23, #0x1
1000a3d28:     	tst	x23, x5
1000a3d2c:     	b.eq	0x1000a3d3c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x110>
1000a3d30:     	udiv	x5, x24, x23
1000a3d34:     	msub	x24, x5, x23, x24
1000a3d38:     	b	0x1000a3d40 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x114>
1000a3d3c:     	and	x24, x5, x24
1000a3d40:     	ldr	x25, [x0, #0x10]
1000a3d44:     	mov	x26, x23
1000a3d48:     	b	0x1000a3d60 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x134>
1000a3d4c:     	add	x5, x24, #0x1
1000a3d50:     	cmp	x5, x23
1000a3d54:     	csinc	x24, xzr, x24, hs
1000a3d58:     	subs	x26, x26, #0x1
1000a3d5c:     	b.eq	0x1000a3de0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b4>
1000a3d60:     	madd	x27, x24, x17, x25
1000a3d64:     	ldr	w28, [x27]
1000a3d68:     	cmp	w28, #0x1
1000a3d6c:     	b.eq	0x1000a3d4c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x120>
1000a3d70:     	cmp	w28, #0x2
1000a3d74:     	b.ne	0x1000a3de0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b4>
1000a3d78:     	ldr	x5, [x27, #0x8]
1000a3d7c:     	cmp	x5, x22
1000a3d80:     	b.ne	0x1000a3d4c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x120>
1000a3d84:     	ldr	x5, [x27, #0x10]
1000a3d88:     	str	w16, [x27]
1000a3d8c:     	sub	x7, x7, #0x1
1000a3d90:     	stp	xzr, xzr, [x27, #0x8]
1000a3d94:     	adds	x19, x19, #0x1
1000a3d98:     	csinv	x19, x19, xzr, lo
1000a3d9c:     	stp	x7, x19, [x0, #0x18]
1000a3da0:     	mul	x23, x22, x4
1000a3da4:     	mov	w24, #0x4309            ; =17161
1000a3da8:     	madd	x6, x6, x24, x23
1000a3dac:     	add	x5, x6, x5
1000a3db0:     	add	x6, x5, #0x83
1000a3db4:     	tbz	w15, #0x0, 0x1000a3de8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1bc>
1000a3db8:     	mov	x25, #0x0               ; =0
1000a3dbc:     	add	x23, x21, x20
1000a3dc0:     	ldr	x24, [x0]
1000a3dc4:     	cbz	x24, 0x1000a3e0c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1e0>
1000a3dc8:     	sub	x5, x24, #0x1
1000a3dcc:     	tst	x24, x5
1000a3dd0:     	b.eq	0x1000a3e14 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1e8>
1000a3dd4:     	udiv	x5, x25, x24
1000a3dd8:     	msub	x26, x5, x24, x25
1000a3ddc:     	b	0x1000a3e18 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1ec>
1000a3de0:     	mul	x6, x6, x4
1000a3de4:     	tbnz	w15, #0x0, 0x1000a3db8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x18c>
1000a3de8:     	eor	x5, x14, x22
1000a3dec:     	eor	x5, x5, x5, lsr #30
1000a3df0:     	mul	x5, x5, x9
1000a3df4:     	eor	x5, x5, x5, lsr #27
1000a3df8:     	mul	x5, x5, x8
1000a3dfc:     	eor	x25, x5, x5, lsr #31
1000a3e00:     	add	x23, x21, x20
1000a3e04:     	ldr	x24, [x0]
1000a3e08:     	cbnz	x24, 0x1000a3dc8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x19c>
1000a3e0c:     	mov	x25, #0x0               ; =0
1000a3e10:     	b	0x1000a3e8c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x260>
1000a3e14:     	and	x26, x5, x25
1000a3e18:     	ldr	x27, [x0, #0x10]
1000a3e1c:     	mov	x28, x24
1000a3e20:     	mov	x25, x24
1000a3e24:     	b	0x1000a3e44 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x218>
1000a3e28:     	cmp	x25, x24
1000a3e2c:     	csel	x25, x26, x25, eq
1000a3e30:     	add	x5, x26, #0x1
1000a3e34:     	cmp	x5, x24
1000a3e38:     	csinc	x26, xzr, x26, hs
1000a3e3c:     	subs	x28, x28, #0x1
1000a3e40:     	b.eq	0x1000a3e8c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x260>
1000a3e44:     	madd	x30, x26, x17, x27
1000a3e48:     	ldr	w5, [x30]
1000a3e4c:     	cmp	w5, #0x1
1000a3e50:     	b.eq	0x1000a3e28 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
1000a3e54:     	cmp	w5, #0x2
1000a3e58:     	b.ne	0x1000a3e84 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x258>
1000a3e5c:     	ldr	x5, [x30, #0x8]
1000a3e60:     	cmp	x5, x22
1000a3e64:     	b.ne	0x1000a3e30 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x204>
1000a3e68:     	ldr	x5, [x30, #0x10]
1000a3e6c:     	str	w3, [x30]
1000a3e70:     	str	x23, [x30, #0x10]
1000a3e74:     	strb	wzr, [sp, #0xc]
1000a3e78:     	mov	w24, #0x1               ; =1
1000a3e7c:     	mov	x23, x5
1000a3e80:     	b	0x1000a3ccc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xa0>
1000a3e84:     	cmp	x25, x24
1000a3e88:     	csel	x25, x26, x25, eq
1000a3e8c:     	cmp	x25, x24
1000a3e90:     	b.hs	0x1000a3cc0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
1000a3e94:     	cmp	x7, #0x2, lsl #12       ; =0x2000
1000a3e98:     	b.hs	0x1000a3cc0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
1000a3e9c:     	add	x7, x7, #0x1
1000a3ea0:     	str	x7, [x0, #0x18]
1000a3ea4:     	ldr	x5, [x0, #0x10]
1000a3ea8:     	madd	x24, x25, x17, x5
1000a3eac:     	ldr	w27, [x24]
1000a3eb0:     	cmp	w27, #0x1
1000a3eb4:     	b.ne	0x1000a3ed0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2a4>
1000a3eb8:     	subs	x5, x19, #0x1
1000a3ebc:     	csel	x19, xzr, x5, lo
1000a3ec0:     	str	x19, [x0, #0x20]
1000a3ec4:     	str	w3, [x24]
1000a3ec8:     	stp	x22, x23, [x24, #0x8]
1000a3ecc:     	b	0x1000a3ef4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2c8>
1000a3ed0:     	ldp	x25, x26, [x24, #0x8]
1000a3ed4:     	str	w3, [x24]
1000a3ed8:     	stp	x22, x23, [x24, #0x8]
1000a3edc:     	cbz	w27, 0x1000a3ef4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2c8>
1000a3ee0:     	strb	wzr, [sp, #0xc]
1000a3ee4:     	mov	w24, #0x1               ; =1
1000a3ee8:     	mov	x23, x26
1000a3eec:     	mov	x22, x25
1000a3ef0:     	b	0x1000a3ccc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xa0>
1000a3ef4:     	strb	wzr, [sp, #0xc]
1000a3ef8:     	mul	x6, x6, x4
1000a3efc:     	add	x20, x20, #0x1
1000a3f00:     	cmp	x20, x12
1000a3f04:     	b.ne	0x1000a3ce4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xb8>
1000a3f08:     	b	0x1000a3ca0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x74>
1000a3f0c:     	ldp	x29, x30, [sp, #0x60]
1000a3f10:     	ldp	x20, x19, [sp, #0x50]
1000a3f14:     	ldp	x22, x21, [sp, #0x40]
1000a3f18:     	ldp	x24, x23, [sp, #0x30]
1000a3f1c:     	ldp	x26, x25, [sp, #0x20]
1000a3f20:     	ldp	x28, x27, [sp, #0x10]
1000a3f24:     	add	sp, sp, #0x70
1000a3f28:     	eor	x10, x6, x6, lsr #30
1000a3f2c:     	mul	x9, x10, x9
1000a3f30:     	eor	x9, x9, x9, lsr #27
1000a3f34:     	mul	x8, x9, x8
1000a3f38:     	eor	x0, x8, x8, lsr #31
1000a3f3c:     	ret
1000a3f40:     	add	x11, x11, x1
1000a3f44:     	str	x11, [x0, #0x48]
1000a3f48:     	eor	x10, x10, x10, lsr #30
1000a3f4c:     	mul	x9, x10, x9
1000a3f50:     	eor	x9, x9, x9, lsr #27
1000a3f54:     	mul	x8, x9, x8
1000a3f58:     	eor	x0, x8, x8, lsr #31
1000a3f5c:     	ret
