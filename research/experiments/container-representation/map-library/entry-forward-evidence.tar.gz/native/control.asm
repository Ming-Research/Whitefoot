
research/experiments/container-representation/map-library/.build/lookup-api/mutation-screen/candidate.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	x20, x19, [sp, #-0x20]!
       4:      	stp	x29, x30, [sp, #0x10]
       8:      	adrp	x19, 0x0 <ltmp0>
		0000000000000008:  ARM64_RELOC_PAGE21	l_.wf_resource.heap
       c:      	add	x19, x19, #0x0
		000000000000000c:  ARM64_RELOC_PAGEOFF12	l_.wf_resource.heap
      10:      	mov	w20, #0x14              ; =20
      14:      	mov	w0, #0x2                ; =2
      18:      	mov	x1, x19
      1c:      	mov	x2, x20
      20:      	bl	0x20 <ltmp0+0x20>
		0000000000000020:  ARM64_RELOC_BRANCH26	_write
      24:      	tbz	x0, #0x3f, 0x4c <ltmp0+0x4c>
      28:      	bl	0x28 <ltmp0+0x28>
		0000000000000028:  ARM64_RELOC_BRANCH26	___error
      2c:      	ldr	w8, [x0]
      30:      	cmp	w8, #0x4
      34:      	b.ne	0x74 <ltmp0+0x74>
      38:      	mov	w0, #0x2                ; =2
      3c:      	mov	x1, x19
      40:      	mov	x2, x20
      44:      	bl	0x44 <ltmp0+0x44>
		0000000000000044:  ARM64_RELOC_BRANCH26	_write
      48:      	tbnz	x0, #0x3f, 0x28 <ltmp0+0x28>
      4c:      	subs	x20, x20, x0
      50:      	b.eq	0x74 <ltmp0+0x74>
      54:      	cbz	x0, 0x74 <ltmp0+0x74>
      58:      	add	x19, x19, x0
      5c:      	mov	w0, #0x2                ; =2
      60:      	mov	x1, x19
      64:      	mov	x2, x20
      68:      	bl	0x68 <ltmp0+0x68>
		0000000000000068:  ARM64_RELOC_BRANCH26	_write
      6c:      	tbnz	x0, #0x3f, 0x28 <ltmp0+0x28>
      70:      	b	0x4c <ltmp0+0x4c>
      74:      	bl	0x74 <ltmp0+0x74>
		0000000000000074:  ARM64_RELOC_BRANCH26	_abort

0000000000000078 <l_wf_resource_abort>:
      78:      	stp	x29, x30, [sp, #-0x10]!
      7c:      	bl	0x7c <l_wf_resource_abort+0x4>
		000000000000007c:  ARM64_RELOC_BRANCH26	l_wf_resource_record_abort

0000000000000080 <_wf_map_cost_mix>:
      80:      	eor	x8, x0, x0, lsr #30
      84:      	mov	x9, #0xe5b9             ; =58809
      88:      	movk	x9, #0x1ce4, lsl #16
      8c:      	movk	x9, #0x476d, lsl #32
      90:      	movk	x9, #0xbf58, lsl #48
      94:      	mul	x8, x8, x9
      98:      	eor	x8, x8, x8, lsr #27
      9c:      	mov	x9, #0x11eb             ; =4587
      a0:      	movk	x9, #0x1331, lsl #16
      a4:      	movk	x9, #0x49bb, lsl #32
      a8:      	movk	x9, #0x94d0, lsl #48
      ac:      	mul	x8, x8, x9
      b0:      	eor	x0, x8, x8, lsr #31
      b4:      	ret

00000000000000b8 <_wf_map_cost_hash>:
      b8:      	ldrb	w8, [x0, #0x8]
      bc:      	tbz	w8, #0x0, 0xc8 <_wf_map_cost_hash+0x10>
      c0:      	mov	x0, #0x0                ; =0
      c4:      	ret
      c8:      	ldr	x8, [x1]
      cc:      	ldr	x9, [x0]
      d0:      	eor	x8, x9, x8
      d4:      	eor	x8, x8, x8, lsr #30
      d8:      	mov	x9, #0xe5b9             ; =58809
      dc:      	movk	x9, #0x1ce4, lsl #16
      e0:      	movk	x9, #0x476d, lsl #32
      e4:      	movk	x9, #0xbf58, lsl #48
      e8:      	mul	x8, x8, x9
      ec:      	eor	x8, x8, x8, lsr #27
      f0:      	mov	x9, #0x11eb             ; =4587
      f4:      	movk	x9, #0x1331, lsl #16
      f8:      	movk	x9, #0x49bb, lsl #32
      fc:      	movk	x9, #0x94d0, lsl #48
     100:      	mul	x8, x8, x9
     104:      	eor	x0, x8, x8, lsr #31
     108:      	ret

000000000000010c <_wf_map_cost_equal>:
     10c:      	ldr	x8, [x1]
     110:      	ldr	x9, [x2]
     114:      	cmp	x8, x9
     118:      	cset	w0, eq
     11c:      	ret

0000000000000120 <_wf_map_cost_key>:
     120:      	mov	w8, #0x1                ; =1
     124:      	orr	x0, x8, x0, lsl #1
     128:      	ret

000000000000012c <_wf_map_cost_ordered>:
     12c:      	ldr	x8, [x0]
     130:      	mov	w9, #0x83               ; =131
     134:      	madd	x8, x8, x9, x1
     138:      	str	x8, [x0]
     13c:      	mov	w0, #0x0                ; =0
     140:      	ret

0000000000000144 <_wf_map_cost_final>:
     144:      	ldp	x8, x9, [x0, #0x8]
     148:      	add	x8, x8, x1
     14c:      	eor	x10, x1, x1, lsr #30
     150:      	mov	x11, #0xe5b9            ; =58809
     154:      	movk	x11, #0x1ce4, lsl #16
     158:      	movk	x11, #0x476d, lsl #32
     15c:      	movk	x11, #0xbf58, lsl #48
     160:      	mul	x10, x10, x11
     164:      	eor	x10, x10, x10, lsr #27
     168:      	mov	x11, #0x11eb            ; =4587
     16c:      	movk	x11, #0x1331, lsl #16
     170:      	movk	x11, #0x49bb, lsl #32
     174:      	movk	x11, #0x94d0, lsl #48
     178:      	mul	x10, x10, x11
     17c:      	eor	x9, x9, x10, lsr #31
     180:      	eor	x9, x9, x10
     184:      	stp	x8, x9, [x0, #0x8]
     188:      	ldr	x8, [x0, #0x18]
     18c:      	add	x8, x8, #0x1
     190:      	str	x8, [x0, #0x18]
     194:      	mov	w0, #0x0                ; =0
     198:      	ret

000000000000019c <_wf_map_cost_finish>:
     19c:      	ldp	x8, x9, [x0]
     1a0:      	ldp	x10, x11, [x0, #0x10]
     1a4:      	eor	x8, x8, x8, lsr #30
     1a8:      	mov	x12, #0xe5b9            ; =58809
     1ac:      	movk	x12, #0x1ce4, lsl #16
     1b0:      	movk	x12, #0x476d, lsl #32
     1b4:      	movk	x12, #0xbf58, lsl #48
     1b8:      	mul	x8, x8, x12
     1bc:      	eor	x8, x8, x8, lsr #27
     1c0:      	mov	x13, #0x11eb            ; =4587
     1c4:      	movk	x13, #0x1331, lsl #16
     1c8:      	movk	x13, #0x49bb, lsl #32
     1cc:      	movk	x13, #0x94d0, lsl #48
     1d0:      	mul	x8, x8, x13
     1d4:      	eor	x9, x9, x9, lsr #30
     1d8:      	mul	x9, x9, x12
     1dc:      	eor	x9, x9, x9, lsr #27
     1e0:      	mul	x9, x9, x13
     1e4:      	eor	x12, x9, x8
     1e8:      	mov	x13, #0x7c15            ; =31765
     1ec:      	movk	x13, #0x7f4a, lsl #16
     1f0:      	movk	x13, #0x79b9, lsl #32
     1f4:      	movk	x13, #0x9e37, lsl #48
     1f8:      	mul	x11, x11, x13
     1fc:      	eor	x10, x10, x11
     200:      	eor	x10, x10, x12, lsr #31
     204:      	eor	x8, x8, x9
     208:      	eor	x0, x10, x8
     20c:      	ret

0000000000000210 <_wf_map_cost_word_make>:
     210:      	ret

0000000000000214 <_wf_map_cost_word_content>:
     214:      	mov	w8, #0x83               ; =131
     218:      	madd	x0, x0, x8, x1
     21c:      	ret

0000000000000220 <_wf_map_cost_word_observe>:
     220:      	ldr	x0, [x2]
     224:      	ret

0000000000000228 <_wf_map_cost_word_edit>:
     228:      	ldr	x8, [x2]
     22c:      	add	x0, x8, #0x1
     230:      	str	x0, [x2]
     234:      	ret

0000000000000238 <_wf_map_cost_word_consume>:
     238:      	mov	w8, #0x83               ; =131
     23c:      	madd	x8, x1, x8, x2
     240:      	ldp	x9, x10, [x0, #0x8]
     244:      	add	x9, x9, x8
     248:      	eor	x8, x8, x8, lsr #30
     24c:      	mov	x11, #0xe5b9            ; =58809
     250:      	movk	x11, #0x1ce4, lsl #16
     254:      	movk	x11, #0x476d, lsl #32
     258:      	movk	x11, #0xbf58, lsl #48
     25c:      	mul	x8, x8, x11
     260:      	eor	x8, x8, x8, lsr #27
     264:      	mov	x11, #0x11eb            ; =4587
     268:      	movk	x11, #0x1331, lsl #16
     26c:      	movk	x11, #0x49bb, lsl #32
     270:      	movk	x11, #0x94d0, lsl #48
     274:      	mul	x8, x8, x11
     278:      	eor	x10, x10, x8, lsr #31
     27c:      	eor	x8, x10, x8
     280:      	stp	x9, x8, [x0, #0x8]
     284:      	ldr	x8, [x0, #0x18]
     288:      	add	x8, x8, #0x1
     28c:      	str	x8, [x0, #0x18]
     290:      	mov	w0, #0x0                ; =0
     294:      	ret

0000000000000298 <_wf_map_cost_record_make>:
     298:      	dup.2d	v0, x1
     29c:      	adrp	x8, 0x0 <ltmp0>
		000000000000029c:  ARM64_RELOC_PAGE21	lCPI14_0
     2a0:      	ldr	q1, [x8]
		00000000000002a0:  ARM64_RELOC_PAGEOFF12	lCPI14_0
     2a4:      	adrp	x8, 0x0 <ltmp0>
		00000000000002a4:  ARM64_RELOC_PAGE21	lCPI14_1
     2a8:      	ldr	q2, [x8]
		00000000000002a8:  ARM64_RELOC_PAGEOFF12	lCPI14_1
     2ac:      	add.2d	v1, v0, v1
     2b0:      	adrp	x8, 0x0 <ltmp0>
		00000000000002b0:  ARM64_RELOC_PAGE21	lCPI14_2
     2b4:      	ldr	q3, [x8]
		00000000000002b4:  ARM64_RELOC_PAGEOFF12	lCPI14_2
     2b8:      	add.2d	v2, v0, v2
     2bc:      	adrp	x8, 0x0 <ltmp0>
		00000000000002bc:  ARM64_RELOC_PAGE21	lCPI14_3
     2c0:      	ldr	q4, [x8]
		00000000000002c0:  ARM64_RELOC_PAGEOFF12	lCPI14_3
     2c4:      	add.2d	v3, v0, v3
     2c8:      	adrp	x8, 0x0 <ltmp0>
		00000000000002c8:  ARM64_RELOC_PAGE21	lCPI14_4
     2cc:      	ldr	q5, [x8]
		00000000000002cc:  ARM64_RELOC_PAGEOFF12	lCPI14_4
     2d0:      	add.2d	v4, v0, v4
     2d4:      	adrp	x8, 0x0 <ltmp0>
		00000000000002d4:  ARM64_RELOC_PAGE21	lCPI14_5
     2d8:      	ldr	q6, [x8]
		00000000000002d8:  ARM64_RELOC_PAGEOFF12	lCPI14_5
     2dc:      	add.2d	v5, v0, v5
     2e0:      	adrp	x8, 0x0 <ltmp0>
		00000000000002e0:  ARM64_RELOC_PAGE21	lCPI14_6
     2e4:      	ldr	q7, [x8]
		00000000000002e4:  ARM64_RELOC_PAGEOFF12	lCPI14_6
     2e8:      	add.2d	v6, v0, v6
     2ec:      	adrp	x8, 0x0 <ltmp0>
		00000000000002ec:  ARM64_RELOC_PAGE21	lCPI14_7
     2f0:      	ldr	q16, [x8]
		00000000000002f0:  ARM64_RELOC_PAGEOFF12	lCPI14_7
     2f4:      	add.2d	v7, v0, v7
     2f8:      	adrp	x8, 0x0 <ltmp0>
		00000000000002f8:  ARM64_RELOC_PAGE21	lCPI14_8
     2fc:      	ldr	q17, [x8]
		00000000000002fc:  ARM64_RELOC_PAGEOFF12	lCPI14_8
     300:      	add.2d	v16, v0, v16
     304:      	adrp	x8, 0x0 <ltmp0>
		0000000000000304:  ARM64_RELOC_PAGE21	lCPI14_9
     308:      	ldr	q18, [x8]
		0000000000000308:  ARM64_RELOC_PAGEOFF12	lCPI14_9
     30c:      	add.2d	v17, v0, v17
     310:      	adrp	x8, 0x0 <ltmp0>
		0000000000000310:  ARM64_RELOC_PAGE21	lCPI14_10
     314:      	ldr	q19, [x8]
		0000000000000314:  ARM64_RELOC_PAGEOFF12	lCPI14_10
     318:      	add.2d	v18, v0, v18
     31c:      	adrp	x8, 0x0 <ltmp0>
		000000000000031c:  ARM64_RELOC_PAGE21	lCPI14_11
     320:      	ldr	q20, [x8]
		0000000000000320:  ARM64_RELOC_PAGEOFF12	lCPI14_11
     324:      	add.2d	v19, v0, v19
     328:      	adrp	x8, 0x0 <ltmp0>
		0000000000000328:  ARM64_RELOC_PAGE21	lCPI14_12
     32c:      	ldr	q21, [x8]
		000000000000032c:  ARM64_RELOC_PAGEOFF12	lCPI14_12
     330:      	add.2d	v20, v0, v20
     334:      	adrp	x8, 0x0 <ltmp0>
		0000000000000334:  ARM64_RELOC_PAGE21	lCPI14_13
     338:      	ldr	q22, [x8]
		0000000000000338:  ARM64_RELOC_PAGEOFF12	lCPI14_13
     33c:      	add.2d	v21, v0, v21
     340:      	adrp	x8, 0x0 <ltmp0>
		0000000000000340:  ARM64_RELOC_PAGE21	lCPI14_14
     344:      	ldr	q23, [x8]
		0000000000000344:  ARM64_RELOC_PAGEOFF12	lCPI14_14
     348:      	add.2d	v22, v0, v22
     34c:      	add.2d	v0, v0, v23
     350:      	str	x1, [x0]
     354:      	add	x8, x1, #0x1f
     358:      	stur	q1, [x0, #0x8]
     35c:      	stur	q2, [x0, #0x18]
     360:      	stur	q3, [x0, #0x28]
     364:      	stur	q4, [x0, #0x38]
     368:      	stur	q5, [x0, #0x48]
     36c:      	stur	q6, [x0, #0x58]
     370:      	stur	q7, [x0, #0x68]
     374:      	stur	q16, [x0, #0x78]
     378:      	stur	q17, [x0, #0x88]
     37c:      	stur	q18, [x0, #0x98]
     380:      	stur	q19, [x0, #0xa8]
     384:      	stur	q20, [x0, #0xb8]
     388:      	stur	q21, [x0, #0xc8]
     38c:      	stur	q22, [x0, #0xd8]
     390:      	stur	q0, [x0, #0xe8]
     394:      	str	x8, [x0, #0xf8]
     398:      	ret

000000000000039c <_wf_map_cost_record_content>:
     39c:      	ldp	x9, x10, [x1]
     3a0:      	mov	w8, #0x83               ; =131
     3a4:      	madd	x9, x0, x8, x9
     3a8:      	madd	x9, x9, x8, x10
     3ac:      	ldp	x10, x11, [x1, #0x10]
     3b0:      	madd	x9, x9, x8, x10
     3b4:      	madd	x9, x9, x8, x11
     3b8:      	ldp	x10, x11, [x1, #0x20]
     3bc:      	madd	x9, x9, x8, x10
     3c0:      	madd	x9, x9, x8, x11
     3c4:      	ldp	x10, x11, [x1, #0x30]
     3c8:      	madd	x9, x9, x8, x10
     3cc:      	madd	x9, x9, x8, x11
     3d0:      	ldp	x10, x11, [x1, #0x40]
     3d4:      	madd	x9, x9, x8, x10
     3d8:      	madd	x9, x9, x8, x11
     3dc:      	ldp	x10, x11, [x1, #0x50]
     3e0:      	madd	x9, x9, x8, x10
     3e4:      	madd	x9, x9, x8, x11
     3e8:      	ldp	x10, x11, [x1, #0x60]
     3ec:      	madd	x9, x9, x8, x10
     3f0:      	madd	x9, x9, x8, x11
     3f4:      	ldp	x10, x11, [x1, #0x70]
     3f8:      	madd	x9, x9, x8, x10
     3fc:      	madd	x9, x9, x8, x11
     400:      	ldp	x10, x11, [x1, #0x80]
     404:      	madd	x9, x9, x8, x10
     408:      	madd	x9, x9, x8, x11
     40c:      	ldp	x10, x11, [x1, #0x90]
     410:      	madd	x9, x9, x8, x10
     414:      	madd	x9, x9, x8, x11
     418:      	ldp	x10, x11, [x1, #0xa0]
     41c:      	madd	x9, x9, x8, x10
     420:      	madd	x9, x9, x8, x11
     424:      	ldp	x10, x11, [x1, #0xb0]
     428:      	madd	x9, x9, x8, x10
     42c:      	madd	x9, x9, x8, x11
     430:      	ldp	x10, x11, [x1, #0xc0]
     434:      	madd	x9, x9, x8, x10
     438:      	madd	x9, x9, x8, x11
     43c:      	ldp	x10, x11, [x1, #0xd0]
     440:      	madd	x9, x9, x8, x10
     444:      	madd	x9, x9, x8, x11
     448:      	ldp	x10, x11, [x1, #0xe0]
     44c:      	madd	x9, x9, x8, x10
     450:      	madd	x9, x9, x8, x11
     454:      	ldp	x10, x11, [x1, #0xf0]
     458:      	madd	x9, x9, x8, x10
     45c:      	madd	x0, x9, x8, x11
     460:      	ret

0000000000000464 <_wf_map_cost_record_observe>:
     464:      	ldr	x0, [x2]
     468:      	ret

000000000000046c <_wf_map_cost_record_edit>:
     46c:      	ldr	x8, [x2]
     470:      	add	x0, x8, #0x1
     474:      	str	x0, [x2]
     478:      	ret

000000000000047c <_wf_map_cost_record_consume>:
     47c:      	ldp	x9, x10, [x2]
     480:      	mov	w8, #0x83               ; =131
     484:      	madd	x9, x1, x8, x9
     488:      	madd	x9, x9, x8, x10
     48c:      	ldp	x10, x11, [x2, #0x10]
     490:      	madd	x9, x9, x8, x10
     494:      	madd	x9, x9, x8, x11
     498:      	ldp	x10, x11, [x2, #0x20]
     49c:      	madd	x9, x9, x8, x10
     4a0:      	madd	x9, x9, x8, x11
     4a4:      	ldp	x10, x11, [x2, #0x30]
     4a8:      	madd	x9, x9, x8, x10
     4ac:      	madd	x9, x9, x8, x11
     4b0:      	ldp	x10, x11, [x2, #0x40]
     4b4:      	madd	x9, x9, x8, x10
     4b8:      	madd	x9, x9, x8, x11
     4bc:      	ldp	x10, x11, [x2, #0x50]
     4c0:      	madd	x9, x9, x8, x10
     4c4:      	madd	x9, x9, x8, x11
     4c8:      	ldp	x10, x11, [x2, #0x60]
     4cc:      	madd	x9, x9, x8, x10
     4d0:      	madd	x9, x9, x8, x11
     4d4:      	ldp	x10, x11, [x2, #0x70]
     4d8:      	madd	x9, x9, x8, x10
     4dc:      	madd	x9, x9, x8, x11
     4e0:      	ldp	x10, x11, [x2, #0x80]
     4e4:      	madd	x9, x9, x8, x10
     4e8:      	madd	x9, x9, x8, x11
     4ec:      	ldp	x10, x11, [x2, #0x90]
     4f0:      	madd	x9, x9, x8, x10
     4f4:      	madd	x9, x9, x8, x11
     4f8:      	ldp	x10, x11, [x2, #0xa0]
     4fc:      	madd	x9, x9, x8, x10
     500:      	madd	x9, x9, x8, x11
     504:      	ldp	x10, x11, [x2, #0xb0]
     508:      	madd	x9, x9, x8, x10
     50c:      	madd	x9, x9, x8, x11
     510:      	ldp	x10, x11, [x2, #0xc0]
     514:      	madd	x9, x9, x8, x10
     518:      	madd	x9, x9, x8, x11
     51c:      	ldp	x10, x11, [x2, #0xd0]
     520:      	madd	x9, x9, x8, x10
     524:      	madd	x9, x9, x8, x11
     528:      	ldp	x10, x11, [x2, #0xe0]
     52c:      	madd	x9, x9, x8, x10
     530:      	madd	x9, x9, x8, x11
     534:      	ldp	x10, x11, [x2, #0xf0]
     538:      	madd	x9, x9, x8, x10
     53c:      	madd	x8, x9, x8, x11
     540:      	ldp	x9, x10, [x0, #0x8]
     544:      	add	x9, x8, x9
     548:      	eor	x8, x8, x8, lsr #30
     54c:      	mov	x11, #0xe5b9            ; =58809
     550:      	movk	x11, #0x1ce4, lsl #16
     554:      	movk	x11, #0x476d, lsl #32
     558:      	movk	x11, #0xbf58, lsl #48
     55c:      	mul	x8, x8, x11
     560:      	eor	x8, x8, x8, lsr #27
     564:      	mov	x11, #0x11eb            ; =4587
     568:      	movk	x11, #0x1331, lsl #16
     56c:      	movk	x11, #0x49bb, lsl #32
     570:      	movk	x11, #0x94d0, lsl #48
     574:      	mul	x8, x8, x11
     578:      	eor	x10, x10, x8, lsr #31
     57c:      	eor	x8, x10, x8
     580:      	stp	x9, x8, [x0, #0x8]
     584:      	ldr	x8, [x0, #0x18]
     588:      	add	x8, x8, #0x1
     58c:      	str	x8, [x0, #0x18]
     590:      	mov	w0, #0x0                ; =0
     594:      	ret

0000000000000598 <_wf_map_cost_lookup_result>:
     598:      	ldr	w8, [x0]
     59c:      	cbz	w8, 0x5b8 <_wf_map_cost_lookup_result+0x20>
     5a0:      	ldr	x8, [x1]
     5a4:      	mov	w9, #0x83               ; =131
     5a8:      	mul	x8, x8, x9
     5ac:      	str	x8, [x1]
     5b0:      	mov	w0, #0x0                ; =0
     5b4:      	ret
     5b8:      	ldr	x8, [x0, #0x8]
     5bc:      	ldr	x9, [x1]
     5c0:      	mov	w10, #0x4309            ; =17161
     5c4:      	madd	x8, x9, x10, x8
     5c8:      	add	x8, x8, #0x83
     5cc:      	str	x8, [x1]
     5d0:      	mov	w0, #0x0                ; =0
     5d4:      	ret

00000000000005d8 <_wf_map_cost_rebuild_result>:
     5d8:      	ldr	w8, [x0]
     5dc:      	cmp	w8, #0x0
     5e0:      	ldr	x8, [x1]
     5e4:      	mov	w9, #0x83               ; =131
     5e8:      	mul	x8, x8, x9
     5ec:      	cinc	x8, x8, eq
     5f0:      	str	x8, [x1]
     5f4:      	mov	w0, #0x0                ; =0
     5f8:      	ret

00000000000005fc <_wf_map_cost_library_word_trace>:
     5fc:      	cmp	x4, #0x8
     600:      	b.ne	0x610 <_wf_map_cost_library_word_trace+0x14>
     604:      	mov	x0, x3
     608:      	mov	x1, x5
     60c:      	b	0x60c <_wf_map_cost_library_word_trace+0x10>
		000000000000060c:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd
     610:      	b	0x610 <_wf_map_cost_library_word_trace+0x14>
		0000000000000610:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd

0000000000000614 <_wf_map_cost_library_record_trace>:
     614:      	cmp	x4, #0x8
     618:      	b.ne	0x628 <_wf_map_cost_library_record_trace+0x14>
     61c:      	mov	x0, x3
     620:      	mov	x1, x5
     624:      	b	0x624 <_wf_map_cost_library_record_trace+0x10>
		0000000000000624:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_policy$instance$4250cb78d3f44027
     628:      	b	0x628 <_wf_map_cost_library_record_trace+0x14>
		0000000000000628:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_trace$instance$4250cb78d3f44027

000000000000062c <_wf_map_cost_library_word_geometry>:
     62c:      	b	0x62c <_wf_map_cost_library_word_geometry>
		000000000000062c:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd

0000000000000630 <_wf_map_cost_library_record_geometry>:
     630:      	b	0x630 <_wf_map_cost_library_record_geometry>
		0000000000000630:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_geometry$instance$4250cb78d3f44027

0000000000000634 <_wf_map_cost_lookup_word_prepare>:
     634:      	b	0x634 <_wf_map_cost_lookup_word_prepare>
		0000000000000634:  ARM64_RELOC_BRANCH26	_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd

0000000000000638 <_wf_map_cost_lookup_record_prepare>:
     638:      	b	0x638 <_wf_map_cost_lookup_record_prepare>
		0000000000000638:  ARM64_RELOC_BRANCH26	_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027

000000000000063c <_wf_map_cost_lookup_word_query>:
     63c:      	b	0x63c <_wf_map_cost_lookup_word_query>
		000000000000063c:  ARM64_RELOC_BRANCH26	_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd

0000000000000640 <_wf_map_cost_lookup_record_query>:
     640:      	b	0x640 <_wf_map_cost_lookup_record_query>
		0000000000000640:  ARM64_RELOC_BRANCH26	_wf_map_cost_lookup_query$instance$4250cb78d3f44027

0000000000000644 <_wf_map_cost_lookup_word_geometry>:
     644:      	ldr	x8, [x0]
     648:      	ldr	x9, [x0, #0x18]
     64c:      	add	x0, x9, x8, lsl #32
     650:      	ret

0000000000000654 <_wf_map_cost_lookup_record_geometry>:
     654:      	ldr	x8, [x0]
     658:      	ldr	x9, [x0, #0x18]
     65c:      	add	x0, x9, x8, lsl #32
     660:      	ret

0000000000000664 <_wf_map_cost_lookup_word_finish>:
     664:      	stp	x24, x23, [sp, #-0x40]!
     668:      	stp	x22, x21, [sp, #0x10]
     66c:      	stp	x20, x19, [sp, #0x20]
     670:      	stp	x29, x30, [sp, #0x30]
     674:      	mov	x8, x0
     678:      	mov	x20, #0xe5b9            ; =58809
     67c:      	movk	x20, #0x1ce4, lsl #16
     680:      	movk	x20, #0x476d, lsl #32
     684:      	movk	x20, #0xbf58, lsl #48
     688:      	mov	x19, #0x11eb            ; =4587
     68c:      	movk	x19, #0x1331, lsl #16
     690:      	movk	x19, #0x49bb, lsl #32
     694:      	movk	x19, #0x94d0, lsl #48
     698:      	ldp	x12, x9, [x0]
     69c:      	ldr	x0, [x0, #0x10]
     6a0:      	cbz	x12, 0x780 <_wf_map_cost_lookup_word_finish+0x11c>
     6a4:      	and	x10, x12, #0x3
     6a8:      	cmp	x12, #0x4
     6ac:      	b.hs	0x798 <_wf_map_cost_lookup_word_finish+0x134>
     6b0:      	mov	x11, #0x0               ; =0
     6b4:      	mov	x21, #0x0               ; =0
     6b8:      	mov	x22, #0x0               ; =0
     6bc:      	cbz	x10, 0x718 <_wf_map_cost_lookup_word_finish+0xb4>
     6c0:      	mov	w13, #0x18              ; =24
     6c4:      	madd	x12, x12, x13, x0
     6c8:      	sub	x12, x12, #0x8
     6cc:      	mov	w13, #0x83              ; =131
     6d0:      	b	0x6e0 <_wf_map_cost_lookup_word_finish+0x7c>
     6d4:      	sub	x12, x12, #0x18
     6d8:      	subs	x10, x10, #0x1
     6dc:      	b.eq	0x718 <_wf_map_cost_lookup_word_finish+0xb4>
     6e0:      	ldur	w14, [x12, #-0x10]
     6e4:      	cmp	w14, #0x2
     6e8:      	b.ne	0x6d4 <_wf_map_cost_lookup_word_finish+0x70>
     6ec:      	ldp	x15, x14, [x12, #-0x8]
     6f0:      	madd	x14, x15, x13, x14
     6f4:      	add	x22, x14, x22
     6f8:      	eor	x14, x14, x14, lsr #30
     6fc:      	mul	x14, x14, x20
     700:      	eor	x14, x14, x14, lsr #27
     704:      	mul	x14, x14, x19
     708:      	eor	x15, x21, x14, lsr #31
     70c:      	eor	x21, x15, x14
     710:      	add	x11, x11, #0x1
     714:      	b	0x6d4 <_wf_map_cost_lookup_word_finish+0x70>
     718:      	mov	x10, #0x7c15            ; =31765
     71c:      	movk	x10, #0x7f4a, lsl #16
     720:      	movk	x10, #0x79b9, lsl #32
     724:      	movk	x10, #0x9e37, lsl #48
     728:      	mul	x23, x11, x10
     72c:      	ldr	x24, [x8, #0x38]
     730:      	cbz	x9, 0x738 <_wf_map_cost_lookup_word_finish+0xd4>
     734:      	bl	0x734 <_wf_map_cost_lookup_word_finish+0xd0>
		0000000000000734:  ARM64_RELOC_BRANCH26	_free
     738:      	eor	x8, x24, x24, lsr #30
     73c:      	mul	x8, x8, x20
     740:      	eor	x8, x8, x8, lsr #27
     744:      	mul	x8, x8, x19
     748:      	eor	x9, x22, x22, lsr #30
     74c:      	mul	x9, x9, x20
     750:      	eor	x9, x9, x9, lsr #27
     754:      	mul	x9, x9, x19
     758:      	eor	x10, x9, x8
     75c:      	eor	x11, x23, x21
     760:      	eor	x10, x11, x10, lsr #31
     764:      	eor	x8, x8, x9
     768:      	eor	x0, x10, x8
     76c:      	ldp	x29, x30, [sp, #0x30]
     770:      	ldp	x20, x19, [sp, #0x20]
     774:      	ldp	x22, x21, [sp, #0x10]
     778:      	ldp	x24, x23, [sp], #0x40
     77c:      	ret
     780:      	mov	x23, #0x0               ; =0
     784:      	mov	x21, #0x0               ; =0
     788:      	mov	x22, #0x0               ; =0
     78c:      	ldr	x24, [x8, #0x38]
     790:      	cbnz	x9, 0x734 <_wf_map_cost_lookup_word_finish+0xd0>
     794:      	b	0x738 <_wf_map_cost_lookup_word_finish+0xd4>
     798:      	mov	x11, #0x0               ; =0
     79c:      	mov	x21, #0x0               ; =0
     7a0:      	mov	x22, #0x0               ; =0
     7a4:      	and	x13, x12, #0xfffffffffffffffc
     7a8:      	mov	w14, #0x18              ; =24
     7ac:      	madd	x14, x12, x14, x0
     7b0:      	sub	x14, x14, #0x30
     7b4:      	mov	w15, #0x83              ; =131
     7b8:      	b	0x7cc <_wf_map_cost_lookup_word_finish+0x168>
     7bc:      	sub	x14, x14, #0x60
     7c0:      	sub	x12, x12, #0x4
     7c4:      	sub	x13, x13, #0x4
     7c8:      	cbz	x13, 0x6bc <_wf_map_cost_lookup_word_finish+0x58>
     7cc:      	ldr	w16, [x14, #0x18]
     7d0:      	cmp	w16, #0x2
     7d4:      	b.eq	0x800 <_wf_map_cost_lookup_word_finish+0x19c>
     7d8:      	ldr	w16, [x14]
     7dc:      	cmp	w16, #0x2
     7e0:      	b.eq	0x834 <_wf_map_cost_lookup_word_finish+0x1d0>
     7e4:      	ldur	w16, [x14, #-0x18]
     7e8:      	cmp	w16, #0x2
     7ec:      	b.eq	0x868 <_wf_map_cost_lookup_word_finish+0x204>
     7f0:      	ldur	w16, [x14, #-0x30]
     7f4:      	cmp	w16, #0x2
     7f8:      	b.ne	0x7bc <_wf_map_cost_lookup_word_finish+0x158>
     7fc:      	b	0x89c <_wf_map_cost_lookup_word_finish+0x238>
     800:      	ldp	x17, x16, [x14, #0x20]
     804:      	madd	x16, x17, x15, x16
     808:      	add	x22, x16, x22
     80c:      	eor	x16, x16, x16, lsr #30
     810:      	mul	x16, x16, x20
     814:      	eor	x16, x16, x16, lsr #27
     818:      	mul	x16, x16, x19
     81c:      	eor	x17, x21, x16, lsr #31
     820:      	eor	x21, x17, x16
     824:      	add	x11, x11, #0x1
     828:      	ldr	w16, [x14]
     82c:      	cmp	w16, #0x2
     830:      	b.ne	0x7e4 <_wf_map_cost_lookup_word_finish+0x180>
     834:      	ldp	x17, x16, [x14, #0x8]
     838:      	madd	x16, x17, x15, x16
     83c:      	add	x22, x16, x22
     840:      	eor	x16, x16, x16, lsr #30
     844:      	mul	x16, x16, x20
     848:      	eor	x16, x16, x16, lsr #27
     84c:      	mul	x16, x16, x19
     850:      	eor	x17, x21, x16, lsr #31
     854:      	eor	x21, x17, x16
     858:      	add	x11, x11, #0x1
     85c:      	ldur	w16, [x14, #-0x18]
     860:      	cmp	w16, #0x2
     864:      	b.ne	0x7f0 <_wf_map_cost_lookup_word_finish+0x18c>
     868:      	ldp	x17, x16, [x14, #-0x10]
     86c:      	madd	x16, x17, x15, x16
     870:      	add	x22, x16, x22
     874:      	eor	x16, x16, x16, lsr #30
     878:      	mul	x16, x16, x20
     87c:      	eor	x16, x16, x16, lsr #27
     880:      	mul	x16, x16, x19
     884:      	eor	x17, x21, x16, lsr #31
     888:      	eor	x21, x17, x16
     88c:      	add	x11, x11, #0x1
     890:      	ldur	w16, [x14, #-0x30]
     894:      	cmp	w16, #0x2
     898:      	b.ne	0x7bc <_wf_map_cost_lookup_word_finish+0x158>
     89c:      	ldp	x17, x16, [x14, #-0x28]
     8a0:      	madd	x16, x17, x15, x16
     8a4:      	add	x22, x16, x22
     8a8:      	eor	x16, x16, x16, lsr #30
     8ac:      	mul	x16, x16, x20
     8b0:      	eor	x16, x16, x16, lsr #27
     8b4:      	mul	x16, x16, x19
     8b8:      	eor	x17, x21, x16, lsr #31
     8bc:      	eor	x21, x17, x16
     8c0:      	add	x11, x11, #0x1
     8c4:      	b	0x7bc <_wf_map_cost_lookup_word_finish+0x158>

00000000000008c8 <_wf_map_cost_lookup_record_finish>:
     8c8:      	sub	sp, sp, #0x60
     8cc:      	stp	x29, x30, [sp, #0x50]
     8d0:      	ldr	x8, [x0, #0x38]
     8d4:      	ldp	q0, q1, [x0]
     8d8:      	stp	q0, q1, [sp, #0x20]
     8dc:      	ldr	x9, [x0, #0x20]
     8e0:      	str	x9, [sp, #0x40]
     8e4:      	stp	x8, xzr, [sp]
     8e8:      	stp	xzr, xzr, [sp, #0x10]
     8ec:      	add	x0, sp, #0x20
     8f0:      	mov	x1, sp
     8f4:      	bl	0x8f4 <_wf_map_cost_lookup_record_finish+0x2c>
		00000000000008f4:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71
     8f8:      	ldp	x8, x9, [sp]
     8fc:      	ldp	x10, x11, [sp, #0x10]
     900:      	eor	x8, x8, x8, lsr #30
     904:      	mov	x12, #0xe5b9            ; =58809
     908:      	movk	x12, #0x1ce4, lsl #16
     90c:      	movk	x12, #0x476d, lsl #32
     910:      	movk	x12, #0xbf58, lsl #48
     914:      	mul	x8, x8, x12
     918:      	eor	x8, x8, x8, lsr #27
     91c:      	mov	x13, #0x11eb            ; =4587
     920:      	movk	x13, #0x1331, lsl #16
     924:      	movk	x13, #0x49bb, lsl #32
     928:      	movk	x13, #0x94d0, lsl #48
     92c:      	mul	x8, x8, x13
     930:      	eor	x9, x9, x9, lsr #30
     934:      	mul	x9, x9, x12
     938:      	eor	x9, x9, x9, lsr #27
     93c:      	mul	x9, x9, x13
     940:      	eor	x12, x9, x8
     944:      	mov	x13, #0x7c15            ; =31765
     948:      	movk	x13, #0x7f4a, lsl #16
     94c:      	movk	x13, #0x79b9, lsl #32
     950:      	movk	x13, #0x9e37, lsl #48
     954:      	mul	x11, x11, x13
     958:      	eor	x10, x10, x11
     95c:      	eor	x10, x10, x12, lsr #31
     960:      	eor	x8, x8, x9
     964:      	eor	x0, x10, x8
     968:      	ldp	x29, x30, [sp, #0x50]
     96c:      	add	sp, sp, #0x60
     970:      	ret

0000000000000974 <_wf_main>:
     974:      	stp	x20, x19, [sp, #-0x20]!
     978:      	stp	x29, x30, [sp, #0x10]
     97c:      	mov	x19, x0
     980:      	mov	w0, #0x3                ; =3
     984:      	mov	w1, #0x2                ; =2
     988:      	mov	w2, #0x2                ; =2
     98c:      	mov	w3, #0x11               ; =17
     990:      	mov	x5, #0x0                ; =0
     994:      	mov	w4, #0x7                ; =7
     998:      	bl	0x998 <_wf_main+0x24>
		0000000000000998:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd
     99c:      	mov	w0, #0x3                ; =3
     9a0:      	mov	w1, #0x2                ; =2
     9a4:      	mov	w2, #0x2                ; =2
     9a8:      	mov	w3, #0x11               ; =17
     9ac:      	mov	w4, #0x3                ; =3
     9b0:      	mov	w5, #0x1                ; =1
     9b4:      	bl	0x9b4 <_wf_main+0x40>
		00000000000009b4:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_trace$instance$4250cb78d3f44027
     9b8:      	mov	x0, x19
     9bc:      	mov	w1, #0x0                ; =0
     9c0:      	ldp	x29, x30, [sp, #0x10]
     9c4:      	ldp	x20, x19, [sp], #0x20
     9c8:      	b	0x9c8 <_wf_main+0x54>
		00000000000009c8:  ARM64_RELOC_BRANCH26	_wf_std.process.exit_status

00000000000009cc <_wf_chain_heads_new>:
     9cc:      	stp	x22, x21, [sp, #-0x30]!
     9d0:      	stp	x20, x19, [sp, #0x10]
     9d4:      	stp	x29, x30, [sp, #0x20]
     9d8:      	mov	x19, x0
     9dc:      	cbz	x0, 0xa04 <_wf_chain_heads_new+0x38>
     9e0:      	lsl	x21, x19, #3
     9e4:      	mov	x0, x21
     9e8:      	bl	0x9e8 <_wf_chain_heads_new+0x1c>
		00000000000009e8:  ARM64_RELOC_BRANCH26	_malloc
     9ec:      	cbz	x0, 0xa28 <_wf_chain_heads_new+0x5c>
     9f0:      	mov	x20, x0
     9f4:      	mov	w1, #0xff               ; =255
     9f8:      	mov	x2, x21
     9fc:      	bl	0x9fc <_wf_chain_heads_new+0x30>
		00000000000009fc:  ARM64_RELOC_BRANCH26	_memset
     a00:      	b	0xa0c <_wf_chain_heads_new+0x40>
     a04:      	adrp	x20, 0x0 <ltmp0>
		0000000000000a04:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
     a08:      	add	x20, x20, #0x0
		0000000000000a08:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
     a0c:      	mov	x0, x19
     a10:      	mov	x1, x19
     a14:      	mov	x2, x20
     a18:      	ldp	x29, x30, [sp, #0x20]
     a1c:      	ldp	x20, x19, [sp, #0x10]
     a20:      	ldp	x22, x21, [sp], #0x30
     a24:      	ret
     a28:      	bl	0xa28 <_wf_chain_heads_new+0x5c>
		0000000000000a28:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

0000000000000a2c <_wf_chain_lookup_word_prepare>:
     a2c:      	b	0xa2c <_wf_chain_lookup_word_prepare>
		0000000000000a2c:  ARM64_RELOC_BRANCH26	_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd

0000000000000a30 <_wf_chain_lookup_word_query>:
     a30:      	b	0xa30 <_wf_chain_lookup_word_query>
		0000000000000a30:  ARM64_RELOC_BRANCH26	_wf_chain_lookup_query$instance$c7c8cd11e7f079bd

0000000000000a34 <_wf_chain_lookup_word_finish>:
     a34:      	sub	sp, sp, #0x60
     a38:      	stp	x29, x30, [sp, #0x50]
     a3c:      	ldp	q0, q1, [x0, #0x20]
     a40:      	stp	q0, q1, [sp, #0x20]
     a44:      	ldr	x8, [x0, #0x40]
     a48:      	str	x8, [sp, #0x40]
     a4c:      	ldp	q1, q0, [x0]
     a50:      	stp	q1, q0, [sp]
     a54:      	mov	x0, sp
     a58:      	bl	0xa58 <_wf_chain_lookup_word_finish+0x24>
		0000000000000a58:  ARM64_RELOC_BRANCH26	_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd
     a5c:      	ldp	x29, x30, [sp, #0x50]
     a60:      	add	sp, sp, #0x60
     a64:      	ret

0000000000000a68 <_wf_chain_lookup_word_geometry>:
     a68:      	ldr	x8, [x0]
     a6c:      	ldr	x9, [x0, #0x18]
     a70:      	add	x0, x9, x8, lsl #32
     a74:      	ret

0000000000000a78 <_wf_chain_lookup_record_prepare>:
     a78:      	b	0xa78 <_wf_chain_lookup_record_prepare>
		0000000000000a78:  ARM64_RELOC_BRANCH26	_wf_chain_lookup_prepare$instance$4250cb78d3f44027

0000000000000a7c <_wf_chain_lookup_record_query>:
     a7c:      	b	0xa7c <_wf_chain_lookup_record_query>
		0000000000000a7c:  ARM64_RELOC_BRANCH26	_wf_chain_lookup_query$instance$4250cb78d3f44027

0000000000000a80 <_wf_chain_lookup_record_finish>:
     a80:      	sub	sp, sp, #0x60
     a84:      	stp	x29, x30, [sp, #0x50]
     a88:      	ldp	q0, q1, [x0, #0x20]
     a8c:      	stp	q0, q1, [sp, #0x20]
     a90:      	ldr	x8, [x0, #0x40]
     a94:      	str	x8, [sp, #0x40]
     a98:      	ldp	q1, q0, [x0]
     a9c:      	stp	q1, q0, [sp]
     aa0:      	mov	x0, sp
     aa4:      	bl	0xaa4 <_wf_chain_lookup_record_finish+0x24>
		0000000000000aa4:  ARM64_RELOC_BRANCH26	_wf_chain_lookup_finish$instance$4250cb78d3f44027
     aa8:      	ldp	x29, x30, [sp, #0x50]
     aac:      	add	sp, sp, #0x60
     ab0:      	ret

0000000000000ab4 <_wf_chain_lookup_record_geometry>:
     ab4:      	ldr	x8, [x0]
     ab8:      	ldr	x9, [x0, #0x18]
     abc:      	add	x0, x9, x8, lsl #32
     ac0:      	ret

0000000000000ac4 <_wf_flat_mutation_word_prepare>:
     ac4:      	b	0xac4 <_wf_flat_mutation_word_prepare>
		0000000000000ac4:  ARM64_RELOC_BRANCH26	_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd

0000000000000ac8 <_wf_flat_mutation_word_batch>:
     ac8:      	b	0xac8 <_wf_flat_mutation_word_batch>
		0000000000000ac8:  ARM64_RELOC_BRANCH26	_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd

0000000000000acc <_wf_flat_mutation_word_geometry>:
     acc:      	ldr	x8, [x0]
     ad0:      	ldr	x9, [x0, #0x18]
     ad4:      	add	x0, x9, x8, lsl #32
     ad8:      	ret

0000000000000adc <_wf_flat_mutation_word_verify>:
     adc:      	b	0xadc <_wf_flat_mutation_word_verify>
		0000000000000adc:  ARM64_RELOC_BRANCH26	_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd

0000000000000ae0 <_wf_flat_mutation_word_finish>:
     ae0:      	stp	x24, x23, [sp, #-0x40]!
     ae4:      	stp	x22, x21, [sp, #0x10]
     ae8:      	stp	x20, x19, [sp, #0x20]
     aec:      	stp	x29, x30, [sp, #0x30]
     af0:      	mov	x8, x0
     af4:      	mov	x20, #0xe5b9            ; =58809
     af8:      	movk	x20, #0x1ce4, lsl #16
     afc:      	movk	x20, #0x476d, lsl #32
     b00:      	movk	x20, #0xbf58, lsl #48
     b04:      	mov	x19, #0x11eb            ; =4587
     b08:      	movk	x19, #0x1331, lsl #16
     b0c:      	movk	x19, #0x49bb, lsl #32
     b10:      	movk	x19, #0x94d0, lsl #48
     b14:      	ldp	x12, x9, [x0]
     b18:      	ldr	x0, [x0, #0x10]
     b1c:      	cbz	x12, 0xbfc <_wf_flat_mutation_word_finish+0x11c>
     b20:      	and	x10, x12, #0x3
     b24:      	cmp	x12, #0x4
     b28:      	b.hs	0xc14 <_wf_flat_mutation_word_finish+0x134>
     b2c:      	mov	x11, #0x0               ; =0
     b30:      	mov	x21, #0x0               ; =0
     b34:      	mov	x22, #0x0               ; =0
     b38:      	cbz	x10, 0xb94 <_wf_flat_mutation_word_finish+0xb4>
     b3c:      	mov	w13, #0x18              ; =24
     b40:      	madd	x12, x12, x13, x0
     b44:      	sub	x12, x12, #0x8
     b48:      	mov	w13, #0x83              ; =131
     b4c:      	b	0xb5c <_wf_flat_mutation_word_finish+0x7c>
     b50:      	sub	x12, x12, #0x18
     b54:      	subs	x10, x10, #0x1
     b58:      	b.eq	0xb94 <_wf_flat_mutation_word_finish+0xb4>
     b5c:      	ldur	w14, [x12, #-0x10]
     b60:      	cmp	w14, #0x2
     b64:      	b.ne	0xb50 <_wf_flat_mutation_word_finish+0x70>
     b68:      	ldp	x15, x14, [x12, #-0x8]
     b6c:      	madd	x14, x15, x13, x14
     b70:      	add	x22, x14, x22
     b74:      	eor	x14, x14, x14, lsr #30
     b78:      	mul	x14, x14, x20
     b7c:      	eor	x14, x14, x14, lsr #27
     b80:      	mul	x14, x14, x19
     b84:      	eor	x15, x21, x14, lsr #31
     b88:      	eor	x21, x15, x14
     b8c:      	add	x11, x11, #0x1
     b90:      	b	0xb50 <_wf_flat_mutation_word_finish+0x70>
     b94:      	mov	x10, #0x7c15            ; =31765
     b98:      	movk	x10, #0x7f4a, lsl #16
     b9c:      	movk	x10, #0x79b9, lsl #32
     ba0:      	movk	x10, #0x9e37, lsl #48
     ba4:      	mul	x23, x11, x10
     ba8:      	ldr	x24, [x8, #0x38]
     bac:      	cbz	x9, 0xbb4 <_wf_flat_mutation_word_finish+0xd4>
     bb0:      	bl	0xbb0 <_wf_flat_mutation_word_finish+0xd0>
		0000000000000bb0:  ARM64_RELOC_BRANCH26	_free
     bb4:      	eor	x8, x24, x24, lsr #30
     bb8:      	mul	x8, x8, x20
     bbc:      	eor	x8, x8, x8, lsr #27
     bc0:      	mul	x8, x8, x19
     bc4:      	eor	x9, x22, x22, lsr #30
     bc8:      	mul	x9, x9, x20
     bcc:      	eor	x9, x9, x9, lsr #27
     bd0:      	mul	x9, x9, x19
     bd4:      	eor	x10, x9, x8
     bd8:      	eor	x11, x23, x21
     bdc:      	eor	x10, x11, x10, lsr #31
     be0:      	eor	x8, x8, x9
     be4:      	eor	x0, x10, x8
     be8:      	ldp	x29, x30, [sp, #0x30]
     bec:      	ldp	x20, x19, [sp, #0x20]
     bf0:      	ldp	x22, x21, [sp, #0x10]
     bf4:      	ldp	x24, x23, [sp], #0x40
     bf8:      	ret
     bfc:      	mov	x23, #0x0               ; =0
     c00:      	mov	x21, #0x0               ; =0
     c04:      	mov	x22, #0x0               ; =0
     c08:      	ldr	x24, [x8, #0x38]
     c0c:      	cbnz	x9, 0xbb0 <_wf_flat_mutation_word_finish+0xd0>
     c10:      	b	0xbb4 <_wf_flat_mutation_word_finish+0xd4>
     c14:      	mov	x11, #0x0               ; =0
     c18:      	mov	x21, #0x0               ; =0
     c1c:      	mov	x22, #0x0               ; =0
     c20:      	and	x13, x12, #0xfffffffffffffffc
     c24:      	mov	w14, #0x18              ; =24
     c28:      	madd	x14, x12, x14, x0
     c2c:      	sub	x14, x14, #0x30
     c30:      	mov	w15, #0x83              ; =131
     c34:      	b	0xc48 <_wf_flat_mutation_word_finish+0x168>
     c38:      	sub	x14, x14, #0x60
     c3c:      	sub	x12, x12, #0x4
     c40:      	sub	x13, x13, #0x4
     c44:      	cbz	x13, 0xb38 <_wf_flat_mutation_word_finish+0x58>
     c48:      	ldr	w16, [x14, #0x18]
     c4c:      	cmp	w16, #0x2
     c50:      	b.eq	0xc7c <_wf_flat_mutation_word_finish+0x19c>
     c54:      	ldr	w16, [x14]
     c58:      	cmp	w16, #0x2
     c5c:      	b.eq	0xcb0 <_wf_flat_mutation_word_finish+0x1d0>
     c60:      	ldur	w16, [x14, #-0x18]
     c64:      	cmp	w16, #0x2
     c68:      	b.eq	0xce4 <_wf_flat_mutation_word_finish+0x204>
     c6c:      	ldur	w16, [x14, #-0x30]
     c70:      	cmp	w16, #0x2
     c74:      	b.ne	0xc38 <_wf_flat_mutation_word_finish+0x158>
     c78:      	b	0xd18 <_wf_flat_mutation_word_finish+0x238>
     c7c:      	ldp	x17, x16, [x14, #0x20]
     c80:      	madd	x16, x17, x15, x16
     c84:      	add	x22, x16, x22
     c88:      	eor	x16, x16, x16, lsr #30
     c8c:      	mul	x16, x16, x20
     c90:      	eor	x16, x16, x16, lsr #27
     c94:      	mul	x16, x16, x19
     c98:      	eor	x17, x21, x16, lsr #31
     c9c:      	eor	x21, x17, x16
     ca0:      	add	x11, x11, #0x1
     ca4:      	ldr	w16, [x14]
     ca8:      	cmp	w16, #0x2
     cac:      	b.ne	0xc60 <_wf_flat_mutation_word_finish+0x180>
     cb0:      	ldp	x17, x16, [x14, #0x8]
     cb4:      	madd	x16, x17, x15, x16
     cb8:      	add	x22, x16, x22
     cbc:      	eor	x16, x16, x16, lsr #30
     cc0:      	mul	x16, x16, x20
     cc4:      	eor	x16, x16, x16, lsr #27
     cc8:      	mul	x16, x16, x19
     ccc:      	eor	x17, x21, x16, lsr #31
     cd0:      	eor	x21, x17, x16
     cd4:      	add	x11, x11, #0x1
     cd8:      	ldur	w16, [x14, #-0x18]
     cdc:      	cmp	w16, #0x2
     ce0:      	b.ne	0xc6c <_wf_flat_mutation_word_finish+0x18c>
     ce4:      	ldp	x17, x16, [x14, #-0x10]
     ce8:      	madd	x16, x17, x15, x16
     cec:      	add	x22, x16, x22
     cf0:      	eor	x16, x16, x16, lsr #30
     cf4:      	mul	x16, x16, x20
     cf8:      	eor	x16, x16, x16, lsr #27
     cfc:      	mul	x16, x16, x19
     d00:      	eor	x17, x21, x16, lsr #31
     d04:      	eor	x21, x17, x16
     d08:      	add	x11, x11, #0x1
     d0c:      	ldur	w16, [x14, #-0x30]
     d10:      	cmp	w16, #0x2
     d14:      	b.ne	0xc38 <_wf_flat_mutation_word_finish+0x158>
     d18:      	ldp	x17, x16, [x14, #-0x28]
     d1c:      	madd	x16, x17, x15, x16
     d20:      	add	x22, x16, x22
     d24:      	eor	x16, x16, x16, lsr #30
     d28:      	mul	x16, x16, x20
     d2c:      	eor	x16, x16, x16, lsr #27
     d30:      	mul	x16, x16, x19
     d34:      	eor	x17, x21, x16, lsr #31
     d38:      	eor	x21, x17, x16
     d3c:      	add	x11, x11, #0x1
     d40:      	b	0xc38 <_wf_flat_mutation_word_finish+0x158>

0000000000000d44 <_wf_flat_mutation_record_prepare>:
     d44:      	b	0xd44 <_wf_flat_mutation_record_prepare>
		0000000000000d44:  ARM64_RELOC_BRANCH26	_wf_flat_mutation_prepare$instance$4250cb78d3f44027

0000000000000d48 <_wf_flat_mutation_record_batch>:
     d48:      	b	0xd48 <_wf_flat_mutation_record_batch>
		0000000000000d48:  ARM64_RELOC_BRANCH26	_wf_flat_mutation_batch$instance$4250cb78d3f44027

0000000000000d4c <_wf_flat_mutation_record_geometry>:
     d4c:      	ldr	x8, [x0]
     d50:      	ldr	x9, [x0, #0x18]
     d54:      	add	x0, x9, x8, lsl #32
     d58:      	ret

0000000000000d5c <_wf_flat_mutation_record_verify>:
     d5c:      	b	0xd5c <_wf_flat_mutation_record_verify>
		0000000000000d5c:  ARM64_RELOC_BRANCH26	_wf_flat_mutation_verify$instance$4250cb78d3f44027

0000000000000d60 <_wf_flat_mutation_record_finish>:
     d60:      	sub	sp, sp, #0x60
     d64:      	stp	x29, x30, [sp, #0x50]
     d68:      	ldr	x8, [x0, #0x38]
     d6c:      	ldp	q0, q1, [x0]
     d70:      	stp	q0, q1, [sp, #0x20]
     d74:      	ldr	x9, [x0, #0x20]
     d78:      	str	x9, [sp, #0x40]
     d7c:      	stp	x8, xzr, [sp]
     d80:      	stp	xzr, xzr, [sp, #0x10]
     d84:      	add	x0, sp, #0x20
     d88:      	mov	x1, sp
     d8c:      	bl	0xd8c <_wf_flat_mutation_record_finish+0x2c>
		0000000000000d8c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_free$instance$e1a21e22af512733
     d90:      	ldp	x8, x9, [sp]
     d94:      	ldp	x10, x11, [sp, #0x10]
     d98:      	eor	x8, x8, x8, lsr #30
     d9c:      	mov	x12, #0xe5b9            ; =58809
     da0:      	movk	x12, #0x1ce4, lsl #16
     da4:      	movk	x12, #0x476d, lsl #32
     da8:      	movk	x12, #0xbf58, lsl #48
     dac:      	mul	x8, x8, x12
     db0:      	eor	x8, x8, x8, lsr #27
     db4:      	mov	x13, #0x11eb            ; =4587
     db8:      	movk	x13, #0x1331, lsl #16
     dbc:      	movk	x13, #0x49bb, lsl #32
     dc0:      	movk	x13, #0x94d0, lsl #48
     dc4:      	mul	x8, x8, x13
     dc8:      	eor	x9, x9, x9, lsr #30
     dcc:      	mul	x9, x9, x12
     dd0:      	eor	x9, x9, x9, lsr #27
     dd4:      	mul	x9, x9, x13
     dd8:      	eor	x12, x9, x8
     ddc:      	mov	x13, #0x7c15            ; =31765
     de0:      	movk	x13, #0x7f4a, lsl #16
     de4:      	movk	x13, #0x79b9, lsl #32
     de8:      	movk	x13, #0x9e37, lsl #48
     dec:      	mul	x11, x11, x13
     df0:      	eor	x10, x10, x11
     df4:      	eor	x10, x10, x12, lsr #31
     df8:      	eor	x8, x8, x9
     dfc:      	eor	x0, x10, x8
     e00:      	ldp	x29, x30, [sp, #0x50]
     e04:      	add	sp, sp, #0x60
     e08:      	ret

0000000000000e0c <_wf_chain_mutation_word_prepare>:
     e0c:      	b	0xe0c <_wf_chain_mutation_word_prepare>
		0000000000000e0c:  ARM64_RELOC_BRANCH26	_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd

0000000000000e10 <_wf_chain_mutation_word_batch>:
     e10:      	b	0xe10 <_wf_chain_mutation_word_batch>
		0000000000000e10:  ARM64_RELOC_BRANCH26	_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd

0000000000000e14 <_wf_chain_mutation_word_geometry>:
     e14:      	ldr	x8, [x0]
     e18:      	ldr	x9, [x0, #0x18]
     e1c:      	add	x0, x9, x8, lsl #32
     e20:      	ret

0000000000000e24 <_wf_chain_mutation_word_verify>:
     e24:      	b	0xe24 <_wf_chain_mutation_word_verify>
		0000000000000e24:  ARM64_RELOC_BRANCH26	_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd

0000000000000e28 <_wf_chain_mutation_word_finish>:
     e28:      	sub	sp, sp, #0x70
     e2c:      	stp	x29, x30, [sp, #0x60]
     e30:      	ldp	q0, q1, [x0, #0x20]
     e34:      	stp	q0, q1, [sp, #0x20]
     e38:      	ldr	q0, [x0, #0x40]
     e3c:      	str	q0, [sp, #0x40]
     e40:      	ldr	x8, [x0, #0x50]
     e44:      	str	x8, [sp, #0x50]
     e48:      	ldp	q0, q1, [x0]
     e4c:      	stp	q0, q1, [sp]
     e50:      	mov	x0, sp
     e54:      	bl	0xe54 <_wf_chain_mutation_word_finish+0x2c>
		0000000000000e54:  ARM64_RELOC_BRANCH26	_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd
     e58:      	ldp	x29, x30, [sp, #0x60]
     e5c:      	add	sp, sp, #0x70
     e60:      	ret

0000000000000e64 <_wf_chain_mutation_record_prepare>:
     e64:      	b	0xe64 <_wf_chain_mutation_record_prepare>
		0000000000000e64:  ARM64_RELOC_BRANCH26	_wf_chain_mutation_prepare$instance$4250cb78d3f44027

0000000000000e68 <_wf_chain_mutation_record_batch>:
     e68:      	b	0xe68 <_wf_chain_mutation_record_batch>
		0000000000000e68:  ARM64_RELOC_BRANCH26	_wf_chain_mutation_batch$instance$4250cb78d3f44027

0000000000000e6c <_wf_chain_mutation_record_geometry>:
     e6c:      	ldr	x8, [x0]
     e70:      	ldr	x9, [x0, #0x18]
     e74:      	add	x0, x9, x8, lsl #32
     e78:      	ret

0000000000000e7c <_wf_chain_mutation_record_verify>:
     e7c:      	b	0xe7c <_wf_chain_mutation_record_verify>
		0000000000000e7c:  ARM64_RELOC_BRANCH26	_wf_chain_mutation_verify$instance$4250cb78d3f44027

0000000000000e80 <_wf_chain_mutation_record_finish>:
     e80:      	sub	sp, sp, #0x60
     e84:      	stp	x29, x30, [sp, #0x50]
     e88:      	ldr	x8, [x0, #0x40]
     e8c:      	ldp	q0, q1, [x0]
     e90:      	stp	q0, q1, [sp, #0x20]
     e94:      	ldr	q0, [x0, #0x20]
     e98:      	str	q0, [sp, #0x40]
     e9c:      	stp	x8, xzr, [sp]
     ea0:      	stp	xzr, xzr, [sp, #0x10]
     ea4:      	add	x0, sp, #0x20
     ea8:      	mov	x1, sp
     eac:      	bl	0xeac <_wf_chain_mutation_record_finish+0x2c>
		0000000000000eac:  ARM64_RELOC_BRANCH26	_wf_full_chain_free$instance$e1a21e22af512733
     eb0:      	ldp	x8, x9, [sp]
     eb4:      	ldp	x10, x11, [sp, #0x10]
     eb8:      	eor	x8, x8, x8, lsr #30
     ebc:      	mov	x12, #0xe5b9            ; =58809
     ec0:      	movk	x12, #0x1ce4, lsl #16
     ec4:      	movk	x12, #0x476d, lsl #32
     ec8:      	movk	x12, #0xbf58, lsl #48
     ecc:      	mul	x8, x8, x12
     ed0:      	eor	x8, x8, x8, lsr #27
     ed4:      	mov	x13, #0x11eb            ; =4587
     ed8:      	movk	x13, #0x1331, lsl #16
     edc:      	movk	x13, #0x49bb, lsl #32
     ee0:      	movk	x13, #0x94d0, lsl #48
     ee4:      	mul	x8, x8, x13
     ee8:      	eor	x9, x9, x9, lsr #30
     eec:      	mul	x9, x9, x12
     ef0:      	eor	x9, x9, x9, lsr #27
     ef4:      	mul	x9, x9, x13
     ef8:      	eor	x12, x9, x8
     efc:      	mov	x13, #0x7c15            ; =31765
     f00:      	movk	x13, #0x7f4a, lsl #16
     f04:      	movk	x13, #0x79b9, lsl #32
     f08:      	movk	x13, #0x9e37, lsl #48
     f0c:      	mul	x11, x11, x13
     f10:      	eor	x10, x10, x11
     f14:      	eor	x10, x10, x12, lsr #31
     f18:      	eor	x8, x8, x9
     f1c:      	eor	x0, x10, x8
     f20:      	ldp	x29, x30, [sp, #0x50]
     f24:      	add	sp, sp, #0x60
     f28:      	ret

0000000000000f2c <_wf_std.collections.hash_map.hash_map_probe>:
     f2c:      	sub	x8, x2, x0
     f30:      	cmp	x1, x8
     f34:      	csneg	x8, x0, x8, lo
     f38:      	add	x0, x8, x1
     f3c:      	ret

0000000000000f40 <_wf_array_filled$instance$581665c886d1d2c8>:
     f40:      	dup.2d	v0, x1
     f44:      	stp	q0, q0, [x0]
     f48:      	stp	q0, q0, [x0, #0x20]
     f4c:      	stp	q0, q0, [x0, #0x40]
     f50:      	stp	q0, q0, [x0, #0x60]
     f54:      	stp	q0, q0, [x0, #0x80]
     f58:      	stp	q0, q0, [x0, #0xa0]
     f5c:      	stp	q0, q0, [x0, #0xc0]
     f60:      	stp	q0, q0, [x0, #0xe0]
     f64:      	ret

0000000000000f68 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd>:
     f68:      	sub	sp, sp, #0xb0
     f6c:      	stp	x28, x27, [sp, #0x50]
     f70:      	stp	x26, x25, [sp, #0x60]
     f74:      	stp	x24, x23, [sp, #0x70]
     f78:      	stp	x22, x21, [sp, #0x80]
     f7c:      	stp	x20, x19, [sp, #0x90]
     f80:      	stp	x29, x30, [sp, #0xa0]
     f84:      	mov	x19, x0
     f88:      	mov	x8, #0x7c15             ; =31765
     f8c:      	movk	x8, #0x7f4a, lsl #16
     f90:      	movk	x8, #0x79b9, lsl #32
     f94:      	movk	x8, #0x9e37, lsl #48
     f98:      	eor	x20, x0, x8
     f9c:      	cmp	x1, #0x0
     fa0:      	cset	w8, ne
     fa4:      	str	x20, [sp, #0x30]
     fa8:      	strb	w8, [sp, #0x38]
     fac:      	mov	w0, #0x48               ; =72
     fb0:      	bl	0xfb0 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x48>
		0000000000000fb0:  ARM64_RELOC_BRANCH26	_malloc
     fb4:      	cbz	x0, 0x17e4 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x87c>
     fb8:      	mov	x25, #0x0               ; =0
     fbc:      	mov	x21, #0xe5b9            ; =58809
     fc0:      	movk	x21, #0x1ce4, lsl #16
     fc4:      	movk	x21, #0x476d, lsl #32
     fc8:      	movk	x21, #0xbf58, lsl #48
     fcc:      	str	wzr, [x0]
     fd0:      	stp	xzr, xzr, [x0, #0x38]
     fd4:      	stp	xzr, xzr, [x0, #0x8]
     fd8:      	str	wzr, [x0, #0x18]
     fdc:      	stp	xzr, xzr, [x0, #0x20]
     fe0:      	mov	w1, #0x3                ; =3
     fe4:      	dup.2d	v0, x1
     fe8:      	str	wzr, [x0, #0x30]
     fec:      	str	q0, [sp]
     ff0:      	stp	xzr, xzr, [sp, #0x18]
     ff4:      	str	x0, [sp, #0x10]
     ff8:      	eor	x26, x20, x20, lsr #30
     ffc:      	mov	w27, #0x1               ; =1
    1000:      	ldrb	w23, [sp, #0x38]
    1004:      	mov	w28, #0x2               ; =2
    1008:      	mov	w22, #0x18              ; =24
    100c:      	mov	w20, #0x83              ; =131
    1010:      	mov	x24, x19
    1014:      	b	0x103c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0xd4>
    1018:      	strb	w27, [sp, #0x4c]
    101c:      	tst	w27, #0x1
    1020:      	cinc	x10, x27, ne
    1024:      	madd	x8, x24, x20, x8
    1028:      	add	x8, x8, x10
    102c:      	madd	x24, x8, x20, x9
    1030:      	add	x25, x25, #0x1
    1034:      	cmp	x25, #0x3
    1038:      	b.eq	0x11dc <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x274>
    103c:      	ldp	x8, x9, [sp, #0x18]
    1040:      	adds	x9, x8, x9
    1044:      	csinv	x9, x9, xzr, lo
    1048:      	cmp	x1, #0x2
    104c:      	b.hi	0x1084 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x11c>
    1050:      	sub	x10, x1, x1, lsr #2
    1054:      	cmp	x9, x10
    1058:      	b.lo	0x1084 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x11c>
    105c:      	cmp	x8, x1, lsr #1
    1060:      	b.lo	0x1078 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x110>
    1064:      	cbz	x1, 0x1074 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x10c>
    1068:      	cmp	x1, #0x1
    106c:      	cinc	x1, x28, ne
    1070:      	b	0x1078 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x110>
    1074:      	mov	w1, #0x1                ; =1
    1078:      	mov	x0, sp
    107c:      	add	x2, sp, #0x30
    1080:      	bl	0x1080 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x118>
		0000000000001080:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6
    1084:      	orr	x8, x27, x25, lsl #1
    1088:      	tbz	w23, #0x0, 0x1110 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x1a8>
    108c:      	mov	x10, #0x0               ; =0
    1090:      	add	x9, x25, x19
    1094:      	ldr	x1, [sp]
    1098:      	cbz	x1, 0x1140 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x1d8>
    109c:      	udiv	x11, x10, x1
    10a0:      	msub	x11, x11, x1, x10
    10a4:      	ldr	x12, [sp, #0x10]
    10a8:      	mov	x13, x1
    10ac:      	mov	x10, x1
    10b0:      	b	0x10d0 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x168>
    10b4:      	cmp	x10, x1
    10b8:      	csel	x10, x11, x10, eq
    10bc:      	add	x14, x11, #0x1
    10c0:      	cmp	x14, x1
    10c4:      	csinc	x11, xzr, x11, hs
    10c8:      	subs	x13, x13, #0x1
    10cc:      	b.eq	0x1144 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x1dc>
    10d0:      	madd	x14, x11, x22, x12
    10d4:      	ldr	w15, [x14]
    10d8:      	cmp	w15, #0x1
    10dc:      	b.eq	0x10b4 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x14c>
    10e0:      	cmp	w15, #0x2
    10e4:      	b.ne	0x1190 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x228>
    10e8:      	ldr	x15, [x14, #0x8]
    10ec:      	cmp	x15, x8
    10f0:      	b.ne	0x10bc <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x154>
    10f4:      	ldr	x11, [x14, #0x10]
    10f8:      	str	w28, [x14]
    10fc:      	str	x9, [x14, #0x10]
    1100:      	strb	wzr, [sp, #0x4c]
    1104:      	mov	w10, #0x1               ; =1
    1108:      	mov	x9, x11
    110c:      	b	0x1024 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0xbc>
    1110:      	eor	x9, x26, x8
    1114:      	mul	x9, x9, x21
    1118:      	eor	x9, x9, x9, lsr #27
    111c:      	mov	x10, #0x11eb            ; =4587
    1120:      	movk	x10, #0x1331, lsl #16
    1124:      	movk	x10, #0x49bb, lsl #32
    1128:      	movk	x10, #0x94d0, lsl #48
    112c:      	mul	x9, x9, x10
    1130:      	eor	x10, x9, x9, lsr #31
    1134:      	add	x9, x25, x19
    1138:      	ldr	x1, [sp]
    113c:      	cbnz	x1, 0x109c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x134>
    1140:      	mov	x10, #0x0               ; =0
    1144:      	cmp	x10, x1
    1148:      	b.hs	0x1018 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0xb0>
    114c:      	ldr	x11, [sp, #0x18]
    1150:      	cmp	x11, #0x2
    1154:      	b.hi	0x1018 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0xb0>
    1158:      	add	x11, x11, #0x1
    115c:      	str	x11, [sp, #0x18]
    1160:      	ldr	x11, [sp, #0x10]
    1164:      	madd	x10, x10, x22, x11
    1168:      	ldr	w13, [x10]
    116c:      	cmp	w13, #0x1
    1170:      	b.ne	0x11a4 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x23c>
    1174:      	ldr	x11, [sp, #0x20]
    1178:      	subs	x11, x11, #0x1
    117c:      	csel	x11, xzr, x11, lo
    1180:      	str	x11, [sp, #0x20]
    1184:      	str	w28, [x10]
    1188:      	stp	x8, x9, [x10, #0x8]
    118c:      	b	0x11c8 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x260>
    1190:      	cmp	x10, x1
    1194:      	csel	x10, x11, x10, eq
    1198:      	cmp	x10, x1
    119c:      	b.hs	0x1018 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0xb0>
    11a0:      	b	0x114c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x1e4>
    11a4:      	ldp	x11, x12, [x10, #0x8]
    11a8:      	str	w28, [x10]
    11ac:      	stp	x8, x9, [x10, #0x8]
    11b0:      	cbz	w13, 0x11c8 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x260>
    11b4:      	strb	wzr, [sp, #0x4c]
    11b8:      	mov	w10, #0x1               ; =1
    11bc:      	mov	x9, x12
    11c0:      	mov	x8, x11
    11c4:      	b	0x1024 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0xbc>
    11c8:      	strb	wzr, [sp, #0x4c]
    11cc:      	mul	x24, x24, x20
    11d0:      	add	x25, x25, #0x1
    11d4:      	cmp	x25, #0x3
    11d8:      	b.ne	0x103c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0xd4>
    11dc:      	add	x20, x19, #0xa
    11e0:      	ldp	x8, x9, [sp, #0x18]
    11e4:      	adds	x9, x8, x9
    11e8:      	csinv	x9, x9, xzr, lo
    11ec:      	cmp	x1, #0x2
    11f0:      	b.hi	0x1228 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x2c0>
    11f4:      	sub	x10, x1, x1, lsr #2
    11f8:      	cmp	x9, x10
    11fc:      	b.lo	0x1228 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x2c0>
    1200:      	cmp	x1, #0x1
    1204:      	mov	w9, #0x2                ; =2
    1208:      	cinc	x9, x9, ne
    120c:      	cmp	x1, #0x0
    1210:      	csinc	x9, x9, xzr, ne
    1214:      	cmp	x8, x1, lsr #1
    1218:      	csel	x1, x1, x9, lo
    121c:      	mov	x0, sp
    1220:      	add	x2, sp, #0x30
    1224:      	bl	0x1224 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x2bc>
		0000000000001224:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6
    1228:      	mov	x27, #0x7c15            ; =31765
    122c:      	movk	x27, #0x7f4a, lsl #16
    1230:      	movk	x27, #0x79b9, lsl #32
    1234:      	movk	x27, #0x9e37, lsl #48
    1238:      	sub	x8, x27, #0x1
    123c:      	eor	x8, x19, x8
    1240:      	eor	x8, x8, x8, lsr #30
    1244:      	mul	x8, x8, x21
    1248:      	eor	x8, x8, x8, lsr #27
    124c:      	mov	x25, #0x11eb            ; =4587
    1250:      	movk	x25, #0x1331, lsl #16
    1254:      	movk	x25, #0x49bb, lsl #32
    1258:      	movk	x25, #0x94d0, lsl #48
    125c:      	mul	x8, x8, x25
    1260:      	eor	x8, x8, x8, lsr #31
    1264:      	tst	w23, #0x1
    1268:      	csel	x9, xzr, x8, ne
    126c:      	ldr	x8, [sp]
    1270:      	cbz	x8, 0x12f4 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x38c>
    1274:      	udiv	x10, x9, x8
    1278:      	msub	x9, x10, x8, x9
    127c:      	ldr	x11, [sp, #0x10]
    1280:      	mov	w12, #0x18              ; =24
    1284:      	mov	x13, x8
    1288:      	mov	x10, x8
    128c:      	b	0x12ac <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x344>
    1290:      	cmp	x10, x8
    1294:      	csel	x10, x9, x10, eq
    1298:      	add	x14, x9, #0x1
    129c:      	cmp	x14, x8
    12a0:      	csinc	x9, xzr, x9, hs
    12a4:      	subs	x13, x13, #0x1
    12a8:      	b.eq	0x12f8 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x390>
    12ac:      	madd	x14, x9, x12, x11
    12b0:      	ldr	w15, [x14]
    12b4:      	cmp	w15, #0x1
    12b8:      	b.eq	0x1290 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x328>
    12bc:      	cmp	w15, #0x2
    12c0:      	b.ne	0x1350 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x3e8>
    12c4:      	ldr	x15, [x14, #0x8]
    12c8:      	cmp	x15, #0x1
    12cc:      	b.ne	0x1298 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x330>
    12d0:      	ldr	x10, [x14, #0x10]
    12d4:      	mov	w9, #0x2                ; =2
    12d8:      	str	w9, [x14]
    12dc:      	str	x20, [x14, #0x10]
    12e0:      	strb	wzr, [sp, #0x48]
    12e4:      	mov	w9, #0x1                ; =1
    12e8:      	mov	x20, x10
    12ec:      	mov	w10, #0x1               ; =1
    12f0:      	b	0x1370 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x408>
    12f4:      	mov	x10, #0x0               ; =0
    12f8:      	cmp	x10, x8
    12fc:      	b.hs	0x1360 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x3f8>
    1300:      	ldr	x9, [sp, #0x18]
    1304:      	cmp	x9, #0x2
    1308:      	b.hi	0x1360 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x3f8>
    130c:      	add	x9, x9, #0x1
    1310:      	str	x9, [sp, #0x18]
    1314:      	ldr	x11, [sp, #0x10]
    1318:      	mov	w12, #0x18              ; =24
    131c:      	madd	x11, x10, x12, x11
    1320:      	ldr	w13, [x11]
    1324:      	cmp	w13, #0x1
    1328:      	b.ne	0x15fc <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x694>
    132c:      	ldr	x10, [sp, #0x20]
    1330:      	subs	x10, x10, #0x1
    1334:      	csel	x10, xzr, x10, lo
    1338:      	str	x10, [sp, #0x20]
    133c:      	mov	w10, #0x2               ; =2
    1340:      	str	w10, [x11]
    1344:      	mov	w10, #0x1               ; =1
    1348:      	stp	x10, x20, [x11, #0x8]
    134c:      	b	0x1624 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x6bc>
    1350:      	cmp	x10, x8
    1354:      	csel	x10, x9, x10, eq
    1358:      	cmp	x10, x8
    135c:      	b.lo	0x1300 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x398>
    1360:      	mov	w10, #0x1               ; =1
    1364:      	strb	w10, [sp, #0x48]
    1368:      	tst	w10, #0x1
    136c:      	cinc	x9, x10, ne
    1370:      	mov	w11, #0x83              ; =131
    1374:      	mul	x12, x24, x11
    1378:      	add	x9, x10, x9
    137c:      	add	x9, x9, x12
    1380:      	madd	x20, x9, x11, x20
    1384:      	ldp	x9, x10, [sp, #0x18]
    1388:      	add	x22, x19, #0x14
    138c:      	adds	x10, x9, x10
    1390:      	csinv	x10, x10, xzr, lo
    1394:      	cmp	x8, #0x2
    1398:      	b.hi	0x13d0 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x468>
    139c:      	sub	x11, x8, x8, lsr #2
    13a0:      	cmp	x10, x11
    13a4:      	b.lo	0x13d0 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x468>
    13a8:      	cmp	x8, #0x1
    13ac:      	mov	w10, #0x2               ; =2
    13b0:      	cinc	x10, x10, ne
    13b4:      	cmp	x8, #0x0
    13b8:      	csinc	x10, x10, xzr, ne
    13bc:      	cmp	x9, x8, lsr #1
    13c0:      	csel	x1, x8, x10, lo
    13c4:      	mov	x0, sp
    13c8:      	add	x2, sp, #0x30
    13cc:      	bl	0x13cc <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x464>
		00000000000013cc:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6
    13d0:      	sub	x8, x27, #0x3
    13d4:      	eor	x8, x19, x8
    13d8:      	eor	x8, x8, x8, lsr #30
    13dc:      	mul	x8, x8, x21
    13e0:      	eor	x8, x8, x8, lsr #27
    13e4:      	mul	x8, x8, x25
    13e8:      	eor	x8, x8, x8, lsr #31
    13ec:      	tst	w23, #0x1
    13f0:      	csel	x9, xzr, x8, ne
    13f4:      	ldr	x8, [sp]
    13f8:      	cbz	x8, 0x1478 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x510>
    13fc:      	udiv	x10, x9, x8
    1400:      	msub	x10, x10, x8, x9
    1404:      	ldr	x0, [sp, #0x10]
    1408:      	mov	w11, #0x18              ; =24
    140c:      	mov	x12, x8
    1410:      	mov	x9, x8
    1414:      	b	0x1434 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x4cc>
    1418:      	cmp	x9, x8
    141c:      	csel	x9, x10, x9, eq
    1420:      	add	x13, x10, #0x1
    1424:      	cmp	x13, x8
    1428:      	csinc	x10, xzr, x10, hs
    142c:      	subs	x12, x12, #0x1
    1430:      	b.eq	0x147c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x514>
    1434:      	madd	x13, x10, x11, x0
    1438:      	ldr	w14, [x13]
    143c:      	cmp	w14, #0x1
    1440:      	b.eq	0x1418 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x4b0>
    1444:      	cmp	w14, #0x2
    1448:      	b.ne	0x14d0 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x568>
    144c:      	ldr	x14, [x13, #0x8]
    1450:      	cmp	x14, #0x7
    1454:      	b.ne	0x1420 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x4b8>
    1458:      	ldr	x10, [x13, #0x10]
    145c:      	mov	w9, #0x2                ; =2
    1460:      	str	w9, [x13]
    1464:      	str	x22, [x13, #0x10]
    1468:      	strb	wzr, [sp, #0x44]
    146c:      	mov	w9, #0x1                ; =1
    1470:      	mov	x22, x10
    1474:      	b	0x14f4 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x58c>
    1478:      	mov	x9, #0x0                ; =0
    147c:      	cmp	x9, x8
    1480:      	b.hs	0x14e0 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x578>
    1484:      	ldp	x0, x10, [sp, #0x10]
    1488:      	cmp	x10, #0x2
    148c:      	b.hi	0x14e4 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x57c>
    1490:      	add	x10, x10, #0x1
    1494:      	str	x10, [sp, #0x18]
    1498:      	mov	w10, #0x18              ; =24
    149c:      	madd	x9, x9, x10, x0
    14a0:      	ldr	w12, [x9]
    14a4:      	cmp	w12, #0x1
    14a8:      	b.ne	0x164c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x6e4>
    14ac:      	ldr	x10, [sp, #0x20]
    14b0:      	subs	x10, x10, #0x1
    14b4:      	csel	x10, xzr, x10, lo
    14b8:      	str	x10, [sp, #0x20]
    14bc:      	mov	w10, #0x2               ; =2
    14c0:      	str	w10, [x9]
    14c4:      	mov	w10, #0x7               ; =7
    14c8:      	stp	x10, x22, [x9, #0x8]
    14cc:      	b	0x1694 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x72c>
    14d0:      	cmp	x9, x8
    14d4:      	csel	x9, x10, x9, eq
    14d8:      	cmp	x9, x8
    14dc:      	b.lo	0x1484 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x51c>
    14e0:      	ldr	x0, [sp, #0x10]
    14e4:      	mov	w9, #0x1                ; =1
    14e8:      	strb	w9, [sp, #0x44]
    14ec:      	tst	w9, #0x1
    14f0:      	cinc	x9, x9, ne
    14f4:      	mov	w10, #0x83              ; =131
    14f8:      	mul	x11, x20, x10
    14fc:      	add	x9, x11, x9
    1500:      	madd	x9, x9, x10, x22
    1504:      	add	x19, x9, #0x395
    1508:      	ldr	x9, [sp, #0x8]
    150c:      	cbz	x8, 0x15e8 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x680>
    1510:      	sub	x11, x8, #0x1
    1514:      	and	x10, x8, #0x3
    1518:      	cmp	x11, #0x3
    151c:      	b.hs	0x16b4 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x74c>
    1520:      	mov	x11, #0x0               ; =0
    1524:      	mov	x23, #0x0               ; =0
    1528:      	mov	x24, #0x0               ; =0
    152c:      	cbz	x10, 0x1588 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x620>
    1530:      	mov	w12, #0x18              ; =24
    1534:      	madd	x8, x8, x12, x0
    1538:      	sub	x8, x8, #0x8
    153c:      	mov	w12, #0x83              ; =131
    1540:      	b	0x1550 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x5e8>
    1544:      	sub	x8, x8, #0x18
    1548:      	subs	x10, x10, #0x1
    154c:      	b.eq	0x1588 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x620>
    1550:      	ldur	w13, [x8, #-0x10]
    1554:      	cmp	w13, #0x2
    1558:      	b.ne	0x1544 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x5dc>
    155c:      	ldp	x14, x13, [x8, #-0x8]
    1560:      	madd	x13, x14, x12, x13
    1564:      	add	x24, x13, x24
    1568:      	eor	x13, x13, x13, lsr #30
    156c:      	mul	x13, x13, x21
    1570:      	eor	x13, x13, x13, lsr #27
    1574:      	mul	x13, x13, x25
    1578:      	eor	x14, x23, x13, lsr #31
    157c:      	eor	x23, x14, x13
    1580:      	add	x11, x11, #0x1
    1584:      	b	0x1544 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x5dc>
    1588:      	mul	x20, x11, x27
    158c:      	cbz	x9, 0x1594 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x62c>
    1590:      	bl	0x1590 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x628>
		0000000000001590:  ARM64_RELOC_BRANCH26	_free
    1594:      	eor	x8, x19, x19, lsr #30
    1598:      	mul	x8, x8, x21
    159c:      	eor	x8, x8, x8, lsr #27
    15a0:      	mul	x8, x8, x25
    15a4:      	eor	x9, x24, x24, lsr #30
    15a8:      	mul	x9, x9, x21
    15ac:      	eor	x9, x9, x9, lsr #27
    15b0:      	mul	x9, x9, x25
    15b4:      	eor	x10, x9, x8
    15b8:      	eor	x11, x23, x20
    15bc:      	eor	x10, x11, x10, lsr #31
    15c0:      	eor	x8, x8, x9
    15c4:      	eor	x0, x10, x8
    15c8:      	ldp	x29, x30, [sp, #0xa0]
    15cc:      	ldp	x20, x19, [sp, #0x90]
    15d0:      	ldp	x22, x21, [sp, #0x80]
    15d4:      	ldp	x24, x23, [sp, #0x70]
    15d8:      	ldp	x26, x25, [sp, #0x60]
    15dc:      	ldp	x28, x27, [sp, #0x50]
    15e0:      	add	sp, sp, #0xb0
    15e4:      	ret
    15e8:      	mov	x20, #0x0               ; =0
    15ec:      	mov	x23, #0x0               ; =0
    15f0:      	mov	x24, #0x0               ; =0
    15f4:      	cbnz	x9, 0x1590 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x628>
    15f8:      	b	0x1594 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x62c>
    15fc:      	ldp	x10, x12, [x11, #0x8]
    1600:      	mov	w14, #0x2               ; =2
    1604:      	str	w14, [x11]
    1608:      	mov	w14, #0x1               ; =1
    160c:      	stp	x14, x20, [x11, #0x8]
    1610:      	cbz	w13, 0x1624 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x6bc>
    1614:      	strb	wzr, [sp, #0x48]
    1618:      	mov	w9, #0x1                ; =1
    161c:      	mov	x20, x12
    1620:      	b	0x1370 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x408>
    1624:      	strb	wzr, [sp, #0x48]
    1628:      	mov	w10, #0x83              ; =131
    162c:      	mul	x20, x24, x10
    1630:      	add	x22, x19, #0x14
    1634:      	ldr	x10, [sp, #0x20]
    1638:      	adds	x10, x9, x10
    163c:      	csinv	x10, x10, xzr, lo
    1640:      	cmp	x8, #0x2
    1644:      	b.ls	0x139c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x434>
    1648:      	b	0x13d0 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x468>
    164c:      	ldp	x10, x11, [x9, #0x8]
    1650:      	mov	w13, #0x2               ; =2
    1654:      	str	w13, [x9]
    1658:      	mov	w13, #0x7               ; =7
    165c:      	stp	x13, x22, [x9, #0x8]
    1660:      	cbz	w12, 0x1694 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x72c>
    1664:      	strb	wzr, [sp, #0x44]
    1668:      	mov	w9, #0x83               ; =131
    166c:      	mul	x12, x20, x9
    1670:      	add	x10, x10, x12
    1674:      	madd	x9, x10, x9, x11
    1678:      	add	x19, x9, #0x83
    167c:      	ldr	x9, [sp, #0x8]
    1680:      	sub	x11, x8, #0x1
    1684:      	and	x10, x8, #0x3
    1688:      	cmp	x11, #0x3
    168c:      	b.lo	0x1520 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x5b8>
    1690:      	b	0x16b4 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x74c>
    1694:      	strb	wzr, [sp, #0x44]
    1698:      	mov	w9, #0x83               ; =131
    169c:      	mul	x19, x20, x9
    16a0:      	ldr	x9, [sp, #0x8]
    16a4:      	sub	x11, x8, #0x1
    16a8:      	and	x10, x8, #0x3
    16ac:      	cmp	x11, #0x3
    16b0:      	b.lo	0x1520 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x5b8>
    16b4:      	mov	x11, #0x0               ; =0
    16b8:      	mov	x23, #0x0               ; =0
    16bc:      	mov	x24, #0x0               ; =0
    16c0:      	and	x12, x8, #0xfffffffffffffffc
    16c4:      	mov	w13, #0x18              ; =24
    16c8:      	madd	x13, x8, x13, x0
    16cc:      	sub	x13, x13, #0x30
    16d0:      	mov	w14, #0x83              ; =131
    16d4:      	b	0x16e8 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x780>
    16d8:      	sub	x13, x13, #0x60
    16dc:      	sub	x8, x8, #0x4
    16e0:      	sub	x12, x12, #0x4
    16e4:      	cbz	x12, 0x152c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x5c4>
    16e8:      	ldr	w15, [x13, #0x18]
    16ec:      	cmp	w15, #0x2
    16f0:      	b.eq	0x171c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x7b4>
    16f4:      	ldr	w15, [x13]
    16f8:      	cmp	w15, #0x2
    16fc:      	b.eq	0x1750 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x7e8>
    1700:      	ldur	w15, [x13, #-0x18]
    1704:      	cmp	w15, #0x2
    1708:      	b.eq	0x1784 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x81c>
    170c:      	ldur	w15, [x13, #-0x30]
    1710:      	cmp	w15, #0x2
    1714:      	b.ne	0x16d8 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x770>
    1718:      	b	0x17b8 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x850>
    171c:      	ldp	x16, x15, [x13, #0x20]
    1720:      	madd	x15, x16, x14, x15
    1724:      	add	x24, x15, x24
    1728:      	eor	x15, x15, x15, lsr #30
    172c:      	mul	x15, x15, x21
    1730:      	eor	x15, x15, x15, lsr #27
    1734:      	mul	x15, x15, x25
    1738:      	eor	x16, x23, x15, lsr #31
    173c:      	eor	x23, x16, x15
    1740:      	add	x11, x11, #0x1
    1744:      	ldr	w15, [x13]
    1748:      	cmp	w15, #0x2
    174c:      	b.ne	0x1700 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x798>
    1750:      	ldp	x16, x15, [x13, #0x8]
    1754:      	madd	x15, x16, x14, x15
    1758:      	add	x24, x15, x24
    175c:      	eor	x15, x15, x15, lsr #30
    1760:      	mul	x15, x15, x21
    1764:      	eor	x15, x15, x15, lsr #27
    1768:      	mul	x15, x15, x25
    176c:      	eor	x16, x23, x15, lsr #31
    1770:      	eor	x23, x16, x15
    1774:      	add	x11, x11, #0x1
    1778:      	ldur	w15, [x13, #-0x18]
    177c:      	cmp	w15, #0x2
    1780:      	b.ne	0x170c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x7a4>
    1784:      	ldp	x16, x15, [x13, #-0x10]
    1788:      	madd	x15, x16, x14, x15
    178c:      	add	x24, x15, x24
    1790:      	eor	x15, x15, x15, lsr #30
    1794:      	mul	x15, x15, x21
    1798:      	eor	x15, x15, x15, lsr #27
    179c:      	mul	x15, x15, x25
    17a0:      	eor	x16, x23, x15, lsr #31
    17a4:      	eor	x23, x16, x15
    17a8:      	add	x11, x11, #0x1
    17ac:      	ldur	w15, [x13, #-0x30]
    17b0:      	cmp	w15, #0x2
    17b4:      	b.ne	0x16d8 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x770>
    17b8:      	ldp	x16, x15, [x13, #-0x28]
    17bc:      	madd	x15, x16, x14, x15
    17c0:      	add	x24, x15, x24
    17c4:      	eor	x15, x15, x15, lsr #30
    17c8:      	mul	x15, x15, x21
    17cc:      	eor	x15, x15, x15, lsr #27
    17d0:      	mul	x15, x15, x25
    17d4:      	eor	x16, x23, x15, lsr #31
    17d8:      	eor	x23, x16, x15
    17dc:      	add	x11, x11, #0x1
    17e0:      	b	0x16d8 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x770>
    17e4:      	bl	0x17e4 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x87c>
		00000000000017e4:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

00000000000017e8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd>:
    17e8:      	stp	x28, x27, [sp, #-0x60]!
    17ec:      	stp	x26, x25, [sp, #0x10]
    17f0:      	stp	x24, x23, [sp, #0x20]
    17f4:      	stp	x22, x21, [sp, #0x30]
    17f8:      	stp	x20, x19, [sp, #0x40]
    17fc:      	stp	x29, x30, [sp, #0x50]
    1800:      	sub	sp, sp, #0x270
    1804:      	mov	x22, x4
    1808:      	str	x2, [sp, #0x18]
    180c:      	mov	x21, x1
    1810:      	mov	x23, x0
    1814:      	mov	x8, #0x7c15             ; =31765
    1818:      	movk	x8, #0x7f4a, lsl #16
    181c:      	movk	x8, #0x79b9, lsl #32
    1820:      	movk	x8, #0x9e37, lsl #48
    1824:      	str	x3, [sp, #0x38]
    1828:      	eor	x8, x3, x8
    182c:      	cmp	x5, #0x0
    1830:      	cset	w9, ne
    1834:      	str	x8, [sp, #0x200]
    1838:      	strb	w9, [sp, #0x208]
    183c:      	cbz	x0, 0x1870 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x88>
    1840:      	add	x8, x23, x23, lsl #1
    1844:      	lsl	x0, x8, #3
    1848:      	bl	0x1848 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x60>
		0000000000001848:  ARM64_RELOC_BRANCH26	_malloc
    184c:      	cbz	x0, 0x2c58 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1470>
    1850:      	mov	x8, #0x0                ; =0
    1854:      	add	x9, x0, #0x8
    1858:      	stur	wzr, [x9, #-0x8]
    185c:      	add	x8, x8, #0x1
    1860:      	stp	xzr, xzr, [x9], #0x18
    1864:      	cmp	x23, x8
    1868:      	b.ne	0x1858 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x70>
    186c:      	b	0x1878 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x90>
    1870:      	adrp	x0, 0x1000 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x98>
		0000000000001870:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    1874:      	add	x0, x0, #0x0
		0000000000001874:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    1878:      	add	x27, sp, #0x40
    187c:      	mov	x6, #0xe5b9             ; =58809
    1880:      	movk	x6, #0x1ce4, lsl #16
    1884:      	movk	x6, #0x476d, lsl #32
    1888:      	movk	x6, #0xbf58, lsl #48
    188c:      	mov	x5, #0x11eb             ; =4587
    1890:      	movk	x5, #0x1331, lsl #16
    1894:      	movk	x5, #0x49bb, lsl #32
    1898:      	movk	x5, #0x94d0, lsl #48
    189c:      	str	x23, [sp, #0x210]
    18a0:      	str	x23, [sp, #0x218]
    18a4:      	str	x0, [sp, #0x220]
    18a8:      	str	xzr, [sp, #0x228]
    18ac:      	str	xzr, [sp, #0x230]
    18b0:      	ldr	x8, [sp, #0x38]
    18b4:      	str	x8, [sp, #0x238]
    18b8:      	str	xzr, [sp, #0x240]
    18bc:      	str	xzr, [sp, #0x250]
    18c0:      	str	xzr, [sp, #0x248]
    18c4:      	cbz	x21, 0x1b04 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x31c>
    18c8:      	mov	x19, #0x0               ; =0
    18cc:      	add	x20, sp, #0x40
    18d0:      	mov	w24, #0x1               ; =1
    18d4:      	mov	w25, #0x18              ; =24
    18d8:      	mov	w26, #0x2               ; =2
    18dc:      	mov	w28, #0x83              ; =131
    18e0:      	b	0x1920 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x138>
    18e4:      	stp	x24, x8, [sp, #0x40]
    18e8:      	strb	w24, [sp, #0x44]
    18ec:      	str	x9, [sp, #0x50]
    18f0:      	ldur	q0, [x20, #0x8]
    18f4:      	stur	q0, [x27, #0x18]
    18f8:      	mov	w8, #0x2                ; =2
    18fc:      	ldr	x9, [sp, #0x238]
    1900:      	madd	x8, x9, x28, x8
    1904:      	ldp	x9, x10, [sp, #0x58]
    1908:      	add	x8, x9, x8
    190c:      	madd	x8, x8, x28, x10
    1910:      	str	x8, [sp, #0x238]
    1914:      	add	x19, x19, #0x1
    1918:      	cmp	x19, x21
    191c:      	b.eq	0x1b04 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x31c>
    1920:      	ldr	x1, [sp, #0x210]
    1924:      	ldr	x8, [sp, #0x228]
    1928:      	ldr	x9, [sp, #0x230]
    192c:      	adds	x9, x8, x9
    1930:      	csinv	x10, x9, xzr, lo
    1934:      	sub	x9, x1, x1, lsr #2
    1938:      	lsr	x11, x1, #14
    193c:      	cmp	x11, #0x0
    1940:      	ccmp	x10, x9, #0x0, eq
    1944:      	b.lo	0x1998 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1b0>
    1948:      	cmp	x8, x9, lsr #1
    194c:      	b.lo	0x196c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x184>
    1950:      	cbz	x1, 0x1968 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x180>
    1954:      	cmp	x1, #0x2, lsl #12       ; =0x2000
    1958:      	mov	w8, #0x2000             ; =8192
    195c:      	csel	x8, x1, x8, lo
    1960:      	lsl	x1, x8, #1
    1964:      	b	0x196c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x184>
    1968:      	mov	w1, #0x1                ; =1
    196c:      	add	x0, x27, #0x1d0
    1970:      	add	x2, x27, #0x1c0
    1974:      	bl	0x1974 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x18c>
		0000000000001974:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    1978:      	mov	x5, #0x11eb             ; =4587
    197c:      	movk	x5, #0x1331, lsl #16
    1980:      	movk	x5, #0x49bb, lsl #32
    1984:      	movk	x5, #0x94d0, lsl #48
    1988:      	mov	x6, #0xe5b9             ; =58809
    198c:      	movk	x6, #0x1ce4, lsl #16
    1990:      	movk	x6, #0x476d, lsl #32
    1994:      	movk	x6, #0xbf58, lsl #48
    1998:      	orr	x8, x24, x19, lsl #1
    199c:      	ldrb	w9, [sp, #0x208]
    19a0:      	tbz	w9, #0x0, 0x1a20 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x238>
    19a4:      	mov	x11, #0x0               ; =0
    19a8:      	ldr	x9, [sp, #0x38]
    19ac:      	add	x9, x19, x9
    19b0:      	ldr	x10, [sp, #0x210]
    19b4:      	cbz	x10, 0x1a4c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x264>
    19b8:      	udiv	x12, x11, x10
    19bc:      	msub	x12, x12, x10, x11
    19c0:      	ldr	x13, [sp, #0x220]
    19c4:      	mov	x14, x10
    19c8:      	mov	x11, x10
    19cc:      	b	0x19ec <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x204>
    19d0:      	cmp	x11, x10
    19d4:      	csel	x11, x12, x11, eq
    19d8:      	add	x15, x12, #0x1
    19dc:      	cmp	x15, x10
    19e0:      	csinc	x12, xzr, x12, hs
    19e4:      	subs	x14, x14, #0x1
    19e8:      	b.eq	0x1a50 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x268>
    19ec:      	madd	x15, x12, x25, x13
    19f0:      	ldr	w16, [x15]
    19f4:      	cmp	w16, #0x1
    19f8:      	b.eq	0x19d0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1e8>
    19fc:      	cmp	w16, #0x2
    1a00:      	b.ne	0x1a9c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x2b4>
    1a04:      	ldr	x16, [x15, #0x8]
    1a08:      	cmp	x16, x8
    1a0c:      	b.ne	0x19d8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1f0>
    1a10:      	ldr	x10, [x15, #0x10]
    1a14:      	str	w26, [x15]
    1a18:      	str	x9, [x15, #0x10]
    1a1c:      	b	0x1ac4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x2dc>
    1a20:      	ldr	x9, [sp, #0x200]
    1a24:      	eor	x9, x9, x8
    1a28:      	eor	x9, x9, x9, lsr #30
    1a2c:      	mul	x9, x9, x6
    1a30:      	eor	x9, x9, x9, lsr #27
    1a34:      	mul	x9, x9, x5
    1a38:      	eor	x11, x9, x9, lsr #31
    1a3c:      	ldr	x9, [sp, #0x38]
    1a40:      	add	x9, x19, x9
    1a44:      	ldr	x10, [sp, #0x210]
    1a48:      	cbnz	x10, 0x19b8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1d0>
    1a4c:      	mov	x11, #0x0               ; =0
    1a50:      	cmp	x11, x10
    1a54:      	b.hs	0x18e4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xfc>
    1a58:      	ldr	x10, [sp, #0x228]
    1a5c:      	lsr	x12, x10, #14
    1a60:      	cbnz	x12, 0x18e4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xfc>
    1a64:      	add	x10, x10, #0x1
    1a68:      	str	x10, [sp, #0x228]
    1a6c:      	ldr	x10, [sp, #0x220]
    1a70:      	madd	x11, x11, x25, x10
    1a74:      	ldr	w12, [x11]
    1a78:      	cmp	w12, #0x1
    1a7c:      	b.ne	0x1ab0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x2c8>
    1a80:      	ldr	x10, [sp, #0x230]
    1a84:      	subs	x10, x10, #0x1
    1a88:      	csel	x10, xzr, x10, lo
    1a8c:      	str	x10, [sp, #0x230]
    1a90:      	str	w26, [x11]
    1a94:      	stp	x8, x9, [x11, #0x8]
    1a98:      	b	0x1ae4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x2fc>
    1a9c:      	cmp	x11, x10
    1aa0:      	csel	x11, x12, x11, eq
    1aa4:      	cmp	x11, x10
    1aa8:      	b.lo	0x1a58 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x270>
    1aac:      	b	0x18e4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xfc>
    1ab0:      	ldp	x13, x10, [x11, #0x8]
    1ab4:      	str	w26, [x11]
    1ab8:      	stp	x8, x9, [x11, #0x8]
    1abc:      	cbz	w12, 0x1ae4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x2fc>
    1ac0:      	mov	x8, x13
    1ac4:      	stp	x24, x8, [sp, #0x40]
    1ac8:      	str	x10, [sp, #0x50]
    1acc:      	ubfx	x9, x24, #32, #8
    1ad0:      	ldur	q0, [x20, #0x8]
    1ad4:      	stur	q0, [x27, #0x18]
    1ad8:      	mov	w8, #0x1                ; =1
    1adc:      	tbnz	w9, #0x0, 0x18f8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x110>
    1ae0:      	b	0x18fc <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x114>
    1ae4:      	stp	xzr, xzr, [sp, #0x40]
    1ae8:      	str	xzr, [sp, #0x50]
    1aec:      	ldr	x8, [sp, #0x238]
    1af0:      	mul	x8, x8, x28
    1af4:      	str	x8, [sp, #0x238]
    1af8:      	add	x19, x19, #0x1
    1afc:      	cmp	x19, x21
    1b00:      	b.ne	0x1920 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x138>
    1b04:      	ldr	x9, [sp, #0x18]
    1b08:      	cbz	x9, 0x20e4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x8fc>
    1b0c:      	lsl	x9, x23, #1
    1b10:      	cmp	x23, #0x0
    1b14:      	csinc	x25, x9, xzr, ne
    1b18:      	cmp	x22, #0x1
    1b1c:      	csel	x24, x21, xzr, eq
    1b20:      	add	x28, sp, #0x40
    1b24:      	cmp	x22, #0x5
    1b28:      	b.ne	0x2188 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x9a0>
    1b2c:      	mov	x19, #0x0               ; =0
    1b30:      	sub	x8, x21, x21, lsr #1
    1b34:      	cmp	x8, #0x1
    1b38:      	csinc	x20, x8, xzr, hi
    1b3c:      	mov	w22, #0x83              ; =131
    1b40:      	mov	w23, #0x1               ; =1
    1b44:      	mov	w24, #0x18              ; =24
    1b48:      	mov	w25, #0x2               ; =2
    1b4c:      	mov	w26, #0x4309            ; =17161
    1b50:      	b	0x1b68 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x380>
    1b54:      	ldr	x19, [sp, #0x30]
    1b58:      	mov	w26, #0x4309            ; =17161
    1b5c:      	ldr	x8, [sp, #0x18]
    1b60:      	cmp	x19, x8
    1b64:      	b.eq	0x20e4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x8fc>
    1b68:      	ldr	x8, [sp, #0x210]
    1b6c:      	cbz	x21, 0x1d4c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x564>
    1b70:      	mov	x9, #0x0                ; =0
    1b74:      	ldr	x10, [sp, #0x200]
    1b78:      	ldrb	w11, [sp, #0x208]
    1b7c:      	ldr	x12, [sp, #0x228]
    1b80:      	ldr	x13, [sp, #0x220]
    1b84:      	ldr	x14, [sp, #0x230]
    1b88:      	b	0x1bac <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x3c4>
    1b8c:      	str	w23, [sp, #0x90]
    1b90:      	str	xzr, [sp, #0x98]
    1b94:      	mul	x15, x15, x22
    1b98:      	strb	wzr, [sp, #0xa0]
    1b9c:      	str	x15, [sp, #0x238]
    1ba0:      	add	x9, x9, #0x1
    1ba4:      	cmp	x9, x20
    1ba8:      	b.eq	0x1d50 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x568>
    1bac:      	orr	x15, x23, x9, lsl #2
    1bb0:      	str	x15, [sp, #0x258]
    1bb4:      	cbz	x12, 0x1ca8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x4c0>
    1bb8:      	tbz	w11, #0x0, 0x1bc8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x3e0>
    1bbc:      	mov	x16, #0x0               ; =0
    1bc0:      	cbnz	x8, 0x1be4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x3fc>
    1bc4:      	b	0x1ca8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x4c0>
    1bc8:      	eor	x16, x10, x15
    1bcc:      	eor	x16, x16, x16, lsr #30
    1bd0:      	mul	x16, x16, x6
    1bd4:      	eor	x16, x16, x16, lsr #27
    1bd8:      	mul	x16, x16, x5
    1bdc:      	eor	x16, x16, x16, lsr #31
    1be0:      	cbz	x8, 0x1ca8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x4c0>
    1be4:      	udiv	x17, x16, x8
    1be8:      	msub	x16, x17, x8, x16
    1bec:      	mov	x17, x8
    1bf0:      	b	0x1c08 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x420>
    1bf4:      	add	x0, x16, #0x1
    1bf8:      	cmp	x0, x8
    1bfc:      	csinc	x16, xzr, x16, hs
    1c00:      	subs	x17, x17, #0x1
    1c04:      	b.eq	0x1ca8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x4c0>
    1c08:      	madd	x0, x16, x24, x13
    1c0c:      	ldr	w1, [x0]
    1c10:      	cmp	w1, #0x1
    1c14:      	b.eq	0x1bf4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x40c>
    1c18:      	cmp	w1, #0x2
    1c1c:      	b.ne	0x1ca8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x4c0>
    1c20:      	ldr	x1, [x0, #0x8]
    1c24:      	cmp	x1, x15
    1c28:      	b.ne	0x1bf4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x40c>
    1c2c:      	ldr	x16, [x0, #0x10]
    1c30:      	str	w23, [x0]
    1c34:      	sub	x12, x12, #0x1
    1c38:      	stp	xzr, xzr, [x0, #0x8]
    1c3c:      	adds	x14, x14, #0x1
    1c40:      	csinv	x14, x14, xzr, lo
    1c44:      	str	x12, [sp, #0x228]
    1c48:      	str	x14, [sp, #0x230]
    1c4c:      	str	w23, [sp, #0x68]
    1c50:      	stp	x15, x16, [sp, #0x70]
    1c54:      	ldur	q0, [x28, #0x30]
    1c58:      	stur	q0, [x27, #0x40]
    1c5c:      	ldr	x15, [sp, #0x238]
    1c60:      	ldp	x16, x17, [sp, #0x80]
    1c64:      	madd	x15, x15, x22, x16
    1c68:      	madd	x15, x15, x22, x17
    1c6c:      	add	x15, x15, #0x83
    1c70:      	str	x15, [sp, #0x238]
    1c74:      	ldrb	w16, [sp, #0x208]
    1c78:      	tbnz	w16, #0x0, 0x1cc4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x4dc>
    1c7c:      	ldr	x16, [sp, #0x200]
    1c80:      	ldr	x17, [sp, #0x258]
    1c84:      	eor	x16, x17, x16
    1c88:      	eor	x16, x16, x16, lsr #30
    1c8c:      	mul	x16, x16, x6
    1c90:      	eor	x16, x16, x16, lsr #27
    1c94:      	mul	x16, x16, x5
    1c98:      	eor	x16, x16, x16, lsr #31
    1c9c:      	ldr	x1, [sp, #0x210]
    1ca0:      	cbnz	x1, 0x1cd0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x4e8>
    1ca4:      	b	0x1b8c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x3a4>
    1ca8:      	str	wzr, [sp, #0x68]
    1cac:      	stp	xzr, xzr, [x28, #0x30]
    1cb0:      	ldr	x15, [sp, #0x238]
    1cb4:      	mul	x15, x15, x22
    1cb8:      	str	x15, [sp, #0x238]
    1cbc:      	ldrb	w16, [sp, #0x208]
    1cc0:      	tbz	w16, #0x0, 0x1c7c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x494>
    1cc4:      	mov	x16, #0x0               ; =0
    1cc8:      	ldr	x1, [sp, #0x210]
    1ccc:      	cbz	x1, 0x1b8c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x3a4>
    1cd0:      	udiv	x17, x16, x1
    1cd4:      	msub	x16, x17, x1, x16
    1cd8:      	ldr	x17, [sp, #0x220]
    1cdc:      	ldr	x0, [sp, #0x258]
    1ce0:      	mov	x2, x1
    1ce4:      	b	0x1cfc <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x514>
    1ce8:      	add	x3, x16, #0x1
    1cec:      	cmp	x3, x1
    1cf0:      	csinc	x16, xzr, x16, hs
    1cf4:      	subs	x2, x2, #0x1
    1cf8:      	b.eq	0x1b8c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x3a4>
    1cfc:      	madd	x3, x16, x24, x17
    1d00:      	ldr	w4, [x3]
    1d04:      	cmp	w4, #0x1
    1d08:      	b.eq	0x1ce8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x500>
    1d0c:      	cmp	w4, #0x2
    1d10:      	b.ne	0x1b8c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x3a4>
    1d14:      	ldr	x4, [x3, #0x8]
    1d18:      	cmp	x4, x0
    1d1c:      	b.ne	0x1ce8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x500>
    1d20:      	ldr	x16, [x3, #0x10]
    1d24:      	str	wzr, [sp, #0x90]
    1d28:      	str	x16, [sp, #0x98]
    1d2c:      	strb	wzr, [sp, #0xa0]
    1d30:      	madd	x15, x15, x26, x16
    1d34:      	add	x15, x15, #0x83
    1d38:      	str	x15, [sp, #0x238]
    1d3c:      	add	x9, x9, #0x1
    1d40:      	cmp	x9, x20
    1d44:      	b.ne	0x1bac <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x3c4>
    1d48:      	b	0x1d50 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x568>
    1d4c:      	mov	x1, x8
    1d50:      	add	x0, x27, #0x1d0
    1d54:      	add	x2, x27, #0x1c0
    1d58:      	bl	0x1d58 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x570>
		0000000000001d58:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    1d5c:      	str	w0, [sp, #0xa8]
    1d60:      	strb	w1, [sp, #0xac]
    1d64:      	strb	w2, [sp, #0xad]
    1d68:      	cmp	w0, #0x0
    1d6c:      	ldr	x8, [sp, #0x238]
    1d70:      	mul	x8, x8, x22
    1d74:      	cinc	x8, x8, eq
    1d78:      	str	x8, [sp, #0x238]
    1d7c:      	cbz	x21, 0x20b4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x8cc>
    1d80:      	mov	x9, #0x0                ; =0
    1d84:      	ldr	x10, [sp, #0x200]
    1d88:      	ldrb	w11, [sp, #0x208]
    1d8c:      	ldr	x12, [sp, #0x210]
    1d90:      	ldr	x13, [sp, #0x220]
    1d94:      	mov	x5, #0x11eb             ; =4587
    1d98:      	movk	x5, #0x1331, lsl #16
    1d9c:      	movk	x5, #0x49bb, lsl #32
    1da0:      	movk	x5, #0x94d0, lsl #48
    1da4:      	mov	x6, #0xe5b9             ; =58809
    1da8:      	movk	x6, #0x1ce4, lsl #16
    1dac:      	movk	x6, #0x476d, lsl #32
    1db0:      	movk	x6, #0xbf58, lsl #48
    1db4:      	b	0x1dd8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x5f0>
    1db8:      	str	w23, [sp, #0xb0]
    1dbc:      	str	xzr, [sp, #0xb8]
    1dc0:      	mul	x8, x8, x22
    1dc4:      	strb	wzr, [sp, #0xc0]
    1dc8:      	str	x8, [sp, #0x238]
    1dcc:      	add	x9, x9, #0x1
    1dd0:      	cmp	x9, x21
    1dd4:      	b.eq	0x1e7c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x694>
    1dd8:      	orr	x14, x23, x9, lsl #1
    1ddc:      	str	x14, [sp, #0x260]
    1de0:      	tbz	w11, #0x0, 0x1df0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x608>
    1de4:      	mov	x15, #0x0               ; =0
    1de8:      	cbnz	x12, 0x1e0c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x624>
    1dec:      	b	0x1db8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x5d0>
    1df0:      	eor	x15, x10, x14
    1df4:      	eor	x15, x15, x15, lsr #30
    1df8:      	mul	x15, x15, x6
    1dfc:      	eor	x15, x15, x15, lsr #27
    1e00:      	mul	x15, x15, x5
    1e04:      	eor	x15, x15, x15, lsr #31
    1e08:      	cbz	x12, 0x1db8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x5d0>
    1e0c:      	udiv	x16, x15, x12
    1e10:      	msub	x15, x16, x12, x15
    1e14:      	mov	x16, x12
    1e18:      	b	0x1e30 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x648>
    1e1c:      	add	x17, x15, #0x1
    1e20:      	cmp	x17, x12
    1e24:      	csinc	x15, xzr, x15, hs
    1e28:      	subs	x16, x16, #0x1
    1e2c:      	b.eq	0x1db8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x5d0>
    1e30:      	madd	x17, x15, x24, x13
    1e34:      	ldr	w0, [x17]
    1e38:      	cmp	w0, #0x1
    1e3c:      	b.eq	0x1e1c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x634>
    1e40:      	cmp	w0, #0x2
    1e44:      	b.ne	0x1db8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x5d0>
    1e48:      	ldr	x0, [x17, #0x8]
    1e4c:      	cmp	x0, x14
    1e50:      	b.ne	0x1e1c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x634>
    1e54:      	ldr	x14, [x17, #0x10]
    1e58:      	str	wzr, [sp, #0xb0]
    1e5c:      	str	x14, [sp, #0xb8]
    1e60:      	strb	wzr, [sp, #0xc0]
    1e64:      	madd	x8, x8, x26, x14
    1e68:      	add	x8, x8, #0x83
    1e6c:      	str	x8, [sp, #0x238]
    1e70:      	add	x9, x9, #0x1
    1e74:      	cmp	x9, x21
    1e78:      	b.ne	0x1dd8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x5f0>
    1e7c:      	mov	x26, #0x0               ; =0
    1e80:      	add	x19, x19, #0x1
    1e84:      	ldr	x8, [sp, #0x38]
    1e88:      	str	x19, [sp, #0x30]
    1e8c:      	madd	x19, x19, x21, x8
    1e90:      	b	0x1ed0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x6e8>
    1e94:      	stp	x23, x8, [sp, #0xc8]
    1e98:      	strb	w23, [sp, #0xcc]
    1e9c:      	str	x9, [sp, #0xd8]
    1ea0:      	ldur	q0, [x28, #0x90]
    1ea4:      	stur	q0, [x27, #0xa0]
    1ea8:      	mov	w8, #0x2                ; =2
    1eac:      	ldr	x9, [sp, #0x238]
    1eb0:      	madd	x8, x9, x22, x8
    1eb4:      	ldp	x9, x10, [sp, #0xe0]
    1eb8:      	add	x8, x9, x8
    1ebc:      	madd	x8, x8, x22, x10
    1ec0:      	str	x8, [sp, #0x238]
    1ec4:      	add	x26, x26, #0x1
    1ec8:      	cmp	x26, x20
    1ecc:      	b.eq	0x1b54 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x36c>
    1ed0:      	ldr	x1, [sp, #0x210]
    1ed4:      	ldr	x8, [sp, #0x228]
    1ed8:      	ldr	x9, [sp, #0x230]
    1edc:      	adds	x9, x8, x9
    1ee0:      	csinv	x10, x9, xzr, lo
    1ee4:      	sub	x9, x1, x1, lsr #2
    1ee8:      	lsr	x11, x1, #14
    1eec:      	cmp	x11, #0x0
    1ef0:      	ccmp	x10, x9, #0x0, eq
    1ef4:      	b.lo	0x1f48 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x760>
    1ef8:      	cmp	x8, x9, lsr #1
    1efc:      	b.lo	0x1f1c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x734>
    1f00:      	cbz	x1, 0x1f18 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x730>
    1f04:      	cmp	x1, #0x2, lsl #12       ; =0x2000
    1f08:      	mov	w8, #0x2000             ; =8192
    1f0c:      	csel	x8, x1, x8, lo
    1f10:      	lsl	x1, x8, #1
    1f14:      	b	0x1f1c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x734>
    1f18:      	mov	w1, #0x1                ; =1
    1f1c:      	add	x0, x27, #0x1d0
    1f20:      	add	x2, x27, #0x1c0
    1f24:      	bl	0x1f24 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x73c>
		0000000000001f24:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    1f28:      	mov	x5, #0x11eb             ; =4587
    1f2c:      	movk	x5, #0x1331, lsl #16
    1f30:      	movk	x5, #0x49bb, lsl #32
    1f34:      	movk	x5, #0x94d0, lsl #48
    1f38:      	mov	x6, #0xe5b9             ; =58809
    1f3c:      	movk	x6, #0x1ce4, lsl #16
    1f40:      	movk	x6, #0x476d, lsl #32
    1f44:      	movk	x6, #0xbf58, lsl #48
    1f48:      	orr	x8, x23, x26, lsl #2
    1f4c:      	ldrb	w9, [sp, #0x208]
    1f50:      	tbz	w9, #0x0, 0x1fcc <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x7e4>
    1f54:      	mov	x11, #0x0               ; =0
    1f58:      	add	x9, x19, x26, lsl #1
    1f5c:      	ldr	x10, [sp, #0x210]
    1f60:      	cbz	x10, 0x1ff4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x80c>
    1f64:      	udiv	x12, x11, x10
    1f68:      	msub	x12, x12, x10, x11
    1f6c:      	ldr	x13, [sp, #0x220]
    1f70:      	mov	x14, x10
    1f74:      	mov	x11, x10
    1f78:      	b	0x1f98 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x7b0>
    1f7c:      	cmp	x11, x10
    1f80:      	csel	x11, x12, x11, eq
    1f84:      	add	x15, x12, #0x1
    1f88:      	cmp	x15, x10
    1f8c:      	csinc	x12, xzr, x12, hs
    1f90:      	subs	x14, x14, #0x1
    1f94:      	b.eq	0x1ff8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x810>
    1f98:      	madd	x15, x12, x24, x13
    1f9c:      	ldr	w16, [x15]
    1fa0:      	cmp	w16, #0x1
    1fa4:      	b.eq	0x1f7c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x794>
    1fa8:      	cmp	w16, #0x2
    1fac:      	b.ne	0x2044 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x85c>
    1fb0:      	ldr	x16, [x15, #0x8]
    1fb4:      	cmp	x16, x8
    1fb8:      	b.ne	0x1f84 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x79c>
    1fbc:      	ldr	x10, [x15, #0x10]
    1fc0:      	str	w25, [x15]
    1fc4:      	str	x9, [x15, #0x10]
    1fc8:      	b	0x206c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x884>
    1fcc:      	ldr	x9, [sp, #0x200]
    1fd0:      	eor	x9, x9, x8
    1fd4:      	eor	x9, x9, x9, lsr #30
    1fd8:      	mul	x9, x9, x6
    1fdc:      	eor	x9, x9, x9, lsr #27
    1fe0:      	mul	x9, x9, x5
    1fe4:      	eor	x11, x9, x9, lsr #31
    1fe8:      	add	x9, x19, x26, lsl #1
    1fec:      	ldr	x10, [sp, #0x210]
    1ff0:      	cbnz	x10, 0x1f64 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x77c>
    1ff4:      	mov	x11, #0x0               ; =0
    1ff8:      	cmp	x11, x10
    1ffc:      	b.hs	0x1e94 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x6ac>
    2000:      	ldr	x10, [sp, #0x228]
    2004:      	cmp	x10, #0x4, lsl #12      ; =0x4000
    2008:      	b.hs	0x1e94 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x6ac>
    200c:      	add	x10, x10, #0x1
    2010:      	str	x10, [sp, #0x228]
    2014:      	ldr	x10, [sp, #0x220]
    2018:      	madd	x11, x11, x24, x10
    201c:      	ldr	w12, [x11]
    2020:      	cmp	w12, #0x1
    2024:      	b.ne	0x2058 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x870>
    2028:      	ldr	x10, [sp, #0x230]
    202c:      	subs	x10, x10, #0x1
    2030:      	csel	x10, xzr, x10, lo
    2034:      	str	x10, [sp, #0x230]
    2038:      	str	w25, [x11]
    203c:      	stp	x8, x9, [x11, #0x8]
    2040:      	b	0x2090 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x8a8>
    2044:      	cmp	x11, x10
    2048:      	csel	x11, x12, x11, eq
    204c:      	cmp	x11, x10
    2050:      	b.lo	0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x818>
    2054:      	b	0x1e94 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x6ac>
    2058:      	ldp	x13, x10, [x11, #0x8]
    205c:      	str	w25, [x11]
    2060:      	stp	x8, x9, [x11, #0x8]
    2064:      	cbz	w12, 0x2090 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x8a8>
    2068:      	mov	x8, x13
    206c:      	stp	x23, x8, [sp, #0xc8]
    2070:      	str	x10, [sp, #0xd8]
    2074:      	ubfx	x9, x23, #32, #8
    2078:      	ldur	q0, [x28, #0x90]
    207c:      	stur	q0, [x27, #0xa0]
    2080:      	mov	w8, #0x1                ; =1
    2084:      	cmp	w9, #0x1
    2088:      	b.eq	0x1ea8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x6c0>
    208c:      	b	0x1eac <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x6c4>
    2090:      	stp	xzr, xzr, [x27, #0x88]
    2094:      	stur	xzr, [x27, #0x98]
    2098:      	ldr	x8, [sp, #0x238]
    209c:      	mul	x8, x8, x22
    20a0:      	str	x8, [sp, #0x238]
    20a4:      	add	x26, x26, #0x1
    20a8:      	cmp	x26, x20
    20ac:      	b.ne	0x1ed0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x6e8>
    20b0:      	b	0x1b54 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x36c>
    20b4:      	add	x19, x19, #0x1
    20b8:      	mov	x5, #0x11eb             ; =4587
    20bc:      	movk	x5, #0x1331, lsl #16
    20c0:      	movk	x5, #0x49bb, lsl #32
    20c4:      	movk	x5, #0x94d0, lsl #48
    20c8:      	mov	x6, #0xe5b9             ; =58809
    20cc:      	movk	x6, #0x1ce4, lsl #16
    20d0:      	movk	x6, #0x476d, lsl #32
    20d4:      	movk	x6, #0xbf58, lsl #48
    20d8:      	ldr	x8, [sp, #0x18]
    20dc:      	cmp	x19, x8
    20e0:      	b.ne	0x1b68 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x380>
    20e4:      	add	x8, sp, #0x40
    20e8:      	add	x8, x8, #0x178
    20ec:      	ldp	q0, q1, [x27, #0x1d0]
    20f0:      	stp	q0, q1, [x8]
    20f4:      	ldr	x8, [x27, #0x1f0]
    20f8:      	str	x8, [sp, #0x1d8]
    20fc:      	ldp	x13, x8, [sp, #0x1b8]
    2100:      	ldr	x0, [sp, #0x1c8]
    2104:      	cbz	x13, 0x2a68 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1280>
    2108:      	ldr	x9, [sp, #0x240]
    210c:      	ldr	x11, [sp, #0x248]
    2110:      	ldr	x10, [sp, #0x250]
    2114:      	ands	x14, x13, #0x3
    2118:      	b.eq	0x2a5c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1274>
    211c:      	mov	w12, #0x18              ; =24
    2120:      	madd	x12, x13, x12, x0
    2124:      	sub	x15, x12, #0x8
    2128:      	mov	w16, #0x83              ; =131
    212c:      	mov	x12, x13
    2130:      	b	0x2144 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x95c>
    2134:      	sub	x15, x15, #0x18
    2138:      	sub	x12, x12, #0x1
    213c:      	sub	x14, x14, #0x1
    2140:      	cbz	x14, 0x2a60 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1278>
    2144:      	ldur	w17, [x15, #-0x10]
    2148:      	cmp	w17, #0x2
    214c:      	b.ne	0x2134 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x94c>
    2150:      	ldp	x1, x17, [x15, #-0x8]
    2154:      	madd	x17, x1, x16, x17
    2158:      	add	x9, x17, x9
    215c:      	str	x9, [sp, #0x240]
    2160:      	eor	x17, x17, x17, lsr #30
    2164:      	mul	x17, x17, x6
    2168:      	eor	x17, x17, x17, lsr #27
    216c:      	mul	x17, x17, x5
    2170:      	eor	x11, x11, x17, lsr #31
    2174:      	eor	x11, x11, x17
    2178:      	str	x11, [sp, #0x248]
    217c:      	add	x10, x10, #0x1
    2180:      	str	x10, [sp, #0x250]
    2184:      	b	0x2134 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x94c>
    2188:      	mov	x3, #0x0                ; =0
    218c:      	sub	x4, x22, #0x9
    2190:      	mov	w19, #0x83              ; =131
    2194:      	mov	w20, #0x1               ; =1
    2198:      	mov	w23, #0x18              ; =24
    219c:      	str	x4, [sp, #0x20]
    21a0:      	str	x25, [sp, #0x10]
    21a4:      	b	0x21b4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x9cc>
    21a8:      	ldp	x25, x9, [sp, #0x10]
    21ac:      	cmp	x3, x9
    21b0:      	b.eq	0x20e4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x8fc>
    21b4:      	cmp	x22, #0x4
    21b8:      	b.eq	0x21d8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x9f0>
    21bc:      	cmp	x22, #0x9
    21c0:      	b.eq	0x21d8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x9f0>
    21c4:      	cmp	x22, #0xa
    21c8:      	b.ne	0x2284 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xa9c>
    21cc:      	mov	x9, #0x1                ; =1
    21d0:      	madd	x8, x8, x19, x9
    21d4:      	b	0x2270 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xa88>
    21d8:      	cmp	x25, #0x4, lsl #12      ; =0x4000
    21dc:      	b.ls	0x21f0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xa08>
    21e0:      	mov	w2, #0x0                ; =0
    21e4:      	mov	w1, #0x0                ; =0
    21e8:      	mov	w0, #0x1                ; =1
    21ec:      	b	0x224c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xa64>
    21f0:      	ldr	x9, [sp, #0x210]
    21f4:      	cmp	x25, x9
    21f8:      	b.ls	0x2240 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xa58>
    21fc:      	add	x0, x27, #0x1d0
    2200:      	add	x2, x27, #0x1c0
    2204:      	mov	x1, x25
    2208:      	mov	x26, x3
    220c:      	bl	0x220c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xa24>
		000000000000220c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    2210:      	ldr	x4, [sp, #0x20]
    2214:      	mov	x3, x26
    2218:      	mov	x6, #0xe5b9             ; =58809
    221c:      	movk	x6, #0x1ce4, lsl #16
    2220:      	movk	x6, #0x476d, lsl #32
    2224:      	movk	x6, #0xbf58, lsl #48
    2228:      	mov	x5, #0x11eb             ; =4587
    222c:      	movk	x5, #0x1331, lsl #16
    2230:      	movk	x5, #0x49bb, lsl #32
    2234:      	movk	x5, #0x94d0, lsl #48
    2238:      	ldr	x8, [sp, #0x238]
    223c:      	b	0x224c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xa64>
    2240:      	mov	w2, #0x0                ; =0
    2244:      	mov	w1, #0x0                ; =0
    2248:      	mov	w0, #0x0                ; =0
    224c:      	str	w0, [sp, #0xf0]
    2250:      	strb	w1, [sp, #0xf4]
    2254:      	strb	w2, [sp, #0xf5]
    2258:      	cmp	w0, #0x0
    225c:      	mul	x8, x8, x19
    2260:      	cinc	x8, x8, eq
    2264:      	str	x8, [sp, #0x238]
    2268:      	cmp	x4, #0x2
    226c:      	b.hs	0x2284 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xa9c>
    2270:      	ldr	x9, [sp, #0x210]
    2274:      	cmp	x9, x25
    2278:      	mul	x8, x8, x19
    227c:      	cinc	x8, x8, hs
    2280:      	str	x8, [sp, #0x238]
    2284:      	add	x3, x3, #0x1
    2288:      	cbz	x21, 0x21a8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x9c0>
    228c:      	mov	x25, #0x0               ; =0
    2290:      	ldr	x9, [sp, #0x38]
    2294:      	madd	x0, x3, x21, x9
    2298:      	stp	x0, x3, [sp, #0x28]
    229c:      	b	0x22c0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xad8>
    22a0:      	str	w20, [sp, #0xf8]
    22a4:      	str	xzr, [sp, #0x100]
    22a8:      	mul	x8, x8, x19
    22ac:      	strb	wzr, [sp, #0x108]
    22b0:      	str	x8, [sp, #0x238]
    22b4:      	add	x25, x25, #0x1
    22b8:      	cmp	x25, x21
    22bc:      	b.eq	0x21a8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x9c0>
    22c0:      	add	x9, x25, x24
    22c4:      	orr	x26, x20, x9, lsl #1
    22c8:      	str	x26, [sp, #0x268]
    22cc:      	cmp	x22, #0x3
    22d0:      	b.gt	0x230c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xb24>
    22d4:      	cmp	x22, #0x2
    22d8:      	b.lo	0x2324 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xb3c>
    22dc:      	b.eq	0x23cc <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xbe4>
    22e0:      	cmp	x22, #0x3
    22e4:      	b.ne	0x22b4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xacc>
    22e8:      	ldr	x11, [sp, #0x200]
    22ec:      	ldrb	w12, [sp, #0x208]
    22f0:      	ldr	x9, [sp, #0x228]
    22f4:      	cbz	x9, 0x25c4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xddc>
    22f8:      	tbz	w12, #0x0, 0x24e8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xd00>
    22fc:      	mov	x13, #0x0               ; =0
    2300:      	ldr	x10, [sp, #0x210]
    2304:      	cbnz	x10, 0x2508 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xd20>
    2308:      	b	0x25c4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xddc>
    230c:      	cmp	x4, #0x2
    2310:      	b.lo	0x2324 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xb3c>
    2314:      	cmp	x22, #0x7
    2318:      	b.eq	0x2414 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xc2c>
    231c:      	cmp	x22, #0x4
    2320:      	b.ne	0x22b4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xacc>
    2324:      	ldrb	w9, [sp, #0x208]
    2328:      	tbz	w9, #0x0, 0x233c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xb54>
    232c:      	mov	x10, #0x0               ; =0
    2330:      	ldr	x9, [sp, #0x210]
    2334:      	cbnz	x9, 0x2360 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xb78>
    2338:      	b	0x22a0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xab8>
    233c:      	ldr	x9, [sp, #0x200]
    2340:      	eor	x9, x9, x26
    2344:      	eor	x9, x9, x9, lsr #30
    2348:      	mul	x9, x9, x6
    234c:      	eor	x9, x9, x9, lsr #27
    2350:      	mul	x9, x9, x5
    2354:      	eor	x10, x9, x9, lsr #31
    2358:      	ldr	x9, [sp, #0x210]
    235c:      	cbz	x9, 0x22a0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xab8>
    2360:      	udiv	x11, x10, x9
    2364:      	msub	x10, x11, x9, x10
    2368:      	ldr	x11, [sp, #0x220]
    236c:      	mov	x12, x9
    2370:      	b	0x2388 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xba0>
    2374:      	add	x13, x10, #0x1
    2378:      	cmp	x13, x9
    237c:      	csinc	x10, xzr, x10, hs
    2380:      	subs	x12, x12, #0x1
    2384:      	b.eq	0x22a0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xab8>
    2388:      	madd	x13, x10, x23, x11
    238c:      	ldr	w14, [x13]
    2390:      	cmp	w14, #0x1
    2394:      	b.eq	0x2374 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xb8c>
    2398:      	cmp	w14, #0x2
    239c:      	b.ne	0x22a0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xab8>
    23a0:      	ldr	x14, [x13, #0x8]
    23a4:      	cmp	x14, x26
    23a8:      	b.ne	0x2374 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xb8c>
    23ac:      	ldr	x9, [x13, #0x10]
    23b0:      	str	wzr, [sp, #0xf8]
    23b4:      	str	x9, [sp, #0x100]
    23b8:      	strb	wzr, [sp, #0x108]
    23bc:      	mov	w10, #0x4309            ; =17161
    23c0:      	madd	x8, x8, x10, x9
    23c4:      	add	x8, x8, #0x83
    23c8:      	b	0x22b0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xac8>
    23cc:      	ldr	x1, [sp, #0x210]
    23d0:      	ldr	x8, [sp, #0x228]
    23d4:      	ldr	x9, [sp, #0x230]
    23d8:      	adds	x9, x8, x9
    23dc:      	csinv	x9, x9, xzr, lo
    23e0:      	lsr	x10, x1, #14
    23e4:      	cbnz	x10, 0x28d0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x10e8>
    23e8:      	sub	x10, x1, x1, lsr #2
    23ec:      	cmp	x9, x10
    23f0:      	b.lo	0x28d0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x10e8>
    23f4:      	cmp	x8, x10, lsr #1
    23f8:      	b.lo	0x289c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x10b4>
    23fc:      	cbz	x1, 0x2898 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x10b0>
    2400:      	cmp	x1, #0x2, lsl #12       ; =0x2000
    2404:      	mov	w8, #0x2000             ; =8192
    2408:      	csel	x8, x1, x8, lo
    240c:      	lsl	x1, x8, #1
    2410:      	b	0x289c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x10b4>
    2414:      	ldrb	w9, [sp, #0x208]
    2418:      	tbz	w9, #0x0, 0x242c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xc44>
    241c:      	mov	x11, #0x0               ; =0
    2420:      	ldr	x9, [sp, #0x210]
    2424:      	cbnz	x9, 0x2450 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xc68>
    2428:      	b	0x24d4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xcec>
    242c:      	ldr	x9, [sp, #0x200]
    2430:      	eor	x9, x9, x26
    2434:      	eor	x9, x9, x9, lsr #30
    2438:      	mul	x9, x9, x6
    243c:      	eor	x9, x9, x9, lsr #27
    2440:      	mul	x9, x9, x5
    2444:      	eor	x11, x9, x9, lsr #31
    2448:      	ldr	x9, [sp, #0x210]
    244c:      	cbz	x9, 0x24d4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xcec>
    2450:      	mov	x10, #0x0               ; =0
    2454:      	udiv	x12, x11, x9
    2458:      	msub	x11, x12, x9, x11
    245c:      	sub	x12, x9, x11
    2460:      	neg	x13, x12
    2464:      	ldr	x14, [sp, #0x220]
    2468:      	b	0x2478 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xc90>
    246c:      	add	x10, x10, #0x1
    2470:      	cmp	x9, x10
    2474:      	b.eq	0x24d4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xcec>
    2478:      	cmp	x10, x12
    247c:      	csel	x15, x11, x13, lo
    2480:      	add	x15, x15, x10
    2484:      	madd	x15, x15, x23, x14
    2488:      	ldr	w16, [x15]
    248c:      	cmp	w16, #0x1
    2490:      	b.eq	0x246c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xc84>
    2494:      	cmp	w16, #0x2
    2498:      	b.ne	0x24d4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xcec>
    249c:      	ldr	x16, [x15, #0x8]
    24a0:      	cmp	x16, x26
    24a4:      	b.ne	0x246c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xc84>
    24a8:      	ldr	x8, [x15, #0x10]
    24ac:      	add	x9, x8, #0x1
    24b0:      	str	x9, [x15, #0x10]
    24b4:      	str	wzr, [sp, #0x1a0]
    24b8:      	str	x9, [sp, #0x1a8]
    24bc:      	strb	wzr, [sp, #0x1b0]
    24c0:      	ldr	x9, [sp, #0x238]
    24c4:      	mov	w10, #0x4309            ; =17161
    24c8:      	madd	x8, x9, x10, x8
    24cc:      	add	x8, x8, #0x84
    24d0:      	b	0x22b0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xac8>
    24d4:      	str	w20, [sp, #0x1a0]
    24d8:      	str	xzr, [sp, #0x1a8]
    24dc:      	mul	x8, x8, x19
    24e0:      	strb	wzr, [sp, #0x1b0]
    24e4:      	b	0x22b0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xac8>
    24e8:      	eor	x10, x11, x26
    24ec:      	eor	x10, x10, x10, lsr #30
    24f0:      	mul	x10, x10, x6
    24f4:      	eor	x10, x10, x10, lsr #27
    24f8:      	mul	x10, x10, x5
    24fc:      	eor	x13, x10, x10, lsr #31
    2500:      	ldr	x10, [sp, #0x210]
    2504:      	cbz	x10, 0x25c4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xddc>
    2508:      	udiv	x14, x13, x10
    250c:      	msub	x13, x14, x10, x13
    2510:      	ldr	x14, [sp, #0x220]
    2514:      	mov	x15, x10
    2518:      	b	0x2530 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xd48>
    251c:      	add	x16, x13, #0x1
    2520:      	cmp	x16, x10
    2524:      	csinc	x13, xzr, x13, hs
    2528:      	subs	x15, x15, #0x1
    252c:      	b.eq	0x25c4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xddc>
    2530:      	madd	x16, x13, x23, x14
    2534:      	ldr	w17, [x16]
    2538:      	cmp	w17, #0x1
    253c:      	b.eq	0x251c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xd34>
    2540:      	cmp	w17, #0x2
    2544:      	b.ne	0x25c4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xddc>
    2548:      	ldr	x17, [x16, #0x8]
    254c:      	cmp	x17, x26
    2550:      	b.ne	0x251c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xd34>
    2554:      	ldr	x10, [x16, #0x10]
    2558:      	mov	w8, #0x1                ; =1
    255c:      	str	w8, [x16]
    2560:      	sub	x9, x9, #0x1
    2564:      	stp	xzr, xzr, [x16, #0x8]
    2568:      	ldr	x11, [sp, #0x230]
    256c:      	ldr	x12, [sp, #0x238]
    2570:      	adds	x11, x11, #0x1
    2574:      	csinv	x11, x11, xzr, lo
    2578:      	str	x9, [sp, #0x228]
    257c:      	str	x11, [sp, #0x230]
    2580:      	str	w8, [sp, #0x138]
    2584:      	stp	x26, x10, [sp, #0x140]
    2588:      	ldr	q0, [x28, #0x100]
    258c:      	str	q0, [x27, #0x110]
    2590:      	ldp	x10, x11, [sp, #0x150]
    2594:      	madd	x10, x12, x19, x10
    2598:      	madd	x10, x10, x19, x11
    259c:      	add	x10, x10, #0x83
    25a0:      	ldr	x11, [sp, #0x200]
    25a4:      	ldrb	w12, [sp, #0x208]
    25a8:      	ldr	x26, [sp, #0x268]
    25ac:      	str	x10, [sp, #0x238]
    25b0:      	tbz	w12, #0x0, 0x25ec <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xe04>
    25b4:      	mov	x12, #0x0               ; =0
    25b8:      	ldr	x11, [sp, #0x210]
    25bc:      	cbnz	x11, 0x2610 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xe28>
    25c0:      	b	0x2694 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xeac>
    25c4:      	str	wzr, [sp, #0x138]
    25c8:      	mul	x10, x8, x19
    25cc:      	stp	xzr, xzr, [x28, #0x100]
    25d0:      	str	x10, [sp, #0x238]
    25d4:      	tbz	w12, #0x0, 0x25ec <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xe04>
    25d8:      	mov	x12, #0x0               ; =0
    25dc:      	mov	w8, #0x1                ; =1
    25e0:      	ldr	x11, [sp, #0x210]
    25e4:      	cbnz	x11, 0x2610 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xe28>
    25e8:      	b	0x2694 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xeac>
    25ec:      	mov	w8, #0x0                ; =0
    25f0:      	eor	x11, x26, x11
    25f4:      	eor	x11, x11, x11, lsr #30
    25f8:      	mul	x11, x11, x6
    25fc:      	eor	x11, x11, x11, lsr #27
    2600:      	mul	x11, x11, x5
    2604:      	eor	x12, x11, x11, lsr #31
    2608:      	ldr	x11, [sp, #0x210]
    260c:      	cbz	x11, 0x2694 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xeac>
    2610:      	udiv	x13, x12, x11
    2614:      	msub	x12, x13, x11, x12
    2618:      	ldr	x13, [sp, #0x220]
    261c:      	mov	x14, x11
    2620:      	b	0x2638 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xe50>
    2624:      	add	x15, x12, #0x1
    2628:      	cmp	x15, x11
    262c:      	csinc	x12, xzr, x12, hs
    2630:      	subs	x14, x14, #0x1
    2634:      	b.eq	0x2694 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xeac>
    2638:      	madd	x15, x12, x23, x13
    263c:      	ldr	w16, [x15]
    2640:      	cmp	w16, #0x1
    2644:      	b.eq	0x2624 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xe3c>
    2648:      	cmp	w16, #0x2
    264c:      	b.ne	0x2694 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xeac>
    2650:      	ldr	x16, [x15, #0x8]
    2654:      	cmp	x16, x26
    2658:      	b.ne	0x2624 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xe3c>
    265c:      	ldr	x12, [x15, #0x10]
    2660:      	str	wzr, [sp, #0x160]
    2664:      	str	x12, [sp, #0x168]
    2668:      	strb	wzr, [sp, #0x170]
    266c:      	mov	w13, #0x4309            ; =17161
    2670:      	madd	x10, x10, x13, x12
    2674:      	add	x10, x10, #0x83
    2678:      	str	x10, [sp, #0x238]
    267c:      	ldr	x10, [sp, #0x230]
    2680:      	adds	x10, x9, x10
    2684:      	csinv	x12, x10, xzr, lo
    2688:      	lsr	x10, x11, #14
    268c:      	cbz	x10, 0x26bc <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xed4>
    2690:      	b	0x2754 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xf6c>
    2694:      	str	w20, [sp, #0x160]
    2698:      	str	xzr, [sp, #0x168]
    269c:      	mul	x10, x10, x19
    26a0:      	strb	wzr, [sp, #0x170]
    26a4:      	str	x10, [sp, #0x238]
    26a8:      	ldr	x10, [sp, #0x230]
    26ac:      	adds	x10, x9, x10
    26b0:      	csinv	x12, x10, xzr, lo
    26b4:      	lsr	x10, x11, #14
    26b8:      	cbnz	x10, 0x2754 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xf6c>
    26bc:      	sub	x10, x11, x11, lsr #2
    26c0:      	cmp	x12, x10
    26c4:      	b.lo	0x2754 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xf6c>
    26c8:      	cmp	x11, #0x2, lsl #12      ; =0x2000
    26cc:      	mov	w8, #0x2000             ; =8192
    26d0:      	csel	x8, x11, x8, lo
    26d4:      	lsl	x8, x8, #1
    26d8:      	cmp	x11, #0x0
    26dc:      	csinc	x8, x8, xzr, ne
    26e0:      	cmp	x9, x10, lsr #1
    26e4:      	csel	x1, x11, x8, lo
    26e8:      	add	x0, x27, #0x1d0
    26ec:      	add	x2, x27, #0x1c0
    26f0:      	bl	0x26f0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xf08>
		00000000000026f0:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    26f4:      	ldp	x4, x0, [sp, #0x20]
    26f8:      	ldr	x3, [sp, #0x30]
    26fc:      	mov	x6, #0xe5b9             ; =58809
    2700:      	movk	x6, #0x1ce4, lsl #16
    2704:      	movk	x6, #0x476d, lsl #32
    2708:      	movk	x6, #0xbf58, lsl #48
    270c:      	mov	x5, #0x11eb             ; =4587
    2710:      	movk	x5, #0x1331, lsl #16
    2714:      	movk	x5, #0x49bb, lsl #32
    2718:      	movk	x5, #0x94d0, lsl #48
    271c:      	ldrb	w8, [sp, #0x208]
    2720:      	tbnz	w8, #0x0, 0x2758 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xf70>
    2724:      	ldr	x8, [sp, #0x200]
    2728:      	eor	x8, x8, x26
    272c:      	eor	x8, x8, x8, lsr #30
    2730:      	mul	x8, x8, x6
    2734:      	eor	x8, x8, x8, lsr #27
    2738:      	mul	x8, x8, x5
    273c:      	eor	x10, x8, x8, lsr #31
    2740:      	add	x8, x0, x25
    2744:      	ldr	x9, [sp, #0x210]
    2748:      	cbnz	x9, 0x2768 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xf80>
    274c:      	mov	x10, #0x0               ; =0
    2750:      	b	0x27dc <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xff4>
    2754:      	tbz	w8, #0x0, 0x2724 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xf3c>
    2758:      	mov	x10, #0x0               ; =0
    275c:      	add	x8, x0, x25
    2760:      	ldr	x9, [sp, #0x210]
    2764:      	cbz	x9, 0x274c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xf64>
    2768:      	udiv	x11, x10, x9
    276c:      	msub	x11, x11, x9, x10
    2770:      	ldr	x12, [sp, #0x220]
    2774:      	mov	x13, x9
    2778:      	mov	x10, x9
    277c:      	b	0x279c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xfb4>
    2780:      	cmp	x10, x9
    2784:      	csel	x10, x11, x10, eq
    2788:      	add	x14, x11, #0x1
    278c:      	cmp	x14, x9
    2790:      	csinc	x11, xzr, x11, hs
    2794:      	subs	x13, x13, #0x1
    2798:      	b.eq	0x27dc <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xff4>
    279c:      	madd	x14, x11, x23, x12
    27a0:      	ldr	w15, [x14]
    27a4:      	cmp	w15, #0x1
    27a8:      	b.eq	0x2780 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xf98>
    27ac:      	cmp	w15, #0x2
    27b0:      	b.ne	0x27d4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xfec>
    27b4:      	ldr	x15, [x14, #0x8]
    27b8:      	cmp	x15, x26
    27bc:      	b.ne	0x2788 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xfa0>
    27c0:      	ldr	x9, [x14, #0x10]
    27c4:      	mov	w10, #0x2               ; =2
    27c8:      	str	w10, [x14]
    27cc:      	str	x8, [x14, #0x10]
    27d0:      	b	0x286c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1084>
    27d4:      	cmp	x10, x9
    27d8:      	csel	x10, x11, x10, eq
    27dc:      	cmp	x10, x9
    27e0:      	b.hs	0x282c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1044>
    27e4:      	ldr	x9, [sp, #0x228]
    27e8:      	lsr	x11, x9, #14
    27ec:      	cbnz	x11, 0x282c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1044>
    27f0:      	add	x9, x9, #0x1
    27f4:      	str	x9, [sp, #0x228]
    27f8:      	ldr	x9, [sp, #0x220]
    27fc:      	madd	x10, x10, x23, x9
    2800:      	ldr	w11, [x10]
    2804:      	cmp	w11, #0x1
    2808:      	b.ne	0x2854 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x106c>
    280c:      	ldr	x9, [sp, #0x230]
    2810:      	subs	x9, x9, #0x1
    2814:      	csel	x9, xzr, x9, lo
    2818:      	str	x9, [sp, #0x230]
    281c:      	mov	w9, #0x2                ; =2
    2820:      	str	w9, [x10]
    2824:      	stp	x26, x8, [x10, #0x8]
    2828:      	b	0x288c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x10a4>
    282c:      	stp	x20, x26, [sp, #0x178]
    2830:      	strb	w20, [x27, #0x13c]
    2834:      	str	x8, [sp, #0x188]
    2838:      	ldr	q0, [x28, #0x140]
    283c:      	str	q0, [x27, #0x150]
    2840:      	mov	w8, #0x2                ; =2
    2844:      	ldr	x9, [sp, #0x238]
    2848:      	madd	x8, x9, x19, x8
    284c:      	ldp	x9, x10, [sp, #0x190]
    2850:      	b	0x2a04 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x121c>
    2854:      	ldp	x12, x9, [x10, #0x8]
    2858:      	mov	w13, #0x2               ; =2
    285c:      	str	w13, [x10]
    2860:      	stp	x26, x8, [x10, #0x8]
    2864:      	cbz	w11, 0x288c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x10a4>
    2868:      	mov	x26, x12
    286c:      	stp	x20, x26, [sp, #0x178]
    2870:      	str	x9, [sp, #0x188]
    2874:      	ldrb	w9, [x27, #0x13c]
    2878:      	ldr	q0, [x28, #0x140]
    287c:      	str	q0, [x27, #0x150]
    2880:      	mov	w8, #0x1                ; =1
    2884:      	tbnz	w9, #0x0, 0x2840 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1058>
    2888:      	b	0x2844 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x105c>
    288c:      	stp	xzr, xzr, [x27, #0x138]
    2890:      	str	xzr, [x27, #0x148]
    2894:      	b	0x2a50 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1268>
    2898:      	mov	w1, #0x1                ; =1
    289c:      	add	x0, x27, #0x1d0
    28a0:      	add	x2, x27, #0x1c0
    28a4:      	bl	0x28a4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x10bc>
		00000000000028a4:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    28a8:      	mov	x5, #0x11eb             ; =4587
    28ac:      	movk	x5, #0x1331, lsl #16
    28b0:      	movk	x5, #0x49bb, lsl #32
    28b4:      	movk	x5, #0x94d0, lsl #48
    28b8:      	mov	x6, #0xe5b9             ; =58809
    28bc:      	movk	x6, #0x1ce4, lsl #16
    28c0:      	movk	x6, #0x476d, lsl #32
    28c4:      	movk	x6, #0xbf58, lsl #48
    28c8:      	ldp	x0, x3, [sp, #0x28]
    28cc:      	ldr	x4, [sp, #0x20]
    28d0:      	ldrb	w8, [sp, #0x208]
    28d4:      	tbz	w8, #0x0, 0x2954 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x116c>
    28d8:      	mov	x10, #0x0               ; =0
    28dc:      	add	x8, x0, x25
    28e0:      	ldr	x9, [sp, #0x210]
    28e4:      	cbz	x9, 0x297c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1194>
    28e8:      	udiv	x11, x10, x9
    28ec:      	msub	x11, x11, x9, x10
    28f0:      	ldr	x12, [sp, #0x220]
    28f4:      	mov	x13, x9
    28f8:      	mov	x10, x9
    28fc:      	b	0x291c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1134>
    2900:      	cmp	x10, x9
    2904:      	csel	x10, x11, x10, eq
    2908:      	add	x14, x11, #0x1
    290c:      	cmp	x14, x9
    2910:      	csinc	x11, xzr, x11, hs
    2914:      	subs	x13, x13, #0x1
    2918:      	b.eq	0x2980 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1198>
    291c:      	madd	x14, x11, x23, x12
    2920:      	ldr	w15, [x14]
    2924:      	cmp	w15, #0x1
    2928:      	b.eq	0x2900 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1118>
    292c:      	cmp	w15, #0x2
    2930:      	b.ne	0x29d0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x11e8>
    2934:      	ldr	x15, [x14, #0x8]
    2938:      	cmp	x15, x26
    293c:      	b.ne	0x2908 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1120>
    2940:      	ldr	x9, [x14, #0x10]
    2944:      	mov	w10, #0x2               ; =2
    2948:      	str	w10, [x14]
    294c:      	str	x8, [x14, #0x10]
    2950:      	b	0x2a28 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1240>
    2954:      	ldr	x8, [sp, #0x200]
    2958:      	eor	x8, x8, x26
    295c:      	eor	x8, x8, x8, lsr #30
    2960:      	mul	x8, x8, x6
    2964:      	eor	x8, x8, x8, lsr #27
    2968:      	mul	x8, x8, x5
    296c:      	eor	x10, x8, x8, lsr #31
    2970:      	add	x8, x0, x25
    2974:      	ldr	x9, [sp, #0x210]
    2978:      	cbnz	x9, 0x28e8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1100>
    297c:      	mov	x10, #0x0               ; =0
    2980:      	cmp	x10, x9
    2984:      	b.hs	0x29e0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x11f8>
    2988:      	ldr	x9, [sp, #0x228]
    298c:      	lsr	x11, x9, #14
    2990:      	cbnz	x11, 0x29e0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x11f8>
    2994:      	add	x9, x9, #0x1
    2998:      	str	x9, [sp, #0x228]
    299c:      	ldr	x9, [sp, #0x220]
    29a0:      	madd	x10, x10, x23, x9
    29a4:      	ldr	w11, [x10]
    29a8:      	cmp	w11, #0x1
    29ac:      	b.ne	0x2a10 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1228>
    29b0:      	ldr	x9, [sp, #0x230]
    29b4:      	subs	x9, x9, #0x1
    29b8:      	csel	x9, xzr, x9, lo
    29bc:      	str	x9, [sp, #0x230]
    29c0:      	mov	w9, #0x2                ; =2
    29c4:      	str	w9, [x10]
    29c8:      	stp	x26, x8, [x10, #0x8]
    29cc:      	b	0x2a48 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1260>
    29d0:      	cmp	x10, x9
    29d4:      	csel	x10, x11, x10, eq
    29d8:      	cmp	x10, x9
    29dc:      	b.lo	0x2988 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x11a0>
    29e0:      	stp	x20, x26, [sp, #0x110]
    29e4:      	strb	w20, [sp, #0x114]
    29e8:      	str	x8, [sp, #0x120]
    29ec:      	ldur	q0, [x28, #0xd8]
    29f0:      	stur	q0, [x27, #0xe8]
    29f4:      	mov	w8, #0x2                ; =2
    29f8:      	ldr	x9, [sp, #0x238]
    29fc:      	madd	x8, x9, x19, x8
    2a00:      	ldp	x9, x10, [sp, #0x128]
    2a04:      	add	x8, x9, x8
    2a08:      	madd	x8, x8, x19, x10
    2a0c:      	b	0x22b0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xac8>
    2a10:      	ldp	x12, x9, [x10, #0x8]
    2a14:      	mov	w13, #0x2               ; =2
    2a18:      	str	w13, [x10]
    2a1c:      	stp	x26, x8, [x10, #0x8]
    2a20:      	cbz	w11, 0x2a48 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1260>
    2a24:      	mov	x26, x12
    2a28:      	stp	x20, x26, [sp, #0x110]
    2a2c:      	str	x9, [sp, #0x120]
    2a30:      	ubfx	x9, x20, #32, #8
    2a34:      	ldur	q0, [x28, #0xd8]
    2a38:      	stur	q0, [x27, #0xe8]
    2a3c:      	mov	w8, #0x1                ; =1
    2a40:      	tbnz	w9, #0x0, 0x29f4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x120c>
    2a44:      	b	0x29f8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1210>
    2a48:      	stp	xzr, xzr, [x27, #0xd0]
    2a4c:      	stur	xzr, [x27, #0xe0]
    2a50:      	ldr	x8, [sp, #0x238]
    2a54:      	mul	x8, x8, x19
    2a58:      	b	0x22b0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xac8>
    2a5c:      	mov	x12, x13
    2a60:      	cmp	x13, #0x4
    2a64:      	b.hs	0x2b0c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1324>
    2a68:      	add	x19, x27, #0x1f8
    2a6c:      	cbz	x8, 0x2a94 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x12ac>
    2a70:      	bl	0x2a70 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1288>
		0000000000002a70:  ARM64_RELOC_BRANCH26	_free
    2a74:      	mov	x6, #0xe5b9             ; =58809
    2a78:      	movk	x6, #0x1ce4, lsl #16
    2a7c:      	movk	x6, #0x476d, lsl #32
    2a80:      	movk	x6, #0xbf58, lsl #48
    2a84:      	mov	x5, #0x11eb             ; =4587
    2a88:      	movk	x5, #0x1331, lsl #16
    2a8c:      	movk	x5, #0x49bb, lsl #32
    2a90:      	movk	x5, #0x94d0, lsl #48
    2a94:      	ldp	q0, q1, [x19]
    2a98:      	stp	q0, q1, [sp, #0x1e0]
    2a9c:      	ldp	x8, x9, [sp, #0x1e0]
    2aa0:      	ldp	x10, x11, [sp, #0x1f0]
    2aa4:      	eor	x8, x8, x8, lsr #30
    2aa8:      	mul	x8, x8, x6
    2aac:      	eor	x8, x8, x8, lsr #27
    2ab0:      	mul	x8, x8, x5
    2ab4:      	eor	x9, x9, x9, lsr #30
    2ab8:      	mul	x9, x9, x6
    2abc:      	eor	x9, x9, x9, lsr #27
    2ac0:      	mul	x9, x9, x5
    2ac4:      	eor	x12, x9, x8
    2ac8:      	mov	x13, #0x7c15            ; =31765
    2acc:      	movk	x13, #0x7f4a, lsl #16
    2ad0:      	movk	x13, #0x79b9, lsl #32
    2ad4:      	movk	x13, #0x9e37, lsl #48
    2ad8:      	mul	x11, x11, x13
    2adc:      	eor	x10, x10, x11
    2ae0:      	eor	x10, x10, x12, lsr #31
    2ae4:      	eor	x8, x8, x9
    2ae8:      	eor	x0, x10, x8
    2aec:      	add	sp, sp, #0x270
    2af0:      	ldp	x29, x30, [sp, #0x50]
    2af4:      	ldp	x20, x19, [sp, #0x40]
    2af8:      	ldp	x22, x21, [sp, #0x30]
    2afc:      	ldp	x24, x23, [sp, #0x20]
    2b00:      	ldp	x26, x25, [sp, #0x10]
    2b04:      	ldp	x28, x27, [sp], #0x60
    2b08:      	ret
    2b0c:      	mov	w13, #0x18              ; =24
    2b10:      	madd	x13, x12, x13, x0
    2b14:      	sub	x13, x13, #0x30
    2b18:      	mov	w14, #0x83              ; =131
    2b1c:      	b	0x2b2c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1344>
    2b20:      	sub	x13, x13, #0x60
    2b24:      	sub	x12, x12, #0x4
    2b28:      	cbz	x12, 0x2a68 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1280>
    2b2c:      	ldr	w15, [x13, #0x18]
    2b30:      	cmp	w15, #0x2
    2b34:      	b.ne	0x2bc8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x13e0>
    2b38:      	ldp	x16, x15, [x13, #0x20]
    2b3c:      	madd	x15, x16, x14, x15
    2b40:      	add	x9, x15, x9
    2b44:      	str	x9, [sp, #0x240]
    2b48:      	eor	x15, x15, x15, lsr #30
    2b4c:      	mul	x15, x15, x6
    2b50:      	eor	x15, x15, x15, lsr #27
    2b54:      	mul	x15, x15, x5
    2b58:      	eor	x11, x11, x15, lsr #31
    2b5c:      	eor	x11, x11, x15
    2b60:      	str	x11, [sp, #0x248]
    2b64:      	add	x10, x10, #0x1
    2b68:      	str	x10, [sp, #0x250]
    2b6c:      	ldr	w15, [x13]
    2b70:      	cmp	w15, #0x2
    2b74:      	b.eq	0x2bd4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x13ec>
    2b78:      	ldur	w15, [x13, #-0x18]
    2b7c:      	cmp	w15, #0x2
    2b80:      	b.ne	0x2c14 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x142c>
    2b84:      	ldp	x16, x15, [x13, #-0x10]
    2b88:      	madd	x15, x16, x14, x15
    2b8c:      	add	x9, x15, x9
    2b90:      	str	x9, [sp, #0x240]
    2b94:      	eor	x15, x15, x15, lsr #30
    2b98:      	mul	x15, x15, x6
    2b9c:      	eor	x15, x15, x15, lsr #27
    2ba0:      	mul	x15, x15, x5
    2ba4:      	eor	x11, x11, x15, lsr #31
    2ba8:      	eor	x11, x11, x15
    2bac:      	str	x11, [sp, #0x248]
    2bb0:      	add	x10, x10, #0x1
    2bb4:      	str	x10, [sp, #0x250]
    2bb8:      	ldur	w15, [x13, #-0x30]
    2bbc:      	cmp	w15, #0x2
    2bc0:      	b.ne	0x2b20 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1338>
    2bc4:      	b	0x2c20 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1438>
    2bc8:      	ldr	w15, [x13]
    2bcc:      	cmp	w15, #0x2
    2bd0:      	b.ne	0x2b78 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1390>
    2bd4:      	ldp	x16, x15, [x13, #0x8]
    2bd8:      	madd	x15, x16, x14, x15
    2bdc:      	add	x9, x15, x9
    2be0:      	str	x9, [sp, #0x240]
    2be4:      	eor	x15, x15, x15, lsr #30
    2be8:      	mul	x15, x15, x6
    2bec:      	eor	x15, x15, x15, lsr #27
    2bf0:      	mul	x15, x15, x5
    2bf4:      	eor	x11, x11, x15, lsr #31
    2bf8:      	eor	x11, x11, x15
    2bfc:      	str	x11, [sp, #0x248]
    2c00:      	add	x10, x10, #0x1
    2c04:      	str	x10, [sp, #0x250]
    2c08:      	ldur	w15, [x13, #-0x18]
    2c0c:      	cmp	w15, #0x2
    2c10:      	b.eq	0x2b84 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x139c>
    2c14:      	ldur	w15, [x13, #-0x30]
    2c18:      	cmp	w15, #0x2
    2c1c:      	b.ne	0x2b20 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1338>
    2c20:      	ldp	x16, x15, [x13, #-0x28]
    2c24:      	madd	x15, x16, x14, x15
    2c28:      	add	x9, x15, x9
    2c2c:      	str	x9, [sp, #0x240]
    2c30:      	eor	x15, x15, x15, lsr #30
    2c34:      	mul	x15, x15, x6
    2c38:      	eor	x15, x15, x15, lsr #27
    2c3c:      	mul	x15, x15, x5
    2c40:      	eor	x11, x11, x15, lsr #31
    2c44:      	eor	x11, x11, x15
    2c48:      	str	x11, [sp, #0x248]
    2c4c:      	add	x10, x10, #0x1
    2c50:      	str	x10, [sp, #0x250]
    2c54:      	b	0x2b20 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1338>
    2c58:      	bl	0x2c58 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1470>
		0000000000002c58:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

0000000000002c5c <_wf_map_cost_library_policy$instance$4250cb78d3f44027>:
    2c5c:      	stp	x28, x27, [sp, #-0x60]!
    2c60:      	stp	x26, x25, [sp, #0x10]
    2c64:      	stp	x24, x23, [sp, #0x20]
    2c68:      	stp	x22, x21, [sp, #0x30]
    2c6c:      	stp	x20, x19, [sp, #0x40]
    2c70:      	stp	x29, x30, [sp, #0x50]
    2c74:      	sub	sp, sp, #0x620
    2c78:      	mov	x19, x0
    2c7c:      	mov	x8, #0x7c15             ; =31765
    2c80:      	movk	x8, #0x7f4a, lsl #16
    2c84:      	movk	x8, #0x79b9, lsl #32
    2c88:      	movk	x8, #0x9e37, lsl #48
    2c8c:      	eor	x8, x0, x8
    2c90:      	cmp	x1, #0x0
    2c94:      	cset	w9, ne
    2c98:      	str	x8, [sp, #0x160]
    2c9c:      	strb	w9, [sp, #0x168]
    2ca0:      	mov	w0, #0x330              ; =816
    2ca4:      	bl	0x2ca4 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x48>
		0000000000002ca4:  ARM64_RELOC_BRANCH26	_malloc
    2ca8:      	cbz	x0, 0x3678 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0xa1c>
    2cac:      	add	x21, sp, #0x4a0
    2cb0:      	str	wzr, [x0]
    2cb4:      	add	x8, x0, #0x118
    2cb8:      	add	x9, x0, #0x228
    2cbc:      	str	xzr, [x0, #0x328]
    2cc0:      	movi.2d	v0, #0000000000000000
    2cc4:      	stp	q0, q0, [x9]
    2cc8:      	stp	q0, q0, [x9, #0x20]
    2ccc:      	stp	q0, q0, [x9, #0x40]
    2cd0:      	stp	q0, q0, [x9, #0x60]
    2cd4:      	stp	q0, q0, [x9, #0x80]
    2cd8:      	stp	q0, q0, [x9, #0xa0]
    2cdc:      	stp	q0, q0, [x9, #0xc0]
    2ce0:      	stp	q0, q0, [x9, #0xe0]
    2ce4:      	stur	q0, [x0, #0xf8]
    2ce8:      	stur	q0, [x0, #0xe8]
    2cec:      	stur	q0, [x0, #0xd8]
    2cf0:      	stur	q0, [x0, #0xc8]
    2cf4:      	stur	q0, [x0, #0xb8]
    2cf8:      	stur	q0, [x0, #0xa8]
    2cfc:      	stur	q0, [x0, #0x98]
    2d00:      	stur	q0, [x0, #0x88]
    2d04:      	stur	q0, [x0, #0x78]
    2d08:      	stur	q0, [x0, #0x68]
    2d0c:      	stur	q0, [x0, #0x58]
    2d10:      	stur	q0, [x0, #0x48]
    2d14:      	stur	q0, [x0, #0x38]
    2d18:      	stur	q0, [x0, #0x28]
    2d1c:      	stur	q0, [x0, #0x18]
    2d20:      	mov	x9, x0
    2d24:      	str	q0, [x9, #0x8]!
    2d28:      	stur	q0, [x9, #0xfc]
    2d2c:      	stur	q0, [x8, #0xfc]
    2d30:      	stp	q0, q0, [x8, #0xe0]
    2d34:      	stp	q0, q0, [x8, #0xc0]
    2d38:      	stp	q0, q0, [x8, #0xa0]
    2d3c:      	stp	q0, q0, [x8, #0x80]
    2d40:      	stp	q0, q0, [x8, #0x60]
    2d44:      	stp	q0, q0, [x8, #0x40]
    2d48:      	stp	q0, q0, [x8, #0x20]
    2d4c:      	stp	q0, q0, [x8]
    2d50:      	mov	w8, #0x3                ; =3
    2d54:      	dup.2d	v0, x8
    2d58:      	str	q0, [sp, #0x130]
    2d5c:      	stp	xzr, xzr, [sp, #0x148]
    2d60:      	str	x0, [sp, #0x140]
    2d64:      	add	x23, x21, #0x128
    2d68:      	stp	x19, xzr, [sp, #0x110]
    2d6c:      	stp	xzr, xzr, [sp, #0x120]
    2d70:      	add	x8, x19, #0x1f
    2d74:      	dup.2d	v1, x19
    2d78:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x818>
		0000000000002d78:  ARM64_RELOC_PAGE21	lCPI67_0
    2d7c:      	ldr	q0, [x9]
		0000000000002d7c:  ARM64_RELOC_PAGEOFF12	lCPI67_0
    2d80:      	str	q0, [sp, #0xf0]
    2d84:      	add.2d	v0, v1, v0
    2d88:      	stur	q0, [x21, #0x8]
    2d8c:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x818>
		0000000000002d8c:  ARM64_RELOC_PAGE21	lCPI67_1
    2d90:      	ldr	q0, [x9]
		0000000000002d90:  ARM64_RELOC_PAGEOFF12	lCPI67_1
    2d94:      	str	q0, [sp, #0xe0]
    2d98:      	add.2d	v0, v1, v0
    2d9c:      	stur	q0, [x21, #0x18]
    2da0:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x818>
		0000000000002da0:  ARM64_RELOC_PAGE21	lCPI67_2
    2da4:      	ldr	q0, [x9]
		0000000000002da4:  ARM64_RELOC_PAGEOFF12	lCPI67_2
    2da8:      	str	q0, [sp, #0xd0]
    2dac:      	add.2d	v0, v1, v0
    2db0:      	stur	q0, [x21, #0x28]
    2db4:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x818>
		0000000000002db4:  ARM64_RELOC_PAGE21	lCPI67_3
    2db8:      	ldr	q0, [x9]
		0000000000002db8:  ARM64_RELOC_PAGEOFF12	lCPI67_3
    2dbc:      	str	q0, [sp, #0xc0]
    2dc0:      	add.2d	v0, v1, v0
    2dc4:      	stur	q0, [x21, #0x38]
    2dc8:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x818>
		0000000000002dc8:  ARM64_RELOC_PAGE21	lCPI67_4
    2dcc:      	ldr	q0, [x9]
		0000000000002dcc:  ARM64_RELOC_PAGEOFF12	lCPI67_4
    2dd0:      	str	q0, [sp, #0xb0]
    2dd4:      	add.2d	v0, v1, v0
    2dd8:      	stur	q0, [x21, #0x48]
    2ddc:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x818>
		0000000000002ddc:  ARM64_RELOC_PAGE21	lCPI67_5
    2de0:      	ldr	q0, [x9]
		0000000000002de0:  ARM64_RELOC_PAGEOFF12	lCPI67_5
    2de4:      	str	q0, [sp, #0xa0]
    2de8:      	add.2d	v0, v1, v0
    2dec:      	stur	q0, [x21, #0x58]
    2df0:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x818>
		0000000000002df0:  ARM64_RELOC_PAGE21	lCPI67_6
    2df4:      	ldr	q0, [x9]
		0000000000002df4:  ARM64_RELOC_PAGEOFF12	lCPI67_6
    2df8:      	str	q0, [sp, #0x90]
    2dfc:      	add.2d	v0, v1, v0
    2e00:      	stur	q0, [x21, #0x68]
    2e04:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x818>
		0000000000002e04:  ARM64_RELOC_PAGE21	lCPI67_7
    2e08:      	ldr	q0, [x9]
		0000000000002e08:  ARM64_RELOC_PAGEOFF12	lCPI67_7
    2e0c:      	str	q0, [sp, #0x80]
    2e10:      	add.2d	v0, v1, v0
    2e14:      	stur	q0, [x21, #0x78]
    2e18:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x818>
		0000000000002e18:  ARM64_RELOC_PAGE21	lCPI67_8
    2e1c:      	ldr	q0, [x9]
		0000000000002e1c:  ARM64_RELOC_PAGEOFF12	lCPI67_8
    2e20:      	str	q0, [sp, #0x70]
    2e24:      	add.2d	v0, v1, v0
    2e28:      	stur	q0, [x21, #0x88]
    2e2c:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x818>
		0000000000002e2c:  ARM64_RELOC_PAGE21	lCPI67_9
    2e30:      	ldr	q0, [x9]
		0000000000002e30:  ARM64_RELOC_PAGEOFF12	lCPI67_9
    2e34:      	str	q0, [sp, #0x60]
    2e38:      	add.2d	v0, v1, v0
    2e3c:      	stur	q0, [x21, #0x98]
    2e40:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x818>
		0000000000002e40:  ARM64_RELOC_PAGE21	lCPI67_10
    2e44:      	ldr	q0, [x9]
		0000000000002e44:  ARM64_RELOC_PAGEOFF12	lCPI67_10
    2e48:      	str	q0, [sp, #0x50]
    2e4c:      	add.2d	v0, v1, v0
    2e50:      	stur	q0, [x21, #0xa8]
    2e54:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x818>
		0000000000002e54:  ARM64_RELOC_PAGE21	lCPI67_11
    2e58:      	ldr	q0, [x9]
		0000000000002e58:  ARM64_RELOC_PAGEOFF12	lCPI67_11
    2e5c:      	str	q0, [sp, #0x40]
    2e60:      	add.2d	v0, v1, v0
    2e64:      	stur	q0, [x21, #0xb8]
    2e68:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x818>
		0000000000002e68:  ARM64_RELOC_PAGE21	lCPI67_12
    2e6c:      	ldr	q0, [x9]
		0000000000002e6c:  ARM64_RELOC_PAGEOFF12	lCPI67_12
    2e70:      	str	q0, [sp, #0x30]
    2e74:      	add.2d	v0, v1, v0
    2e78:      	stur	q0, [x21, #0xc8]
    2e7c:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x818>
		0000000000002e7c:  ARM64_RELOC_PAGE21	lCPI67_13
    2e80:      	ldr	q0, [x9]
		0000000000002e80:  ARM64_RELOC_PAGEOFF12	lCPI67_13
    2e84:      	str	q0, [sp, #0x20]
    2e88:      	add.2d	v0, v1, v0
    2e8c:      	stur	q0, [x21, #0xd8]
    2e90:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x818>
		0000000000002e90:  ARM64_RELOC_PAGE21	lCPI67_14
    2e94:      	ldr	q0, [x9]
		0000000000002e94:  ARM64_RELOC_PAGEOFF12	lCPI67_14
    2e98:      	str	q1, [sp, #0x100]
    2e9c:      	str	q0, [sp, #0x10]
    2ea0:      	add.2d	v0, v1, v0
    2ea4:      	stur	q0, [x21, #0xe8]
    2ea8:      	str	x19, [sp, #0x4a0]
    2eac:      	str	x8, [sp, #0x598]
    2eb0:      	ldr	x1, [sp, #0x130]
    2eb4:      	ldr	x9, [sp, #0x150]
    2eb8:      	ldp	q1, q0, [sp, #0x130]
    2ebc:      	str	q0, [sp, #0x5b0]
    2ec0:      	str	q1, [sp, #0x5a0]
    2ec4:      	ldr	x8, [sp, #0x5b8]
    2ec8:      	stp	q1, q0, [x23]
    2ecc:      	adds	x8, x8, x9
    2ed0:      	csinv	x8, x8, xzr, lo
    2ed4:      	str	x9, [sp, #0x5c0]
    2ed8:      	str	x9, [sp, #0x5e8]
    2edc:      	cmp	x1, #0x2
    2ee0:      	b.hi	0x2f3c <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x2e0>
    2ee4:      	sub	x9, x1, x1, lsr #2
    2ee8:      	cmp	x8, x9
    2eec:      	b.lo	0x2f3c <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x2e0>
    2ef0:      	ldr	x8, [sp, #0x150]
    2ef4:      	str	x8, [x21, #0x170]
    2ef8:      	ldp	q1, q0, [sp, #0x130]
    2efc:      	stp	q1, q0, [x21, #0x150]
    2f00:      	ldr	x8, [sp, #0x608]
    2f04:      	cmp	x8, x1, lsr #1
    2f08:      	b.lo	0x2f24 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x2c8>
    2f0c:      	cbz	x1, 0x2f20 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x2c4>
    2f10:      	cmp	x1, #0x1
    2f14:      	mov	w8, #0x2                ; =2
    2f18:      	cinc	x1, x8, ne
    2f1c:      	b	0x2f24 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x2c8>
    2f20:      	mov	w1, #0x1                ; =1
    2f24:      	add	x0, sp, #0x130
    2f28:      	add	x2, sp, #0x160
    2f2c:      	bl	0x2f2c <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x2d0>
		0000000000002f2c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07
    2f30:      	str	w0, [sp, #0x618]
    2f34:      	strb	w1, [sp, #0x61c]
    2f38:      	strb	w2, [sp, #0x61d]
    2f3c:      	add	x0, sp, #0x390
    2f40:      	add	x1, sp, #0x130
    2f44:      	add	x3, sp, #0x4a0
    2f48:      	add	x4, sp, #0x160
    2f4c:      	mov	w2, #0x1                ; =1
    2f50:      	bl	0x2f50 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x2f4>
		0000000000002f50:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07
    2f54:      	add	x0, sp, #0x390
    2f58:      	add	x1, sp, #0x110
    2f5c:      	bl	0x2f5c <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x300>
		0000000000002f5c:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
    2f60:      	add	x8, x19, #0x1
    2f64:      	dup.2d	v0, x8
    2f68:      	ldr	q1, [sp, #0xf0]
    2f6c:      	add.2d	v1, v0, v1
    2f70:      	stur	q1, [x21, #0x8]
    2f74:      	add	x9, x19, #0x20
    2f78:      	ldr	q1, [sp, #0xe0]
    2f7c:      	add.2d	v1, v0, v1
    2f80:      	stur	q1, [x21, #0x18]
    2f84:      	ldr	q1, [sp, #0xd0]
    2f88:      	add.2d	v1, v0, v1
    2f8c:      	stur	q1, [x21, #0x28]
    2f90:      	ldr	q1, [sp, #0xc0]
    2f94:      	add.2d	v1, v0, v1
    2f98:      	stur	q1, [x21, #0x38]
    2f9c:      	ldr	q1, [sp, #0xb0]
    2fa0:      	add.2d	v1, v0, v1
    2fa4:      	stur	q1, [x21, #0x48]
    2fa8:      	ldr	q1, [sp, #0xa0]
    2fac:      	add.2d	v1, v0, v1
    2fb0:      	stur	q1, [x21, #0x58]
    2fb4:      	ldr	q1, [sp, #0x90]
    2fb8:      	add.2d	v1, v0, v1
    2fbc:      	stur	q1, [x21, #0x68]
    2fc0:      	ldr	q1, [sp, #0x80]
    2fc4:      	add.2d	v1, v0, v1
    2fc8:      	stur	q1, [x21, #0x78]
    2fcc:      	ldr	q1, [sp, #0x70]
    2fd0:      	add.2d	v1, v0, v1
    2fd4:      	stur	q1, [x21, #0x88]
    2fd8:      	ldr	q1, [sp, #0x60]
    2fdc:      	add.2d	v1, v0, v1
    2fe0:      	stur	q1, [x21, #0x98]
    2fe4:      	ldr	q1, [sp, #0x50]
    2fe8:      	add.2d	v1, v0, v1
    2fec:      	stur	q1, [x21, #0xa8]
    2ff0:      	ldr	q1, [sp, #0x40]
    2ff4:      	add.2d	v1, v0, v1
    2ff8:      	stur	q1, [x21, #0xb8]
    2ffc:      	ldr	q1, [sp, #0x30]
    3000:      	add.2d	v1, v0, v1
    3004:      	stur	q1, [x21, #0xc8]
    3008:      	ldr	q1, [sp, #0x20]
    300c:      	add.2d	v1, v0, v1
    3010:      	stur	q1, [x21, #0xd8]
    3014:      	ldr	q1, [sp, #0x10]
    3018:      	add.2d	v0, v0, v1
    301c:      	stur	q0, [x21, #0xe8]
    3020:      	str	x8, [sp, #0x4a0]
    3024:      	str	x9, [sp, #0x598]
    3028:      	ldr	x1, [sp, #0x130]
    302c:      	ldr	x8, [sp, #0x150]
    3030:      	str	x8, [x21, #0x120]
    3034:      	ldp	q1, q0, [sp, #0x130]
    3038:      	stp	q1, q0, [x21, #0x100]
    303c:      	str	x8, [x23, #0x20]
    3040:      	ldr	x8, [sp, #0x5b8]
    3044:      	ldr	x9, [sp, #0x5e8]
    3048:      	adds	x8, x8, x9
    304c:      	csinv	x8, x8, xzr, lo
    3050:      	stp	q1, q0, [x23]
    3054:      	cmp	x1, #0x2
    3058:      	b.hi	0x30b4 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x458>
    305c:      	sub	x9, x1, x1, lsr #2
    3060:      	cmp	x8, x9
    3064:      	b.lo	0x30b4 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x458>
    3068:      	ldr	x8, [sp, #0x150]
    306c:      	str	x8, [x21, #0x170]
    3070:      	ldp	q1, q0, [sp, #0x130]
    3074:      	stp	q1, q0, [x21, #0x150]
    3078:      	ldr	x8, [sp, #0x608]
    307c:      	cmp	x8, x1, lsr #1
    3080:      	b.lo	0x309c <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x440>
    3084:      	cbz	x1, 0x3098 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x43c>
    3088:      	cmp	x1, #0x1
    308c:      	mov	w8, #0x2                ; =2
    3090:      	cinc	x1, x8, ne
    3094:      	b	0x309c <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x440>
    3098:      	mov	w1, #0x1                ; =1
    309c:      	add	x0, sp, #0x130
    30a0:      	add	x2, sp, #0x160
    30a4:      	bl	0x30a4 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x448>
		00000000000030a4:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07
    30a8:      	str	w0, [sp, #0x618]
    30ac:      	strb	w1, [sp, #0x61c]
    30b0:      	strb	w2, [sp, #0x61d]
    30b4:      	add	x0, sp, #0x390
    30b8:      	add	x1, sp, #0x130
    30bc:      	add	x3, sp, #0x4a0
    30c0:      	add	x4, sp, #0x160
    30c4:      	mov	w2, #0x3                ; =3
    30c8:      	bl	0x30c8 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x46c>
		00000000000030c8:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07
    30cc:      	add	x0, sp, #0x390
    30d0:      	add	x1, sp, #0x110
    30d4:      	bl	0x30d4 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x478>
		00000000000030d4:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
    30d8:      	add	x8, x19, #0x2
    30dc:      	dup.2d	v0, x8
    30e0:      	ldr	q1, [sp, #0xf0]
    30e4:      	add.2d	v1, v0, v1
    30e8:      	stur	q1, [x21, #0x8]
    30ec:      	add	x24, x19, #0x21
    30f0:      	ldr	q1, [sp, #0xe0]
    30f4:      	add.2d	v1, v0, v1
    30f8:      	stur	q1, [x21, #0x18]
    30fc:      	ldr	q1, [sp, #0xd0]
    3100:      	add.2d	v1, v0, v1
    3104:      	stur	q1, [x21, #0x28]
    3108:      	ldr	q1, [sp, #0xc0]
    310c:      	add.2d	v1, v0, v1
    3110:      	stur	q1, [x21, #0x38]
    3114:      	ldr	q1, [sp, #0xb0]
    3118:      	add.2d	v1, v0, v1
    311c:      	stur	q1, [x21, #0x48]
    3120:      	ldr	q1, [sp, #0xa0]
    3124:      	add.2d	v1, v0, v1
    3128:      	stur	q1, [x21, #0x58]
    312c:      	ldr	q1, [sp, #0x90]
    3130:      	add.2d	v1, v0, v1
    3134:      	stur	q1, [x21, #0x68]
    3138:      	ldr	q1, [sp, #0x80]
    313c:      	add.2d	v1, v0, v1
    3140:      	stur	q1, [x21, #0x78]
    3144:      	ldr	q1, [sp, #0x70]
    3148:      	add.2d	v1, v0, v1
    314c:      	stur	q1, [x21, #0x88]
    3150:      	ldr	q1, [sp, #0x60]
    3154:      	add.2d	v1, v0, v1
    3158:      	stur	q1, [x21, #0x98]
    315c:      	ldr	q1, [sp, #0x50]
    3160:      	add.2d	v1, v0, v1
    3164:      	stur	q1, [x21, #0xa8]
    3168:      	ldr	q1, [sp, #0x40]
    316c:      	add.2d	v1, v0, v1
    3170:      	stur	q1, [x21, #0xb8]
    3174:      	ldr	q1, [sp, #0x30]
    3178:      	add.2d	v1, v0, v1
    317c:      	stur	q1, [x21, #0xc8]
    3180:      	ldr	q1, [sp, #0x20]
    3184:      	add.2d	v1, v0, v1
    3188:      	stur	q1, [x21, #0xd8]
    318c:      	ldr	q1, [sp, #0x10]
    3190:      	add.2d	v0, v0, v1
    3194:      	stur	q0, [x21, #0xe8]
    3198:      	str	x8, [sp, #0x4a0]
    319c:      	str	x24, [sp, #0x598]
    31a0:      	ldr	x1, [sp, #0x130]
    31a4:      	ldr	x8, [sp, #0x150]
    31a8:      	str	x8, [x21, #0x120]
    31ac:      	ldp	q1, q0, [sp, #0x130]
    31b0:      	stp	q1, q0, [x21, #0x100]
    31b4:      	str	x8, [x23, #0x20]
    31b8:      	ldr	x8, [sp, #0x5b8]
    31bc:      	ldr	x9, [sp, #0x5e8]
    31c0:      	adds	x8, x8, x9
    31c4:      	csinv	x8, x8, xzr, lo
    31c8:      	stp	q1, q0, [x23]
    31cc:      	cmp	x1, #0x2
    31d0:      	b.hi	0x322c <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x5d0>
    31d4:      	sub	x9, x1, x1, lsr #2
    31d8:      	cmp	x8, x9
    31dc:      	b.lo	0x322c <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x5d0>
    31e0:      	ldr	x8, [sp, #0x150]
    31e4:      	str	x8, [x21, #0x170]
    31e8:      	ldp	q1, q0, [sp, #0x130]
    31ec:      	stp	q1, q0, [x21, #0x150]
    31f0:      	ldr	x8, [sp, #0x608]
    31f4:      	cmp	x8, x1, lsr #1
    31f8:      	b.lo	0x3214 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x5b8>
    31fc:      	cbz	x1, 0x3210 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x5b4>
    3200:      	cmp	x1, #0x1
    3204:      	mov	w8, #0x2                ; =2
    3208:      	cinc	x1, x8, ne
    320c:      	b	0x3214 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x5b8>
    3210:      	mov	w1, #0x1                ; =1
    3214:      	add	x0, sp, #0x130
    3218:      	add	x2, sp, #0x160
    321c:      	bl	0x321c <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x5c0>
		000000000000321c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07
    3220:      	str	w0, [sp, #0x618]
    3224:      	strb	w1, [sp, #0x61c]
    3228:      	strb	w2, [sp, #0x61d]
    322c:      	add	x0, sp, #0x390
    3230:      	add	x1, sp, #0x130
    3234:      	add	x3, sp, #0x4a0
    3238:      	add	x4, sp, #0x160
    323c:      	mov	w2, #0x5                ; =5
    3240:      	bl	0x3240 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x5e4>
		0000000000003240:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07
    3244:      	add	x0, sp, #0x390
    3248:      	add	x1, sp, #0x110
    324c:      	bl	0x324c <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x5f0>
		000000000000324c:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
    3250:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003250:  ARM64_RELOC_PAGE21	lCPI67_15
    3254:      	ldr	q0, [x8]
		0000000000003254:  ARM64_RELOC_PAGEOFF12	lCPI67_15
    3258:      	ldr	q5, [sp, #0x100]
    325c:      	add.2d	v0, v5, v0
    3260:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003260:  ARM64_RELOC_PAGE21	lCPI67_16
    3264:      	ldr	q1, [x8]
		0000000000003264:  ARM64_RELOC_PAGEOFF12	lCPI67_16
    3268:      	add.2d	v1, v5, v1
    326c:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		000000000000326c:  ARM64_RELOC_PAGE21	lCPI67_17
    3270:      	ldr	q2, [x8]
		0000000000003270:  ARM64_RELOC_PAGEOFF12	lCPI67_17
    3274:      	add.2d	v2, v5, v2
    3278:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003278:  ARM64_RELOC_PAGE21	lCPI67_18
    327c:      	ldr	q3, [x8]
		000000000000327c:  ARM64_RELOC_PAGEOFF12	lCPI67_18
    3280:      	add.2d	v3, v5, v3
    3284:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003284:  ARM64_RELOC_PAGE21	lCPI67_19
    3288:      	ldr	q4, [x8]
		0000000000003288:  ARM64_RELOC_PAGEOFF12	lCPI67_19
    328c:      	add.2d	v4, v5, v4
    3290:      	add	x8, x19, #0x14
    3294:      	add	x9, x19, #0x15
    3298:      	add	x10, x19, #0x16
    329c:      	str	q0, [sp, #0x4a0]
    32a0:      	str	q1, [sp, #0x4b0]
    32a4:      	add	x11, x19, #0x17
    32a8:      	add	x12, x19, #0x18
    32ac:      	add	x13, x19, #0x19
    32b0:      	add	x14, x19, #0x1a
    32b4:      	str	q2, [sp, #0x4c0]
    32b8:      	str	q3, [sp, #0x4d0]
    32bc:      	add	x15, x19, #0x1b
    32c0:      	add	x16, x19, #0x1c
    32c4:      	str	q4, [sp, #0x4e0]
    32c8:      	add	x17, x19, #0x1d
    32cc:      	add	x0, x19, #0x1e
    32d0:      	add	x1, x19, #0x1f
    32d4:      	add	x25, x19, #0x20
    32d8:      	str	x8, [sp, #0xe0]
    32dc:      	str	x8, [sp, #0x4f0]
    32e0:      	str	x9, [sp, #0xd0]
    32e4:      	str	x9, [sp, #0x4f8]
    32e8:      	add	x26, x19, #0x22
    32ec:      	add	x27, x19, #0x23
    32f0:      	add	x28, x19, #0x24
    32f4:      	add	x20, x19, #0x25
    32f8:      	str	x10, [sp, #0xc0]
    32fc:      	str	x10, [sp, #0x500]
    3300:      	str	x11, [sp, #0xb0]
    3304:      	str	x11, [sp, #0x508]
    3308:      	add	x22, x19, #0x26
    330c:      	add	x21, x19, #0x27
    3310:      	add	x23, x19, #0x28
    3314:      	add	x19, x19, #0x29
    3318:      	str	x12, [sp, #0xa0]
    331c:      	str	x12, [sp, #0x510]
    3320:      	str	x13, [sp, #0x90]
    3324:      	str	x13, [sp, #0x518]
    3328:      	add	x8, sp, #0x4a0
    332c:      	add	x8, x8, #0x128
    3330:      	str	x14, [sp, #0x80]
    3334:      	str	x14, [sp, #0x520]
    3338:      	str	x15, [sp, #0x70]
    333c:      	str	x15, [sp, #0x528]
    3340:      	str	x16, [sp, #0x60]
    3344:      	str	x16, [sp, #0x530]
    3348:      	str	x17, [sp, #0x50]
    334c:      	str	x17, [sp, #0x538]
    3350:      	str	x0, [sp, #0x40]
    3354:      	str	x0, [sp, #0x540]
    3358:      	str	x1, [sp, #0x30]
    335c:      	str	x1, [sp, #0x548]
    3360:      	str	x25, [sp, #0x550]
    3364:      	str	x24, [sp, #0xf0]
    3368:      	str	x24, [sp, #0x558]
    336c:      	str	x26, [sp, #0x560]
    3370:      	str	x27, [sp, #0x568]
    3374:      	str	x28, [sp, #0x570]
    3378:      	str	x20, [sp, #0x578]
    337c:      	str	x22, [sp, #0x580]
    3380:      	str	x21, [sp, #0x588]
    3384:      	str	x23, [sp, #0x590]
    3388:      	str	x19, [sp, #0x598]
    338c:      	ldr	x1, [sp, #0x130]
    3390:      	ldr	x9, [sp, #0x150]
    3394:      	ldp	q1, q0, [sp, #0x130]
    3398:      	str	q0, [sp, #0x5b0]
    339c:      	str	q1, [sp, #0x5a0]
    33a0:      	ldr	x10, [sp, #0x5b8]
    33a4:      	stp	q1, q0, [x8]
    33a8:      	adds	x8, x10, x9
    33ac:      	csinv	x8, x8, xzr, lo
    33b0:      	str	x9, [sp, #0x5c0]
    33b4:      	str	x9, [sp, #0x5e8]
    33b8:      	cmp	x1, #0x2
    33bc:      	b.hi	0x341c <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x7c0>
    33c0:      	sub	x9, x1, x1, lsr #2
    33c4:      	cmp	x8, x9
    33c8:      	b.lo	0x341c <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x7c0>
    33cc:      	ldp	q1, q0, [sp, #0x130]
    33d0:      	str	q0, [sp, #0x600]
    33d4:      	str	q1, [sp, #0x5f0]
    33d8:      	ldr	x8, [sp, #0x150]
    33dc:      	str	x8, [sp, #0x610]
    33e0:      	ldr	x8, [sp, #0x608]
    33e4:      	cmp	x8, x1, lsr #1
    33e8:      	b.lo	0x3404 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x7a8>
    33ec:      	cbz	x1, 0x3400 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x7a4>
    33f0:      	cmp	x1, #0x1
    33f4:      	mov	w8, #0x2                ; =2
    33f8:      	cinc	x1, x8, ne
    33fc:      	b	0x3404 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x7a8>
    3400:      	mov	w1, #0x1                ; =1
    3404:      	add	x0, sp, #0x130
    3408:      	add	x2, sp, #0x160
    340c:      	bl	0x340c <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x7b0>
		000000000000340c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07
    3410:      	str	w0, [sp, #0x618]
    3414:      	strb	w1, [sp, #0x61c]
    3418:      	strb	w2, [sp, #0x61d]
    341c:      	add	x24, sp, #0x4a0
    3420:      	add	x0, sp, #0x280
    3424:      	add	x1, sp, #0x130
    3428:      	add	x3, sp, #0x4a0
    342c:      	add	x4, sp, #0x160
    3430:      	mov	w2, #0x1                ; =1
    3434:      	bl	0x3434 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x7d8>
		0000000000003434:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07
    3438:      	add	x0, sp, #0x280
    343c:      	add	x1, sp, #0x110
    3440:      	bl	0x3440 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x7e4>
		0000000000003440:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
    3444:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003444:  ARM64_RELOC_PAGE21	lCPI67_20
    3448:      	ldr	q0, [x8]
		0000000000003448:  ARM64_RELOC_PAGEOFF12	lCPI67_20
    344c:      	ldr	q5, [sp, #0x100]
    3450:      	add.2d	v0, v5, v0
    3454:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003454:  ARM64_RELOC_PAGE21	lCPI67_21
    3458:      	ldr	q1, [x8]
		0000000000003458:  ARM64_RELOC_PAGEOFF12	lCPI67_21
    345c:      	add.2d	v1, v5, v1
    3460:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003460:  ARM64_RELOC_PAGE21	lCPI67_22
    3464:      	ldr	q2, [x8]
		0000000000003464:  ARM64_RELOC_PAGEOFF12	lCPI67_22
    3468:      	add.2d	v2, v5, v2
    346c:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		000000000000346c:  ARM64_RELOC_PAGE21	lCPI67_23
    3470:      	ldr	q3, [x8]
		0000000000003470:  ARM64_RELOC_PAGEOFF12	lCPI67_23
    3474:      	add.2d	v3, v5, v3
    3478:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003478:  ARM64_RELOC_PAGE21	lCPI67_24
    347c:      	ldr	q4, [x8]
		000000000000347c:  ARM64_RELOC_PAGEOFF12	lCPI67_24
    3480:      	add.2d	v4, v5, v4
    3484:      	add	x8, x24, #0x128
    3488:      	ldr	x9, [sp, #0xe0]
    348c:      	str	x9, [sp, #0x4a0]
    3490:      	ldr	x9, [sp, #0xd0]
    3494:      	str	x9, [sp, #0x4a8]
    3498:      	ldr	x9, [sp, #0xc0]
    349c:      	str	x9, [sp, #0x4b0]
    34a0:      	ldr	x9, [sp, #0xb0]
    34a4:      	str	x9, [sp, #0x4b8]
    34a8:      	ldr	x9, [sp, #0xa0]
    34ac:      	str	x9, [sp, #0x4c0]
    34b0:      	ldr	x9, [sp, #0x90]
    34b4:      	str	x9, [sp, #0x4c8]
    34b8:      	ldr	x9, [sp, #0x80]
    34bc:      	str	x9, [sp, #0x4d0]
    34c0:      	ldr	x9, [sp, #0x70]
    34c4:      	str	x9, [sp, #0x4d8]
    34c8:      	ldr	x9, [sp, #0x60]
    34cc:      	str	x9, [sp, #0x4e0]
    34d0:      	ldr	x9, [sp, #0x50]
    34d4:      	str	x9, [sp, #0x4e8]
    34d8:      	ldr	x9, [sp, #0x40]
    34dc:      	str	x9, [sp, #0x4f0]
    34e0:      	ldr	x9, [sp, #0x30]
    34e4:      	str	x9, [sp, #0x4f8]
    34e8:      	str	x25, [sp, #0x500]
    34ec:      	ldr	x9, [sp, #0xf0]
    34f0:      	str	x9, [sp, #0x508]
    34f4:      	str	x26, [sp, #0x510]
    34f8:      	str	x27, [sp, #0x518]
    34fc:      	str	x28, [sp, #0x520]
    3500:      	str	x20, [sp, #0x528]
    3504:      	str	x22, [sp, #0x530]
    3508:      	str	x21, [sp, #0x538]
    350c:      	str	x23, [sp, #0x540]
    3510:      	str	x19, [sp, #0x548]
    3514:      	str	q0, [sp, #0x550]
    3518:      	str	q1, [sp, #0x560]
    351c:      	str	q2, [sp, #0x570]
    3520:      	str	q3, [sp, #0x580]
    3524:      	ldr	x1, [sp, #0x130]
    3528:      	ldp	q1, q0, [sp, #0x130]
    352c:      	str	q0, [sp, #0x5b0]
    3530:      	ldr	x9, [sp, #0x150]
    3534:      	str	q4, [sp, #0x590]
    3538:      	str	q1, [sp, #0x5a0]
    353c:      	ldr	x10, [sp, #0x5b8]
    3540:      	stp	q1, q0, [x8]
    3544:      	adds	x8, x10, x9
    3548:      	csinv	x8, x8, xzr, lo
    354c:      	str	x9, [sp, #0x5c0]
    3550:      	str	x9, [sp, #0x5e8]
    3554:      	cmp	x1, #0x2
    3558:      	mov	x19, #0x7c15            ; =31765
    355c:      	movk	x19, #0x7f4a, lsl #16
    3560:      	movk	x19, #0x79b9, lsl #32
    3564:      	movk	x19, #0x9e37, lsl #48
    3568:      	b.hi	0x35c8 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x96c>
    356c:      	sub	x9, x1, x1, lsr #2
    3570:      	cmp	x8, x9
    3574:      	b.lo	0x35c8 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x96c>
    3578:      	ldp	q1, q0, [sp, #0x130]
    357c:      	str	q0, [sp, #0x600]
    3580:      	str	q1, [sp, #0x5f0]
    3584:      	ldr	x8, [sp, #0x150]
    3588:      	str	x8, [sp, #0x610]
    358c:      	ldr	x8, [sp, #0x608]
    3590:      	cmp	x8, x1, lsr #1
    3594:      	b.lo	0x35b0 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x954>
    3598:      	cbz	x1, 0x35ac <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x950>
    359c:      	cmp	x1, #0x1
    35a0:      	mov	w8, #0x2                ; =2
    35a4:      	cinc	x1, x8, ne
    35a8:      	b	0x35b0 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x954>
    35ac:      	mov	w1, #0x1                ; =1
    35b0:      	add	x0, sp, #0x130
    35b4:      	add	x2, sp, #0x160
    35b8:      	bl	0x35b8 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x95c>
		00000000000035b8:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07
    35bc:      	str	w0, [sp, #0x618]
    35c0:      	strb	w1, [sp, #0x61c]
    35c4:      	strb	w2, [sp, #0x61d]
    35c8:      	add	x0, sp, #0x170
    35cc:      	add	x1, sp, #0x130
    35d0:      	add	x3, sp, #0x4a0
    35d4:      	add	x4, sp, #0x160
    35d8:      	mov	w2, #0x7                ; =7
    35dc:      	bl	0x35dc <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x980>
		00000000000035dc:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07
    35e0:      	add	x0, sp, #0x170
    35e4:      	add	x1, sp, #0x110
    35e8:      	bl	0x35e8 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x98c>
		00000000000035e8:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
    35ec:      	add	x0, sp, #0x130
    35f0:      	add	x1, sp, #0x110
    35f4:      	bl	0x35f4 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x998>
		00000000000035f4:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146
    35f8:      	ldp	x8, x9, [sp, #0x110]
    35fc:      	ldp	x10, x11, [sp, #0x120]
    3600:      	eor	x8, x8, x8, lsr #30
    3604:      	mov	x12, #0xe5b9            ; =58809
    3608:      	movk	x12, #0x1ce4, lsl #16
    360c:      	movk	x12, #0x476d, lsl #32
    3610:      	movk	x12, #0xbf58, lsl #48
    3614:      	mul	x8, x8, x12
    3618:      	eor	x8, x8, x8, lsr #27
    361c:      	mov	x13, #0x11eb            ; =4587
    3620:      	movk	x13, #0x1331, lsl #16
    3624:      	movk	x13, #0x49bb, lsl #32
    3628:      	movk	x13, #0x94d0, lsl #48
    362c:      	mul	x8, x8, x13
    3630:      	eor	x9, x9, x9, lsr #30
    3634:      	mul	x9, x9, x12
    3638:      	eor	x9, x9, x9, lsr #27
    363c:      	mul	x9, x9, x13
    3640:      	eor	x12, x9, x8
    3644:      	mul	x11, x11, x19
    3648:      	eor	x10, x10, x11
    364c:      	eor	x10, x10, x12, lsr #31
    3650:      	eor	x8, x8, x9
    3654:      	eor	x0, x10, x8
    3658:      	add	sp, sp, #0x620
    365c:      	ldp	x29, x30, [sp, #0x50]
    3660:      	ldp	x20, x19, [sp, #0x40]
    3664:      	ldp	x22, x21, [sp, #0x30]
    3668:      	ldp	x24, x23, [sp, #0x20]
    366c:      	ldp	x26, x25, [sp, #0x10]
    3670:      	ldp	x28, x27, [sp], #0x60
    3674:      	ret
    3678:      	bl	0x3678 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0xa1c>
		0000000000003678:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000367c <_wf_map_cost_library_trace$instance$4250cb78d3f44027>:
    367c:      	stp	x28, x27, [sp, #-0x60]!
    3680:      	stp	x26, x25, [sp, #0x10]
    3684:      	stp	x24, x23, [sp, #0x20]
    3688:      	stp	x22, x21, [sp, #0x30]
    368c:      	stp	x20, x19, [sp, #0x40]
    3690:      	stp	x29, x30, [sp, #0x50]
    3694:      	mov	w9, #0x1ca0             ; =7328
    3698:      	adrp	x16, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003698:  ARM64_RELOC_GOT_LOAD_PAGE21	___chkstk_darwin
    369c:      	ldr	x16, [x16]
		000000000000369c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	___chkstk_darwin
    36a0:      	blr	x16
    36a4:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
    36a8:      	sub	sp, sp, #0xca0
    36ac:      	str	x4, [sp, #0x2e0]
    36b0:      	str	x2, [sp, #0xe8]
    36b4:      	mov	x19, x1
    36b8:      	mov	x20, x0
    36bc:      	add	x6, sp, #0x350
    36c0:      	mov	x8, #0x7c15             ; =31765
    36c4:      	movk	x8, #0x7f4a, lsl #16
    36c8:      	movk	x8, #0x79b9, lsl #32
    36cc:      	movk	x8, #0x9e37, lsl #48
    36d0:      	str	x3, [sp, #0xa0]
    36d4:      	eor	x8, x3, x8
    36d8:      	cmp	x5, #0x0
    36dc:      	cset	w9, ne
    36e0:      	mov	w10, #0x1768            ; =5992
    36e4:      	str	x8, [sp, #0x1ab0]
    36e8:      	strb	w9, [x6, x10]
    36ec:      	cbz	x0, 0x374c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xd0>
    36f0:      	add	x8, x20, x20, lsl #4
    36f4:      	lsl	x0, x8, #4
    36f8:      	bl	0x36f8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x7c>
		00000000000036f8:  ARM64_RELOC_BRANCH26	_malloc
    36fc:      	cbz	x0, 0x5a30 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x23b4>
    3700:      	mov	x8, #0x0                ; =0
    3704:      	add	x9, x0, #0x8
    3708:      	movi.2d	v0, #0000000000000000
    370c:      	stur	wzr, [x9, #-0x8]
    3710:      	add	x8, x8, #0x1
    3714:      	stp	q0, q0, [x9]
    3718:      	stp	q0, q0, [x9, #0x20]
    371c:      	stp	q0, q0, [x9, #0x40]
    3720:      	stp	q0, q0, [x9, #0x60]
    3724:      	stp	q0, q0, [x9, #0x80]
    3728:      	stp	q0, q0, [x9, #0xa0]
    372c:      	stp	q0, q0, [x9, #0xc0]
    3730:      	stp	q0, q0, [x9, #0xe0]
    3734:      	str	xzr, [x9, #0x100]
    3738:      	add	x9, x9, #0x110
    373c:      	cmp	x20, x8
    3740:      	b.ne	0x370c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x90>
    3744:      	add	x6, sp, #0x350
    3748:      	b	0x3754 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xd8>
    374c:      	adrp	x0, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		000000000000374c:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    3750:      	add	x0, x0, #0x0
		0000000000003750:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    3754:      	str	x20, [sp, #0x1ac0]
    3758:      	add	x8, x6, #0x104
    375c:      	str	x8, [sp, #0x228]
    3760:      	str	x20, [sp, #0x230]
    3764:      	str	x20, [sp, #0x1ac8]
    3768:      	mov	w8, #0x1770             ; =6000
    376c:      	str	x0, [sp, #0x1ad0]
    3770:      	movi.2d	v0, #0000000000000000
    3774:      	mov	w9, #0x1788             ; =6024
    3778:      	str	q0, [x6, x9]
    377c:      	add	x8, x6, x8
    3780:      	str	x8, [sp, #0x348]
    3784:      	mov	w8, #0x1798             ; =6040
    3788:      	ldr	x9, [sp, #0xa0]
    378c:      	str	x9, [sp, #0x1ae8]
    3790:      	add	x8, x6, x8
    3794:      	str	x8, [sp, #0x8]
    3798:      	str	xzr, [sp, #0x1af0]
    379c:      	str	xzr, [sp, #0x1b00]
    37a0:      	str	xzr, [sp, #0x1af8]
    37a4:      	str	x19, [sp, #0xc0]
    37a8:      	cbz	x19, 0x3c40 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x5c4>
    37ac:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		00000000000037ac:  ARM64_RELOC_PAGE21	lCPI68_0
    37b0:      	ldr	q0, [x8]
		00000000000037b0:  ARM64_RELOC_PAGEOFF12	lCPI68_0
    37b4:      	str	q0, [sp, #0x330]
    37b8:      	add	x19, x6, #0x318
    37bc:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		00000000000037bc:  ARM64_RELOC_PAGE21	lCPI68_1
    37c0:      	ldr	q0, [x8]
		00000000000037c0:  ARM64_RELOC_PAGEOFF12	lCPI68_1
    37c4:      	str	q0, [sp, #0x320]
    37c8:      	add	x20, sp, #0x1, lsl #12  ; =0x1000
    37cc:      	add	x20, x20, #0xb20
    37d0:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		00000000000037d0:  ARM64_RELOC_PAGE21	lCPI68_2
    37d4:      	ldr	q0, [x8]
		00000000000037d4:  ARM64_RELOC_PAGEOFF12	lCPI68_2
    37d8:      	str	q0, [sp, #0x310]
    37dc:      	add	x22, x20, #0x128
    37e0:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		00000000000037e0:  ARM64_RELOC_PAGE21	lCPI68_3
    37e4:      	ldr	q0, [x8]
		00000000000037e4:  ARM64_RELOC_PAGEOFF12	lCPI68_3
    37e8:      	str	q0, [sp, #0x300]
    37ec:      	add	x23, sp, #0x350
    37f0:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		00000000000037f0:  ARM64_RELOC_PAGE21	lCPI68_4
    37f4:      	ldr	q0, [x8]
		00000000000037f4:  ARM64_RELOC_PAGEOFF12	lCPI68_4
    37f8:      	str	q0, [sp, #0x2f0]
    37fc:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		00000000000037fc:  ARM64_RELOC_PAGE21	lCPI68_5
    3800:      	ldr	q0, [x8]
		0000000000003800:  ARM64_RELOC_PAGEOFF12	lCPI68_5
    3804:      	str	q0, [sp, #0x2d0]
    3808:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003808:  ARM64_RELOC_PAGE21	lCPI68_6
    380c:      	ldr	q0, [x8]
		000000000000380c:  ARM64_RELOC_PAGEOFF12	lCPI68_6
    3810:      	str	q0, [sp, #0x2c0]
    3814:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003814:  ARM64_RELOC_PAGE21	lCPI68_7
    3818:      	ldr	q0, [x8]
		0000000000003818:  ARM64_RELOC_PAGEOFF12	lCPI68_7
    381c:      	str	q0, [sp, #0x2b0]
    3820:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003820:  ARM64_RELOC_PAGE21	lCPI68_8
    3824:      	ldr	q0, [x8]
		0000000000003824:  ARM64_RELOC_PAGEOFF12	lCPI68_8
    3828:      	str	q0, [sp, #0x2a0]
    382c:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		000000000000382c:  ARM64_RELOC_PAGE21	lCPI68_9
    3830:      	ldr	q0, [x8]
		0000000000003830:  ARM64_RELOC_PAGEOFF12	lCPI68_9
    3834:      	str	q0, [sp, #0x290]
    3838:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003838:  ARM64_RELOC_PAGE21	lCPI68_10
    383c:      	ldr	q0, [x8]
		000000000000383c:  ARM64_RELOC_PAGEOFF12	lCPI68_10
    3840:      	str	q0, [sp, #0x280]
    3844:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003844:  ARM64_RELOC_PAGE21	lCPI68_11
    3848:      	ldr	q0, [x8]
		0000000000003848:  ARM64_RELOC_PAGEOFF12	lCPI68_11
    384c:      	str	q0, [sp, #0x270]
    3850:      	mov	w26, #0x83              ; =131
    3854:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003854:  ARM64_RELOC_PAGE21	lCPI68_12
    3858:      	ldr	q0, [x8]
		0000000000003858:  ARM64_RELOC_PAGEOFF12	lCPI68_12
    385c:      	str	q0, [sp, #0x260]
    3860:      	mov	w21, #0x1               ; =1
    3864:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003864:  ARM64_RELOC_PAGE21	lCPI68_13
    3868:      	ldr	q0, [x8]
		0000000000003868:  ARM64_RELOC_PAGEOFF12	lCPI68_13
    386c:      	str	q0, [sp, #0x250]
    3870:      	ldr	x27, [sp, #0xc0]
    3874:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003874:  ARM64_RELOC_PAGE21	lCPI68_14
    3878:      	ldr	q0, [x8]
		0000000000003878:  ARM64_RELOC_PAGEOFF12	lCPI68_14
    387c:      	str	q0, [sp, #0x240]
    3880:      	ldr	x28, [sp, #0xa0]
    3884:      	b	0x3a14 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x398>
    3888:      	ldr	x8, [sp, #0x228]
    388c:      	ldrb	w25, [x8]
    3890:      	add	x0, x24, #0x210
    3894:      	add	x1, x23, #0x108
    3898:      	mov	w2, #0x108              ; =264
    389c:      	bl	0x389c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x220>
		000000000000389c:  ARM64_RELOC_BRANCH26	_memcpy
    38a0:      	ldr	x8, [sp, #0x1ae8]
    38a4:      	cmp	w25, #0x0
    38a8:      	mov	w9, #0x1                ; =1
    38ac:      	cinc	x9, x9, ne
    38b0:      	madd	x8, x8, x26, x9
    38b4:      	ldr	x9, [sp, #0x560]
    38b8:      	ldp	q1, q0, [x23, #0x170]
    38bc:      	stp	q1, q0, [x19, #0x60]
    38c0:      	ldp	q1, q0, [x23, #0x150]
    38c4:      	stp	q1, q0, [x19, #0x40]
    38c8:      	ldp	q1, q0, [x23, #0x1b0]
    38cc:      	stp	q1, q0, [x19, #0xa0]
    38d0:      	ldp	q1, q0, [x23, #0x190]
    38d4:      	stp	q1, q0, [x19, #0x80]
    38d8:      	ldp	q1, q0, [x23, #0x1f0]
    38dc:      	stp	q1, q0, [x19, #0xe0]
    38e0:      	ldp	q1, q0, [x23, #0x1d0]
    38e4:      	stp	q1, q0, [x19, #0xc0]
    38e8:      	ldp	q1, q0, [x23, #0x130]
    38ec:      	stp	q1, q0, [x19, #0x20]
    38f0:      	ldp	q0, q1, [x23, #0x110]
    38f4:      	stp	q0, q1, [x19]
    38f8:      	ldr	x10, [sp, #0x668]
    38fc:      	madd	x9, x9, x26, x10
    3900:      	ldr	x10, [sp, #0x670]
    3904:      	madd	x9, x9, x26, x10
    3908:      	ldr	x10, [sp, #0x678]
    390c:      	madd	x9, x9, x26, x10
    3910:      	ldr	x10, [sp, #0x680]
    3914:      	madd	x9, x9, x26, x10
    3918:      	ldr	x10, [sp, #0x688]
    391c:      	madd	x9, x9, x26, x10
    3920:      	ldr	x10, [sp, #0x690]
    3924:      	madd	x9, x9, x26, x10
    3928:      	ldr	x10, [sp, #0x698]
    392c:      	madd	x9, x9, x26, x10
    3930:      	ldr	x10, [sp, #0x6a0]
    3934:      	madd	x9, x9, x26, x10
    3938:      	ldr	x10, [sp, #0x6a8]
    393c:      	madd	x9, x9, x26, x10
    3940:      	ldr	x10, [sp, #0x6b0]
    3944:      	madd	x9, x9, x26, x10
    3948:      	ldr	x10, [sp, #0x6b8]
    394c:      	madd	x9, x9, x26, x10
    3950:      	ldr	x10, [sp, #0x6c0]
    3954:      	madd	x9, x9, x26, x10
    3958:      	ldr	x10, [sp, #0x6c8]
    395c:      	madd	x9, x9, x26, x10
    3960:      	ldr	x10, [sp, #0x6d0]
    3964:      	madd	x9, x9, x26, x10
    3968:      	ldr	x10, [sp, #0x6d8]
    396c:      	madd	x9, x9, x26, x10
    3970:      	ldr	x10, [sp, #0x6e0]
    3974:      	madd	x9, x9, x26, x10
    3978:      	ldr	x10, [sp, #0x6e8]
    397c:      	madd	x9, x9, x26, x10
    3980:      	ldr	x10, [sp, #0x6f0]
    3984:      	madd	x9, x9, x26, x10
    3988:      	ldr	x10, [sp, #0x6f8]
    398c:      	madd	x9, x9, x26, x10
    3990:      	ldr	x10, [sp, #0x700]
    3994:      	madd	x9, x9, x26, x10
    3998:      	ldr	x10, [sp, #0x708]
    399c:      	madd	x9, x9, x26, x10
    39a0:      	ldr	x10, [sp, #0x710]
    39a4:      	madd	x9, x9, x26, x10
    39a8:      	ldr	x10, [sp, #0x718]
    39ac:      	madd	x9, x9, x26, x10
    39b0:      	ldr	x10, [sp, #0x720]
    39b4:      	madd	x9, x9, x26, x10
    39b8:      	ldr	x10, [sp, #0x728]
    39bc:      	madd	x9, x9, x26, x10
    39c0:      	ldr	x10, [sp, #0x730]
    39c4:      	madd	x9, x9, x26, x10
    39c8:      	ldr	x10, [sp, #0x738]
    39cc:      	madd	x9, x9, x26, x10
    39d0:      	ldr	x10, [sp, #0x740]
    39d4:      	madd	x9, x9, x26, x10
    39d8:      	ldr	x10, [sp, #0x748]
    39dc:      	madd	x9, x9, x26, x10
    39e0:      	ldr	x10, [sp, #0x750]
    39e4:      	madd	x9, x9, x26, x10
    39e8:      	ldr	x10, [sp, #0x758]
    39ec:      	add	x8, x8, x10
    39f0:      	madd	x8, x9, x26, x8
    39f4:      	ldr	x9, [sp, #0x760]
    39f8:      	madd	x8, x8, x26, x9
    39fc:      	str	x8, [sp, #0x1ae8]
    3a00:      	add	x28, x28, #0x1
    3a04:      	add	x21, x21, #0x2
    3a08:      	subs	x27, x27, #0x1
    3a0c:      	add	x6, sp, #0x350
    3a10:      	b.eq	0x3c40 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x5c4>
    3a14:      	add	x8, x28, #0x1f
    3a18:      	str	x28, [sp, #0x350]
    3a1c:      	dup.2d	v0, x28
    3a20:      	ldr	q1, [sp, #0x330]
    3a24:      	add.2d	v1, v0, v1
    3a28:      	add	x9, sp, #0x259
    3a2c:      	stur	q1, [x9, #0xff]
    3a30:      	ldr	q1, [sp, #0x320]
    3a34:      	add.2d	v1, v0, v1
    3a38:      	add	x9, sp, #0x269
    3a3c:      	stur	q1, [x9, #0xff]
    3a40:      	ldr	q1, [sp, #0x310]
    3a44:      	add.2d	v1, v0, v1
    3a48:      	add	x9, sp, #0x279
    3a4c:      	stur	q1, [x9, #0xff]
    3a50:      	ldr	q1, [sp, #0x300]
    3a54:      	add.2d	v1, v0, v1
    3a58:      	add	x9, sp, #0x289
    3a5c:      	stur	q1, [x9, #0xff]
    3a60:      	ldr	q1, [sp, #0x2f0]
    3a64:      	add.2d	v1, v0, v1
    3a68:      	add	x9, sp, #0x299
    3a6c:      	stur	q1, [x9, #0xff]
    3a70:      	ldr	q1, [sp, #0x2d0]
    3a74:      	add.2d	v1, v0, v1
    3a78:      	add	x9, sp, #0x2a9
    3a7c:      	stur	q1, [x9, #0xff]
    3a80:      	ldr	q1, [sp, #0x2c0]
    3a84:      	add.2d	v1, v0, v1
    3a88:      	add	x9, sp, #0x2b9
    3a8c:      	stur	q1, [x9, #0xff]
    3a90:      	ldr	q1, [sp, #0x2b0]
    3a94:      	add.2d	v1, v0, v1
    3a98:      	add	x9, sp, #0x2c9
    3a9c:      	stur	q1, [x9, #0xff]
    3aa0:      	ldr	q1, [sp, #0x2a0]
    3aa4:      	add.2d	v1, v0, v1
    3aa8:      	stur	q1, [x6, #0x88]
    3aac:      	ldr	q1, [sp, #0x290]
    3ab0:      	add.2d	v1, v0, v1
    3ab4:      	stur	q1, [x6, #0x98]
    3ab8:      	ldr	q1, [sp, #0x280]
    3abc:      	add.2d	v1, v0, v1
    3ac0:      	stur	q1, [x6, #0xa8]
    3ac4:      	ldr	q1, [sp, #0x270]
    3ac8:      	add.2d	v1, v0, v1
    3acc:      	stur	q1, [x6, #0xb8]
    3ad0:      	ldr	q1, [sp, #0x260]
    3ad4:      	add.2d	v1, v0, v1
    3ad8:      	stur	q1, [x6, #0xc8]
    3adc:      	ldr	q1, [sp, #0x250]
    3ae0:      	add.2d	v1, v0, v1
    3ae4:      	stur	q1, [x6, #0xd8]
    3ae8:      	ldr	q1, [sp, #0x240]
    3aec:      	add.2d	v0, v0, v1
    3af0:      	stur	q0, [x6, #0xe8]
    3af4:      	str	x8, [sp, #0x448]
    3af8:      	ldr	q0, [sp, #0x410]
    3afc:      	ldr	q1, [sp, #0x420]
    3b00:      	str	q0, [sp, #0x1be0]
    3b04:      	str	q1, [sp, #0x1bf0]
    3b08:      	ldr	q0, [sp, #0x430]
    3b0c:      	ldr	q1, [sp, #0x440]
    3b10:      	str	q0, [sp, #0x1c00]
    3b14:      	str	q1, [sp, #0x1c10]
    3b18:      	ldp	q0, q1, [sp, #0x3d0]
    3b1c:      	str	q0, [sp, #0x1ba0]
    3b20:      	str	q1, [sp, #0x1bb0]
    3b24:      	ldp	q0, q1, [sp, #0x3f0]
    3b28:      	str	q0, [sp, #0x1bc0]
    3b2c:      	str	q1, [sp, #0x1bd0]
    3b30:      	ldp	q0, q1, [sp, #0x390]
    3b34:      	str	q0, [sp, #0x1b60]
    3b38:      	str	q1, [sp, #0x1b70]
    3b3c:      	ldp	q0, q1, [sp, #0x3b0]
    3b40:      	str	q0, [sp, #0x1b80]
    3b44:      	str	q1, [sp, #0x1b90]
    3b48:      	ldp	q0, q1, [sp, #0x350]
    3b4c:      	str	q0, [sp, #0x1b20]
    3b50:      	str	q1, [sp, #0x1b30]
    3b54:      	ldp	q0, q1, [sp, #0x370]
    3b58:      	str	q0, [sp, #0x1b40]
    3b5c:      	str	q1, [sp, #0x1b50]
    3b60:      	ldr	x1, [sp, #0x1ac0]
    3b64:      	ldr	x9, [sp, #0x348]
    3b68:      	ldr	x8, [x9, #0x20]
    3b6c:      	str	x8, [x20, #0x120]
    3b70:      	ldp	q1, q0, [x9]
    3b74:      	stp	q1, q0, [x20, #0x100]
    3b78:      	str	x8, [x22, #0x20]
    3b7c:      	ldr	x8, [sp, #0x1c38]
    3b80:      	ldr	x9, [sp, #0x1c68]
    3b84:      	adds	x8, x8, x9
    3b88:      	csinv	x9, x8, xzr, lo
    3b8c:      	lsr	x8, x1, #14
    3b90:      	stp	q1, q0, [x22]
    3b94:      	cbnz	x8, 0x3c08 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x58c>
    3b98:      	sub	x8, x1, x1, lsr #2
    3b9c:      	cmp	x9, x8
    3ba0:      	b.lo	0x3c08 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x58c>
    3ba4:      	ldr	x10, [sp, #0x348]
    3ba8:      	ldr	x9, [x10, #0x20]
    3bac:      	str	x9, [x20, #0x170]
    3bb0:      	ldp	q1, q0, [x10]
    3bb4:      	stp	q1, q0, [x20, #0x150]
    3bb8:      	ldr	x9, [sp, #0x1c88]
    3bbc:      	cmp	x9, x8, lsr #1
    3bc0:      	b.lo	0x3be0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x564>
    3bc4:      	cbz	x1, 0x3bdc <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x560>
    3bc8:      	cmp	x1, #0x2, lsl #12       ; =0x2000
    3bcc:      	mov	w8, #0x2000             ; =8192
    3bd0:      	csel	x8, x1, x8, lo
    3bd4:      	lsl	x1, x8, #1
    3bd8:      	b	0x3be0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x564>
    3bdc:      	mov	w1, #0x1                ; =1
    3be0:      	mov	w8, #0x1760             ; =5984
    3be4:      	add	x2, x6, x8
    3be8:      	ldr	x0, [sp, #0x348]
    3bec:      	bl	0x3bec <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x570>
		0000000000003bec:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    3bf0:      	add	x6, sp, #0x350
    3bf4:      	str	w0, [sp, #0x1c98]
    3bf8:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
    3bfc:      	add	x8, x8, #0xb20
    3c00:      	strb	w1, [x8, #0x17c]
    3c04:      	strb	w2, [x8, #0x17d]
    3c08:      	add	x0, x6, #0x100
    3c0c:      	add	x3, sp, #0x1, lsl #12   ; =0x1000
    3c10:      	add	x3, x3, #0xb20
    3c14:      	add	x24, sp, #0x350
    3c18:      	mov	w8, #0x1760             ; =5984
    3c1c:      	add	x4, x24, x8
    3c20:      	ldr	x1, [sp, #0x348]
    3c24:      	mov	x2, x21
    3c28:      	bl	0x3c28 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x5ac>
		0000000000003c28:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
    3c2c:      	ldr	w8, [sp, #0x450]
    3c30:      	cbnz	w8, 0x3888 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x20c>
    3c34:      	ldr	x8, [sp, #0x1ae8]
    3c38:      	mul	x8, x8, x26
    3c3c:      	b	0x39fc <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x380>
    3c40:      	ldr	x8, [sp, #0xe8]
    3c44:      	ldr	x22, [sp, #0xc0]
    3c48:      	ldr	x23, [sp, #0x2e0]
    3c4c:      	cbz	x8, 0x595c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x22e0>
    3c50:      	ldr	x9, [sp, #0x230]
    3c54:      	lsl	x8, x9, #1
    3c58:      	cmp	x9, #0x0
    3c5c:      	csinc	x21, x8, xzr, ne
    3c60:      	cmp	x23, #0x1
    3c64:      	csel	x16, x22, xzr, eq
    3c68:      	add	x14, sp, #0x350
    3c6c:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
    3c70:      	add	x8, x8, #0xb20
    3c74:      	add	x8, x8, #0x128
    3c78:      	str	x8, [sp, #0x330]
    3c7c:      	cmp	x23, #0x5
    3c80:      	b.ne	0x480c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1190>
    3c84:      	mov	x10, #0x0               ; =0
    3c88:      	add	x20, x6, #0x418
    3c8c:      	add	x8, x6, #0x630
    3c90:      	str	x8, [sp, #0x1b0]
    3c94:      	add	x25, x6, #0x768
    3c98:      	add	x8, x6, #0xa80
    3c9c:      	str	x8, [sp, #0x210]
    3ca0:      	ldr	x9, [sp, #0x228]
    3ca4:      	add	x8, x9, #0x324
    3ca8:      	str	x8, [sp, #0x1a0]
    3cac:      	add	x8, x9, #0x334
    3cb0:      	str	x8, [sp, #0x190]
    3cb4:      	add	x8, x9, #0x344
    3cb8:      	str	x8, [sp, #0x180]
    3cbc:      	add	x8, x9, #0x354
    3cc0:      	str	x8, [sp, #0x170]
    3cc4:      	add	x8, x9, #0x364
    3cc8:      	str	x8, [sp, #0x160]
    3ccc:      	add	x8, x9, #0x374
    3cd0:      	str	x8, [sp, #0x150]
    3cd4:      	add	x8, x9, #0x384
    3cd8:      	str	x8, [sp, #0x140]
    3cdc:      	add	x8, x9, #0x394
    3ce0:      	str	x8, [sp, #0x130]
    3ce4:      	add	x8, x9, #0x3a4
    3ce8:      	str	x8, [sp, #0x120]
    3cec:      	add	x8, x9, #0x3b4
    3cf0:      	str	x8, [sp, #0x110]
    3cf4:      	add	x8, x9, #0x3c4
    3cf8:      	str	x8, [sp, #0x100]
    3cfc:      	add	x8, x9, #0x3d4
    3d00:      	str	x8, [sp, #0xf0]
    3d04:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003d04:  ARM64_RELOC_PAGE21	lCPI68_0
    3d08:      	ldr	q0, [x8]
		0000000000003d08:  ARM64_RELOC_PAGEOFF12	lCPI68_0
    3d0c:      	str	q0, [sp, #0x310]
    3d10:      	add	x8, x9, #0x3e4
    3d14:      	str	x8, [sp, #0xe0]
    3d18:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003d18:  ARM64_RELOC_PAGE21	lCPI68_1
    3d1c:      	ldr	q0, [x8]
		0000000000003d1c:  ARM64_RELOC_PAGEOFF12	lCPI68_1
    3d20:      	str	q0, [sp, #0x300]
    3d24:      	add	x8, x9, #0x3f4
    3d28:      	str	x8, [sp, #0xd8]
    3d2c:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003d2c:  ARM64_RELOC_PAGE21	lCPI68_2
    3d30:      	ldr	q0, [x8]
		0000000000003d30:  ARM64_RELOC_PAGEOFF12	lCPI68_2
    3d34:      	str	q0, [sp, #0x2f0]
    3d38:      	add	x8, x9, #0x404
    3d3c:      	str	x8, [sp, #0xd0]
    3d40:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003d40:  ARM64_RELOC_PAGE21	lCPI68_3
    3d44:      	ldr	q0, [x8]
		0000000000003d44:  ARM64_RELOC_PAGEOFF12	lCPI68_3
    3d48:      	str	q0, [sp, #0x2e0]
    3d4c:      	add	x8, x9, #0x414
    3d50:      	str	x8, [sp, #0xc8]
    3d54:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003d54:  ARM64_RELOC_PAGE21	lCPI68_4
    3d58:      	ldr	q0, [x8]
		0000000000003d58:  ARM64_RELOC_PAGEOFF12	lCPI68_4
    3d5c:      	str	q0, [sp, #0x2d0]
    3d60:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003d60:  ARM64_RELOC_PAGE21	lCPI68_5
    3d64:      	ldr	q0, [x8]
		0000000000003d64:  ARM64_RELOC_PAGEOFF12	lCPI68_5
    3d68:      	str	q0, [sp, #0x2c0]
    3d6c:      	sub	x8, x22, x22, lsr #1
    3d70:      	adrp	x9, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003d70:  ARM64_RELOC_PAGE21	lCPI68_6
    3d74:      	ldr	q0, [x9]
		0000000000003d74:  ARM64_RELOC_PAGEOFF12	lCPI68_6
    3d78:      	str	q0, [sp, #0x2b0]
    3d7c:      	cmp	x8, #0x1
    3d80:      	adrp	x9, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003d80:  ARM64_RELOC_PAGE21	lCPI68_7
    3d84:      	ldr	q0, [x9]
		0000000000003d84:  ARM64_RELOC_PAGEOFF12	lCPI68_7
    3d88:      	str	q0, [sp, #0x2a0]
    3d8c:      	csinc	x8, x8, xzr, hi
    3d90:      	str	x8, [sp, #0x320]
    3d94:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003d94:  ARM64_RELOC_PAGE21	lCPI68_8
    3d98:      	ldr	q0, [x8]
		0000000000003d98:  ARM64_RELOC_PAGEOFF12	lCPI68_8
    3d9c:      	str	q0, [sp, #0x290]
    3da0:      	add	x19, x14, #0x878
    3da4:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003da4:  ARM64_RELOC_PAGE21	lCPI68_9
    3da8:      	ldr	q0, [x8]
		0000000000003da8:  ARM64_RELOC_PAGEOFF12	lCPI68_9
    3dac:      	str	q0, [sp, #0x280]
    3db0:      	ldr	x8, [sp, #0xa0]
    3db4:      	add	x8, x8, x22
    3db8:      	str	x8, [sp, #0x1d0]
    3dbc:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003dbc:  ARM64_RELOC_PAGE21	lCPI68_10
    3dc0:      	ldr	q0, [x8]
		0000000000003dc0:  ARM64_RELOC_PAGEOFF12	lCPI68_10
    3dc4:      	str	q0, [sp, #0x270]
    3dc8:      	mov	w26, #0x83              ; =131
    3dcc:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003dcc:  ARM64_RELOC_PAGE21	lCPI68_11
    3dd0:      	ldr	q0, [x8]
		0000000000003dd0:  ARM64_RELOC_PAGEOFF12	lCPI68_11
    3dd4:      	str	q0, [sp, #0x260]
    3dd8:      	mov	w15, #0x1               ; =1
    3ddc:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003ddc:  ARM64_RELOC_PAGE21	lCPI68_12
    3de0:      	ldr	q0, [x8]
		0000000000003de0:  ARM64_RELOC_PAGEOFF12	lCPI68_12
    3de4:      	str	q0, [sp, #0x250]
    3de8:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003de8:  ARM64_RELOC_PAGE21	lCPI68_13
    3dec:      	ldr	q0, [x8]
		0000000000003dec:  ARM64_RELOC_PAGEOFF12	lCPI68_13
    3df0:      	str	q0, [sp, #0x240]
    3df4:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x3a4>
		0000000000003df4:  ARM64_RELOC_PAGE21	lCPI68_14
    3df8:      	ldr	q0, [x8]
		0000000000003df8:  ARM64_RELOC_PAGEOFF12	lCPI68_14
    3dfc:      	str	q0, [sp, #0x230]
    3e00:      	mov	w24, #0x110             ; =272
    3e04:      	b	0x3e30 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x7b4>
    3e08:      	ldr	x10, [sp, #0x1e0]
    3e0c:      	add	x10, x10, #0x1
    3e10:      	add	x6, sp, #0x350
    3e14:      	mov	w15, #0x1               ; =1
    3e18:      	ldr	x8, [sp, #0x1d0]
    3e1c:      	add	x8, x8, x22
    3e20:      	str	x8, [sp, #0x1d0]
    3e24:      	ldr	x8, [sp, #0xe8]
    3e28:      	cmp	x10, x8
    3e2c:      	b.eq	0x595c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x22e0>
    3e30:      	str	x10, [sp, #0x1e0]
    3e34:      	ldr	x21, [sp, #0x1ac0]
    3e38:      	cbz	x22, 0x42d4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xc58>
    3e3c:      	mov	x28, #0x0               ; =0
    3e40:      	ldr	x17, [sp, #0x1ad8]
    3e44:      	ldr	x23, [sp, #0x1ab0]
    3e48:      	mov	w8, #0x1768             ; =5992
    3e4c:      	ldrb	w0, [x6, x8]
    3e50:      	ldr	x22, [sp, #0x1ad0]
    3e54:      	ldr	x2, [sp, #0x1ae0]
    3e58:      	mov	x27, #0x11eb            ; =4587
    3e5c:      	movk	x27, #0x1331, lsl #16
    3e60:      	movk	x27, #0x49bb, lsl #32
    3e64:      	movk	x27, #0x94d0, lsl #48
    3e68:      	str	w0, [sp, #0x1c0]
    3e6c:      	b	0x3e94 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x818>
    3e70:      	str	w15, [sp, #0xa80]
    3e74:      	str	xzr, [sp, #0xa88]
    3e78:      	mul	x8, x8, x26
    3e7c:      	strb	wzr, [sp, #0xa90]
    3e80:      	str	x8, [sp, #0x1ae8]
    3e84:      	add	x28, x28, #0x1
    3e88:      	ldr	x8, [sp, #0x320]
    3e8c:      	cmp	x28, x8
    3e90:      	b.eq	0x42e8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xc6c>
    3e94:      	orr	x8, x15, x28, lsl #2
    3e98:      	str	x8, [sp, #0x1b08]
    3e9c:      	cbz	x17, 0x4204 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xb88>
    3ea0:      	tbz	w0, #0x0, 0x3eb0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x834>
    3ea4:      	mov	x9, #0x0                ; =0
    3ea8:      	cbnz	x21, 0x3edc <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x860>
    3eac:      	b	0x4204 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xb88>
    3eb0:      	eor	x9, x23, x8
    3eb4:      	eor	x9, x9, x9, lsr #30
    3eb8:      	mov	x10, #0xe5b9            ; =58809
    3ebc:      	movk	x10, #0x1ce4, lsl #16
    3ec0:      	movk	x10, #0x476d, lsl #32
    3ec4:      	movk	x10, #0xbf58, lsl #48
    3ec8:      	mul	x9, x9, x10
    3ecc:      	eor	x9, x9, x9, lsr #27
    3ed0:      	mul	x9, x9, x27
    3ed4:      	eor	x9, x9, x9, lsr #31
    3ed8:      	cbz	x21, 0x4204 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xb88>
    3edc:      	udiv	x10, x9, x21
    3ee0:      	msub	x10, x10, x21, x9
    3ee4:      	mov	x11, x21
    3ee8:      	b	0x3f00 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x884>
    3eec:      	add	x9, x10, #0x1
    3ef0:      	cmp	x9, x21
    3ef4:      	csinc	x10, xzr, x10, hs
    3ef8:      	subs	x11, x11, #0x1
    3efc:      	b.eq	0x4204 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xb88>
    3f00:      	madd	x9, x10, x24, x22
    3f04:      	ldr	w12, [x9]
    3f08:      	cmp	w12, #0x1
    3f0c:      	b.eq	0x3eec <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x870>
    3f10:      	cmp	w12, #0x2
    3f14:      	b.ne	0x4204 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xb88>
    3f18:      	ldr	x12, [x9, #0x8]
    3f1c:      	cmp	x12, x8
    3f20:      	b.ne	0x3eec <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x870>
    3f24:      	str	w15, [x9]
    3f28:      	sub	x17, x17, #0x1
    3f2c:      	str	x17, [sp, #0x200]
    3f30:      	adds	x10, x2, #0x1
    3f34:      	csinv	x10, x10, xzr, lo
    3f38:      	str	x10, [sp, #0x1f0]
    3f3c:      	ldp	q0, q1, [x9, #0x10]
    3f40:      	ldp	q2, q3, [x9, #0x30]
    3f44:      	ldp	q4, q5, [x9, #0x50]
    3f48:      	ldp	q6, q7, [x9, #0x70]
    3f4c:      	ldp	q16, q17, [x9, #0x90]
    3f50:      	ldp	q18, q19, [x9, #0xb0]
    3f54:      	ldp	q20, q21, [x9, #0xd0]
    3f58:      	ldp	q22, q23, [x9, #0xf0]
    3f5c:      	movi.2d	v24, #0000000000000000
    3f60:      	stur	q24, [x9, #0x18]
    3f64:      	stur	q24, [x9, #0x28]
    3f68:      	stur	q24, [x9, #0x38]
    3f6c:      	stur	q24, [x9, #0x48]
    3f70:      	stur	q24, [x9, #0x58]
    3f74:      	stur	q24, [x9, #0x68]
    3f78:      	stur	q24, [x9, #0x78]
    3f7c:      	stur	q24, [x9, #0x88]
    3f80:      	stur	q24, [x9, #0x98]
    3f84:      	stur	q24, [x9, #0xa8]
    3f88:      	stur	q24, [x9, #0xb8]
    3f8c:      	stur	q24, [x9, #0xc8]
    3f90:      	stur	q24, [x9, #0xd8]
    3f94:      	stur	q24, [x9, #0xe8]
    3f98:      	stur	q24, [x9, #0xf8]
    3f9c:      	stur	q24, [x9, #0x8]
    3fa0:      	str	xzr, [x9, #0x108]
    3fa4:      	str	x17, [sp, #0x1ad8]
    3fa8:      	str	x10, [sp, #0x1ae0]
    3fac:      	str	x15, [sp, #0x768]
    3fb0:      	str	x8, [sp, #0x770]
    3fb4:      	ldr	x27, [sp, #0x1a0]
    3fb8:      	str	q0, [x27]
    3fbc:      	ldr	x8, [sp, #0x190]
    3fc0:      	str	q1, [x8]
    3fc4:      	ldr	x8, [sp, #0x180]
    3fc8:      	str	q2, [x8]
    3fcc:      	ldr	x8, [sp, #0x170]
    3fd0:      	str	q3, [x8]
    3fd4:      	ldr	x8, [sp, #0x160]
    3fd8:      	str	q4, [x8]
    3fdc:      	ldr	x8, [sp, #0x150]
    3fe0:      	str	q5, [x8]
    3fe4:      	ldr	x8, [sp, #0x140]
    3fe8:      	str	q6, [x8]
    3fec:      	ldr	x8, [sp, #0x130]
    3ff0:      	str	q7, [x8]
    3ff4:      	ldr	x8, [sp, #0x120]
    3ff8:      	str	q16, [x8]
    3ffc:      	ldr	x8, [sp, #0x110]
    4000:      	str	q17, [x8]
    4004:      	ldr	x8, [sp, #0x100]
    4008:      	str	q18, [x8]
    400c:      	ldr	x8, [sp, #0xf0]
    4010:      	str	q19, [x8]
    4014:      	ldp	x8, x9, [sp, #0xd8]
    4018:      	str	q20, [x9]
    401c:      	str	q21, [x8]
    4020:      	ldp	x8, x9, [sp, #0xc8]
    4024:      	str	q22, [x9]
    4028:      	str	q23, [x8]
    402c:      	add	x0, x6, #0x528
    4030:      	add	x8, sp, #0x350
    4034:      	add	x1, x8, #0x420
    4038:      	mov	w2, #0x108              ; =264
    403c:      	bl	0x403c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x9c0>
		000000000000403c:  ARM64_RELOC_BRANCH26	_memcpy
    4040:      	ldr	x2, [sp, #0x1f0]
    4044:      	ldr	w0, [sp, #0x1c0]
    4048:      	ldr	x17, [sp, #0x200]
    404c:      	mov	w15, #0x1               ; =1
    4050:      	add	x6, sp, #0x350
    4054:      	ldr	x8, [sp, #0x1ae8]
    4058:      	ldr	x9, [sp, #0x878]
    405c:      	ldp	q1, q0, [x27, #0x20]
    4060:      	ldr	x10, [sp, #0x1b0]
    4064:      	stp	q1, q0, [x10, #0x20]
    4068:      	ldp	q1, q0, [x27, #0x60]
    406c:      	stp	q1, q0, [x10, #0x60]
    4070:      	ldp	q1, q0, [x27, #0x40]
    4074:      	stp	q1, q0, [x10, #0x40]
    4078:      	ldp	q1, q0, [x27, #0xa0]
    407c:      	stp	q1, q0, [x10, #0xa0]
    4080:      	ldp	q1, q0, [x27, #0x80]
    4084:      	stp	q1, q0, [x10, #0x80]
    4088:      	ldp	q1, q0, [x27, #0xe0]
    408c:      	stp	q1, q0, [x10, #0xe0]
    4090:      	ldp	q1, q0, [x27, #0xc0]
    4094:      	stp	q1, q0, [x10, #0xc0]
    4098:      	ldp	q1, q0, [x27]
    409c:      	mov	x27, #0x11eb            ; =4587
    40a0:      	movk	x27, #0x1331, lsl #16
    40a4:      	movk	x27, #0x49bb, lsl #32
    40a8:      	movk	x27, #0x94d0, lsl #48
    40ac:      	stp	q1, q0, [x10]
    40b0:      	ldr	x10, [sp, #0xa70]
    40b4:      	madd	x8, x8, x26, x10
    40b8:      	ldr	x10, [sp, #0x980]
    40bc:      	madd	x9, x9, x26, x10
    40c0:      	ldr	x10, [sp, #0x988]
    40c4:      	madd	x9, x9, x26, x10
    40c8:      	ldr	x10, [sp, #0x990]
    40cc:      	madd	x9, x9, x26, x10
    40d0:      	ldr	x10, [sp, #0x998]
    40d4:      	madd	x9, x9, x26, x10
    40d8:      	ldr	x10, [sp, #0x9a0]
    40dc:      	madd	x9, x9, x26, x10
    40e0:      	ldr	x10, [sp, #0x9a8]
    40e4:      	madd	x9, x9, x26, x10
    40e8:      	ldr	x10, [sp, #0x9b0]
    40ec:      	madd	x9, x9, x26, x10
    40f0:      	ldr	x10, [sp, #0x9b8]
    40f4:      	madd	x9, x9, x26, x10
    40f8:      	ldr	x10, [sp, #0x9c0]
    40fc:      	madd	x9, x9, x26, x10
    4100:      	ldr	x10, [sp, #0x9c8]
    4104:      	madd	x9, x9, x26, x10
    4108:      	ldr	x10, [sp, #0x9d0]
    410c:      	madd	x9, x9, x26, x10
    4110:      	ldr	x10, [sp, #0x9d8]
    4114:      	madd	x9, x9, x26, x10
    4118:      	ldr	x10, [sp, #0x9e0]
    411c:      	madd	x9, x9, x26, x10
    4120:      	ldr	x10, [sp, #0x9e8]
    4124:      	madd	x9, x9, x26, x10
    4128:      	ldr	x10, [sp, #0x9f0]
    412c:      	madd	x9, x9, x26, x10
    4130:      	ldr	x10, [sp, #0x9f8]
    4134:      	madd	x9, x9, x26, x10
    4138:      	ldr	x10, [sp, #0xa00]
    413c:      	madd	x9, x9, x26, x10
    4140:      	ldr	x10, [sp, #0xa08]
    4144:      	madd	x9, x9, x26, x10
    4148:      	ldr	x10, [sp, #0xa10]
    414c:      	madd	x9, x9, x26, x10
    4150:      	ldr	x10, [sp, #0xa18]
    4154:      	madd	x9, x9, x26, x10
    4158:      	ldr	x10, [sp, #0xa20]
    415c:      	madd	x9, x9, x26, x10
    4160:      	ldr	x10, [sp, #0xa28]
    4164:      	madd	x9, x9, x26, x10
    4168:      	ldr	x10, [sp, #0xa30]
    416c:      	madd	x9, x9, x26, x10
    4170:      	ldr	x10, [sp, #0xa38]
    4174:      	madd	x9, x9, x26, x10
    4178:      	ldr	x10, [sp, #0xa40]
    417c:      	madd	x9, x9, x26, x10
    4180:      	ldr	x10, [sp, #0xa48]
    4184:      	madd	x9, x9, x26, x10
    4188:      	ldr	x10, [sp, #0xa50]
    418c:      	madd	x9, x9, x26, x10
    4190:      	ldr	x10, [sp, #0xa58]
    4194:      	madd	x9, x9, x26, x10
    4198:      	ldr	x10, [sp, #0xa60]
    419c:      	madd	x9, x9, x26, x10
    41a0:      	ldr	x10, [sp, #0xa68]
    41a4:      	madd	x9, x9, x26, x10
    41a8:      	madd	x8, x9, x26, x8
    41ac:      	ldr	x9, [sp, #0xa78]
    41b0:      	madd	x8, x8, x26, x9
    41b4:      	add	x8, x8, #0x83
    41b8:      	str	x8, [sp, #0x1ae8]
    41bc:      	mov	w9, #0x1768             ; =5992
    41c0:      	ldrb	w9, [x6, x9]
    41c4:      	tbnz	w9, #0x0, 0x4244 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xbc8>
    41c8:      	ldr	x9, [sp, #0x1ab0]
    41cc:      	ldr	x10, [sp, #0x1b08]
    41d0:      	eor	x9, x10, x9
    41d4:      	eor	x9, x9, x9, lsr #30
    41d8:      	mov	x10, #0xe5b9            ; =58809
    41dc:      	movk	x10, #0x1ce4, lsl #16
    41e0:      	movk	x10, #0x476d, lsl #32
    41e4:      	movk	x10, #0xbf58, lsl #48
    41e8:      	mul	x9, x9, x10
    41ec:      	eor	x9, x9, x9, lsr #27
    41f0:      	mul	x9, x9, x27
    41f4:      	eor	x9, x9, x9, lsr #31
    41f8:      	ldr	x1, [sp, #0x1ac0]
    41fc:      	cbnz	x1, 0x4250 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xbd4>
    4200:      	b	0x3e70 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x7f4>
    4204:      	movi.2d	v0, #0000000000000000
    4208:      	stp	q0, q0, [x20, #0xf0]
    420c:      	stp	q0, q0, [x20, #0xd0]
    4210:      	stp	q0, q0, [x20, #0xb0]
    4214:      	stp	q0, q0, [x20, #0x90]
    4218:      	stp	q0, q0, [x20, #0x70]
    421c:      	stp	q0, q0, [x20, #0x50]
    4220:      	stp	q0, q0, [x20, #0x30]
    4224:      	stp	q0, q0, [x20, #0x10]
    4228:      	ldr	x8, [sp, #0x1ae8]
    422c:      	mul	x8, x8, x26
    4230:      	str	q0, [x20]
    4234:      	str	x8, [sp, #0x1ae8]
    4238:      	mov	w9, #0x1768             ; =5992
    423c:      	ldrb	w9, [x6, x9]
    4240:      	tbz	w9, #0x0, 0x41c8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xb4c>
    4244:      	mov	x9, #0x0                ; =0
    4248:      	ldr	x1, [sp, #0x1ac0]
    424c:      	cbz	x1, 0x3e70 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x7f4>
    4250:      	udiv	x10, x9, x1
    4254:      	msub	x9, x10, x1, x9
    4258:      	ldr	x10, [sp, #0x1ad0]
    425c:      	ldr	x11, [sp, #0x1b08]
    4260:      	mov	x12, x1
    4264:      	b	0x427c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xc00>
    4268:      	add	x13, x9, #0x1
    426c:      	cmp	x13, x1
    4270:      	csinc	x9, xzr, x9, hs
    4274:      	subs	x12, x12, #0x1
    4278:      	b.eq	0x3e70 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x7f4>
    427c:      	madd	x13, x9, x24, x10
    4280:      	ldr	w14, [x13]
    4284:      	cmp	w14, #0x1
    4288:      	b.eq	0x4268 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xbec>
    428c:      	cmp	w14, #0x2
    4290:      	b.ne	0x3e70 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x7f4>
    4294:      	ldr	x14, [x13, #0x8]
    4298:      	cmp	x14, x11
    429c:      	b.ne	0x4268 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xbec>
    42a0:      	ldr	x9, [x13, #0x10]
    42a4:      	str	wzr, [sp, #0xa80]
    42a8:      	str	x9, [sp, #0xa88]
    42ac:      	strb	wzr, [sp, #0xa90]
    42b0:      	mov	w10, #0x4309            ; =17161
    42b4:      	madd	x8, x8, x10, x9
    42b8:      	add	x8, x8, #0x83
    42bc:      	str	x8, [sp, #0x1ae8]
    42c0:      	add	x28, x28, #0x1
    42c4:      	ldr	x8, [sp, #0x320]
    42c8:      	cmp	x28, x8
    42cc:      	b.ne	0x3e94 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x818>
    42d0:      	b	0x42e8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xc6c>
    42d4:      	mov	x1, x21
    42d8:      	mov	x27, #0x11eb            ; =4587
    42dc:      	movk	x27, #0x1331, lsl #16
    42e0:      	movk	x27, #0x49bb, lsl #32
    42e4:      	movk	x27, #0x94d0, lsl #48
    42e8:      	mov	w8, #0x1760             ; =5984
    42ec:      	add	x2, x6, x8
    42f0:      	ldr	x28, [sp, #0x348]
    42f4:      	mov	x0, x28
    42f8:      	add	x21, sp, #0x350
    42fc:      	bl	0x42fc <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xc80>
		00000000000042fc:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    4300:      	str	w0, [sp, #0xa98]
    4304:      	strb	w1, [sp, #0xa9c]
    4308:      	strb	w2, [sp, #0xa9d]
    430c:      	cmp	w0, #0x0
    4310:      	ldr	x8, [sp, #0x1ae8]
    4314:      	mul	x8, x8, x26
    4318:      	cinc	x8, x8, eq
    431c:      	str	x8, [sp, #0x1ae8]
    4320:      	ldr	x22, [sp, #0xc0]
    4324:      	cbz	x22, 0x3e08 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x78c>
    4328:      	mov	x9, #0x0                ; =0
    432c:      	ldr	x10, [sp, #0x1ab0]
    4330:      	mov	w11, #0x1768            ; =5992
    4334:      	ldrb	w11, [x21, x11]
    4338:      	ldr	x12, [sp, #0x1ac0]
    433c:      	ldr	x13, [sp, #0x1ad0]
    4340:      	add	x6, sp, #0x350
    4344:      	ldr	x1, [sp, #0x1e0]
    4348:      	mov	w2, #0x1                ; =1
    434c:      	b	0x4370 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xcf4>
    4350:      	str	w2, [sp, #0xaa0]
    4354:      	str	xzr, [sp, #0xaa8]
    4358:      	mul	x8, x8, x26
    435c:      	strb	wzr, [sp, #0xab0]
    4360:      	str	x8, [sp, #0x1ae8]
    4364:      	add	x9, x9, #0x1
    4368:      	cmp	x9, x22
    436c:      	b.eq	0x4428 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xdac>
    4370:      	orr	x14, x2, x9, lsl #1
    4374:      	str	x14, [sp, #0x1b10]
    4378:      	tbz	w11, #0x0, 0x4388 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xd0c>
    437c:      	mov	x15, #0x0               ; =0
    4380:      	cbnz	x12, 0x43b4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xd38>
    4384:      	b	0x4350 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xcd4>
    4388:      	eor	x15, x10, x14
    438c:      	eor	x15, x15, x15, lsr #30
    4390:      	mov	x16, #0xe5b9            ; =58809
    4394:      	movk	x16, #0x1ce4, lsl #16
    4398:      	movk	x16, #0x476d, lsl #32
    439c:      	movk	x16, #0xbf58, lsl #48
    43a0:      	mul	x15, x15, x16
    43a4:      	eor	x15, x15, x15, lsr #27
    43a8:      	mul	x15, x15, x27
    43ac:      	eor	x15, x15, x15, lsr #31
    43b0:      	cbz	x12, 0x4350 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xcd4>
    43b4:      	udiv	x16, x15, x12
    43b8:      	msub	x15, x16, x12, x15
    43bc:      	mov	x16, x12
    43c0:      	b	0x43d8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xd5c>
    43c4:      	add	x17, x15, #0x1
    43c8:      	cmp	x17, x12
    43cc:      	csinc	x15, xzr, x15, hs
    43d0:      	subs	x16, x16, #0x1
    43d4:      	b.eq	0x4350 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xcd4>
    43d8:      	madd	x17, x15, x24, x13
    43dc:      	ldr	w0, [x17]
    43e0:      	cmp	w0, #0x1
    43e4:      	b.eq	0x43c4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xd48>
    43e8:      	cmp	w0, #0x2
    43ec:      	b.ne	0x4350 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xcd4>
    43f0:      	ldr	x0, [x17, #0x8]
    43f4:      	cmp	x0, x14
    43f8:      	b.ne	0x43c4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xd48>
    43fc:      	ldr	x14, [x17, #0x10]
    4400:      	str	wzr, [sp, #0xaa0]
    4404:      	str	x14, [sp, #0xaa8]
    4408:      	strb	wzr, [sp, #0xab0]
    440c:      	mov	w15, #0x4309            ; =17161
    4410:      	madd	x8, x8, x15, x14
    4414:      	add	x8, x8, #0x83
    4418:      	str	x8, [sp, #0x1ae8]
    441c:      	add	x9, x9, #0x1
    4420:      	cmp	x9, x22
    4424:      	b.ne	0x4370 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xcf4>
    4428:      	add	x1, x1, #0x1
    442c:      	str	x1, [sp, #0x1e0]
    4430:      	ldr	x22, [sp, #0x1d0]
    4434:      	mov	w21, #0x1               ; =1
    4438:      	ldr	x23, [sp, #0x320]
    443c:      	b	0x4464 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xde8>
    4440:      	ldr	x8, [sp, #0x1ae8]
    4444:      	mul	x8, x8, x26
    4448:      	mov	w15, #0x1               ; =1
    444c:      	str	x8, [sp, #0x1ae8]
    4450:      	add	x21, x21, #0x4
    4454:      	add	x22, x22, #0x2
    4458:      	subs	x23, x23, #0x1
    445c:      	add	x6, sp, #0x350
    4460:      	b.eq	0x4800 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1184>
    4464:      	add	x8, x22, #0x1f
    4468:      	str	x22, [sp, #0xab8]
    446c:      	dup.2d	v0, x22
    4470:      	ldr	q1, [sp, #0x310]
    4474:      	add.2d	v1, v0, v1
    4478:      	str	q1, [sp, #0xac0]
    447c:      	ldr	q1, [sp, #0x300]
    4480:      	add.2d	v1, v0, v1
    4484:      	str	q1, [sp, #0xad0]
    4488:      	ldr	q1, [sp, #0x2f0]
    448c:      	add.2d	v1, v0, v1
    4490:      	str	q1, [sp, #0xae0]
    4494:      	ldr	q1, [sp, #0x2e0]
    4498:      	add.2d	v1, v0, v1
    449c:      	str	q1, [sp, #0xaf0]
    44a0:      	ldr	q1, [sp, #0x2d0]
    44a4:      	add.2d	v1, v0, v1
    44a8:      	str	q1, [sp, #0xb00]
    44ac:      	ldr	q1, [sp, #0x2c0]
    44b0:      	add.2d	v1, v0, v1
    44b4:      	str	q1, [sp, #0xb10]
    44b8:      	ldr	q1, [sp, #0x2b0]
    44bc:      	add.2d	v1, v0, v1
    44c0:      	str	q1, [sp, #0xb20]
    44c4:      	ldr	q1, [sp, #0x2a0]
    44c8:      	add.2d	v1, v0, v1
    44cc:      	str	q1, [sp, #0xb30]
    44d0:      	ldr	q1, [sp, #0x290]
    44d4:      	add.2d	v1, v0, v1
    44d8:      	str	q1, [sp, #0xb40]
    44dc:      	ldr	q1, [sp, #0x280]
    44e0:      	add.2d	v1, v0, v1
    44e4:      	str	q1, [sp, #0xb50]
    44e8:      	ldr	q1, [sp, #0x270]
    44ec:      	add.2d	v1, v0, v1
    44f0:      	str	q1, [sp, #0xb60]
    44f4:      	ldr	q1, [sp, #0x260]
    44f8:      	add.2d	v1, v0, v1
    44fc:      	str	q1, [sp, #0xb70]
    4500:      	ldr	q1, [sp, #0x250]
    4504:      	add.2d	v1, v0, v1
    4508:      	str	q1, [sp, #0xb80]
    450c:      	ldr	q1, [sp, #0x240]
    4510:      	add.2d	v1, v0, v1
    4514:      	str	q1, [sp, #0xb90]
    4518:      	ldr	q1, [sp, #0x230]
    451c:      	add.2d	v0, v0, v1
    4520:      	str	q0, [sp, #0xba0]
    4524:      	str	x8, [sp, #0xbb0]
    4528:      	ldp	q0, q1, [x25, #0xc0]
    452c:      	str	q0, [sp, #0x1be0]
    4530:      	str	q1, [sp, #0x1bf0]
    4534:      	ldp	q0, q1, [x25, #0xe0]
    4538:      	str	q0, [sp, #0x1c00]
    453c:      	str	q1, [sp, #0x1c10]
    4540:      	ldp	q0, q1, [x25, #0x80]
    4544:      	str	q0, [sp, #0x1ba0]
    4548:      	str	q1, [sp, #0x1bb0]
    454c:      	ldp	q0, q1, [x25, #0xa0]
    4550:      	str	q0, [sp, #0x1bc0]
    4554:      	str	q1, [sp, #0x1bd0]
    4558:      	ldp	q0, q1, [x25, #0x40]
    455c:      	str	q0, [sp, #0x1b60]
    4560:      	str	q1, [sp, #0x1b70]
    4564:      	ldp	q0, q1, [x25, #0x60]
    4568:      	str	q0, [sp, #0x1b80]
    456c:      	str	q1, [sp, #0x1b90]
    4570:      	ldp	q0, q1, [x25]
    4574:      	str	q0, [sp, #0x1b20]
    4578:      	str	q1, [sp, #0x1b30]
    457c:      	ldp	q0, q1, [x25, #0x20]
    4580:      	str	q0, [sp, #0x1b40]
    4584:      	str	q1, [sp, #0x1b50]
    4588:      	ldr	x1, [sp, #0x1ac0]
    458c:      	ldr	x8, [x28, #0x20]
    4590:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
    4594:      	add	x9, x9, #0xb20
    4598:      	str	x8, [x9, #0x120]
    459c:      	ldp	q1, q0, [x28]
    45a0:      	stp	q1, q0, [x9, #0x100]
    45a4:      	ldr	x10, [sp, #0x330]
    45a8:      	str	x8, [x10, #0x20]
    45ac:      	ldr	x8, [sp, #0x1c38]
    45b0:      	ldr	x9, [sp, #0x1c68]
    45b4:      	adds	x8, x8, x9
    45b8:      	csinv	x9, x8, xzr, lo
    45bc:      	lsr	x8, x1, #14
    45c0:      	stp	q1, q0, [x10]
    45c4:      	cbnz	x8, 0x463c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xfc0>
    45c8:      	sub	x8, x1, x1, lsr #2
    45cc:      	cmp	x9, x8
    45d0:      	b.lo	0x463c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xfc0>
    45d4:      	ldr	x9, [x28, #0x20]
    45d8:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
    45dc:      	add	x10, x10, #0xb20
    45e0:      	str	x9, [x10, #0x170]
    45e4:      	ldp	q1, q0, [x28]
    45e8:      	stp	q1, q0, [x10, #0x150]
    45ec:      	ldr	x9, [sp, #0x1c88]
    45f0:      	cmp	x9, x8, lsr #1
    45f4:      	b.lo	0x4614 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xf98>
    45f8:      	cbz	x1, 0x4610 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xf94>
    45fc:      	cmp	x1, #0x2, lsl #12       ; =0x2000
    4600:      	mov	w8, #0x2000             ; =8192
    4604:      	csel	x8, x1, x8, lo
    4608:      	lsl	x1, x8, #1
    460c:      	b	0x4614 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xf98>
    4610:      	mov	w1, #0x1                ; =1
    4614:      	mov	w8, #0x1760             ; =5984
    4618:      	add	x2, x6, x8
    461c:      	mov	x0, x28
    4620:      	bl	0x4620 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xfa4>
		0000000000004620:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    4624:      	add	x6, sp, #0x350
    4628:      	str	w0, [sp, #0x1c98]
    462c:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
    4630:      	add	x8, x8, #0xb20
    4634:      	strb	w1, [x8, #0x17c]
    4638:      	strb	w2, [x8, #0x17d]
    463c:      	add	x0, x6, #0x868
    4640:      	add	x3, sp, #0x1, lsl #12   ; =0x1000
    4644:      	add	x3, x3, #0xb20
    4648:      	add	x27, sp, #0x350
    464c:      	mov	w8, #0x1760             ; =5984
    4650:      	add	x4, x27, x8
    4654:      	mov	x1, x28
    4658:      	mov	x2, x21
    465c:      	bl	0x465c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xfe0>
		000000000000465c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
    4660:      	ldr	w8, [sp, #0xbb8]
    4664:      	cbz	w8, 0x4440 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xdc4>
    4668:      	ldr	x8, [sp, #0x228]
    466c:      	ldrb	w28, [x8, #0x768]
    4670:      	add	x0, x27, #0x978
    4674:      	add	x8, sp, #0x350
    4678:      	add	x1, x8, #0x870
    467c:      	mov	w2, #0x108              ; =264
    4680:      	bl	0x4680 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1004>
		0000000000004680:  ARM64_RELOC_BRANCH26	_memcpy
    4684:      	ldr	x8, [sp, #0x1ae8]
    4688:      	cmp	w28, #0x0
    468c:      	ldr	x28, [sp, #0x348]
    4690:      	mov	w15, #0x1               ; =1
    4694:      	cinc	x9, x15, ne
    4698:      	madd	x8, x8, x26, x9
    469c:      	ldr	x9, [sp, #0xcc8]
    46a0:      	ldp	q1, q0, [x19, #0x60]
    46a4:      	ldr	x10, [sp, #0x210]
    46a8:      	stp	q1, q0, [x10, #0x60]
    46ac:      	ldp	q1, q0, [x19, #0x40]
    46b0:      	stp	q1, q0, [x10, #0x40]
    46b4:      	ldp	q1, q0, [x19, #0xa0]
    46b8:      	stp	q1, q0, [x10, #0xa0]
    46bc:      	ldp	q1, q0, [x19, #0x80]
    46c0:      	stp	q1, q0, [x10, #0x80]
    46c4:      	ldp	q1, q0, [x19, #0xe0]
    46c8:      	stp	q1, q0, [x10, #0xe0]
    46cc:      	ldp	q1, q0, [x19, #0xc0]
    46d0:      	stp	q1, q0, [x10, #0xc0]
    46d4:      	ldp	q1, q0, [x19, #0x20]
    46d8:      	stp	q1, q0, [x10, #0x20]
    46dc:      	ldp	q0, q1, [x19]
    46e0:      	stp	q0, q1, [x10]
    46e4:      	ldr	x10, [sp, #0xdd0]
    46e8:      	madd	x9, x9, x26, x10
    46ec:      	ldr	x10, [sp, #0xdd8]
    46f0:      	madd	x9, x9, x26, x10
    46f4:      	ldr	x10, [sp, #0xde0]
    46f8:      	madd	x9, x9, x26, x10
    46fc:      	ldr	x10, [sp, #0xde8]
    4700:      	madd	x9, x9, x26, x10
    4704:      	ldr	x10, [sp, #0xdf0]
    4708:      	madd	x9, x9, x26, x10
    470c:      	ldr	x10, [sp, #0xdf8]
    4710:      	madd	x9, x9, x26, x10
    4714:      	ldr	x10, [sp, #0xe00]
    4718:      	madd	x9, x9, x26, x10
    471c:      	ldr	x10, [sp, #0xe08]
    4720:      	madd	x9, x9, x26, x10
    4724:      	ldr	x10, [sp, #0xe10]
    4728:      	madd	x9, x9, x26, x10
    472c:      	ldr	x10, [sp, #0xe18]
    4730:      	madd	x9, x9, x26, x10
    4734:      	ldr	x10, [sp, #0xe20]
    4738:      	madd	x9, x9, x26, x10
    473c:      	ldr	x10, [sp, #0xe28]
    4740:      	madd	x9, x9, x26, x10
    4744:      	ldr	x10, [sp, #0xe30]
    4748:      	madd	x9, x9, x26, x10
    474c:      	ldr	x10, [sp, #0xe38]
    4750:      	madd	x9, x9, x26, x10
    4754:      	ldr	x10, [sp, #0xe40]
    4758:      	madd	x9, x9, x26, x10
    475c:      	ldr	x10, [sp, #0xe48]
    4760:      	madd	x9, x9, x26, x10
    4764:      	ldr	x10, [sp, #0xe50]
    4768:      	madd	x9, x9, x26, x10
    476c:      	ldr	x10, [sp, #0xe58]
    4770:      	madd	x9, x9, x26, x10
    4774:      	ldr	x10, [sp, #0xe60]
    4778:      	madd	x9, x9, x26, x10
    477c:      	ldr	x10, [sp, #0xe68]
    4780:      	madd	x9, x9, x26, x10
    4784:      	ldr	x10, [sp, #0xe70]
    4788:      	madd	x9, x9, x26, x10
    478c:      	ldr	x10, [sp, #0xe78]
    4790:      	madd	x9, x9, x26, x10
    4794:      	ldr	x10, [sp, #0xe80]
    4798:      	madd	x9, x9, x26, x10
    479c:      	ldr	x10, [sp, #0xe88]
    47a0:      	madd	x9, x9, x26, x10
    47a4:      	ldr	x10, [sp, #0xe90]
    47a8:      	madd	x9, x9, x26, x10
    47ac:      	ldr	x10, [sp, #0xe98]
    47b0:      	madd	x9, x9, x26, x10
    47b4:      	ldr	x10, [sp, #0xea0]
    47b8:      	madd	x9, x9, x26, x10
    47bc:      	ldr	x10, [sp, #0xea8]
    47c0:      	madd	x9, x9, x26, x10
    47c4:      	ldr	x10, [sp, #0xeb0]
    47c8:      	madd	x9, x9, x26, x10
    47cc:      	ldr	x10, [sp, #0xeb8]
    47d0:      	madd	x9, x9, x26, x10
    47d4:      	ldr	x10, [sp, #0xec0]
    47d8:      	add	x8, x8, x10
    47dc:      	madd	x8, x9, x26, x8
    47e0:      	ldr	x9, [sp, #0xec8]
    47e4:      	madd	x8, x8, x26, x9
    47e8:      	str	x8, [sp, #0x1ae8]
    47ec:      	add	x21, x21, #0x4
    47f0:      	add	x22, x22, #0x2
    47f4:      	subs	x23, x23, #0x1
    47f8:      	add	x6, sp, #0x350
    47fc:      	b.ne	0x4464 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xde8>
    4800:      	ldr	x22, [sp, #0xc0]
    4804:      	ldr	x10, [sp, #0x1e0]
    4808:      	b	0x3e18 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x79c>
    480c:      	mov	x24, #0x0               ; =0
    4810:      	mov	w8, #0x12e0             ; =4832
    4814:      	mov	w9, #0x10c8             ; =4296
    4818:      	mov	w10, #0x11d0            ; =4560
    481c:      	mov	w11, #0x12e8            ; =4840
    4820:      	mov	w12, #0x14f8            ; =5368
    4824:      	mov	w13, #0x1600            ; =5632
    4828:      	add	x8, x6, x8
    482c:      	str	x8, [sp, #0x320]
    4830:      	add	x8, x6, x9
    4834:      	str	x8, [sp, #0x98]
    4838:      	add	x8, x6, x10
    483c:      	str	x8, [sp, #0x90]
    4840:      	add	x25, x6, x11
    4844:      	add	x8, x6, x12
    4848:      	str	x8, [sp, #0xe0]
    484c:      	add	x8, x6, x13
    4850:      	str	x8, [sp, #0xd8]
    4854:      	add	x19, x6, #0xba0
    4858:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		0000000000004858:  ARM64_RELOC_PAGE21	lCPI68_15
    485c:      	ldr	q0, [x8]
		000000000000485c:  ARM64_RELOC_PAGEOFF12	lCPI68_15
    4860:      	str	q0, [sp, #0x2d0]
    4864:      	add	x8, x6, #0xeb8
    4868:      	str	x8, [sp, #0xd0]
    486c:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		000000000000486c:  ARM64_RELOC_PAGE21	lCPI68_16
    4870:      	ldr	q0, [x8]
		0000000000004870:  ARM64_RELOC_PAGEOFF12	lCPI68_16
    4874:      	str	q0, [sp, #0x2c0]
    4878:      	add	x20, x6, #0xfb8
    487c:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		000000000000487c:  ARM64_RELOC_PAGE21	lCPI68_17
    4880:      	ldr	q0, [x8]
		0000000000004880:  ARM64_RELOC_PAGEOFF12	lCPI68_17
    4884:      	str	q0, [sp, #0x2b0]
    4888:      	sub	x17, x23, #0x9
    488c:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		000000000000488c:  ARM64_RELOC_PAGE21	lCPI68_18
    4890:      	ldr	q0, [x8]
		0000000000004890:  ARM64_RELOC_PAGEOFF12	lCPI68_18
    4894:      	str	q0, [sp, #0x2a0]
    4898:      	ldr	x9, [sp, #0x228]
    489c:      	add	x8, x9, #0xec4
    48a0:      	str	x8, [sp, #0x88]
    48a4:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		00000000000048a4:  ARM64_RELOC_PAGE21	lCPI68_19
    48a8:      	ldr	q0, [x8]
		00000000000048a8:  ARM64_RELOC_PAGEOFF12	lCPI68_19
    48ac:      	str	q0, [sp, #0x290]
    48b0:      	add	x8, x9, #0xed4
    48b4:      	str	x8, [sp, #0x80]
    48b8:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		00000000000048b8:  ARM64_RELOC_PAGE21	lCPI68_20
    48bc:      	ldr	q0, [x8]
		00000000000048bc:  ARM64_RELOC_PAGEOFF12	lCPI68_20
    48c0:      	str	q0, [sp, #0x280]
    48c4:      	add	x8, x9, #0xee4
    48c8:      	str	x8, [sp, #0x78]
    48cc:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		00000000000048cc:  ARM64_RELOC_PAGE21	lCPI68_21
    48d0:      	ldr	q0, [x8]
		00000000000048d0:  ARM64_RELOC_PAGEOFF12	lCPI68_21
    48d4:      	str	q0, [sp, #0x270]
    48d8:      	add	x8, x9, #0xef4
    48dc:      	str	x8, [sp, #0x70]
    48e0:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		00000000000048e0:  ARM64_RELOC_PAGE21	lCPI68_22
    48e4:      	ldr	q0, [x8]
		00000000000048e4:  ARM64_RELOC_PAGEOFF12	lCPI68_22
    48e8:      	str	q0, [sp, #0x260]
    48ec:      	add	x8, x9, #0xf04
    48f0:      	str	x8, [sp, #0x68]
    48f4:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		00000000000048f4:  ARM64_RELOC_PAGE21	lCPI68_23
    48f8:      	ldr	q0, [x8]
		00000000000048f8:  ARM64_RELOC_PAGEOFF12	lCPI68_23
    48fc:      	str	q0, [sp, #0x250]
    4900:      	add	x8, x9, #0xf14
    4904:      	str	x8, [sp, #0x60]
    4908:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		0000000000004908:  ARM64_RELOC_PAGE21	lCPI68_24
    490c:      	ldr	q0, [x8]
		000000000000490c:  ARM64_RELOC_PAGEOFF12	lCPI68_24
    4910:      	str	q0, [sp, #0x240]
    4914:      	add	x8, x9, #0xf24
    4918:      	str	x8, [sp, #0x58]
    491c:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		000000000000491c:  ARM64_RELOC_PAGE21	lCPI68_25
    4920:      	ldr	q0, [x8]
		0000000000004920:  ARM64_RELOC_PAGEOFF12	lCPI68_25
    4924:      	str	q0, [sp, #0x230]
    4928:      	add	x8, x9, #0xf34
    492c:      	str	x8, [sp, #0x50]
    4930:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		0000000000004930:  ARM64_RELOC_PAGE21	lCPI68_26
    4934:      	ldr	q0, [x8]
		0000000000004934:  ARM64_RELOC_PAGEOFF12	lCPI68_26
    4938:      	str	q0, [sp, #0x210]
    493c:      	add	x8, x9, #0xf44
    4940:      	str	x8, [sp, #0x48]
    4944:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		0000000000004944:  ARM64_RELOC_PAGE21	lCPI68_27
    4948:      	ldr	q0, [x8]
		0000000000004948:  ARM64_RELOC_PAGEOFF12	lCPI68_27
    494c:      	str	q0, [sp, #0x200]
    4950:      	add	x8, x9, #0xf54
    4954:      	str	x8, [sp, #0x40]
    4958:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		0000000000004958:  ARM64_RELOC_PAGE21	lCPI68_28
    495c:      	ldr	q0, [x8]
		000000000000495c:  ARM64_RELOC_PAGEOFF12	lCPI68_28
    4960:      	str	q0, [sp, #0x1f0]
    4964:      	add	x8, x9, #0xf64
    4968:      	str	x8, [sp, #0x38]
    496c:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		000000000000496c:  ARM64_RELOC_PAGE21	lCPI68_29
    4970:      	ldr	q0, [x8]
		0000000000004970:  ARM64_RELOC_PAGEOFF12	lCPI68_29
    4974:      	str	q0, [sp, #0x1e0]
    4978:      	add	x8, x9, #0xf74
    497c:      	str	x8, [sp, #0x30]
    4980:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		0000000000004980:  ARM64_RELOC_PAGE21	lCPI68_0
    4984:      	ldr	q0, [x8]
		0000000000004984:  ARM64_RELOC_PAGEOFF12	lCPI68_0
    4988:      	str	q0, [sp, #0x1d0]
    498c:      	add	x8, x9, #0xf84
    4990:      	str	x8, [sp, #0x28]
    4994:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		0000000000004994:  ARM64_RELOC_PAGE21	lCPI68_1
    4998:      	ldr	q0, [x8]
		0000000000004998:  ARM64_RELOC_PAGEOFF12	lCPI68_1
    499c:      	str	q0, [sp, #0x1c0]
    49a0:      	add	x8, x9, #0xf94
    49a4:      	str	x8, [sp, #0x20]
    49a8:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		00000000000049a8:  ARM64_RELOC_PAGE21	lCPI68_2
    49ac:      	ldr	q0, [x8]
		00000000000049ac:  ARM64_RELOC_PAGEOFF12	lCPI68_2
    49b0:      	str	q0, [sp, #0x1b0]
    49b4:      	add	x8, x9, #0xfa4
    49b8:      	str	x8, [sp, #0x18]
    49bc:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		00000000000049bc:  ARM64_RELOC_PAGE21	lCPI68_3
    49c0:      	ldr	q0, [x8]
		00000000000049c0:  ARM64_RELOC_PAGEOFF12	lCPI68_3
    49c4:      	str	q0, [sp, #0x1a0]
    49c8:      	add	x8, x9, #0xfb4
    49cc:      	str	x8, [sp, #0x10]
    49d0:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		00000000000049d0:  ARM64_RELOC_PAGE21	lCPI68_4
    49d4:      	ldr	q0, [x8]
		00000000000049d4:  ARM64_RELOC_PAGEOFF12	lCPI68_4
    49d8:      	str	q0, [sp, #0x190]
    49dc:      	mov	w8, #0x13f0             ; =5104
    49e0:      	adrp	x9, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		00000000000049e0:  ARM64_RELOC_PAGE21	lCPI68_5
    49e4:      	ldr	q0, [x9]
		00000000000049e4:  ARM64_RELOC_PAGEOFF12	lCPI68_5
    49e8:      	str	q0, [sp, #0x180]
    49ec:      	add	x8, x14, x8
    49f0:      	str	x8, [sp, #0xc8]
    49f4:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		00000000000049f4:  ARM64_RELOC_PAGE21	lCPI68_6
    49f8:      	ldr	q0, [x8]
		00000000000049f8:  ARM64_RELOC_PAGEOFF12	lCPI68_6
    49fc:      	str	q0, [sp, #0x170]
    4a00:      	mov	w8, #0x13f8             ; =5112
    4a04:      	adrp	x9, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		0000000000004a04:  ARM64_RELOC_PAGE21	lCPI68_7
    4a08:      	ldr	q0, [x9]
		0000000000004a08:  ARM64_RELOC_PAGEOFF12	lCPI68_7
    4a0c:      	str	q0, [sp, #0x160]
    4a10:      	add	x8, x14, x8
    4a14:      	str	x8, [sp, #0xb8]
    4a18:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		0000000000004a18:  ARM64_RELOC_PAGE21	lCPI68_8
    4a1c:      	ldr	q0, [x8]
		0000000000004a1c:  ARM64_RELOC_PAGEOFF12	lCPI68_8
    4a20:      	str	q0, [sp, #0x150]
    4a24:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		0000000000004a24:  ARM64_RELOC_PAGE21	lCPI68_9
    4a28:      	ldr	q0, [x8]
		0000000000004a28:  ARM64_RELOC_PAGEOFF12	lCPI68_9
    4a2c:      	str	q0, [sp, #0x140]
    4a30:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		0000000000004a30:  ARM64_RELOC_PAGE21	lCPI68_10
    4a34:      	ldr	q0, [x8]
		0000000000004a34:  ARM64_RELOC_PAGEOFF12	lCPI68_10
    4a38:      	str	q0, [sp, #0x130]
    4a3c:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		0000000000004a3c:  ARM64_RELOC_PAGE21	lCPI68_11
    4a40:      	ldr	q0, [x8]
		0000000000004a40:  ARM64_RELOC_PAGEOFF12	lCPI68_11
    4a44:      	str	q0, [sp, #0x120]
    4a48:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		0000000000004a48:  ARM64_RELOC_PAGE21	lCPI68_12
    4a4c:      	ldr	q0, [x8]
		0000000000004a4c:  ARM64_RELOC_PAGEOFF12	lCPI68_12
    4a50:      	str	q0, [sp, #0x110]
    4a54:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		0000000000004a54:  ARM64_RELOC_PAGE21	lCPI68_13
    4a58:      	ldr	q0, [x8]
		0000000000004a58:  ARM64_RELOC_PAGEOFF12	lCPI68_13
    4a5c:      	str	q0, [sp, #0x100]
    4a60:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x984>
		0000000000004a60:  ARM64_RELOC_PAGE21	lCPI68_14
    4a64:      	ldr	q0, [x8]
		0000000000004a64:  ARM64_RELOC_PAGEOFF12	lCPI68_14
    4a68:      	str	q0, [sp, #0xf0]
    4a6c:      	add	x8, x14, #0xcb0
    4a70:      	stp	x21, x8, [sp, #0xa8]
    4a74:      	mov	w28, #0x83              ; =131
    4a78:      	mov	w3, #0x1                ; =1
    4a7c:      	mov	w27, #0x110             ; =272
    4a80:      	str	x16, [sp, #0x300]
    4a84:      	mov	x26, x17
    4a88:      	b	0x4aa0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1424>
    4a8c:      	ldr	x8, [sp, #0xe8]
    4a90:      	ldr	x24, [sp, #0x2f0]
    4a94:      	cmp	x24, x8
    4a98:      	ldr	x21, [sp, #0xa8]
    4a9c:      	b.eq	0x595c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x22e0>
    4aa0:      	cmp	x23, #0x4
    4aa4:      	b.eq	0x4ac8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x144c>
    4aa8:      	cmp	x23, #0x9
    4aac:      	b.eq	0x4ac8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x144c>
    4ab0:      	cmp	x23, #0xa
    4ab4:      	b.ne	0x4b5c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x14e0>
    4ab8:      	ldr	x8, [sp, #0x1ae8]
    4abc:      	mov	x9, #0x1                ; =1
    4ac0:      	madd	x8, x8, x28, x9
    4ac4:      	b	0x4b48 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x14cc>
    4ac8:      	cmp	x21, #0x4, lsl #12      ; =0x4000
    4acc:      	b.ls	0x4ae0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1464>
    4ad0:      	mov	w2, #0x0                ; =0
    4ad4:      	mov	w1, #0x0                ; =0
    4ad8:      	mov	w0, #0x1                ; =1
    4adc:      	b	0x4b20 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x14a4>
    4ae0:      	ldr	x8, [sp, #0x1ac0]
    4ae4:      	cmp	x21, x8
    4ae8:      	b.ls	0x4b14 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1498>
    4aec:      	mov	w8, #0x1760             ; =5984
    4af0:      	add	x2, x6, x8
    4af4:      	ldr	x0, [sp, #0x348]
    4af8:      	mov	x1, x21
    4afc:      	bl	0x4afc <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1480>
		0000000000004afc:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    4b00:      	mov	w3, #0x1                ; =1
    4b04:      	mov	x17, x26
    4b08:      	ldr	x16, [sp, #0x300]
    4b0c:      	add	x6, sp, #0x350
    4b10:      	b	0x4b20 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x14a4>
    4b14:      	mov	w2, #0x0                ; =0
    4b18:      	mov	w1, #0x0                ; =0
    4b1c:      	mov	w0, #0x0                ; =0
    4b20:      	str	w0, [sp, #0xed0]
    4b24:      	strb	w1, [sp, #0xed4]
    4b28:      	strb	w2, [sp, #0xed5]
    4b2c:      	cmp	w0, #0x0
    4b30:      	ldr	x8, [sp, #0x1ae8]
    4b34:      	mul	x8, x8, x28
    4b38:      	cinc	x8, x8, eq
    4b3c:      	str	x8, [sp, #0x1ae8]
    4b40:      	cmp	x17, #0x2
    4b44:      	b.hs	0x4b5c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x14e0>
    4b48:      	ldr	x9, [sp, #0x1ac0]
    4b4c:      	cmp	x9, x21
    4b50:      	mul	x8, x8, x28
    4b54:      	cinc	x8, x8, hs
    4b58:      	str	x8, [sp, #0x1ae8]
    4b5c:      	add	x24, x24, #0x1
    4b60:      	str	x24, [sp, #0x2f0]
    4b64:      	cbz	x22, 0x4a8c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1410>
    4b68:      	mov	x24, #0x0               ; =0
    4b6c:      	ldr	x8, [sp, #0xa0]
    4b70:      	ldr	x9, [sp, #0x2f0]
    4b74:      	madd	x8, x9, x22, x8
    4b78:      	str	x8, [sp, #0x310]
    4b7c:      	b	0x4ba4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1528>
    4b80:      	str	w3, [sp, #0xed8]
    4b84:      	str	xzr, [sp, #0xee0]
    4b88:      	strb	wzr, [sp, #0xee8]
    4b8c:      	ldr	x8, [sp, #0x1ae8]
    4b90:      	mul	x8, x8, x28
    4b94:      	str	x8, [sp, #0x1ae8]
    4b98:      	add	x24, x24, #0x1
    4b9c:      	cmp	x24, x22
    4ba0:      	b.eq	0x4a8c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1410>
    4ba4:      	add	x8, x24, x16
    4ba8:      	orr	x21, x3, x8, lsl #1
    4bac:      	str	x21, [sp, #0x1b18]
    4bb0:      	cmp	x23, #0x3
    4bb4:      	b.gt	0x4bf0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1574>
    4bb8:      	cmp	x23, #0x2
    4bbc:      	b.lo	0x4c08 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x158c>
    4bc0:      	b.eq	0x4cd8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x165c>
    4bc4:      	cmp	x23, #0x3
    4bc8:      	b.ne	0x4b98 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x151c>
    4bcc:      	ldr	x8, [sp, #0x1ad8]
    4bd0:      	cbz	x8, 0x52d8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1c5c>
    4bd4:      	mov	w9, #0x1768             ; =5992
    4bd8:      	ldrb	w9, [x6, x9]
    4bdc:      	tbz	w9, #0x0, 0x4f90 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1914>
    4be0:      	mov	x9, #0x0                ; =0
    4be4:      	ldr	x10, [sp, #0x1ac0]
    4be8:      	cbnz	x10, 0x4fd4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1958>
    4bec:      	b	0x52d8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1c5c>
    4bf0:      	cmp	x17, #0x2
    4bf4:      	b.lo	0x4c08 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x158c>
    4bf8:      	cmp	x23, #0x7
    4bfc:      	b.eq	0x4e94 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1818>
    4c00:      	cmp	x23, #0x4
    4c04:      	b.ne	0x4b98 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x151c>
    4c08:      	mov	w8, #0x1768             ; =5992
    4c0c:      	ldrb	w8, [x6, x8]
    4c10:      	tbz	w8, #0x0, 0x4c24 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x15a8>
    4c14:      	mov	x9, #0x0                ; =0
    4c18:      	ldr	x8, [sp, #0x1ac0]
    4c1c:      	cbnz	x8, 0x4c68 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x15ec>
    4c20:      	b	0x4b80 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1504>
    4c24:      	ldr	x8, [sp, #0x1ab0]
    4c28:      	eor	x8, x8, x21
    4c2c:      	eor	x8, x8, x8, lsr #30
    4c30:      	mov	x9, #0xe5b9             ; =58809
    4c34:      	movk	x9, #0x1ce4, lsl #16
    4c38:      	movk	x9, #0x476d, lsl #32
    4c3c:      	movk	x9, #0xbf58, lsl #48
    4c40:      	mul	x8, x8, x9
    4c44:      	eor	x8, x8, x8, lsr #27
    4c48:      	mov	x9, #0x11eb             ; =4587
    4c4c:      	movk	x9, #0x1331, lsl #16
    4c50:      	movk	x9, #0x49bb, lsl #32
    4c54:      	movk	x9, #0x94d0, lsl #48
    4c58:      	mul	x8, x8, x9
    4c5c:      	eor	x9, x8, x8, lsr #31
    4c60:      	ldr	x8, [sp, #0x1ac0]
    4c64:      	cbz	x8, 0x4b80 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1504>
    4c68:      	udiv	x10, x9, x8
    4c6c:      	msub	x9, x10, x8, x9
    4c70:      	ldr	x10, [sp, #0x1ad0]
    4c74:      	mov	x11, x8
    4c78:      	b	0x4c90 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1614>
    4c7c:      	add	x12, x9, #0x1
    4c80:      	cmp	x12, x8
    4c84:      	csinc	x9, xzr, x9, hs
    4c88:      	subs	x11, x11, #0x1
    4c8c:      	b.eq	0x4b80 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1504>
    4c90:      	madd	x12, x9, x27, x10
    4c94:      	ldr	w13, [x12]
    4c98:      	cmp	w13, #0x1
    4c9c:      	b.eq	0x4c7c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1600>
    4ca0:      	cmp	w13, #0x2
    4ca4:      	b.ne	0x4b80 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1504>
    4ca8:      	ldr	x13, [x12, #0x8]
    4cac:      	cmp	x13, x21
    4cb0:      	b.ne	0x4c7c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1600>
    4cb4:      	ldr	x8, [x12, #0x10]
    4cb8:      	str	wzr, [sp, #0xed8]
    4cbc:      	str	x8, [sp, #0xee0]
    4cc0:      	strb	wzr, [sp, #0xee8]
    4cc4:      	ldr	x9, [sp, #0x1ae8]
    4cc8:      	mov	w10, #0x4309            ; =17161
    4ccc:      	madd	x8, x9, x10, x8
    4cd0:      	add	x8, x8, #0x83
    4cd4:      	b	0x4b94 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1518>
    4cd8:      	ldr	x8, [sp, #0x310]
    4cdc:      	add	x8, x8, x24
    4ce0:      	str	x8, [sp, #0xef0]
    4ce4:      	add	x9, x8, #0x1
    4ce8:      	dup.2d	v0, x8
    4cec:      	str	x9, [sp, #0xef8]
    4cf0:      	ldr	q1, [sp, #0x2d0]
    4cf4:      	add.2d	v1, v0, v1
    4cf8:      	str	q1, [sp, #0xf00]
    4cfc:      	ldr	q1, [sp, #0x2c0]
    4d00:      	add.2d	v1, v0, v1
    4d04:      	str	q1, [sp, #0xf10]
    4d08:      	ldr	q1, [sp, #0x2b0]
    4d0c:      	add.2d	v1, v0, v1
    4d10:      	str	q1, [sp, #0xf20]
    4d14:      	ldr	q1, [sp, #0x2a0]
    4d18:      	add.2d	v1, v0, v1
    4d1c:      	str	q1, [sp, #0xf30]
    4d20:      	ldr	q1, [sp, #0x290]
    4d24:      	add.2d	v1, v0, v1
    4d28:      	str	q1, [sp, #0xf40]
    4d2c:      	ldr	q1, [sp, #0x280]
    4d30:      	add.2d	v1, v0, v1
    4d34:      	str	q1, [sp, #0xf50]
    4d38:      	ldr	q1, [sp, #0x270]
    4d3c:      	add.2d	v1, v0, v1
    4d40:      	str	q1, [sp, #0xf60]
    4d44:      	ldr	q1, [sp, #0x260]
    4d48:      	add.2d	v1, v0, v1
    4d4c:      	str	q1, [sp, #0xf70]
    4d50:      	ldr	q1, [sp, #0x250]
    4d54:      	add.2d	v1, v0, v1
    4d58:      	str	q1, [sp, #0xf80]
    4d5c:      	ldr	q1, [sp, #0x240]
    4d60:      	add.2d	v1, v0, v1
    4d64:      	str	q1, [sp, #0xf90]
    4d68:      	ldr	q1, [sp, #0x230]
    4d6c:      	add.2d	v1, v0, v1
    4d70:      	str	q1, [sp, #0xfa0]
    4d74:      	ldr	q1, [sp, #0x210]
    4d78:      	add.2d	v1, v0, v1
    4d7c:      	str	q1, [sp, #0xfb0]
    4d80:      	ldr	q1, [sp, #0x200]
    4d84:      	add.2d	v1, v0, v1
    4d88:      	str	q1, [sp, #0xfc0]
    4d8c:      	ldr	q1, [sp, #0x1f0]
    4d90:      	add.2d	v1, v0, v1
    4d94:      	str	q1, [sp, #0xfd0]
    4d98:      	ldr	q1, [sp, #0x1e0]
    4d9c:      	add.2d	v0, v0, v1
    4da0:      	str	q0, [sp, #0xfe0]
    4da4:      	ldp	q0, q1, [x19, #0xc0]
    4da8:      	str	q0, [sp, #0x1be0]
    4dac:      	str	q1, [sp, #0x1bf0]
    4db0:      	ldp	q0, q1, [x19, #0xe0]
    4db4:      	str	q0, [sp, #0x1c00]
    4db8:      	str	q1, [sp, #0x1c10]
    4dbc:      	ldp	q0, q1, [x19, #0x80]
    4dc0:      	str	q0, [sp, #0x1ba0]
    4dc4:      	str	q1, [sp, #0x1bb0]
    4dc8:      	ldp	q0, q1, [x19, #0xa0]
    4dcc:      	str	q0, [sp, #0x1bc0]
    4dd0:      	str	q1, [sp, #0x1bd0]
    4dd4:      	ldp	q0, q1, [x19, #0x40]
    4dd8:      	str	q0, [sp, #0x1b60]
    4ddc:      	str	q1, [sp, #0x1b70]
    4de0:      	ldp	q0, q1, [x19, #0x60]
    4de4:      	str	q0, [sp, #0x1b80]
    4de8:      	str	q1, [sp, #0x1b90]
    4dec:      	ldp	q0, q1, [x19]
    4df0:      	str	q0, [sp, #0x1b20]
    4df4:      	str	q1, [sp, #0x1b30]
    4df8:      	ldp	q0, q1, [x19, #0x20]
    4dfc:      	str	q0, [sp, #0x1b40]
    4e00:      	str	q1, [sp, #0x1b50]
    4e04:      	ldr	x1, [sp, #0x1ac0]
    4e08:      	ldr	x9, [sp, #0x348]
    4e0c:      	ldr	x8, [x9, #0x20]
    4e10:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
    4e14:      	add	x10, x10, #0xb20
    4e18:      	str	x8, [x10, #0x120]
    4e1c:      	ldp	q1, q0, [x9]
    4e20:      	stp	q1, q0, [x10, #0x100]
    4e24:      	ldr	x10, [sp, #0x330]
    4e28:      	str	x8, [x10, #0x20]
    4e2c:      	ldr	x8, [sp, #0x1c38]
    4e30:      	ldr	x9, [sp, #0x1c68]
    4e34:      	adds	x8, x8, x9
    4e38:      	csinv	x9, x8, xzr, lo
    4e3c:      	lsr	x8, x1, #14
    4e40:      	stp	q1, q0, [x10]
    4e44:      	cbnz	x8, 0x577c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x2100>
    4e48:      	sub	x8, x1, x1, lsr #2
    4e4c:      	cmp	x9, x8
    4e50:      	b.lo	0x577c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x2100>
    4e54:      	ldr	x10, [sp, #0x348]
    4e58:      	ldr	x9, [x10, #0x20]
    4e5c:      	add	x11, sp, #0x1, lsl #12  ; =0x1000
    4e60:      	add	x11, x11, #0xb20
    4e64:      	str	x9, [x11, #0x170]
    4e68:      	ldp	q1, q0, [x10]
    4e6c:      	stp	q1, q0, [x11, #0x150]
    4e70:      	ldr	x9, [sp, #0x1c88]
    4e74:      	cmp	x9, x8, lsr #1
    4e78:      	b.lo	0x5754 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x20d8>
    4e7c:      	cbz	x1, 0x5750 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x20d4>
    4e80:      	cmp	x1, #0x2, lsl #12       ; =0x2000
    4e84:      	mov	w8, #0x2000             ; =8192
    4e88:      	csel	x8, x1, x8, lo
    4e8c:      	lsl	x1, x8, #1
    4e90:      	b	0x5754 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x20d8>
    4e94:      	mov	w8, #0x1768             ; =5992
    4e98:      	ldrb	w8, [x6, x8]
    4e9c:      	tbz	w8, #0x0, 0x4eb0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1834>
    4ea0:      	mov	x10, #0x0               ; =0
    4ea4:      	ldr	x8, [sp, #0x1ac0]
    4ea8:      	cbnz	x8, 0x4ef4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1878>
    4eac:      	b	0x4f7c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1900>
    4eb0:      	ldr	x8, [sp, #0x1ab0]
    4eb4:      	eor	x8, x8, x21
    4eb8:      	eor	x8, x8, x8, lsr #30
    4ebc:      	mov	x9, #0xe5b9             ; =58809
    4ec0:      	movk	x9, #0x1ce4, lsl #16
    4ec4:      	movk	x9, #0x476d, lsl #32
    4ec8:      	movk	x9, #0xbf58, lsl #48
    4ecc:      	mul	x8, x8, x9
    4ed0:      	eor	x8, x8, x8, lsr #27
    4ed4:      	mov	x9, #0x11eb             ; =4587
    4ed8:      	movk	x9, #0x1331, lsl #16
    4edc:      	movk	x9, #0x49bb, lsl #32
    4ee0:      	movk	x9, #0x94d0, lsl #48
    4ee4:      	mul	x8, x8, x9
    4ee8:      	eor	x10, x8, x8, lsr #31
    4eec:      	ldr	x8, [sp, #0x1ac0]
    4ef0:      	cbz	x8, 0x4f7c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1900>
    4ef4:      	mov	x9, #0x0                ; =0
    4ef8:      	udiv	x11, x10, x8
    4efc:      	msub	x10, x11, x8, x10
    4f00:      	sub	x11, x8, x10
    4f04:      	neg	x12, x11
    4f08:      	ldr	x13, [sp, #0x1ad0]
    4f0c:      	b	0x4f1c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x18a0>
    4f10:      	add	x9, x9, #0x1
    4f14:      	cmp	x8, x9
    4f18:      	b.eq	0x4f7c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1900>
    4f1c:      	cmp	x9, x11
    4f20:      	csel	x14, x10, x12, lo
    4f24:      	add	x14, x14, x9
    4f28:      	madd	x14, x14, x27, x13
    4f2c:      	ldr	w15, [x14]
    4f30:      	cmp	w15, #0x1
    4f34:      	b.eq	0x4f10 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1894>
    4f38:      	cmp	w15, #0x2
    4f3c:      	b.ne	0x4f7c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1900>
    4f40:      	ldr	x15, [x14, #0x8]
    4f44:      	cmp	x15, x21
    4f48:      	b.ne	0x4f10 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1894>
    4f4c:      	ldr	x8, [x14, #0x10]
    4f50:      	add	x9, x8, #0x1
    4f54:      	str	x9, [x14, #0x10]
    4f58:      	str	wzr, [sp, #0x1a50]
    4f5c:      	str	x9, [sp, #0x1a58]
    4f60:      	ldr	x9, [sp, #0x320]
    4f64:      	strb	wzr, [x9, #0x430]
    4f68:      	ldr	x9, [sp, #0x1ae8]
    4f6c:      	mov	w10, #0x4309            ; =17161
    4f70:      	madd	x8, x9, x10, x8
    4f74:      	add	x8, x8, #0x84
    4f78:      	b	0x4b94 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1518>
    4f7c:      	str	w3, [sp, #0x1a50]
    4f80:      	str	xzr, [sp, #0x1a58]
    4f84:      	ldr	x8, [sp, #0x320]
    4f88:      	strb	wzr, [x8, #0x430]
    4f8c:      	b	0x4b8c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1510>
    4f90:      	ldr	x9, [sp, #0x1ab0]
    4f94:      	eor	x9, x9, x21
    4f98:      	eor	x9, x9, x9, lsr #30
    4f9c:      	mov	x10, #0xe5b9            ; =58809
    4fa0:      	movk	x10, #0x1ce4, lsl #16
    4fa4:      	movk	x10, #0x476d, lsl #32
    4fa8:      	movk	x10, #0xbf58, lsl #48
    4fac:      	mul	x9, x9, x10
    4fb0:      	eor	x9, x9, x9, lsr #27
    4fb4:      	mov	x10, #0x11eb            ; =4587
    4fb8:      	movk	x10, #0x1331, lsl #16
    4fbc:      	movk	x10, #0x49bb, lsl #32
    4fc0:      	movk	x10, #0x94d0, lsl #48
    4fc4:      	mul	x9, x9, x10
    4fc8:      	eor	x9, x9, x9, lsr #31
    4fcc:      	ldr	x10, [sp, #0x1ac0]
    4fd0:      	cbz	x10, 0x52d8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1c5c>
    4fd4:      	udiv	x11, x9, x10
    4fd8:      	msub	x11, x11, x10, x9
    4fdc:      	ldr	x12, [sp, #0x1ad0]
    4fe0:      	mov	x13, x10
    4fe4:      	b	0x4ffc <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1980>
    4fe8:      	add	x9, x11, #0x1
    4fec:      	cmp	x9, x10
    4ff0:      	csinc	x11, xzr, x11, hs
    4ff4:      	subs	x13, x13, #0x1
    4ff8:      	b.eq	0x52d8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1c5c>
    4ffc:      	madd	x9, x11, x27, x12
    5000:      	ldr	w14, [x9]
    5004:      	cmp	w14, #0x1
    5008:      	b.eq	0x4fe8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x196c>
    500c:      	cmp	w14, #0x2
    5010:      	b.ne	0x52d8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1c5c>
    5014:      	ldr	x14, [x9, #0x8]
    5018:      	cmp	x14, x21
    501c:      	b.ne	0x4fe8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x196c>
    5020:      	str	w3, [x9]
    5024:      	sub	x8, x8, #0x1
    5028:      	ldp	q0, q1, [x9, #0x10]
    502c:      	ldp	q2, q3, [x9, #0x30]
    5030:      	ldp	q4, q5, [x9, #0x50]
    5034:      	ldp	q6, q7, [x9, #0x70]
    5038:      	ldp	q16, q17, [x9, #0x90]
    503c:      	ldp	q18, q19, [x9, #0xb0]
    5040:      	ldp	q20, q21, [x9, #0xd0]
    5044:      	ldp	q22, q23, [x9, #0xf0]
    5048:      	movi.2d	v24, #0000000000000000
    504c:      	stur	q24, [x9, #0x18]
    5050:      	stur	q24, [x9, #0x28]
    5054:      	stur	q24, [x9, #0x38]
    5058:      	stur	q24, [x9, #0x48]
    505c:      	stur	q24, [x9, #0x58]
    5060:      	stur	q24, [x9, #0x68]
    5064:      	stur	q24, [x9, #0x78]
    5068:      	stur	q24, [x9, #0x88]
    506c:      	stur	q24, [x9, #0x98]
    5070:      	stur	q24, [x9, #0xa8]
    5074:      	stur	q24, [x9, #0xb8]
    5078:      	stur	q24, [x9, #0xc8]
    507c:      	stur	q24, [x9, #0xd8]
    5080:      	stur	q24, [x9, #0xe8]
    5084:      	stur	q24, [x9, #0xf8]
    5088:      	stur	q24, [x9, #0x8]
    508c:      	str	xzr, [x9, #0x108]
    5090:      	str	x8, [sp, #0x1ad8]
    5094:      	ldr	x8, [sp, #0x1ae0]
    5098:      	adds	x8, x8, #0x1
    509c:      	csinv	x8, x8, xzr, lo
    50a0:      	str	x8, [sp, #0x1ae0]
    50a4:      	str	x3, [sp, #0x1308]
    50a8:      	str	x21, [sp, #0x1310]
    50ac:      	ldp	x8, x21, [sp, #0x80]
    50b0:      	str	q0, [x21]
    50b4:      	str	q1, [x8]
    50b8:      	ldp	x8, x9, [sp, #0x70]
    50bc:      	str	q2, [x9]
    50c0:      	str	q3, [x8]
    50c4:      	ldp	x8, x9, [sp, #0x60]
    50c8:      	str	q4, [x9]
    50cc:      	str	q5, [x8]
    50d0:      	ldp	x8, x9, [sp, #0x50]
    50d4:      	str	q6, [x9]
    50d8:      	str	q7, [x8]
    50dc:      	ldp	x8, x9, [sp, #0x40]
    50e0:      	str	q16, [x9]
    50e4:      	str	q17, [x8]
    50e8:      	ldp	x8, x9, [sp, #0x30]
    50ec:      	str	q18, [x9]
    50f0:      	str	q19, [x8]
    50f4:      	ldp	x8, x9, [sp, #0x20]
    50f8:      	str	q20, [x9]
    50fc:      	str	q21, [x8]
    5100:      	ldp	x8, x9, [sp, #0x10]
    5104:      	str	q22, [x9]
    5108:      	str	q23, [x8]
    510c:      	add	x8, sp, #0x350
    5110:      	add	x1, x8, #0xfc0
    5114:      	ldr	x0, [sp, #0x98]
    5118:      	mov	w2, #0x108              ; =264
    511c:      	bl	0x511c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1aa0>
		000000000000511c:  ARM64_RELOC_BRANCH26	_memcpy
    5120:      	mov	w3, #0x1                ; =1
    5124:      	add	x6, sp, #0x350
    5128:      	ldr	x8, [sp, #0x1ae8]
    512c:      	ldr	x9, [sp, #0x1418]
    5130:      	ldp	q1, q0, [x21, #0x20]
    5134:      	ldr	x10, [sp, #0x90]
    5138:      	stp	q1, q0, [x10, #0x20]
    513c:      	ldp	q1, q0, [x21, #0x60]
    5140:      	stp	q1, q0, [x10, #0x60]
    5144:      	ldp	q1, q0, [x21, #0x40]
    5148:      	stp	q1, q0, [x10, #0x40]
    514c:      	ldp	q1, q0, [x21, #0xa0]
    5150:      	stp	q1, q0, [x10, #0xa0]
    5154:      	ldp	q1, q0, [x21, #0x80]
    5158:      	stp	q1, q0, [x10, #0x80]
    515c:      	ldp	q1, q0, [x21, #0xe0]
    5160:      	stp	q1, q0, [x10, #0xe0]
    5164:      	ldp	q1, q0, [x21, #0xc0]
    5168:      	stp	q1, q0, [x10, #0xc0]
    516c:      	ldp	q1, q0, [x21]
    5170:      	stp	q1, q0, [x10]
    5174:      	ldr	x10, [sp, #0x1610]
    5178:      	madd	x8, x8, x28, x10
    517c:      	ldr	x10, [sp, #0x1520]
    5180:      	madd	x9, x9, x28, x10
    5184:      	ldr	x10, [sp, #0x1528]
    5188:      	madd	x9, x9, x28, x10
    518c:      	ldr	x10, [sp, #0x1530]
    5190:      	madd	x9, x9, x28, x10
    5194:      	ldr	x10, [sp, #0x1538]
    5198:      	madd	x9, x9, x28, x10
    519c:      	ldr	x10, [sp, #0x1540]
    51a0:      	madd	x9, x9, x28, x10
    51a4:      	ldr	x10, [sp, #0x1548]
    51a8:      	madd	x9, x9, x28, x10
    51ac:      	ldr	x10, [sp, #0x1550]
    51b0:      	madd	x9, x9, x28, x10
    51b4:      	ldr	x10, [sp, #0x1558]
    51b8:      	madd	x9, x9, x28, x10
    51bc:      	ldr	x10, [sp, #0x1560]
    51c0:      	madd	x9, x9, x28, x10
    51c4:      	ldr	x10, [sp, #0x1568]
    51c8:      	madd	x9, x9, x28, x10
    51cc:      	ldr	x10, [sp, #0x1570]
    51d0:      	madd	x9, x9, x28, x10
    51d4:      	ldr	x10, [sp, #0x1578]
    51d8:      	madd	x9, x9, x28, x10
    51dc:      	ldr	x10, [sp, #0x1580]
    51e0:      	madd	x9, x9, x28, x10
    51e4:      	ldr	x10, [sp, #0x1588]
    51e8:      	madd	x9, x9, x28, x10
    51ec:      	ldr	x10, [sp, #0x1590]
    51f0:      	madd	x9, x9, x28, x10
    51f4:      	ldr	x10, [sp, #0x1598]
    51f8:      	madd	x9, x9, x28, x10
    51fc:      	ldr	x10, [sp, #0x15a0]
    5200:      	madd	x9, x9, x28, x10
    5204:      	ldr	x10, [sp, #0x15a8]
    5208:      	madd	x9, x9, x28, x10
    520c:      	ldr	x10, [sp, #0x15b0]
    5210:      	madd	x9, x9, x28, x10
    5214:      	ldr	x10, [sp, #0x15b8]
    5218:      	madd	x9, x9, x28, x10
    521c:      	ldr	x10, [sp, #0x15c0]
    5220:      	madd	x9, x9, x28, x10
    5224:      	ldr	x10, [sp, #0x15c8]
    5228:      	madd	x9, x9, x28, x10
    522c:      	ldr	x10, [sp, #0x15d0]
    5230:      	madd	x9, x9, x28, x10
    5234:      	ldr	x10, [sp, #0x15d8]
    5238:      	madd	x9, x9, x28, x10
    523c:      	ldr	x10, [sp, #0x15e0]
    5240:      	madd	x9, x9, x28, x10
    5244:      	ldr	x10, [sp, #0x15e8]
    5248:      	madd	x9, x9, x28, x10
    524c:      	ldr	x10, [sp, #0x15f0]
    5250:      	madd	x9, x9, x28, x10
    5254:      	ldr	x10, [sp, #0x15f8]
    5258:      	madd	x9, x9, x28, x10
    525c:      	ldr	x10, [sp, #0x1600]
    5260:      	madd	x9, x9, x28, x10
    5264:      	ldr	x10, [sp, #0x1608]
    5268:      	madd	x9, x9, x28, x10
    526c:      	madd	x8, x9, x28, x8
    5270:      	ldr	x9, [sp, #0x1618]
    5274:      	madd	x8, x8, x28, x9
    5278:      	add	x9, x8, #0x83
    527c:      	str	x9, [sp, #0x1ae8]
    5280:      	mov	w8, #0x1768             ; =5992
    5284:      	ldrb	w8, [x6, x8]
    5288:      	ldr	x21, [sp, #0x1b18]
    528c:      	tbnz	w8, #0x0, 0x531c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1ca0>
    5290:      	ldr	x8, [sp, #0x1ab0]
    5294:      	eor	x8, x21, x8
    5298:      	eor	x8, x8, x8, lsr #30
    529c:      	mov	x10, #0xe5b9            ; =58809
    52a0:      	movk	x10, #0x1ce4, lsl #16
    52a4:      	movk	x10, #0x476d, lsl #32
    52a8:      	movk	x10, #0xbf58, lsl #48
    52ac:      	mul	x8, x8, x10
    52b0:      	eor	x8, x8, x8, lsr #27
    52b4:      	mov	x10, #0x11eb            ; =4587
    52b8:      	movk	x10, #0x1331, lsl #16
    52bc:      	movk	x10, #0x49bb, lsl #32
    52c0:      	movk	x10, #0x94d0, lsl #48
    52c4:      	mul	x8, x8, x10
    52c8:      	eor	x10, x8, x8, lsr #31
    52cc:      	ldr	x8, [sp, #0x1ac0]
    52d0:      	cbnz	x8, 0x5328 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1cac>
    52d4:      	b	0x5398 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1d1c>
    52d8:      	movi.2d	v0, #0000000000000000
    52dc:      	stp	q0, q0, [x20, #0xf0]
    52e0:      	stp	q0, q0, [x20, #0xd0]
    52e4:      	stp	q0, q0, [x20, #0xb0]
    52e8:      	stp	q0, q0, [x20, #0x90]
    52ec:      	stp	q0, q0, [x20, #0x70]
    52f0:      	stp	q0, q0, [x20, #0x50]
    52f4:      	stp	q0, q0, [x20, #0x30]
    52f8:      	stp	q0, q0, [x20, #0x10]
    52fc:      	ldr	x8, [sp, #0x1ae8]
    5300:      	mul	x9, x8, x28
    5304:      	str	q0, [x20]
    5308:      	str	x9, [sp, #0x1ae8]
    530c:      	mov	w8, #0x1768             ; =5992
    5310:      	ldrb	w8, [x6, x8]
    5314:      	ldr	x21, [sp, #0x1b18]
    5318:      	tbz	w8, #0x0, 0x5290 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1c14>
    531c:      	mov	x10, #0x0               ; =0
    5320:      	ldr	x8, [sp, #0x1ac0]
    5324:      	cbz	x8, 0x5398 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1d1c>
    5328:      	udiv	x11, x10, x8
    532c:      	msub	x10, x11, x8, x10
    5330:      	ldr	x11, [sp, #0x1ad0]
    5334:      	mov	x12, x8
    5338:      	b	0x5350 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1cd4>
    533c:      	add	x13, x10, #0x1
    5340:      	cmp	x13, x8
    5344:      	csinc	x10, xzr, x10, hs
    5348:      	subs	x12, x12, #0x1
    534c:      	b.eq	0x5398 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1d1c>
    5350:      	madd	x13, x10, x27, x11
    5354:      	ldr	w14, [x13]
    5358:      	cmp	w14, #0x1
    535c:      	b.eq	0x533c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1cc0>
    5360:      	cmp	w14, #0x2
    5364:      	b.ne	0x5398 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1d1c>
    5368:      	ldr	x14, [x13, #0x8]
    536c:      	cmp	x14, x21
    5370:      	b.ne	0x533c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1cc0>
    5374:      	ldr	x10, [x13, #0x10]
    5378:      	str	wzr, [sp, #0x1620]
    537c:      	str	x10, [sp, #0x1628]
    5380:      	ldr	x11, [sp, #0x320]
    5384:      	strb	wzr, [x11]
    5388:      	mov	w11, #0x4309            ; =17161
    538c:      	madd	x9, x9, x11, x10
    5390:      	add	x9, x9, #0x83
    5394:      	b	0x53ac <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1d30>
    5398:      	str	w3, [sp, #0x1620]
    539c:      	str	xzr, [sp, #0x1628]
    53a0:      	mul	x9, x9, x28
    53a4:      	ldr	x10, [sp, #0x320]
    53a8:      	strb	wzr, [x10]
    53ac:      	str	x9, [sp, #0x1ae8]
    53b0:      	ldr	x9, [sp, #0x310]
    53b4:      	add	x9, x9, x24
    53b8:      	add	x10, x9, #0x1f
    53bc:      	dup.2d	v0, x9
    53c0:      	str	x9, [sp, #0x1638]
    53c4:      	ldr	q1, [sp, #0x1d0]
    53c8:      	add.2d	v1, v0, v1
    53cc:      	str	q1, [sp, #0x1640]
    53d0:      	ldr	q1, [sp, #0x1c0]
    53d4:      	add.2d	v1, v0, v1
    53d8:      	str	q1, [sp, #0x1650]
    53dc:      	ldr	q1, [sp, #0x1b0]
    53e0:      	add.2d	v1, v0, v1
    53e4:      	str	q1, [sp, #0x1660]
    53e8:      	ldr	q1, [sp, #0x1a0]
    53ec:      	add.2d	v1, v0, v1
    53f0:      	str	q1, [sp, #0x1670]
    53f4:      	ldr	q1, [sp, #0x190]
    53f8:      	add.2d	v1, v0, v1
    53fc:      	str	q1, [sp, #0x1680]
    5400:      	ldr	q1, [sp, #0x180]
    5404:      	add.2d	v1, v0, v1
    5408:      	str	q1, [sp, #0x1690]
    540c:      	ldr	q1, [sp, #0x170]
    5410:      	add.2d	v1, v0, v1
    5414:      	str	q1, [sp, #0x16a0]
    5418:      	ldr	q1, [sp, #0x160]
    541c:      	add.2d	v1, v0, v1
    5420:      	str	q1, [sp, #0x16b0]
    5424:      	ldr	q1, [sp, #0x150]
    5428:      	add.2d	v1, v0, v1
    542c:      	str	q1, [sp, #0x16c0]
    5430:      	ldr	q1, [sp, #0x140]
    5434:      	add.2d	v1, v0, v1
    5438:      	str	q1, [sp, #0x16d0]
    543c:      	ldr	q1, [sp, #0x130]
    5440:      	add.2d	v1, v0, v1
    5444:      	str	q1, [sp, #0x16e0]
    5448:      	ldr	q1, [sp, #0x120]
    544c:      	add.2d	v1, v0, v1
    5450:      	str	q1, [sp, #0x16f0]
    5454:      	ldr	q1, [sp, #0x110]
    5458:      	add.2d	v1, v0, v1
    545c:      	str	q1, [sp, #0x1700]
    5460:      	ldr	q1, [sp, #0x100]
    5464:      	add.2d	v1, v0, v1
    5468:      	str	q1, [sp, #0x1710]
    546c:      	ldr	q1, [sp, #0xf0]
    5470:      	add.2d	v0, v0, v1
    5474:      	str	q0, [sp, #0x1720]
    5478:      	str	x10, [sp, #0x1730]
    547c:      	ldp	q0, q1, [x25, #0xc0]
    5480:      	str	q0, [sp, #0x1be0]
    5484:      	str	q1, [sp, #0x1bf0]
    5488:      	ldp	q0, q1, [x25, #0xe0]
    548c:      	str	q0, [sp, #0x1c00]
    5490:      	str	q1, [sp, #0x1c10]
    5494:      	ldp	q0, q1, [x25, #0x80]
    5498:      	str	q0, [sp, #0x1ba0]
    549c:      	str	q1, [sp, #0x1bb0]
    54a0:      	ldp	q0, q1, [x25, #0xa0]
    54a4:      	str	q0, [sp, #0x1bc0]
    54a8:      	str	q1, [sp, #0x1bd0]
    54ac:      	ldp	q0, q1, [x25, #0x40]
    54b0:      	str	q0, [sp, #0x1b60]
    54b4:      	str	q1, [sp, #0x1b70]
    54b8:      	ldp	q0, q1, [x25, #0x60]
    54bc:      	str	q0, [sp, #0x1b80]
    54c0:      	str	q1, [sp, #0x1b90]
    54c4:      	ldp	q0, q1, [x25]
    54c8:      	str	q0, [sp, #0x1b20]
    54cc:      	str	q1, [sp, #0x1b30]
    54d0:      	ldp	q0, q1, [x25, #0x20]
    54d4:      	str	q0, [sp, #0x1b40]
    54d8:      	str	q1, [sp, #0x1b50]
    54dc:      	ldr	x10, [sp, #0x348]
    54e0:      	ldr	x9, [x10, #0x20]
    54e4:      	add	x11, sp, #0x1, lsl #12  ; =0x1000
    54e8:      	add	x11, x11, #0xb20
    54ec:      	str	x9, [x11, #0x120]
    54f0:      	ldp	q1, q0, [x10]
    54f4:      	stp	q1, q0, [x11, #0x100]
    54f8:      	ldr	x11, [sp, #0x330]
    54fc:      	str	x9, [x11, #0x20]
    5500:      	ldr	x9, [sp, #0x1c38]
    5504:      	ldr	x10, [sp, #0x1c68]
    5508:      	adds	x9, x9, x10
    550c:      	csinv	x10, x9, xzr, lo
    5510:      	lsr	x9, x8, #14
    5514:      	stp	q1, q0, [x11]
    5518:      	cbnz	x9, 0x558c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1f10>
    551c:      	sub	x9, x8, x8, lsr #2
    5520:      	cmp	x10, x9
    5524:      	b.lo	0x558c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1f10>
    5528:      	ldr	x0, [sp, #0x348]
    552c:      	ldr	x10, [x0, #0x20]
    5530:      	add	x11, sp, #0x1, lsl #12  ; =0x1000
    5534:      	add	x11, x11, #0xb20
    5538:      	str	x10, [x11, #0x170]
    553c:      	ldp	q1, q0, [x0]
    5540:      	stp	q1, q0, [x11, #0x150]
    5544:      	ldr	x10, [sp, #0x1c88]
    5548:      	cmp	x8, #0x2, lsl #12       ; =0x2000
    554c:      	mov	w11, #0x2000            ; =8192
    5550:      	csel	x11, x8, x11, lo
    5554:      	lsl	x11, x11, #1
    5558:      	cmp	x8, #0x0
    555c:      	csinc	x11, x11, xzr, ne
    5560:      	cmp	x10, x9, lsr #1
    5564:      	csel	x1, x8, x11, lo
    5568:      	mov	w8, #0x1760             ; =5984
    556c:      	add	x2, x6, x8
    5570:      	bl	0x5570 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1ef4>
		0000000000005570:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    5574:      	add	x6, sp, #0x350
    5578:      	str	w0, [sp, #0x1c98]
    557c:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
    5580:      	add	x8, x8, #0xb20
    5584:      	strb	w1, [x8, #0x17c]
    5588:      	strb	w2, [x8, #0x17d]
    558c:      	mov	w8, #0x13e8             ; =5096
    5590:      	add	x0, x6, x8
    5594:      	add	x3, sp, #0x1, lsl #12   ; =0x1000
    5598:      	add	x3, x3, #0xb20
    559c:      	add	x8, sp, #0x350
    55a0:      	mov	w9, #0x1760             ; =5984
    55a4:      	add	x4, x8, x9
    55a8:      	ldr	x1, [sp, #0x348]
    55ac:      	mov	x2, x21
    55b0:      	bl	0x55b0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1f34>
		00000000000055b0:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
    55b4:      	ldr	w8, [sp, #0x1738]
    55b8:      	cbz	w8, 0x5740 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x20c4>
    55bc:      	ldr	x8, [sp, #0x320]
    55c0:      	ldrb	w21, [x8, #0x10c]
    55c4:      	ldr	x0, [sp, #0xe0]
    55c8:      	ldr	x1, [sp, #0xc8]
    55cc:      	mov	w2, #0x108              ; =264
    55d0:      	bl	0x55d0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1f54>
		00000000000055d0:  ARM64_RELOC_BRANCH26	_memcpy
    55d4:      	ldr	x8, [sp, #0x1ae8]
    55d8:      	cmp	w21, #0x0
    55dc:      	mov	w3, #0x1                ; =1
    55e0:      	cinc	x9, x3, ne
    55e4:      	madd	x8, x8, x28, x9
    55e8:      	ldr	x9, [sp, #0x1848]
    55ec:      	ldr	x11, [sp, #0xb8]
    55f0:      	ldp	q1, q0, [x11, #0x60]
    55f4:      	ldr	x10, [sp, #0xd8]
    55f8:      	stp	q1, q0, [x10, #0x60]
    55fc:      	ldp	q1, q0, [x11, #0x40]
    5600:      	stp	q1, q0, [x10, #0x40]
    5604:      	ldp	q1, q0, [x11, #0xa0]
    5608:      	stp	q1, q0, [x10, #0xa0]
    560c:      	ldp	q1, q0, [x11, #0x80]
    5610:      	stp	q1, q0, [x10, #0x80]
    5614:      	ldp	q1, q0, [x11, #0xe0]
    5618:      	stp	q1, q0, [x10, #0xe0]
    561c:      	ldp	q1, q0, [x11, #0xc0]
    5620:      	stp	q1, q0, [x10, #0xc0]
    5624:      	ldp	q1, q0, [x11, #0x20]
    5628:      	stp	q1, q0, [x10, #0x20]
    562c:      	ldp	q0, q1, [x11]
    5630:      	stp	q0, q1, [x10]
    5634:      	ldr	x10, [sp, #0x1950]
    5638:      	madd	x9, x9, x28, x10
    563c:      	ldr	x10, [sp, #0x1958]
    5640:      	madd	x9, x9, x28, x10
    5644:      	ldr	x10, [sp, #0x1960]
    5648:      	madd	x9, x9, x28, x10
    564c:      	ldr	x10, [sp, #0x1968]
    5650:      	madd	x9, x9, x28, x10
    5654:      	ldr	x10, [sp, #0x1970]
    5658:      	madd	x9, x9, x28, x10
    565c:      	ldr	x10, [sp, #0x1978]
    5660:      	madd	x9, x9, x28, x10
    5664:      	ldr	x10, [sp, #0x1980]
    5668:      	madd	x9, x9, x28, x10
    566c:      	ldr	x10, [sp, #0x1988]
    5670:      	madd	x9, x9, x28, x10
    5674:      	ldr	x10, [sp, #0x1990]
    5678:      	madd	x9, x9, x28, x10
    567c:      	ldr	x10, [sp, #0x1998]
    5680:      	madd	x9, x9, x28, x10
    5684:      	ldr	x10, [sp, #0x19a0]
    5688:      	madd	x9, x9, x28, x10
    568c:      	ldr	x10, [sp, #0x19a8]
    5690:      	madd	x9, x9, x28, x10
    5694:      	ldr	x10, [sp, #0x19b0]
    5698:      	madd	x9, x9, x28, x10
    569c:      	ldr	x10, [sp, #0x19b8]
    56a0:      	madd	x9, x9, x28, x10
    56a4:      	ldr	x10, [sp, #0x19c0]
    56a8:      	madd	x9, x9, x28, x10
    56ac:      	ldr	x10, [sp, #0x19c8]
    56b0:      	madd	x9, x9, x28, x10
    56b4:      	ldr	x10, [sp, #0x19d0]
    56b8:      	madd	x9, x9, x28, x10
    56bc:      	ldr	x10, [sp, #0x19d8]
    56c0:      	madd	x9, x9, x28, x10
    56c4:      	ldr	x10, [sp, #0x19e0]
    56c8:      	madd	x9, x9, x28, x10
    56cc:      	ldr	x10, [sp, #0x19e8]
    56d0:      	madd	x9, x9, x28, x10
    56d4:      	ldr	x10, [sp, #0x19f0]
    56d8:      	madd	x9, x9, x28, x10
    56dc:      	ldr	x10, [sp, #0x19f8]
    56e0:      	madd	x9, x9, x28, x10
    56e4:      	ldr	x10, [sp, #0x1a00]
    56e8:      	madd	x9, x9, x28, x10
    56ec:      	ldr	x10, [sp, #0x1a08]
    56f0:      	madd	x9, x9, x28, x10
    56f4:      	ldr	x10, [sp, #0x1a10]
    56f8:      	madd	x9, x9, x28, x10
    56fc:      	ldr	x10, [sp, #0x1a18]
    5700:      	madd	x9, x9, x28, x10
    5704:      	ldr	x10, [sp, #0x1a20]
    5708:      	madd	x9, x9, x28, x10
    570c:      	ldr	x10, [sp, #0x1a28]
    5710:      	madd	x9, x9, x28, x10
    5714:      	ldr	x10, [sp, #0x1a30]
    5718:      	madd	x9, x9, x28, x10
    571c:      	ldr	x10, [sp, #0x1a38]
    5720:      	madd	x9, x9, x28, x10
    5724:      	ldr	x10, [sp, #0x1a40]
    5728:      	add	x8, x8, x10
    572c:      	madd	x8, x9, x28, x8
    5730:      	ldr	x9, [sp, #0x1a48]
    5734:      	madd	x8, x8, x28, x9
    5738:      	add	x6, sp, #0x350
    573c:      	b	0x5930 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x22b4>
    5740:      	ldr	x8, [sp, #0x1ae8]
    5744:      	mul	x8, x8, x28
    5748:      	add	x6, sp, #0x350
    574c:      	b	0x594c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x22d0>
    5750:      	mov	w1, #0x1                ; =1
    5754:      	mov	w8, #0x1760             ; =5984
    5758:      	add	x2, x6, x8
    575c:      	ldr	x0, [sp, #0x348]
    5760:      	bl	0x5760 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x20e4>
		0000000000005760:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    5764:      	add	x6, sp, #0x350
    5768:      	str	w0, [sp, #0x1c98]
    576c:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
    5770:      	add	x8, x8, #0xb20
    5774:      	strb	w1, [x8, #0x17c]
    5778:      	strb	w2, [x8, #0x17d]
    577c:      	add	x0, x6, #0xca0
    5780:      	add	x3, sp, #0x1, lsl #12   ; =0x1000
    5784:      	add	x3, x3, #0xb20
    5788:      	add	x23, sp, #0x350
    578c:      	mov	w8, #0x1760             ; =5984
    5790:      	add	x4, x23, x8
    5794:      	ldr	x1, [sp, #0x348]
    5798:      	mov	x2, x21
    579c:      	bl	0x579c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x2120>
		000000000000579c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
    57a0:      	ldr	w8, [sp, #0xff0]
    57a4:      	cbz	w8, 0x593c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x22c0>
    57a8:      	ldr	x8, [sp, #0x228]
    57ac:      	ldrb	w21, [x8, #0xba0]
    57b0:      	add	x0, x23, #0xdb0
    57b4:      	add	x8, sp, #0x350
    57b8:      	add	x1, x8, #0xca8
    57bc:      	mov	w2, #0x108              ; =264
    57c0:      	bl	0x57c0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x2144>
		00000000000057c0:  ARM64_RELOC_BRANCH26	_memcpy
    57c4:      	ldr	x8, [sp, #0x1ae8]
    57c8:      	cmp	w21, #0x0
    57cc:      	mov	w3, #0x1                ; =1
    57d0:      	cinc	x9, x3, ne
    57d4:      	madd	x8, x8, x28, x9
    57d8:      	ldr	x9, [sp, #0x1100]
    57dc:      	ldr	x11, [sp, #0xb0]
    57e0:      	ldp	q1, q0, [x11, #0x60]
    57e4:      	ldr	x10, [sp, #0xd0]
    57e8:      	stp	q1, q0, [x10, #0x60]
    57ec:      	ldp	q1, q0, [x11, #0x40]
    57f0:      	stp	q1, q0, [x10, #0x40]
    57f4:      	ldp	q1, q0, [x11, #0xa0]
    57f8:      	stp	q1, q0, [x10, #0xa0]
    57fc:      	ldp	q1, q0, [x11, #0x80]
    5800:      	stp	q1, q0, [x10, #0x80]
    5804:      	ldp	q1, q0, [x11, #0xe0]
    5808:      	stp	q1, q0, [x10, #0xe0]
    580c:      	ldp	q1, q0, [x11, #0xc0]
    5810:      	stp	q1, q0, [x10, #0xc0]
    5814:      	ldp	q1, q0, [x11, #0x20]
    5818:      	stp	q1, q0, [x10, #0x20]
    581c:      	ldp	q0, q1, [x11]
    5820:      	stp	q0, q1, [x10]
    5824:      	ldr	x10, [sp, #0x1208]
    5828:      	madd	x9, x9, x28, x10
    582c:      	ldr	x10, [sp, #0x1210]
    5830:      	madd	x9, x9, x28, x10
    5834:      	ldr	x10, [sp, #0x1218]
    5838:      	madd	x9, x9, x28, x10
    583c:      	ldr	x10, [sp, #0x1220]
    5840:      	madd	x9, x9, x28, x10
    5844:      	ldr	x10, [sp, #0x1228]
    5848:      	madd	x9, x9, x28, x10
    584c:      	ldr	x10, [sp, #0x1230]
    5850:      	madd	x9, x9, x28, x10
    5854:      	ldr	x10, [sp, #0x1238]
    5858:      	madd	x9, x9, x28, x10
    585c:      	ldr	x10, [sp, #0x1240]
    5860:      	madd	x9, x9, x28, x10
    5864:      	ldr	x10, [sp, #0x1248]
    5868:      	madd	x9, x9, x28, x10
    586c:      	ldr	x10, [sp, #0x1250]
    5870:      	madd	x9, x9, x28, x10
    5874:      	ldr	x10, [sp, #0x1258]
    5878:      	madd	x9, x9, x28, x10
    587c:      	ldr	x10, [sp, #0x1260]
    5880:      	madd	x9, x9, x28, x10
    5884:      	ldr	x10, [sp, #0x1268]
    5888:      	madd	x9, x9, x28, x10
    588c:      	ldr	x10, [sp, #0x1270]
    5890:      	madd	x9, x9, x28, x10
    5894:      	ldr	x10, [sp, #0x1278]
    5898:      	madd	x9, x9, x28, x10
    589c:      	ldr	x10, [sp, #0x1280]
    58a0:      	madd	x9, x9, x28, x10
    58a4:      	ldr	x10, [sp, #0x1288]
    58a8:      	madd	x9, x9, x28, x10
    58ac:      	ldr	x10, [sp, #0x1290]
    58b0:      	madd	x9, x9, x28, x10
    58b4:      	ldr	x10, [sp, #0x1298]
    58b8:      	madd	x9, x9, x28, x10
    58bc:      	ldr	x10, [sp, #0x12a0]
    58c0:      	madd	x9, x9, x28, x10
    58c4:      	ldr	x10, [sp, #0x12a8]
    58c8:      	madd	x9, x9, x28, x10
    58cc:      	ldr	x10, [sp, #0x12b0]
    58d0:      	madd	x9, x9, x28, x10
    58d4:      	ldr	x10, [sp, #0x12b8]
    58d8:      	madd	x9, x9, x28, x10
    58dc:      	ldr	x10, [sp, #0x12c0]
    58e0:      	madd	x9, x9, x28, x10
    58e4:      	ldr	x10, [sp, #0x12c8]
    58e8:      	madd	x9, x9, x28, x10
    58ec:      	ldr	x10, [sp, #0x12d0]
    58f0:      	madd	x9, x9, x28, x10
    58f4:      	ldr	x10, [sp, #0x12d8]
    58f8:      	madd	x9, x9, x28, x10
    58fc:      	ldr	x10, [sp, #0x12e0]
    5900:      	madd	x9, x9, x28, x10
    5904:      	ldr	x10, [sp, #0x12e8]
    5908:      	madd	x9, x9, x28, x10
    590c:      	ldr	x10, [sp, #0x12f0]
    5910:      	madd	x9, x9, x28, x10
    5914:      	ldr	x10, [sp, #0x12f8]
    5918:      	add	x8, x8, x10
    591c:      	madd	x8, x9, x28, x8
    5920:      	ldr	x9, [sp, #0x1300]
    5924:      	madd	x8, x8, x28, x9
    5928:      	add	x6, sp, #0x350
    592c:      	ldr	x23, [sp, #0x2e0]
    5930:      	ldr	x16, [sp, #0x300]
    5934:      	mov	x17, x26
    5938:      	b	0x4b94 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1518>
    593c:      	ldr	x8, [sp, #0x1ae8]
    5940:      	mul	x8, x8, x28
    5944:      	add	x6, sp, #0x350
    5948:      	ldr	x23, [sp, #0x2e0]
    594c:      	ldr	x16, [sp, #0x300]
    5950:      	mov	x17, x26
    5954:      	mov	w3, #0x1                ; =1
    5958:      	b	0x4b94 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1518>
    595c:      	mov	w8, #0x1718             ; =5912
    5960:      	add	x9, sp, #0x350
    5964:      	add	x0, x9, x8
    5968:      	ldr	x8, [sp, #0x348]
    596c:      	ldp	q0, q1, [x8]
    5970:      	stp	q0, q1, [x0]
    5974:      	ldr	x8, [x8, #0x20]
    5978:      	str	x8, [sp, #0x1a88]
    597c:      	ldr	x19, [sp, #0x8]
    5980:      	mov	x1, x19
    5984:      	bl	0x5984 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x2308>
		0000000000005984:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71
    5988:      	ldp	q0, q1, [x19]
    598c:      	str	q0, [sp, #0x1a90]
    5990:      	str	q1, [sp, #0x1aa0]
    5994:      	ldr	x8, [sp, #0x1a90]
    5998:      	ldr	x9, [sp, #0x1a98]
    599c:      	ldr	x10, [sp, #0x1aa0]
    59a0:      	ldr	x11, [sp, #0x1aa8]
    59a4:      	eor	x8, x8, x8, lsr #30
    59a8:      	mov	x13, #0xe5b9            ; =58809
    59ac:      	movk	x13, #0x1ce4, lsl #16
    59b0:      	movk	x13, #0x476d, lsl #32
    59b4:      	movk	x13, #0xbf58, lsl #48
    59b8:      	mul	x8, x8, x13
    59bc:      	eor	x8, x8, x8, lsr #27
    59c0:      	mov	x12, #0x11eb            ; =4587
    59c4:      	movk	x12, #0x1331, lsl #16
    59c8:      	movk	x12, #0x49bb, lsl #32
    59cc:      	movk	x12, #0x94d0, lsl #48
    59d0:      	mul	x8, x8, x12
    59d4:      	eor	x9, x9, x9, lsr #30
    59d8:      	mul	x9, x9, x13
    59dc:      	eor	x9, x9, x9, lsr #27
    59e0:      	mul	x9, x9, x12
    59e4:      	eor	x12, x9, x8
    59e8:      	mov	x13, #0x7c15            ; =31765
    59ec:      	movk	x13, #0x7f4a, lsl #16
    59f0:      	movk	x13, #0x79b9, lsl #32
    59f4:      	movk	x13, #0x9e37, lsl #48
    59f8:      	mul	x11, x11, x13
    59fc:      	eor	x10, x10, x11
    5a00:      	eor	x10, x10, x12, lsr #31
    5a04:      	eor	x8, x8, x9
    5a08:      	eor	x0, x10, x8
    5a0c:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
    5a10:      	add	sp, sp, #0xca0
    5a14:      	ldp	x29, x30, [sp, #0x50]
    5a18:      	ldp	x20, x19, [sp, #0x40]
    5a1c:      	ldp	x22, x21, [sp, #0x30]
    5a20:      	ldp	x24, x23, [sp, #0x20]
    5a24:      	ldp	x26, x25, [sp, #0x10]
    5a28:      	ldp	x28, x27, [sp], #0x60
    5a2c:      	ret
    5a30:      	bl	0x5a30 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x23b4>
		0000000000005a30:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

0000000000005a34 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd>:
    5a34:      	sub	sp, sp, #0xa0
    5a38:      	stp	x28, x27, [sp, #0x40]
    5a3c:      	stp	x26, x25, [sp, #0x50]
    5a40:      	stp	x24, x23, [sp, #0x60]
    5a44:      	stp	x22, x21, [sp, #0x70]
    5a48:      	stp	x20, x19, [sp, #0x80]
    5a4c:      	stp	x29, x30, [sp, #0x90]
    5a50:      	mov	x19, x2
    5a54:      	mov	x21, x1
    5a58:      	mov	x20, x0
    5a5c:      	mov	x22, #0x7c15            ; =31765
    5a60:      	movk	x22, #0x7f4a, lsl #16
    5a64:      	movk	x22, #0x79b9, lsl #32
    5a68:      	movk	x22, #0x9e37, lsl #48
    5a6c:      	eor	x25, x2, x22
    5a70:      	str	x25, [sp, #0x28]
    5a74:      	strb	wzr, [sp, #0x30]
    5a78:      	cbz	x0, 0x5aac <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x78>
    5a7c:      	add	x8, x20, x20, lsl #1
    5a80:      	lsl	x0, x8, #3
    5a84:      	bl	0x5a84 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x50>
		0000000000005a84:  ARM64_RELOC_BRANCH26	_malloc
    5a88:      	cbz	x0, 0x5f48 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x514>
    5a8c:      	mov	x8, #0x0                ; =0
    5a90:      	add	x9, x0, #0x8
    5a94:      	stur	wzr, [x9, #-0x8]
    5a98:      	add	x8, x8, #0x1
    5a9c:      	stp	xzr, xzr, [x9], #0x18
    5aa0:      	cmp	x20, x8
    5aa4:      	b.ne	0x5a94 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x60>
    5aa8:      	b	0x5ab4 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x80>
    5aac:      	adrp	x0, 0x5000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1984>
		0000000000005aac:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    5ab0:      	add	x0, x0, #0x0
		0000000000005ab0:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    5ab4:      	mov	x24, #0xe5b9            ; =58809
    5ab8:      	movk	x24, #0x1ce4, lsl #16
    5abc:      	movk	x24, #0x476d, lsl #32
    5ac0:      	movk	x24, #0xbf58, lsl #48
    5ac4:      	mov	x16, #0x11eb            ; =4587
    5ac8:      	movk	x16, #0x1331, lsl #16
    5acc:      	movk	x16, #0x49bb, lsl #32
    5ad0:      	movk	x16, #0x94d0, lsl #48
    5ad4:      	stp	x20, x20, [sp]
    5ad8:      	stp	xzr, xzr, [sp, #0x18]
    5adc:      	str	x0, [sp, #0x10]
    5ae0:      	cbz	x21, 0x5df8 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x3c4>
    5ae4:      	mov	x26, #0x0               ; =0
    5ae8:      	ldrb	w27, [sp, #0x30]
    5aec:      	mov	w28, #0x1               ; =1
    5af0:      	mov	w22, #0x18              ; =24
    5af4:      	mov	w23, #0x83              ; =131
    5af8:      	mov	x1, x20
    5afc:      	mov	x20, x19
    5b00:      	b	0x5b28 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0xf4>
    5b04:      	strb	w28, [sp, #0x3c]
    5b08:      	tst	w28, #0x1
    5b0c:      	cinc	x10, x28, ne
    5b10:      	madd	x8, x20, x23, x8
    5b14:      	add	x8, x8, x10
    5b18:      	madd	x20, x8, x23, x9
    5b1c:      	add	x26, x26, #0x1
    5b20:      	cmp	x26, x21
    5b24:      	b.eq	0x5ce0 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x2ac>
    5b28:      	ldp	x8, x9, [sp, #0x18]
    5b2c:      	adds	x9, x8, x9
    5b30:      	csinv	x9, x9, xzr, lo
    5b34:      	lsr	x10, x1, #14
    5b38:      	cbnz	x10, 0x5b88 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x154>
    5b3c:      	sub	x10, x1, x1, lsr #2
    5b40:      	cmp	x9, x10
    5b44:      	b.lo	0x5b88 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x154>
    5b48:      	cmp	x8, x10, lsr #1
    5b4c:      	b.lo	0x5b6c <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x138>
    5b50:      	cbz	x1, 0x5b68 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x134>
    5b54:      	cmp	x1, #0x2, lsl #12       ; =0x2000
    5b58:      	mov	w8, #0x2000             ; =8192
    5b5c:      	csel	x8, x1, x8, lo
    5b60:      	lsl	x1, x8, #1
    5b64:      	b	0x5b6c <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x138>
    5b68:      	mov	w1, #0x1                ; =1
    5b6c:      	mov	x0, sp
    5b70:      	add	x2, sp, #0x28
    5b74:      	bl	0x5b74 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x140>
		0000000000005b74:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    5b78:      	mov	x16, #0x11eb            ; =4587
    5b7c:      	movk	x16, #0x1331, lsl #16
    5b80:      	movk	x16, #0x49bb, lsl #32
    5b84:      	movk	x16, #0x94d0, lsl #48
    5b88:      	orr	x8, x28, x26, lsl #1
    5b8c:      	tbz	w27, #0x0, 0x5c18 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x1e4>
    5b90:      	mov	x10, #0x0               ; =0
    5b94:      	add	x9, x26, x19
    5b98:      	ldr	x1, [sp]
    5b9c:      	cbz	x1, 0x5c3c <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x208>
    5ba0:      	udiv	x11, x10, x1
    5ba4:      	msub	x11, x11, x1, x10
    5ba8:      	ldr	x12, [sp, #0x10]
    5bac:      	mov	x13, x1
    5bb0:      	mov	x10, x1
    5bb4:      	b	0x5bd4 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x1a0>
    5bb8:      	cmp	x10, x1
    5bbc:      	csel	x10, x11, x10, eq
    5bc0:      	add	x14, x11, #0x1
    5bc4:      	cmp	x14, x1
    5bc8:      	csinc	x11, xzr, x11, hs
    5bcc:      	subs	x13, x13, #0x1
    5bd0:      	b.eq	0x5c40 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x20c>
    5bd4:      	madd	x14, x11, x22, x12
    5bd8:      	ldr	w15, [x14]
    5bdc:      	cmp	w15, #0x1
    5be0:      	b.eq	0x5bb8 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x184>
    5be4:      	cmp	w15, #0x2
    5be8:      	b.ne	0x5c90 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x25c>
    5bec:      	ldr	x15, [x14, #0x8]
    5bf0:      	cmp	x15, x8
    5bf4:      	b.ne	0x5bc0 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x18c>
    5bf8:      	ldr	x11, [x14, #0x10]
    5bfc:      	mov	w10, #0x2               ; =2
    5c00:      	str	w10, [x14]
    5c04:      	str	x9, [x14, #0x10]
    5c08:      	strb	wzr, [sp, #0x3c]
    5c0c:      	mov	w10, #0x1               ; =1
    5c10:      	mov	x9, x11
    5c14:      	b	0x5b10 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0xdc>
    5c18:      	eor	x9, x8, x25
    5c1c:      	eor	x9, x9, x9, lsr #30
    5c20:      	mul	x9, x9, x24
    5c24:      	eor	x9, x9, x9, lsr #27
    5c28:      	mul	x9, x9, x16
    5c2c:      	eor	x10, x9, x9, lsr #31
    5c30:      	add	x9, x26, x19
    5c34:      	ldr	x1, [sp]
    5c38:      	cbnz	x1, 0x5ba0 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x16c>
    5c3c:      	mov	x10, #0x0               ; =0
    5c40:      	cmp	x10, x1
    5c44:      	b.hs	0x5b04 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0xd0>
    5c48:      	ldr	x11, [sp, #0x18]
    5c4c:      	lsr	x12, x11, #14
    5c50:      	cbnz	x12, 0x5b04 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0xd0>
    5c54:      	add	x11, x11, #0x1
    5c58:      	str	x11, [sp, #0x18]
    5c5c:      	ldr	x11, [sp, #0x10]
    5c60:      	madd	x10, x10, x22, x11
    5c64:      	ldr	w13, [x10]
    5c68:      	cmp	w13, #0x1
    5c6c:      	b.ne	0x5ca4 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x270>
    5c70:      	ldr	x11, [sp, #0x20]
    5c74:      	subs	x11, x11, #0x1
    5c78:      	csel	x11, xzr, x11, lo
    5c7c:      	str	x11, [sp, #0x20]
    5c80:      	mov	w11, #0x2               ; =2
    5c84:      	str	w11, [x10]
    5c88:      	stp	x8, x9, [x10, #0x8]
    5c8c:      	b	0x5ccc <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x298>
    5c90:      	cmp	x10, x1
    5c94:      	csel	x10, x11, x10, eq
    5c98:      	cmp	x10, x1
    5c9c:      	b.hs	0x5b04 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0xd0>
    5ca0:      	b	0x5c48 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x214>
    5ca4:      	ldp	x11, x12, [x10, #0x8]
    5ca8:      	mov	w14, #0x2               ; =2
    5cac:      	str	w14, [x10]
    5cb0:      	stp	x8, x9, [x10, #0x8]
    5cb4:      	cbz	w13, 0x5ccc <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x298>
    5cb8:      	strb	wzr, [sp, #0x3c]
    5cbc:      	mov	w10, #0x1               ; =1
    5cc0:      	mov	x9, x12
    5cc4:      	mov	x8, x11
    5cc8:      	b	0x5b10 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0xdc>
    5ccc:      	strb	wzr, [sp, #0x3c]
    5cd0:      	mul	x20, x20, x23
    5cd4:      	add	x26, x26, #0x1
    5cd8:      	cmp	x26, x21
    5cdc:      	b.ne	0x5b28 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0xf4>
    5ce0:      	ldp	x0, x21, [sp, #0x10]
    5ce4:      	mov	x19, x20
    5ce8:      	ldr	x20, [sp, #0x8]
    5cec:      	mov	x22, #0x7c15            ; =31765
    5cf0:      	movk	x22, #0x7f4a, lsl #16
    5cf4:      	movk	x22, #0x79b9, lsl #32
    5cf8:      	movk	x22, #0x9e37, lsl #48
    5cfc:      	cbz	x1, 0x5e00 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x3cc>
    5d00:      	and	x8, x1, #0x3
    5d04:      	cmp	x1, #0x4
    5d08:      	b.hs	0x5e14 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x3e0>
    5d0c:      	mov	x9, #0x0                ; =0
    5d10:      	mov	x25, #0x0               ; =0
    5d14:      	mov	x26, #0x0               ; =0
    5d18:      	mov	x10, x1
    5d1c:      	cbz	x8, 0x5d78 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x344>
    5d20:      	mov	w11, #0x18              ; =24
    5d24:      	madd	x10, x10, x11, x0
    5d28:      	sub	x10, x10, #0x8
    5d2c:      	mov	w11, #0x83              ; =131
    5d30:      	b	0x5d40 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x30c>
    5d34:      	sub	x10, x10, #0x18
    5d38:      	subs	x8, x8, #0x1
    5d3c:      	b.eq	0x5d78 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x344>
    5d40:      	ldur	w12, [x10, #-0x10]
    5d44:      	cmp	w12, #0x2
    5d48:      	b.ne	0x5d34 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x300>
    5d4c:      	ldp	x13, x12, [x10, #-0x8]
    5d50:      	madd	x12, x13, x11, x12
    5d54:      	add	x26, x12, x26
    5d58:      	eor	x12, x12, x12, lsr #30
    5d5c:      	mul	x12, x12, x24
    5d60:      	eor	x12, x12, x12, lsr #27
    5d64:      	mul	x12, x12, x16
    5d68:      	eor	x13, x25, x12, lsr #31
    5d6c:      	eor	x25, x13, x12
    5d70:      	add	x9, x9, #0x1
    5d74:      	b	0x5d34 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x300>
    5d78:      	mul	x22, x9, x22
    5d7c:      	cbz	x20, 0x5d9c <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x368>
    5d80:      	mov	x20, x1
    5d84:      	bl	0x5d84 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x350>
		0000000000005d84:  ARM64_RELOC_BRANCH26	_free
    5d88:      	mov	x16, #0x11eb            ; =4587
    5d8c:      	movk	x16, #0x1331, lsl #16
    5d90:      	movk	x16, #0x49bb, lsl #32
    5d94:      	movk	x16, #0x94d0, lsl #48
    5d98:      	mov	x1, x20
    5d9c:      	add	x8, x21, x1, lsl #32
    5da0:      	eor	x9, x19, x19, lsr #30
    5da4:      	mul	x9, x9, x24
    5da8:      	eor	x9, x9, x9, lsr #27
    5dac:      	mul	x9, x9, x16
    5db0:      	eor	x10, x26, x26, lsr #30
    5db4:      	mul	x10, x10, x24
    5db8:      	eor	x10, x10, x10, lsr #27
    5dbc:      	mul	x10, x10, x16
    5dc0:      	eor	x11, x10, x9
    5dc4:      	eor	x8, x8, x25
    5dc8:      	eor	x8, x8, x22
    5dcc:      	eor	x8, x8, x11, lsr #31
    5dd0:      	eor	x9, x9, x10
    5dd4:      	eor	x0, x8, x9
    5dd8:      	ldp	x29, x30, [sp, #0x90]
    5ddc:      	ldp	x20, x19, [sp, #0x80]
    5de0:      	ldp	x22, x21, [sp, #0x70]
    5de4:      	ldp	x24, x23, [sp, #0x60]
    5de8:      	ldp	x26, x25, [sp, #0x50]
    5dec:      	ldp	x28, x27, [sp, #0x40]
    5df0:      	add	sp, sp, #0xa0
    5df4:      	ret
    5df8:      	mov	x1, x20
    5dfc:      	cbnz	x20, 0x5d00 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x2cc>
    5e00:      	mov	x22, #0x0               ; =0
    5e04:      	mov	x25, #0x0               ; =0
    5e08:      	mov	x26, #0x0               ; =0
    5e0c:      	cbnz	x20, 0x5d80 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x34c>
    5e10:      	b	0x5d9c <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x368>
    5e14:      	mov	x9, #0x0                ; =0
    5e18:      	mov	x25, #0x0               ; =0
    5e1c:      	mov	x26, #0x0               ; =0
    5e20:      	and	x11, x1, #0xfffffffffffffffc
    5e24:      	mov	w10, #0x18              ; =24
    5e28:      	madd	x10, x1, x10, x0
    5e2c:      	sub	x12, x10, #0x30
    5e30:      	mov	w13, #0x83              ; =131
    5e34:      	mov	x10, x1
    5e38:      	b	0x5e4c <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x418>
    5e3c:      	sub	x12, x12, #0x60
    5e40:      	sub	x10, x10, #0x4
    5e44:      	sub	x11, x11, #0x4
    5e48:      	cbz	x11, 0x5d1c <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x2e8>
    5e4c:      	ldr	w14, [x12, #0x18]
    5e50:      	cmp	w14, #0x2
    5e54:      	b.eq	0x5e80 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x44c>
    5e58:      	ldr	w14, [x12]
    5e5c:      	cmp	w14, #0x2
    5e60:      	b.eq	0x5eb4 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x480>
    5e64:      	ldur	w14, [x12, #-0x18]
    5e68:      	cmp	w14, #0x2
    5e6c:      	b.eq	0x5ee8 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x4b4>
    5e70:      	ldur	w14, [x12, #-0x30]
    5e74:      	cmp	w14, #0x2
    5e78:      	b.ne	0x5e3c <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x408>
    5e7c:      	b	0x5f1c <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x4e8>
    5e80:      	ldp	x15, x14, [x12, #0x20]
    5e84:      	madd	x14, x15, x13, x14
    5e88:      	add	x26, x14, x26
    5e8c:      	eor	x14, x14, x14, lsr #30
    5e90:      	mul	x14, x14, x24
    5e94:      	eor	x14, x14, x14, lsr #27
    5e98:      	mul	x14, x14, x16
    5e9c:      	eor	x15, x25, x14, lsr #31
    5ea0:      	eor	x25, x15, x14
    5ea4:      	add	x9, x9, #0x1
    5ea8:      	ldr	w14, [x12]
    5eac:      	cmp	w14, #0x2
    5eb0:      	b.ne	0x5e64 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x430>
    5eb4:      	ldp	x15, x14, [x12, #0x8]
    5eb8:      	madd	x14, x15, x13, x14
    5ebc:      	add	x26, x14, x26
    5ec0:      	eor	x14, x14, x14, lsr #30
    5ec4:      	mul	x14, x14, x24
    5ec8:      	eor	x14, x14, x14, lsr #27
    5ecc:      	mul	x14, x14, x16
    5ed0:      	eor	x15, x25, x14, lsr #31
    5ed4:      	eor	x25, x15, x14
    5ed8:      	add	x9, x9, #0x1
    5edc:      	ldur	w14, [x12, #-0x18]
    5ee0:      	cmp	w14, #0x2
    5ee4:      	b.ne	0x5e70 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x43c>
    5ee8:      	ldp	x15, x14, [x12, #-0x10]
    5eec:      	madd	x14, x15, x13, x14
    5ef0:      	add	x26, x14, x26
    5ef4:      	eor	x14, x14, x14, lsr #30
    5ef8:      	mul	x14, x14, x24
    5efc:      	eor	x14, x14, x14, lsr #27
    5f00:      	mul	x14, x14, x16
    5f04:      	eor	x15, x25, x14, lsr #31
    5f08:      	eor	x25, x15, x14
    5f0c:      	add	x9, x9, #0x1
    5f10:      	ldur	w14, [x12, #-0x30]
    5f14:      	cmp	w14, #0x2
    5f18:      	b.ne	0x5e3c <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x408>
    5f1c:      	ldp	x15, x14, [x12, #-0x28]
    5f20:      	madd	x14, x15, x13, x14
    5f24:      	add	x26, x14, x26
    5f28:      	eor	x14, x14, x14, lsr #30
    5f2c:      	mul	x14, x14, x24
    5f30:      	eor	x14, x14, x14, lsr #27
    5f34:      	mul	x14, x14, x16
    5f38:      	eor	x15, x25, x14, lsr #31
    5f3c:      	eor	x25, x15, x14
    5f40:      	add	x9, x9, #0x1
    5f44:      	b	0x5e3c <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x408>
    5f48:      	bl	0x5f48 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x514>
		0000000000005f48:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

0000000000005f4c <_wf_map_cost_library_geometry$instance$4250cb78d3f44027>:
    5f4c:      	stp	x28, x27, [sp, #-0x60]!
    5f50:      	stp	x26, x25, [sp, #0x10]
    5f54:      	stp	x24, x23, [sp, #0x20]
    5f58:      	stp	x22, x21, [sp, #0x30]
    5f5c:      	stp	x20, x19, [sp, #0x40]
    5f60:      	stp	x29, x30, [sp, #0x50]
    5f64:      	sub	sp, sp, #0x3e0
    5f68:      	mov	x19, x2
    5f6c:      	mov	x20, x1
    5f70:      	mov	x21, x0
    5f74:      	mov	x22, #0x7c15            ; =31765
    5f78:      	movk	x22, #0x7f4a, lsl #16
    5f7c:      	movk	x22, #0x79b9, lsl #32
    5f80:      	movk	x22, #0x9e37, lsl #48
    5f84:      	eor	x8, x2, x22
    5f88:      	str	x8, [sp, #0x140]
    5f8c:      	strb	wzr, [sp, #0x148]
    5f90:      	cbz	x0, 0x6274 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x328>
    5f94:      	add	x8, x21, x21, lsl #4
    5f98:      	lsl	x0, x8, #4
    5f9c:      	bl	0x5f9c <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x50>
		0000000000005f9c:  ARM64_RELOC_BRANCH26	_malloc
    5fa0:      	cbz	x0, 0x632c <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x3e0>
    5fa4:      	mov	x8, #0x0                ; =0
    5fa8:      	add	x9, x0, #0x8
    5fac:      	movi.2d	v0, #0000000000000000
    5fb0:      	stur	wzr, [x9, #-0x8]
    5fb4:      	add	x8, x8, #0x1
    5fb8:      	stp	q0, q0, [x9]
    5fbc:      	stp	q0, q0, [x9, #0x20]
    5fc0:      	stp	q0, q0, [x9, #0x40]
    5fc4:      	stp	q0, q0, [x9, #0x60]
    5fc8:      	stp	q0, q0, [x9, #0x80]
    5fcc:      	stp	q0, q0, [x9, #0xa0]
    5fd0:      	stp	q0, q0, [x9, #0xc0]
    5fd4:      	stp	q0, q0, [x9, #0xe0]
    5fd8:      	str	xzr, [x9, #0x100]
    5fdc:      	add	x9, x9, #0x110
    5fe0:      	cmp	x21, x8
    5fe4:      	b.ne	0x5fb0 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x64>
    5fe8:      	stp	x21, x21, [sp, #0x118]
    5fec:      	stp	xzr, xzr, [sp, #0x130]
    5ff0:      	str	x0, [sp, #0x128]
    5ff4:      	stp	x19, xzr, [sp, #0xf8]
    5ff8:      	stp	xzr, xzr, [sp, #0x108]
    5ffc:      	cbz	x20, 0x6294 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x348>
    6000:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		0000000000006000:  ARM64_RELOC_PAGE21	lCPI70_0
    6004:      	ldr	q0, [x8]
		0000000000006004:  ARM64_RELOC_PAGEOFF12	lCPI70_0
    6008:      	str	q0, [sp, #0xe0]
    600c:      	add	x23, sp, #0x260
    6010:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		0000000000006010:  ARM64_RELOC_PAGE21	lCPI70_1
    6014:      	ldr	q0, [x8]
		0000000000006014:  ARM64_RELOC_PAGEOFF12	lCPI70_1
    6018:      	str	q0, [sp, #0xd0]
    601c:      	add	x24, sp, #0x260
    6020:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		0000000000006020:  ARM64_RELOC_PAGE21	lCPI70_2
    6024:      	ldr	q0, [x8]
		0000000000006024:  ARM64_RELOC_PAGEOFF12	lCPI70_2
    6028:      	str	q0, [sp, #0xc0]
    602c:      	add	x25, x24, #0x128
    6030:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		0000000000006030:  ARM64_RELOC_PAGE21	lCPI70_3
    6034:      	ldr	q0, [x8]
		0000000000006034:  ARM64_RELOC_PAGEOFF12	lCPI70_3
    6038:      	str	q0, [sp, #0xb0]
    603c:      	mov	w21, #0x1               ; =1
    6040:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		0000000000006040:  ARM64_RELOC_PAGE21	lCPI70_4
    6044:      	ldr	q0, [x8]
		0000000000006044:  ARM64_RELOC_PAGEOFF12	lCPI70_4
    6048:      	str	q0, [sp, #0xa0]
    604c:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		000000000000604c:  ARM64_RELOC_PAGE21	lCPI70_5
    6050:      	ldr	q0, [x8]
		0000000000006050:  ARM64_RELOC_PAGEOFF12	lCPI70_5
    6054:      	str	q0, [sp, #0x90]
    6058:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		0000000000006058:  ARM64_RELOC_PAGE21	lCPI70_6
    605c:      	ldr	q0, [x8]
		000000000000605c:  ARM64_RELOC_PAGEOFF12	lCPI70_6
    6060:      	str	q0, [sp, #0x80]
    6064:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		0000000000006064:  ARM64_RELOC_PAGE21	lCPI70_7
    6068:      	ldr	q0, [x8]
		0000000000006068:  ARM64_RELOC_PAGEOFF12	lCPI70_7
    606c:      	str	q0, [sp, #0x70]
    6070:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		0000000000006070:  ARM64_RELOC_PAGE21	lCPI70_8
    6074:      	ldr	q0, [x8]
		0000000000006074:  ARM64_RELOC_PAGEOFF12	lCPI70_8
    6078:      	str	q0, [sp, #0x60]
    607c:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		000000000000607c:  ARM64_RELOC_PAGE21	lCPI70_9
    6080:      	ldr	q0, [x8]
		0000000000006080:  ARM64_RELOC_PAGEOFF12	lCPI70_9
    6084:      	str	q0, [sp, #0x50]
    6088:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		0000000000006088:  ARM64_RELOC_PAGE21	lCPI70_10
    608c:      	ldr	q0, [x8]
		000000000000608c:  ARM64_RELOC_PAGEOFF12	lCPI70_10
    6090:      	str	q0, [sp, #0x40]
    6094:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		0000000000006094:  ARM64_RELOC_PAGE21	lCPI70_11
    6098:      	ldr	q0, [x8]
		0000000000006098:  ARM64_RELOC_PAGEOFF12	lCPI70_11
    609c:      	str	q0, [sp, #0x30]
    60a0:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		00000000000060a0:  ARM64_RELOC_PAGE21	lCPI70_12
    60a4:      	ldr	q0, [x8]
		00000000000060a4:  ARM64_RELOC_PAGEOFF12	lCPI70_12
    60a8:      	str	q0, [sp, #0x20]
    60ac:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		00000000000060ac:  ARM64_RELOC_PAGE21	lCPI70_13
    60b0:      	ldr	q0, [x8]
		00000000000060b0:  ARM64_RELOC_PAGEOFF12	lCPI70_13
    60b4:      	str	q0, [sp, #0x10]
    60b8:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		00000000000060b8:  ARM64_RELOC_PAGE21	lCPI70_14
    60bc:      	ldr	q0, [x8]
		00000000000060bc:  ARM64_RELOC_PAGEOFF12	lCPI70_14
    60c0:      	str	q0, [sp]
    60c4:      	mov	w26, #0x2000            ; =8192
    60c8:      	b	0x6124 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1d8>
    60cc:      	cmp	x1, #0x2, lsl #12       ; =0x2000
    60d0:      	csel	x8, x1, x26, lo
    60d4:      	lsl	x1, x8, #1
    60d8:      	add	x0, sp, #0x118
    60dc:      	add	x2, sp, #0x140
    60e0:      	bl	0x60e0 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x194>
		00000000000060e0:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    60e4:      	str	w0, [sp, #0x3d8]
    60e8:      	strb	w1, [sp, #0x3dc]
    60ec:      	strb	w2, [sp, #0x3dd]
    60f0:      	add	x0, sp, #0x150
    60f4:      	add	x1, sp, #0x118
    60f8:      	add	x3, sp, #0x260
    60fc:      	add	x4, sp, #0x140
    6100:      	mov	x2, x21
    6104:      	bl	0x6104 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1b8>
		0000000000006104:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
    6108:      	add	x0, sp, #0x150
    610c:      	add	x1, sp, #0xf8
    6110:      	bl	0x6110 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1c4>
		0000000000006110:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
    6114:      	add	x19, x19, #0x1
    6118:      	add	x21, x21, #0x2
    611c:      	subs	x20, x20, #0x1
    6120:      	b.eq	0x6268 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x31c>
    6124:      	dup.2d	v0, x19
    6128:      	add	x8, x19, #0x1f
    612c:      	ldr	q1, [sp, #0xe0]
    6130:      	add.2d	v1, v0, v1
    6134:      	stur	q1, [x23, #0x8]
    6138:      	ldr	q1, [sp, #0xd0]
    613c:      	add.2d	v1, v0, v1
    6140:      	stur	q1, [x23, #0x18]
    6144:      	ldr	q1, [sp, #0xc0]
    6148:      	add.2d	v1, v0, v1
    614c:      	stur	q1, [x23, #0x28]
    6150:      	ldr	q1, [sp, #0xb0]
    6154:      	add.2d	v1, v0, v1
    6158:      	stur	q1, [x23, #0x38]
    615c:      	ldr	q1, [sp, #0xa0]
    6160:      	add.2d	v1, v0, v1
    6164:      	stur	q1, [x23, #0x48]
    6168:      	ldr	q1, [sp, #0x90]
    616c:      	add.2d	v1, v0, v1
    6170:      	stur	q1, [x23, #0x58]
    6174:      	ldr	q1, [sp, #0x80]
    6178:      	add.2d	v1, v0, v1
    617c:      	stur	q1, [x23, #0x68]
    6180:      	ldr	q1, [sp, #0x70]
    6184:      	add.2d	v1, v0, v1
    6188:      	stur	q1, [x23, #0x78]
    618c:      	ldr	q1, [sp, #0x60]
    6190:      	add.2d	v1, v0, v1
    6194:      	stur	q1, [x23, #0x88]
    6198:      	ldr	q1, [sp, #0x50]
    619c:      	add.2d	v1, v0, v1
    61a0:      	stur	q1, [x23, #0x98]
    61a4:      	ldr	q1, [sp, #0x40]
    61a8:      	add.2d	v1, v0, v1
    61ac:      	stur	q1, [x23, #0xa8]
    61b0:      	ldr	q1, [sp, #0x30]
    61b4:      	add.2d	v1, v0, v1
    61b8:      	stur	q1, [x23, #0xb8]
    61bc:      	ldr	q1, [sp, #0x20]
    61c0:      	add.2d	v1, v0, v1
    61c4:      	stur	q1, [x23, #0xc8]
    61c8:      	ldr	q1, [sp, #0x10]
    61cc:      	add.2d	v1, v0, v1
    61d0:      	stur	q1, [x23, #0xd8]
    61d4:      	ldr	q1, [sp]
    61d8:      	add.2d	v0, v0, v1
    61dc:      	stur	q0, [x23, #0xe8]
    61e0:      	str	x19, [sp, #0x260]
    61e4:      	str	x8, [sp, #0x358]
    61e8:      	ldr	x1, [sp, #0x118]
    61ec:      	ldr	x8, [sp, #0x138]
    61f0:      	str	x8, [x24, #0x120]
    61f4:      	add	x9, sp, #0x29
    61f8:      	ldur	q0, [x9, #0xff]
    61fc:      	add	x9, sp, #0x19
    6200:      	ldur	q1, [x9, #0xff]
    6204:      	stp	q1, q0, [x24, #0x100]
    6208:      	str	x8, [x25, #0x20]
    620c:      	ldr	x8, [sp, #0x378]
    6210:      	ldr	x9, [sp, #0x3a8]
    6214:      	adds	x8, x8, x9
    6218:      	csinv	x9, x8, xzr, lo
    621c:      	lsr	x8, x1, #14
    6220:      	stp	q1, q0, [x25]
    6224:      	cbnz	x8, 0x60f0 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1a4>
    6228:      	sub	x8, x1, x1, lsr #2
    622c:      	cmp	x9, x8
    6230:      	b.lo	0x60f0 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1a4>
    6234:      	ldr	x9, [sp, #0x138]
    6238:      	str	x9, [x24, #0x170]
    623c:      	add	x9, sp, #0x29
    6240:      	ldur	q0, [x9, #0xff]
    6244:      	add	x9, sp, #0x19
    6248:      	ldur	q1, [x9, #0xff]
    624c:      	stp	q1, q0, [x24, #0x150]
    6250:      	ldr	x9, [sp, #0x3c8]
    6254:      	cmp	x9, x8, lsr #1
    6258:      	b.lo	0x60d8 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x18c>
    625c:      	cbnz	x1, 0x60cc <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x180>
    6260:      	mov	w1, #0x1                ; =1
    6264:      	b	0x60d8 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x18c>
    6268:      	ldr	x21, [sp, #0x118]
    626c:      	ldr	x8, [sp, #0x130]
    6270:      	b	0x6298 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x34c>
    6274:      	adrp	x0, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		0000000000006274:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    6278:      	add	x0, x0, #0x0
		0000000000006278:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    627c:      	stp	x21, x21, [sp, #0x118]
    6280:      	stp	xzr, xzr, [sp, #0x130]
    6284:      	str	x0, [sp, #0x128]
    6288:      	stp	x19, xzr, [sp, #0xf8]
    628c:      	stp	xzr, xzr, [sp, #0x108]
    6290:      	cbnz	x20, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
    6294:      	mov	x8, #0x0                ; =0
    6298:      	add	x19, x8, x21, lsl #32
    629c:      	add	x0, sp, #0x118
    62a0:      	add	x1, sp, #0xf8
    62a4:      	bl	0x62a4 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x358>
		00000000000062a4:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71
    62a8:      	ldp	x8, x9, [sp, #0xf8]
    62ac:      	ldp	x10, x11, [sp, #0x108]
    62b0:      	eor	x8, x8, x8, lsr #30
    62b4:      	mov	x12, #0xe5b9            ; =58809
    62b8:      	movk	x12, #0x1ce4, lsl #16
    62bc:      	movk	x12, #0x476d, lsl #32
    62c0:      	movk	x12, #0xbf58, lsl #48
    62c4:      	mul	x8, x8, x12
    62c8:      	eor	x8, x8, x8, lsr #27
    62cc:      	mov	x13, #0x11eb            ; =4587
    62d0:      	movk	x13, #0x1331, lsl #16
    62d4:      	movk	x13, #0x49bb, lsl #32
    62d8:      	movk	x13, #0x94d0, lsl #48
    62dc:      	mul	x8, x8, x13
    62e0:      	eor	x9, x9, x9, lsr #30
    62e4:      	mul	x9, x9, x12
    62e8:      	eor	x9, x9, x9, lsr #27
    62ec:      	mul	x9, x9, x13
    62f0:      	eor	x12, x9, x8
    62f4:      	mul	x11, x11, x22
    62f8:      	eor	x10, x19, x10
    62fc:      	eor	x10, x10, x11
    6300:      	eor	x10, x10, x12, lsr #31
    6304:      	eor	x8, x8, x9
    6308:      	eor	x0, x10, x8
    630c:      	add	sp, sp, #0x3e0
    6310:      	ldp	x29, x30, [sp, #0x50]
    6314:      	ldp	x20, x19, [sp, #0x40]
    6318:      	ldp	x22, x21, [sp, #0x30]
    631c:      	ldp	x24, x23, [sp, #0x20]
    6320:      	ldp	x26, x25, [sp, #0x10]
    6324:      	ldp	x28, x27, [sp], #0x60
    6328:      	ret
    632c:      	bl	0x632c <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x3e0>
		000000000000632c:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

0000000000006330 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd>:
    6330:      	sub	sp, sp, #0xa0
    6334:      	stp	x28, x27, [sp, #0x40]
    6338:      	stp	x26, x25, [sp, #0x50]
    633c:      	stp	x24, x23, [sp, #0x60]
    6340:      	stp	x22, x21, [sp, #0x70]
    6344:      	stp	x20, x19, [sp, #0x80]
    6348:      	stp	x29, x30, [sp, #0x90]
    634c:      	mov	x20, x3
    6350:      	mov	x19, x2
    6354:      	mov	x21, x0
    6358:      	mov	x8, #0x7c15             ; =31765
    635c:      	movk	x8, #0x7f4a, lsl #16
    6360:      	movk	x8, #0x79b9, lsl #32
    6364:      	movk	x8, #0x9e37, lsl #48
    6368:      	eor	x22, x3, x8
    636c:      	str	x22, [sp, #0x30]
    6370:      	strb	wzr, [sp, #0x38]
    6374:      	cbz	x1, 0x63c0 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x90>
    6378:      	mov	x23, x1
    637c:      	add	x8, x1, x1, lsl #1
    6380:      	lsl	x0, x8, #3
    6384:      	bl	0x6384 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x54>
		0000000000006384:  ARM64_RELOC_BRANCH26	_malloc
    6388:      	cbz	x0, 0x65b4 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x284>
    638c:      	mov	x8, #0x0                ; =0
    6390:      	add	x9, x0, #0x8
    6394:      	mov	x1, x23
    6398:      	stur	wzr, [x9, #-0x8]
    639c:      	add	x8, x8, #0x1
    63a0:      	stp	xzr, xzr, [x9], #0x18
    63a4:      	cmp	x1, x8
    63a8:      	b.ne	0x6398 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x68>
    63ac:      	stp	x1, x1, [sp, #0x8]
    63b0:      	stp	xzr, xzr, [sp, #0x20]
    63b4:      	str	x0, [sp, #0x18]
    63b8:      	cbnz	x19, 0x63d8 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0xa8>
    63bc:      	b	0x6574 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x244>
    63c0:      	adrp	x0, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		00000000000063c0:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    63c4:      	add	x0, x0, #0x0
		00000000000063c4:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    63c8:      	stp	x1, x1, [sp, #0x8]
    63cc:      	stp	xzr, xzr, [sp, #0x20]
    63d0:      	str	x0, [sp, #0x18]
    63d4:      	cbz	x19, 0x6574 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x244>
    63d8:      	mov	x23, #0x0               ; =0
    63dc:      	mov	w24, #0x1               ; =1
    63e0:      	ldrb	w25, [sp, #0x38]
    63e4:      	mov	w27, #0x18              ; =24
    63e8:      	mov	x26, #0xe5b9            ; =58809
    63ec:      	movk	x26, #0x1ce4, lsl #16
    63f0:      	movk	x26, #0x476d, lsl #32
    63f4:      	movk	x26, #0xbf58, lsl #48
    63f8:      	mov	x28, #0x11eb            ; =4587
    63fc:      	movk	x28, #0x1331, lsl #16
    6400:      	movk	x28, #0x49bb, lsl #32
    6404:      	movk	x28, #0x94d0, lsl #48
    6408:      	b	0x6424 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0xf4>
    640c:      	mov	w11, #0x2               ; =2
    6410:      	str	w11, [x10]
    6414:      	stp	x8, x9, [x10, #0x8]
    6418:      	add	x23, x23, #0x1
    641c:      	cmp	x23, x19
    6420:      	b.eq	0x6574 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x244>
    6424:      	ldp	x8, x9, [sp, #0x20]
    6428:      	adds	x9, x8, x9
    642c:      	csinv	x9, x9, xzr, lo
    6430:      	lsr	x10, x1, #14
    6434:      	cbnz	x10, 0x6474 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x144>
    6438:      	sub	x10, x1, x1, lsr #2
    643c:      	cmp	x9, x10
    6440:      	b.lo	0x6474 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x144>
    6444:      	cmp	x8, x10, lsr #1
    6448:      	b.lo	0x6468 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x138>
    644c:      	cbz	x1, 0x6464 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x134>
    6450:      	cmp	x1, #0x2, lsl #12       ; =0x2000
    6454:      	mov	w8, #0x2000             ; =8192
    6458:      	csel	x8, x1, x8, lo
    645c:      	lsl	x1, x8, #1
    6460:      	b	0x6468 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x138>
    6464:      	mov	w1, #0x1                ; =1
    6468:      	add	x0, sp, #0x8
    646c:      	add	x2, sp, #0x30
    6470:      	bl	0x6470 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x140>
		0000000000006470:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    6474:      	orr	x8, x24, x23, lsl #1
    6478:      	tbz	w25, #0x0, 0x64f4 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x1c4>
    647c:      	mov	x10, #0x0               ; =0
    6480:      	add	x9, x23, x20
    6484:      	ldr	x1, [sp, #0x8]
    6488:      	cbz	x1, 0x6518 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x1e8>
    648c:      	udiv	x11, x10, x1
    6490:      	msub	x11, x11, x1, x10
    6494:      	ldr	x12, [sp, #0x18]
    6498:      	mov	x13, x1
    649c:      	mov	x10, x1
    64a0:      	b	0x64c0 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x190>
    64a4:      	cmp	x10, x1
    64a8:      	csel	x10, x11, x10, eq
    64ac:      	add	x14, x11, #0x1
    64b0:      	cmp	x14, x1
    64b4:      	csinc	x11, xzr, x11, hs
    64b8:      	subs	x13, x13, #0x1
    64bc:      	b.eq	0x651c <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x1ec>
    64c0:      	madd	x14, x11, x27, x12
    64c4:      	ldr	w15, [x14]
    64c8:      	cmp	w15, #0x1
    64cc:      	b.eq	0x64a4 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x174>
    64d0:      	cmp	w15, #0x2
    64d4:      	b.ne	0x6560 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x230>
    64d8:      	ldr	x15, [x14, #0x8]
    64dc:      	cmp	x15, x8
    64e0:      	b.ne	0x64ac <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x17c>
    64e4:      	mov	w8, #0x2                ; =2
    64e8:      	str	w8, [x14]
    64ec:      	str	x9, [x14, #0x10]
    64f0:      	b	0x6418 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0xe8>
    64f4:      	eor	x9, x8, x22
    64f8:      	eor	x9, x9, x9, lsr #30
    64fc:      	mul	x9, x9, x26
    6500:      	eor	x9, x9, x9, lsr #27
    6504:      	mul	x9, x9, x28
    6508:      	eor	x10, x9, x9, lsr #31
    650c:      	add	x9, x23, x20
    6510:      	ldr	x1, [sp, #0x8]
    6514:      	cbnz	x1, 0x648c <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x15c>
    6518:      	mov	x10, #0x0               ; =0
    651c:      	cmp	x10, x1
    6520:      	b.hs	0x6418 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0xe8>
    6524:      	ldr	x11, [sp, #0x20]
    6528:      	lsr	x12, x11, #14
    652c:      	cbnz	x12, 0x6418 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0xe8>
    6530:      	add	x11, x11, #0x1
    6534:      	str	x11, [sp, #0x20]
    6538:      	ldr	x11, [sp, #0x18]
    653c:      	madd	x10, x10, x27, x11
    6540:      	ldr	w11, [x10]
    6544:      	cmp	w11, #0x1
    6548:      	b.ne	0x640c <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0xdc>
    654c:      	ldr	x11, [sp, #0x28]
    6550:      	subs	x11, x11, #0x1
    6554:      	csel	x11, xzr, x11, lo
    6558:      	str	x11, [sp, #0x28]
    655c:      	b	0x640c <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0xdc>
    6560:      	cmp	x10, x1
    6564:      	csel	x10, x11, x10, eq
    6568:      	cmp	x10, x1
    656c:      	b.hs	0x6418 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0xe8>
    6570:      	b	0x6524 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x1f4>
    6574:      	ldur	q0, [sp, #0x8]
    6578:      	ldur	q1, [sp, #0x18]
    657c:      	stp	q0, q1, [x21]
    6580:      	ldr	x8, [sp, #0x28]
    6584:      	str	x8, [x21, #0x20]
    6588:      	ldr	q0, [sp, #0x30]
    658c:      	stur	q0, [x21, #0x28]
    6590:      	stp	x20, x19, [x21, #0x38]
    6594:      	ldp	x29, x30, [sp, #0x90]
    6598:      	ldp	x20, x19, [sp, #0x80]
    659c:      	ldp	x22, x21, [sp, #0x70]
    65a0:      	ldp	x24, x23, [sp, #0x60]
    65a4:      	ldp	x26, x25, [sp, #0x50]
    65a8:      	ldp	x28, x27, [sp, #0x40]
    65ac:      	add	sp, sp, #0xa0
    65b0:      	ret
    65b4:      	bl	0x65b4 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x284>
		00000000000065b4:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

00000000000065b8 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027>:
    65b8:      	stp	x28, x27, [sp, #-0x60]!
    65bc:      	stp	x26, x25, [sp, #0x10]
    65c0:      	stp	x24, x23, [sp, #0x20]
    65c4:      	stp	x22, x21, [sp, #0x30]
    65c8:      	stp	x20, x19, [sp, #0x40]
    65cc:      	stp	x29, x30, [sp, #0x50]
    65d0:      	sub	sp, sp, #0x3d0
    65d4:      	mov	x20, x3
    65d8:      	mov	x19, x2
    65dc:      	mov	x22, x1
    65e0:      	mov	x21, x0
    65e4:      	mov	x8, #0x7c15             ; =31765
    65e8:      	movk	x8, #0x7f4a, lsl #16
    65ec:      	movk	x8, #0x79b9, lsl #32
    65f0:      	movk	x8, #0x9e37, lsl #48
    65f4:      	eor	x8, x3, x8
    65f8:      	str	x8, [sp, #0x130]
    65fc:      	strb	wzr, [sp, #0x138]
    6600:      	cbz	x1, 0x666c <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0xb4>
    6604:      	add	x8, x22, x22, lsl #4
    6608:      	lsl	x0, x8, #4
    660c:      	bl	0x660c <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x54>
		000000000000660c:  ARM64_RELOC_BRANCH26	_malloc
    6610:      	cbz	x0, 0x6930 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x378>
    6614:      	mov	x8, #0x0                ; =0
    6618:      	add	x9, x0, #0x8
    661c:      	movi.2d	v0, #0000000000000000
    6620:      	stur	wzr, [x9, #-0x8]
    6624:      	add	x8, x8, #0x1
    6628:      	stp	q0, q0, [x9]
    662c:      	stp	q0, q0, [x9, #0x20]
    6630:      	stp	q0, q0, [x9, #0x40]
    6634:      	stp	q0, q0, [x9, #0x60]
    6638:      	stp	q0, q0, [x9, #0x80]
    663c:      	stp	q0, q0, [x9, #0xa0]
    6640:      	stp	q0, q0, [x9, #0xc0]
    6644:      	stp	q0, q0, [x9, #0xe0]
    6648:      	str	xzr, [x9, #0x100]
    664c:      	add	x9, x9, #0x110
    6650:      	cmp	x22, x8
    6654:      	b.ne	0x6620 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x68>
    6658:      	stp	x22, x22, [sp, #0x108]
    665c:      	stp	xzr, xzr, [sp, #0x120]
    6660:      	str	x0, [sp, #0x118]
    6664:      	cbnz	x19, 0x6684 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0xcc>
    6668:      	b	0x68e8 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x330>
    666c:      	adrp	x0, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		000000000000666c:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    6670:      	add	x0, x0, #0x0
		0000000000006670:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    6674:      	stp	x22, x22, [sp, #0x108]
    6678:      	stp	xzr, xzr, [sp, #0x120]
    667c:      	str	x0, [sp, #0x118]
    6680:      	cbz	x19, 0x68e8 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x330>
    6684:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		0000000000006684:  ARM64_RELOC_PAGE21	lCPI72_0
    6688:      	ldr	q0, [x8]
		0000000000006688:  ARM64_RELOC_PAGEOFF12	lCPI72_0
    668c:      	str	q0, [sp, #0xf0]
    6690:      	add	x23, sp, #0x250
    6694:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		0000000000006694:  ARM64_RELOC_PAGE21	lCPI72_1
    6698:      	ldr	q0, [x8]
		0000000000006698:  ARM64_RELOC_PAGEOFF12	lCPI72_1
    669c:      	str	q0, [sp, #0xe0]
    66a0:      	add	x24, sp, #0x250
    66a4:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		00000000000066a4:  ARM64_RELOC_PAGE21	lCPI72_2
    66a8:      	ldr	q0, [x8]
		00000000000066a8:  ARM64_RELOC_PAGEOFF12	lCPI72_2
    66ac:      	str	q0, [sp, #0xd0]
    66b0:      	add	x25, x24, #0x128
    66b4:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		00000000000066b4:  ARM64_RELOC_PAGE21	lCPI72_3
    66b8:      	ldr	q0, [x8]
		00000000000066b8:  ARM64_RELOC_PAGEOFF12	lCPI72_3
    66bc:      	str	q0, [sp, #0xc0]
    66c0:      	mov	w22, #0x1               ; =1
    66c4:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		00000000000066c4:  ARM64_RELOC_PAGE21	lCPI72_4
    66c8:      	ldr	q0, [x8]
		00000000000066c8:  ARM64_RELOC_PAGEOFF12	lCPI72_4
    66cc:      	str	q0, [sp, #0xb0]
    66d0:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		00000000000066d0:  ARM64_RELOC_PAGE21	lCPI72_5
    66d4:      	ldr	q0, [x8]
		00000000000066d4:  ARM64_RELOC_PAGEOFF12	lCPI72_5
    66d8:      	str	q0, [sp, #0xa0]
    66dc:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		00000000000066dc:  ARM64_RELOC_PAGE21	lCPI72_6
    66e0:      	ldr	q0, [x8]
		00000000000066e0:  ARM64_RELOC_PAGEOFF12	lCPI72_6
    66e4:      	str	q0, [sp, #0x90]
    66e8:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		00000000000066e8:  ARM64_RELOC_PAGE21	lCPI72_7
    66ec:      	ldr	q0, [x8]
		00000000000066ec:  ARM64_RELOC_PAGEOFF12	lCPI72_7
    66f0:      	str	q0, [sp, #0x80]
    66f4:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		00000000000066f4:  ARM64_RELOC_PAGE21	lCPI72_8
    66f8:      	ldr	q0, [x8]
		00000000000066f8:  ARM64_RELOC_PAGEOFF12	lCPI72_8
    66fc:      	str	q0, [sp, #0x70]
    6700:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		0000000000006700:  ARM64_RELOC_PAGE21	lCPI72_9
    6704:      	ldr	q0, [x8]
		0000000000006704:  ARM64_RELOC_PAGEOFF12	lCPI72_9
    6708:      	str	q0, [sp, #0x60]
    670c:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		000000000000670c:  ARM64_RELOC_PAGE21	lCPI72_10
    6710:      	ldr	q0, [x8]
		0000000000006710:  ARM64_RELOC_PAGEOFF12	lCPI72_10
    6714:      	str	q0, [sp, #0x50]
    6718:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		0000000000006718:  ARM64_RELOC_PAGE21	lCPI72_11
    671c:      	ldr	q0, [x8]
		000000000000671c:  ARM64_RELOC_PAGEOFF12	lCPI72_11
    6720:      	str	q0, [sp, #0x40]
    6724:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		0000000000006724:  ARM64_RELOC_PAGE21	lCPI72_12
    6728:      	ldr	q0, [x8]
		0000000000006728:  ARM64_RELOC_PAGEOFF12	lCPI72_12
    672c:      	str	q0, [sp, #0x30]
    6730:      	mov	w26, #0x2000            ; =8192
    6734:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		0000000000006734:  ARM64_RELOC_PAGE21	lCPI72_13
    6738:      	ldr	q0, [x8]
		0000000000006738:  ARM64_RELOC_PAGEOFF12	lCPI72_13
    673c:      	str	q0, [sp, #0x20]
    6740:      	mov	x27, x19
    6744:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
		0000000000006744:  ARM64_RELOC_PAGE21	lCPI72_14
    6748:      	ldr	q0, [x8]
		0000000000006748:  ARM64_RELOC_PAGEOFF12	lCPI72_14
    674c:      	str	q0, [sp, #0x10]
    6750:      	mov	x28, x20
    6754:      	b	0x67a4 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x1ec>
    6758:      	cmp	x1, #0x2, lsl #12       ; =0x2000
    675c:      	csel	x8, x1, x26, lo
    6760:      	lsl	x1, x8, #1
    6764:      	add	x0, sp, #0x108
    6768:      	add	x2, sp, #0x130
    676c:      	bl	0x676c <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x1b4>
		000000000000676c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    6770:      	str	w0, [sp, #0x3c8]
    6774:      	strb	w1, [sp, #0x3cc]
    6778:      	strb	w2, [sp, #0x3cd]
    677c:      	add	x0, sp, #0x140
    6780:      	add	x1, sp, #0x108
    6784:      	add	x3, sp, #0x250
    6788:      	add	x4, sp, #0x130
    678c:      	mov	x2, x22
    6790:      	bl	0x6790 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x1d8>
		0000000000006790:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
    6794:      	add	x28, x28, #0x1
    6798:      	add	x22, x22, #0x2
    679c:      	subs	x27, x27, #0x1
    67a0:      	b.eq	0x68e8 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x330>
    67a4:      	dup.2d	v0, x28
    67a8:      	add	x8, x28, #0x1f
    67ac:      	ldr	q1, [sp, #0xf0]
    67b0:      	add.2d	v1, v0, v1
    67b4:      	stur	q1, [x23, #0x8]
    67b8:      	ldr	q1, [sp, #0xe0]
    67bc:      	add.2d	v1, v0, v1
    67c0:      	stur	q1, [x23, #0x18]
    67c4:      	ldr	q1, [sp, #0xd0]
    67c8:      	add.2d	v1, v0, v1
    67cc:      	stur	q1, [x23, #0x28]
    67d0:      	ldr	q1, [sp, #0xc0]
    67d4:      	add.2d	v1, v0, v1
    67d8:      	stur	q1, [x23, #0x38]
    67dc:      	ldr	q1, [sp, #0xb0]
    67e0:      	add.2d	v1, v0, v1
    67e4:      	stur	q1, [x23, #0x48]
    67e8:      	ldr	q1, [sp, #0xa0]
    67ec:      	add.2d	v1, v0, v1
    67f0:      	stur	q1, [x23, #0x58]
    67f4:      	ldr	q1, [sp, #0x90]
    67f8:      	add.2d	v1, v0, v1
    67fc:      	stur	q1, [x23, #0x68]
    6800:      	ldr	q1, [sp, #0x80]
    6804:      	add.2d	v1, v0, v1
    6808:      	stur	q1, [x23, #0x78]
    680c:      	ldr	q1, [sp, #0x70]
    6810:      	add.2d	v1, v0, v1
    6814:      	stur	q1, [x23, #0x88]
    6818:      	ldr	q1, [sp, #0x60]
    681c:      	add.2d	v1, v0, v1
    6820:      	stur	q1, [x23, #0x98]
    6824:      	ldr	q1, [sp, #0x50]
    6828:      	add.2d	v1, v0, v1
    682c:      	stur	q1, [x23, #0xa8]
    6830:      	ldr	q1, [sp, #0x40]
    6834:      	add.2d	v1, v0, v1
    6838:      	stur	q1, [x23, #0xb8]
    683c:      	ldr	q1, [sp, #0x30]
    6840:      	add.2d	v1, v0, v1
    6844:      	stur	q1, [x23, #0xc8]
    6848:      	ldr	q1, [sp, #0x20]
    684c:      	add.2d	v1, v0, v1
    6850:      	stur	q1, [x23, #0xd8]
    6854:      	ldr	q1, [sp, #0x10]
    6858:      	add.2d	v0, v0, v1
    685c:      	stur	q0, [x23, #0xe8]
    6860:      	str	x28, [sp, #0x250]
    6864:      	str	x8, [sp, #0x348]
    6868:      	ldr	x1, [sp, #0x108]
    686c:      	ldr	x8, [sp, #0x128]
    6870:      	str	x8, [x24, #0x120]
    6874:      	add	x9, sp, #0x19
    6878:      	ldur	q0, [x9, #0xff]
    687c:      	add	x9, sp, #0x9
    6880:      	ldur	q1, [x9, #0xff]
    6884:      	stp	q1, q0, [x24, #0x100]
    6888:      	str	x8, [x25, #0x20]
    688c:      	ldr	x8, [sp, #0x368]
    6890:      	ldr	x9, [sp, #0x398]
    6894:      	adds	x8, x8, x9
    6898:      	csinv	x9, x8, xzr, lo
    689c:      	lsr	x8, x1, #14
    68a0:      	stp	q1, q0, [x25]
    68a4:      	cbnz	x8, 0x677c <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x1c4>
    68a8:      	sub	x8, x1, x1, lsr #2
    68ac:      	cmp	x9, x8
    68b0:      	b.lo	0x677c <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x1c4>
    68b4:      	ldr	x9, [sp, #0x128]
    68b8:      	str	x9, [x24, #0x170]
    68bc:      	add	x9, sp, #0x19
    68c0:      	ldur	q0, [x9, #0xff]
    68c4:      	add	x9, sp, #0x9
    68c8:      	ldur	q1, [x9, #0xff]
    68cc:      	stp	q1, q0, [x24, #0x150]
    68d0:      	ldr	x9, [sp, #0x3b8]
    68d4:      	cmp	x9, x8, lsr #1
    68d8:      	b.lo	0x6764 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x1ac>
    68dc:      	cbnz	x1, 0x6758 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x1a0>
    68e0:      	mov	w1, #0x1                ; =1
    68e4:      	b	0x6764 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x1ac>
    68e8:      	add	x8, sp, #0x9
    68ec:      	ldur	q0, [x8, #0xff]
    68f0:      	add	x8, sp, #0x19
    68f4:      	ldur	q1, [x8, #0xff]
    68f8:      	stp	q0, q1, [x21]
    68fc:      	ldr	x8, [sp, #0x128]
    6900:      	str	x8, [x21, #0x20]
    6904:      	ldr	q0, [sp, #0x130]
    6908:      	stur	q0, [x21, #0x28]
    690c:      	stp	x20, x19, [x21, #0x38]
    6910:      	add	sp, sp, #0x3d0
    6914:      	ldp	x29, x30, [sp, #0x50]
    6918:      	ldp	x20, x19, [sp, #0x40]
    691c:      	ldp	x22, x21, [sp, #0x30]
    6920:      	ldp	x24, x23, [sp, #0x20]
    6924:      	ldp	x26, x25, [sp, #0x10]
    6928:      	ldp	x28, x27, [sp], #0x60
    692c:      	ret
    6930:      	bl	0x6930 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x378>
		0000000000006930:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

0000000000006934 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd>:
    6934:      	mov	x9, #0xe5b9             ; =58809
    6938:      	movk	x9, #0x1ce4, lsl #16
    693c:      	movk	x9, #0x476d, lsl #32
    6940:      	movk	x9, #0xbf58, lsl #48
    6944:      	mov	x8, #0x11eb             ; =4587
    6948:      	movk	x8, #0x1331, lsl #16
    694c:      	movk	x8, #0x49bb, lsl #32
    6950:      	movk	x8, #0x94d0, lsl #48
    6954:      	ldr	x10, [x0, #0x38]
    6958:      	cmp	x2, #0x0
    695c:      	mov	w11, #0x1               ; =1
    6960:      	cinc	x11, x11, ne
    6964:      	cbz	x1, 0x6a44 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x110>
    6968:      	ldr	x12, [x0, #0x40]
    696c:      	cbz	x12, 0x6a44 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x110>
    6970:      	ldrb	w15, [x0, #0x30]
    6974:      	ldr	x13, [x0]
    6978:      	cbz	x13, 0x6a24 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0xf0>
    697c:      	stp	x20, x19, [sp, #-0x10]!
    6980:      	ldr	x14, [x0, #0x10]
    6984:      	tbz	w15, #0x0, 0x6a5c <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x128>
    6988:      	mov	x15, #0x0               ; =0
    698c:      	mov	w16, #0x18              ; =24
    6990:      	mov	w17, #0x83              ; =131
    6994:      	mov	w0, #0x4309             ; =17161
    6998:      	b	0x69a8 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x74>
    699c:      	add	x15, x15, #0x1
    69a0:      	cmp	x15, x1
    69a4:      	b.eq	0x6b18 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x1e4>
    69a8:      	mov	x2, #0x0                ; =0
    69ac:      	b	0x69c0 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x8c>
    69b0:      	mul	x10, x10, x17
    69b4:      	add	x2, x2, #0x1
    69b8:      	cmp	x2, x12
    69bc:      	b.eq	0x699c <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x68>
    69c0:      	mov	x3, #0x0                ; =0
    69c4:      	add	x4, x11, x2, lsl #1
    69c8:      	mov	x5, x13
    69cc:      	b	0x69e4 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0xb0>
    69d0:      	add	x6, x3, #0x1
    69d4:      	cmp	x6, x13
    69d8:      	csinc	x3, xzr, x3, hs
    69dc:      	subs	x5, x5, #0x1
    69e0:      	b.eq	0x69b0 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x7c>
    69e4:      	madd	x6, x3, x16, x14
    69e8:      	ldr	w7, [x6]
    69ec:      	cmp	w7, #0x1
    69f0:      	b.eq	0x69d0 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x9c>
    69f4:      	cmp	w7, #0x2
    69f8:      	b.ne	0x69b0 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x7c>
    69fc:      	ldr	x7, [x6, #0x8]
    6a00:      	cmp	x7, x4
    6a04:      	b.ne	0x69d0 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x9c>
    6a08:      	ldr	x3, [x6, #0x10]
    6a0c:      	madd	x10, x10, x0, x3
    6a10:      	add	x10, x10, #0x83
    6a14:      	add	x2, x2, #0x1
    6a18:      	cmp	x2, x12
    6a1c:      	b.ne	0x69c0 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x8c>
    6a20:      	b	0x699c <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x68>
    6a24:      	and	x11, x12, #0xfffffffffffffffe
    6a28:      	cmp	x12, #0x1
    6a2c:      	tbz	w15, #0x0, 0x6b34 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x200>
    6a30:      	b.ne	0x6b4c <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x218>
    6a34:      	mov	w11, #0x83              ; =131
    6a38:      	mul	x10, x10, x11
    6a3c:      	subs	x1, x1, #0x1
    6a40:      	b.ne	0x6a38 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x104>
    6a44:      	eor	x10, x10, x10, lsr #30
    6a48:      	mul	x9, x10, x9
    6a4c:      	eor	x9, x9, x9, lsr #27
    6a50:      	mul	x8, x9, x8
    6a54:      	eor	x0, x8, x8, lsr #31
    6a58:      	ret
    6a5c:      	mov	x15, #0x0               ; =0
    6a60:      	ldr	x16, [x0, #0x28]
    6a64:      	mov	w17, #0x18              ; =24
    6a68:      	mov	w0, #0x83               ; =131
    6a6c:      	mov	w2, #0x4309             ; =17161
    6a70:      	b	0x6a80 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x14c>
    6a74:      	add	x15, x15, #0x1
    6a78:      	cmp	x15, x1
    6a7c:      	b.eq	0x6b18 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x1e4>
    6a80:      	mov	x3, #0x0                ; =0
    6a84:      	b	0x6a98 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x164>
    6a88:      	mul	x10, x10, x0
    6a8c:      	add	x3, x3, #0x1
    6a90:      	cmp	x3, x12
    6a94:      	b.eq	0x6a74 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x140>
    6a98:      	add	x4, x11, x3, lsl #1
    6a9c:      	eor	x5, x16, x4
    6aa0:      	eor	x5, x5, x5, lsr #30
    6aa4:      	mul	x5, x5, x9
    6aa8:      	eor	x5, x5, x5, lsr #27
    6aac:      	mul	x5, x5, x8
    6ab0:      	eor	x5, x5, x5, lsr #31
    6ab4:      	udiv	x6, x5, x13
    6ab8:      	msub	x5, x6, x13, x5
    6abc:      	mov	x6, x13
    6ac0:      	b	0x6ad8 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x1a4>
    6ac4:      	add	x7, x5, #0x1
    6ac8:      	cmp	x7, x13
    6acc:      	csinc	x5, xzr, x5, hs
    6ad0:      	subs	x6, x6, #0x1
    6ad4:      	b.eq	0x6a88 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x154>
    6ad8:      	madd	x7, x5, x17, x14
    6adc:      	ldr	w19, [x7]
    6ae0:      	cmp	w19, #0x1
    6ae4:      	b.eq	0x6ac4 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x190>
    6ae8:      	cmp	w19, #0x2
    6aec:      	b.ne	0x6a88 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x154>
    6af0:      	ldr	x19, [x7, #0x8]
    6af4:      	cmp	x19, x4
    6af8:      	b.ne	0x6ac4 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x190>
    6afc:      	ldr	x4, [x7, #0x10]
    6b00:      	madd	x10, x10, x2, x4
    6b04:      	add	x10, x10, #0x83
    6b08:      	add	x3, x3, #0x1
    6b0c:      	cmp	x3, x12
    6b10:      	b.ne	0x6a98 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x164>
    6b14:      	b	0x6a74 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x140>
    6b18:      	ldp	x20, x19, [sp], #0x10
    6b1c:      	eor	x10, x10, x10, lsr #30
    6b20:      	mul	x9, x10, x9
    6b24:      	eor	x9, x9, x9, lsr #27
    6b28:      	mul	x8, x9, x8
    6b2c:      	eor	x0, x8, x8, lsr #31
    6b30:      	ret
    6b34:      	b.ne	0x6b84 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x250>
    6b38:      	mov	w11, #0x83              ; =131
    6b3c:      	mul	x10, x10, x11
    6b40:      	subs	x1, x1, #0x1
    6b44:      	b.ne	0x6b3c <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x208>
    6b48:      	b	0x6a44 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x110>
    6b4c:      	subs	x12, x12, x11
    6b50:      	b.ne	0x6bbc <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x288>
    6b54:      	mov	w13, #0x83              ; =131
    6b58:      	mov	x14, x11
    6b5c:      	mov	w15, #0x1               ; =1
    6b60:      	mul	x10, x10, x13
    6b64:      	mul	x15, x15, x13
    6b68:      	subs	x14, x14, #0x2
    6b6c:      	b.ne	0x6b60 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x22c>
    6b70:      	mul	x10, x15, x10
    6b74:      	add	x12, x12, #0x1
    6b78:      	cmp	x12, x1
    6b7c:      	b.ne	0x6b58 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x224>
    6b80:      	b	0x6a44 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x110>
    6b84:      	subs	x12, x12, x11
    6b88:      	b.ne	0x6c00 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x2cc>
    6b8c:      	mov	w13, #0x83              ; =131
    6b90:      	mov	x14, x11
    6b94:      	mov	w15, #0x1               ; =1
    6b98:      	mul	x10, x10, x13
    6b9c:      	mul	x15, x15, x13
    6ba0:      	subs	x14, x14, #0x2
    6ba4:      	b.ne	0x6b98 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x264>
    6ba8:      	mul	x10, x15, x10
    6bac:      	add	x12, x12, #0x1
    6bb0:      	cmp	x12, x1
    6bb4:      	b.ne	0x6b90 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x25c>
    6bb8:      	b	0x6a44 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x110>
    6bbc:      	mov	x13, #0x0               ; =0
    6bc0:      	mov	w14, #0x83              ; =131
    6bc4:      	mov	x15, x11
    6bc8:      	mov	w16, #0x1               ; =1
    6bcc:      	mul	x10, x10, x14
    6bd0:      	mul	x16, x16, x14
    6bd4:      	subs	x15, x15, #0x2
    6bd8:      	b.ne	0x6bcc <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x298>
    6bdc:      	mul	x10, x16, x10
    6be0:      	mov	x15, x12
    6be4:      	mul	x10, x10, x14
    6be8:      	subs	x15, x15, #0x1
    6bec:      	b.ne	0x6be4 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x2b0>
    6bf0:      	add	x13, x13, #0x1
    6bf4:      	cmp	x13, x1
    6bf8:      	b.ne	0x6bc4 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x290>
    6bfc:      	b	0x6a44 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x110>
    6c00:      	mov	x13, #0x0               ; =0
    6c04:      	mov	w14, #0x83              ; =131
    6c08:      	mov	x15, x11
    6c0c:      	mov	w16, #0x1               ; =1
    6c10:      	mul	x10, x10, x14
    6c14:      	mul	x16, x16, x14
    6c18:      	subs	x15, x15, #0x2
    6c1c:      	b.ne	0x6c10 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x2dc>
    6c20:      	mul	x10, x16, x10
    6c24:      	mov	x15, x12
    6c28:      	mul	x10, x10, x14
    6c2c:      	subs	x15, x15, #0x1
    6c30:      	b.ne	0x6c28 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x2f4>
    6c34:      	add	x13, x13, #0x1
    6c38:      	cmp	x13, x1
    6c3c:      	b.ne	0x6c08 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x2d4>
    6c40:      	b	0x6a44 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x110>

0000000000006c44 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027>:
    6c44:      	mov	x9, #0xe5b9             ; =58809
    6c48:      	movk	x9, #0x1ce4, lsl #16
    6c4c:      	movk	x9, #0x476d, lsl #32
    6c50:      	movk	x9, #0xbf58, lsl #48
    6c54:      	mov	x8, #0x11eb             ; =4587
    6c58:      	movk	x8, #0x1331, lsl #16
    6c5c:      	movk	x8, #0x49bb, lsl #32
    6c60:      	movk	x8, #0x94d0, lsl #48
    6c64:      	ldr	x10, [x0, #0x38]
    6c68:      	cmp	x2, #0x0
    6c6c:      	mov	w11, #0x1               ; =1
    6c70:      	cinc	x11, x11, ne
    6c74:      	cbz	x1, 0x6d54 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x110>
    6c78:      	ldr	x12, [x0, #0x40]
    6c7c:      	cbz	x12, 0x6d54 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x110>
    6c80:      	ldrb	w15, [x0, #0x30]
    6c84:      	ldr	x13, [x0]
    6c88:      	cbz	x13, 0x6d34 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0xf0>
    6c8c:      	stp	x20, x19, [sp, #-0x10]!
    6c90:      	ldr	x14, [x0, #0x10]
    6c94:      	tbz	w15, #0x0, 0x6d6c <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x128>
    6c98:      	mov	x15, #0x0               ; =0
    6c9c:      	mov	w16, #0x110             ; =272
    6ca0:      	mov	w17, #0x83              ; =131
    6ca4:      	mov	w0, #0x4309             ; =17161
    6ca8:      	b	0x6cb8 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x74>
    6cac:      	add	x15, x15, #0x1
    6cb0:      	cmp	x15, x1
    6cb4:      	b.eq	0x6e28 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x1e4>
    6cb8:      	mov	x2, #0x0                ; =0
    6cbc:      	b	0x6cd0 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x8c>
    6cc0:      	mul	x10, x10, x17
    6cc4:      	add	x2, x2, #0x1
    6cc8:      	cmp	x2, x12
    6ccc:      	b.eq	0x6cac <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x68>
    6cd0:      	mov	x3, #0x0                ; =0
    6cd4:      	add	x4, x11, x2, lsl #1
    6cd8:      	mov	x5, x13
    6cdc:      	b	0x6cf4 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0xb0>
    6ce0:      	add	x6, x3, #0x1
    6ce4:      	cmp	x6, x13
    6ce8:      	csinc	x3, xzr, x3, hs
    6cec:      	subs	x5, x5, #0x1
    6cf0:      	b.eq	0x6cc0 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x7c>
    6cf4:      	madd	x6, x3, x16, x14
    6cf8:      	ldr	w7, [x6]
    6cfc:      	cmp	w7, #0x1
    6d00:      	b.eq	0x6ce0 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x9c>
    6d04:      	cmp	w7, #0x2
    6d08:      	b.ne	0x6cc0 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x7c>
    6d0c:      	ldr	x7, [x6, #0x8]
    6d10:      	cmp	x7, x4
    6d14:      	b.ne	0x6ce0 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x9c>
    6d18:      	ldr	x3, [x6, #0x10]
    6d1c:      	madd	x10, x10, x0, x3
    6d20:      	add	x10, x10, #0x83
    6d24:      	add	x2, x2, #0x1
    6d28:      	cmp	x2, x12
    6d2c:      	b.ne	0x6cd0 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x8c>
    6d30:      	b	0x6cac <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x68>
    6d34:      	and	x11, x12, #0xfffffffffffffffe
    6d38:      	cmp	x12, #0x1
    6d3c:      	tbz	w15, #0x0, 0x6e44 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x200>
    6d40:      	b.ne	0x6e5c <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x218>
    6d44:      	mov	w11, #0x83              ; =131
    6d48:      	mul	x10, x10, x11
    6d4c:      	subs	x1, x1, #0x1
    6d50:      	b.ne	0x6d48 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x104>
    6d54:      	eor	x10, x10, x10, lsr #30
    6d58:      	mul	x9, x10, x9
    6d5c:      	eor	x9, x9, x9, lsr #27
    6d60:      	mul	x8, x9, x8
    6d64:      	eor	x0, x8, x8, lsr #31
    6d68:      	ret
    6d6c:      	mov	x15, #0x0               ; =0
    6d70:      	ldr	x16, [x0, #0x28]
    6d74:      	mov	w17, #0x110             ; =272
    6d78:      	mov	w0, #0x83               ; =131
    6d7c:      	mov	w2, #0x4309             ; =17161
    6d80:      	b	0x6d90 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x14c>
    6d84:      	add	x15, x15, #0x1
    6d88:      	cmp	x15, x1
    6d8c:      	b.eq	0x6e28 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x1e4>
    6d90:      	mov	x3, #0x0                ; =0
    6d94:      	b	0x6da8 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x164>
    6d98:      	mul	x10, x10, x0
    6d9c:      	add	x3, x3, #0x1
    6da0:      	cmp	x3, x12
    6da4:      	b.eq	0x6d84 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x140>
    6da8:      	add	x4, x11, x3, lsl #1
    6dac:      	eor	x5, x16, x4
    6db0:      	eor	x5, x5, x5, lsr #30
    6db4:      	mul	x5, x5, x9
    6db8:      	eor	x5, x5, x5, lsr #27
    6dbc:      	mul	x5, x5, x8
    6dc0:      	eor	x5, x5, x5, lsr #31
    6dc4:      	udiv	x6, x5, x13
    6dc8:      	msub	x5, x6, x13, x5
    6dcc:      	mov	x6, x13
    6dd0:      	b	0x6de8 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x1a4>
    6dd4:      	add	x7, x5, #0x1
    6dd8:      	cmp	x7, x13
    6ddc:      	csinc	x5, xzr, x5, hs
    6de0:      	subs	x6, x6, #0x1
    6de4:      	b.eq	0x6d98 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x154>
    6de8:      	madd	x7, x5, x17, x14
    6dec:      	ldr	w19, [x7]
    6df0:      	cmp	w19, #0x1
    6df4:      	b.eq	0x6dd4 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x190>
    6df8:      	cmp	w19, #0x2
    6dfc:      	b.ne	0x6d98 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x154>
    6e00:      	ldr	x19, [x7, #0x8]
    6e04:      	cmp	x19, x4
    6e08:      	b.ne	0x6dd4 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x190>
    6e0c:      	ldr	x4, [x7, #0x10]
    6e10:      	madd	x10, x10, x2, x4
    6e14:      	add	x10, x10, #0x83
    6e18:      	add	x3, x3, #0x1
    6e1c:      	cmp	x3, x12
    6e20:      	b.ne	0x6da8 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x164>
    6e24:      	b	0x6d84 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x140>
    6e28:      	ldp	x20, x19, [sp], #0x10
    6e2c:      	eor	x10, x10, x10, lsr #30
    6e30:      	mul	x9, x10, x9
    6e34:      	eor	x9, x9, x9, lsr #27
    6e38:      	mul	x8, x9, x8
    6e3c:      	eor	x0, x8, x8, lsr #31
    6e40:      	ret
    6e44:      	b.ne	0x6e94 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x250>
    6e48:      	mov	w11, #0x83              ; =131
    6e4c:      	mul	x10, x10, x11
    6e50:      	subs	x1, x1, #0x1
    6e54:      	b.ne	0x6e4c <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x208>
    6e58:      	b	0x6d54 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x110>
    6e5c:      	subs	x12, x12, x11
    6e60:      	b.ne	0x6ecc <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x288>
    6e64:      	mov	w13, #0x83              ; =131
    6e68:      	mov	x14, x11
    6e6c:      	mov	w15, #0x1               ; =1
    6e70:      	mul	x10, x10, x13
    6e74:      	mul	x15, x15, x13
    6e78:      	subs	x14, x14, #0x2
    6e7c:      	b.ne	0x6e70 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x22c>
    6e80:      	mul	x10, x15, x10
    6e84:      	add	x12, x12, #0x1
    6e88:      	cmp	x12, x1
    6e8c:      	b.ne	0x6e68 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x224>
    6e90:      	b	0x6d54 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x110>
    6e94:      	subs	x12, x12, x11
    6e98:      	b.ne	0x6f10 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x2cc>
    6e9c:      	mov	w13, #0x83              ; =131
    6ea0:      	mov	x14, x11
    6ea4:      	mov	w15, #0x1               ; =1
    6ea8:      	mul	x10, x10, x13
    6eac:      	mul	x15, x15, x13
    6eb0:      	subs	x14, x14, #0x2
    6eb4:      	b.ne	0x6ea8 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x264>
    6eb8:      	mul	x10, x15, x10
    6ebc:      	add	x12, x12, #0x1
    6ec0:      	cmp	x12, x1
    6ec4:      	b.ne	0x6ea0 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x25c>
    6ec8:      	b	0x6d54 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x110>
    6ecc:      	mov	x13, #0x0               ; =0
    6ed0:      	mov	w14, #0x83              ; =131
    6ed4:      	mov	x15, x11
    6ed8:      	mov	w16, #0x1               ; =1
    6edc:      	mul	x10, x10, x14
    6ee0:      	mul	x16, x16, x14
    6ee4:      	subs	x15, x15, #0x2
    6ee8:      	b.ne	0x6edc <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x298>
    6eec:      	mul	x10, x16, x10
    6ef0:      	mov	x15, x12
    6ef4:      	mul	x10, x10, x14
    6ef8:      	subs	x15, x15, #0x1
    6efc:      	b.ne	0x6ef4 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x2b0>
    6f00:      	add	x13, x13, #0x1
    6f04:      	cmp	x13, x1
    6f08:      	b.ne	0x6ed4 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x290>
    6f0c:      	b	0x6d54 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x110>
    6f10:      	mov	x13, #0x0               ; =0
    6f14:      	mov	w14, #0x83              ; =131
    6f18:      	mov	x15, x11
    6f1c:      	mov	w16, #0x1               ; =1
    6f20:      	mul	x10, x10, x14
    6f24:      	mul	x16, x16, x14
    6f28:      	subs	x15, x15, #0x2
    6f2c:      	b.ne	0x6f20 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x2dc>
    6f30:      	mul	x10, x16, x10
    6f34:      	mov	x15, x12
    6f38:      	mul	x10, x10, x14
    6f3c:      	subs	x15, x15, #0x1
    6f40:      	b.ne	0x6f38 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x2f4>
    6f44:      	add	x13, x13, #0x1
    6f48:      	cmp	x13, x1
    6f4c:      	b.ne	0x6f18 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x2d4>
    6f50:      	b	0x6d54 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x110>

0000000000006f54 <_wf_map_cost_lookup_geometry$instance$e194368921a477a7>:
    6f54:      	ldr	x8, [x0]
    6f58:      	ldr	x9, [x0, #0x18]
    6f5c:      	add	x0, x9, x8, lsl #32
    6f60:      	ret

0000000000006f64 <_wf_map_cost_lookup_geometry$instance$9fed7d4c5d7cc122>:
    6f64:      	ldr	x8, [x0]
    6f68:      	ldr	x9, [x0, #0x18]
    6f6c:      	add	x0, x9, x8, lsl #32
    6f70:      	ret

0000000000006f74 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd>:
    6f74:      	stp	x24, x23, [sp, #-0x40]!
    6f78:      	stp	x22, x21, [sp, #0x10]
    6f7c:      	stp	x20, x19, [sp, #0x20]
    6f80:      	stp	x29, x30, [sp, #0x30]
    6f84:      	mov	x8, x0
    6f88:      	mov	x20, #0xe5b9            ; =58809
    6f8c:      	movk	x20, #0x1ce4, lsl #16
    6f90:      	movk	x20, #0x476d, lsl #32
    6f94:      	movk	x20, #0xbf58, lsl #48
    6f98:      	mov	x19, #0x11eb            ; =4587
    6f9c:      	movk	x19, #0x1331, lsl #16
    6fa0:      	movk	x19, #0x49bb, lsl #32
    6fa4:      	movk	x19, #0x94d0, lsl #48
    6fa8:      	ldp	x12, x9, [x0]
    6fac:      	ldr	x0, [x0, #0x10]
    6fb0:      	cbz	x12, 0x7090 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x11c>
    6fb4:      	and	x10, x12, #0x3
    6fb8:      	cmp	x12, #0x4
    6fbc:      	b.hs	0x70a8 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x134>
    6fc0:      	mov	x11, #0x0               ; =0
    6fc4:      	mov	x21, #0x0               ; =0
    6fc8:      	mov	x22, #0x0               ; =0
    6fcc:      	cbz	x10, 0x7028 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0xb4>
    6fd0:      	mov	w13, #0x18              ; =24
    6fd4:      	madd	x12, x12, x13, x0
    6fd8:      	sub	x12, x12, #0x8
    6fdc:      	mov	w13, #0x83              ; =131
    6fe0:      	b	0x6ff0 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x7c>
    6fe4:      	sub	x12, x12, #0x18
    6fe8:      	subs	x10, x10, #0x1
    6fec:      	b.eq	0x7028 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0xb4>
    6ff0:      	ldur	w14, [x12, #-0x10]
    6ff4:      	cmp	w14, #0x2
    6ff8:      	b.ne	0x6fe4 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x70>
    6ffc:      	ldp	x15, x14, [x12, #-0x8]
    7000:      	madd	x14, x15, x13, x14
    7004:      	add	x22, x14, x22
    7008:      	eor	x14, x14, x14, lsr #30
    700c:      	mul	x14, x14, x20
    7010:      	eor	x14, x14, x14, lsr #27
    7014:      	mul	x14, x14, x19
    7018:      	eor	x15, x21, x14, lsr #31
    701c:      	eor	x21, x15, x14
    7020:      	add	x11, x11, #0x1
    7024:      	b	0x6fe4 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x70>
    7028:      	mov	x10, #0x7c15            ; =31765
    702c:      	movk	x10, #0x7f4a, lsl #16
    7030:      	movk	x10, #0x79b9, lsl #32
    7034:      	movk	x10, #0x9e37, lsl #48
    7038:      	mul	x23, x11, x10
    703c:      	ldr	x24, [x8, #0x38]
    7040:      	cbz	x9, 0x7048 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0xd4>
    7044:      	bl	0x7044 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0xd0>
		0000000000007044:  ARM64_RELOC_BRANCH26	_free
    7048:      	eor	x8, x24, x24, lsr #30
    704c:      	mul	x8, x8, x20
    7050:      	eor	x8, x8, x8, lsr #27
    7054:      	mul	x8, x8, x19
    7058:      	eor	x9, x22, x22, lsr #30
    705c:      	mul	x9, x9, x20
    7060:      	eor	x9, x9, x9, lsr #27
    7064:      	mul	x9, x9, x19
    7068:      	eor	x10, x9, x8
    706c:      	eor	x11, x23, x21
    7070:      	eor	x10, x11, x10, lsr #31
    7074:      	eor	x8, x8, x9
    7078:      	eor	x0, x10, x8
    707c:      	ldp	x29, x30, [sp, #0x30]
    7080:      	ldp	x20, x19, [sp, #0x20]
    7084:      	ldp	x22, x21, [sp, #0x10]
    7088:      	ldp	x24, x23, [sp], #0x40
    708c:      	ret
    7090:      	mov	x23, #0x0               ; =0
    7094:      	mov	x21, #0x0               ; =0
    7098:      	mov	x22, #0x0               ; =0
    709c:      	ldr	x24, [x8, #0x38]
    70a0:      	cbnz	x9, 0x7044 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0xd0>
    70a4:      	b	0x7048 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0xd4>
    70a8:      	mov	x11, #0x0               ; =0
    70ac:      	mov	x21, #0x0               ; =0
    70b0:      	mov	x22, #0x0               ; =0
    70b4:      	and	x13, x12, #0xfffffffffffffffc
    70b8:      	mov	w14, #0x18              ; =24
    70bc:      	madd	x14, x12, x14, x0
    70c0:      	sub	x14, x14, #0x30
    70c4:      	mov	w15, #0x83              ; =131
    70c8:      	b	0x70dc <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x168>
    70cc:      	sub	x14, x14, #0x60
    70d0:      	sub	x12, x12, #0x4
    70d4:      	sub	x13, x13, #0x4
    70d8:      	cbz	x13, 0x6fcc <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x58>
    70dc:      	ldr	w16, [x14, #0x18]
    70e0:      	cmp	w16, #0x2
    70e4:      	b.eq	0x7110 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x19c>
    70e8:      	ldr	w16, [x14]
    70ec:      	cmp	w16, #0x2
    70f0:      	b.eq	0x7144 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x1d0>
    70f4:      	ldur	w16, [x14, #-0x18]
    70f8:      	cmp	w16, #0x2
    70fc:      	b.eq	0x7178 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x204>
    7100:      	ldur	w16, [x14, #-0x30]
    7104:      	cmp	w16, #0x2
    7108:      	b.ne	0x70cc <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x158>
    710c:      	b	0x71ac <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x238>
    7110:      	ldp	x17, x16, [x14, #0x20]
    7114:      	madd	x16, x17, x15, x16
    7118:      	add	x22, x16, x22
    711c:      	eor	x16, x16, x16, lsr #30
    7120:      	mul	x16, x16, x20
    7124:      	eor	x16, x16, x16, lsr #27
    7128:      	mul	x16, x16, x19
    712c:      	eor	x17, x21, x16, lsr #31
    7130:      	eor	x21, x17, x16
    7134:      	add	x11, x11, #0x1
    7138:      	ldr	w16, [x14]
    713c:      	cmp	w16, #0x2
    7140:      	b.ne	0x70f4 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x180>
    7144:      	ldp	x17, x16, [x14, #0x8]
    7148:      	madd	x16, x17, x15, x16
    714c:      	add	x22, x16, x22
    7150:      	eor	x16, x16, x16, lsr #30
    7154:      	mul	x16, x16, x20
    7158:      	eor	x16, x16, x16, lsr #27
    715c:      	mul	x16, x16, x19
    7160:      	eor	x17, x21, x16, lsr #31
    7164:      	eor	x21, x17, x16
    7168:      	add	x11, x11, #0x1
    716c:      	ldur	w16, [x14, #-0x18]
    7170:      	cmp	w16, #0x2
    7174:      	b.ne	0x7100 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x18c>
    7178:      	ldp	x17, x16, [x14, #-0x10]
    717c:      	madd	x16, x17, x15, x16
    7180:      	add	x22, x16, x22
    7184:      	eor	x16, x16, x16, lsr #30
    7188:      	mul	x16, x16, x20
    718c:      	eor	x16, x16, x16, lsr #27
    7190:      	mul	x16, x16, x19
    7194:      	eor	x17, x21, x16, lsr #31
    7198:      	eor	x21, x17, x16
    719c:      	add	x11, x11, #0x1
    71a0:      	ldur	w16, [x14, #-0x30]
    71a4:      	cmp	w16, #0x2
    71a8:      	b.ne	0x70cc <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x158>
    71ac:      	ldp	x17, x16, [x14, #-0x28]
    71b0:      	madd	x16, x17, x15, x16
    71b4:      	add	x22, x16, x22
    71b8:      	eor	x16, x16, x16, lsr #30
    71bc:      	mul	x16, x16, x20
    71c0:      	eor	x16, x16, x16, lsr #27
    71c4:      	mul	x16, x16, x19
    71c8:      	eor	x17, x21, x16, lsr #31
    71cc:      	eor	x21, x17, x16
    71d0:      	add	x11, x11, #0x1
    71d4:      	b	0x70cc <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x158>

00000000000071d8 <_wf_map_cost_lookup_finish$instance$4250cb78d3f44027>:
    71d8:      	sub	sp, sp, #0x60
    71dc:      	stp	x29, x30, [sp, #0x50]
    71e0:      	ldr	x8, [x0, #0x38]
    71e4:      	ldp	q0, q1, [x0]
    71e8:      	stp	q0, q1, [sp, #0x20]
    71ec:      	ldr	x9, [x0, #0x20]
    71f0:      	str	x9, [sp, #0x40]
    71f4:      	stp	x8, xzr, [sp]
    71f8:      	stp	xzr, xzr, [sp, #0x10]
    71fc:      	add	x0, sp, #0x20
    7200:      	mov	x1, sp
    7204:      	bl	0x7204 <_wf_map_cost_lookup_finish$instance$4250cb78d3f44027+0x2c>
		0000000000007204:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71
    7208:      	ldp	x8, x9, [sp]
    720c:      	ldp	x10, x11, [sp, #0x10]
    7210:      	eor	x8, x8, x8, lsr #30
    7214:      	mov	x12, #0xe5b9            ; =58809
    7218:      	movk	x12, #0x1ce4, lsl #16
    721c:      	movk	x12, #0x476d, lsl #32
    7220:      	movk	x12, #0xbf58, lsl #48
    7224:      	mul	x8, x8, x12
    7228:      	eor	x8, x8, x8, lsr #27
    722c:      	mov	x13, #0x11eb            ; =4587
    7230:      	movk	x13, #0x1331, lsl #16
    7234:      	movk	x13, #0x49bb, lsl #32
    7238:      	movk	x13, #0x94d0, lsl #48
    723c:      	mul	x8, x8, x13
    7240:      	eor	x9, x9, x9, lsr #30
    7244:      	mul	x9, x9, x12
    7248:      	eor	x9, x9, x9, lsr #27
    724c:      	mul	x9, x9, x13
    7250:      	eor	x12, x9, x8
    7254:      	mov	x13, #0x7c15            ; =31765
    7258:      	movk	x13, #0x7f4a, lsl #16
    725c:      	movk	x13, #0x79b9, lsl #32
    7260:      	movk	x13, #0x9e37, lsl #48
    7264:      	mul	x11, x11, x13
    7268:      	eor	x10, x10, x11
    726c:      	eor	x10, x10, x12, lsr #31
    7270:      	eor	x8, x8, x9
    7274:      	eor	x0, x10, x8
    7278:      	ldp	x29, x30, [sp, #0x50]
    727c:      	add	sp, sp, #0x60
    7280:      	ret

0000000000007284 <_wf_box_slots_new$instance$e194368921a477a7>:
    7284:      	stp	x20, x19, [sp, #-0x20]!
    7288:      	stp	x29, x30, [sp, #0x10]
    728c:      	mov	x19, x0
    7290:      	cbz	x0, 0x72b8 <_wf_box_slots_new$instance$e194368921a477a7+0x34>
    7294:      	lsl	x0, x19, #3
    7298:      	bl	0x7298 <_wf_box_slots_new$instance$e194368921a477a7+0x14>
		0000000000007298:  ARM64_RELOC_BRANCH26	_malloc
    729c:      	mov	x2, x0
    72a0:      	cbz	x0, 0x72d4 <_wf_box_slots_new$instance$e194368921a477a7+0x50>
    72a4:      	mov	x0, #0x0                ; =0
    72a8:      	mov	x1, x19
    72ac:      	ldp	x29, x30, [sp, #0x10]
    72b0:      	ldp	x20, x19, [sp], #0x20
    72b4:      	ret
    72b8:      	adrp	x2, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x8c>
		00000000000072b8:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    72bc:      	add	x2, x2, #0x0
		00000000000072bc:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    72c0:      	mov	x0, #0x0                ; =0
    72c4:      	mov	x1, x19
    72c8:      	ldp	x29, x30, [sp, #0x10]
    72cc:      	ldp	x20, x19, [sp], #0x20
    72d0:      	ret
    72d4:      	bl	0x72d4 <_wf_box_slots_new$instance$e194368921a477a7+0x50>
		00000000000072d4:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

00000000000072d8 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd>:
    72d8:      	sub	sp, sp, #0x50
    72dc:      	stp	x24, x23, [sp, #0x10]
    72e0:      	stp	x22, x21, [sp, #0x20]
    72e4:      	stp	x20, x19, [sp, #0x30]
    72e8:      	stp	x29, x30, [sp, #0x40]
    72ec:      	mov	x19, x3
    72f0:      	mov	x21, x1
    72f4:      	mov	x20, x0
    72f8:      	cbz	x1, 0x73a0 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0xc8>
    72fc:      	mov	x23, x2
    7300:      	lsl	x24, x21, #3
    7304:      	mov	x0, x24
    7308:      	bl	0x7308 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x30>
		0000000000007308:  ARM64_RELOC_BRANCH26	_malloc
    730c:      	cbz	x0, 0x7490 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x1b8>
    7310:      	mov	x22, x0
    7314:      	mov	w1, #0xff               ; =255
    7318:      	mov	x2, x24
    731c:      	bl	0x731c <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x44>
		000000000000731c:  ARM64_RELOC_BRANCH26	_memset
    7320:      	add	x8, x21, x21, lsl #1
    7324:      	lsl	x0, x8, #3
    7328:      	bl	0x7328 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000007328:  ARM64_RELOC_BRANCH26	_malloc
    732c:      	cbz	x0, 0x7490 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x1b8>
    7330:      	mov	x8, #0x7c15             ; =31765
    7334:      	movk	x8, #0x7f4a, lsl #16
    7338:      	movk	x8, #0x79b9, lsl #32
    733c:      	movk	x8, #0x9e37, lsl #48
    7340:      	eor	x8, x19, x8
    7344:      	strb	wzr, [sp, #0x8]
    7348:      	cbz	x23, 0x73cc <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0xf4>
    734c:      	cbz	wzr, 0x7400 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x128>
    7350:      	mov	x13, #0x0               ; =0
    7354:      	mov	w10, #0x1               ; =1
    7358:      	mov	w11, #0x18              ; =24
    735c:      	mov	x12, x19
    7360:      	b	0x7378 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0xa0>
    7364:      	add	x12, x12, #0x1
    7368:      	add	x10, x10, #0x2
    736c:      	mov	x13, x9
    7370:      	subs	x23, x23, #0x1
    7374:      	b.eq	0x73d0 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0xf8>
    7378:      	mov	x9, x21
    737c:      	cmp	x13, x21
    7380:      	b.eq	0x7364 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x8c>
    7384:      	ldr	x9, [x22]
    7388:      	madd	x14, x13, x11, x0
    738c:      	stp	x10, x12, [x14]
    7390:      	str	x9, [x14, #0x10]
    7394:      	add	x9, x13, #0x1
    7398:      	str	x13, [x22]
    739c:      	b	0x7364 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x8c>
    73a0:      	mov	x9, #0x0                ; =0
    73a4:      	mov	x8, #0x7c15             ; =31765
    73a8:      	movk	x8, #0x7f4a, lsl #16
    73ac:      	movk	x8, #0x79b9, lsl #32
    73b0:      	movk	x8, #0x9e37, lsl #48
    73b4:      	eor	x8, x19, x8
    73b8:      	strb	wzr, [sp, #0x8]
    73bc:      	adrp	x0, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x8c>
		00000000000073bc:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    73c0:      	add	x0, x0, #0x0
		00000000000073c0:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    73c4:      	mov	x22, x0
    73c8:      	b	0x73d0 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0xf8>
    73cc:      	mov	x9, #0x0                ; =0
    73d0:      	stp	x21, x21, [x20]
    73d4:      	stp	x22, x9, [x20, #0x10]
    73d8:      	stp	x21, x0, [x20, #0x20]
    73dc:      	stp	x8, xzr, [x20, #0x30]
    73e0:      	strb	wzr, [x20, #0x38]
    73e4:      	str	x19, [x20, #0x40]
    73e8:      	ldp	x29, x30, [sp, #0x40]
    73ec:      	ldp	x20, x19, [sp, #0x30]
    73f0:      	ldp	x22, x21, [sp, #0x20]
    73f4:      	ldp	x24, x23, [sp, #0x10]
    73f8:      	add	sp, sp, #0x50
    73fc:      	ret
    7400:      	mov	x15, #0x0               ; =0
    7404:      	mov	w10, #0x1               ; =1
    7408:      	mov	x11, #0xe5b9            ; =58809
    740c:      	movk	x11, #0x1ce4, lsl #16
    7410:      	movk	x11, #0x476d, lsl #32
    7414:      	movk	x11, #0xbf58, lsl #48
    7418:      	mov	x12, #0x11eb            ; =4587
    741c:      	movk	x12, #0x1331, lsl #16
    7420:      	movk	x12, #0x49bb, lsl #32
    7424:      	movk	x12, #0x94d0, lsl #48
    7428:      	mov	w13, #0x18              ; =24
    742c:      	mov	x14, x19
    7430:      	b	0x7448 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x170>
    7434:      	add	x14, x14, #0x1
    7438:      	add	x10, x10, #0x2
    743c:      	mov	x15, x9
    7440:      	subs	x23, x23, #0x1
    7444:      	b.eq	0x73d0 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0xf8>
    7448:      	mov	x9, x21
    744c:      	cmp	x15, x21
    7450:      	b.eq	0x7434 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x15c>
    7454:      	eor	x9, x10, x8
    7458:      	eor	x9, x9, x9, lsr #30
    745c:      	mul	x9, x9, x11
    7460:      	eor	x9, x9, x9, lsr #27
    7464:      	mul	x9, x9, x12
    7468:      	eor	x9, x9, x9, lsr #31
    746c:      	udiv	x16, x9, x21
    7470:      	msub	x16, x16, x21, x9
    7474:      	ldr	x9, [x22, x16, lsl #3]
    7478:      	madd	x17, x15, x13, x0
    747c:      	stp	x10, x14, [x17]
    7480:      	str	x9, [x17, #0x10]
    7484:      	add	x9, x15, #0x1
    7488:      	str	x15, [x22, x16, lsl #3]
    748c:      	b	0x7434 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x15c>
    7490:      	bl	0x7490 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x1b8>
		0000000000007490:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

0000000000007494 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd>:
    7494:      	mov	x9, #0xe5b9             ; =58809
    7498:      	movk	x9, #0x1ce4, lsl #16
    749c:      	movk	x9, #0x476d, lsl #32
    74a0:      	movk	x9, #0xbf58, lsl #48
    74a4:      	mov	x8, #0x11eb             ; =4587
    74a8:      	movk	x8, #0x1331, lsl #16
    74ac:      	movk	x8, #0x49bb, lsl #32
    74b0:      	movk	x8, #0x94d0, lsl #48
    74b4:      	ldr	x10, [x0, #0x40]
    74b8:      	cmp	x2, #0x0
    74bc:      	mov	w11, #0x1               ; =1
    74c0:      	cinc	x11, x11, ne
    74c4:      	cbz	x1, 0x7598 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x104>
    74c8:      	ldr	x12, [x0, #0x18]
    74cc:      	cbz	x12, 0x7598 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x104>
    74d0:      	ldrb	w15, [x0, #0x38]
    74d4:      	ldr	x14, [x0]
    74d8:      	cbz	x14, 0x7578 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0xe4>
    74dc:      	stp	x20, x19, [sp, #-0x10]!
    74e0:      	ldr	x13, [x0, #0x10]
    74e4:      	tbz	w15, #0x0, 0x75b0 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x11c>
    74e8:      	mov	x14, #0x0               ; =0
    74ec:      	mov	w15, #0x18              ; =24
    74f0:      	mov	w16, #0x4309            ; =17161
    74f4:      	mov	w17, #0x83              ; =131
    74f8:      	b	0x7508 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x74>
    74fc:      	add	x14, x14, #0x1
    7500:      	cmp	x14, x1
    7504:      	b.eq	0x7664 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x1d0>
    7508:      	mov	x2, #0x0                ; =0
    750c:      	b	0x7520 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x8c>
    7510:      	mul	x10, x10, x17
    7514:      	add	x2, x2, #0x1
    7518:      	cmp	x2, x12
    751c:      	b.eq	0x74fc <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x68>
    7520:      	add	x3, x11, x2, lsl #1
    7524:      	mov	x4, x12
    7528:      	mov	x5, x13
    752c:      	ldr	x5, [x5]
    7530:      	cmp	x5, x12
    7534:      	b.hs	0x7510 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x7c>
    7538:      	ldr	x6, [x0, #0x28]
    753c:      	madd	x5, x5, x15, x6
    7540:      	ldr	x6, [x5]
    7544:      	cmp	x6, x3
    7548:      	b.eq	0x755c <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0xc8>
    754c:      	add	x5, x5, #0x10
    7550:      	subs	x4, x4, #0x1
    7554:      	b.ne	0x752c <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x98>
    7558:      	b	0x7510 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x7c>
    755c:      	ldr	x3, [x5, #0x8]
    7560:      	madd	x10, x10, x16, x3
    7564:      	add	x10, x10, #0x83
    7568:      	add	x2, x2, #0x1
    756c:      	cmp	x2, x12
    7570:      	b.ne	0x7520 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x8c>
    7574:      	b	0x74fc <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x68>
    7578:      	and	x11, x12, #0xfffffffffffffffe
    757c:      	cmp	x12, #0x1
    7580:      	tbz	w15, #0x0, 0x7680 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x1ec>
    7584:      	b.ne	0x7698 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x204>
    7588:      	mov	w11, #0x83              ; =131
    758c:      	mul	x10, x10, x11
    7590:      	subs	x1, x1, #0x1
    7594:      	b.ne	0x758c <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0xf8>
    7598:      	eor	x10, x10, x10, lsr #30
    759c:      	mul	x9, x10, x9
    75a0:      	eor	x9, x9, x9, lsr #27
    75a4:      	mul	x8, x9, x8
    75a8:      	eor	x0, x8, x8, lsr #31
    75ac:      	ret
    75b0:      	mov	x15, #0x0               ; =0
    75b4:      	ldr	x16, [x0, #0x30]
    75b8:      	mov	w17, #0x18              ; =24
    75bc:      	mov	w2, #0x4309             ; =17161
    75c0:      	mov	w3, #0x83               ; =131
    75c4:      	b	0x75d4 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x140>
    75c8:      	add	x15, x15, #0x1
    75cc:      	cmp	x15, x1
    75d0:      	b.eq	0x7664 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x1d0>
    75d4:      	mov	x4, #0x0                ; =0
    75d8:      	b	0x75ec <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x158>
    75dc:      	mul	x10, x10, x3
    75e0:      	add	x4, x4, #0x1
    75e4:      	cmp	x4, x12
    75e8:      	b.eq	0x75c8 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x134>
    75ec:      	add	x5, x11, x4, lsl #1
    75f0:      	eor	x6, x16, x5
    75f4:      	eor	x6, x6, x6, lsr #30
    75f8:      	mul	x6, x6, x9
    75fc:      	eor	x6, x6, x6, lsr #27
    7600:      	mul	x6, x6, x8
    7604:      	eor	x6, x6, x6, lsr #31
    7608:      	udiv	x7, x6, x14
    760c:      	msub	x6, x7, x14, x6
    7610:      	add	x7, x13, x6, lsl #3
    7614:      	mov	x6, x12
    7618:      	ldr	x7, [x7]
    761c:      	cmp	x7, x12
    7620:      	b.hs	0x75dc <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x148>
    7624:      	ldr	x19, [x0, #0x28]
    7628:      	madd	x7, x7, x17, x19
    762c:      	ldr	x19, [x7]
    7630:      	cmp	x19, x5
    7634:      	b.eq	0x7648 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x1b4>
    7638:      	add	x7, x7, #0x10
    763c:      	subs	x6, x6, #0x1
    7640:      	b.ne	0x7618 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x184>
    7644:      	b	0x75dc <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x148>
    7648:      	ldr	x5, [x7, #0x8]
    764c:      	madd	x10, x10, x2, x5
    7650:      	add	x10, x10, #0x83
    7654:      	add	x4, x4, #0x1
    7658:      	cmp	x4, x12
    765c:      	b.ne	0x75ec <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x158>
    7660:      	b	0x75c8 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x134>
    7664:      	ldp	x20, x19, [sp], #0x10
    7668:      	eor	x10, x10, x10, lsr #30
    766c:      	mul	x9, x10, x9
    7670:      	eor	x9, x9, x9, lsr #27
    7674:      	mul	x8, x9, x8
    7678:      	eor	x0, x8, x8, lsr #31
    767c:      	ret
    7680:      	b.ne	0x76d0 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x23c>
    7684:      	mov	w11, #0x83              ; =131
    7688:      	mul	x10, x10, x11
    768c:      	subs	x1, x1, #0x1
    7690:      	b.ne	0x7688 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x1f4>
    7694:      	b	0x7598 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x104>
    7698:      	subs	x12, x12, x11
    769c:      	b.ne	0x7708 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x274>
    76a0:      	mov	w13, #0x83              ; =131
    76a4:      	mov	x14, x11
    76a8:      	mov	w15, #0x1               ; =1
    76ac:      	mul	x10, x10, x13
    76b0:      	mul	x15, x15, x13
    76b4:      	subs	x14, x14, #0x2
    76b8:      	b.ne	0x76ac <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x218>
    76bc:      	mul	x10, x15, x10
    76c0:      	add	x12, x12, #0x1
    76c4:      	cmp	x12, x1
    76c8:      	b.ne	0x76a4 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x210>
    76cc:      	b	0x7598 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x104>
    76d0:      	subs	x12, x12, x11
    76d4:      	b.ne	0x774c <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x2b8>
    76d8:      	mov	w13, #0x83              ; =131
    76dc:      	mov	x14, x11
    76e0:      	mov	w15, #0x1               ; =1
    76e4:      	mul	x10, x10, x13
    76e8:      	mul	x15, x15, x13
    76ec:      	subs	x14, x14, #0x2
    76f0:      	b.ne	0x76e4 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x250>
    76f4:      	mul	x10, x15, x10
    76f8:      	add	x12, x12, #0x1
    76fc:      	cmp	x12, x1
    7700:      	b.ne	0x76dc <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x248>
    7704:      	b	0x7598 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x104>
    7708:      	mov	x13, #0x0               ; =0
    770c:      	mov	w14, #0x83              ; =131
    7710:      	mov	x15, x11
    7714:      	mov	w16, #0x1               ; =1
    7718:      	mul	x10, x10, x14
    771c:      	mul	x16, x16, x14
    7720:      	subs	x15, x15, #0x2
    7724:      	b.ne	0x7718 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x284>
    7728:      	mul	x10, x16, x10
    772c:      	mov	x15, x12
    7730:      	mul	x10, x10, x14
    7734:      	subs	x15, x15, #0x1
    7738:      	b.ne	0x7730 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x29c>
    773c:      	add	x13, x13, #0x1
    7740:      	cmp	x13, x1
    7744:      	b.ne	0x7710 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x27c>
    7748:      	b	0x7598 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x104>
    774c:      	mov	x13, #0x0               ; =0
    7750:      	mov	w14, #0x83              ; =131
    7754:      	mov	x15, x11
    7758:      	mov	w16, #0x1               ; =1
    775c:      	mul	x10, x10, x14
    7760:      	mul	x16, x16, x14
    7764:      	subs	x15, x15, #0x2
    7768:      	b.ne	0x775c <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x2c8>
    776c:      	mul	x10, x16, x10
    7770:      	mov	x15, x12
    7774:      	mul	x10, x10, x14
    7778:      	subs	x15, x15, #0x1
    777c:      	b.ne	0x7774 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x2e0>
    7780:      	add	x13, x13, #0x1
    7784:      	cmp	x13, x1
    7788:      	b.ne	0x7754 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x2c0>
    778c:      	b	0x7598 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x104>

0000000000007790 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd>:
    7790:      	stp	x28, x27, [sp, #-0x60]!
    7794:      	stp	x26, x25, [sp, #0x10]
    7798:      	stp	x24, x23, [sp, #0x20]
    779c:      	stp	x22, x21, [sp, #0x30]
    77a0:      	stp	x20, x19, [sp, #0x40]
    77a4:      	stp	x29, x30, [sp, #0x50]
    77a8:      	mov	x8, x0
    77ac:      	mov	x21, #0xe5b9            ; =58809
    77b0:      	movk	x21, #0x1ce4, lsl #16
    77b4:      	movk	x21, #0x476d, lsl #32
    77b8:      	movk	x21, #0xbf58, lsl #48
    77bc:      	mov	x20, #0x11eb            ; =4587
    77c0:      	movk	x20, #0x1331, lsl #16
    77c4:      	movk	x20, #0x49bb, lsl #32
    77c8:      	movk	x20, #0x94d0, lsl #48
    77cc:      	ldp	x10, x9, [x0, #0x18]
    77d0:      	ldr	x0, [x0, #0x28]
    77d4:      	cbz	x10, 0x77f0 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0x60>
    77d8:      	cmp	x10, #0x4
    77dc:      	b.hs	0x780c <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0x7c>
    77e0:      	mov	x23, #0x0               ; =0
    77e4:      	mov	x22, #0x0               ; =0
    77e8:      	mov	x11, x10
    77ec:      	b	0x7904 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0x174>
    77f0:      	mov	x24, #0x0               ; =0
    77f4:      	mov	x22, #0x0               ; =0
    77f8:      	mov	x23, #0x0               ; =0
    77fc:      	ldp	x26, x19, [x8, #0x8]
    7800:      	ldr	x25, [x8, #0x40]
    7804:      	cbnz	x9, 0x7960 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0x1d0>
    7808:      	b	0x7964 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0x1d4>
    780c:      	mov	x13, #0x0               ; =0
    7810:      	mov	x14, #0x0               ; =0
    7814:      	mov	x15, #0x0               ; =0
    7818:      	mov	x16, #0x0               ; =0
    781c:      	mov	x17, #0x0               ; =0
    7820:      	mov	x1, #0x0                ; =0
    7824:      	mov	x2, #0x0                ; =0
    7828:      	mov	x3, #0x0                ; =0
    782c:      	and	x12, x10, #0xfffffffffffffffc
    7830:      	and	x11, x10, #0x3
    7834:      	mov	w4, #0x18               ; =24
    7838:      	madd	x4, x10, x4, x0
    783c:      	sub	x4, x4, #0x30
    7840:      	mov	w5, #0x83               ; =131
    7844:      	mov	x6, x12
    7848:      	ldp	x7, x19, [x4, #0x18]
    784c:      	ldp	x22, x23, [x4]
    7850:      	ldp	x24, x25, [x4, #-0x18]
    7854:      	ldp	x26, x27, [x4, #-0x30]
    7858:      	madd	x7, x7, x5, x19
    785c:      	madd	x19, x22, x5, x23
    7860:      	madd	x22, x24, x5, x25
    7864:      	madd	x23, x26, x5, x27
    7868:      	add	x13, x7, x13
    786c:      	add	x14, x19, x14
    7870:      	add	x15, x22, x15
    7874:      	add	x16, x23, x16
    7878:      	eor	x7, x7, x7, lsr #30
    787c:      	eor	x19, x19, x19, lsr #30
    7880:      	eor	x22, x22, x22, lsr #30
    7884:      	eor	x23, x23, x23, lsr #30
    7888:      	mul	x7, x7, x21
    788c:      	mul	x19, x19, x21
    7890:      	mul	x22, x22, x21
    7894:      	mul	x23, x23, x21
    7898:      	eor	x7, x7, x7, lsr #27
    789c:      	eor	x19, x19, x19, lsr #27
    78a0:      	eor	x22, x22, x22, lsr #27
    78a4:      	eor	x23, x23, x23, lsr #27
    78a8:      	mul	x7, x7, x20
    78ac:      	mul	x19, x19, x20
    78b0:      	mul	x22, x22, x20
    78b4:      	eor	x17, x17, x7, lsr #31
    78b8:      	mul	x23, x23, x20
    78bc:      	eor	x1, x1, x19, lsr #31
    78c0:      	eor	x2, x2, x22, lsr #31
    78c4:      	eor	x3, x3, x23, lsr #31
    78c8:      	eor	x17, x17, x7
    78cc:      	eor	x1, x1, x19
    78d0:      	eor	x2, x2, x22
    78d4:      	eor	x3, x3, x23
    78d8:      	sub	x4, x4, #0x60
    78dc:      	sub	x6, x6, #0x4
    78e0:      	cbnz	x6, 0x7848 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0xb8>
    78e4:      	add	x13, x14, x13
    78e8:      	add	x14, x16, x15
    78ec:      	add	x23, x14, x13
    78f0:      	eor	x13, x1, x17
    78f4:      	eor	x14, x3, x2
    78f8:      	eor	x22, x14, x13
    78fc:      	cmp	x10, x12
    7900:      	b.eq	0x7940 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0x1b0>
    7904:      	mov	w12, #0x18              ; =24
    7908:      	madd	x12, x11, x12, x0
    790c:      	sub	x12, x12, #0x18
    7910:      	mov	w13, #0x83              ; =131
    7914:      	ldp	x14, x15, [x12], #-0x18
    7918:      	madd	x14, x14, x13, x15
    791c:      	add	x23, x14, x23
    7920:      	eor	x14, x14, x14, lsr #30
    7924:      	mul	x14, x14, x21
    7928:      	eor	x14, x14, x14, lsr #27
    792c:      	mul	x14, x14, x20
    7930:      	eor	x15, x22, x14, lsr #31
    7934:      	eor	x22, x15, x14
    7938:      	sub	x11, x11, #0x1
    793c:      	cbnz	x11, 0x7914 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0x184>
    7940:      	mov	x11, #0x7c15            ; =31765
    7944:      	movk	x11, #0x7f4a, lsl #16
    7948:      	movk	x11, #0x79b9, lsl #32
    794c:      	movk	x11, #0x9e37, lsl #48
    7950:      	mul	x24, x10, x11
    7954:      	ldp	x26, x19, [x8, #0x8]
    7958:      	ldr	x25, [x8, #0x40]
    795c:      	cbz	x9, 0x7964 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0x1d4>
    7960:      	bl	0x7960 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0x1d0>
		0000000000007960:  ARM64_RELOC_BRANCH26	_free
    7964:      	cbz	x26, 0x7970 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0x1e0>
    7968:      	mov	x0, x19
    796c:      	bl	0x796c <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0x1dc>
		000000000000796c:  ARM64_RELOC_BRANCH26	_free
    7970:      	eor	x8, x23, x23, lsr #30
    7974:      	mul	x8, x8, x21
    7978:      	eor	x8, x8, x8, lsr #27
    797c:      	mul	x8, x8, x20
    7980:      	eor	x9, x25, x25, lsr #30
    7984:      	mul	x9, x9, x21
    7988:      	eor	x9, x9, x9, lsr #27
    798c:      	mul	x9, x9, x20
    7990:      	eor	x10, x8, x9
    7994:      	eor	x11, x24, x22
    7998:      	eor	x10, x11, x10, lsr #31
    799c:      	eor	x8, x9, x8
    79a0:      	eor	x0, x10, x8
    79a4:      	ldp	x29, x30, [sp, #0x50]
    79a8:      	ldp	x20, x19, [sp, #0x40]
    79ac:      	ldp	x22, x21, [sp, #0x30]
    79b0:      	ldp	x24, x23, [sp, #0x20]
    79b4:      	ldp	x26, x25, [sp, #0x10]
    79b8:      	ldp	x28, x27, [sp], #0x60
    79bc:      	ret

00000000000079c0 <_wf_chain_lookup_geometry$instance$e194368921a477a7>:
    79c0:      	ldr	x8, [x0]
    79c4:      	ldr	x9, [x0, #0x18]
    79c8:      	add	x0, x9, x8, lsl #32
    79cc:      	ret

00000000000079d0 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027>:
    79d0:      	sub	sp, sp, #0x50
    79d4:      	stp	x24, x23, [sp, #0x10]
    79d8:      	stp	x22, x21, [sp, #0x20]
    79dc:      	stp	x20, x19, [sp, #0x30]
    79e0:      	stp	x29, x30, [sp, #0x40]
    79e4:      	mov	x19, x3
    79e8:      	mov	x23, x2
    79ec:      	mov	x21, x1
    79f0:      	mov	x20, x0
    79f4:      	cbz	x1, 0x7a2c <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x5c>
    79f8:      	lsl	x24, x21, #3
    79fc:      	mov	x0, x24
    7a00:      	bl	0x7a00 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x30>
		0000000000007a00:  ARM64_RELOC_BRANCH26	_malloc
    7a04:      	cbz	x0, 0x7a28 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x58>
    7a08:      	mov	x22, x0
    7a0c:      	mov	w1, #0xff               ; =255
    7a10:      	mov	x2, x24
    7a14:      	bl	0x7a14 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x44>
		0000000000007a14:  ARM64_RELOC_BRANCH26	_memset
    7a18:      	add	x8, x21, x21, lsl #4
    7a1c:      	lsl	x0, x8, #4
    7a20:      	bl	0x7a20 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x50>
		0000000000007a20:  ARM64_RELOC_BRANCH26	_malloc
    7a24:      	cbnz	x0, 0x7a38 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x68>
    7a28:      	bl	0x7a28 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x58>
		0000000000007a28:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
    7a2c:      	adrp	x22, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x8c>
		0000000000007a2c:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    7a30:      	add	x22, x22, #0x0
		0000000000007a30:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    7a34:      	mov	x0, x22
    7a38:      	mov	x8, #0x7c15             ; =31765
    7a3c:      	movk	x8, #0x7f4a, lsl #16
    7a40:      	movk	x8, #0x79b9, lsl #32
    7a44:      	movk	x8, #0x9e37, lsl #48
    7a48:      	eor	x8, x19, x8
    7a4c:      	strb	wzr, [sp, #0x8]
    7a50:      	mov	x9, #0x0                ; =0
    7a54:      	cbz	x23, 0x7bcc <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x1fc>
    7a58:      	adrp	x10, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x8c>
		0000000000007a58:  ARM64_RELOC_PAGE21	lCPI84_0
    7a5c:      	ldr	q0, [x10]
		0000000000007a5c:  ARM64_RELOC_PAGEOFF12	lCPI84_0
    7a60:      	adrp	x10, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x8c>
		0000000000007a60:  ARM64_RELOC_PAGE21	lCPI84_1
    7a64:      	ldr	q1, [x10]
		0000000000007a64:  ARM64_RELOC_PAGEOFF12	lCPI84_1
    7a68:      	mov	w10, #0x1               ; =1
    7a6c:      	adrp	x11, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x8c>
		0000000000007a6c:  ARM64_RELOC_PAGE21	lCPI84_2
    7a70:      	ldr	q2, [x11]
		0000000000007a70:  ARM64_RELOC_PAGEOFF12	lCPI84_2
    7a74:      	adrp	x11, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x8c>
		0000000000007a74:  ARM64_RELOC_PAGE21	lCPI84_3
    7a78:      	ldr	q3, [x11]
		0000000000007a78:  ARM64_RELOC_PAGEOFF12	lCPI84_3
    7a7c:      	adrp	x11, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x8c>
		0000000000007a7c:  ARM64_RELOC_PAGE21	lCPI84_4
    7a80:      	ldr	q4, [x11]
		0000000000007a80:  ARM64_RELOC_PAGEOFF12	lCPI84_4
    7a84:      	adrp	x11, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x8c>
		0000000000007a84:  ARM64_RELOC_PAGE21	lCPI84_5
    7a88:      	ldr	q5, [x11]
		0000000000007a88:  ARM64_RELOC_PAGEOFF12	lCPI84_5
    7a8c:      	adrp	x11, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x8c>
		0000000000007a8c:  ARM64_RELOC_PAGE21	lCPI84_6
    7a90:      	ldr	q6, [x11]
		0000000000007a90:  ARM64_RELOC_PAGEOFF12	lCPI84_6
    7a94:      	adrp	x11, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x8c>
		0000000000007a94:  ARM64_RELOC_PAGE21	lCPI84_7
    7a98:      	ldr	q7, [x11]
		0000000000007a98:  ARM64_RELOC_PAGEOFF12	lCPI84_7
    7a9c:      	adrp	x11, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x8c>
		0000000000007a9c:  ARM64_RELOC_PAGE21	lCPI84_8
    7aa0:      	ldr	q16, [x11]
		0000000000007aa0:  ARM64_RELOC_PAGEOFF12	lCPI84_8
    7aa4:      	adrp	x11, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x8c>
		0000000000007aa4:  ARM64_RELOC_PAGE21	lCPI84_9
    7aa8:      	ldr	q17, [x11]
		0000000000007aa8:  ARM64_RELOC_PAGEOFF12	lCPI84_9
    7aac:      	adrp	x11, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x8c>
		0000000000007aac:  ARM64_RELOC_PAGE21	lCPI84_10
    7ab0:      	ldr	q18, [x11]
		0000000000007ab0:  ARM64_RELOC_PAGEOFF12	lCPI84_10
    7ab4:      	adrp	x11, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x8c>
		0000000000007ab4:  ARM64_RELOC_PAGE21	lCPI84_11
    7ab8:      	ldr	q19, [x11]
		0000000000007ab8:  ARM64_RELOC_PAGEOFF12	lCPI84_11
    7abc:      	mov	w11, #0x110             ; =272
    7ac0:      	adrp	x12, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x8c>
		0000000000007ac0:  ARM64_RELOC_PAGE21	lCPI84_12
    7ac4:      	ldr	q20, [x12]
		0000000000007ac4:  ARM64_RELOC_PAGEOFF12	lCPI84_12
    7ac8:      	mov	x12, #0xe5b9            ; =58809
    7acc:      	movk	x12, #0x1ce4, lsl #16
    7ad0:      	movk	x12, #0x476d, lsl #32
    7ad4:      	movk	x12, #0xbf58, lsl #48
    7ad8:      	adrp	x13, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x8c>
		0000000000007ad8:  ARM64_RELOC_PAGE21	lCPI84_13
    7adc:      	ldr	q21, [x13]
		0000000000007adc:  ARM64_RELOC_PAGEOFF12	lCPI84_13
    7ae0:      	mov	x13, #0x11eb            ; =4587
    7ae4:      	movk	x13, #0x1331, lsl #16
    7ae8:      	movk	x13, #0x49bb, lsl #32
    7aec:      	movk	x13, #0x94d0, lsl #48
    7af0:      	adrp	x14, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x8c>
		0000000000007af0:  ARM64_RELOC_PAGE21	lCPI84_14
    7af4:      	ldr	q22, [x14]
		0000000000007af4:  ARM64_RELOC_PAGEOFF12	lCPI84_14
    7af8:      	mov	x14, x19
    7afc:      	b	0x7b10 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x140>
    7b00:      	add	x14, x14, #0x1
    7b04:      	add	x10, x10, #0x2
    7b08:      	subs	x23, x23, #0x1
    7b0c:      	b.eq	0x7bcc <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x1fc>
    7b10:      	cbz	wzr, 0x7b20 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x150>
    7b14:      	mov	x15, #0x0               ; =0
    7b18:      	cbnz	x21, 0x7b3c <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x16c>
    7b1c:      	b	0x7b00 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x130>
    7b20:      	eor	x15, x10, x8
    7b24:      	eor	x15, x15, x15, lsr #30
    7b28:      	mul	x15, x15, x12
    7b2c:      	eor	x15, x15, x15, lsr #27
    7b30:      	mul	x15, x15, x13
    7b34:      	eor	x15, x15, x15, lsr #31
    7b38:      	cbz	x21, 0x7b00 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x130>
    7b3c:      	cmp	x9, x21
    7b40:      	b.eq	0x7b00 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x130>
    7b44:      	dup.2d	v23, x14
    7b48:      	udiv	x16, x15, x21
    7b4c:      	msub	x15, x16, x21, x15
    7b50:      	ldr	x16, [x22, x15, lsl #3]
    7b54:      	madd	x17, x9, x11, x0
    7b58:      	stp	x10, x14, [x17]
    7b5c:      	add.2d	v24, v23, v0
    7b60:      	add.2d	v25, v23, v1
    7b64:      	stp	q24, q25, [x17, #0x10]
    7b68:      	add.2d	v24, v23, v2
    7b6c:      	add.2d	v25, v23, v3
    7b70:      	stp	q24, q25, [x17, #0x30]
    7b74:      	add.2d	v24, v23, v4
    7b78:      	add.2d	v25, v23, v5
    7b7c:      	stp	q24, q25, [x17, #0x50]
    7b80:      	add.2d	v24, v23, v6
    7b84:      	add.2d	v25, v23, v7
    7b88:      	stp	q24, q25, [x17, #0x70]
    7b8c:      	add.2d	v24, v23, v16
    7b90:      	add.2d	v25, v23, v17
    7b94:      	stp	q24, q25, [x17, #0x90]
    7b98:      	add.2d	v24, v23, v18
    7b9c:      	add.2d	v25, v23, v19
    7ba0:      	add.2d	v26, v23, v20
    7ba4:      	add.2d	v27, v23, v21
    7ba8:      	stp	q24, q25, [x17, #0xb0]
    7bac:      	add.2d	v23, v23, v22
    7bb0:      	stp	q26, q27, [x17, #0xd0]
    7bb4:      	add	x1, x14, #0x1f
    7bb8:      	str	q23, [x17, #0xf0]
    7bbc:      	stp	x1, x16, [x17, #0x100]
    7bc0:      	str	x9, [x22, x15, lsl #3]
    7bc4:      	add	x9, x9, #0x1
    7bc8:      	b	0x7b00 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x130>
    7bcc:      	stp	x21, x21, [x20]
    7bd0:      	stp	x22, x9, [x20, #0x10]
    7bd4:      	stp	x21, x0, [x20, #0x20]
    7bd8:      	stp	x8, xzr, [x20, #0x30]
    7bdc:      	strb	wzr, [x20, #0x38]
    7be0:      	str	x19, [x20, #0x40]
    7be4:      	ldp	x29, x30, [sp, #0x40]
    7be8:      	ldp	x20, x19, [sp, #0x30]
    7bec:      	ldp	x22, x21, [sp, #0x20]
    7bf0:      	ldp	x24, x23, [sp, #0x10]
    7bf4:      	add	sp, sp, #0x50
    7bf8:      	ret

0000000000007bfc <_wf_chain_lookup_query$instance$4250cb78d3f44027>:
    7bfc:      	mov	x9, #0xe5b9             ; =58809
    7c00:      	movk	x9, #0x1ce4, lsl #16
    7c04:      	movk	x9, #0x476d, lsl #32
    7c08:      	movk	x9, #0xbf58, lsl #48
    7c0c:      	mov	x8, #0x11eb             ; =4587
    7c10:      	movk	x8, #0x1331, lsl #16
    7c14:      	movk	x8, #0x49bb, lsl #32
    7c18:      	movk	x8, #0x94d0, lsl #48
    7c1c:      	ldr	x10, [x0, #0x40]
    7c20:      	cmp	x2, #0x0
    7c24:      	mov	w11, #0x1               ; =1
    7c28:      	cinc	x11, x11, ne
    7c2c:      	cbz	x1, 0x7d00 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x104>
    7c30:      	ldr	x12, [x0, #0x18]
    7c34:      	cbz	x12, 0x7d00 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x104>
    7c38:      	ldrb	w15, [x0, #0x38]
    7c3c:      	ldr	x14, [x0]
    7c40:      	cbz	x14, 0x7ce0 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0xe4>
    7c44:      	stp	x20, x19, [sp, #-0x10]!
    7c48:      	ldr	x13, [x0, #0x10]
    7c4c:      	tbz	w15, #0x0, 0x7d18 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x11c>
    7c50:      	mov	x14, #0x0               ; =0
    7c54:      	mov	w15, #0x110             ; =272
    7c58:      	mov	w16, #0x4309            ; =17161
    7c5c:      	mov	w17, #0x83              ; =131
    7c60:      	b	0x7c70 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x74>
    7c64:      	add	x14, x14, #0x1
    7c68:      	cmp	x14, x1
    7c6c:      	b.eq	0x7dcc <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x1d0>
    7c70:      	mov	x2, #0x0                ; =0
    7c74:      	b	0x7c88 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x8c>
    7c78:      	mul	x10, x10, x17
    7c7c:      	add	x2, x2, #0x1
    7c80:      	cmp	x2, x12
    7c84:      	b.eq	0x7c64 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x68>
    7c88:      	add	x3, x11, x2, lsl #1
    7c8c:      	mov	x4, x12
    7c90:      	mov	x5, x13
    7c94:      	ldr	x5, [x5]
    7c98:      	cmp	x5, x12
    7c9c:      	b.hs	0x7c78 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x7c>
    7ca0:      	ldr	x6, [x0, #0x28]
    7ca4:      	madd	x5, x5, x15, x6
    7ca8:      	ldr	x6, [x5]
    7cac:      	cmp	x6, x3
    7cb0:      	b.eq	0x7cc4 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0xc8>
    7cb4:      	add	x5, x5, #0x108
    7cb8:      	subs	x4, x4, #0x1
    7cbc:      	b.ne	0x7c94 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x98>
    7cc0:      	b	0x7c78 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x7c>
    7cc4:      	ldr	x3, [x5, #0x8]
    7cc8:      	madd	x10, x10, x16, x3
    7ccc:      	add	x10, x10, #0x83
    7cd0:      	add	x2, x2, #0x1
    7cd4:      	cmp	x2, x12
    7cd8:      	b.ne	0x7c88 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x8c>
    7cdc:      	b	0x7c64 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x68>
    7ce0:      	and	x11, x12, #0xfffffffffffffffe
    7ce4:      	cmp	x12, #0x1
    7ce8:      	tbz	w15, #0x0, 0x7de8 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x1ec>
    7cec:      	b.ne	0x7e00 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x204>
    7cf0:      	mov	w11, #0x83              ; =131
    7cf4:      	mul	x10, x10, x11
    7cf8:      	subs	x1, x1, #0x1
    7cfc:      	b.ne	0x7cf4 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0xf8>
    7d00:      	eor	x10, x10, x10, lsr #30
    7d04:      	mul	x9, x10, x9
    7d08:      	eor	x9, x9, x9, lsr #27
    7d0c:      	mul	x8, x9, x8
    7d10:      	eor	x0, x8, x8, lsr #31
    7d14:      	ret
    7d18:      	mov	x15, #0x0               ; =0
    7d1c:      	ldr	x16, [x0, #0x30]
    7d20:      	mov	w17, #0x110             ; =272
    7d24:      	mov	w2, #0x4309             ; =17161
    7d28:      	mov	w3, #0x83               ; =131
    7d2c:      	b	0x7d3c <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x140>
    7d30:      	add	x15, x15, #0x1
    7d34:      	cmp	x15, x1
    7d38:      	b.eq	0x7dcc <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x1d0>
    7d3c:      	mov	x4, #0x0                ; =0
    7d40:      	b	0x7d54 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x158>
    7d44:      	mul	x10, x10, x3
    7d48:      	add	x4, x4, #0x1
    7d4c:      	cmp	x4, x12
    7d50:      	b.eq	0x7d30 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x134>
    7d54:      	add	x5, x11, x4, lsl #1
    7d58:      	eor	x6, x16, x5
    7d5c:      	eor	x6, x6, x6, lsr #30
    7d60:      	mul	x6, x6, x9
    7d64:      	eor	x6, x6, x6, lsr #27
    7d68:      	mul	x6, x6, x8
    7d6c:      	eor	x6, x6, x6, lsr #31
    7d70:      	udiv	x7, x6, x14
    7d74:      	msub	x6, x7, x14, x6
    7d78:      	add	x7, x13, x6, lsl #3
    7d7c:      	mov	x6, x12
    7d80:      	ldr	x7, [x7]
    7d84:      	cmp	x7, x12
    7d88:      	b.hs	0x7d44 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x148>
    7d8c:      	ldr	x19, [x0, #0x28]
    7d90:      	madd	x7, x7, x17, x19
    7d94:      	ldr	x19, [x7]
    7d98:      	cmp	x19, x5
    7d9c:      	b.eq	0x7db0 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x1b4>
    7da0:      	add	x7, x7, #0x108
    7da4:      	subs	x6, x6, #0x1
    7da8:      	b.ne	0x7d80 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x184>
    7dac:      	b	0x7d44 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x148>
    7db0:      	ldr	x5, [x7, #0x8]
    7db4:      	madd	x10, x10, x2, x5
    7db8:      	add	x10, x10, #0x83
    7dbc:      	add	x4, x4, #0x1
    7dc0:      	cmp	x4, x12
    7dc4:      	b.ne	0x7d54 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x158>
    7dc8:      	b	0x7d30 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x134>
    7dcc:      	ldp	x20, x19, [sp], #0x10
    7dd0:      	eor	x10, x10, x10, lsr #30
    7dd4:      	mul	x9, x10, x9
    7dd8:      	eor	x9, x9, x9, lsr #27
    7ddc:      	mul	x8, x9, x8
    7de0:      	eor	x0, x8, x8, lsr #31
    7de4:      	ret
    7de8:      	b.ne	0x7e38 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x23c>
    7dec:      	mov	w11, #0x83              ; =131
    7df0:      	mul	x10, x10, x11
    7df4:      	subs	x1, x1, #0x1
    7df8:      	b.ne	0x7df0 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x1f4>
    7dfc:      	b	0x7d00 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x104>
    7e00:      	subs	x12, x12, x11
    7e04:      	b.ne	0x7e70 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x274>
    7e08:      	mov	w13, #0x83              ; =131
    7e0c:      	mov	x14, x11
    7e10:      	mov	w15, #0x1               ; =1
    7e14:      	mul	x10, x10, x13
    7e18:      	mul	x15, x15, x13
    7e1c:      	subs	x14, x14, #0x2
    7e20:      	b.ne	0x7e14 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x218>
    7e24:      	mul	x10, x15, x10
    7e28:      	add	x12, x12, #0x1
    7e2c:      	cmp	x12, x1
    7e30:      	b.ne	0x7e0c <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x210>
    7e34:      	b	0x7d00 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x104>
    7e38:      	subs	x12, x12, x11
    7e3c:      	b.ne	0x7eb4 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x2b8>
    7e40:      	mov	w13, #0x83              ; =131
    7e44:      	mov	x14, x11
    7e48:      	mov	w15, #0x1               ; =1
    7e4c:      	mul	x10, x10, x13
    7e50:      	mul	x15, x15, x13
    7e54:      	subs	x14, x14, #0x2
    7e58:      	b.ne	0x7e4c <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x250>
    7e5c:      	mul	x10, x15, x10
    7e60:      	add	x12, x12, #0x1
    7e64:      	cmp	x12, x1
    7e68:      	b.ne	0x7e44 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x248>
    7e6c:      	b	0x7d00 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x104>
    7e70:      	mov	x13, #0x0               ; =0
    7e74:      	mov	w14, #0x83              ; =131
    7e78:      	mov	x15, x11
    7e7c:      	mov	w16, #0x1               ; =1
    7e80:      	mul	x10, x10, x14
    7e84:      	mul	x16, x16, x14
    7e88:      	subs	x15, x15, #0x2
    7e8c:      	b.ne	0x7e80 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x284>
    7e90:      	mul	x10, x16, x10
    7e94:      	mov	x15, x12
    7e98:      	mul	x10, x10, x14
    7e9c:      	subs	x15, x15, #0x1
    7ea0:      	b.ne	0x7e98 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x29c>
    7ea4:      	add	x13, x13, #0x1
    7ea8:      	cmp	x13, x1
    7eac:      	b.ne	0x7e78 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x27c>
    7eb0:      	b	0x7d00 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x104>
    7eb4:      	mov	x13, #0x0               ; =0
    7eb8:      	mov	w14, #0x83              ; =131
    7ebc:      	mov	x15, x11
    7ec0:      	mov	w16, #0x1               ; =1
    7ec4:      	mul	x10, x10, x14
    7ec8:      	mul	x16, x16, x14
    7ecc:      	subs	x15, x15, #0x2
    7ed0:      	b.ne	0x7ec4 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x2c8>
    7ed4:      	mul	x10, x16, x10
    7ed8:      	mov	x15, x12
    7edc:      	mul	x10, x10, x14
    7ee0:      	subs	x15, x15, #0x1
    7ee4:      	b.ne	0x7edc <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x2e0>
    7ee8:      	add	x13, x13, #0x1
    7eec:      	cmp	x13, x1
    7ef0:      	b.ne	0x7ebc <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x2c0>
    7ef4:      	b	0x7d00 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x104>

0000000000007ef8 <_wf_chain_lookup_finish$instance$4250cb78d3f44027>:
    7ef8:      	stp	x26, x25, [sp, #-0x50]!
    7efc:      	stp	x24, x23, [sp, #0x10]
    7f00:      	stp	x22, x21, [sp, #0x20]
    7f04:      	stp	x20, x19, [sp, #0x30]
    7f08:      	stp	x29, x30, [sp, #0x40]
    7f0c:      	mov	x8, x0
    7f10:      	mov	x21, #0xe5b9            ; =58809
    7f14:      	movk	x21, #0x1ce4, lsl #16
    7f18:      	movk	x21, #0x476d, lsl #32
    7f1c:      	movk	x21, #0xbf58, lsl #48
    7f20:      	mov	x20, #0x11eb            ; =4587
    7f24:      	movk	x20, #0x1331, lsl #16
    7f28:      	movk	x20, #0x49bb, lsl #32
    7f2c:      	movk	x20, #0x94d0, lsl #48
    7f30:      	ldp	x10, x9, [x0, #0x18]
    7f34:      	ldr	x0, [x0, #0x28]
    7f38:      	cbz	x10, 0x80c0 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x1c8>
    7f3c:      	mov	x23, #0x0               ; =0
    7f40:      	mov	x22, #0x0               ; =0
    7f44:      	mov	w11, #0x110             ; =272
    7f48:      	madd	x11, x10, x11, x0
    7f4c:      	sub	x11, x11, #0x88
    7f50:      	mov	w12, #0x83              ; =131
    7f54:      	mov	x13, x10
    7f58:      	ldp	x14, x15, [x11, #-0x88]
    7f5c:      	madd	x14, x14, x12, x15
    7f60:      	ldp	x15, x16, [x11, #-0x78]
    7f64:      	madd	x14, x14, x12, x15
    7f68:      	madd	x14, x14, x12, x16
    7f6c:      	ldp	x15, x16, [x11, #-0x68]
    7f70:      	madd	x14, x14, x12, x15
    7f74:      	madd	x14, x14, x12, x16
    7f78:      	ldp	x15, x16, [x11, #-0x58]
    7f7c:      	madd	x14, x14, x12, x15
    7f80:      	madd	x14, x14, x12, x16
    7f84:      	ldp	x15, x16, [x11, #-0x48]
    7f88:      	madd	x14, x14, x12, x15
    7f8c:      	madd	x14, x14, x12, x16
    7f90:      	ldp	x15, x16, [x11, #-0x38]
    7f94:      	madd	x14, x14, x12, x15
    7f98:      	madd	x14, x14, x12, x16
    7f9c:      	ldp	x15, x16, [x11, #-0x28]
    7fa0:      	madd	x14, x14, x12, x15
    7fa4:      	madd	x14, x14, x12, x16
    7fa8:      	ldp	x15, x16, [x11, #-0x18]
    7fac:      	madd	x14, x14, x12, x15
    7fb0:      	madd	x14, x14, x12, x16
    7fb4:      	ldp	x15, x16, [x11, #-0x8]
    7fb8:      	madd	x14, x14, x12, x15
    7fbc:      	madd	x14, x14, x12, x16
    7fc0:      	ldp	x15, x16, [x11, #0x8]
    7fc4:      	madd	x14, x14, x12, x15
    7fc8:      	madd	x14, x14, x12, x16
    7fcc:      	ldp	x15, x16, [x11, #0x18]
    7fd0:      	madd	x14, x14, x12, x15
    7fd4:      	madd	x14, x14, x12, x16
    7fd8:      	ldp	x15, x16, [x11, #0x28]
    7fdc:      	madd	x14, x14, x12, x15
    7fe0:      	madd	x14, x14, x12, x16
    7fe4:      	ldp	x15, x16, [x11, #0x38]
    7fe8:      	madd	x14, x14, x12, x15
    7fec:      	madd	x14, x14, x12, x16
    7ff0:      	ldp	x15, x16, [x11, #0x48]
    7ff4:      	madd	x14, x14, x12, x15
    7ff8:      	madd	x14, x14, x12, x16
    7ffc:      	ldp	x15, x16, [x11, #0x58]
    8000:      	madd	x14, x14, x12, x15
    8004:      	madd	x14, x14, x12, x16
    8008:      	ldp	x15, x16, [x11, #0x68]
    800c:      	madd	x14, x14, x12, x15
    8010:      	madd	x14, x14, x12, x16
    8014:      	ldr	x15, [x11, #0x78]
    8018:      	madd	x14, x14, x12, x15
    801c:      	add	x23, x14, x23
    8020:      	eor	x14, x14, x14, lsr #30
    8024:      	mul	x14, x14, x21
    8028:      	eor	x14, x14, x14, lsr #27
    802c:      	mul	x14, x14, x20
    8030:      	eor	x15, x22, x14, lsr #31
    8034:      	eor	x22, x15, x14
    8038:      	sub	x11, x11, #0x110
    803c:      	sub	x13, x13, #0x1
    8040:      	cbnz	x13, 0x7f58 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x60>
    8044:      	mov	x11, #0x7c15            ; =31765
    8048:      	movk	x11, #0x7f4a, lsl #16
    804c:      	movk	x11, #0x79b9, lsl #32
    8050:      	movk	x11, #0x9e37, lsl #48
    8054:      	mul	x24, x10, x11
    8058:      	ldp	x26, x19, [x8, #0x8]
    805c:      	ldr	x25, [x8, #0x40]
    8060:      	cbz	x9, 0x8068 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x170>
    8064:      	bl	0x8064 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x16c>
		0000000000008064:  ARM64_RELOC_BRANCH26	_free
    8068:      	cbz	x26, 0x8074 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x17c>
    806c:      	mov	x0, x19
    8070:      	bl	0x8070 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x178>
		0000000000008070:  ARM64_RELOC_BRANCH26	_free
    8074:      	eor	x8, x23, x23, lsr #30
    8078:      	mul	x8, x8, x21
    807c:      	eor	x8, x8, x8, lsr #27
    8080:      	mul	x8, x8, x20
    8084:      	eor	x9, x25, x25, lsr #30
    8088:      	mul	x9, x9, x21
    808c:      	eor	x9, x9, x9, lsr #27
    8090:      	mul	x9, x9, x20
    8094:      	eor	x10, x8, x9
    8098:      	eor	x11, x24, x22
    809c:      	eor	x10, x11, x10, lsr #31
    80a0:      	eor	x8, x9, x8
    80a4:      	eor	x0, x10, x8
    80a8:      	ldp	x29, x30, [sp, #0x40]
    80ac:      	ldp	x20, x19, [sp, #0x30]
    80b0:      	ldp	x22, x21, [sp, #0x20]
    80b4:      	ldp	x24, x23, [sp, #0x10]
    80b8:      	ldp	x26, x25, [sp], #0x50
    80bc:      	ret
    80c0:      	mov	x24, #0x0               ; =0
    80c4:      	mov	x22, #0x0               ; =0
    80c8:      	mov	x23, #0x0               ; =0
    80cc:      	ldp	x26, x19, [x8, #0x8]
    80d0:      	ldr	x25, [x8, #0x40]
    80d4:      	cbnz	x9, 0x8064 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x16c>
    80d8:      	b	0x8068 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x170>

00000000000080dc <_wf_chain_lookup_geometry$instance$9fed7d4c5d7cc122>:
    80dc:      	ldr	x8, [x0]
    80e0:      	ldr	x9, [x0, #0x18]
    80e4:      	add	x0, x9, x8, lsl #32
    80e8:      	ret

00000000000080ec <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd>:
    80ec:      	sub	sp, sp, #0x50
    80f0:      	stp	x24, x23, [sp, #0x10]
    80f4:      	stp	x22, x21, [sp, #0x20]
    80f8:      	stp	x20, x19, [sp, #0x30]
    80fc:      	stp	x29, x30, [sp, #0x40]
    8100:      	mov	x20, x3
    8104:      	mov	x19, x2
    8108:      	mov	x22, x1
    810c:      	mov	x21, x0
    8110:      	mov	x8, #0x7c15             ; =31765
    8114:      	movk	x8, #0x7f4a, lsl #16
    8118:      	movk	x8, #0x79b9, lsl #32
    811c:      	movk	x8, #0x9e37, lsl #48
    8120:      	eor	x23, x3, x8
    8124:      	strb	wzr, [sp, #0x8]
    8128:      	cbz	x1, 0x825c <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x170>
    812c:      	add	x8, x22, x22, lsl #1
    8130:      	lsl	x0, x8, #3
    8134:      	bl	0x8134 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x48>
		0000000000008134:  ARM64_RELOC_BRANCH26	_malloc
    8138:      	cbz	x0, 0x82a8 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x1bc>
    813c:      	mov	x8, #0x0                ; =0
    8140:      	add	x9, x0, #0x8
    8144:      	stur	wzr, [x9, #-0x8]
    8148:      	add	x8, x8, #0x1
    814c:      	stp	xzr, xzr, [x9], #0x18
    8150:      	cmp	x22, x8
    8154:      	b.ne	0x8144 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x58>
    8158:      	ldrb	w8, [sp, #0x8]
    815c:      	cbz	x19, 0x8270 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x184>
    8160:      	mov	x10, #0x0               ; =0
    8164:      	mov	x9, #0x0                ; =0
    8168:      	mov	w11, #0x1               ; =1
    816c:      	mov	w12, #0x18              ; =24
    8170:      	mov	w13, #0x2               ; =2
    8174:      	mov	x14, #0xe5b9            ; =58809
    8178:      	movk	x14, #0x1ce4, lsl #16
    817c:      	movk	x14, #0x476d, lsl #32
    8180:      	movk	x14, #0xbf58, lsl #48
    8184:      	mov	x15, #0x11eb            ; =4587
    8188:      	movk	x15, #0x1331, lsl #16
    818c:      	movk	x15, #0x49bb, lsl #32
    8190:      	movk	x15, #0x94d0, lsl #48
    8194:      	b	0x81ac <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0xc0>
    8198:      	str	w13, [x4]
    819c:      	str	x17, [x4, #0x10]
    81a0:      	add	x10, x10, #0x1
    81a4:      	cmp	x10, x19
    81a8:      	b.eq	0x8274 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x188>
    81ac:      	orr	x16, x11, x10, lsl #1
    81b0:      	tbz	w8, #0x0, 0x81bc <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0xd0>
    81b4:      	mov	x1, #0x0                ; =0
    81b8:      	b	0x81d4 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0xe8>
    81bc:      	eor	x17, x16, x23
    81c0:      	eor	x17, x17, x17, lsr #30
    81c4:      	mul	x17, x17, x14
    81c8:      	eor	x17, x17, x17, lsr #27
    81cc:      	mul	x17, x17, x15
    81d0:      	eor	x1, x17, x17, lsr #31
    81d4:      	add	x17, x10, x20
    81d8:      	udiv	x2, x1, x22
    81dc:      	msub	x2, x2, x22, x1
    81e0:      	mov	x3, x22
    81e4:      	mov	x1, x22
    81e8:      	b	0x8208 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x11c>
    81ec:      	cmp	x1, x22
    81f0:      	csel	x1, x2, x1, eq
    81f4:      	add	x4, x2, #0x1
    81f8:      	cmp	x4, x22
    81fc:      	csinc	x2, xzr, x2, hs
    8200:      	subs	x3, x3, #0x1
    8204:      	b.eq	0x8238 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x14c>
    8208:      	madd	x4, x2, x12, x0
    820c:      	ldr	w5, [x4]
    8210:      	cmp	w5, #0x1
    8214:      	b.eq	0x81ec <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x100>
    8218:      	cmp	w5, #0x2
    821c:      	b.ne	0x8230 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x144>
    8220:      	ldr	x5, [x4, #0x8]
    8224:      	cmp	x5, x16
    8228:      	b.ne	0x81f4 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x108>
    822c:      	b	0x8198 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0xac>
    8230:      	cmp	x1, x22
    8234:      	csel	x1, x2, x1, eq
    8238:      	cmp	x1, x22
    823c:      	b.hs	0x81a0 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0xb4>
    8240:      	cmp	x9, #0x2, lsl #12       ; =0x2000
    8244:      	b.hs	0x81a0 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0xb4>
    8248:      	madd	x1, x1, x12, x0
    824c:      	str	w13, [x1]
    8250:      	add	x9, x9, #0x1
    8254:      	stp	x16, x17, [x1, #0x8]
    8258:      	b	0x81a0 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0xb4>
    825c:      	mov	x9, #0x0                ; =0
    8260:      	adrp	x0, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008260:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    8264:      	add	x0, x0, #0x0
		0000000000008264:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    8268:      	ldrb	w8, [sp, #0x8]
    826c:      	b	0x8274 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x188>
    8270:      	mov	x9, #0x0                ; =0
    8274:      	stp	x23, xzr, [x21, #0x28]
    8278:      	stp	x22, x22, [x21]
    827c:      	stp	x0, x9, [x21, #0x10]
    8280:      	str	xzr, [x21, #0x20]
    8284:      	strb	w8, [x21, #0x30]
    8288:      	stp	x20, x19, [x21, #0x38]
    828c:      	str	xzr, [x21, #0x48]
    8290:      	ldp	x29, x30, [sp, #0x40]
    8294:      	ldp	x20, x19, [sp, #0x30]
    8298:      	ldp	x22, x21, [sp, #0x20]
    829c:      	ldp	x24, x23, [sp, #0x10]
    82a0:      	add	sp, sp, #0x50
    82a4:      	ret
    82a8:      	bl	0x82a8 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x1bc>
		00000000000082a8:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

00000000000082ac <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd>:
    82ac:      	mov	x9, #0xe5b9             ; =58809
    82b0:      	movk	x9, #0x1ce4, lsl #16
    82b4:      	movk	x9, #0x476d, lsl #32
    82b8:      	movk	x9, #0xbf58, lsl #48
    82bc:      	mov	x8, #0x11eb             ; =4587
    82c0:      	movk	x8, #0x1331, lsl #16
    82c4:      	movk	x8, #0x49bb, lsl #32
    82c8:      	movk	x8, #0x94d0, lsl #48
    82cc:      	ldr	x10, [x0, #0x38]
    82d0:      	cbz	x1, 0x85a8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2fc>
    82d4:      	ldp	x12, x11, [x0, #0x40]
    82d8:      	cbz	x12, 0x85a0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2f4>
    82dc:      	sub	sp, sp, #0x70
    82e0:      	stp	x28, x27, [sp, #0x10]
    82e4:      	stp	x26, x25, [sp, #0x20]
    82e8:      	stp	x24, x23, [sp, #0x30]
    82ec:      	stp	x22, x21, [sp, #0x40]
    82f0:      	stp	x20, x19, [sp, #0x50]
    82f4:      	stp	x29, x30, [sp, #0x60]
    82f8:      	mov	x13, #0x0               ; =0
    82fc:      	ldp	x19, x14, [x0, #0x20]
    8300:      	ldrb	w15, [x0, #0x30]
    8304:      	mov	w16, #0x1               ; =1
    8308:      	mov	w17, #0x18              ; =24
    830c:      	mov	w3, #0x2                ; =2
    8310:      	mov	w4, #0x83               ; =131
    8314:      	mov	x6, x10
    8318:      	ldr	x7, [x0, #0x18]
    831c:      	b	0x8330 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x84>
    8320:      	str	x11, [x0, #0x48]
    8324:      	add	x13, x13, #0x1
    8328:      	cmp	x13, x1
    832c:      	b.eq	0x856c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2c0>
    8330:      	mov	x20, #0x0               ; =0
    8334:      	add	x11, x11, #0x1
    8338:      	madd	x21, x11, x12, x10
    833c:      	b	0x8364 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xb8>
    8340:      	strb	w16, [sp, #0xc]
    8344:      	tst	w16, #0x1
    8348:      	cinc	x24, x16, ne
    834c:      	madd	x5, x6, x4, x22
    8350:      	add	x5, x5, x24
    8354:      	madd	x6, x5, x4, x23
    8358:      	add	x20, x20, #0x1
    835c:      	cmp	x20, x12
    8360:      	b.eq	0x8320 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x74>
    8364:      	orr	x22, x16, x20, lsl #1
    8368:      	cbz	x2, 0x8420 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x174>
    836c:      	cbz	x7, 0x84a8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
    8370:      	tbz	w15, #0x0, 0x8384 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xd8>
    8374:      	mov	x24, #0x0               ; =0
    8378:      	ldr	x23, [x0]
    837c:      	cbnz	x23, 0x83a4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xf8>
    8380:      	b	0x84a8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
    8384:      	eor	x5, x14, x22
    8388:      	eor	x5, x5, x5, lsr #30
    838c:      	mul	x5, x5, x9
    8390:      	eor	x5, x5, x5, lsr #27
    8394:      	mul	x5, x5, x8
    8398:      	eor	x24, x5, x5, lsr #31
    839c:      	ldr	x23, [x0]
    83a0:      	cbz	x23, 0x84a8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
    83a4:      	udiv	x5, x24, x23
    83a8:      	msub	x24, x5, x23, x24
    83ac:      	ldr	x25, [x0, #0x10]
    83b0:      	mov	x26, x23
    83b4:      	b	0x83cc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x120>
    83b8:      	add	x5, x24, #0x1
    83bc:      	cmp	x5, x23
    83c0:      	csinc	x24, xzr, x24, hs
    83c4:      	subs	x26, x26, #0x1
    83c8:      	b.eq	0x84a8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
    83cc:      	madd	x27, x24, x17, x25
    83d0:      	ldr	w28, [x27]
    83d4:      	cmp	w28, #0x1
    83d8:      	b.eq	0x83b8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x10c>
    83dc:      	cmp	w28, #0x2
    83e0:      	b.ne	0x84a8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
    83e4:      	ldr	x5, [x27, #0x8]
    83e8:      	cmp	x5, x22
    83ec:      	b.ne	0x83b8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x10c>
    83f0:      	ldr	x5, [x27, #0x10]
    83f4:      	str	w16, [x27]
    83f8:      	sub	x7, x7, #0x1
    83fc:      	stp	xzr, xzr, [x27, #0x8]
    8400:      	adds	x19, x19, #0x1
    8404:      	csinv	x19, x19, xzr, lo
    8408:      	stp	x7, x19, [x0, #0x18]
    840c:      	mul	x23, x22, x4
    8410:      	mov	w24, #0x4309            ; =17161
    8414:      	madd	x6, x6, x24, x23
    8418:      	add	x5, x6, x5
    841c:      	add	x6, x5, #0x83
    8420:      	tbz	w15, #0x0, 0x84b0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x204>
    8424:      	mov	x25, #0x0               ; =0
    8428:      	add	x23, x21, x20
    842c:      	ldr	x24, [x0]
    8430:      	cbz	x24, 0x84d4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x228>
    8434:      	udiv	x5, x25, x24
    8438:      	msub	x26, x5, x24, x25
    843c:      	ldr	x27, [x0, #0x10]
    8440:      	mov	x28, x24
    8444:      	mov	x25, x24
    8448:      	b	0x8468 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1bc>
    844c:      	cmp	x25, x24
    8450:      	csel	x25, x26, x25, eq
    8454:      	add	x5, x26, #0x1
    8458:      	cmp	x5, x24
    845c:      	csinc	x26, xzr, x26, hs
    8460:      	subs	x28, x28, #0x1
    8464:      	b.eq	0x84d8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x22c>
    8468:      	madd	x30, x26, x17, x27
    846c:      	ldr	w5, [x30]
    8470:      	cmp	w5, #0x1
    8474:      	b.eq	0x844c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1a0>
    8478:      	cmp	w5, #0x2
    847c:      	b.ne	0x8558 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2ac>
    8480:      	ldr	x5, [x30, #0x8]
    8484:      	cmp	x5, x22
    8488:      	b.ne	0x8454 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1a8>
    848c:      	ldr	x5, [x30, #0x10]
    8490:      	str	w3, [x30]
    8494:      	str	x23, [x30, #0x10]
    8498:      	strb	wzr, [sp, #0xc]
    849c:      	mov	w24, #0x1               ; =1
    84a0:      	mov	x23, x5
    84a4:      	b	0x834c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xa0>
    84a8:      	mul	x6, x6, x4
    84ac:      	tbnz	w15, #0x0, 0x8424 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x178>
    84b0:      	eor	x5, x14, x22
    84b4:      	eor	x5, x5, x5, lsr #30
    84b8:      	mul	x5, x5, x9
    84bc:      	eor	x5, x5, x5, lsr #27
    84c0:      	mul	x5, x5, x8
    84c4:      	eor	x25, x5, x5, lsr #31
    84c8:      	add	x23, x21, x20
    84cc:      	ldr	x24, [x0]
    84d0:      	cbnz	x24, 0x8434 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x188>
    84d4:      	mov	x25, #0x0               ; =0
    84d8:      	cmp	x25, x24
    84dc:      	b.hs	0x8340 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
    84e0:      	cmp	x7, #0x2, lsl #12       ; =0x2000
    84e4:      	b.hs	0x8340 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
    84e8:      	add	x7, x7, #0x1
    84ec:      	str	x7, [x0, #0x18]
    84f0:      	ldr	x5, [x0, #0x10]
    84f4:      	madd	x24, x25, x17, x5
    84f8:      	ldr	w27, [x24]
    84fc:      	cmp	w27, #0x1
    8500:      	b.ne	0x851c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x270>
    8504:      	subs	x5, x19, #0x1
    8508:      	csel	x19, xzr, x5, lo
    850c:      	str	x19, [x0, #0x20]
    8510:      	str	w3, [x24]
    8514:      	stp	x22, x23, [x24, #0x8]
    8518:      	b	0x8540 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x294>
    851c:      	ldp	x25, x26, [x24, #0x8]
    8520:      	str	w3, [x24]
    8524:      	stp	x22, x23, [x24, #0x8]
    8528:      	cbz	w27, 0x8540 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x294>
    852c:      	strb	wzr, [sp, #0xc]
    8530:      	mov	w24, #0x1               ; =1
    8534:      	mov	x23, x26
    8538:      	mov	x22, x25
    853c:      	b	0x834c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xa0>
    8540:      	strb	wzr, [sp, #0xc]
    8544:      	mul	x6, x6, x4
    8548:      	add	x20, x20, #0x1
    854c:      	cmp	x20, x12
    8550:      	b.ne	0x8364 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xb8>
    8554:      	b	0x8320 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x74>
    8558:      	cmp	x25, x24
    855c:      	csel	x25, x26, x25, eq
    8560:      	cmp	x25, x24
    8564:      	b.lo	0x84e0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x234>
    8568:      	b	0x8340 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
    856c:      	ldp	x29, x30, [sp, #0x60]
    8570:      	ldp	x20, x19, [sp, #0x50]
    8574:      	ldp	x22, x21, [sp, #0x40]
    8578:      	ldp	x24, x23, [sp, #0x30]
    857c:      	ldp	x26, x25, [sp, #0x20]
    8580:      	ldp	x28, x27, [sp, #0x10]
    8584:      	add	sp, sp, #0x70
    8588:      	eor	x10, x6, x6, lsr #30
    858c:      	mul	x9, x10, x9
    8590:      	eor	x9, x9, x9, lsr #27
    8594:      	mul	x8, x9, x8
    8598:      	eor	x0, x8, x8, lsr #31
    859c:      	ret
    85a0:      	add	x11, x11, x1
    85a4:      	str	x11, [x0, #0x48]
    85a8:      	eor	x10, x10, x10, lsr #30
    85ac:      	mul	x9, x10, x9
    85b0:      	eor	x9, x9, x9, lsr #27
    85b4:      	mul	x8, x9, x8
    85b8:      	eor	x0, x8, x8, lsr #31
    85bc:      	ret

00000000000085c0 <_wf_flat_mutation_geometry$instance$e194368921a477a7>:
    85c0:      	ldr	x8, [x0]
    85c4:      	ldr	x9, [x0, #0x18]
    85c8:      	add	x0, x9, x8, lsl #32
    85cc:      	ret

00000000000085d0 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd>:
    85d0:      	mov	x9, #0xe5b9             ; =58809
    85d4:      	movk	x9, #0x1ce4, lsl #16
    85d8:      	movk	x9, #0x476d, lsl #32
    85dc:      	movk	x9, #0xbf58, lsl #48
    85e0:      	mov	x8, #0x11eb             ; =4587
    85e4:      	movk	x8, #0x1331, lsl #16
    85e8:      	movk	x8, #0x49bb, lsl #32
    85ec:      	movk	x8, #0x94d0, lsl #48
    85f0:      	ldp	x1, x10, [x0, #0x38]
    85f4:      	cbz	x10, 0x875c <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x18c>
    85f8:      	mov	x11, #0x0               ; =0
    85fc:      	ldr	x12, [x0, #0x28]
    8600:      	ldrb	w13, [x0, #0x30]
    8604:      	mov	w14, #0x83              ; =131
    8608:      	mov	w15, #0x18              ; =24
    860c:      	mov	w16, #0x4309            ; =17161
    8610:      	ldr	x17, [x0]
    8614:      	b	0x8628 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x58>
    8618:      	mul	x1, x1, x14
    861c:      	add	x11, x11, #0x1
    8620:      	cmp	x11, x10
    8624:      	b.eq	0x875c <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x18c>
    8628:      	mov	w2, #0x1                ; =1
    862c:      	bfi	x2, x11, #1, #63
    8630:      	tbz	w13, #0x0, 0x8640 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x70>
    8634:      	mov	x3, #0x0                ; =0
    8638:      	cbnz	x17, 0x865c <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x8c>
    863c:      	b	0x86e0 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x110>
    8640:      	eor	x3, x12, x2
    8644:      	eor	x3, x3, x3, lsr #30
    8648:      	mul	x3, x3, x9
    864c:      	eor	x3, x3, x3, lsr #27
    8650:      	mul	x3, x3, x8
    8654:      	eor	x3, x3, x3, lsr #31
    8658:      	cbz	x17, 0x86e0 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x110>
    865c:      	udiv	x4, x3, x17
    8660:      	msub	x3, x4, x17, x3
    8664:      	ldr	x4, [x0, #0x10]
    8668:      	mov	x5, x17
    866c:      	b	0x8684 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0xb4>
    8670:      	add	x6, x3, #0x1
    8674:      	cmp	x6, x17
    8678:      	csinc	x3, xzr, x3, hs
    867c:      	subs	x5, x5, #0x1
    8680:      	b.eq	0x86e0 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x110>
    8684:      	madd	x6, x3, x15, x4
    8688:      	ldr	w7, [x6]
    868c:      	cmp	w7, #0x1
    8690:      	b.eq	0x8670 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0xa0>
    8694:      	cmp	w7, #0x2
    8698:      	b.ne	0x86e0 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x110>
    869c:      	ldr	x7, [x6, #0x8]
    86a0:      	cmp	x7, x2
    86a4:      	b.ne	0x8670 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0xa0>
    86a8:      	ldr	x2, [x6, #0x10]
    86ac:      	madd	x1, x1, x16, x2
    86b0:      	add	x1, x1, #0x83
    86b4:      	lsl	x2, x11, #1
    86b8:      	add	x2, x2, #0x2
    86bc:      	tbnz	w13, #0x0, 0x86f0 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x120>
    86c0:      	eor	x3, x12, x2
    86c4:      	eor	x3, x3, x3, lsr #30
    86c8:      	mul	x3, x3, x9
    86cc:      	eor	x3, x3, x3, lsr #27
    86d0:      	mul	x3, x3, x8
    86d4:      	eor	x3, x3, x3, lsr #31
    86d8:      	cbnz	x17, 0x86f8 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x128>
    86dc:      	b	0x8618 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x48>
    86e0:      	mul	x1, x1, x14
    86e4:      	lsl	x2, x11, #1
    86e8:      	add	x2, x2, #0x2
    86ec:      	tbz	w13, #0x0, 0x86c0 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0xf0>
    86f0:      	mov	x3, #0x0                ; =0
    86f4:      	cbz	x17, 0x8618 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x48>
    86f8:      	udiv	x4, x3, x17
    86fc:      	msub	x3, x4, x17, x3
    8700:      	ldr	x4, [x0, #0x10]
    8704:      	mov	x5, x17
    8708:      	b	0x8720 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x150>
    870c:      	add	x6, x3, #0x1
    8710:      	cmp	x6, x17
    8714:      	csinc	x3, xzr, x3, hs
    8718:      	subs	x5, x5, #0x1
    871c:      	b.eq	0x8618 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x48>
    8720:      	madd	x6, x3, x15, x4
    8724:      	ldr	w7, [x6]
    8728:      	cmp	w7, #0x1
    872c:      	b.eq	0x870c <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x13c>
    8730:      	cmp	w7, #0x2
    8734:      	b.ne	0x8618 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x48>
    8738:      	ldr	x7, [x6, #0x8]
    873c:      	cmp	x7, x2
    8740:      	b.ne	0x870c <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x13c>
    8744:      	ldr	x2, [x6, #0x10]
    8748:      	madd	x1, x1, x16, x2
    874c:      	add	x1, x1, #0x83
    8750:      	add	x11, x11, #0x1
    8754:      	cmp	x11, x10
    8758:      	b.ne	0x8628 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x58>
    875c:      	eor	x10, x1, x1, lsr #30
    8760:      	mul	x9, x10, x9
    8764:      	eor	x9, x9, x9, lsr #27
    8768:      	mul	x8, x9, x8
    876c:      	eor	x0, x8, x8, lsr #31
    8770:      	ret

0000000000008774 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd>:
    8774:      	stp	x24, x23, [sp, #-0x40]!
    8778:      	stp	x22, x21, [sp, #0x10]
    877c:      	stp	x20, x19, [sp, #0x20]
    8780:      	stp	x29, x30, [sp, #0x30]
    8784:      	mov	x8, x0
    8788:      	mov	x20, #0xe5b9            ; =58809
    878c:      	movk	x20, #0x1ce4, lsl #16
    8790:      	movk	x20, #0x476d, lsl #32
    8794:      	movk	x20, #0xbf58, lsl #48
    8798:      	mov	x19, #0x11eb            ; =4587
    879c:      	movk	x19, #0x1331, lsl #16
    87a0:      	movk	x19, #0x49bb, lsl #32
    87a4:      	movk	x19, #0x94d0, lsl #48
    87a8:      	ldp	x12, x9, [x0]
    87ac:      	ldr	x0, [x0, #0x10]
    87b0:      	cbz	x12, 0x8890 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x11c>
    87b4:      	and	x10, x12, #0x3
    87b8:      	cmp	x12, #0x4
    87bc:      	b.hs	0x88a8 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x134>
    87c0:      	mov	x11, #0x0               ; =0
    87c4:      	mov	x21, #0x0               ; =0
    87c8:      	mov	x22, #0x0               ; =0
    87cc:      	cbz	x10, 0x8828 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0xb4>
    87d0:      	mov	w13, #0x18              ; =24
    87d4:      	madd	x12, x12, x13, x0
    87d8:      	sub	x12, x12, #0x8
    87dc:      	mov	w13, #0x83              ; =131
    87e0:      	b	0x87f0 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x7c>
    87e4:      	sub	x12, x12, #0x18
    87e8:      	subs	x10, x10, #0x1
    87ec:      	b.eq	0x8828 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0xb4>
    87f0:      	ldur	w14, [x12, #-0x10]
    87f4:      	cmp	w14, #0x2
    87f8:      	b.ne	0x87e4 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x70>
    87fc:      	ldp	x15, x14, [x12, #-0x8]
    8800:      	madd	x14, x15, x13, x14
    8804:      	add	x22, x14, x22
    8808:      	eor	x14, x14, x14, lsr #30
    880c:      	mul	x14, x14, x20
    8810:      	eor	x14, x14, x14, lsr #27
    8814:      	mul	x14, x14, x19
    8818:      	eor	x15, x21, x14, lsr #31
    881c:      	eor	x21, x15, x14
    8820:      	add	x11, x11, #0x1
    8824:      	b	0x87e4 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x70>
    8828:      	mov	x10, #0x7c15            ; =31765
    882c:      	movk	x10, #0x7f4a, lsl #16
    8830:      	movk	x10, #0x79b9, lsl #32
    8834:      	movk	x10, #0x9e37, lsl #48
    8838:      	mul	x23, x11, x10
    883c:      	ldr	x24, [x8, #0x38]
    8840:      	cbz	x9, 0x8848 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0xd4>
    8844:      	bl	0x8844 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0xd0>
		0000000000008844:  ARM64_RELOC_BRANCH26	_free
    8848:      	eor	x8, x24, x24, lsr #30
    884c:      	mul	x8, x8, x20
    8850:      	eor	x8, x8, x8, lsr #27
    8854:      	mul	x8, x8, x19
    8858:      	eor	x9, x22, x22, lsr #30
    885c:      	mul	x9, x9, x20
    8860:      	eor	x9, x9, x9, lsr #27
    8864:      	mul	x9, x9, x19
    8868:      	eor	x10, x9, x8
    886c:      	eor	x11, x23, x21
    8870:      	eor	x10, x11, x10, lsr #31
    8874:      	eor	x8, x8, x9
    8878:      	eor	x0, x10, x8
    887c:      	ldp	x29, x30, [sp, #0x30]
    8880:      	ldp	x20, x19, [sp, #0x20]
    8884:      	ldp	x22, x21, [sp, #0x10]
    8888:      	ldp	x24, x23, [sp], #0x40
    888c:      	ret
    8890:      	mov	x23, #0x0               ; =0
    8894:      	mov	x21, #0x0               ; =0
    8898:      	mov	x22, #0x0               ; =0
    889c:      	ldr	x24, [x8, #0x38]
    88a0:      	cbnz	x9, 0x8844 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0xd0>
    88a4:      	b	0x8848 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0xd4>
    88a8:      	mov	x11, #0x0               ; =0
    88ac:      	mov	x21, #0x0               ; =0
    88b0:      	mov	x22, #0x0               ; =0
    88b4:      	and	x13, x12, #0xfffffffffffffffc
    88b8:      	mov	w14, #0x18              ; =24
    88bc:      	madd	x14, x12, x14, x0
    88c0:      	sub	x14, x14, #0x30
    88c4:      	mov	w15, #0x83              ; =131
    88c8:      	b	0x88dc <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x168>
    88cc:      	sub	x14, x14, #0x60
    88d0:      	sub	x12, x12, #0x4
    88d4:      	sub	x13, x13, #0x4
    88d8:      	cbz	x13, 0x87cc <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x58>
    88dc:      	ldr	w16, [x14, #0x18]
    88e0:      	cmp	w16, #0x2
    88e4:      	b.eq	0x8910 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x19c>
    88e8:      	ldr	w16, [x14]
    88ec:      	cmp	w16, #0x2
    88f0:      	b.eq	0x8944 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x1d0>
    88f4:      	ldur	w16, [x14, #-0x18]
    88f8:      	cmp	w16, #0x2
    88fc:      	b.eq	0x8978 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x204>
    8900:      	ldur	w16, [x14, #-0x30]
    8904:      	cmp	w16, #0x2
    8908:      	b.ne	0x88cc <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x158>
    890c:      	b	0x89ac <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x238>
    8910:      	ldp	x17, x16, [x14, #0x20]
    8914:      	madd	x16, x17, x15, x16
    8918:      	add	x22, x16, x22
    891c:      	eor	x16, x16, x16, lsr #30
    8920:      	mul	x16, x16, x20
    8924:      	eor	x16, x16, x16, lsr #27
    8928:      	mul	x16, x16, x19
    892c:      	eor	x17, x21, x16, lsr #31
    8930:      	eor	x21, x17, x16
    8934:      	add	x11, x11, #0x1
    8938:      	ldr	w16, [x14]
    893c:      	cmp	w16, #0x2
    8940:      	b.ne	0x88f4 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x180>
    8944:      	ldp	x17, x16, [x14, #0x8]
    8948:      	madd	x16, x17, x15, x16
    894c:      	add	x22, x16, x22
    8950:      	eor	x16, x16, x16, lsr #30
    8954:      	mul	x16, x16, x20
    8958:      	eor	x16, x16, x16, lsr #27
    895c:      	mul	x16, x16, x19
    8960:      	eor	x17, x21, x16, lsr #31
    8964:      	eor	x21, x17, x16
    8968:      	add	x11, x11, #0x1
    896c:      	ldur	w16, [x14, #-0x18]
    8970:      	cmp	w16, #0x2
    8974:      	b.ne	0x8900 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x18c>
    8978:      	ldp	x17, x16, [x14, #-0x10]
    897c:      	madd	x16, x17, x15, x16
    8980:      	add	x22, x16, x22
    8984:      	eor	x16, x16, x16, lsr #30
    8988:      	mul	x16, x16, x20
    898c:      	eor	x16, x16, x16, lsr #27
    8990:      	mul	x16, x16, x19
    8994:      	eor	x17, x21, x16, lsr #31
    8998:      	eor	x21, x17, x16
    899c:      	add	x11, x11, #0x1
    89a0:      	ldur	w16, [x14, #-0x30]
    89a4:      	cmp	w16, #0x2
    89a8:      	b.ne	0x88cc <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x158>
    89ac:      	ldp	x17, x16, [x14, #-0x28]
    89b0:      	madd	x16, x17, x15, x16
    89b4:      	add	x22, x16, x22
    89b8:      	eor	x16, x16, x16, lsr #30
    89bc:      	mul	x16, x16, x20
    89c0:      	eor	x16, x16, x16, lsr #27
    89c4:      	mul	x16, x16, x19
    89c8:      	eor	x17, x21, x16, lsr #31
    89cc:      	eor	x21, x17, x16
    89d0:      	add	x11, x11, #0x1
    89d4:      	b	0x88cc <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x158>

00000000000089d8 <_wf_flat_mutation_prepare$instance$4250cb78d3f44027>:
    89d8:      	stp	x26, x25, [sp, #-0x50]!
    89dc:      	stp	x24, x23, [sp, #0x10]
    89e0:      	stp	x22, x21, [sp, #0x20]
    89e4:      	stp	x20, x19, [sp, #0x30]
    89e8:      	stp	x29, x30, [sp, #0x40]
    89ec:      	sub	sp, sp, #0x340
    89f0:      	mov	x21, x3
    89f4:      	mov	x20, x2
    89f8:      	mov	x22, x1
    89fc:      	mov	x19, x0
    8a00:      	mov	x8, #0x7c15             ; =31765
    8a04:      	movk	x8, #0x7f4a, lsl #16
    8a08:      	movk	x8, #0x79b9, lsl #32
    8a0c:      	movk	x8, #0x9e37, lsl #48
    8a10:      	eor	x8, x3, x8
    8a14:      	str	x8, [sp, #0x120]
    8a18:      	strb	wzr, [sp, #0x128]
    8a1c:      	cbz	x1, 0x8a88 <_wf_flat_mutation_prepare$instance$4250cb78d3f44027+0xb0>
    8a20:      	add	x8, x22, x22, lsl #4
    8a24:      	lsl	x0, x8, #4
    8a28:      	bl	0x8a28 <_wf_flat_mutation_prepare$instance$4250cb78d3f44027+0x50>
		0000000000008a28:  ARM64_RELOC_BRANCH26	_malloc
    8a2c:      	cbz	x0, 0x8c94 <_wf_flat_mutation_prepare$instance$4250cb78d3f44027+0x2bc>
    8a30:      	mov	x8, #0x0                ; =0
    8a34:      	add	x9, x0, #0x8
    8a38:      	movi.2d	v0, #0000000000000000
    8a3c:      	stur	wzr, [x9, #-0x8]
    8a40:      	add	x8, x8, #0x1
    8a44:      	stp	q0, q0, [x9]
    8a48:      	stp	q0, q0, [x9, #0x20]
    8a4c:      	stp	q0, q0, [x9, #0x40]
    8a50:      	stp	q0, q0, [x9, #0x60]
    8a54:      	stp	q0, q0, [x9, #0x80]
    8a58:      	stp	q0, q0, [x9, #0xa0]
    8a5c:      	stp	q0, q0, [x9, #0xc0]
    8a60:      	stp	q0, q0, [x9, #0xe0]
    8a64:      	str	xzr, [x9, #0x100]
    8a68:      	add	x9, x9, #0x110
    8a6c:      	cmp	x22, x8
    8a70:      	b.ne	0x8a3c <_wf_flat_mutation_prepare$instance$4250cb78d3f44027+0x64>
    8a74:      	stp	x22, x22, [sp, #0xf8]
    8a78:      	stp	xzr, xzr, [sp, #0x110]
    8a7c:      	str	x0, [sp, #0x108]
    8a80:      	cbnz	x20, 0x8aa0 <_wf_flat_mutation_prepare$instance$4250cb78d3f44027+0xc8>
    8a84:      	b	0x8c50 <_wf_flat_mutation_prepare$instance$4250cb78d3f44027+0x278>
    8a88:      	adrp	x0, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008a88:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    8a8c:      	add	x0, x0, #0x0
		0000000000008a8c:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    8a90:      	stp	x22, x22, [sp, #0xf8]
    8a94:      	stp	xzr, xzr, [sp, #0x110]
    8a98:      	str	x0, [sp, #0x108]
    8a9c:      	cbz	x20, 0x8c50 <_wf_flat_mutation_prepare$instance$4250cb78d3f44027+0x278>
    8aa0:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008aa0:  ARM64_RELOC_PAGE21	lCPI93_0
    8aa4:      	ldr	q0, [x8]
		0000000000008aa4:  ARM64_RELOC_PAGEOFF12	lCPI93_0
    8aa8:      	str	q0, [sp, #0xe0]
    8aac:      	add	x23, sp, #0x240
    8ab0:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008ab0:  ARM64_RELOC_PAGE21	lCPI93_1
    8ab4:      	ldr	q0, [x8]
		0000000000008ab4:  ARM64_RELOC_PAGEOFF12	lCPI93_1
    8ab8:      	str	q0, [sp, #0xd0]
    8abc:      	mov	w22, #0x1               ; =1
    8ac0:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008ac0:  ARM64_RELOC_PAGE21	lCPI93_2
    8ac4:      	ldr	q0, [x8]
		0000000000008ac4:  ARM64_RELOC_PAGEOFF12	lCPI93_2
    8ac8:      	str	q0, [sp, #0xc0]
    8acc:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008acc:  ARM64_RELOC_PAGE21	lCPI93_3
    8ad0:      	ldr	q0, [x8]
		0000000000008ad0:  ARM64_RELOC_PAGEOFF12	lCPI93_3
    8ad4:      	str	q0, [sp, #0xb0]
    8ad8:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008ad8:  ARM64_RELOC_PAGE21	lCPI93_4
    8adc:      	ldr	q0, [x8]
		0000000000008adc:  ARM64_RELOC_PAGEOFF12	lCPI93_4
    8ae0:      	str	q0, [sp, #0xa0]
    8ae4:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008ae4:  ARM64_RELOC_PAGE21	lCPI93_5
    8ae8:      	ldr	q0, [x8]
		0000000000008ae8:  ARM64_RELOC_PAGEOFF12	lCPI93_5
    8aec:      	str	q0, [sp, #0x90]
    8af0:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008af0:  ARM64_RELOC_PAGE21	lCPI93_6
    8af4:      	ldr	q0, [x8]
		0000000000008af4:  ARM64_RELOC_PAGEOFF12	lCPI93_6
    8af8:      	str	q0, [sp, #0x80]
    8afc:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008afc:  ARM64_RELOC_PAGE21	lCPI93_7
    8b00:      	ldr	q0, [x8]
		0000000000008b00:  ARM64_RELOC_PAGEOFF12	lCPI93_7
    8b04:      	str	q0, [sp, #0x70]
    8b08:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008b08:  ARM64_RELOC_PAGE21	lCPI93_8
    8b0c:      	ldr	q0, [x8]
		0000000000008b0c:  ARM64_RELOC_PAGEOFF12	lCPI93_8
    8b10:      	str	q0, [sp, #0x60]
    8b14:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008b14:  ARM64_RELOC_PAGE21	lCPI93_9
    8b18:      	ldr	q0, [x8]
		0000000000008b18:  ARM64_RELOC_PAGEOFF12	lCPI93_9
    8b1c:      	str	q0, [sp, #0x50]
    8b20:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008b20:  ARM64_RELOC_PAGE21	lCPI93_10
    8b24:      	ldr	q0, [x8]
		0000000000008b24:  ARM64_RELOC_PAGEOFF12	lCPI93_10
    8b28:      	str	q0, [sp, #0x40]
    8b2c:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008b2c:  ARM64_RELOC_PAGE21	lCPI93_11
    8b30:      	ldr	q0, [x8]
		0000000000008b30:  ARM64_RELOC_PAGEOFF12	lCPI93_11
    8b34:      	str	q0, [sp, #0x30]
    8b38:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008b38:  ARM64_RELOC_PAGE21	lCPI93_12
    8b3c:      	ldr	q0, [x8]
		0000000000008b3c:  ARM64_RELOC_PAGEOFF12	lCPI93_12
    8b40:      	str	q0, [sp, #0x20]
    8b44:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008b44:  ARM64_RELOC_PAGE21	lCPI93_13
    8b48:      	ldr	q0, [x8]
		0000000000008b48:  ARM64_RELOC_PAGEOFF12	lCPI93_13
    8b4c:      	str	q0, [sp, #0x10]
    8b50:      	mov	x24, x20
    8b54:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008b54:  ARM64_RELOC_PAGE21	lCPI93_14
    8b58:      	ldr	q0, [x8]
		0000000000008b58:  ARM64_RELOC_PAGEOFF12	lCPI93_14
    8b5c:      	str	q0, [sp]
    8b60:      	mov	x25, x21
    8b64:      	dup.2d	v0, x25
    8b68:      	add	x8, x25, #0x1f
    8b6c:      	ldr	q1, [sp, #0xe0]
    8b70:      	add.2d	v1, v0, v1
    8b74:      	stur	q1, [x23, #0x8]
    8b78:      	ldr	q1, [sp, #0xd0]
    8b7c:      	add.2d	v1, v0, v1
    8b80:      	stur	q1, [x23, #0x18]
    8b84:      	ldr	q1, [sp, #0xc0]
    8b88:      	add.2d	v1, v0, v1
    8b8c:      	stur	q1, [x23, #0x28]
    8b90:      	ldr	q1, [sp, #0xb0]
    8b94:      	add.2d	v1, v0, v1
    8b98:      	stur	q1, [x23, #0x38]
    8b9c:      	ldr	q1, [sp, #0xa0]
    8ba0:      	add.2d	v1, v0, v1
    8ba4:      	stur	q1, [x23, #0x48]
    8ba8:      	ldr	q1, [sp, #0x90]
    8bac:      	add.2d	v1, v0, v1
    8bb0:      	stur	q1, [x23, #0x58]
    8bb4:      	ldr	q1, [sp, #0x80]
    8bb8:      	add.2d	v1, v0, v1
    8bbc:      	stur	q1, [x23, #0x68]
    8bc0:      	ldr	q1, [sp, #0x70]
    8bc4:      	add.2d	v1, v0, v1
    8bc8:      	stur	q1, [x23, #0x78]
    8bcc:      	ldr	q1, [sp, #0x60]
    8bd0:      	add.2d	v1, v0, v1
    8bd4:      	stur	q1, [x23, #0x88]
    8bd8:      	ldr	q1, [sp, #0x50]
    8bdc:      	add.2d	v1, v0, v1
    8be0:      	stur	q1, [x23, #0x98]
    8be4:      	ldr	q1, [sp, #0x40]
    8be8:      	add.2d	v1, v0, v1
    8bec:      	stur	q1, [x23, #0xa8]
    8bf0:      	ldr	q1, [sp, #0x30]
    8bf4:      	add.2d	v1, v0, v1
    8bf8:      	stur	q1, [x23, #0xb8]
    8bfc:      	ldr	q1, [sp, #0x20]
    8c00:      	add.2d	v1, v0, v1
    8c04:      	stur	q1, [x23, #0xc8]
    8c08:      	ldr	q1, [sp, #0x10]
    8c0c:      	add.2d	v1, v0, v1
    8c10:      	stur	q1, [x23, #0xd8]
    8c14:      	ldr	q1, [sp]
    8c18:      	add.2d	v0, v0, v1
    8c1c:      	stur	q0, [x23, #0xe8]
    8c20:      	str	x25, [sp, #0x240]
    8c24:      	str	x8, [sp, #0x338]
    8c28:      	add	x0, sp, #0x130
    8c2c:      	add	x1, sp, #0xf8
    8c30:      	add	x3, sp, #0x240
    8c34:      	add	x4, sp, #0x120
    8c38:      	mov	x2, x22
    8c3c:      	bl	0x8c3c <_wf_flat_mutation_prepare$instance$4250cb78d3f44027+0x264>
		0000000000008c3c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d
    8c40:      	add	x25, x25, #0x1
    8c44:      	add	x22, x22, #0x2
    8c48:      	subs	x24, x24, #0x1
    8c4c:      	b.ne	0x8b64 <_wf_flat_mutation_prepare$instance$4250cb78d3f44027+0x18c>
    8c50:      	ldur	q0, [sp, #0xf8]
    8c54:      	add	x8, sp, #0x9
    8c58:      	ldur	q1, [x8, #0xff]
    8c5c:      	stp	q0, q1, [x19]
    8c60:      	ldr	x8, [sp, #0x118]
    8c64:      	str	x8, [x19, #0x20]
    8c68:      	ldr	q0, [sp, #0x120]
    8c6c:      	stur	q0, [x19, #0x28]
    8c70:      	stp	x21, x20, [x19, #0x38]
    8c74:      	str	xzr, [x19, #0x48]
    8c78:      	add	sp, sp, #0x340
    8c7c:      	ldp	x29, x30, [sp, #0x40]
    8c80:      	ldp	x20, x19, [sp, #0x30]
    8c84:      	ldp	x22, x21, [sp, #0x20]
    8c88:      	ldp	x24, x23, [sp, #0x10]
    8c8c:      	ldp	x26, x25, [sp], #0x50
    8c90:      	ret
    8c94:      	bl	0x8c94 <_wf_flat_mutation_prepare$instance$4250cb78d3f44027+0x2bc>
		0000000000008c94:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

0000000000008c98 <_wf_flat_mutation_batch$instance$4250cb78d3f44027>:
    8c98:      	stp	x28, x27, [sp, #-0x60]!
    8c9c:      	stp	x26, x25, [sp, #0x10]
    8ca0:      	stp	x24, x23, [sp, #0x20]
    8ca4:      	stp	x22, x21, [sp, #0x30]
    8ca8:      	stp	x20, x19, [sp, #0x40]
    8cac:      	stp	x29, x30, [sp, #0x50]
    8cb0:      	sub	sp, sp, #0x3a0
    8cb4:      	ldr	x24, [x0, #0x38]
    8cb8:      	str	x1, [sp, #0x8]
    8cbc:      	cbz	x1, 0x9238 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x5a0>
    8cc0:      	mov	x19, x0
    8cc4:      	ldr	x26, [x0, #0x40]
    8cc8:      	cbz	x26, 0x9228 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x590>
    8ccc:      	mov	x21, x2
    8cd0:      	str	xzr, [sp, #0x18]
    8cd4:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008cd4:  ARM64_RELOC_PAGE21	lCPI94_0
    8cd8:      	ldr	q0, [x8]
		0000000000008cd8:  ARM64_RELOC_PAGEOFF12	lCPI94_0
    8cdc:      	str	q0, [sp, #0x180]
    8ce0:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008ce0:  ARM64_RELOC_PAGE21	lCPI94_1
    8ce4:      	ldr	q0, [x8]
		0000000000008ce4:  ARM64_RELOC_PAGEOFF12	lCPI94_1
    8ce8:      	str	q0, [sp, #0x170]
    8cec:      	add	x27, sp, #0x2a0
    8cf0:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008cf0:  ARM64_RELOC_PAGE21	lCPI94_2
    8cf4:      	ldr	q0, [x8]
		0000000000008cf4:  ARM64_RELOC_PAGEOFF12	lCPI94_2
    8cf8:      	str	q0, [sp, #0x160]
    8cfc:      	mov	w28, #0x1               ; =1
    8d00:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008d00:  ARM64_RELOC_PAGE21	lCPI94_3
    8d04:      	ldr	q0, [x8]
		0000000000008d04:  ARM64_RELOC_PAGEOFF12	lCPI94_3
    8d08:      	str	q0, [sp, #0x150]
    8d0c:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008d0c:  ARM64_RELOC_PAGE21	lCPI94_4
    8d10:      	ldr	q0, [x8]
		0000000000008d10:  ARM64_RELOC_PAGEOFF12	lCPI94_4
    8d14:      	str	q0, [sp, #0x140]
    8d18:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008d18:  ARM64_RELOC_PAGE21	lCPI94_5
    8d1c:      	ldr	q0, [x8]
		0000000000008d1c:  ARM64_RELOC_PAGEOFF12	lCPI94_5
    8d20:      	str	q0, [sp, #0x130]
    8d24:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008d24:  ARM64_RELOC_PAGE21	lCPI94_6
    8d28:      	ldr	q0, [x8]
		0000000000008d28:  ARM64_RELOC_PAGEOFF12	lCPI94_6
    8d2c:      	str	q0, [sp, #0x120]
    8d30:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008d30:  ARM64_RELOC_PAGE21	lCPI94_7
    8d34:      	ldr	q0, [x8]
		0000000000008d34:  ARM64_RELOC_PAGEOFF12	lCPI94_7
    8d38:      	str	q0, [sp, #0x110]
    8d3c:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008d3c:  ARM64_RELOC_PAGE21	lCPI94_8
    8d40:      	ldr	q0, [x8]
		0000000000008d40:  ARM64_RELOC_PAGEOFF12	lCPI94_8
    8d44:      	str	q0, [sp, #0x100]
    8d48:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008d48:  ARM64_RELOC_PAGE21	lCPI94_9
    8d4c:      	ldr	q0, [x8]
		0000000000008d4c:  ARM64_RELOC_PAGEOFF12	lCPI94_9
    8d50:      	str	q0, [sp, #0xf0]
    8d54:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008d54:  ARM64_RELOC_PAGE21	lCPI94_10
    8d58:      	ldr	q0, [x8]
		0000000000008d58:  ARM64_RELOC_PAGEOFF12	lCPI94_10
    8d5c:      	str	q0, [sp, #0xe0]
    8d60:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008d60:  ARM64_RELOC_PAGE21	lCPI94_11
    8d64:      	ldr	q0, [x8]
		0000000000008d64:  ARM64_RELOC_PAGEOFF12	lCPI94_11
    8d68:      	str	q0, [sp, #0xd0]
    8d6c:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008d6c:  ARM64_RELOC_PAGE21	lCPI94_12
    8d70:      	ldr	q0, [x8]
		0000000000008d70:  ARM64_RELOC_PAGEOFF12	lCPI94_12
    8d74:      	str	q0, [sp, #0xc0]
    8d78:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008d78:  ARM64_RELOC_PAGE21	lCPI94_13
    8d7c:      	ldr	q0, [x8]
		0000000000008d7c:  ARM64_RELOC_PAGEOFF12	lCPI94_13
    8d80:      	str	q0, [sp, #0xb0]
    8d84:      	adrp	x8, 0x8000 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x108>
		0000000000008d84:  ARM64_RELOC_PAGE21	lCPI94_14
    8d88:      	ldr	q0, [x8]
		0000000000008d88:  ARM64_RELOC_PAGEOFF12	lCPI94_14
    8d8c:      	str	q0, [sp, #0xa0]
    8d90:      	mov	w20, #0x83              ; =131
    8d94:      	mov	w22, #0x110             ; =272
    8d98:      	ldr	x10, [x19, #0x48]
    8d9c:      	add	x10, x10, #0x1
    8da0:      	str	x10, [sp, #0x10]
    8da4:      	cbz	x26, 0x91fc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x564>
    8da8:      	mov	x23, #0x0               ; =0
    8dac:      	ldr	x8, [x19, #0x38]
    8db0:      	madd	x25, x10, x26, x8
    8db4:      	b	0x8ec0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x228>
    8db8:      	ldrb	w8, [sp, #0x194]
    8dbc:      	tst	w8, #0x1
    8dc0:      	ldp	x9, x8, [sp, #0x198]
    8dc4:      	madd	x8, x9, x20, x8
    8dc8:      	ldp	x10, x9, [sp, #0x1a8]
    8dcc:      	madd	x8, x8, x20, x10
    8dd0:      	madd	x8, x8, x20, x9
    8dd4:      	ldp	x10, x9, [sp, #0x1b8]
    8dd8:      	madd	x8, x8, x20, x10
    8ddc:      	madd	x8, x8, x20, x9
    8de0:      	ldp	x10, x9, [sp, #0x1c8]
    8de4:      	madd	x8, x8, x20, x10
    8de8:      	madd	x8, x8, x20, x9
    8dec:      	ldp	x10, x9, [sp, #0x1d8]
    8df0:      	madd	x8, x8, x20, x10
    8df4:      	madd	x8, x8, x20, x9
    8df8:      	ldp	x10, x9, [sp, #0x1e8]
    8dfc:      	madd	x8, x8, x20, x10
    8e00:      	madd	x8, x8, x20, x9
    8e04:      	ldp	x10, x9, [sp, #0x1f8]
    8e08:      	madd	x8, x8, x20, x10
    8e0c:      	madd	x8, x8, x20, x9
    8e10:      	ldr	x9, [sp, #0x208]
    8e14:      	madd	x8, x8, x20, x9
    8e18:      	ldr	x9, [sp, #0x210]
    8e1c:      	madd	x8, x8, x20, x9
    8e20:      	ldr	x9, [sp, #0x218]
    8e24:      	madd	x8, x8, x20, x9
    8e28:      	ldr	x9, [sp, #0x220]
    8e2c:      	madd	x8, x8, x20, x9
    8e30:      	ldr	x9, [sp, #0x228]
    8e34:      	madd	x8, x8, x20, x9
    8e38:      	ldr	x9, [sp, #0x230]
    8e3c:      	madd	x8, x8, x20, x9
    8e40:      	ldr	x9, [sp, #0x238]
    8e44:      	madd	x8, x8, x20, x9
    8e48:      	ldr	x9, [sp, #0x240]
    8e4c:      	madd	x8, x8, x20, x9
    8e50:      	ldr	x9, [sp, #0x248]
    8e54:      	madd	x8, x8, x20, x9
    8e58:      	ldr	x9, [sp, #0x250]
    8e5c:      	madd	x8, x8, x20, x9
    8e60:      	ldr	x9, [sp, #0x258]
    8e64:      	madd	x8, x8, x20, x9
    8e68:      	ldr	x9, [sp, #0x260]
    8e6c:      	madd	x8, x8, x20, x9
    8e70:      	ldr	x9, [sp, #0x268]
    8e74:      	madd	x8, x8, x20, x9
    8e78:      	ldr	x9, [sp, #0x270]
    8e7c:      	madd	x8, x8, x20, x9
    8e80:      	ldr	x9, [sp, #0x278]
    8e84:      	madd	x8, x8, x20, x9
    8e88:      	ldr	x9, [sp, #0x280]
    8e8c:      	madd	x8, x8, x20, x9
    8e90:      	ldr	x9, [sp, #0x288]
    8e94:      	add	x9, x9, x24
    8e98:      	ldr	x10, [sp, #0x290]
    8e9c:      	madd	x8, x8, x20, x9
    8ea0:      	cinc	x9, x28, ne
    8ea4:      	add	x9, x9, x10
    8ea8:      	madd	x8, x8, x20, x9
    8eac:      	ldr	x9, [sp, #0x298]
    8eb0:      	madd	x24, x8, x20, x9
    8eb4:      	add	x23, x23, #0x1
    8eb8:      	cmp	x23, x26
    8ebc:      	b.eq	0x91fc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x564>
    8ec0:      	orr	x2, x28, x23, lsl #1
    8ec4:      	cbz	x21, 0x9108 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x470>
    8ec8:      	ldr	x8, [x19, #0x18]
    8ecc:      	cbz	x8, 0x9104 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x46c>
    8ed0:      	ldrb	w9, [x19, #0x30]
    8ed4:      	tbz	w9, #0x0, 0x8ee8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x250>
    8ed8:      	mov	x9, #0x0                ; =0
    8edc:      	ldr	x10, [x19]
    8ee0:      	cbnz	x10, 0x8f2c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x294>
    8ee4:      	b	0x9104 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x46c>
    8ee8:      	ldr	x9, [x19, #0x28]
    8eec:      	eor	x9, x9, x2
    8ef0:      	eor	x9, x9, x9, lsr #30
    8ef4:      	mov	x10, #0xe5b9            ; =58809
    8ef8:      	movk	x10, #0x1ce4, lsl #16
    8efc:      	movk	x10, #0x476d, lsl #32
    8f00:      	movk	x10, #0xbf58, lsl #48
    8f04:      	mul	x9, x9, x10
    8f08:      	eor	x9, x9, x9, lsr #27
    8f0c:      	mov	x10, #0x11eb            ; =4587
    8f10:      	movk	x10, #0x1331, lsl #16
    8f14:      	movk	x10, #0x49bb, lsl #32
    8f18:      	movk	x10, #0x94d0, lsl #48
    8f1c:      	mul	x9, x9, x10
    8f20:      	eor	x9, x9, x9, lsr #31
    8f24:      	ldr	x10, [x19]
    8f28:      	cbz	x10, 0x9104 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x46c>
    8f2c:      	udiv	x11, x9, x10
    8f30:      	msub	x11, x11, x10, x9
    8f34:      	ldr	x12, [x19, #0x10]
    8f38:      	mov	x13, x10
    8f3c:      	b	0x8f54 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2bc>
    8f40:      	add	x9, x11, #0x1
    8f44:      	cmp	x9, x10
    8f48:      	csinc	x11, xzr, x11, hs
    8f4c:      	subs	x13, x13, #0x1
    8f50:      	b.eq	0x9104 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x46c>
    8f54:      	madd	x9, x11, x22, x12
    8f58:      	ldr	w14, [x9]
    8f5c:      	cmp	w14, #0x1
    8f60:      	b.eq	0x8f40 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2a8>
    8f64:      	cmp	w14, #0x2
    8f68:      	b.ne	0x9104 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x46c>
    8f6c:      	ldr	x14, [x9, #0x8]
    8f70:      	cmp	x14, x2
    8f74:      	b.ne	0x8f40 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2a8>
    8f78:      	ldp	x11, x10, [x9, #0x10]
    8f7c:      	stp	x10, x11, [sp, #0x90]
    8f80:      	ldp	x11, x10, [x9, #0x20]
    8f84:      	stp	x10, x11, [sp, #0x80]
    8f88:      	ldp	x14, x15, [x9, #0x30]
    8f8c:      	ldp	x16, x17, [x9, #0x40]
    8f90:      	ldp	x0, x1, [x9, #0x50]
    8f94:      	ldp	x3, x4, [x9, #0x60]
    8f98:      	ldp	x5, x6, [x9, #0x70]
    8f9c:      	ldp	x7, x30, [x9, #0x80]
    8fa0:      	ldp	x11, x10, [x9, #0x90]
    8fa4:      	stp	x10, x11, [sp, #0x70]
    8fa8:      	ldp	x11, x10, [x9, #0xa0]
    8fac:      	stp	x10, x11, [sp, #0x60]
    8fb0:      	ldp	x11, x10, [x9, #0xb0]
    8fb4:      	stp	x10, x11, [sp, #0x50]
    8fb8:      	ldp	x11, x10, [x9, #0xc0]
    8fbc:      	stp	x10, x11, [sp, #0x40]
    8fc0:      	ldp	x11, x10, [x9, #0xd0]
    8fc4:      	stp	x10, x11, [sp, #0x30]
    8fc8:      	ldp	x11, x10, [x9, #0xe0]
    8fcc:      	stp	x10, x11, [sp, #0x20]
    8fd0:      	str	w28, [x9]
    8fd4:      	movi.2d	v0, #0000000000000000
    8fd8:      	stur	q0, [x9, #0x8]
    8fdc:      	stur	q0, [x9, #0x18]
    8fe0:      	stur	q0, [x9, #0x28]
    8fe4:      	stur	q0, [x9, #0x38]
    8fe8:      	stur	q0, [x9, #0x48]
    8fec:      	stur	q0, [x9, #0x58]
    8ff0:      	stur	q0, [x9, #0x68]
    8ff4:      	stur	q0, [x9, #0x78]
    8ff8:      	stur	q0, [x9, #0x88]
    8ffc:      	stur	q0, [x9, #0x98]
    9000:      	stur	q0, [x9, #0xa8]
    9004:      	stur	q0, [x9, #0xb8]
    9008:      	stur	q0, [x9, #0xc8]
    900c:      	stur	q0, [x9, #0xd8]
    9010:      	ldp	x12, x13, [x9, #0xf0]
    9014:      	stur	q0, [x9, #0xe8]
    9018:      	ldp	x10, x11, [x9, #0x100]
    901c:      	stur	q0, [x9, #0xf8]
    9020:      	str	xzr, [x9, #0x108]
    9024:      	sub	x8, x8, #0x1
    9028:      	ldr	x9, [x19, #0x20]
    902c:      	adds	x9, x9, #0x1
    9030:      	csinv	x9, x9, xzr, lo
    9034:      	stp	x8, x9, [x19, #0x18]
    9038:      	ldp	x9, x8, [sp, #0x90]
    903c:      	madd	x8, x2, x20, x8
    9040:      	madd	x8, x8, x20, x9
    9044:      	ldr	x9, [sp, #0x88]
    9048:      	madd	x8, x8, x20, x9
    904c:      	ldr	x9, [sp, #0x80]
    9050:      	madd	x8, x8, x20, x9
    9054:      	madd	x8, x8, x20, x14
    9058:      	madd	x8, x8, x20, x15
    905c:      	madd	x8, x8, x20, x16
    9060:      	madd	x8, x8, x20, x17
    9064:      	madd	x8, x8, x20, x0
    9068:      	madd	x8, x8, x20, x1
    906c:      	madd	x8, x8, x20, x3
    9070:      	madd	x8, x8, x20, x4
    9074:      	madd	x8, x8, x20, x5
    9078:      	madd	x8, x8, x20, x6
    907c:      	madd	x8, x8, x20, x7
    9080:      	madd	x8, x8, x20, x30
    9084:      	ldr	x9, [sp, #0x78]
    9088:      	madd	x8, x8, x20, x9
    908c:      	ldr	x9, [sp, #0x70]
    9090:      	madd	x8, x8, x20, x9
    9094:      	ldr	x9, [sp, #0x68]
    9098:      	madd	x8, x8, x20, x9
    909c:      	ldr	x9, [sp, #0x60]
    90a0:      	madd	x8, x8, x20, x9
    90a4:      	ldr	x9, [sp, #0x58]
    90a8:      	madd	x8, x8, x20, x9
    90ac:      	ldr	x9, [sp, #0x50]
    90b0:      	madd	x8, x8, x20, x9
    90b4:      	ldr	x9, [sp, #0x48]
    90b8:      	madd	x8, x8, x20, x9
    90bc:      	ldr	x9, [sp, #0x40]
    90c0:      	madd	x8, x8, x20, x9
    90c4:      	ldr	x9, [sp, #0x38]
    90c8:      	madd	x8, x8, x20, x9
    90cc:      	ldr	x9, [sp, #0x30]
    90d0:      	madd	x8, x8, x20, x9
    90d4:      	ldr	x9, [sp, #0x28]
    90d8:      	madd	x8, x8, x20, x9
    90dc:      	ldr	x9, [sp, #0x20]
    90e0:      	madd	x8, x8, x20, x9
    90e4:      	madd	x8, x8, x20, x12
    90e8:      	madd	x8, x8, x20, x13
    90ec:      	madd	x8, x8, x20, x10
    90f0:      	mov	w9, #0x4309             ; =17161
    90f4:      	madd	x9, x24, x9, x11
    90f8:      	madd	x8, x8, x20, x9
    90fc:      	add	x24, x8, #0x83
    9100:      	b	0x9108 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x470>
    9104:      	mul	x24, x24, x20
    9108:      	add	x8, x25, x23
    910c:      	dup.2d	v0, x8
    9110:      	ldr	q1, [sp, #0x180]
    9114:      	add.2d	v1, v0, v1
    9118:      	stur	q1, [x27, #0x8]
    911c:      	add	x9, x8, #0x1f
    9120:      	ldr	q1, [sp, #0x170]
    9124:      	add.2d	v1, v0, v1
    9128:      	stur	q1, [x27, #0x18]
    912c:      	ldr	q1, [sp, #0x160]
    9130:      	add.2d	v1, v0, v1
    9134:      	stur	q1, [x27, #0x28]
    9138:      	ldr	q1, [sp, #0x150]
    913c:      	add.2d	v1, v0, v1
    9140:      	stur	q1, [x27, #0x38]
    9144:      	ldr	q1, [sp, #0x140]
    9148:      	add.2d	v1, v0, v1
    914c:      	stur	q1, [x27, #0x48]
    9150:      	ldr	q1, [sp, #0x130]
    9154:      	add.2d	v1, v0, v1
    9158:      	stur	q1, [x27, #0x58]
    915c:      	ldr	q1, [sp, #0x120]
    9160:      	add.2d	v1, v0, v1
    9164:      	stur	q1, [x27, #0x68]
    9168:      	ldr	q1, [sp, #0x110]
    916c:      	add.2d	v1, v0, v1
    9170:      	stur	q1, [x27, #0x78]
    9174:      	ldr	q1, [sp, #0x100]
    9178:      	add.2d	v1, v0, v1
    917c:      	stur	q1, [x27, #0x88]
    9180:      	ldr	q1, [sp, #0xf0]
    9184:      	add.2d	v1, v0, v1
    9188:      	stur	q1, [x27, #0x98]
    918c:      	ldr	q1, [sp, #0xe0]
    9190:      	add.2d	v1, v0, v1
    9194:      	stur	q1, [x27, #0xa8]
    9198:      	ldr	q1, [sp, #0xd0]
    919c:      	add.2d	v1, v0, v1
    91a0:      	stur	q1, [x27, #0xb8]
    91a4:      	ldr	q1, [sp, #0xc0]
    91a8:      	add.2d	v1, v0, v1
    91ac:      	stur	q1, [x27, #0xc8]
    91b0:      	ldr	q1, [sp, #0xb0]
    91b4:      	add.2d	v1, v0, v1
    91b8:      	stur	q1, [x27, #0xd8]
    91bc:      	ldr	q1, [sp, #0xa0]
    91c0:      	add.2d	v0, v0, v1
    91c4:      	stur	q0, [x27, #0xe8]
    91c8:      	str	x8, [sp, #0x2a0]
    91cc:      	str	x9, [sp, #0x398]
    91d0:      	add	x0, sp, #0x190
    91d4:      	add	x3, sp, #0x2a0
    91d8:      	add	x4, x19, #0x28
    91dc:      	mov	x1, x19
    91e0:      	bl	0x91e0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x548>
		00000000000091e0:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d
    91e4:      	ldr	w8, [sp, #0x190]
    91e8:      	cbnz	w8, 0x8db8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x120>
    91ec:      	mul	x24, x24, x20
    91f0:      	add	x23, x23, #0x1
    91f4:      	cmp	x23, x26
    91f8:      	b.ne	0x8ec0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x228>
    91fc:      	ldp	x10, x9, [sp, #0x10]
    9200:      	str	x10, [x19, #0x48]
    9204:      	add	x9, x9, #0x1
    9208:      	ldr	x8, [sp, #0x8]
    920c:      	cmp	x9, x8
    9210:      	b.eq	0x9238 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x5a0>
    9214:      	ldr	x26, [x19, #0x40]
    9218:      	add	x10, x10, #0x1
    921c:      	stp	x10, x9, [sp, #0x10]
    9220:      	cbnz	x26, 0x8da8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x110>
    9224:      	b	0x91fc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x564>
    9228:      	ldr	x8, [x19, #0x48]
    922c:      	ldr	x9, [sp, #0x8]
    9230:      	add	x8, x8, x9
    9234:      	str	x8, [x19, #0x48]
    9238:      	eor	x8, x24, x24, lsr #30
    923c:      	mov	x9, #0xe5b9             ; =58809
    9240:      	movk	x9, #0x1ce4, lsl #16
    9244:      	movk	x9, #0x476d, lsl #32
    9248:      	movk	x9, #0xbf58, lsl #48
    924c:      	mul	x8, x8, x9
    9250:      	eor	x8, x8, x8, lsr #27
    9254:      	mov	x9, #0x11eb             ; =4587
    9258:      	movk	x9, #0x1331, lsl #16
    925c:      	movk	x9, #0x49bb, lsl #32
    9260:      	movk	x9, #0x94d0, lsl #48
    9264:      	mul	x8, x8, x9
    9268:      	eor	x0, x8, x8, lsr #31
    926c:      	add	sp, sp, #0x3a0
    9270:      	ldp	x29, x30, [sp, #0x50]
    9274:      	ldp	x20, x19, [sp, #0x40]
    9278:      	ldp	x22, x21, [sp, #0x30]
    927c:      	ldp	x24, x23, [sp, #0x20]
    9280:      	ldp	x26, x25, [sp, #0x10]
    9284:      	ldp	x28, x27, [sp], #0x60
    9288:      	ret

000000000000928c <_wf_flat_mutation_geometry$instance$9fed7d4c5d7cc122>:
    928c:      	ldr	x8, [x0]
    9290:      	ldr	x9, [x0, #0x18]
    9294:      	add	x0, x9, x8, lsl #32
    9298:      	ret

000000000000929c <_wf_flat_mutation_verify$instance$4250cb78d3f44027>:
    929c:      	mov	x9, #0xe5b9             ; =58809
    92a0:      	movk	x9, #0x1ce4, lsl #16
    92a4:      	movk	x9, #0x476d, lsl #32
    92a8:      	movk	x9, #0xbf58, lsl #48
    92ac:      	mov	x8, #0x11eb             ; =4587
    92b0:      	movk	x8, #0x1331, lsl #16
    92b4:      	movk	x8, #0x49bb, lsl #32
    92b8:      	movk	x8, #0x94d0, lsl #48
    92bc:      	ldp	x1, x10, [x0, #0x38]
    92c0:      	cbz	x10, 0x9428 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x18c>
    92c4:      	mov	x11, #0x0               ; =0
    92c8:      	ldr	x12, [x0, #0x28]
    92cc:      	ldrb	w13, [x0, #0x30]
    92d0:      	mov	w14, #0x83              ; =131
    92d4:      	mov	w15, #0x110             ; =272
    92d8:      	mov	w16, #0x4309            ; =17161
    92dc:      	ldr	x17, [x0]
    92e0:      	b	0x92f4 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x58>
    92e4:      	mul	x1, x1, x14
    92e8:      	add	x11, x11, #0x1
    92ec:      	cmp	x11, x10
    92f0:      	b.eq	0x9428 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x18c>
    92f4:      	mov	w2, #0x1                ; =1
    92f8:      	bfi	x2, x11, #1, #63
    92fc:      	tbz	w13, #0x0, 0x930c <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x70>
    9300:      	mov	x3, #0x0                ; =0
    9304:      	cbnz	x17, 0x9328 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x8c>
    9308:      	b	0x93ac <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x110>
    930c:      	eor	x3, x12, x2
    9310:      	eor	x3, x3, x3, lsr #30
    9314:      	mul	x3, x3, x9
    9318:      	eor	x3, x3, x3, lsr #27
    931c:      	mul	x3, x3, x8
    9320:      	eor	x3, x3, x3, lsr #31
    9324:      	cbz	x17, 0x93ac <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x110>
    9328:      	udiv	x4, x3, x17
    932c:      	msub	x3, x4, x17, x3
    9330:      	ldr	x4, [x0, #0x10]
    9334:      	mov	x5, x17
    9338:      	b	0x9350 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0xb4>
    933c:      	add	x6, x3, #0x1
    9340:      	cmp	x6, x17
    9344:      	csinc	x3, xzr, x3, hs
    9348:      	subs	x5, x5, #0x1
    934c:      	b.eq	0x93ac <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x110>
    9350:      	madd	x6, x3, x15, x4
    9354:      	ldr	w7, [x6]
    9358:      	cmp	w7, #0x1
    935c:      	b.eq	0x933c <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0xa0>
    9360:      	cmp	w7, #0x2
    9364:      	b.ne	0x93ac <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x110>
    9368:      	ldr	x7, [x6, #0x8]
    936c:      	cmp	x7, x2
    9370:      	b.ne	0x933c <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0xa0>
    9374:      	ldr	x2, [x6, #0x10]
    9378:      	madd	x1, x1, x16, x2
    937c:      	add	x1, x1, #0x83
    9380:      	lsl	x2, x11, #1
    9384:      	add	x2, x2, #0x2
    9388:      	tbnz	w13, #0x0, 0x93bc <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x120>
    938c:      	eor	x3, x12, x2
    9390:      	eor	x3, x3, x3, lsr #30
    9394:      	mul	x3, x3, x9
    9398:      	eor	x3, x3, x3, lsr #27
    939c:      	mul	x3, x3, x8
    93a0:      	eor	x3, x3, x3, lsr #31
    93a4:      	cbnz	x17, 0x93c4 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x128>
    93a8:      	b	0x92e4 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x48>
    93ac:      	mul	x1, x1, x14
    93b0:      	lsl	x2, x11, #1
    93b4:      	add	x2, x2, #0x2
    93b8:      	tbz	w13, #0x0, 0x938c <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0xf0>
    93bc:      	mov	x3, #0x0                ; =0
    93c0:      	cbz	x17, 0x92e4 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x48>
    93c4:      	udiv	x4, x3, x17
    93c8:      	msub	x3, x4, x17, x3
    93cc:      	ldr	x4, [x0, #0x10]
    93d0:      	mov	x5, x17
    93d4:      	b	0x93ec <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x150>
    93d8:      	add	x6, x3, #0x1
    93dc:      	cmp	x6, x17
    93e0:      	csinc	x3, xzr, x3, hs
    93e4:      	subs	x5, x5, #0x1
    93e8:      	b.eq	0x92e4 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x48>
    93ec:      	madd	x6, x3, x15, x4
    93f0:      	ldr	w7, [x6]
    93f4:      	cmp	w7, #0x1
    93f8:      	b.eq	0x93d8 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x13c>
    93fc:      	cmp	w7, #0x2
    9400:      	b.ne	0x92e4 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x48>
    9404:      	ldr	x7, [x6, #0x8]
    9408:      	cmp	x7, x2
    940c:      	b.ne	0x93d8 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x13c>
    9410:      	ldr	x2, [x6, #0x10]
    9414:      	madd	x1, x1, x16, x2
    9418:      	add	x1, x1, #0x83
    941c:      	add	x11, x11, #0x1
    9420:      	cmp	x11, x10
    9424:      	b.ne	0x92f4 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x58>
    9428:      	eor	x10, x1, x1, lsr #30
    942c:      	mul	x9, x10, x9
    9430:      	eor	x9, x9, x9, lsr #27
    9434:      	mul	x8, x9, x8
    9438:      	eor	x0, x8, x8, lsr #31
    943c:      	ret

0000000000009440 <_wf_flat_mutation_finish$instance$4250cb78d3f44027>:
    9440:      	sub	sp, sp, #0x60
    9444:      	stp	x29, x30, [sp, #0x50]
    9448:      	ldr	x8, [x0, #0x38]
    944c:      	ldp	q0, q1, [x0]
    9450:      	stp	q0, q1, [sp, #0x20]
    9454:      	ldr	x9, [x0, #0x20]
    9458:      	str	x9, [sp, #0x40]
    945c:      	stp	x8, xzr, [sp]
    9460:      	stp	xzr, xzr, [sp, #0x10]
    9464:      	add	x0, sp, #0x20
    9468:      	mov	x1, sp
    946c:      	bl	0x946c <_wf_flat_mutation_finish$instance$4250cb78d3f44027+0x2c>
		000000000000946c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_free$instance$e1a21e22af512733
    9470:      	ldp	x8, x9, [sp]
    9474:      	ldp	x10, x11, [sp, #0x10]
    9478:      	eor	x8, x8, x8, lsr #30
    947c:      	mov	x12, #0xe5b9            ; =58809
    9480:      	movk	x12, #0x1ce4, lsl #16
    9484:      	movk	x12, #0x476d, lsl #32
    9488:      	movk	x12, #0xbf58, lsl #48
    948c:      	mul	x8, x8, x12
    9490:      	eor	x8, x8, x8, lsr #27
    9494:      	mov	x13, #0x11eb            ; =4587
    9498:      	movk	x13, #0x1331, lsl #16
    949c:      	movk	x13, #0x49bb, lsl #32
    94a0:      	movk	x13, #0x94d0, lsl #48
    94a4:      	mul	x8, x8, x13
    94a8:      	eor	x9, x9, x9, lsr #30
    94ac:      	mul	x9, x9, x12
    94b0:      	eor	x9, x9, x9, lsr #27
    94b4:      	mul	x9, x9, x13
    94b8:      	eor	x12, x9, x8
    94bc:      	mov	x13, #0x7c15            ; =31765
    94c0:      	movk	x13, #0x7f4a, lsl #16
    94c4:      	movk	x13, #0x79b9, lsl #32
    94c8:      	movk	x13, #0x9e37, lsl #48
    94cc:      	mul	x11, x11, x13
    94d0:      	eor	x10, x10, x11
    94d4:      	eor	x10, x10, x12, lsr #31
    94d8:      	eor	x8, x8, x9
    94dc:      	eor	x0, x10, x8
    94e0:      	ldp	x29, x30, [sp, #0x50]
    94e4:      	add	sp, sp, #0x60
    94e8:      	ret

00000000000094ec <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd>:
    94ec:      	sub	sp, sp, #0x60
    94f0:      	stp	x26, x25, [sp, #0x10]
    94f4:      	stp	x24, x23, [sp, #0x20]
    94f8:      	stp	x22, x21, [sp, #0x30]
    94fc:      	stp	x20, x19, [sp, #0x40]
    9500:      	stp	x29, x30, [sp, #0x50]
    9504:      	mov	x20, x3
    9508:      	mov	x19, x2
    950c:      	mov	x22, x1
    9510:      	mov	x21, x0
    9514:      	mov	x8, #0x7c15             ; =31765
    9518:      	movk	x8, #0x7f4a, lsl #16
    951c:      	movk	x8, #0x79b9, lsl #32
    9520:      	movk	x8, #0x9e37, lsl #48
    9524:      	eor	x25, x3, x8
    9528:      	strb	wzr, [sp, #0x8]
    952c:      	cbz	x1, 0x9604 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x118>
    9530:      	lsl	x24, x22, #3
    9534:      	mov	x0, x24
    9538:      	bl	0x9538 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x4c>
		0000000000009538:  ARM64_RELOC_BRANCH26	_malloc
    953c:      	cbz	x0, 0x9724 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x238>
    9540:      	mov	x23, x0
    9544:      	mov	w1, #0xff               ; =255
    9548:      	mov	x2, x24
    954c:      	bl	0x954c <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x60>
		000000000000954c:  ARM64_RELOC_BRANCH26	_memset
    9550:      	add	x8, x22, x22, lsl #1
    9554:      	lsl	x0, x8, #3
    9558:      	bl	0x9558 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x6c>
		0000000000009558:  ARM64_RELOC_BRANCH26	_malloc
    955c:      	cbz	x0, 0x9724 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x238>
    9560:      	mov	w8, #0x2000             ; =8192
    9564:      	cmp	x22, #0x2, lsl #12      ; =0x2000
    9568:      	csel	x10, x22, x8, lo
    956c:      	ldrb	w8, [sp, #0x8]
    9570:      	cbz	x19, 0x961c <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x130>
    9574:      	mov	x11, #0x0               ; =0
    9578:      	mov	x9, #0x0                ; =0
    957c:      	tbz	w8, #0x0, 0x9624 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x138>
    9580:      	ldr	x12, [x23]
    9584:      	mov	w13, #0x1               ; =1
    9588:      	mov	w14, #0x18              ; =24
    958c:      	b	0x95a0 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0xb4>
    9590:      	str	x15, [x1, #0x8]
    9594:      	add	x11, x11, #0x1
    9598:      	cmp	x11, x19
    959c:      	b.eq	0x96e8 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x1fc>
    95a0:      	orr	x16, x13, x11, lsl #1
    95a4:      	add	x15, x11, x20
    95a8:      	cbz	x9, 0x95e4 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0xf8>
    95ac:      	cmp	x12, x9
    95b0:      	b.hs	0x95e4 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0xf8>
    95b4:      	mov	w17, #0x1               ; =1
    95b8:      	mov	x1, x12
    95bc:      	madd	x1, x1, x14, x0
    95c0:      	ldr	x2, [x1]
    95c4:      	cmp	x2, x16
    95c8:      	b.eq	0x9590 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0xa4>
    95cc:      	cmp	x17, x9
    95d0:      	b.hs	0x95e4 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0xf8>
    95d4:      	ldr	x1, [x1, #0x10]
    95d8:      	add	x17, x17, #0x1
    95dc:      	cmp	x1, x9
    95e0:      	b.lo	0x95bc <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0xd0>
    95e4:      	cmp	x9, x10
    95e8:      	b.hs	0x9594 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0xa8>
    95ec:      	madd	x17, x9, x14, x0
    95f0:      	stp	x16, x15, [x17]
    95f4:      	str	x12, [x17, #0x10]
    95f8:      	mov	x12, x9
    95fc:      	add	x9, x9, #0x1
    9600:      	b	0x9594 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0xa8>
    9604:      	mov	x9, #0x0                ; =0
    9608:      	adrp	x0, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x368>
		0000000000009608:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    960c:      	add	x0, x0, #0x0
		000000000000960c:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    9610:      	ldrb	w8, [sp, #0x8]
    9614:      	mov	x23, x0
    9618:      	b	0x96ec <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x200>
    961c:      	mov	x9, #0x0                ; =0
    9620:      	b	0x96ec <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x200>
    9624:      	mov	w12, #0x1               ; =1
    9628:      	mov	x13, #0xe5b9            ; =58809
    962c:      	movk	x13, #0x1ce4, lsl #16
    9630:      	movk	x13, #0x476d, lsl #32
    9634:      	movk	x13, #0xbf58, lsl #48
    9638:      	mov	x14, #0x11eb            ; =4587
    963c:      	movk	x14, #0x1331, lsl #16
    9640:      	movk	x14, #0x49bb, lsl #32
    9644:      	movk	x14, #0x94d0, lsl #48
    9648:      	mov	w15, #0x18              ; =24
    964c:      	b	0x9660 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x174>
    9650:      	str	x16, [x4, #0x8]
    9654:      	add	x11, x11, #0x1
    9658:      	cmp	x11, x19
    965c:      	b.eq	0x96ec <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x200>
    9660:      	orr	x17, x12, x11, lsl #1
    9664:      	add	x16, x11, x20
    9668:      	eor	x1, x17, x25
    966c:      	eor	x1, x1, x1, lsr #30
    9670:      	mul	x1, x1, x13
    9674:      	eor	x1, x1, x1, lsr #27
    9678:      	mul	x1, x1, x14
    967c:      	eor	x1, x1, x1, lsr #31
    9680:      	udiv	x2, x1, x22
    9684:      	msub	x1, x2, x22, x1
    9688:      	ldr	x2, [x23, x1, lsl #3]
    968c:      	cbz	x9, 0x96c8 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x1dc>
    9690:      	cmp	x2, x9
    9694:      	b.hs	0x96c8 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x1dc>
    9698:      	mov	w3, #0x1                ; =1
    969c:      	mov	x4, x2
    96a0:      	madd	x4, x4, x15, x0
    96a4:      	ldr	x5, [x4]
    96a8:      	cmp	x5, x17
    96ac:      	b.eq	0x9650 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x164>
    96b0:      	cmp	x3, x9
    96b4:      	b.hs	0x96c8 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x1dc>
    96b8:      	ldr	x4, [x4, #0x10]
    96bc:      	add	x3, x3, #0x1
    96c0:      	cmp	x4, x9
    96c4:      	b.lo	0x96a0 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x1b4>
    96c8:      	cmp	x9, x10
    96cc:      	b.hs	0x9654 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x168>
    96d0:      	madd	x3, x9, x15, x0
    96d4:      	stp	x17, x16, [x3]
    96d8:      	str	x2, [x3, #0x10]
    96dc:      	str	x9, [x23, x1, lsl #3]
    96e0:      	add	x9, x9, #0x1
    96e4:      	b	0x9654 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x168>
    96e8:      	str	x12, [x23]
    96ec:      	stp	x22, x22, [x21]
    96f0:      	stp	x23, x9, [x21, #0x10]
    96f4:      	stp	x22, x0, [x21, #0x20]
    96f8:      	stp	x25, xzr, [x21, #0x30]
    96fc:      	strb	w8, [x21, #0x38]
    9700:      	stp	x20, x19, [x21, #0x40]
    9704:      	str	xzr, [x21, #0x50]
    9708:      	ldp	x29, x30, [sp, #0x50]
    970c:      	ldp	x20, x19, [sp, #0x40]
    9710:      	ldp	x22, x21, [sp, #0x30]
    9714:      	ldp	x24, x23, [sp, #0x20]
    9718:      	ldp	x26, x25, [sp, #0x10]
    971c:      	add	sp, sp, #0x60
    9720:      	ret
    9724:      	bl	0x9724 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x238>
		0000000000009724:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

0000000000009728 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd>:
    9728:      	sub	sp, sp, #0x70
    972c:      	stp	x28, x27, [sp, #0x10]
    9730:      	stp	x26, x25, [sp, #0x20]
    9734:      	stp	x24, x23, [sp, #0x30]
    9738:      	stp	x22, x21, [sp, #0x40]
    973c:      	stp	x20, x19, [sp, #0x50]
    9740:      	stp	x29, x30, [sp, #0x60]
    9744:      	mov	x9, #0xe5b9             ; =58809
    9748:      	movk	x9, #0x1ce4, lsl #16
    974c:      	movk	x9, #0x476d, lsl #32
    9750:      	movk	x9, #0xbf58, lsl #48
    9754:      	mov	x8, #0x11eb             ; =4587
    9758:      	movk	x8, #0x1331, lsl #16
    975c:      	movk	x8, #0x49bb, lsl #32
    9760:      	movk	x8, #0x94d0, lsl #48
    9764:      	ldr	x20, [x0, #0x40]
    9768:      	str	x1, [sp]
    976c:      	cbz	x1, 0x9a94 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x36c>
    9770:      	ldp	x12, x11, [x0, #0x48]
    9774:      	cbz	x12, 0x9a80 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x358>
    9778:      	mov	x13, #0x0               ; =0
    977c:      	ldr	x14, [x0, #0x30]
    9780:      	ldr	x15, [x0]
    9784:      	mov	w10, #0x2000            ; =8192
    9788:      	cmp	x15, #0x2, lsl #12      ; =0x2000
    978c:      	csel	x16, x15, x10, lo
    9790:      	mov	w17, #0x1               ; =1
    9794:      	ldrb	w3, [x0, #0x38]
    9798:      	mov	w4, #0x83               ; =131
    979c:      	mov	w5, #0x18               ; =24
    97a0:      	mov	x7, x20
    97a4:      	b	0x97bc <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
    97a8:      	add	x13, x13, #0x1
    97ac:      	ldr	x10, [sp]
    97b0:      	cmp	x13, x10
    97b4:      	mov	x20, x6
    97b8:      	b.eq	0x9a8c <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x364>
    97bc:      	mov	x19, #0x0               ; =0
    97c0:      	add	x11, x11, #0x1
    97c4:      	mov	x6, x20
    97c8:      	madd	x20, x11, x12, x20
    97cc:      	b	0x97f4 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0xcc>
    97d0:      	strb	w17, [sp, #0xc]
    97d4:      	tst	w17, #0x1
    97d8:      	cinc	x10, x17, ne
    97dc:      	madd	x1, x7, x4, x21
    97e0:      	add	x10, x1, x10
    97e4:      	madd	x7, x10, x4, x22
    97e8:      	add	x19, x19, #0x1
    97ec:      	cmp	x19, x12
    97f0:      	b.eq	0x97a8 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x80>
    97f4:      	orr	x21, x17, x19, lsl #1
    97f8:      	cbz	x2, 0x9880 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x158>
    97fc:      	ldr	x25, [x0, #0x18]
    9800:      	cbz	x25, 0x987c <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x154>
    9804:      	tbz	w3, #0x0, 0x9814 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0xec>
    9808:      	mov	x10, #0x0               ; =0
    980c:      	cbnz	x15, 0x9830 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x108>
    9810:      	b	0x987c <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x154>
    9814:      	eor	x10, x14, x21
    9818:      	eor	x10, x10, x10, lsr #30
    981c:      	mul	x10, x10, x9
    9820:      	eor	x10, x10, x10, lsr #27
    9824:      	mul	x10, x10, x8
    9828:      	eor	x10, x10, x10, lsr #31
    982c:      	cbz	x15, 0x987c <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x154>
    9830:      	udiv	x22, x10, x15
    9834:      	msub	x10, x22, x15, x10
    9838:      	ldr	x23, [x0, #0x10]
    983c:      	add	x26, x23, x10, lsl #3
    9840:      	mov	x30, x25
    9844:      	mov	x28, x26
    9848:      	mov	x27, x25
    984c:      	ldr	x22, [x28]
    9850:      	cmp	x22, x25
    9854:      	b.hs	0x987c <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x154>
    9858:      	ldr	x24, [x0, #0x28]
    985c:      	madd	x10, x22, x5, x24
    9860:      	mov	x28, x10
    9864:      	ldr	x1, [x28], #0x10
    9868:      	cmp	x1, x21
    986c:      	b.eq	0x9894 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x16c>
    9870:      	mov	x27, x22
    9874:      	subs	x30, x30, #0x1
    9878:      	b.ne	0x984c <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x124>
    987c:      	mul	x7, x7, x4
    9880:      	tbz	w3, #0x0, 0x9994 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x26c>
    9884:      	mov	x10, #0x0               ; =0
    9888:      	add	x22, x20, x19
    988c:      	cbnz	x15, 0x99b4 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x28c>
    9890:      	b	0x97d0 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0xa8>
    9894:      	ldr	x28, [x28]
    9898:      	cmp	x27, x25
    989c:      	b.hs	0x98d8 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x1b0>
    98a0:      	madd	x1, x27, x5, x24
    98a4:      	str	x28, [x1, #0x10]
    98a8:      	sub	x27, x25, #0x1
    98ac:      	madd	x25, x27, x5, x24
    98b0:      	str	x27, [x0, #0x18]
    98b4:      	ldp	x28, x30, [x25]
    98b8:      	cmp	x22, x27
    98bc:      	b.lo	0x98f4 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x1cc>
    98c0:      	mov	w10, #0x4309            ; =17161
    98c4:      	madd	x10, x7, x10, x30
    98c8:      	madd	x10, x28, x4, x10
    98cc:      	add	x7, x10, #0x83
    98d0:      	tbnz	w3, #0x0, 0x9884 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x15c>
    98d4:      	b	0x9994 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x26c>
    98d8:      	str	x28, [x26]
    98dc:      	sub	x27, x25, #0x1
    98e0:      	madd	x25, x27, x5, x24
    98e4:      	str	x27, [x0, #0x18]
    98e8:      	ldp	x28, x30, [x25]
    98ec:      	cmp	x22, x27
    98f0:      	b.hs	0x98c0 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x198>
    98f4:      	ldr	x1, [x25, #0x10]
    98f8:      	ldp	x25, x26, [x10]
    98fc:      	stp	x28, x30, [x10]
    9900:      	str	x1, [x10, #0x10]
    9904:      	tbz	w3, #0x0, 0x9950 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x228>
    9908:      	mov	x10, #0x0               ; =0
    990c:      	udiv	x1, x10, x15
    9910:      	msub	x10, x1, x15, x10
    9914:      	ldr	x28, [x23, x10, lsl #3]
    9918:      	cmp	x28, x27
    991c:      	b.eq	0x997c <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x254>
    9920:      	b.hs	0x9980 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x258>
    9924:      	mov	w23, #0x1               ; =1
    9928:      	madd	x10, x28, x5, x24
    992c:      	ldr	x28, [x10, #0x10]!
    9930:      	cmp	x28, x27
    9934:      	b.eq	0x9a64 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x33c>
    9938:      	cmp	x23, x27
    993c:      	b.hs	0x9980 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x258>
    9940:      	add	x23, x23, #0x1
    9944:      	cmp	x28, x27
    9948:      	b.lo	0x9928 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x200>
    994c:      	b	0x9980 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x258>
    9950:      	eor	x10, x28, x14
    9954:      	eor	x10, x10, x10, lsr #30
    9958:      	mul	x10, x10, x9
    995c:      	eor	x10, x10, x10, lsr #27
    9960:      	mul	x10, x10, x8
    9964:      	eor	x10, x10, x10, lsr #31
    9968:      	udiv	x1, x10, x15
    996c:      	msub	x10, x1, x15, x10
    9970:      	ldr	x28, [x23, x10, lsl #3]
    9974:      	cmp	x28, x27
    9978:      	b.ne	0x9920 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x1f8>
    997c:      	str	x22, [x23, x10, lsl #3]
    9980:      	mov	w10, #0x4309            ; =17161
    9984:      	madd	x10, x7, x10, x26
    9988:      	madd	x10, x25, x4, x10
    998c:      	add	x7, x10, #0x83
    9990:      	tbnz	w3, #0x0, 0x9884 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x15c>
    9994:      	eor	x10, x14, x21
    9998:      	eor	x10, x10, x10, lsr #30
    999c:      	mul	x10, x10, x9
    99a0:      	eor	x10, x10, x10, lsr #27
    99a4:      	mul	x10, x10, x8
    99a8:      	eor	x10, x10, x10, lsr #31
    99ac:      	add	x22, x20, x19
    99b0:      	cbz	x15, 0x97d0 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0xa8>
    99b4:      	udiv	x1, x10, x15
    99b8:      	msub	x23, x1, x15, x10
    99bc:      	ldp	x24, x25, [x0, #0x10]
    99c0:      	ldr	x26, [x24, x23, lsl #3]
    99c4:      	cbz	x25, 0x9a04 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x2dc>
    99c8:      	cmp	x26, x25
    99cc:      	b.hs	0x9a04 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x2dc>
    99d0:      	ldr	x27, [x0, #0x28]
    99d4:      	mov	w28, #0x1               ; =1
    99d8:      	mov	x10, x26
    99dc:      	madd	x10, x10, x5, x27
    99e0:      	ldr	x1, [x10]
    99e4:      	cmp	x1, x21
    99e8:      	b.eq	0x9a4c <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x324>
    99ec:      	cmp	x28, x25
    99f0:      	b.hs	0x9a04 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x2dc>
    99f4:      	ldr	x10, [x10, #0x10]
    99f8:      	add	x28, x28, #0x1
    99fc:      	cmp	x10, x25
    9a00:      	b.lo	0x99dc <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x2b4>
    9a04:      	cmp	x25, x16
    9a08:      	b.hs	0x97d0 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0xa8>
    9a0c:      	ldr	x10, [x0, #0x20]
    9a10:      	cmp	x25, x10
    9a14:      	b.hs	0x97d0 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0xa8>
    9a18:      	ldr	x10, [x0, #0x28]
    9a1c:      	madd	x10, x25, x5, x10
    9a20:      	stp	x21, x22, [x10]
    9a24:      	str	x26, [x10, #0x10]
    9a28:      	add	x10, x25, #0x1
    9a2c:      	str	x10, [x0, #0x18]
    9a30:      	str	x25, [x24, x23, lsl #3]
    9a34:      	strb	wzr, [sp, #0xc]
    9a38:      	mul	x7, x7, x4
    9a3c:      	add	x19, x19, #0x1
    9a40:      	cmp	x19, x12
    9a44:      	b.ne	0x97f4 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0xcc>
    9a48:      	b	0x97a8 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x80>
    9a4c:      	ldr	x1, [x10, #0x8]
    9a50:      	str	x22, [x10, #0x8]
    9a54:      	strb	wzr, [sp, #0xc]
    9a58:      	mov	w10, #0x1               ; =1
    9a5c:      	mov	x22, x1
    9a60:      	b	0x97dc <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0xb4>
    9a64:      	str	x22, [x10]
    9a68:      	mov	w10, #0x4309            ; =17161
    9a6c:      	madd	x10, x7, x10, x26
    9a70:      	madd	x10, x25, x4, x10
    9a74:      	add	x7, x10, #0x83
    9a78:      	tbnz	w3, #0x0, 0x9884 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x15c>
    9a7c:      	b	0x9994 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x26c>
    9a80:      	ldr	x10, [sp]
    9a84:      	add	x11, x11, x10
    9a88:      	mov	x7, x20
    9a8c:      	str	x11, [x0, #0x50]
    9a90:      	mov	x20, x7
    9a94:      	eor	x10, x20, x20, lsr #30
    9a98:      	mul	x9, x10, x9
    9a9c:      	eor	x9, x9, x9, lsr #27
    9aa0:      	mul	x8, x9, x8
    9aa4:      	eor	x0, x8, x8, lsr #31
    9aa8:      	ldp	x29, x30, [sp, #0x60]
    9aac:      	ldp	x20, x19, [sp, #0x50]
    9ab0:      	ldp	x22, x21, [sp, #0x40]
    9ab4:      	ldp	x24, x23, [sp, #0x30]
    9ab8:      	ldp	x26, x25, [sp, #0x20]
    9abc:      	ldp	x28, x27, [sp, #0x10]
    9ac0:      	add	sp, sp, #0x70
    9ac4:      	ret

0000000000009ac8 <_wf_chain_mutation_geometry$instance$e194368921a477a7>:
    9ac8:      	ldr	x8, [x0]
    9acc:      	ldr	x9, [x0, #0x18]
    9ad0:      	add	x0, x9, x8, lsl #32
    9ad4:      	ret

0000000000009ad8 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd>:
    9ad8:      	mov	x9, #0xe5b9             ; =58809
    9adc:      	movk	x9, #0x1ce4, lsl #16
    9ae0:      	movk	x9, #0x476d, lsl #32
    9ae4:      	movk	x9, #0xbf58, lsl #48
    9ae8:      	mov	x8, #0x11eb             ; =4587
    9aec:      	movk	x8, #0x1331, lsl #16
    9af0:      	movk	x8, #0x49bb, lsl #32
    9af4:      	movk	x8, #0x94d0, lsl #48
    9af8:      	ldp	x1, x10, [x0, #0x40]
    9afc:      	cbz	x10, 0x9c70 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x198>
    9b00:      	stp	x20, x19, [sp, #-0x10]!
    9b04:      	mov	x11, #0x0               ; =0
    9b08:      	ldr	x12, [x0, #0x30]
    9b0c:      	ldrb	w13, [x0, #0x38]
    9b10:      	mov	w14, #0x83              ; =131
    9b14:      	mov	w15, #0x18              ; =24
    9b18:      	mov	w16, #0x4309            ; =17161
    9b1c:      	ldr	x17, [x0]
    9b20:      	b	0x9b34 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x5c>
    9b24:      	mul	x1, x1, x14
    9b28:      	add	x11, x11, #0x1
    9b2c:      	cmp	x11, x10
    9b30:      	b.eq	0x9c6c <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x194>
    9b34:      	mov	w2, #0x1                ; =1
    9b38:      	bfi	x2, x11, #1, #63
    9b3c:      	tbz	w13, #0x0, 0x9b4c <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x74>
    9b40:      	mov	x4, #0x0                ; =0
    9b44:      	cbnz	x17, 0x9b68 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x90>
    9b48:      	b	0x9bb0 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0xd8>
    9b4c:      	eor	x3, x12, x2
    9b50:      	eor	x3, x3, x3, lsr #30
    9b54:      	mul	x3, x3, x9
    9b58:      	eor	x3, x3, x3, lsr #27
    9b5c:      	mul	x3, x3, x8
    9b60:      	eor	x4, x3, x3, lsr #31
    9b64:      	cbz	x17, 0x9bb0 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0xd8>
    9b68:      	ldr	x3, [x0, #0x18]
    9b6c:      	cbz	x3, 0x9bb0 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0xd8>
    9b70:      	udiv	x5, x4, x17
    9b74:      	msub	x4, x5, x17, x4
    9b78:      	ldr	x5, [x0, #0x10]
    9b7c:      	add	x5, x5, x4, lsl #3
    9b80:      	mov	x4, x3
    9b84:      	ldr	x5, [x5]
    9b88:      	cmp	x5, x3
    9b8c:      	b.hs	0x9bb0 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0xd8>
    9b90:      	ldr	x6, [x0, #0x28]
    9b94:      	madd	x7, x5, x15, x6
    9b98:      	ldr	x19, [x7]
    9b9c:      	cmp	x19, x2
    9ba0:      	b.eq	0x9bcc <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0xf4>
    9ba4:      	add	x5, x7, #0x10
    9ba8:      	subs	x4, x4, #0x1
    9bac:      	b.ne	0x9b84 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0xac>
    9bb0:      	mul	x1, x1, x14
    9bb4:      	lsl	x2, x11, #1
    9bb8:      	add	x2, x2, #0x2
    9bbc:      	tbz	w13, #0x0, 0x9be8 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x110>
    9bc0:      	mov	x4, #0x0                ; =0
    9bc4:      	cbnz	x17, 0x9c04 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x12c>
    9bc8:      	b	0x9b24 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x4c>
    9bcc:      	madd	x2, x5, x15, x6
    9bd0:      	ldr	x2, [x2, #0x8]
    9bd4:      	madd	x1, x1, x16, x2
    9bd8:      	add	x1, x1, #0x83
    9bdc:      	lsl	x2, x11, #1
    9be0:      	add	x2, x2, #0x2
    9be4:      	tbnz	w13, #0x0, 0x9bc0 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0xe8>
    9be8:      	eor	x3, x12, x2
    9bec:      	eor	x3, x3, x3, lsr #30
    9bf0:      	mul	x3, x3, x9
    9bf4:      	eor	x3, x3, x3, lsr #27
    9bf8:      	mul	x3, x3, x8
    9bfc:      	eor	x4, x3, x3, lsr #31
    9c00:      	cbz	x17, 0x9b24 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x4c>
    9c04:      	ldr	x3, [x0, #0x18]
    9c08:      	cbz	x3, 0x9b24 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x4c>
    9c0c:      	udiv	x5, x4, x17
    9c10:      	msub	x4, x5, x17, x4
    9c14:      	ldr	x5, [x0, #0x10]
    9c18:      	add	x5, x5, x4, lsl #3
    9c1c:      	mov	x4, x3
    9c20:      	ldr	x5, [x5]
    9c24:      	cmp	x5, x3
    9c28:      	b.hs	0x9b24 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x4c>
    9c2c:      	ldr	x6, [x0, #0x28]
    9c30:      	madd	x7, x5, x15, x6
    9c34:      	ldr	x19, [x7]
    9c38:      	cmp	x19, x2
    9c3c:      	b.eq	0x9c50 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x178>
    9c40:      	add	x5, x7, #0x10
    9c44:      	subs	x4, x4, #0x1
    9c48:      	b.ne	0x9c20 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x148>
    9c4c:      	b	0x9b24 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x4c>
    9c50:      	madd	x2, x5, x15, x6
    9c54:      	ldr	x2, [x2, #0x8]
    9c58:      	madd	x1, x1, x16, x2
    9c5c:      	add	x1, x1, #0x83
    9c60:      	add	x11, x11, #0x1
    9c64:      	cmp	x11, x10
    9c68:      	b.ne	0x9b34 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x5c>
    9c6c:      	ldp	x20, x19, [sp], #0x10
    9c70:      	eor	x10, x1, x1, lsr #30
    9c74:      	mul	x9, x10, x9
    9c78:      	eor	x9, x9, x9, lsr #27
    9c7c:      	mul	x8, x9, x8
    9c80:      	eor	x0, x8, x8, lsr #31
    9c84:      	ret

0000000000009c88 <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd>:
    9c88:      	stp	x28, x27, [sp, #-0x60]!
    9c8c:      	stp	x26, x25, [sp, #0x10]
    9c90:      	stp	x24, x23, [sp, #0x20]
    9c94:      	stp	x22, x21, [sp, #0x30]
    9c98:      	stp	x20, x19, [sp, #0x40]
    9c9c:      	stp	x29, x30, [sp, #0x50]
    9ca0:      	mov	x8, x0
    9ca4:      	mov	x22, #0xe5b9            ; =58809
    9ca8:      	movk	x22, #0x1ce4, lsl #16
    9cac:      	movk	x22, #0x476d, lsl #32
    9cb0:      	movk	x22, #0xbf58, lsl #48
    9cb4:      	mov	x21, #0x11eb            ; =4587
    9cb8:      	movk	x21, #0x1331, lsl #16
    9cbc:      	movk	x21, #0x49bb, lsl #32
    9cc0:      	movk	x21, #0x94d0, lsl #48
    9cc4:      	ldp	x20, x9, [x0, #0x18]
    9cc8:      	ldr	x0, [x0, #0x28]
    9ccc:      	cbz	x20, 0x9ce8 <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd+0x60>
    9cd0:      	cmp	x20, #0x4
    9cd4:      	b.hs	0x9cf4 <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd+0x6c>
    9cd8:      	mov	x23, #0x0               ; =0
    9cdc:      	mov	x24, #0x0               ; =0
    9ce0:      	mov	x10, x20
    9ce4:      	b	0x9dec <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd+0x164>
    9ce8:      	mov	x23, #0x0               ; =0
    9cec:      	mov	x24, #0x0               ; =0
    9cf0:      	b	0x9e28 <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd+0x1a0>
    9cf4:      	mov	x16, #0x0               ; =0
    9cf8:      	mov	x17, #0x0               ; =0
    9cfc:      	mov	x1, #0x0                ; =0
    9d00:      	mov	x2, #0x0                ; =0
    9d04:      	mov	x12, #0x0               ; =0
    9d08:      	mov	x13, #0x0               ; =0
    9d0c:      	mov	x14, #0x0               ; =0
    9d10:      	mov	x15, #0x0               ; =0
    9d14:      	and	x11, x20, #0xfffffffffffffffc
    9d18:      	and	x10, x20, #0x3
    9d1c:      	mov	w3, #0x18               ; =24
    9d20:      	madd	x3, x20, x3, x0
    9d24:      	sub	x3, x3, #0x30
    9d28:      	mov	w4, #0x83               ; =131
    9d2c:      	mov	x5, x11
    9d30:      	ldp	x6, x7, [x3, #0x18]
    9d34:      	ldp	x19, x23, [x3]
    9d38:      	ldp	x24, x25, [x3, #-0x18]
    9d3c:      	ldp	x26, x27, [x3, #-0x30]
    9d40:      	madd	x6, x6, x4, x7
    9d44:      	madd	x7, x19, x4, x23
    9d48:      	madd	x19, x24, x4, x25
    9d4c:      	madd	x23, x26, x4, x27
    9d50:      	add	x12, x6, x12
    9d54:      	add	x13, x7, x13
    9d58:      	add	x14, x19, x14
    9d5c:      	add	x15, x23, x15
    9d60:      	eor	x6, x6, x6, lsr #30
    9d64:      	eor	x7, x7, x7, lsr #30
    9d68:      	eor	x19, x19, x19, lsr #30
    9d6c:      	eor	x23, x23, x23, lsr #30
    9d70:      	mul	x6, x6, x22
    9d74:      	mul	x7, x7, x22
    9d78:      	mul	x19, x19, x22
    9d7c:      	mul	x23, x23, x22
    9d80:      	eor	x6, x6, x6, lsr #27
    9d84:      	eor	x7, x7, x7, lsr #27
    9d88:      	eor	x19, x19, x19, lsr #27
    9d8c:      	eor	x23, x23, x23, lsr #27
    9d90:      	mul	x6, x6, x21
    9d94:      	mul	x7, x7, x21
    9d98:      	mul	x19, x19, x21
    9d9c:      	eor	x16, x16, x6, lsr #31
    9da0:      	mul	x23, x23, x21
    9da4:      	eor	x17, x17, x7, lsr #31
    9da8:      	eor	x1, x1, x19, lsr #31
    9dac:      	eor	x2, x2, x23, lsr #31
    9db0:      	eor	x16, x16, x6
    9db4:      	eor	x17, x17, x7
    9db8:      	eor	x1, x1, x19
    9dbc:      	eor	x2, x2, x23
    9dc0:      	sub	x3, x3, #0x60
    9dc4:      	sub	x5, x5, #0x4
    9dc8:      	cbnz	x5, 0x9d30 <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd+0xa8>
    9dcc:      	eor	x16, x17, x16
    9dd0:      	eor	x17, x2, x1
    9dd4:      	eor	x23, x17, x16
    9dd8:      	add	x12, x13, x12
    9ddc:      	add	x13, x15, x14
    9de0:      	add	x24, x13, x12
    9de4:      	cmp	x20, x11
    9de8:      	b.eq	0x9e28 <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd+0x1a0>
    9dec:      	mov	w11, #0x18              ; =24
    9df0:      	madd	x11, x10, x11, x0
    9df4:      	sub	x11, x11, #0x18
    9df8:      	mov	w12, #0x83              ; =131
    9dfc:      	ldp	x13, x14, [x11], #-0x18
    9e00:      	madd	x13, x13, x12, x14
    9e04:      	add	x24, x13, x24
    9e08:      	eor	x13, x13, x13, lsr #30
    9e0c:      	mul	x13, x13, x22
    9e10:      	eor	x13, x13, x13, lsr #27
    9e14:      	mul	x13, x13, x21
    9e18:      	eor	x14, x23, x13, lsr #31
    9e1c:      	eor	x23, x14, x13
    9e20:      	sub	x10, x10, #0x1
    9e24:      	cbnz	x10, 0x9dfc <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd+0x174>
    9e28:      	ldp	x26, x19, [x8, #0x8]
    9e2c:      	ldr	x25, [x8, #0x40]
    9e30:      	cbz	x9, 0x9e38 <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd+0x1b0>
    9e34:      	bl	0x9e34 <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd+0x1ac>
		0000000000009e34:  ARM64_RELOC_BRANCH26	_free
    9e38:      	cbz	x26, 0x9e44 <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd+0x1bc>
    9e3c:      	mov	x0, x19
    9e40:      	bl	0x9e40 <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd+0x1b8>
		0000000000009e40:  ARM64_RELOC_BRANCH26	_free
    9e44:      	eor	x8, x25, x25, lsr #30
    9e48:      	mul	x8, x8, x22
    9e4c:      	eor	x8, x8, x8, lsr #27
    9e50:      	mul	x8, x8, x21
    9e54:      	eor	x9, x24, x24, lsr #30
    9e58:      	mul	x9, x9, x22
    9e5c:      	eor	x9, x9, x9, lsr #27
    9e60:      	mul	x9, x9, x21
    9e64:      	eor	x10, x9, x8
    9e68:      	mov	x11, #0x7c15            ; =31765
    9e6c:      	movk	x11, #0x7f4a, lsl #16
    9e70:      	movk	x11, #0x79b9, lsl #32
    9e74:      	movk	x11, #0x9e37, lsl #48
    9e78:      	mul	x11, x20, x11
    9e7c:      	eor	x11, x11, x23
    9e80:      	eor	x10, x11, x10, lsr #31
    9e84:      	eor	x8, x8, x9
    9e88:      	eor	x0, x10, x8
    9e8c:      	ldp	x29, x30, [sp, #0x50]
    9e90:      	ldp	x20, x19, [sp, #0x40]
    9e94:      	ldp	x22, x21, [sp, #0x30]
    9e98:      	ldp	x24, x23, [sp, #0x20]
    9e9c:      	ldp	x26, x25, [sp, #0x10]
    9ea0:      	ldp	x28, x27, [sp], #0x60
    9ea4:      	ret

0000000000009ea8 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027>:
    9ea8:      	stp	x26, x25, [sp, #-0x50]!
    9eac:      	stp	x24, x23, [sp, #0x10]
    9eb0:      	stp	x22, x21, [sp, #0x20]
    9eb4:      	stp	x20, x19, [sp, #0x30]
    9eb8:      	stp	x29, x30, [sp, #0x40]
    9ebc:      	sub	sp, sp, #0x340
    9ec0:      	mov	x21, x3
    9ec4:      	mov	x20, x2
    9ec8:      	mov	x22, x1
    9ecc:      	mov	x19, x0
    9ed0:      	mov	x8, #0x7c15             ; =31765
    9ed4:      	movk	x8, #0x7f4a, lsl #16
    9ed8:      	movk	x8, #0x79b9, lsl #32
    9edc:      	movk	x8, #0x9e37, lsl #48
    9ee0:      	eor	x8, x3, x8
    9ee4:      	str	x8, [sp, #0x120]
    9ee8:      	strb	wzr, [sp, #0x128]
    9eec:      	cbz	x1, 0x9f34 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x8c>
    9ef0:      	lsl	x24, x22, #3
    9ef4:      	mov	x0, x24
    9ef8:      	bl	0x9ef8 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x50>
		0000000000009ef8:  ARM64_RELOC_BRANCH26	_malloc
    9efc:      	cbz	x0, 0xa130 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x288>
    9f00:      	mov	x23, x0
    9f04:      	mov	w1, #0xff               ; =255
    9f08:      	mov	x2, x24
    9f0c:      	bl	0x9f0c <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x64>
		0000000000009f0c:  ARM64_RELOC_BRANCH26	_memset
    9f10:      	add	x8, x22, x22, lsl #4
    9f14:      	lsl	x0, x8, #4
    9f18:      	bl	0x9f18 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x70>
		0000000000009f18:  ARM64_RELOC_BRANCH26	_malloc
    9f1c:      	cbz	x0, 0xa130 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x288>
    9f20:      	stp	x22, x22, [sp, #0xf0]
    9f24:      	stp	x23, xzr, [sp, #0x100]
    9f28:      	stp	x22, x0, [sp, #0x110]
    9f2c:      	cbnz	x20, 0x9f4c <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0xa4>
    9f30:      	b	0xa0fc <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x254>
    9f34:      	adrp	x23, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x368>
		0000000000009f34:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    9f38:      	add	x23, x23, #0x0
		0000000000009f38:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    9f3c:      	stp	x22, x22, [sp, #0xf0]
    9f40:      	stp	x23, xzr, [sp, #0x100]
    9f44:      	stp	x22, x23, [sp, #0x110]
    9f48:      	cbz	x20, 0xa0fc <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x254>
    9f4c:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x368>
		0000000000009f4c:  ARM64_RELOC_PAGE21	lCPI103_0
    9f50:      	ldr	q0, [x8]
		0000000000009f50:  ARM64_RELOC_PAGEOFF12	lCPI103_0
    9f54:      	str	q0, [sp, #0xe0]
    9f58:      	add	x23, sp, #0x240
    9f5c:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x368>
		0000000000009f5c:  ARM64_RELOC_PAGE21	lCPI103_1
    9f60:      	ldr	q0, [x8]
		0000000000009f60:  ARM64_RELOC_PAGEOFF12	lCPI103_1
    9f64:      	str	q0, [sp, #0xd0]
    9f68:      	mov	w22, #0x1               ; =1
    9f6c:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x368>
		0000000000009f6c:  ARM64_RELOC_PAGE21	lCPI103_2
    9f70:      	ldr	q0, [x8]
		0000000000009f70:  ARM64_RELOC_PAGEOFF12	lCPI103_2
    9f74:      	str	q0, [sp, #0xc0]
    9f78:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x368>
		0000000000009f78:  ARM64_RELOC_PAGE21	lCPI103_3
    9f7c:      	ldr	q0, [x8]
		0000000000009f7c:  ARM64_RELOC_PAGEOFF12	lCPI103_3
    9f80:      	str	q0, [sp, #0xb0]
    9f84:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x368>
		0000000000009f84:  ARM64_RELOC_PAGE21	lCPI103_4
    9f88:      	ldr	q0, [x8]
		0000000000009f88:  ARM64_RELOC_PAGEOFF12	lCPI103_4
    9f8c:      	str	q0, [sp, #0xa0]
    9f90:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x368>
		0000000000009f90:  ARM64_RELOC_PAGE21	lCPI103_5
    9f94:      	ldr	q0, [x8]
		0000000000009f94:  ARM64_RELOC_PAGEOFF12	lCPI103_5
    9f98:      	str	q0, [sp, #0x90]
    9f9c:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x368>
		0000000000009f9c:  ARM64_RELOC_PAGE21	lCPI103_6
    9fa0:      	ldr	q0, [x8]
		0000000000009fa0:  ARM64_RELOC_PAGEOFF12	lCPI103_6
    9fa4:      	str	q0, [sp, #0x80]
    9fa8:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x368>
		0000000000009fa8:  ARM64_RELOC_PAGE21	lCPI103_7
    9fac:      	ldr	q0, [x8]
		0000000000009fac:  ARM64_RELOC_PAGEOFF12	lCPI103_7
    9fb0:      	str	q0, [sp, #0x70]
    9fb4:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x368>
		0000000000009fb4:  ARM64_RELOC_PAGE21	lCPI103_8
    9fb8:      	ldr	q0, [x8]
		0000000000009fb8:  ARM64_RELOC_PAGEOFF12	lCPI103_8
    9fbc:      	str	q0, [sp, #0x60]
    9fc0:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x368>
		0000000000009fc0:  ARM64_RELOC_PAGE21	lCPI103_9
    9fc4:      	ldr	q0, [x8]
		0000000000009fc4:  ARM64_RELOC_PAGEOFF12	lCPI103_9
    9fc8:      	str	q0, [sp, #0x50]
    9fcc:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x368>
		0000000000009fcc:  ARM64_RELOC_PAGE21	lCPI103_10
    9fd0:      	ldr	q0, [x8]
		0000000000009fd0:  ARM64_RELOC_PAGEOFF12	lCPI103_10
    9fd4:      	str	q0, [sp, #0x40]
    9fd8:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x368>
		0000000000009fd8:  ARM64_RELOC_PAGE21	lCPI103_11
    9fdc:      	ldr	q0, [x8]
		0000000000009fdc:  ARM64_RELOC_PAGEOFF12	lCPI103_11
    9fe0:      	str	q0, [sp, #0x30]
    9fe4:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x368>
		0000000000009fe4:  ARM64_RELOC_PAGE21	lCPI103_12
    9fe8:      	ldr	q0, [x8]
		0000000000009fe8:  ARM64_RELOC_PAGEOFF12	lCPI103_12
    9fec:      	str	q0, [sp, #0x20]
    9ff0:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x368>
		0000000000009ff0:  ARM64_RELOC_PAGE21	lCPI103_13
    9ff4:      	ldr	q0, [x8]
		0000000000009ff4:  ARM64_RELOC_PAGEOFF12	lCPI103_13
    9ff8:      	str	q0, [sp, #0x10]
    9ffc:      	mov	x24, x20
    a000:      	adrp	x8, 0xa000 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x158>
		000000000000a000:  ARM64_RELOC_PAGE21	lCPI103_14
    a004:      	ldr	q0, [x8]
		000000000000a004:  ARM64_RELOC_PAGEOFF12	lCPI103_14
    a008:      	str	q0, [sp]
    a00c:      	mov	x25, x21
    a010:      	dup.2d	v0, x25
    a014:      	add	x8, x25, #0x1f
    a018:      	ldr	q1, [sp, #0xe0]
    a01c:      	add.2d	v1, v0, v1
    a020:      	stur	q1, [x23, #0x8]
    a024:      	ldr	q1, [sp, #0xd0]
    a028:      	add.2d	v1, v0, v1
    a02c:      	stur	q1, [x23, #0x18]
    a030:      	ldr	q1, [sp, #0xc0]
    a034:      	add.2d	v1, v0, v1
    a038:      	stur	q1, [x23, #0x28]
    a03c:      	ldr	q1, [sp, #0xb0]
    a040:      	add.2d	v1, v0, v1
    a044:      	stur	q1, [x23, #0x38]
    a048:      	ldr	q1, [sp, #0xa0]
    a04c:      	add.2d	v1, v0, v1
    a050:      	stur	q1, [x23, #0x48]
    a054:      	ldr	q1, [sp, #0x90]
    a058:      	add.2d	v1, v0, v1
    a05c:      	stur	q1, [x23, #0x58]
    a060:      	ldr	q1, [sp, #0x80]
    a064:      	add.2d	v1, v0, v1
    a068:      	stur	q1, [x23, #0x68]
    a06c:      	ldr	q1, [sp, #0x70]
    a070:      	add.2d	v1, v0, v1
    a074:      	stur	q1, [x23, #0x78]
    a078:      	ldr	q1, [sp, #0x60]
    a07c:      	add.2d	v1, v0, v1
    a080:      	stur	q1, [x23, #0x88]
    a084:      	ldr	q1, [sp, #0x50]
    a088:      	add.2d	v1, v0, v1
    a08c:      	stur	q1, [x23, #0x98]
    a090:      	ldr	q1, [sp, #0x40]
    a094:      	add.2d	v1, v0, v1
    a098:      	stur	q1, [x23, #0xa8]
    a09c:      	ldr	q1, [sp, #0x30]
    a0a0:      	add.2d	v1, v0, v1
    a0a4:      	stur	q1, [x23, #0xb8]
    a0a8:      	ldr	q1, [sp, #0x20]
    a0ac:      	add.2d	v1, v0, v1
    a0b0:      	stur	q1, [x23, #0xc8]
    a0b4:      	ldr	q1, [sp, #0x10]
    a0b8:      	add.2d	v1, v0, v1
    a0bc:      	stur	q1, [x23, #0xd8]
    a0c0:      	ldr	q1, [sp]
    a0c4:      	add.2d	v0, v0, v1
    a0c8:      	stur	q0, [x23, #0xe8]
    a0cc:      	str	x25, [sp, #0x240]
    a0d0:      	str	x8, [sp, #0x338]
    a0d4:      	add	x0, sp, #0x130
    a0d8:      	add	x1, sp, #0xf0
    a0dc:      	add	x3, sp, #0x240
    a0e0:      	add	x4, sp, #0x120
    a0e4:      	mov	x2, x22
    a0e8:      	bl	0xa0e8 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x240>
		000000000000a0e8:  ARM64_RELOC_BRANCH26	_wf_full_chain_try_put$instance$58dd6ca826103b6d
    a0ec:      	add	x25, x25, #0x1
    a0f0:      	add	x22, x22, #0x2
    a0f4:      	subs	x24, x24, #0x1
    a0f8:      	b.ne	0xa010 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x168>
    a0fc:      	ldp	q0, q1, [sp, #0xf0]
    a100:      	stp	q0, q1, [x19]
    a104:      	ldp	q0, q1, [sp, #0x110]
    a108:      	stp	q0, q1, [x19, #0x20]
    a10c:      	stp	x21, x20, [x19, #0x40]
    a110:      	str	xzr, [x19, #0x50]
    a114:      	add	sp, sp, #0x340
    a118:      	ldp	x29, x30, [sp, #0x40]
    a11c:      	ldp	x20, x19, [sp, #0x30]
    a120:      	ldp	x22, x21, [sp, #0x20]
    a124:      	ldp	x24, x23, [sp, #0x10]
    a128:      	ldp	x26, x25, [sp], #0x50
    a12c:      	ret
    a130:      	bl	0xa130 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x288>
		000000000000a130:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000a134 <_wf_chain_mutation_batch$instance$4250cb78d3f44027>:
    a134:      	stp	x28, x27, [sp, #-0x60]!
    a138:      	stp	x26, x25, [sp, #0x10]
    a13c:      	stp	x24, x23, [sp, #0x20]
    a140:      	stp	x22, x21, [sp, #0x30]
    a144:      	stp	x20, x19, [sp, #0x40]
    a148:      	stp	x29, x30, [sp, #0x50]
    a14c:      	sub	sp, sp, #0x440
    a150:      	ldr	x23, [x0, #0x40]
    a154:      	str	x1, [sp, #0x10]
    a158:      	cbz	x1, 0xa5bc <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x488>
    a15c:      	mov	x19, x0
    a160:      	ldr	x27, [x0, #0x48]
    a164:      	cbz	x27, 0xa5ac <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x478>
    a168:      	mov	x21, x2
    a16c:      	mov	x24, #0x0               ; =0
    a170:      	ldr	x25, [x19, #0x50]
    a174:      	add	x26, sp, #0x230
    a178:      	adrp	x8, 0xa000 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x158>
		000000000000a178:  ARM64_RELOC_PAGE21	lCPI104_0
    a17c:      	ldr	q0, [x8]
		000000000000a17c:  ARM64_RELOC_PAGEOFF12	lCPI104_0
    a180:      	str	q0, [sp, #0x100]
    a184:      	add	x9, x25, #0x1
    a188:      	adrp	x8, 0xa000 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x158>
		000000000000a188:  ARM64_RELOC_PAGE21	lCPI104_1
    a18c:      	ldr	q0, [x8]
		000000000000a18c:  ARM64_RELOC_PAGEOFF12	lCPI104_1
    a190:      	str	q0, [sp, #0xf0]
    a194:      	adrp	x8, 0xa000 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x158>
		000000000000a194:  ARM64_RELOC_PAGE21	lCPI104_2
    a198:      	ldr	q0, [x8]
		000000000000a198:  ARM64_RELOC_PAGEOFF12	lCPI104_2
    a19c:      	str	q0, [sp, #0xe0]
    a1a0:      	adrp	x8, 0xa000 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x158>
		000000000000a1a0:  ARM64_RELOC_PAGE21	lCPI104_3
    a1a4:      	ldr	q0, [x8]
		000000000000a1a4:  ARM64_RELOC_PAGEOFF12	lCPI104_3
    a1a8:      	str	q0, [sp, #0xd0]
    a1ac:      	adrp	x8, 0xa000 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x158>
		000000000000a1ac:  ARM64_RELOC_PAGE21	lCPI104_4
    a1b0:      	ldr	q0, [x8]
		000000000000a1b0:  ARM64_RELOC_PAGEOFF12	lCPI104_4
    a1b4:      	str	q0, [sp, #0xc0]
    a1b8:      	adrp	x8, 0xa000 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x158>
		000000000000a1b8:  ARM64_RELOC_PAGE21	lCPI104_5
    a1bc:      	ldr	q0, [x8]
		000000000000a1bc:  ARM64_RELOC_PAGEOFF12	lCPI104_5
    a1c0:      	str	q0, [sp, #0xb0]
    a1c4:      	adrp	x8, 0xa000 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x158>
		000000000000a1c4:  ARM64_RELOC_PAGE21	lCPI104_6
    a1c8:      	ldr	q0, [x8]
		000000000000a1c8:  ARM64_RELOC_PAGEOFF12	lCPI104_6
    a1cc:      	str	q0, [sp, #0xa0]
    a1d0:      	adrp	x8, 0xa000 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x158>
		000000000000a1d0:  ARM64_RELOC_PAGE21	lCPI104_7
    a1d4:      	ldr	q0, [x8]
		000000000000a1d4:  ARM64_RELOC_PAGEOFF12	lCPI104_7
    a1d8:      	str	q0, [sp, #0x90]
    a1dc:      	adrp	x8, 0xa000 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x158>
		000000000000a1dc:  ARM64_RELOC_PAGE21	lCPI104_8
    a1e0:      	ldr	q0, [x8]
		000000000000a1e0:  ARM64_RELOC_PAGEOFF12	lCPI104_8
    a1e4:      	str	q0, [sp, #0x80]
    a1e8:      	adrp	x8, 0xa000 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x158>
		000000000000a1e8:  ARM64_RELOC_PAGE21	lCPI104_9
    a1ec:      	ldr	q0, [x8]
		000000000000a1ec:  ARM64_RELOC_PAGEOFF12	lCPI104_9
    a1f0:      	str	q0, [sp, #0x70]
    a1f4:      	adrp	x8, 0xa000 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x158>
		000000000000a1f4:  ARM64_RELOC_PAGE21	lCPI104_10
    a1f8:      	ldr	q0, [x8]
		000000000000a1f8:  ARM64_RELOC_PAGEOFF12	lCPI104_10
    a1fc:      	str	q0, [sp, #0x60]
    a200:      	adrp	x8, 0xa000 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x158>
		000000000000a200:  ARM64_RELOC_PAGE21	lCPI104_11
    a204:      	ldr	q0, [x8]
		000000000000a204:  ARM64_RELOC_PAGEOFF12	lCPI104_11
    a208:      	str	q0, [sp, #0x50]
    a20c:      	adrp	x8, 0xa000 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x158>
		000000000000a20c:  ARM64_RELOC_PAGE21	lCPI104_12
    a210:      	ldr	q0, [x8]
		000000000000a210:  ARM64_RELOC_PAGEOFF12	lCPI104_12
    a214:      	str	q0, [sp, #0x40]
    a218:      	adrp	x8, 0xa000 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x158>
		000000000000a218:  ARM64_RELOC_PAGE21	lCPI104_13
    a21c:      	ldr	q0, [x8]
		000000000000a21c:  ARM64_RELOC_PAGEOFF12	lCPI104_13
    a220:      	str	q0, [sp, #0x30]
    a224:      	mov	w28, #0x83              ; =131
    a228:      	adrp	x8, 0xa000 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x158>
		000000000000a228:  ARM64_RELOC_PAGE21	lCPI104_14
    a22c:      	ldr	q0, [x8]
		000000000000a22c:  ARM64_RELOC_PAGEOFF12	lCPI104_14
    a230:      	str	q0, [sp, #0x20]
    a234:      	str	x9, [sp, #0x18]
    a238:      	cbz	x27, 0xa57c <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x448>
    a23c:      	ldr	x8, [x19, #0x40]
    a240:      	madd	x20, x27, x9, x8
    a244:      	mov	w22, #0x1               ; =1
    a248:      	b	0xa440 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x30c>
    a24c:      	mul	x23, x23, x28
    a250:      	dup.2d	v0, x20
    a254:      	add	x8, x20, #0x1f
    a258:      	ldr	q1, [sp, #0x100]
    a25c:      	add.2d	v1, v0, v1
    a260:      	stur	q1, [x26, #0x8]
    a264:      	ldr	q1, [sp, #0xf0]
    a268:      	add.2d	v1, v0, v1
    a26c:      	stur	q1, [x26, #0x18]
    a270:      	ldr	q1, [sp, #0xe0]
    a274:      	add.2d	v1, v0, v1
    a278:      	stur	q1, [x26, #0x28]
    a27c:      	ldr	q1, [sp, #0xd0]
    a280:      	add.2d	v1, v0, v1
    a284:      	stur	q1, [x26, #0x38]
    a288:      	ldr	q1, [sp, #0xc0]
    a28c:      	add.2d	v1, v0, v1
    a290:      	stur	q1, [x26, #0x48]
    a294:      	ldr	q1, [sp, #0xb0]
    a298:      	add.2d	v1, v0, v1
    a29c:      	stur	q1, [x26, #0x58]
    a2a0:      	ldr	q1, [sp, #0xa0]
    a2a4:      	add.2d	v1, v0, v1
    a2a8:      	stur	q1, [x26, #0x68]
    a2ac:      	ldr	q1, [sp, #0x90]
    a2b0:      	add.2d	v1, v0, v1
    a2b4:      	stur	q1, [x26, #0x78]
    a2b8:      	ldr	q1, [sp, #0x80]
    a2bc:      	add.2d	v1, v0, v1
    a2c0:      	stur	q1, [x26, #0x88]
    a2c4:      	ldr	q1, [sp, #0x70]
    a2c8:      	add.2d	v1, v0, v1
    a2cc:      	stur	q1, [x26, #0x98]
    a2d0:      	ldr	q1, [sp, #0x60]
    a2d4:      	add.2d	v1, v0, v1
    a2d8:      	stur	q1, [x26, #0xa8]
    a2dc:      	ldr	q1, [sp, #0x50]
    a2e0:      	add.2d	v1, v0, v1
    a2e4:      	stur	q1, [x26, #0xb8]
    a2e8:      	ldr	q1, [sp, #0x40]
    a2ec:      	add.2d	v1, v0, v1
    a2f0:      	stur	q1, [x26, #0xc8]
    a2f4:      	ldr	q1, [sp, #0x30]
    a2f8:      	add.2d	v1, v0, v1
    a2fc:      	stur	q1, [x26, #0xd8]
    a300:      	ldr	q1, [sp, #0x20]
    a304:      	add.2d	v0, v0, v1
    a308:      	stur	q0, [x26, #0xe8]
    a30c:      	str	x20, [sp, #0x230]
    a310:      	str	x8, [sp, #0x328]
    a314:      	add	x0, sp, #0x120
    a318:      	add	x3, sp, #0x230
    a31c:      	add	x4, x19, #0x30
    a320:      	mov	x1, x19
    a324:      	mov	x2, x22
    a328:      	bl	0xa328 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x1f4>
		000000000000a328:  ARM64_RELOC_BRANCH26	_wf_full_chain_try_put$instance$58dd6ca826103b6d
    a32c:      	ldr	w8, [sp, #0x120]
    a330:      	cbz	w8, 0xa42c <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x2f8>
    a334:      	ldrb	w8, [sp, #0x124]
    a338:      	tst	w8, #0x1
    a33c:      	ldp	x9, x8, [sp, #0x128]
    a340:      	madd	x8, x9, x28, x8
    a344:      	ldp	x10, x9, [sp, #0x138]
    a348:      	madd	x8, x8, x28, x10
    a34c:      	madd	x8, x8, x28, x9
    a350:      	ldp	x10, x9, [sp, #0x148]
    a354:      	madd	x8, x8, x28, x10
    a358:      	madd	x8, x8, x28, x9
    a35c:      	ldp	x10, x9, [sp, #0x158]
    a360:      	madd	x8, x8, x28, x10
    a364:      	madd	x8, x8, x28, x9
    a368:      	ldp	x10, x9, [sp, #0x168]
    a36c:      	madd	x8, x8, x28, x10
    a370:      	madd	x8, x8, x28, x9
    a374:      	ldp	x10, x9, [sp, #0x178]
    a378:      	madd	x8, x8, x28, x10
    a37c:      	madd	x8, x8, x28, x9
    a380:      	ldp	x10, x9, [sp, #0x188]
    a384:      	madd	x8, x8, x28, x10
    a388:      	madd	x8, x8, x28, x9
    a38c:      	ldp	x10, x9, [sp, #0x198]
    a390:      	madd	x8, x8, x28, x10
    a394:      	madd	x8, x8, x28, x9
    a398:      	ldp	x10, x9, [sp, #0x1a8]
    a39c:      	madd	x8, x8, x28, x10
    a3a0:      	madd	x8, x8, x28, x9
    a3a4:      	ldp	x10, x9, [sp, #0x1b8]
    a3a8:      	madd	x8, x8, x28, x10
    a3ac:      	madd	x8, x8, x28, x9
    a3b0:      	ldp	x10, x9, [sp, #0x1c8]
    a3b4:      	madd	x8, x8, x28, x10
    a3b8:      	madd	x8, x8, x28, x9
    a3bc:      	ldp	x10, x9, [sp, #0x1d8]
    a3c0:      	madd	x8, x8, x28, x10
    a3c4:      	madd	x8, x8, x28, x9
    a3c8:      	ldp	x10, x9, [sp, #0x1e8]
    a3cc:      	madd	x8, x8, x28, x10
    a3d0:      	madd	x8, x8, x28, x9
    a3d4:      	ldp	x10, x9, [sp, #0x1f8]
    a3d8:      	madd	x8, x8, x28, x10
    a3dc:      	madd	x8, x8, x28, x9
    a3e0:      	ldr	x9, [sp, #0x208]
    a3e4:      	madd	x8, x8, x28, x9
    a3e8:      	ldr	x9, [sp, #0x210]
    a3ec:      	madd	x8, x8, x28, x9
    a3f0:      	ldr	x9, [sp, #0x218]
    a3f4:      	add	x9, x9, x23
    a3f8:      	ldr	x10, [sp, #0x220]
    a3fc:      	madd	x8, x8, x28, x9
    a400:      	mov	w9, #0x1                ; =1
    a404:      	cinc	x9, x9, ne
    a408:      	add	x9, x9, x10
    a40c:      	madd	x8, x8, x28, x9
    a410:      	ldr	x9, [sp, #0x228]
    a414:      	madd	x23, x8, x28, x9
    a418:      	add	x20, x20, #0x1
    a41c:      	add	x22, x22, #0x2
    a420:      	subs	x27, x27, #0x1
    a424:      	b.ne	0xa440 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x30c>
    a428:      	b	0xa57c <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x448>
    a42c:      	mul	x23, x23, x28
    a430:      	add	x20, x20, #0x1
    a434:      	add	x22, x22, #0x2
    a438:      	subs	x27, x27, #0x1
    a43c:      	b.eq	0xa57c <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x448>
    a440:      	str	x22, [sp, #0x118]
    a444:      	cbz	x21, 0xa250 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x11c>
    a448:      	add	x0, sp, #0x330
    a44c:      	add	x2, sp, #0x118
    a450:      	add	x3, x19, #0x30
    a454:      	mov	x1, x19
    a458:      	bl	0xa458 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x324>
		000000000000a458:  ARM64_RELOC_BRANCH26	_wf_full_chain_remove$instance$58dd6ca826103b6d
    a45c:      	ldr	w8, [sp, #0x330]
    a460:      	cmp	w8, #0x1
    a464:      	b.ne	0xa24c <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x118>
    a468:      	ldr	x8, [sp, #0x338]
    a46c:      	ldr	x9, [sp, #0x340]
    a470:      	madd	x8, x8, x28, x9
    a474:      	ldr	x9, [sp, #0x348]
    a478:      	ldr	x10, [sp, #0x350]
    a47c:      	madd	x8, x8, x28, x9
    a480:      	madd	x8, x8, x28, x10
    a484:      	ldr	x9, [sp, #0x358]
    a488:      	ldr	x10, [sp, #0x360]
    a48c:      	madd	x8, x8, x28, x9
    a490:      	madd	x8, x8, x28, x10
    a494:      	ldr	x9, [sp, #0x368]
    a498:      	ldr	x10, [sp, #0x370]
    a49c:      	madd	x8, x8, x28, x9
    a4a0:      	madd	x8, x8, x28, x10
    a4a4:      	ldr	x9, [sp, #0x378]
    a4a8:      	ldr	x10, [sp, #0x380]
    a4ac:      	madd	x8, x8, x28, x9
    a4b0:      	madd	x8, x8, x28, x10
    a4b4:      	ldr	x9, [sp, #0x388]
    a4b8:      	ldr	x10, [sp, #0x390]
    a4bc:      	madd	x8, x8, x28, x9
    a4c0:      	madd	x8, x8, x28, x10
    a4c4:      	ldr	x9, [sp, #0x398]
    a4c8:      	ldr	x10, [sp, #0x3a0]
    a4cc:      	madd	x8, x8, x28, x9
    a4d0:      	madd	x8, x8, x28, x10
    a4d4:      	ldr	x9, [sp, #0x3a8]
    a4d8:      	ldr	x10, [sp, #0x3b0]
    a4dc:      	madd	x8, x8, x28, x9
    a4e0:      	madd	x8, x8, x28, x10
    a4e4:      	ldr	x9, [sp, #0x3b8]
    a4e8:      	ldr	x10, [sp, #0x3c0]
    a4ec:      	madd	x8, x8, x28, x9
    a4f0:      	madd	x8, x8, x28, x10
    a4f4:      	ldr	x9, [sp, #0x3c8]
    a4f8:      	ldr	x10, [sp, #0x3d0]
    a4fc:      	madd	x8, x8, x28, x9
    a500:      	madd	x8, x8, x28, x10
    a504:      	ldr	x9, [sp, #0x3d8]
    a508:      	ldr	x10, [sp, #0x3e0]
    a50c:      	madd	x8, x8, x28, x9
    a510:      	madd	x8, x8, x28, x10
    a514:      	ldr	x9, [sp, #0x3e8]
    a518:      	ldr	x10, [sp, #0x3f0]
    a51c:      	madd	x8, x8, x28, x9
    a520:      	madd	x8, x8, x28, x10
    a524:      	ldr	x9, [sp, #0x3f8]
    a528:      	ldr	x10, [sp, #0x400]
    a52c:      	madd	x8, x8, x28, x9
    a530:      	madd	x8, x8, x28, x10
    a534:      	ldr	x9, [sp, #0x408]
    a538:      	ldr	x10, [sp, #0x410]
    a53c:      	madd	x8, x8, x28, x9
    a540:      	madd	x8, x8, x28, x10
    a544:      	ldr	x9, [sp, #0x418]
    a548:      	ldr	x10, [sp, #0x420]
    a54c:      	madd	x8, x8, x28, x9
    a550:      	madd	x8, x8, x28, x10
    a554:      	ldr	x9, [sp, #0x428]
    a558:      	ldr	x10, [sp, #0x430]
    a55c:      	madd	x8, x8, x28, x9
    a560:      	madd	x8, x8, x28, x10
    a564:      	ldr	x9, [sp, #0x438]
    a568:      	mov	w10, #0x4309            ; =17161
    a56c:      	madd	x9, x23, x10, x9
    a570:      	madd	x8, x8, x28, x9
    a574:      	add	x23, x8, #0x83
    a578:      	b	0xa250 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x11c>
    a57c:      	add	x25, x25, #0x1
    a580:      	str	x25, [x19, #0x50]
    a584:      	add	x24, x24, #0x1
    a588:      	ldr	x8, [sp, #0x10]
    a58c:      	cmp	x24, x8
    a590:      	b.eq	0xa5bc <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x488>
    a594:      	ldr	x27, [x19, #0x48]
    a598:      	ldr	x9, [sp, #0x18]
    a59c:      	add	x9, x9, #0x1
    a5a0:      	str	x9, [sp, #0x18]
    a5a4:      	cbnz	x27, 0xa23c <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x108>
    a5a8:      	b	0xa57c <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x448>
    a5ac:      	ldr	x8, [x19, #0x50]
    a5b0:      	ldr	x9, [sp, #0x10]
    a5b4:      	add	x8, x8, x9
    a5b8:      	str	x8, [x19, #0x50]
    a5bc:      	eor	x8, x23, x23, lsr #30
    a5c0:      	mov	x9, #0xe5b9             ; =58809
    a5c4:      	movk	x9, #0x1ce4, lsl #16
    a5c8:      	movk	x9, #0x476d, lsl #32
    a5cc:      	movk	x9, #0xbf58, lsl #48
    a5d0:      	mul	x8, x8, x9
    a5d4:      	eor	x8, x8, x8, lsr #27
    a5d8:      	mov	x9, #0x11eb             ; =4587
    a5dc:      	movk	x9, #0x1331, lsl #16
    a5e0:      	movk	x9, #0x49bb, lsl #32
    a5e4:      	movk	x9, #0x94d0, lsl #48
    a5e8:      	mul	x8, x8, x9
    a5ec:      	eor	x0, x8, x8, lsr #31
    a5f0:      	add	sp, sp, #0x440
    a5f4:      	ldp	x29, x30, [sp, #0x50]
    a5f8:      	ldp	x20, x19, [sp, #0x40]
    a5fc:      	ldp	x22, x21, [sp, #0x30]
    a600:      	ldp	x24, x23, [sp, #0x20]
    a604:      	ldp	x26, x25, [sp, #0x10]
    a608:      	ldp	x28, x27, [sp], #0x60
    a60c:      	ret

000000000000a610 <_wf_chain_mutation_geometry$instance$9fed7d4c5d7cc122>:
    a610:      	ldr	x8, [x0]
    a614:      	ldr	x9, [x0, #0x18]
    a618:      	add	x0, x9, x8, lsl #32
    a61c:      	ret

000000000000a620 <_wf_chain_mutation_verify$instance$4250cb78d3f44027>:
    a620:      	mov	x9, #0xe5b9             ; =58809
    a624:      	movk	x9, #0x1ce4, lsl #16
    a628:      	movk	x9, #0x476d, lsl #32
    a62c:      	movk	x9, #0xbf58, lsl #48
    a630:      	mov	x8, #0x11eb             ; =4587
    a634:      	movk	x8, #0x1331, lsl #16
    a638:      	movk	x8, #0x49bb, lsl #32
    a63c:      	movk	x8, #0x94d0, lsl #48
    a640:      	ldp	x1, x10, [x0, #0x40]
    a644:      	cbz	x10, 0xa7b8 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x198>
    a648:      	stp	x20, x19, [sp, #-0x10]!
    a64c:      	mov	x11, #0x0               ; =0
    a650:      	ldr	x12, [x0, #0x30]
    a654:      	ldrb	w13, [x0, #0x38]
    a658:      	mov	w14, #0x83              ; =131
    a65c:      	mov	w15, #0x110             ; =272
    a660:      	mov	w16, #0x4309            ; =17161
    a664:      	ldr	x17, [x0]
    a668:      	b	0xa67c <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x5c>
    a66c:      	mul	x1, x1, x14
    a670:      	add	x11, x11, #0x1
    a674:      	cmp	x11, x10
    a678:      	b.eq	0xa7b4 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x194>
    a67c:      	mov	w2, #0x1                ; =1
    a680:      	bfi	x2, x11, #1, #63
    a684:      	tbz	w13, #0x0, 0xa694 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x74>
    a688:      	mov	x4, #0x0                ; =0
    a68c:      	cbnz	x17, 0xa6b0 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x90>
    a690:      	b	0xa6f8 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0xd8>
    a694:      	eor	x3, x12, x2
    a698:      	eor	x3, x3, x3, lsr #30
    a69c:      	mul	x3, x3, x9
    a6a0:      	eor	x3, x3, x3, lsr #27
    a6a4:      	mul	x3, x3, x8
    a6a8:      	eor	x4, x3, x3, lsr #31
    a6ac:      	cbz	x17, 0xa6f8 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0xd8>
    a6b0:      	ldr	x3, [x0, #0x18]
    a6b4:      	cbz	x3, 0xa6f8 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0xd8>
    a6b8:      	udiv	x5, x4, x17
    a6bc:      	msub	x4, x5, x17, x4
    a6c0:      	ldr	x5, [x0, #0x10]
    a6c4:      	add	x5, x5, x4, lsl #3
    a6c8:      	mov	x4, x3
    a6cc:      	ldr	x5, [x5]
    a6d0:      	cmp	x5, x3
    a6d4:      	b.hs	0xa6f8 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0xd8>
    a6d8:      	ldr	x6, [x0, #0x28]
    a6dc:      	madd	x7, x5, x15, x6
    a6e0:      	ldr	x19, [x7]
    a6e4:      	cmp	x19, x2
    a6e8:      	b.eq	0xa714 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0xf4>
    a6ec:      	add	x5, x7, #0x108
    a6f0:      	subs	x4, x4, #0x1
    a6f4:      	b.ne	0xa6cc <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0xac>
    a6f8:      	mul	x1, x1, x14
    a6fc:      	lsl	x2, x11, #1
    a700:      	add	x2, x2, #0x2
    a704:      	tbz	w13, #0x0, 0xa730 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x110>
    a708:      	mov	x4, #0x0                ; =0
    a70c:      	cbnz	x17, 0xa74c <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x12c>
    a710:      	b	0xa66c <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x4c>
    a714:      	madd	x2, x5, x15, x6
    a718:      	ldr	x2, [x2, #0x8]
    a71c:      	madd	x1, x1, x16, x2
    a720:      	add	x1, x1, #0x83
    a724:      	lsl	x2, x11, #1
    a728:      	add	x2, x2, #0x2
    a72c:      	tbnz	w13, #0x0, 0xa708 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0xe8>
    a730:      	eor	x3, x12, x2
    a734:      	eor	x3, x3, x3, lsr #30
    a738:      	mul	x3, x3, x9
    a73c:      	eor	x3, x3, x3, lsr #27
    a740:      	mul	x3, x3, x8
    a744:      	eor	x4, x3, x3, lsr #31
    a748:      	cbz	x17, 0xa66c <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x4c>
    a74c:      	ldr	x3, [x0, #0x18]
    a750:      	cbz	x3, 0xa66c <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x4c>
    a754:      	udiv	x5, x4, x17
    a758:      	msub	x4, x5, x17, x4
    a75c:      	ldr	x5, [x0, #0x10]
    a760:      	add	x5, x5, x4, lsl #3
    a764:      	mov	x4, x3
    a768:      	ldr	x5, [x5]
    a76c:      	cmp	x5, x3
    a770:      	b.hs	0xa66c <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x4c>
    a774:      	ldr	x6, [x0, #0x28]
    a778:      	madd	x7, x5, x15, x6
    a77c:      	ldr	x19, [x7]
    a780:      	cmp	x19, x2
    a784:      	b.eq	0xa798 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x178>
    a788:      	add	x5, x7, #0x108
    a78c:      	subs	x4, x4, #0x1
    a790:      	b.ne	0xa768 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x148>
    a794:      	b	0xa66c <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x4c>
    a798:      	madd	x2, x5, x15, x6
    a79c:      	ldr	x2, [x2, #0x8]
    a7a0:      	madd	x1, x1, x16, x2
    a7a4:      	add	x1, x1, #0x83
    a7a8:      	add	x11, x11, #0x1
    a7ac:      	cmp	x11, x10
    a7b0:      	b.ne	0xa67c <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x5c>
    a7b4:      	ldp	x20, x19, [sp], #0x10
    a7b8:      	eor	x10, x1, x1, lsr #30
    a7bc:      	mul	x9, x10, x9
    a7c0:      	eor	x9, x9, x9, lsr #27
    a7c4:      	mul	x8, x9, x8
    a7c8:      	eor	x0, x8, x8, lsr #31
    a7cc:      	ret

000000000000a7d0 <_wf_chain_mutation_finish$instance$4250cb78d3f44027>:
    a7d0:      	sub	sp, sp, #0x60
    a7d4:      	stp	x29, x30, [sp, #0x50]
    a7d8:      	ldr	x8, [x0, #0x40]
    a7dc:      	ldp	q0, q1, [x0]
    a7e0:      	stp	q0, q1, [sp, #0x20]
    a7e4:      	ldr	q0, [x0, #0x20]
    a7e8:      	str	q0, [sp, #0x40]
    a7ec:      	stp	x8, xzr, [sp]
    a7f0:      	stp	xzr, xzr, [sp, #0x10]
    a7f4:      	add	x0, sp, #0x20
    a7f8:      	mov	x1, sp
    a7fc:      	bl	0xa7fc <_wf_chain_mutation_finish$instance$4250cb78d3f44027+0x2c>
		000000000000a7fc:  ARM64_RELOC_BRANCH26	_wf_full_chain_free$instance$e1a21e22af512733
    a800:      	ldp	x8, x9, [sp]
    a804:      	ldp	x10, x11, [sp, #0x10]
    a808:      	eor	x8, x8, x8, lsr #30
    a80c:      	mov	x12, #0xe5b9            ; =58809
    a810:      	movk	x12, #0x1ce4, lsl #16
    a814:      	movk	x12, #0x476d, lsl #32
    a818:      	movk	x12, #0xbf58, lsl #48
    a81c:      	mul	x8, x8, x12
    a820:      	eor	x8, x8, x8, lsr #27
    a824:      	mov	x13, #0x11eb            ; =4587
    a828:      	movk	x13, #0x1331, lsl #16
    a82c:      	movk	x13, #0x49bb, lsl #32
    a830:      	movk	x13, #0x94d0, lsl #48
    a834:      	mul	x8, x8, x13
    a838:      	eor	x9, x9, x9, lsr #30
    a83c:      	mul	x9, x9, x12
    a840:      	eor	x9, x9, x9, lsr #27
    a844:      	mul	x9, x9, x13
    a848:      	eor	x12, x9, x8
    a84c:      	mov	x13, #0x7c15            ; =31765
    a850:      	movk	x13, #0x7f4a, lsl #16
    a854:      	movk	x13, #0x79b9, lsl #32
    a858:      	movk	x13, #0x9e37, lsl #48
    a85c:      	mul	x11, x11, x13
    a860:      	eor	x10, x10, x11
    a864:      	eor	x10, x10, x12, lsr #31
    a868:      	eor	x8, x8, x9
    a86c:      	eor	x0, x10, x8
    a870:      	ldp	x29, x30, [sp, #0x50]
    a874:      	add	sp, sp, #0x60
    a878:      	ret

000000000000a87c <_wf_std.collections.hash_map.hash_map_new$instance$a62a753cf2b0b5ca>:
    a87c:      	stp	x20, x19, [sp, #-0x20]!
    a880:      	stp	x29, x30, [sp, #0x10]
    a884:      	mov	x20, x1
    a888:      	mov	x19, x0
    a88c:      	cbz	x1, 0xa8d4 <_wf_std.collections.hash_map.hash_map_new$instance$a62a753cf2b0b5ca+0x58>
    a890:      	add	x8, x20, x20, lsl #1
    a894:      	lsl	x0, x8, #3
    a898:      	bl	0xa898 <_wf_std.collections.hash_map.hash_map_new$instance$a62a753cf2b0b5ca+0x1c>
		000000000000a898:  ARM64_RELOC_BRANCH26	_malloc
    a89c:      	cbz	x0, 0xa8f4 <_wf_std.collections.hash_map.hash_map_new$instance$a62a753cf2b0b5ca+0x78>
    a8a0:      	mov	x8, #0x0                ; =0
    a8a4:      	add	x9, x0, #0x8
    a8a8:      	stur	wzr, [x9, #-0x8]
    a8ac:      	add	x8, x8, #0x1
    a8b0:      	stp	xzr, xzr, [x9], #0x18
    a8b4:      	cmp	x20, x8
    a8b8:      	b.ne	0xa8a8 <_wf_std.collections.hash_map.hash_map_new$instance$a62a753cf2b0b5ca+0x2c>
    a8bc:      	stp	x20, x20, [x19]
    a8c0:      	stp	xzr, xzr, [x19, #0x18]
    a8c4:      	str	x0, [x19, #0x10]
    a8c8:      	ldp	x29, x30, [sp, #0x10]
    a8cc:      	ldp	x20, x19, [sp], #0x20
    a8d0:      	ret
    a8d4:      	adrp	x0, 0xa000 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x158>
		000000000000a8d4:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    a8d8:      	add	x0, x0, #0x0
		000000000000a8d8:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    a8dc:      	stp	x20, x20, [x19]
    a8e0:      	stp	xzr, xzr, [x19, #0x18]
    a8e4:      	str	x0, [x19, #0x10]
    a8e8:      	ldp	x29, x30, [sp, #0x10]
    a8ec:      	ldp	x20, x19, [sp], #0x20
    a8f0:      	ret
    a8f4:      	bl	0xa8f4 <_wf_std.collections.hash_map.hash_map_new$instance$a62a753cf2b0b5ca+0x78>
		000000000000a8f4:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000a8f8 <_wf_std.collections.hash_map.hash_map_put$instance$c7b22b9ef52855b6>:
    a8f8:      	ldr	x8, [x1]
    a8fc:      	ldp	x9, x10, [x1, #0x18]
    a900:      	adds	x10, x9, x10
    a904:      	csinv	x10, x10, xzr, lo
    a908:      	sub	x11, x8, x8, lsr #2
    a90c:      	cmp	x8, #0x2
    a910:      	ccmp	x10, x11, #0x0, ls
    a914:      	b.lo	0xa990 <_wf_std.collections.hash_map.hash_map_put$instance$c7b22b9ef52855b6+0x98>
    a918:      	stp	x24, x23, [sp, #-0x40]!
    a91c:      	stp	x22, x21, [sp, #0x10]
    a920:      	stp	x20, x19, [sp, #0x20]
    a924:      	stp	x29, x30, [sp, #0x30]
    a928:      	mov	w10, #0x1               ; =1
    a92c:      	cmp	x8, #0x1
    a930:      	mov	w11, #0x2               ; =2
    a934:      	cinc	x11, x11, ne
    a938:      	cmp	x8, #0x0
    a93c:      	csel	x10, x10, x11, eq
    a940:      	cmp	x9, x8, lsr #1
    a944:      	csel	x8, x10, x8, hs
    a948:      	mov	x19, x0
    a94c:      	mov	x0, x1
    a950:      	mov	x20, x1
    a954:      	mov	x1, x8
    a958:      	mov	x21, x2
    a95c:      	mov	x2, x4
    a960:      	mov	x22, x4
    a964:      	mov	x23, x3
    a968:      	bl	0xa968 <_wf_std.collections.hash_map.hash_map_put$instance$c7b22b9ef52855b6+0x70>
		000000000000a968:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6
    a96c:      	mov	x0, x19
    a970:      	mov	x1, x20
    a974:      	mov	x2, x21
    a978:      	mov	x3, x23
    a97c:      	mov	x4, x22
    a980:      	ldp	x29, x30, [sp, #0x30]
    a984:      	ldp	x20, x19, [sp, #0x20]
    a988:      	ldp	x22, x21, [sp, #0x10]
    a98c:      	ldp	x24, x23, [sp], #0x40
    a990:      	b	0xa990 <_wf_std.collections.hash_map.hash_map_put$instance$c7b22b9ef52855b6+0x98>
		000000000000a990:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6

000000000000a994 <_wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd>:
    a994:      	ldr	w8, [x0]
    a998:      	cbz	w8, 0xa9d0 <_wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd+0x3c>
    a99c:      	ldp	x9, x8, [x0, #0x8]
    a9a0:      	ldrb	w10, [x0, #0x4]
    a9a4:      	ldr	x11, [x1]
    a9a8:      	mov	w12, #0x83              ; =131
    a9ac:      	tst	w10, #0x1
    a9b0:      	mov	w10, #0x1               ; =1
    a9b4:      	cinc	x10, x10, ne
    a9b8:      	madd	x10, x11, x12, x10
    a9bc:      	add	x9, x10, x9
    a9c0:      	madd	x8, x9, x12, x8
    a9c4:      	str	x8, [x1]
    a9c8:      	mov	w0, #0x0                ; =0
    a9cc:      	ret
    a9d0:      	ldr	x8, [x1]
    a9d4:      	mov	w9, #0x83               ; =131
    a9d8:      	mul	x8, x8, x9
    a9dc:      	str	x8, [x1]
    a9e0:      	mov	w0, #0x0                ; =0
    a9e4:      	ret

000000000000a9e8 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760>:
    a9e8:      	stp	x29, x30, [sp, #-0x10]!
    a9ec:      	ldp	x15, x8, [x0]
    a9f0:      	ldr	x0, [x0, #0x10]
    a9f4:      	cbz	x15, 0xaa9c <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0xb4>
    a9f8:      	mov	x9, #0xe5b9             ; =58809
    a9fc:      	movk	x9, #0x1ce4, lsl #16
    aa00:      	movk	x9, #0x476d, lsl #32
    aa04:      	movk	x9, #0xbf58, lsl #48
    aa08:      	mov	x10, #0x11eb            ; =4587
    aa0c:      	movk	x10, #0x1331, lsl #16
    aa10:      	movk	x10, #0x49bb, lsl #32
    aa14:      	movk	x10, #0x94d0, lsl #48
    aa18:      	ldp	x11, x13, [x1, #0x8]
    aa1c:      	ldr	x12, [x1, #0x18]
    aa20:      	ands	x16, x15, #0x3
    aa24:      	b.eq	0xaa90 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0xa8>
    aa28:      	mov	w14, #0x18              ; =24
    aa2c:      	madd	x14, x15, x14, x0
    aa30:      	sub	x17, x14, #0x8
    aa34:      	mov	w2, #0x83               ; =131
    aa38:      	mov	x14, x15
    aa3c:      	b	0xaa50 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0x68>
    aa40:      	sub	x17, x17, #0x18
    aa44:      	sub	x14, x14, #0x1
    aa48:      	sub	x16, x16, #0x1
    aa4c:      	cbz	x16, 0xaa94 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0xac>
    aa50:      	ldur	w3, [x17, #-0x10]
    aa54:      	cmp	w3, #0x2
    aa58:      	b.ne	0xaa40 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0x58>
    aa5c:      	ldp	x4, x3, [x17, #-0x8]
    aa60:      	madd	x3, x4, x2, x3
    aa64:      	add	x11, x3, x11
    aa68:      	eor	x3, x3, x3, lsr #30
    aa6c:      	mul	x3, x3, x9
    aa70:      	eor	x3, x3, x3, lsr #27
    aa74:      	mul	x3, x3, x10
    aa78:      	eor	x13, x13, x3, lsr #31
    aa7c:      	eor	x13, x13, x3
    aa80:      	stp	x11, x13, [x1, #0x8]
    aa84:      	add	x12, x12, #0x1
    aa88:      	str	x12, [x1, #0x18]
    aa8c:      	b	0xaa40 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0x58>
    aa90:      	mov	x14, x15
    aa94:      	cmp	x15, #0x4
    aa98:      	b.hs	0xaab0 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0xc8>
    aa9c:      	cbz	x8, 0xaaa4 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0xbc>
    aaa0:      	bl	0xaaa0 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0xb8>
		000000000000aaa0:  ARM64_RELOC_BRANCH26	_free
    aaa4:      	mov	w0, #0x0                ; =0
    aaa8:      	ldp	x29, x30, [sp], #0x10
    aaac:      	ret
    aab0:      	mov	w15, #0x18              ; =24
    aab4:      	madd	x15, x14, x15, x0
    aab8:      	sub	x15, x15, #0x30
    aabc:      	mov	w16, #0x83              ; =131
    aac0:      	b	0xaad0 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0xe8>
    aac4:      	sub	x15, x15, #0x60
    aac8:      	sub	x14, x14, #0x4
    aacc:      	cbz	x14, 0xaa9c <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0xb4>
    aad0:      	ldr	w17, [x15, #0x18]
    aad4:      	cmp	w17, #0x2
    aad8:      	b.eq	0xab04 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0x11c>
    aadc:      	ldr	w17, [x15]
    aae0:      	cmp	w17, #0x2
    aae4:      	b.eq	0xab40 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0x158>
    aae8:      	ldur	w17, [x15, #-0x18]
    aaec:      	cmp	w17, #0x2
    aaf0:      	b.eq	0xab7c <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0x194>
    aaf4:      	ldur	w17, [x15, #-0x30]
    aaf8:      	cmp	w17, #0x2
    aafc:      	b.ne	0xaac4 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0xdc>
    ab00:      	b	0xabb8 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0x1d0>
    ab04:      	ldp	x2, x17, [x15, #0x20]
    ab08:      	madd	x17, x2, x16, x17
    ab0c:      	add	x11, x17, x11
    ab10:      	eor	x17, x17, x17, lsr #30
    ab14:      	mul	x17, x17, x9
    ab18:      	eor	x17, x17, x17, lsr #27
    ab1c:      	mul	x17, x17, x10
    ab20:      	eor	x13, x13, x17, lsr #31
    ab24:      	eor	x13, x13, x17
    ab28:      	stp	x11, x13, [x1, #0x8]
    ab2c:      	add	x12, x12, #0x1
    ab30:      	str	x12, [x1, #0x18]
    ab34:      	ldr	w17, [x15]
    ab38:      	cmp	w17, #0x2
    ab3c:      	b.ne	0xaae8 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0x100>
    ab40:      	ldp	x2, x17, [x15, #0x8]
    ab44:      	madd	x17, x2, x16, x17
    ab48:      	add	x11, x17, x11
    ab4c:      	eor	x17, x17, x17, lsr #30
    ab50:      	mul	x17, x17, x9
    ab54:      	eor	x17, x17, x17, lsr #27
    ab58:      	mul	x17, x17, x10
    ab5c:      	eor	x13, x13, x17, lsr #31
    ab60:      	eor	x13, x13, x17
    ab64:      	stp	x11, x13, [x1, #0x8]
    ab68:      	add	x12, x12, #0x1
    ab6c:      	str	x12, [x1, #0x18]
    ab70:      	ldur	w17, [x15, #-0x18]
    ab74:      	cmp	w17, #0x2
    ab78:      	b.ne	0xaaf4 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0x10c>
    ab7c:      	ldp	x2, x17, [x15, #-0x10]
    ab80:      	madd	x17, x2, x16, x17
    ab84:      	add	x11, x17, x11
    ab88:      	eor	x17, x17, x17, lsr #30
    ab8c:      	mul	x17, x17, x9
    ab90:      	eor	x17, x17, x17, lsr #27
    ab94:      	mul	x17, x17, x10
    ab98:      	eor	x13, x13, x17, lsr #31
    ab9c:      	eor	x13, x13, x17
    aba0:      	stp	x11, x13, [x1, #0x8]
    aba4:      	add	x12, x12, #0x1
    aba8:      	str	x12, [x1, #0x18]
    abac:      	ldur	w17, [x15, #-0x30]
    abb0:      	cmp	w17, #0x2
    abb4:      	b.ne	0xaac4 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0xdc>
    abb8:      	ldp	x2, x17, [x15, #-0x28]
    abbc:      	madd	x17, x2, x16, x17
    abc0:      	add	x11, x17, x11
    abc4:      	eor	x17, x17, x17, lsr #30
    abc8:      	mul	x17, x17, x9
    abcc:      	eor	x17, x17, x17, lsr #27
    abd0:      	mul	x17, x17, x10
    abd4:      	eor	x13, x13, x17, lsr #31
    abd8:      	eor	x13, x13, x17
    abdc:      	stp	x11, x13, [x1, #0x8]
    abe0:      	add	x12, x12, #0x1
    abe4:      	str	x12, [x1, #0x18]
    abe8:      	b	0xaac4 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0xdc>

000000000000abec <_wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd>:
    abec:      	stp	x20, x19, [sp, #-0x20]!
    abf0:      	stp	x29, x30, [sp, #0x10]
    abf4:      	mov	x20, x1
    abf8:      	mov	x19, x0
    abfc:      	cbz	x1, 0xac44 <_wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd+0x58>
    ac00:      	add	x8, x20, x20, lsl #1
    ac04:      	lsl	x0, x8, #3
    ac08:      	bl	0xac08 <_wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd+0x1c>
		000000000000ac08:  ARM64_RELOC_BRANCH26	_malloc
    ac0c:      	cbz	x0, 0xac64 <_wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd+0x78>
    ac10:      	mov	x8, #0x0                ; =0
    ac14:      	add	x9, x0, #0x8
    ac18:      	stur	wzr, [x9, #-0x8]
    ac1c:      	add	x8, x8, #0x1
    ac20:      	stp	xzr, xzr, [x9], #0x18
    ac24:      	cmp	x20, x8
    ac28:      	b.ne	0xac18 <_wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd+0x2c>
    ac2c:      	stp	x20, x20, [x19]
    ac30:      	stp	xzr, xzr, [x19, #0x18]
    ac34:      	str	x0, [x19, #0x10]
    ac38:      	ldp	x29, x30, [sp, #0x10]
    ac3c:      	ldp	x20, x19, [sp], #0x20
    ac40:      	ret
    ac44:      	adrp	x0, 0xa000 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x158>
		000000000000ac44:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    ac48:      	add	x0, x0, #0x0
		000000000000ac48:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    ac4c:      	stp	x20, x20, [x19]
    ac50:      	stp	xzr, xzr, [x19, #0x18]
    ac54:      	str	x0, [x19, #0x10]
    ac58:      	ldp	x29, x30, [sp, #0x10]
    ac5c:      	ldp	x20, x19, [sp], #0x20
    ac60:      	ret
    ac64:      	bl	0xac64 <_wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd+0x78>
		000000000000ac64:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000ac68 <_wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad>:
    ac68:      	ldr	x8, [x1]
    ac6c:      	ldp	x9, x10, [x1, #0x18]
    ac70:      	adds	x10, x9, x10
    ac74:      	csinv	x11, x10, xzr, lo
    ac78:      	sub	x10, x8, x8, lsr #2
    ac7c:      	lsr	x12, x8, #14
    ac80:      	cmp	x12, #0x0
    ac84:      	ccmp	x11, x10, #0x0, eq
    ac88:      	b.lo	0xad08 <_wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad+0xa0>
    ac8c:      	stp	x24, x23, [sp, #-0x40]!
    ac90:      	stp	x22, x21, [sp, #0x10]
    ac94:      	stp	x20, x19, [sp, #0x20]
    ac98:      	stp	x29, x30, [sp, #0x30]
    ac9c:      	mov	w11, #0x1               ; =1
    aca0:      	mov	w12, #0x2000            ; =8192
    aca4:      	cmp	x8, #0x2, lsl #12       ; =0x2000
    aca8:      	csel	x12, x8, x12, lo
    acac:      	lsl	x12, x12, #1
    acb0:      	cmp	x8, #0x0
    acb4:      	csel	x11, x11, x12, eq
    acb8:      	cmp	x9, x10, lsr #1
    acbc:      	csel	x8, x11, x8, hs
    acc0:      	mov	x19, x0
    acc4:      	mov	x0, x1
    acc8:      	mov	x20, x1
    accc:      	mov	x1, x8
    acd0:      	mov	x21, x2
    acd4:      	mov	x2, x4
    acd8:      	mov	x22, x4
    acdc:      	mov	x23, x3
    ace0:      	bl	0xace0 <_wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad+0x78>
		000000000000ace0:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    ace4:      	mov	x0, x19
    ace8:      	mov	x1, x20
    acec:      	mov	x2, x21
    acf0:      	mov	x3, x23
    acf4:      	mov	x4, x22
    acf8:      	ldp	x29, x30, [sp, #0x30]
    acfc:      	ldp	x20, x19, [sp, #0x20]
    ad00:      	ldp	x22, x21, [sp, #0x10]
    ad04:      	ldp	x24, x23, [sp], #0x40
    ad08:      	b	0xad08 <_wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad+0xa0>
		000000000000ad08:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad

000000000000ad0c <_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad>:
    ad0c:      	ldr	x10, [x0, #0x18]
    ad10:      	cbz	x10, 0xadf8 <_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad+0xec>
    ad14:      	ldrb	w8, [x2, #0x8]
    ad18:      	tbz	w8, #0x0, 0xad2c <_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad+0x20>
    ad1c:      	mov	x8, #0x0                ; =0
    ad20:      	ldr	x11, [x0]
    ad24:      	cbnz	x11, 0xad74 <_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad+0x68>
    ad28:      	b	0xadf8 <_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad+0xec>
    ad2c:      	ldr	x8, [x2]
    ad30:      	ldr	x9, [x1]
    ad34:      	eor	x8, x9, x8
    ad38:      	eor	x8, x8, x8, lsr #30
    ad3c:      	mov	x9, #0xe5b9             ; =58809
    ad40:      	movk	x9, #0x1ce4, lsl #16
    ad44:      	movk	x9, #0x476d, lsl #32
    ad48:      	movk	x9, #0xbf58, lsl #48
    ad4c:      	mul	x8, x8, x9
    ad50:      	eor	x8, x8, x8, lsr #27
    ad54:      	mov	x9, #0x11eb             ; =4587
    ad58:      	movk	x9, #0x1331, lsl #16
    ad5c:      	movk	x9, #0x49bb, lsl #32
    ad60:      	movk	x9, #0x94d0, lsl #48
    ad64:      	mul	x8, x8, x9
    ad68:      	eor	x8, x8, x8, lsr #31
    ad6c:      	ldr	x11, [x0]
    ad70:      	cbz	x11, 0xadf8 <_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad+0xec>
    ad74:      	udiv	x9, x8, x11
    ad78:      	msub	x12, x9, x11, x8
    ad7c:      	ldr	x13, [x0, #0x10]
    ad80:      	mov	w14, #0x18              ; =24
    ad84:      	mov	x15, x11
    ad88:      	b	0xada0 <_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad+0x94>
    ad8c:      	add	x8, x12, #0x1
    ad90:      	cmp	x8, x11
    ad94:      	csinc	x12, xzr, x12, hs
    ad98:      	subs	x15, x15, #0x1
    ad9c:      	b.eq	0xadf8 <_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad+0xec>
    ada0:      	madd	x16, x12, x14, x13
    ada4:      	ldr	w8, [x16]
    ada8:      	cmp	w8, #0x1
    adac:      	b.eq	0xad8c <_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad+0x80>
    adb0:      	cmp	w8, #0x2
    adb4:      	b.ne	0xae10 <_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad+0x104>
    adb8:      	ldr	x9, [x16, #0x8]
    adbc:      	ldr	x8, [x1]
    adc0:      	cmp	x9, x8
    adc4:      	b.ne	0xad8c <_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad+0x80>
    adc8:      	ldr	x2, [x16, #0x10]
    adcc:      	mov	w8, #0x1                ; =1
    add0:      	str	w8, [x16]
    add4:      	sub	x10, x10, #0x1
    add8:      	stp	xzr, xzr, [x16, #0x8]
    addc:      	ldr	x11, [x0, #0x20]
    ade0:      	adds	x11, x11, #0x1
    ade4:      	csinv	x11, x11, xzr, lo
    ade8:      	stp	x10, x11, [x0, #0x18]
    adec:      	mov	x0, x8
    adf0:      	mov	x1, x9
    adf4:      	ret
    adf8:      	mov	w8, #0x0                ; =0
    adfc:      	mov	x9, #0x0                ; =0
    ae00:      	mov	x2, #0x0                ; =0
    ae04:      	mov	x0, x8
    ae08:      	mov	x1, x9
    ae0c:      	ret
    ae10:      	mov	x9, x8
    ae14:      	mov	x2, x8
    ae18:      	mov	x0, x8
    ae1c:      	mov	x1, x9
    ae20:      	ret

000000000000ae24 <_wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50>:
    ae24:      	ldrb	w8, [x2, #0x8]
    ae28:      	tbz	w8, #0x0, 0xae3c <_wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50+0x18>
    ae2c:      	mov	x8, #0x0                ; =0
    ae30:      	ldr	x9, [x0]
    ae34:      	cbnz	x9, 0xae84 <_wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50+0x60>
    ae38:      	b	0xaeec <_wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50+0xc8>
    ae3c:      	ldr	x8, [x2]
    ae40:      	ldr	x9, [x1]
    ae44:      	eor	x8, x9, x8
    ae48:      	eor	x8, x8, x8, lsr #30
    ae4c:      	mov	x9, #0xe5b9             ; =58809
    ae50:      	movk	x9, #0x1ce4, lsl #16
    ae54:      	movk	x9, #0x476d, lsl #32
    ae58:      	movk	x9, #0xbf58, lsl #48
    ae5c:      	mul	x8, x8, x9
    ae60:      	eor	x8, x8, x8, lsr #27
    ae64:      	mov	x9, #0x11eb             ; =4587
    ae68:      	movk	x9, #0x1331, lsl #16
    ae6c:      	movk	x9, #0x49bb, lsl #32
    ae70:      	movk	x9, #0x94d0, lsl #48
    ae74:      	mul	x8, x8, x9
    ae78:      	eor	x8, x8, x8, lsr #31
    ae7c:      	ldr	x9, [x0]
    ae80:      	cbz	x9, 0xaeec <_wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50+0xc8>
    ae84:      	udiv	x10, x8, x9
    ae88:      	msub	x10, x10, x9, x8
    ae8c:      	ldr	x11, [x0, #0x10]
    ae90:      	mov	w12, #0x18              ; =24
    ae94:      	mov	x13, x9
    ae98:      	b	0xaeb0 <_wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50+0x8c>
    ae9c:      	add	x8, x10, #0x1
    aea0:      	cmp	x8, x9
    aea4:      	csinc	x10, xzr, x10, hs
    aea8:      	subs	x13, x13, #0x1
    aeac:      	b.eq	0xaeec <_wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50+0xc8>
    aeb0:      	madd	x14, x10, x12, x11
    aeb4:      	ldr	w8, [x14]
    aeb8:      	cmp	w8, #0x1
    aebc:      	b.eq	0xae9c <_wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50+0x78>
    aec0:      	cmp	w8, #0x2
    aec4:      	b.ne	0xaef0 <_wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50+0xcc>
    aec8:      	ldr	x8, [x14, #0x8]
    aecc:      	ldr	x15, [x1]
    aed0:      	cmp	x8, x15
    aed4:      	b.ne	0xae9c <_wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50+0x78>
    aed8:      	mov	w0, #0x0                ; =0
    aedc:      	ldr	x8, [x14, #0x10]
    aee0:      	mov	x1, x8
    aee4:      	mov	w2, #0x0                ; =0
    aee8:      	ret
    aeec:      	mov	x8, #0x0                ; =0
    aef0:      	mov	w0, #0x1                ; =1
    aef4:      	mov	x1, x8
    aef8:      	mov	w2, #0x0                ; =0
    aefc:      	ret

000000000000af00 <_wf_std.collections.hash_map.hash_map_rehash$instance$fde7c6722a8b0dad>:
    af00:      	mov	x2, x1
    af04:      	ldr	x1, [x0]
    af08:      	b	0xaf08 <_wf_std.collections.hash_map.hash_map_rehash$instance$fde7c6722a8b0dad+0x8>
		000000000000af08:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad

000000000000af0c <_wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad>:
    af0c:      	cmp	x1, #0x4, lsl #12       ; =0x4000
    af10:      	b.ls	0xaf24 <_wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad+0x18>
    af14:      	mov	w2, #0x0                ; =0
    af18:      	mov	w1, #0x0                ; =0
    af1c:      	mov	w0, #0x1                ; =1
    af20:      	ret
    af24:      	ldr	x8, [x0]
    af28:      	cmp	x1, x8
    af2c:      	b.ls	0xaf40 <_wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad+0x34>
    af30:      	stp	x29, x30, [sp, #-0x10]!
    af34:      	bl	0xaf34 <_wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad+0x28>
		000000000000af34:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    af38:      	ldp	x29, x30, [sp], #0x10
    af3c:      	ret
    af40:      	mov	w2, #0x0                ; =0
    af44:      	mov	w1, #0x0                ; =0
    af48:      	mov	w0, #0x0                ; =0
    af4c:      	ret

000000000000af50 <_wf_std.collections.hash_map.hash_map_capacity$instance$820b2044b97e0fbd>:
    af50:      	ldr	x0, [x0]
    af54:      	ret

000000000000af58 <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567>:
    af58:      	ldrb	w8, [x2, #0x8]
    af5c:      	tbz	w8, #0x0, 0xaf70 <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567+0x18>
    af60:      	mov	x8, #0x0                ; =0
    af64:      	ldr	x9, [x0]
    af68:      	cbnz	x9, 0xafb8 <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567+0x60>
    af6c:      	b	0xb034 <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567+0xdc>
    af70:      	ldr	x8, [x2]
    af74:      	ldr	x9, [x1]
    af78:      	eor	x8, x9, x8
    af7c:      	eor	x8, x8, x8, lsr #30
    af80:      	mov	x9, #0xe5b9             ; =58809
    af84:      	movk	x9, #0x1ce4, lsl #16
    af88:      	movk	x9, #0x476d, lsl #32
    af8c:      	movk	x9, #0xbf58, lsl #48
    af90:      	mul	x8, x8, x9
    af94:      	eor	x8, x8, x8, lsr #27
    af98:      	mov	x9, #0x11eb             ; =4587
    af9c:      	movk	x9, #0x1331, lsl #16
    afa0:      	movk	x9, #0x49bb, lsl #32
    afa4:      	movk	x9, #0x94d0, lsl #48
    afa8:      	mul	x8, x8, x9
    afac:      	eor	x8, x8, x8, lsr #31
    afb0:      	ldr	x9, [x0]
    afb4:      	cbz	x9, 0xb034 <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567+0xdc>
    afb8:      	mov	x10, #0x0               ; =0
    afbc:      	udiv	x11, x8, x9
    afc0:      	msub	x11, x11, x9, x8
    afc4:      	sub	x12, x9, x11
    afc8:      	neg	x13, x12
    afcc:      	ldr	x14, [x0, #0x10]
    afd0:      	mov	w15, #0x18              ; =24
    afd4:      	b	0xafe4 <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567+0x8c>
    afd8:      	add	x10, x10, #0x1
    afdc:      	cmp	x9, x10
    afe0:      	b.eq	0xb034 <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567+0xdc>
    afe4:      	cmp	x10, x12
    afe8:      	csel	x8, x11, x13, lo
    afec:      	add	x8, x8, x10
    aff0:      	madd	x16, x8, x15, x14
    aff4:      	ldr	w8, [x16]
    aff8:      	cmp	w8, #0x1
    affc:      	b.eq	0xafd8 <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567+0x80>
    b000:      	cmp	w8, #0x2
    b004:      	b.ne	0xb038 <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567+0xe0>
    b008:      	ldr	x8, [x16, #0x8]
    b00c:      	ldr	x17, [x1]
    b010:      	cmp	x8, x17
    b014:      	b.ne	0xafd8 <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567+0x80>
    b018:      	mov	w0, #0x0                ; =0
    b01c:      	ldr	x8, [x16, #0x10]
    b020:      	add	x8, x8, #0x1
    b024:      	str	x8, [x16, #0x10]
    b028:      	mov	x1, x8
    b02c:      	mov	w2, #0x0                ; =0
    b030:      	ret
    b034:      	mov	x8, #0x0                ; =0
    b038:      	mov	w0, #0x1                ; =1
    b03c:      	mov	x1, x8
    b040:      	mov	w2, #0x0                ; =0
    b044:      	ret

000000000000b048 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19>:
    b048:      	stp	x29, x30, [sp, #-0x10]!
    b04c:      	ldp	x15, x8, [x0]
    b050:      	ldr	x0, [x0, #0x10]
    b054:      	cbz	x15, 0xb0fc <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xb4>
    b058:      	mov	x9, #0xe5b9             ; =58809
    b05c:      	movk	x9, #0x1ce4, lsl #16
    b060:      	movk	x9, #0x476d, lsl #32
    b064:      	movk	x9, #0xbf58, lsl #48
    b068:      	mov	x10, #0x11eb            ; =4587
    b06c:      	movk	x10, #0x1331, lsl #16
    b070:      	movk	x10, #0x49bb, lsl #32
    b074:      	movk	x10, #0x94d0, lsl #48
    b078:      	ldp	x11, x13, [x1, #0x8]
    b07c:      	ldr	x12, [x1, #0x18]
    b080:      	ands	x16, x15, #0x3
    b084:      	b.eq	0xb0f0 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xa8>
    b088:      	mov	w14, #0x18              ; =24
    b08c:      	madd	x14, x15, x14, x0
    b090:      	sub	x17, x14, #0x8
    b094:      	mov	w2, #0x83               ; =131
    b098:      	mov	x14, x15
    b09c:      	b	0xb0b0 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0x68>
    b0a0:      	sub	x17, x17, #0x18
    b0a4:      	sub	x14, x14, #0x1
    b0a8:      	sub	x16, x16, #0x1
    b0ac:      	cbz	x16, 0xb0f4 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xac>
    b0b0:      	ldur	w3, [x17, #-0x10]
    b0b4:      	cmp	w3, #0x2
    b0b8:      	b.ne	0xb0a0 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0x58>
    b0bc:      	ldp	x4, x3, [x17, #-0x8]
    b0c0:      	madd	x3, x4, x2, x3
    b0c4:      	add	x11, x3, x11
    b0c8:      	eor	x3, x3, x3, lsr #30
    b0cc:      	mul	x3, x3, x9
    b0d0:      	eor	x3, x3, x3, lsr #27
    b0d4:      	mul	x3, x3, x10
    b0d8:      	eor	x13, x13, x3, lsr #31
    b0dc:      	eor	x13, x13, x3
    b0e0:      	stp	x11, x13, [x1, #0x8]
    b0e4:      	add	x12, x12, #0x1
    b0e8:      	str	x12, [x1, #0x18]
    b0ec:      	b	0xb0a0 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0x58>
    b0f0:      	mov	x14, x15
    b0f4:      	cmp	x15, #0x4
    b0f8:      	b.hs	0xb110 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xc8>
    b0fc:      	cbz	x8, 0xb104 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xbc>
    b100:      	bl	0xb100 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xb8>
		000000000000b100:  ARM64_RELOC_BRANCH26	_free
    b104:      	mov	w0, #0x0                ; =0
    b108:      	ldp	x29, x30, [sp], #0x10
    b10c:      	ret
    b110:      	mov	w15, #0x18              ; =24
    b114:      	madd	x15, x14, x15, x0
    b118:      	sub	x15, x15, #0x30
    b11c:      	mov	w16, #0x83              ; =131
    b120:      	b	0xb130 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xe8>
    b124:      	sub	x15, x15, #0x60
    b128:      	sub	x14, x14, #0x4
    b12c:      	cbz	x14, 0xb0fc <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xb4>
    b130:      	ldr	w17, [x15, #0x18]
    b134:      	cmp	w17, #0x2
    b138:      	b.eq	0xb164 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0x11c>
    b13c:      	ldr	w17, [x15]
    b140:      	cmp	w17, #0x2
    b144:      	b.eq	0xb1a0 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0x158>
    b148:      	ldur	w17, [x15, #-0x18]
    b14c:      	cmp	w17, #0x2
    b150:      	b.eq	0xb1dc <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0x194>
    b154:      	ldur	w17, [x15, #-0x30]
    b158:      	cmp	w17, #0x2
    b15c:      	b.ne	0xb124 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xdc>
    b160:      	b	0xb218 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0x1d0>
    b164:      	ldp	x2, x17, [x15, #0x20]
    b168:      	madd	x17, x2, x16, x17
    b16c:      	add	x11, x17, x11
    b170:      	eor	x17, x17, x17, lsr #30
    b174:      	mul	x17, x17, x9
    b178:      	eor	x17, x17, x17, lsr #27
    b17c:      	mul	x17, x17, x10
    b180:      	eor	x13, x13, x17, lsr #31
    b184:      	eor	x13, x13, x17
    b188:      	stp	x11, x13, [x1, #0x8]
    b18c:      	add	x12, x12, #0x1
    b190:      	str	x12, [x1, #0x18]
    b194:      	ldr	w17, [x15]
    b198:      	cmp	w17, #0x2
    b19c:      	b.ne	0xb148 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0x100>
    b1a0:      	ldp	x2, x17, [x15, #0x8]
    b1a4:      	madd	x17, x2, x16, x17
    b1a8:      	add	x11, x17, x11
    b1ac:      	eor	x17, x17, x17, lsr #30
    b1b0:      	mul	x17, x17, x9
    b1b4:      	eor	x17, x17, x17, lsr #27
    b1b8:      	mul	x17, x17, x10
    b1bc:      	eor	x13, x13, x17, lsr #31
    b1c0:      	eor	x13, x13, x17
    b1c4:      	stp	x11, x13, [x1, #0x8]
    b1c8:      	add	x12, x12, #0x1
    b1cc:      	str	x12, [x1, #0x18]
    b1d0:      	ldur	w17, [x15, #-0x18]
    b1d4:      	cmp	w17, #0x2
    b1d8:      	b.ne	0xb154 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0x10c>
    b1dc:      	ldp	x2, x17, [x15, #-0x10]
    b1e0:      	madd	x17, x2, x16, x17
    b1e4:      	add	x11, x17, x11
    b1e8:      	eor	x17, x17, x17, lsr #30
    b1ec:      	mul	x17, x17, x9
    b1f0:      	eor	x17, x17, x17, lsr #27
    b1f4:      	mul	x17, x17, x10
    b1f8:      	eor	x13, x13, x17, lsr #31
    b1fc:      	eor	x13, x13, x17
    b200:      	stp	x11, x13, [x1, #0x8]
    b204:      	add	x12, x12, #0x1
    b208:      	str	x12, [x1, #0x18]
    b20c:      	ldur	w17, [x15, #-0x30]
    b210:      	cmp	w17, #0x2
    b214:      	b.ne	0xb124 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xdc>
    b218:      	ldp	x2, x17, [x15, #-0x28]
    b21c:      	madd	x17, x2, x16, x17
    b220:      	add	x11, x17, x11
    b224:      	eor	x17, x17, x17, lsr #30
    b228:      	mul	x17, x17, x9
    b22c:      	eor	x17, x17, x17, lsr #27
    b230:      	mul	x17, x17, x10
    b234:      	eor	x13, x13, x17, lsr #31
    b238:      	eor	x13, x13, x17
    b23c:      	stp	x11, x13, [x1, #0x8]
    b240:      	add	x12, x12, #0x1
    b244:      	str	x12, [x1, #0x18]
    b248:      	b	0xb124 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xdc>

000000000000b24c <_wf_std.collections.hash_map.hash_map_new$instance$96033bf6ddb80743>:
    b24c:      	stp	x20, x19, [sp, #-0x20]!
    b250:      	stp	x29, x30, [sp, #0x10]
    b254:      	mov	x20, x1
    b258:      	mov	x19, x0
    b25c:      	cbz	x1, 0xb2cc <_wf_std.collections.hash_map.hash_map_new$instance$96033bf6ddb80743+0x80>
    b260:      	add	x8, x20, x20, lsl #4
    b264:      	lsl	x0, x8, #4
    b268:      	bl	0xb268 <_wf_std.collections.hash_map.hash_map_new$instance$96033bf6ddb80743+0x1c>
		000000000000b268:  ARM64_RELOC_BRANCH26	_malloc
    b26c:      	cbz	x0, 0xb2ec <_wf_std.collections.hash_map.hash_map_new$instance$96033bf6ddb80743+0xa0>
    b270:      	mov	x8, #0x0                ; =0
    b274:      	add	x9, x0, #0x8
    b278:      	movi.2d	v0, #0000000000000000
    b27c:      	stur	wzr, [x9, #-0x8]
    b280:      	add	x8, x8, #0x1
    b284:      	stp	q0, q0, [x9]
    b288:      	stp	q0, q0, [x9, #0x20]
    b28c:      	stp	q0, q0, [x9, #0x40]
    b290:      	stp	q0, q0, [x9, #0x60]
    b294:      	stp	q0, q0, [x9, #0x80]
    b298:      	stp	q0, q0, [x9, #0xa0]
    b29c:      	stp	q0, q0, [x9, #0xc0]
    b2a0:      	stp	q0, q0, [x9, #0xe0]
    b2a4:      	str	xzr, [x9, #0x100]
    b2a8:      	add	x9, x9, #0x110
    b2ac:      	cmp	x20, x8
    b2b0:      	b.ne	0xb27c <_wf_std.collections.hash_map.hash_map_new$instance$96033bf6ddb80743+0x30>
    b2b4:      	stp	x20, x20, [x19]
    b2b8:      	stp	xzr, xzr, [x19, #0x18]
    b2bc:      	str	x0, [x19, #0x10]
    b2c0:      	ldp	x29, x30, [sp, #0x10]
    b2c4:      	ldp	x20, x19, [sp], #0x20
    b2c8:      	ret
    b2cc:      	adrp	x0, 0xb000 <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567+0xa8>
		000000000000b2cc:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    b2d0:      	add	x0, x0, #0x0
		000000000000b2d0:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    b2d4:      	stp	x20, x20, [x19]
    b2d8:      	stp	xzr, xzr, [x19, #0x18]
    b2dc:      	str	x0, [x19, #0x10]
    b2e0:      	ldp	x29, x30, [sp, #0x10]
    b2e4:      	ldp	x20, x19, [sp], #0x20
    b2e8:      	ret
    b2ec:      	bl	0xb2ec <_wf_std.collections.hash_map.hash_map_new$instance$96033bf6ddb80743+0xa0>
		000000000000b2ec:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000b2f0 <_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07>:
    b2f0:      	sub	sp, sp, #0x1c0
    b2f4:      	stp	x28, x27, [sp, #0x180]
    b2f8:      	stp	x22, x21, [sp, #0x190]
    b2fc:      	stp	x20, x19, [sp, #0x1a0]
    b300:      	stp	x29, x30, [sp, #0x1b0]
    b304:      	ldp	q0, q1, [x3, #0xc0]
    b308:      	mov	x8, sp
    b30c:      	add	x9, x8, #0x128
    b310:      	stp	q0, q1, [sp, #0xc0]
    b314:      	ldp	q0, q1, [x3, #0xe0]
    b318:      	stp	q0, q1, [sp, #0xe0]
    b31c:      	ldp	q0, q1, [x3, #0x80]
    b320:      	stp	q0, q1, [sp, #0x80]
    b324:      	ldp	q0, q1, [x3, #0xa0]
    b328:      	stp	q0, q1, [sp, #0xa0]
    b32c:      	ldp	q0, q1, [x3, #0x40]
    b330:      	stp	q0, q1, [sp, #0x40]
    b334:      	ldp	q0, q1, [x3, #0x60]
    b338:      	stp	q0, q1, [sp, #0x60]
    b33c:      	ldp	q0, q1, [x3]
    b340:      	stp	q0, q1, [sp]
    b344:      	ldp	q0, q1, [x3, #0x20]
    b348:      	stp	q0, q1, [sp, #0x20]
    b34c:      	ldr	x8, [x1]
    b350:      	ldp	q1, q0, [x1]
    b354:      	stp	q1, q0, [sp, #0x100]
    b358:      	ldr	x10, [x1, #0x20]
    b35c:      	ldr	x11, [sp, #0x118]
    b360:      	stp	q1, q0, [x9]
    b364:      	adds	x9, x11, x10
    b368:      	csinv	x9, x9, xzr, lo
    b36c:      	str	x10, [sp, #0x120]
    b370:      	str	x10, [sp, #0x148]
    b374:      	cmp	x8, #0x2
    b378:      	b.hi	0xb3fc <_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07+0x10c>
    b37c:      	sub	x10, x8, x8, lsr #2
    b380:      	cmp	x9, x10
    b384:      	b.lo	0xb3fc <_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07+0x10c>
    b388:      	ldp	q1, q0, [x1]
    b38c:      	stp	q1, q0, [sp, #0x150]
    b390:      	ldr	x9, [x1, #0x20]
    b394:      	str	x9, [sp, #0x170]
    b398:      	ldr	x9, [sp, #0x168]
    b39c:      	mov	x19, x0
    b3a0:      	mov	x20, x2
    b3a4:      	cmp	x9, x8, lsr #1
    b3a8:      	b.lo	0xb3c4 <_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07+0xd4>
    b3ac:      	cbz	x8, 0xb3c0 <_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07+0xd0>
    b3b0:      	cmp	x8, #0x1
    b3b4:      	mov	w8, #0x2                ; =2
    b3b8:      	cinc	x8, x8, ne
    b3bc:      	b	0xb3c4 <_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07+0xd4>
    b3c0:      	mov	w8, #0x1                ; =1
    b3c4:      	mov	x0, x1
    b3c8:      	mov	x21, x1
    b3cc:      	mov	x1, x8
    b3d0:      	mov	x2, x4
    b3d4:      	mov	x22, x4
    b3d8:      	bl	0xb3d8 <_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07+0xe8>
		000000000000b3d8:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07
    b3dc:      	mov	x4, x22
    b3e0:      	mov	x8, x1
    b3e4:      	mov	x1, x21
    b3e8:      	str	w0, [sp, #0x178]
    b3ec:      	strb	w8, [sp, #0x17c]
    b3f0:      	strb	w2, [sp, #0x17d]
    b3f4:      	mov	x2, x20
    b3f8:      	mov	x0, x19
    b3fc:      	mov	x3, sp
    b400:      	bl	0xb400 <_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07+0x110>
		000000000000b400:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07
    b404:      	ldp	x29, x30, [sp, #0x1b0]
    b408:      	ldp	x20, x19, [sp, #0x1a0]
    b40c:      	ldp	x22, x21, [sp, #0x190]
    b410:      	ldp	x28, x27, [sp, #0x180]
    b414:      	add	sp, sp, #0x1c0
    b418:      	ret

000000000000b41c <_wf_map_cost_library_policy_result$instance$4250cb78d3f44027>:
    b41c:      	ldr	w8, [x0]
    b420:      	cbz	w8, 0xb550 <_wf_map_cost_library_policy_result$instance$4250cb78d3f44027+0x134>
    b424:      	ldrb	w9, [x0, #0x4]
    b428:      	ldr	x10, [x1]
    b42c:      	mov	w8, #0x83               ; =131
    b430:      	tst	w9, #0x1
    b434:      	mov	w9, #0x1                ; =1
    b438:      	cinc	x9, x9, ne
    b43c:      	madd	x9, x10, x8, x9
    b440:      	ldp	x11, x10, [x0, #0x8]
    b444:      	madd	x10, x11, x8, x10
    b448:      	ldr	x11, [x0, #0x18]
    b44c:      	madd	x10, x10, x8, x11
    b450:      	ldr	x11, [x0, #0x20]
    b454:      	madd	x10, x10, x8, x11
    b458:      	ldr	x11, [x0, #0x28]
    b45c:      	madd	x10, x10, x8, x11
    b460:      	ldr	x11, [x0, #0x30]
    b464:      	madd	x10, x10, x8, x11
    b468:      	ldr	x11, [x0, #0x38]
    b46c:      	madd	x10, x10, x8, x11
    b470:      	ldr	x11, [x0, #0x40]
    b474:      	madd	x10, x10, x8, x11
    b478:      	ldr	x11, [x0, #0x48]
    b47c:      	madd	x10, x10, x8, x11
    b480:      	ldr	x11, [x0, #0x50]
    b484:      	madd	x10, x10, x8, x11
    b488:      	ldr	x11, [x0, #0x58]
    b48c:      	madd	x10, x10, x8, x11
    b490:      	ldr	x11, [x0, #0x60]
    b494:      	madd	x10, x10, x8, x11
    b498:      	ldr	x11, [x0, #0x68]
    b49c:      	madd	x10, x10, x8, x11
    b4a0:      	ldr	x11, [x0, #0x70]
    b4a4:      	madd	x10, x10, x8, x11
    b4a8:      	ldr	x11, [x0, #0x78]
    b4ac:      	madd	x10, x10, x8, x11
    b4b0:      	ldr	x11, [x0, #0x80]
    b4b4:      	madd	x10, x10, x8, x11
    b4b8:      	ldr	x11, [x0, #0x88]
    b4bc:      	madd	x10, x10, x8, x11
    b4c0:      	ldr	x11, [x0, #0x90]
    b4c4:      	madd	x10, x10, x8, x11
    b4c8:      	ldr	x11, [x0, #0x98]
    b4cc:      	madd	x10, x10, x8, x11
    b4d0:      	ldr	x11, [x0, #0xa0]
    b4d4:      	madd	x10, x10, x8, x11
    b4d8:      	ldr	x11, [x0, #0xa8]
    b4dc:      	madd	x10, x10, x8, x11
    b4e0:      	ldr	x11, [x0, #0xb0]
    b4e4:      	madd	x10, x10, x8, x11
    b4e8:      	ldr	x11, [x0, #0xb8]
    b4ec:      	madd	x10, x10, x8, x11
    b4f0:      	ldr	x11, [x0, #0xc0]
    b4f4:      	madd	x10, x10, x8, x11
    b4f8:      	ldr	x11, [x0, #0xc8]
    b4fc:      	madd	x10, x10, x8, x11
    b500:      	ldr	x11, [x0, #0xd0]
    b504:      	madd	x10, x10, x8, x11
    b508:      	ldr	x11, [x0, #0xd8]
    b50c:      	madd	x10, x10, x8, x11
    b510:      	ldr	x11, [x0, #0xe0]
    b514:      	madd	x10, x10, x8, x11
    b518:      	ldr	x11, [x0, #0xe8]
    b51c:      	madd	x10, x10, x8, x11
    b520:      	ldr	x11, [x0, #0xf0]
    b524:      	madd	x10, x10, x8, x11
    b528:      	ldr	x11, [x0, #0xf8]
    b52c:      	madd	x10, x10, x8, x11
    b530:      	ldr	x11, [x0, #0x100]
    b534:      	madd	x10, x10, x8, x11
    b538:      	add	x9, x10, x9
    b53c:      	ldr	x10, [x0, #0x108]
    b540:      	madd	x8, x9, x8, x10
    b544:      	str	x8, [x1]
    b548:      	mov	w0, #0x0                ; =0
    b54c:      	ret
    b550:      	ldr	x8, [x1]
    b554:      	mov	w9, #0x83               ; =131
    b558:      	mul	x8, x8, x9
    b55c:      	str	x8, [x1]
    b560:      	mov	w0, #0x0                ; =0
    b564:      	ret

000000000000b568 <_wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146>:
    b568:      	stp	x29, x30, [sp, #-0x10]!
    b56c:      	ldp	x9, x8, [x0]
    b570:      	ldr	x0, [x0, #0x10]
    b574:      	cbz	x9, 0xb6bc <_wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146+0x154>
    b578:      	ldp	x10, x11, [x1, #0x8]
    b57c:      	mov	w12, #0x110             ; =272
    b580:      	madd	x13, x9, x12, x0
    b584:      	ldr	x12, [x1, #0x18]
    b588:      	sub	x13, x13, #0x88
    b58c:      	mov	w14, #0x83              ; =131
    b590:      	mov	x15, #0xe5b9            ; =58809
    b594:      	movk	x15, #0x1ce4, lsl #16
    b598:      	movk	x15, #0x476d, lsl #32
    b59c:      	movk	x15, #0xbf58, lsl #48
    b5a0:      	mov	x16, #0x11eb            ; =4587
    b5a4:      	movk	x16, #0x1331, lsl #16
    b5a8:      	movk	x16, #0x49bb, lsl #32
    b5ac:      	movk	x16, #0x94d0, lsl #48
    b5b0:      	b	0xb5c0 <_wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146+0x58>
    b5b4:      	sub	x13, x13, #0x110
    b5b8:      	sub	x9, x9, #0x1
    b5bc:      	cbz	x9, 0xb6bc <_wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146+0x154>
    b5c0:      	ldur	w17, [x13, #-0x88]
    b5c4:      	cmp	w17, #0x2
    b5c8:      	b.ne	0xb5b4 <_wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146+0x4c>
    b5cc:      	ldp	x2, x17, [x13, #-0x80]
    b5d0:      	madd	x17, x2, x14, x17
    b5d4:      	ldp	x3, x2, [x13, #-0x70]
    b5d8:      	madd	x17, x17, x14, x3
    b5dc:      	madd	x17, x17, x14, x2
    b5e0:      	ldp	x3, x2, [x13, #-0x60]
    b5e4:      	madd	x17, x17, x14, x3
    b5e8:      	madd	x17, x17, x14, x2
    b5ec:      	ldp	x3, x2, [x13, #-0x50]
    b5f0:      	madd	x17, x17, x14, x3
    b5f4:      	madd	x17, x17, x14, x2
    b5f8:      	ldp	x3, x2, [x13, #-0x40]
    b5fc:      	madd	x17, x17, x14, x3
    b600:      	madd	x17, x17, x14, x2
    b604:      	ldp	x3, x2, [x13, #-0x30]
    b608:      	madd	x17, x17, x14, x3
    b60c:      	madd	x17, x17, x14, x2
    b610:      	ldp	x3, x2, [x13, #-0x20]
    b614:      	madd	x17, x17, x14, x3
    b618:      	madd	x17, x17, x14, x2
    b61c:      	ldp	x3, x2, [x13, #-0x10]
    b620:      	madd	x17, x17, x14, x3
    b624:      	madd	x17, x17, x14, x2
    b628:      	ldp	x3, x2, [x13]
    b62c:      	madd	x17, x17, x14, x3
    b630:      	madd	x17, x17, x14, x2
    b634:      	ldp	x3, x2, [x13, #0x10]
    b638:      	madd	x17, x17, x14, x3
    b63c:      	madd	x17, x17, x14, x2
    b640:      	ldp	x3, x2, [x13, #0x20]
    b644:      	madd	x17, x17, x14, x3
    b648:      	madd	x17, x17, x14, x2
    b64c:      	ldp	x3, x2, [x13, #0x30]
    b650:      	madd	x17, x17, x14, x3
    b654:      	madd	x17, x17, x14, x2
    b658:      	ldp	x3, x2, [x13, #0x40]
    b65c:      	madd	x17, x17, x14, x3
    b660:      	madd	x17, x17, x14, x2
    b664:      	ldp	x3, x2, [x13, #0x50]
    b668:      	madd	x17, x17, x14, x3
    b66c:      	madd	x17, x17, x14, x2
    b670:      	ldp	x3, x2, [x13, #0x60]
    b674:      	madd	x17, x17, x14, x3
    b678:      	madd	x17, x17, x14, x2
    b67c:      	ldp	x3, x2, [x13, #0x70]
    b680:      	madd	x17, x17, x14, x3
    b684:      	madd	x17, x17, x14, x2
    b688:      	ldr	x2, [x13, #0x80]
    b68c:      	madd	x17, x17, x14, x2
    b690:      	add	x10, x17, x10
    b694:      	eor	x17, x17, x17, lsr #30
    b698:      	mul	x17, x17, x15
    b69c:      	eor	x17, x17, x17, lsr #27
    b6a0:      	mul	x17, x17, x16
    b6a4:      	eor	x11, x11, x17, lsr #31
    b6a8:      	eor	x11, x11, x17
    b6ac:      	stp	x10, x11, [x1, #0x8]
    b6b0:      	add	x12, x12, #0x1
    b6b4:      	str	x12, [x1, #0x18]
    b6b8:      	b	0xb5b4 <_wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146+0x4c>
    b6bc:      	cbz	x8, 0xb6c4 <_wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146+0x15c>
    b6c0:      	bl	0xb6c0 <_wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146+0x158>
		000000000000b6c0:  ARM64_RELOC_BRANCH26	_free
    b6c4:      	mov	w0, #0x0                ; =0
    b6c8:      	ldp	x29, x30, [sp], #0x10
    b6cc:      	ret

000000000000b6d0 <_wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374>:
    b6d0:      	stp	x20, x19, [sp, #-0x20]!
    b6d4:      	stp	x29, x30, [sp, #0x10]
    b6d8:      	mov	x20, x1
    b6dc:      	mov	x19, x0
    b6e0:      	cbz	x1, 0xb750 <_wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374+0x80>
    b6e4:      	add	x8, x20, x20, lsl #4
    b6e8:      	lsl	x0, x8, #4
    b6ec:      	bl	0xb6ec <_wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374+0x1c>
		000000000000b6ec:  ARM64_RELOC_BRANCH26	_malloc
    b6f0:      	cbz	x0, 0xb770 <_wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374+0xa0>
    b6f4:      	mov	x8, #0x0                ; =0
    b6f8:      	add	x9, x0, #0x8
    b6fc:      	movi.2d	v0, #0000000000000000
    b700:      	stur	wzr, [x9, #-0x8]
    b704:      	add	x8, x8, #0x1
    b708:      	stp	q0, q0, [x9]
    b70c:      	stp	q0, q0, [x9, #0x20]
    b710:      	stp	q0, q0, [x9, #0x40]
    b714:      	stp	q0, q0, [x9, #0x60]
    b718:      	stp	q0, q0, [x9, #0x80]
    b71c:      	stp	q0, q0, [x9, #0xa0]
    b720:      	stp	q0, q0, [x9, #0xc0]
    b724:      	stp	q0, q0, [x9, #0xe0]
    b728:      	str	xzr, [x9, #0x100]
    b72c:      	add	x9, x9, #0x110
    b730:      	cmp	x20, x8
    b734:      	b.ne	0xb700 <_wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374+0x30>
    b738:      	stp	x20, x20, [x19]
    b73c:      	stp	xzr, xzr, [x19, #0x18]
    b740:      	str	x0, [x19, #0x10]
    b744:      	ldp	x29, x30, [sp, #0x10]
    b748:      	ldp	x20, x19, [sp], #0x20
    b74c:      	ret
    b750:      	adrp	x0, 0xb000 <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567+0xa8>
		000000000000b750:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    b754:      	add	x0, x0, #0x0
		000000000000b754:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    b758:      	stp	x20, x20, [x19]
    b75c:      	stp	xzr, xzr, [x19, #0x18]
    b760:      	str	x0, [x19, #0x10]
    b764:      	ldp	x29, x30, [sp, #0x10]
    b768:      	ldp	x20, x19, [sp], #0x20
    b76c:      	ret
    b770:      	bl	0xb770 <_wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374+0xa0>
		000000000000b770:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000b774 <_wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65>:
    b774:      	sub	sp, sp, #0x1c0
    b778:      	stp	x28, x27, [sp, #0x180]
    b77c:      	stp	x22, x21, [sp, #0x190]
    b780:      	stp	x20, x19, [sp, #0x1a0]
    b784:      	stp	x29, x30, [sp, #0x1b0]
    b788:      	ldp	q0, q1, [x3, #0xc0]
    b78c:      	mov	x8, sp
    b790:      	add	x9, x8, #0x128
    b794:      	stp	q0, q1, [sp, #0xc0]
    b798:      	ldp	q0, q1, [x3, #0xe0]
    b79c:      	stp	q0, q1, [sp, #0xe0]
    b7a0:      	ldp	q0, q1, [x3, #0x80]
    b7a4:      	stp	q0, q1, [sp, #0x80]
    b7a8:      	ldp	q0, q1, [x3, #0xa0]
    b7ac:      	stp	q0, q1, [sp, #0xa0]
    b7b0:      	ldp	q0, q1, [x3, #0x40]
    b7b4:      	stp	q0, q1, [sp, #0x40]
    b7b8:      	ldp	q0, q1, [x3, #0x60]
    b7bc:      	stp	q0, q1, [sp, #0x60]
    b7c0:      	ldp	q0, q1, [x3]
    b7c4:      	stp	q0, q1, [sp]
    b7c8:      	ldp	q0, q1, [x3, #0x20]
    b7cc:      	stp	q0, q1, [sp, #0x20]
    b7d0:      	ldr	x8, [x1]
    b7d4:      	ldp	q1, q0, [x1]
    b7d8:      	stp	q1, q0, [sp, #0x100]
    b7dc:      	ldr	x11, [x1, #0x20]
    b7e0:      	ldr	x10, [sp, #0x118]
    b7e4:      	stp	q1, q0, [x9]
    b7e8:      	adds	x9, x10, x11
    b7ec:      	csinv	x10, x9, xzr, lo
    b7f0:      	lsr	x9, x8, #14
    b7f4:      	str	x11, [sp, #0x120]
    b7f8:      	str	x11, [sp, #0x148]
    b7fc:      	cbnz	x9, 0xb884 <_wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65+0x110>
    b800:      	sub	x9, x8, x8, lsr #2
    b804:      	cmp	x10, x9
    b808:      	b.lo	0xb884 <_wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65+0x110>
    b80c:      	ldp	q1, q0, [x1]
    b810:      	stp	q1, q0, [sp, #0x150]
    b814:      	ldr	x10, [x1, #0x20]
    b818:      	str	x10, [sp, #0x170]
    b81c:      	ldr	x10, [sp, #0x168]
    b820:      	mov	x19, x0
    b824:      	mov	x20, x2
    b828:      	cmp	x10, x9, lsr #1
    b82c:      	b.lo	0xb84c <_wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65+0xd8>
    b830:      	cbz	x8, 0xb848 <_wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65+0xd4>
    b834:      	mov	w9, #0x2000             ; =8192
    b838:      	cmp	x8, #0x2, lsl #12       ; =0x2000
    b83c:      	csel	x8, x8, x9, lo
    b840:      	lsl	x8, x8, #1
    b844:      	b	0xb84c <_wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65+0xd8>
    b848:      	mov	w8, #0x1                ; =1
    b84c:      	mov	x0, x1
    b850:      	mov	x21, x1
    b854:      	mov	x1, x8
    b858:      	mov	x2, x4
    b85c:      	mov	x22, x4
    b860:      	bl	0xb860 <_wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65+0xec>
		000000000000b860:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    b864:      	mov	x4, x22
    b868:      	mov	x8, x1
    b86c:      	mov	x1, x21
    b870:      	str	w0, [sp, #0x178]
    b874:      	strb	w8, [sp, #0x17c]
    b878:      	strb	w2, [sp, #0x17d]
    b87c:      	mov	x2, x20
    b880:      	mov	x0, x19
    b884:      	mov	x3, sp
    b888:      	bl	0xb888 <_wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65+0x114>
		000000000000b888:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
    b88c:      	ldp	x29, x30, [sp, #0x1b0]
    b890:      	ldp	x20, x19, [sp, #0x1a0]
    b894:      	ldp	x22, x21, [sp, #0x190]
    b898:      	ldp	x28, x27, [sp, #0x180]
    b89c:      	add	sp, sp, #0x1c0
    b8a0:      	ret

000000000000b8a4 <_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65>:
    b8a4:      	ldr	x8, [x1, #0x18]
    b8a8:      	cbz	x8, 0xba10 <_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65+0x16c>
    b8ac:      	ldrb	w9, [x3, #0x8]
    b8b0:      	tbz	w9, #0x0, 0xb8c4 <_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65+0x20>
    b8b4:      	mov	x9, #0x0                ; =0
    b8b8:      	ldr	x11, [x1]
    b8bc:      	cbnz	x11, 0xb90c <_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65+0x68>
    b8c0:      	b	0xba10 <_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65+0x16c>
    b8c4:      	ldr	x9, [x3]
    b8c8:      	ldr	x10, [x2]
    b8cc:      	eor	x9, x10, x9
    b8d0:      	eor	x9, x9, x9, lsr #30
    b8d4:      	mov	x10, #0xe5b9            ; =58809
    b8d8:      	movk	x10, #0x1ce4, lsl #16
    b8dc:      	movk	x10, #0x476d, lsl #32
    b8e0:      	movk	x10, #0xbf58, lsl #48
    b8e4:      	mul	x9, x9, x10
    b8e8:      	eor	x9, x9, x9, lsr #27
    b8ec:      	mov	x10, #0x11eb            ; =4587
    b8f0:      	movk	x10, #0x1331, lsl #16
    b8f4:      	movk	x10, #0x49bb, lsl #32
    b8f8:      	movk	x10, #0x94d0, lsl #48
    b8fc:      	mul	x9, x9, x10
    b900:      	eor	x9, x9, x9, lsr #31
    b904:      	ldr	x11, [x1]
    b908:      	cbz	x11, 0xba10 <_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65+0x16c>
    b90c:      	udiv	x10, x9, x11
    b910:      	msub	x12, x10, x11, x9
    b914:      	ldr	x13, [x1, #0x10]
    b918:      	mov	w14, #0x110             ; =272
    b91c:      	mov	x15, x11
    b920:      	b	0xb938 <_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65+0x94>
    b924:      	add	x9, x12, #0x1
    b928:      	cmp	x9, x11
    b92c:      	csinc	x12, xzr, x12, hs
    b930:      	subs	x15, x15, #0x1
    b934:      	b.eq	0xba10 <_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65+0x16c>
    b938:      	madd	x9, x12, x14, x13
    b93c:      	ldr	w10, [x9]
    b940:      	cmp	w10, #0x1
    b944:      	b.eq	0xb924 <_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65+0x80>
    b948:      	cmp	w10, #0x2
    b94c:      	b.ne	0xba10 <_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65+0x16c>
    b950:      	ldr	x10, [x9, #0x8]
    b954:      	ldr	x16, [x2]
    b958:      	cmp	x10, x16
    b95c:      	b.ne	0xb924 <_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65+0x80>
    b960:      	mov	w11, #0x1               ; =1
    b964:      	str	w11, [x9]
    b968:      	sub	x8, x8, #0x1
    b96c:      	ldp	q0, q1, [x9, #0x10]
    b970:      	ldp	q2, q3, [x9, #0x30]
    b974:      	ldp	q4, q5, [x9, #0x50]
    b978:      	ldp	q6, q7, [x9, #0x70]
    b97c:      	ldp	q16, q17, [x9, #0x90]
    b980:      	ldp	q18, q19, [x9, #0xb0]
    b984:      	ldp	q20, q21, [x9, #0xd0]
    b988:      	ldp	q22, q23, [x9, #0xf0]
    b98c:      	movi.2d	v24, #0000000000000000
    b990:      	stur	q24, [x9, #0x18]
    b994:      	stur	q24, [x9, #0x28]
    b998:      	stur	q24, [x9, #0x38]
    b99c:      	stur	q24, [x9, #0x48]
    b9a0:      	stur	q24, [x9, #0x58]
    b9a4:      	stur	q24, [x9, #0x68]
    b9a8:      	stur	q24, [x9, #0x78]
    b9ac:      	stur	q24, [x9, #0x88]
    b9b0:      	stur	q24, [x9, #0x98]
    b9b4:      	stur	q24, [x9, #0xa8]
    b9b8:      	stur	q24, [x9, #0xb8]
    b9bc:      	stur	q24, [x9, #0xc8]
    b9c0:      	stur	q24, [x9, #0xd8]
    b9c4:      	stur	q24, [x9, #0xe8]
    b9c8:      	stur	q24, [x9, #0xf8]
    b9cc:      	stur	q24, [x9, #0x8]
    b9d0:      	str	xzr, [x9, #0x108]
    b9d4:      	ldr	x9, [x1, #0x20]
    b9d8:      	adds	x9, x9, #0x1
    b9dc:      	csinv	x9, x9, xzr, lo
    b9e0:      	stp	x8, x9, [x1, #0x18]
    b9e4:      	stp	xzr, x10, [x0]
    b9e8:      	str	w11, [x0]
    b9ec:      	stp	q0, q1, [x0, #0x10]
    b9f0:      	stp	q2, q3, [x0, #0x30]
    b9f4:      	stp	q4, q5, [x0, #0x50]
    b9f8:      	stp	q6, q7, [x0, #0x70]
    b9fc:      	stp	q16, q17, [x0, #0x90]
    ba00:      	stp	q18, q19, [x0, #0xb0]
    ba04:      	stp	q20, q21, [x0, #0xd0]
    ba08:      	stp	q22, q23, [x0, #0xf0]
    ba0c:      	ret
    ba10:      	movi.2d	v0, #0000000000000000
    ba14:      	stp	q0, q0, [x0, #0xf0]
    ba18:      	stp	q0, q0, [x0, #0xd0]
    ba1c:      	stp	q0, q0, [x0, #0xb0]
    ba20:      	stp	q0, q0, [x0, #0x90]
    ba24:      	stp	q0, q0, [x0, #0x70]
    ba28:      	stp	q0, q0, [x0, #0x50]
    ba2c:      	stp	q0, q0, [x0, #0x30]
    ba30:      	stp	q0, q0, [x0, #0x10]
    ba34:      	str	q0, [x0]
    ba38:      	ret

000000000000ba3c <_wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe>:
    ba3c:      	ldrb	w8, [x2, #0x8]
    ba40:      	tbz	w8, #0x0, 0xba54 <_wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe+0x18>
    ba44:      	mov	x8, #0x0                ; =0
    ba48:      	ldr	x9, [x0]
    ba4c:      	cbnz	x9, 0xba9c <_wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe+0x60>
    ba50:      	b	0xbb04 <_wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe+0xc8>
    ba54:      	ldr	x8, [x2]
    ba58:      	ldr	x9, [x1]
    ba5c:      	eor	x8, x9, x8
    ba60:      	eor	x8, x8, x8, lsr #30
    ba64:      	mov	x9, #0xe5b9             ; =58809
    ba68:      	movk	x9, #0x1ce4, lsl #16
    ba6c:      	movk	x9, #0x476d, lsl #32
    ba70:      	movk	x9, #0xbf58, lsl #48
    ba74:      	mul	x8, x8, x9
    ba78:      	eor	x8, x8, x8, lsr #27
    ba7c:      	mov	x9, #0x11eb             ; =4587
    ba80:      	movk	x9, #0x1331, lsl #16
    ba84:      	movk	x9, #0x49bb, lsl #32
    ba88:      	movk	x9, #0x94d0, lsl #48
    ba8c:      	mul	x8, x8, x9
    ba90:      	eor	x8, x8, x8, lsr #31
    ba94:      	ldr	x9, [x0]
    ba98:      	cbz	x9, 0xbb04 <_wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe+0xc8>
    ba9c:      	udiv	x10, x8, x9
    baa0:      	msub	x10, x10, x9, x8
    baa4:      	ldr	x11, [x0, #0x10]
    baa8:      	mov	w12, #0x110             ; =272
    baac:      	mov	x13, x9
    bab0:      	b	0xbac8 <_wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe+0x8c>
    bab4:      	add	x8, x10, #0x1
    bab8:      	cmp	x8, x9
    babc:      	csinc	x10, xzr, x10, hs
    bac0:      	subs	x13, x13, #0x1
    bac4:      	b.eq	0xbb04 <_wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe+0xc8>
    bac8:      	madd	x14, x10, x12, x11
    bacc:      	ldr	w8, [x14]
    bad0:      	cmp	w8, #0x1
    bad4:      	b.eq	0xbab4 <_wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe+0x78>
    bad8:      	cmp	w8, #0x2
    badc:      	b.ne	0xbb08 <_wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe+0xcc>
    bae0:      	ldr	x8, [x14, #0x8]
    bae4:      	ldr	x15, [x1]
    bae8:      	cmp	x8, x15
    baec:      	b.ne	0xbab4 <_wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe+0x78>
    baf0:      	mov	w0, #0x0                ; =0
    baf4:      	ldr	x8, [x14, #0x10]
    baf8:      	mov	x1, x8
    bafc:      	mov	w2, #0x0                ; =0
    bb00:      	ret
    bb04:      	mov	x8, #0x0                ; =0
    bb08:      	mov	w0, #0x1                ; =1
    bb0c:      	mov	x1, x8
    bb10:      	mov	w2, #0x0                ; =0
    bb14:      	ret

000000000000bb18 <_wf_std.collections.hash_map.hash_map_rehash$instance$28da32efc51c2b65>:
    bb18:      	mov	x2, x1
    bb1c:      	ldr	x1, [x0]
    bb20:      	b	0xbb20 <_wf_std.collections.hash_map.hash_map_rehash$instance$28da32efc51c2b65+0x8>
		000000000000bb20:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65

000000000000bb24 <_wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65>:
    bb24:      	cmp	x1, #0x4, lsl #12       ; =0x4000
    bb28:      	b.ls	0xbb3c <_wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65+0x18>
    bb2c:      	mov	w2, #0x0                ; =0
    bb30:      	mov	w1, #0x0                ; =0
    bb34:      	mov	w0, #0x1                ; =1
    bb38:      	ret
    bb3c:      	ldr	x8, [x0]
    bb40:      	cmp	x1, x8
    bb44:      	b.ls	0xbb58 <_wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65+0x34>
    bb48:      	stp	x29, x30, [sp, #-0x10]!
    bb4c:      	bl	0xbb4c <_wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65+0x28>
		000000000000bb4c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    bb50:      	ldp	x29, x30, [sp], #0x10
    bb54:      	ret
    bb58:      	mov	w2, #0x0                ; =0
    bb5c:      	mov	w1, #0x0                ; =0
    bb60:      	mov	w0, #0x0                ; =0
    bb64:      	ret

000000000000bb68 <_wf_std.collections.hash_map.hash_map_capacity$instance$0e108827ecbbe374>:
    bb68:      	ldr	x0, [x0]
    bb6c:      	ret

000000000000bb70 <_wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49>:
    bb70:      	ldrb	w8, [x2, #0x8]
    bb74:      	tbz	w8, #0x0, 0xbb88 <_wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49+0x18>
    bb78:      	mov	x8, #0x0                ; =0
    bb7c:      	ldr	x9, [x0]
    bb80:      	cbnz	x9, 0xbbd0 <_wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49+0x60>
    bb84:      	b	0xbc4c <_wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49+0xdc>
    bb88:      	ldr	x8, [x2]
    bb8c:      	ldr	x9, [x1]
    bb90:      	eor	x8, x9, x8
    bb94:      	eor	x8, x8, x8, lsr #30
    bb98:      	mov	x9, #0xe5b9             ; =58809
    bb9c:      	movk	x9, #0x1ce4, lsl #16
    bba0:      	movk	x9, #0x476d, lsl #32
    bba4:      	movk	x9, #0xbf58, lsl #48
    bba8:      	mul	x8, x8, x9
    bbac:      	eor	x8, x8, x8, lsr #27
    bbb0:      	mov	x9, #0x11eb             ; =4587
    bbb4:      	movk	x9, #0x1331, lsl #16
    bbb8:      	movk	x9, #0x49bb, lsl #32
    bbbc:      	movk	x9, #0x94d0, lsl #48
    bbc0:      	mul	x8, x8, x9
    bbc4:      	eor	x8, x8, x8, lsr #31
    bbc8:      	ldr	x9, [x0]
    bbcc:      	cbz	x9, 0xbc4c <_wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49+0xdc>
    bbd0:      	mov	x10, #0x0               ; =0
    bbd4:      	udiv	x11, x8, x9
    bbd8:      	msub	x11, x11, x9, x8
    bbdc:      	sub	x12, x9, x11
    bbe0:      	neg	x13, x12
    bbe4:      	ldr	x14, [x0, #0x10]
    bbe8:      	mov	w15, #0x110             ; =272
    bbec:      	b	0xbbfc <_wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49+0x8c>
    bbf0:      	add	x10, x10, #0x1
    bbf4:      	cmp	x9, x10
    bbf8:      	b.eq	0xbc4c <_wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49+0xdc>
    bbfc:      	cmp	x10, x12
    bc00:      	csel	x8, x11, x13, lo
    bc04:      	add	x8, x8, x10
    bc08:      	madd	x16, x8, x15, x14
    bc0c:      	ldr	w8, [x16]
    bc10:      	cmp	w8, #0x1
    bc14:      	b.eq	0xbbf0 <_wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49+0x80>
    bc18:      	cmp	w8, #0x2
    bc1c:      	b.ne	0xbc50 <_wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49+0xe0>
    bc20:      	ldr	x8, [x16, #0x8]
    bc24:      	ldr	x17, [x1]
    bc28:      	cmp	x8, x17
    bc2c:      	b.ne	0xbbf0 <_wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49+0x80>
    bc30:      	mov	w0, #0x0                ; =0
    bc34:      	ldr	x8, [x16, #0x10]
    bc38:      	add	x8, x8, #0x1
    bc3c:      	str	x8, [x16, #0x10]
    bc40:      	mov	x1, x8
    bc44:      	mov	w2, #0x0                ; =0
    bc48:      	ret
    bc4c:      	mov	x8, #0x0                ; =0
    bc50:      	mov	w0, #0x1                ; =1
    bc54:      	mov	x1, x8
    bc58:      	mov	w2, #0x0                ; =0
    bc5c:      	ret

000000000000bc60 <_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71>:
    bc60:      	stp	x29, x30, [sp, #-0x10]!
    bc64:      	ldp	x9, x8, [x0]
    bc68:      	ldr	x0, [x0, #0x10]
    bc6c:      	cbz	x9, 0xbdb4 <_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71+0x154>
    bc70:      	ldp	x10, x11, [x1, #0x8]
    bc74:      	mov	w12, #0x110             ; =272
    bc78:      	madd	x13, x9, x12, x0
    bc7c:      	ldr	x12, [x1, #0x18]
    bc80:      	sub	x13, x13, #0x88
    bc84:      	mov	w14, #0x83              ; =131
    bc88:      	mov	x15, #0xe5b9            ; =58809
    bc8c:      	movk	x15, #0x1ce4, lsl #16
    bc90:      	movk	x15, #0x476d, lsl #32
    bc94:      	movk	x15, #0xbf58, lsl #48
    bc98:      	mov	x16, #0x11eb            ; =4587
    bc9c:      	movk	x16, #0x1331, lsl #16
    bca0:      	movk	x16, #0x49bb, lsl #32
    bca4:      	movk	x16, #0x94d0, lsl #48
    bca8:      	b	0xbcb8 <_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71+0x58>
    bcac:      	sub	x13, x13, #0x110
    bcb0:      	sub	x9, x9, #0x1
    bcb4:      	cbz	x9, 0xbdb4 <_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71+0x154>
    bcb8:      	ldur	w17, [x13, #-0x88]
    bcbc:      	cmp	w17, #0x2
    bcc0:      	b.ne	0xbcac <_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71+0x4c>
    bcc4:      	ldp	x2, x17, [x13, #-0x80]
    bcc8:      	madd	x17, x2, x14, x17
    bccc:      	ldp	x3, x2, [x13, #-0x70]
    bcd0:      	madd	x17, x17, x14, x3
    bcd4:      	madd	x17, x17, x14, x2
    bcd8:      	ldp	x3, x2, [x13, #-0x60]
    bcdc:      	madd	x17, x17, x14, x3
    bce0:      	madd	x17, x17, x14, x2
    bce4:      	ldp	x3, x2, [x13, #-0x50]
    bce8:      	madd	x17, x17, x14, x3
    bcec:      	madd	x17, x17, x14, x2
    bcf0:      	ldp	x3, x2, [x13, #-0x40]
    bcf4:      	madd	x17, x17, x14, x3
    bcf8:      	madd	x17, x17, x14, x2
    bcfc:      	ldp	x3, x2, [x13, #-0x30]
    bd00:      	madd	x17, x17, x14, x3
    bd04:      	madd	x17, x17, x14, x2
    bd08:      	ldp	x3, x2, [x13, #-0x20]
    bd0c:      	madd	x17, x17, x14, x3
    bd10:      	madd	x17, x17, x14, x2
    bd14:      	ldp	x3, x2, [x13, #-0x10]
    bd18:      	madd	x17, x17, x14, x3
    bd1c:      	madd	x17, x17, x14, x2
    bd20:      	ldp	x3, x2, [x13]
    bd24:      	madd	x17, x17, x14, x3
    bd28:      	madd	x17, x17, x14, x2
    bd2c:      	ldp	x3, x2, [x13, #0x10]
    bd30:      	madd	x17, x17, x14, x3
    bd34:      	madd	x17, x17, x14, x2
    bd38:      	ldp	x3, x2, [x13, #0x20]
    bd3c:      	madd	x17, x17, x14, x3
    bd40:      	madd	x17, x17, x14, x2
    bd44:      	ldp	x3, x2, [x13, #0x30]
    bd48:      	madd	x17, x17, x14, x3
    bd4c:      	madd	x17, x17, x14, x2
    bd50:      	ldp	x3, x2, [x13, #0x40]
    bd54:      	madd	x17, x17, x14, x3
    bd58:      	madd	x17, x17, x14, x2
    bd5c:      	ldp	x3, x2, [x13, #0x50]
    bd60:      	madd	x17, x17, x14, x3
    bd64:      	madd	x17, x17, x14, x2
    bd68:      	ldp	x3, x2, [x13, #0x60]
    bd6c:      	madd	x17, x17, x14, x3
    bd70:      	madd	x17, x17, x14, x2
    bd74:      	ldp	x3, x2, [x13, #0x70]
    bd78:      	madd	x17, x17, x14, x3
    bd7c:      	madd	x17, x17, x14, x2
    bd80:      	ldr	x2, [x13, #0x80]
    bd84:      	madd	x17, x17, x14, x2
    bd88:      	add	x10, x17, x10
    bd8c:      	eor	x17, x17, x17, lsr #30
    bd90:      	mul	x17, x17, x15
    bd94:      	eor	x17, x17, x17, lsr #27
    bd98:      	mul	x17, x17, x16
    bd9c:      	eor	x11, x11, x17, lsr #31
    bda0:      	eor	x11, x11, x17
    bda4:      	stp	x10, x11, [x1, #0x8]
    bda8:      	add	x12, x12, #0x1
    bdac:      	str	x12, [x1, #0x18]
    bdb0:      	b	0xbcac <_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71+0x4c>
    bdb4:      	cbz	x8, 0xbdbc <_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71+0x15c>
    bdb8:      	bl	0xbdb8 <_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71+0x158>
		000000000000bdb8:  ARM64_RELOC_BRANCH26	_free
    bdbc:      	mov	w0, #0x0                ; =0
    bdc0:      	ldp	x29, x30, [sp], #0x10
    bdc4:      	ret

000000000000bdc8 <_wf_std.collections.hash_map.hash_map_len$instance$820b2044b97e0fbd>:
    bdc8:      	ldr	x0, [x0, #0x18]
    bdcc:      	ret

000000000000bdd0 <_wf_std.collections.hash_map.hash_map_len$instance$0e108827ecbbe374>:
    bdd0:      	ldr	x0, [x0, #0x18]
    bdd4:      	ret

000000000000bdd8 <_wf_box_slots_new$instance$9c4aeb814d69349e>:
    bdd8:      	stp	x20, x19, [sp, #-0x20]!
    bddc:      	stp	x29, x30, [sp, #0x10]
    bde0:      	mov	x19, x0
    bde4:      	cbz	x0, 0xbe10 <_wf_box_slots_new$instance$9c4aeb814d69349e+0x38>
    bde8:      	add	x8, x19, x19, lsl #1
    bdec:      	lsl	x0, x8, #3
    bdf0:      	bl	0xbdf0 <_wf_box_slots_new$instance$9c4aeb814d69349e+0x18>
		000000000000bdf0:  ARM64_RELOC_BRANCH26	_malloc
    bdf4:      	mov	x2, x0
    bdf8:      	cbz	x0, 0xbe2c <_wf_box_slots_new$instance$9c4aeb814d69349e+0x54>
    bdfc:      	mov	x0, #0x0                ; =0
    be00:      	mov	x1, x19
    be04:      	ldp	x29, x30, [sp, #0x10]
    be08:      	ldp	x20, x19, [sp], #0x20
    be0c:      	ret
    be10:      	adrp	x2, 0xb000 <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567+0xa8>
		000000000000be10:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    be14:      	add	x2, x2, #0x0
		000000000000be14:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    be18:      	mov	x0, #0x0                ; =0
    be1c:      	mov	x1, x19
    be20:      	ldp	x29, x30, [sp, #0x10]
    be24:      	ldp	x20, x19, [sp], #0x20
    be28:      	ret
    be2c:      	bl	0xbe2c <_wf_box_slots_new$instance$9c4aeb814d69349e+0x54>
		000000000000be2c:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000be30 <_wf_chain_insert$instance$fc5e3cb62bdf3601>:
    be30:      	ldrb	w8, [x4, #0x8]
    be34:      	tbz	w8, #0x0, 0xbe48 <_wf_chain_insert$instance$fc5e3cb62bdf3601+0x18>
    be38:      	mov	x9, #0x0                ; =0
    be3c:      	ldr	x10, [x1]
    be40:      	cbnz	x10, 0xbe8c <_wf_chain_insert$instance$fc5e3cb62bdf3601+0x5c>
    be44:      	b	0xbe98 <_wf_chain_insert$instance$fc5e3cb62bdf3601+0x68>
    be48:      	ldr	x8, [x4]
    be4c:      	eor	x8, x8, x2
    be50:      	eor	x8, x8, x8, lsr #30
    be54:      	mov	x9, #0xe5b9             ; =58809
    be58:      	movk	x9, #0x1ce4, lsl #16
    be5c:      	movk	x9, #0x476d, lsl #32
    be60:      	movk	x9, #0xbf58, lsl #48
    be64:      	mul	x8, x8, x9
    be68:      	eor	x8, x8, x8, lsr #27
    be6c:      	mov	x9, #0x11eb             ; =4587
    be70:      	movk	x9, #0x1331, lsl #16
    be74:      	movk	x9, #0x49bb, lsl #32
    be78:      	movk	x9, #0x94d0, lsl #48
    be7c:      	mul	x8, x8, x9
    be80:      	eor	x9, x8, x8, lsr #31
    be84:      	ldr	x10, [x1]
    be88:      	cbz	x10, 0xbe98 <_wf_chain_insert$instance$fc5e3cb62bdf3601+0x68>
    be8c:      	ldp	x8, x11, [x1, #0x18]
    be90:      	cmp	x8, x11
    be94:      	b.ne	0xbeac <_wf_chain_insert$instance$fc5e3cb62bdf3601+0x7c>
    be98:      	stp	xzr, x2, [x0]
    be9c:      	mov	w8, #0x1                ; =1
    bea0:      	str	w8, [x0]
    bea4:      	str	x3, [x0, #0x10]
    bea8:      	ret
    beac:      	udiv	x11, x9, x10
    beb0:      	msub	x9, x11, x10, x9
    beb4:      	ldr	x10, [x1, #0x10]
    beb8:      	ldr	x11, [x10, x9, lsl #3]
    bebc:      	ldr	x12, [x1, #0x28]
    bec0:      	mov	w13, #0x18              ; =24
    bec4:      	madd	x12, x8, x13, x12
    bec8:      	stp	x2, x3, [x12]
    becc:      	str	x11, [x12, #0x10]
    bed0:      	add	x11, x8, #0x1
    bed4:      	str	x11, [x1, #0x18]
    bed8:      	str	x8, [x10, x9, lsl #3]
    bedc:      	stp	xzr, xzr, [x0]
    bee0:      	str	xzr, [x0, #0x10]
    bee4:      	ret

000000000000bee8 <_wf_chain_lookup$instance$b1b46ac9d1583c8f>:
    bee8:      	ldrb	w8, [x2, #0x8]
    beec:      	tbz	w8, #0x0, 0xbf00 <_wf_chain_lookup$instance$b1b46ac9d1583c8f+0x18>
    bef0:      	mov	x9, #0x0                ; =0
    bef4:      	ldr	x10, [x0]
    bef8:      	cbnz	x10, 0xbf48 <_wf_chain_lookup$instance$b1b46ac9d1583c8f+0x60>
    befc:      	b	0xbf98 <_wf_chain_lookup$instance$b1b46ac9d1583c8f+0xb0>
    bf00:      	ldr	x8, [x2]
    bf04:      	ldr	x9, [x1]
    bf08:      	eor	x8, x9, x8
    bf0c:      	eor	x8, x8, x8, lsr #30
    bf10:      	mov	x9, #0xe5b9             ; =58809
    bf14:      	movk	x9, #0x1ce4, lsl #16
    bf18:      	movk	x9, #0x476d, lsl #32
    bf1c:      	movk	x9, #0xbf58, lsl #48
    bf20:      	mul	x8, x8, x9
    bf24:      	eor	x8, x8, x8, lsr #27
    bf28:      	mov	x9, #0x11eb             ; =4587
    bf2c:      	movk	x9, #0x1331, lsl #16
    bf30:      	movk	x9, #0x49bb, lsl #32
    bf34:      	movk	x9, #0x94d0, lsl #48
    bf38:      	mul	x8, x8, x9
    bf3c:      	eor	x9, x8, x8, lsr #31
    bf40:      	ldr	x10, [x0]
    bf44:      	cbz	x10, 0xbf98 <_wf_chain_lookup$instance$b1b46ac9d1583c8f+0xb0>
    bf48:      	ldr	x8, [x0, #0x18]
    bf4c:      	cbz	x8, 0xbf98 <_wf_chain_lookup$instance$b1b46ac9d1583c8f+0xb0>
    bf50:      	udiv	x11, x9, x10
    bf54:      	msub	x9, x11, x10, x9
    bf58:      	ldr	x10, [x0, #0x10]
    bf5c:      	add	x11, x10, x9, lsl #3
    bf60:      	mov	w9, #0x18               ; =24
    bf64:      	mov	x10, x8
    bf68:      	ldr	x11, [x11]
    bf6c:      	cmp	x11, x8
    bf70:      	b.hs	0xbf98 <_wf_chain_lookup$instance$b1b46ac9d1583c8f+0xb0>
    bf74:      	ldr	x12, [x0, #0x28]
    bf78:      	madd	x11, x11, x9, x12
    bf7c:      	ldr	x12, [x11]
    bf80:      	ldr	x13, [x1]
    bf84:      	cmp	x12, x13
    bf88:      	b.eq	0xbfa8 <_wf_chain_lookup$instance$b1b46ac9d1583c8f+0xc0>
    bf8c:      	add	x11, x11, #0x10
    bf90:      	subs	x10, x10, #0x1
    bf94:      	b.ne	0xbf68 <_wf_chain_lookup$instance$b1b46ac9d1583c8f+0x80>
    bf98:      	mov	x1, #0x0                ; =0
    bf9c:      	mov	w0, #0x1                ; =1
    bfa0:      	mov	w2, #0x0                ; =0
    bfa4:      	ret
    bfa8:      	mov	w0, #0x0                ; =0
    bfac:      	ldr	x1, [x11, #0x8]
    bfb0:      	mov	w2, #0x0                ; =0
    bfb4:      	ret

000000000000bfb8 <_wf_box_slots_new$instance$1883e0e22b50fc85>:
    bfb8:      	stp	x20, x19, [sp, #-0x20]!
    bfbc:      	stp	x29, x30, [sp, #0x10]
    bfc0:      	mov	x19, x0
    bfc4:      	cbz	x0, 0xbff0 <_wf_box_slots_new$instance$1883e0e22b50fc85+0x38>
    bfc8:      	add	x8, x19, x19, lsl #4
    bfcc:      	lsl	x0, x8, #4
    bfd0:      	bl	0xbfd0 <_wf_box_slots_new$instance$1883e0e22b50fc85+0x18>
		000000000000bfd0:  ARM64_RELOC_BRANCH26	_malloc
    bfd4:      	mov	x2, x0
    bfd8:      	cbz	x0, 0xc00c <_wf_box_slots_new$instance$1883e0e22b50fc85+0x54>
    bfdc:      	mov	x0, #0x0                ; =0
    bfe0:      	mov	x1, x19
    bfe4:      	ldp	x29, x30, [sp, #0x10]
    bfe8:      	ldp	x20, x19, [sp], #0x20
    bfec:      	ret
    bff0:      	adrp	x2, 0xb000 <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567+0xa8>
		000000000000bff0:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    bff4:      	add	x2, x2, #0x0
		000000000000bff4:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    bff8:      	mov	x0, #0x0                ; =0
    bffc:      	mov	x1, x19
    c000:      	ldp	x29, x30, [sp, #0x10]
    c004:      	ldp	x20, x19, [sp], #0x20
    c008:      	ret
    c00c:      	bl	0xc00c <_wf_box_slots_new$instance$1883e0e22b50fc85+0x54>
		000000000000c00c:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000c010 <_wf_chain_insert$instance$c6df3d8464f8cde0>:
    c010:      	sub	sp, sp, #0x150
    c014:      	stp	x28, x27, [sp, #0xf0]
    c018:      	stp	x26, x25, [sp, #0x100]
    c01c:      	stp	x24, x23, [sp, #0x110]
    c020:      	stp	x22, x21, [sp, #0x120]
    c024:      	stp	x20, x19, [sp, #0x130]
    c028:      	stp	x29, x30, [sp, #0x140]
    c02c:      	ldrb	w8, [x4, #0x8]
    c030:      	str	x2, [sp, #0xd8]
    c034:      	tbz	w8, #0x0, 0xc040 <_wf_chain_insert$instance$c6df3d8464f8cde0+0x30>
    c038:      	str	xzr, [sp, #0xb0]
    c03c:      	b	0xc080 <_wf_chain_insert$instance$c6df3d8464f8cde0+0x70>
    c040:      	ldr	x8, [x4]
    c044:      	eor	x8, x8, x2
    c048:      	eor	x8, x8, x8, lsr #30
    c04c:      	mov	x9, #0xe5b9             ; =58809
    c050:      	movk	x9, #0x1ce4, lsl #16
    c054:      	movk	x9, #0x476d, lsl #32
    c058:      	movk	x9, #0xbf58, lsl #48
    c05c:      	mul	x8, x8, x9
    c060:      	eor	x8, x8, x8, lsr #27
    c064:      	mov	x9, #0x11eb             ; =4587
    c068:      	movk	x9, #0x1331, lsl #16
    c06c:      	movk	x9, #0x49bb, lsl #32
    c070:      	movk	x9, #0x94d0, lsl #48
    c074:      	mul	x8, x8, x9
    c078:      	eor	x8, x8, x8, lsr #31
    c07c:      	str	x8, [sp, #0xb0]
    c080:      	ldp	x2, x17, [x3]
    c084:      	ldp	x13, x11, [x3, #0x10]
    c088:      	ldp	x10, x8, [x3, #0x20]
    c08c:      	str	x8, [sp, #0xb8]
    c090:      	ldp	x8, x9, [x3, #0x30]
    c094:      	str	x9, [sp, #0xc0]
    c098:      	ldp	x14, x9, [x3, #0x40]
    c09c:      	str	x9, [sp, #0xc8]
    c0a0:      	ldp	x12, x9, [x3, #0x50]
    c0a4:      	str	x9, [sp, #0xd0]
    c0a8:      	ldp	x15, x9, [x3, #0x60]
    c0ac:      	str	x9, [sp, #0xe0]
    c0b0:      	ldp	x9, x16, [x3, #0x70]
    c0b4:      	str	x16, [sp, #0xe8]
    c0b8:      	ldp	x30, x28, [x3, #0x80]
    c0bc:      	ldp	x27, x26, [x3, #0x90]
    c0c0:      	ldp	x25, x24, [x3, #0xa0]
    c0c4:      	ldp	x23, x22, [x3, #0xb0]
    c0c8:      	ldp	x21, x20, [x3, #0xc0]
    c0cc:      	ldp	x19, x7, [x3, #0xd0]
    c0d0:      	ldp	x6, x5, [x3, #0xe0]
    c0d4:      	ldp	x4, x3, [x3, #0xf0]
    c0d8:      	ldr	x16, [x1]
    c0dc:      	cbz	x16, 0xc1b0 <_wf_chain_insert$instance$c6df3d8464f8cde0+0x1a0>
    c0e0:      	stp	x17, x8, [sp, #0x8]
    c0e4:      	stp	x12, x15, [sp, #0x18]
    c0e8:      	stp	x9, x30, [sp, #0x28]
    c0ec:      	stp	x28, x27, [sp, #0x38]
    c0f0:      	stp	x26, x25, [sp, #0x48]
    c0f4:      	stp	x24, x23, [sp, #0x58]
    c0f8:      	stp	x22, x21, [sp, #0x68]
    c0fc:      	stp	x20, x19, [sp, #0x78]
    c100:      	stp	x7, x6, [sp, #0x88]
    c104:      	stp	x5, x4, [sp, #0x98]
    c108:      	str	x3, [sp, #0xa8]
    c10c:      	ldp	x3, x17, [x1, #0x18]
    c110:      	cmp	x3, x17
    c114:      	b.ne	0xc21c <_wf_chain_insert$instance$c6df3d8464f8cde0+0x20c>
    c118:      	ldp	x8, x9, [sp, #0x8]
    c11c:      	stp	x2, x8, [x0, #0x10]
    c120:      	stp	x13, x11, [x0, #0x20]
    c124:      	str	xzr, [x0]
    c128:      	mov	w11, #0x1               ; =1
    c12c:      	str	w11, [x0]
    c130:      	ldr	x8, [sp, #0xd8]
    c134:      	str	x8, [x0, #0x8]
    c138:      	ldr	x8, [sp, #0xb8]
    c13c:      	stp	x10, x8, [x0, #0x30]
    c140:      	ldp	x10, x8, [sp, #0xc0]
    c144:      	stp	x9, x10, [x0, #0x40]
    c148:      	stp	x14, x8, [x0, #0x50]
    c14c:      	ldr	x9, [sp, #0x18]
    c150:      	ldr	x8, [sp, #0xd0]
    c154:      	stp	x9, x8, [x0, #0x60]
    c158:      	ldr	x9, [sp, #0x20]
    c15c:      	ldp	x10, x8, [sp, #0xe0]
    c160:      	stp	x9, x10, [x0, #0x70]
    c164:      	ldr	x9, [sp, #0x28]
    c168:      	stp	x9, x8, [x0, #0x80]
    c16c:      	ldp	x9, x8, [sp, #0x30]
    c170:      	stp	x9, x8, [x0, #0x90]
    c174:      	ldp	x9, x8, [sp, #0x40]
    c178:      	stp	x9, x8, [x0, #0xa0]
    c17c:      	ldp	x9, x8, [sp, #0x50]
    c180:      	stp	x9, x8, [x0, #0xb0]
    c184:      	ldp	x9, x8, [sp, #0x60]
    c188:      	stp	x9, x8, [x0, #0xc0]
    c18c:      	ldp	x9, x8, [sp, #0x70]
    c190:      	stp	x9, x8, [x0, #0xd0]
    c194:      	ldp	x9, x8, [sp, #0x80]
    c198:      	stp	x9, x8, [x0, #0xe0]
    c19c:      	ldp	x9, x8, [sp, #0x90]
    c1a0:      	stp	x9, x8, [x0, #0xf0]
    c1a4:      	ldp	x9, x8, [sp, #0xa0]
    c1a8:      	stp	x9, x8, [x0, #0x100]
    c1ac:      	b	0xc300 <_wf_chain_insert$instance$c6df3d8464f8cde0+0x2f0>
    c1b0:      	stp	x2, x17, [x0, #0x10]
    c1b4:      	stp	x13, x11, [x0, #0x20]
    c1b8:      	str	xzr, [x0]
    c1bc:      	mov	w11, #0x1               ; =1
    c1c0:      	str	w11, [x0]
    c1c4:      	ldr	x11, [sp, #0xd8]
    c1c8:      	str	x11, [x0, #0x8]
    c1cc:      	str	x10, [x0, #0x30]
    c1d0:      	ldr	x10, [sp, #0xb8]
    c1d4:      	stp	x10, x8, [x0, #0x38]
    c1d8:      	ldp	x10, x8, [sp, #0xc0]
    c1dc:      	stp	x10, x14, [x0, #0x48]
    c1e0:      	stp	x8, x12, [x0, #0x58]
    c1e4:      	ldr	x8, [sp, #0xd0]
    c1e8:      	stp	x8, x15, [x0, #0x68]
    c1ec:      	ldp	x10, x8, [sp, #0xe0]
    c1f0:      	stp	x10, x9, [x0, #0x78]
    c1f4:      	stp	x8, x30, [x0, #0x88]
    c1f8:      	stp	x28, x27, [x0, #0x98]
    c1fc:      	stp	x26, x25, [x0, #0xa8]
    c200:      	stp	x24, x23, [x0, #0xb8]
    c204:      	stp	x22, x21, [x0, #0xc8]
    c208:      	stp	x20, x19, [x0, #0xd8]
    c20c:      	stp	x7, x6, [x0, #0xe8]
    c210:      	stp	x5, x4, [x0, #0xf8]
    c214:      	str	x3, [x0, #0x108]
    c218:      	b	0xc300 <_wf_chain_insert$instance$c6df3d8464f8cde0+0x2f0>
    c21c:      	ldr	x8, [sp, #0xb0]
    c220:      	udiv	x17, x8, x16
    c224:      	msub	x15, x17, x16, x8
    c228:      	ldr	x16, [x1, #0x28]
    c22c:      	mov	w17, #0x110             ; =272
    c230:      	madd	x16, x3, x17, x16
    c234:      	ldr	x17, [x1, #0x10]
    c238:      	ldr	x9, [x17, x15, lsl #3]
    c23c:      	ldr	x8, [sp, #0xd8]
    c240:      	stp	x8, x2, [x16]
    c244:      	ldr	x8, [sp, #0x8]
    c248:      	stp	x8, x13, [x16, #0x10]
    c24c:      	stp	x11, x10, [x16, #0x20]
    c250:      	ldr	x10, [sp, #0xb8]
    c254:      	ldr	x8, [sp, #0x10]
    c258:      	stp	x10, x8, [x16, #0x30]
    c25c:      	ldp	x10, x11, [sp, #0xc0]
    c260:      	stp	x10, x14, [x16, #0x40]
    c264:      	ldr	x8, [sp, #0x18]
    c268:      	stp	x11, x8, [x16, #0x50]
    c26c:      	ldr	x10, [sp, #0xd0]
    c270:      	ldp	x11, x8, [sp, #0x20]
    c274:      	stp	x10, x11, [x16, #0x60]
    c278:      	ldr	x10, [sp, #0xe0]
    c27c:      	stp	x10, x8, [x16, #0x70]
    c280:      	ldr	x10, [sp, #0xe8]
    c284:      	ldp	x11, x8, [sp, #0x30]
    c288:      	stp	x10, x11, [x16, #0x80]
    c28c:      	str	x8, [x16, #0x90]
    c290:      	ldp	x10, x8, [sp, #0x40]
    c294:      	stp	x10, x8, [x16, #0x98]
    c298:      	ldp	x10, x8, [sp, #0x50]
    c29c:      	stp	x10, x8, [x16, #0xa8]
    c2a0:      	ldp	x10, x8, [sp, #0x60]
    c2a4:      	stp	x10, x8, [x16, #0xb8]
    c2a8:      	ldp	x10, x8, [sp, #0x70]
    c2ac:      	stp	x10, x8, [x16, #0xc8]
    c2b0:      	ldp	x10, x8, [sp, #0x80]
    c2b4:      	stp	x10, x8, [x16, #0xd8]
    c2b8:      	ldp	x10, x8, [sp, #0x90]
    c2bc:      	stp	x10, x8, [x16, #0xe8]
    c2c0:      	ldp	x10, x8, [sp, #0xa0]
    c2c4:      	stp	x10, x8, [x16, #0xf8]
    c2c8:      	str	x9, [x16, #0x108]
    c2cc:      	str	x3, [x17, x15, lsl #3]
    c2d0:      	add	x8, x3, #0x1
    c2d4:      	str	x8, [x1, #0x18]
    c2d8:      	movi.2d	v0, #0000000000000000
    c2dc:      	stp	q0, q0, [x0]
    c2e0:      	stp	q0, q0, [x0, #0x20]
    c2e4:      	stp	q0, q0, [x0, #0x40]
    c2e8:      	stp	q0, q0, [x0, #0x60]
    c2ec:      	stp	q0, q0, [x0, #0x80]
    c2f0:      	stp	q0, q0, [x0, #0xa0]
    c2f4:      	stp	q0, q0, [x0, #0xc0]
    c2f8:      	stp	q0, q0, [x0, #0xe0]
    c2fc:      	str	q0, [x0, #0x100]
    c300:      	ldp	x29, x30, [sp, #0x140]
    c304:      	ldp	x20, x19, [sp, #0x130]
    c308:      	ldp	x22, x21, [sp, #0x120]
    c30c:      	ldp	x24, x23, [sp, #0x110]
    c310:      	ldp	x26, x25, [sp, #0x100]
    c314:      	ldp	x28, x27, [sp, #0xf0]
    c318:      	add	sp, sp, #0x150
    c31c:      	ret

000000000000c320 <_wf_chain_lookup$instance$0aacc27190a3eaff>:
    c320:      	ldrb	w8, [x2, #0x8]
    c324:      	tbz	w8, #0x0, 0xc338 <_wf_chain_lookup$instance$0aacc27190a3eaff+0x18>
    c328:      	mov	x9, #0x0                ; =0
    c32c:      	ldr	x10, [x0]
    c330:      	cbnz	x10, 0xc380 <_wf_chain_lookup$instance$0aacc27190a3eaff+0x60>
    c334:      	b	0xc3d0 <_wf_chain_lookup$instance$0aacc27190a3eaff+0xb0>
    c338:      	ldr	x8, [x2]
    c33c:      	ldr	x9, [x1]
    c340:      	eor	x8, x9, x8
    c344:      	eor	x8, x8, x8, lsr #30
    c348:      	mov	x9, #0xe5b9             ; =58809
    c34c:      	movk	x9, #0x1ce4, lsl #16
    c350:      	movk	x9, #0x476d, lsl #32
    c354:      	movk	x9, #0xbf58, lsl #48
    c358:      	mul	x8, x8, x9
    c35c:      	eor	x8, x8, x8, lsr #27
    c360:      	mov	x9, #0x11eb             ; =4587
    c364:      	movk	x9, #0x1331, lsl #16
    c368:      	movk	x9, #0x49bb, lsl #32
    c36c:      	movk	x9, #0x94d0, lsl #48
    c370:      	mul	x8, x8, x9
    c374:      	eor	x9, x8, x8, lsr #31
    c378:      	ldr	x10, [x0]
    c37c:      	cbz	x10, 0xc3d0 <_wf_chain_lookup$instance$0aacc27190a3eaff+0xb0>
    c380:      	ldr	x8, [x0, #0x18]
    c384:      	cbz	x8, 0xc3d0 <_wf_chain_lookup$instance$0aacc27190a3eaff+0xb0>
    c388:      	udiv	x11, x9, x10
    c38c:      	msub	x9, x11, x10, x9
    c390:      	ldr	x10, [x0, #0x10]
    c394:      	add	x11, x10, x9, lsl #3
    c398:      	mov	w9, #0x110              ; =272
    c39c:      	mov	x10, x8
    c3a0:      	ldr	x11, [x11]
    c3a4:      	cmp	x11, x8
    c3a8:      	b.hs	0xc3d0 <_wf_chain_lookup$instance$0aacc27190a3eaff+0xb0>
    c3ac:      	ldr	x12, [x0, #0x28]
    c3b0:      	madd	x11, x11, x9, x12
    c3b4:      	ldr	x12, [x11]
    c3b8:      	ldr	x13, [x1]
    c3bc:      	cmp	x12, x13
    c3c0:      	b.eq	0xc3e0 <_wf_chain_lookup$instance$0aacc27190a3eaff+0xc0>
    c3c4:      	add	x11, x11, #0x108
    c3c8:      	subs	x10, x10, #0x1
    c3cc:      	b.ne	0xc3a0 <_wf_chain_lookup$instance$0aacc27190a3eaff+0x80>
    c3d0:      	mov	x1, #0x0                ; =0
    c3d4:      	mov	w0, #0x1                ; =1
    c3d8:      	mov	w2, #0x0                ; =0
    c3dc:      	ret
    c3e0:      	mov	w0, #0x0                ; =0
    c3e4:      	ldr	x1, [x11, #0x8]
    c3e8:      	mov	w2, #0x0                ; =0
    c3ec:      	ret

000000000000c3f0 <_wf_std.collections.hash_map.hash_map_new$instance$e85fc351f8333b14>:
    c3f0:      	stp	x20, x19, [sp, #-0x20]!
    c3f4:      	stp	x29, x30, [sp, #0x10]
    c3f8:      	mov	x20, x1
    c3fc:      	mov	x19, x0
    c400:      	cbz	x1, 0xc448 <_wf_std.collections.hash_map.hash_map_new$instance$e85fc351f8333b14+0x58>
    c404:      	add	x8, x20, x20, lsl #1
    c408:      	lsl	x0, x8, #3
    c40c:      	bl	0xc40c <_wf_std.collections.hash_map.hash_map_new$instance$e85fc351f8333b14+0x1c>
		000000000000c40c:  ARM64_RELOC_BRANCH26	_malloc
    c410:      	cbz	x0, 0xc468 <_wf_std.collections.hash_map.hash_map_new$instance$e85fc351f8333b14+0x78>
    c414:      	mov	x8, #0x0                ; =0
    c418:      	add	x9, x0, #0x8
    c41c:      	stur	wzr, [x9, #-0x8]
    c420:      	add	x8, x8, #0x1
    c424:      	stp	xzr, xzr, [x9], #0x18
    c428:      	cmp	x20, x8
    c42c:      	b.ne	0xc41c <_wf_std.collections.hash_map.hash_map_new$instance$e85fc351f8333b14+0x2c>
    c430:      	stp	x20, x20, [x19]
    c434:      	stp	xzr, xzr, [x19, #0x18]
    c438:      	str	x0, [x19, #0x10]
    c43c:      	ldp	x29, x30, [sp, #0x10]
    c440:      	ldp	x20, x19, [sp], #0x20
    c444:      	ret
    c448:      	adrp	x0, 0xc000 <_wf_box_slots_new$instance$1883e0e22b50fc85+0x48>
		000000000000c448:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    c44c:      	add	x0, x0, #0x0
		000000000000c44c:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    c450:      	stp	x20, x20, [x19]
    c454:      	stp	xzr, xzr, [x19, #0x18]
    c458:      	str	x0, [x19, #0x10]
    c45c:      	ldp	x29, x30, [sp, #0x10]
    c460:      	ldp	x20, x19, [sp], #0x20
    c464:      	ret
    c468:      	bl	0xc468 <_wf_std.collections.hash_map.hash_map_new$instance$e85fc351f8333b14+0x78>
		000000000000c468:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000c46c <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e>:
    c46c:      	ldrb	w8, [x4, #0x8]
    c470:      	tbz	w8, #0x0, 0xc4fc <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x90>
    c474:      	mov	x9, #0x0                ; =0
    c478:      	ldr	x8, [x1]
    c47c:      	cbz	x8, 0xc540 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0xd4>
    c480:      	udiv	x10, x9, x8
    c484:      	msub	x10, x10, x8, x9
    c488:      	ldr	x11, [x1, #0x10]
    c48c:      	mov	w12, #0x18              ; =24
    c490:      	mov	x13, x8
    c494:      	mov	x9, x8
    c498:      	b	0xc4b8 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x4c>
    c49c:      	cmp	x9, x8
    c4a0:      	csel	x9, x10, x9, eq
    c4a4:      	add	x14, x10, #0x1
    c4a8:      	cmp	x14, x8
    c4ac:      	csinc	x10, xzr, x10, hs
    c4b0:      	subs	x13, x13, #0x1
    c4b4:      	b.eq	0xc544 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0xd8>
    c4b8:      	madd	x14, x10, x12, x11
    c4bc:      	ldr	w15, [x14]
    c4c0:      	cmp	w15, #0x1
    c4c4:      	b.eq	0xc49c <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x30>
    c4c8:      	cmp	w15, #0x2
    c4cc:      	b.ne	0xc5a0 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x134>
    c4d0:      	ldr	x15, [x14, #0x8]
    c4d4:      	cmp	x15, x2
    c4d8:      	b.ne	0xc4a4 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x38>
    c4dc:      	ldr	x8, [x14, #0x10]
    c4e0:      	mov	w9, #0x2                ; =2
    c4e4:      	str	w9, [x14]
    c4e8:      	str	x3, [x14, #0x10]
    c4ec:      	mov	w9, #0x1                ; =1
    c4f0:      	stp	x9, x2, [x0]
    c4f4:      	str	x8, [x0, #0x10]
    c4f8:      	ret
    c4fc:      	ldr	x8, [x4]
    c500:      	eor	x8, x8, x2
    c504:      	eor	x8, x8, x8, lsr #30
    c508:      	mov	x9, #0xe5b9             ; =58809
    c50c:      	movk	x9, #0x1ce4, lsl #16
    c510:      	movk	x9, #0x476d, lsl #32
    c514:      	movk	x9, #0xbf58, lsl #48
    c518:      	mul	x8, x8, x9
    c51c:      	eor	x8, x8, x8, lsr #27
    c520:      	mov	x9, #0x11eb             ; =4587
    c524:      	movk	x9, #0x1331, lsl #16
    c528:      	movk	x9, #0x49bb, lsl #32
    c52c:      	movk	x9, #0x94d0, lsl #48
    c530:      	mul	x8, x8, x9
    c534:      	eor	x9, x8, x8, lsr #31
    c538:      	ldr	x8, [x1]
    c53c:      	cbnz	x8, 0xc480 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x14>
    c540:      	mov	x9, #0x0                ; =0
    c544:      	cmp	x9, x8
    c548:      	b.hs	0xc5b0 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x144>
    c54c:      	ldr	x8, [x1, #0x18]
    c550:      	lsr	x10, x8, #13
    c554:      	cbnz	x10, 0xc5b0 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x144>
    c558:      	add	x8, x8, #0x1
    c55c:      	str	x8, [x1, #0x18]
    c560:      	ldr	x8, [x1, #0x10]
    c564:      	mov	w10, #0x18              ; =24
    c568:      	madd	x8, x9, x10, x8
    c56c:      	ldr	w9, [x8]
    c570:      	cmp	w9, #0x1
    c574:      	b.ne	0xc5c8 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x15c>
    c578:      	ldr	x9, [x1, #0x20]
    c57c:      	subs	x9, x9, #0x1
    c580:      	csel	x9, xzr, x9, lo
    c584:      	str	x9, [x1, #0x20]
    c588:      	mov	w9, #0x2                ; =2
    c58c:      	str	w9, [x8]
    c590:      	stp	x2, x3, [x8, #0x8]
    c594:      	stp	xzr, xzr, [x0, #0x8]
    c598:      	str	xzr, [x0]
    c59c:      	ret
    c5a0:      	cmp	x9, x8
    c5a4:      	csel	x9, x10, x9, eq
    c5a8:      	cmp	x9, x8
    c5ac:      	b.lo	0xc54c <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0xe0>
    c5b0:      	stp	xzr, x2, [x0]
    c5b4:      	mov	w8, #0x1                ; =1
    c5b8:      	str	w8, [x0]
    c5bc:      	strb	w8, [x0, #0x4]
    c5c0:      	str	x3, [x0, #0x10]
    c5c4:      	ret
    c5c8:      	ldur	q0, [x8, #0x8]
    c5cc:      	mov	w10, #0x2               ; =2
    c5d0:      	str	w10, [x8]
    c5d4:      	stp	x2, x3, [x8, #0x8]
    c5d8:      	cbz	w9, 0xc5ec <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x180>
    c5dc:      	mov	w8, #0x1                ; =1
    c5e0:      	str	x8, [x0]
    c5e4:      	stur	q0, [x0, #0x8]
    c5e8:      	ret
    c5ec:      	stp	xzr, xzr, [x0]
    c5f0:      	str	xzr, [x0, #0x10]
    c5f4:      	ret

000000000000c5f8 <_wf_std.collections.hash_map.hash_map_remove$instance$29255544f66aec6e>:
    c5f8:      	ldr	x10, [x0, #0x18]
    c5fc:      	cbz	x10, 0xc6e4 <_wf_std.collections.hash_map.hash_map_remove$instance$29255544f66aec6e+0xec>
    c600:      	ldrb	w8, [x2, #0x8]
    c604:      	tbz	w8, #0x0, 0xc618 <_wf_std.collections.hash_map.hash_map_remove$instance$29255544f66aec6e+0x20>
    c608:      	mov	x8, #0x0                ; =0
    c60c:      	ldr	x11, [x0]
    c610:      	cbnz	x11, 0xc660 <_wf_std.collections.hash_map.hash_map_remove$instance$29255544f66aec6e+0x68>
    c614:      	b	0xc6e4 <_wf_std.collections.hash_map.hash_map_remove$instance$29255544f66aec6e+0xec>
    c618:      	ldr	x8, [x2]
    c61c:      	ldr	x9, [x1]
    c620:      	eor	x8, x9, x8
    c624:      	eor	x8, x8, x8, lsr #30
    c628:      	mov	x9, #0xe5b9             ; =58809
    c62c:      	movk	x9, #0x1ce4, lsl #16
    c630:      	movk	x9, #0x476d, lsl #32
    c634:      	movk	x9, #0xbf58, lsl #48
    c638:      	mul	x8, x8, x9
    c63c:      	eor	x8, x8, x8, lsr #27
    c640:      	mov	x9, #0x11eb             ; =4587
    c644:      	movk	x9, #0x1331, lsl #16
    c648:      	movk	x9, #0x49bb, lsl #32
    c64c:      	movk	x9, #0x94d0, lsl #48
    c650:      	mul	x8, x8, x9
    c654:      	eor	x8, x8, x8, lsr #31
    c658:      	ldr	x11, [x0]
    c65c:      	cbz	x11, 0xc6e4 <_wf_std.collections.hash_map.hash_map_remove$instance$29255544f66aec6e+0xec>
    c660:      	udiv	x9, x8, x11
    c664:      	msub	x12, x9, x11, x8
    c668:      	ldr	x13, [x0, #0x10]
    c66c:      	mov	w14, #0x18              ; =24
    c670:      	mov	x15, x11
    c674:      	b	0xc68c <_wf_std.collections.hash_map.hash_map_remove$instance$29255544f66aec6e+0x94>
    c678:      	add	x8, x12, #0x1
    c67c:      	cmp	x8, x11
    c680:      	csinc	x12, xzr, x12, hs
    c684:      	subs	x15, x15, #0x1
    c688:      	b.eq	0xc6e4 <_wf_std.collections.hash_map.hash_map_remove$instance$29255544f66aec6e+0xec>
    c68c:      	madd	x16, x12, x14, x13
    c690:      	ldr	w8, [x16]
    c694:      	cmp	w8, #0x1
    c698:      	b.eq	0xc678 <_wf_std.collections.hash_map.hash_map_remove$instance$29255544f66aec6e+0x80>
    c69c:      	cmp	w8, #0x2
    c6a0:      	b.ne	0xc6fc <_wf_std.collections.hash_map.hash_map_remove$instance$29255544f66aec6e+0x104>
    c6a4:      	ldr	x9, [x16, #0x8]
    c6a8:      	ldr	x8, [x1]
    c6ac:      	cmp	x9, x8
    c6b0:      	b.ne	0xc678 <_wf_std.collections.hash_map.hash_map_remove$instance$29255544f66aec6e+0x80>
    c6b4:      	ldr	x2, [x16, #0x10]
    c6b8:      	mov	w8, #0x1                ; =1
    c6bc:      	str	w8, [x16]
    c6c0:      	sub	x10, x10, #0x1
    c6c4:      	stp	xzr, xzr, [x16, #0x8]
    c6c8:      	ldr	x11, [x0, #0x20]
    c6cc:      	adds	x11, x11, #0x1
    c6d0:      	csinv	x11, x11, xzr, lo
    c6d4:      	stp	x10, x11, [x0, #0x18]
    c6d8:      	mov	x0, x8
    c6dc:      	mov	x1, x9
    c6e0:      	ret
    c6e4:      	mov	w8, #0x0                ; =0
    c6e8:      	mov	x9, #0x0                ; =0
    c6ec:      	mov	x2, #0x0                ; =0
    c6f0:      	mov	x0, x8
    c6f4:      	mov	x1, x9
    c6f8:      	ret
    c6fc:      	mov	x9, x8
    c700:      	mov	x2, x8
    c704:      	mov	x0, x8
    c708:      	mov	x1, x9
    c70c:      	ret

000000000000c710 <_wf_std.collections.hash_map.hash_map_capacity$instance$e85fc351f8333b14>:
    c710:      	ldr	x0, [x0]
    c714:      	ret

000000000000c718 <_wf_std.collections.hash_map.hash_map_len$instance$e85fc351f8333b14>:
    c718:      	ldr	x0, [x0, #0x18]
    c71c:      	ret

000000000000c720 <_wf_std.collections.hash_map.hash_map_lookup$instance$7c9d455aedf48152>:
    c720:      	ldrb	w8, [x2, #0x8]
    c724:      	tbz	w8, #0x0, 0xc738 <_wf_std.collections.hash_map.hash_map_lookup$instance$7c9d455aedf48152+0x18>
    c728:      	mov	x8, #0x0                ; =0
    c72c:      	ldr	x9, [x0]
    c730:      	cbnz	x9, 0xc780 <_wf_std.collections.hash_map.hash_map_lookup$instance$7c9d455aedf48152+0x60>
    c734:      	b	0xc7e8 <_wf_std.collections.hash_map.hash_map_lookup$instance$7c9d455aedf48152+0xc8>
    c738:      	ldr	x8, [x2]
    c73c:      	ldr	x9, [x1]
    c740:      	eor	x8, x9, x8
    c744:      	eor	x8, x8, x8, lsr #30
    c748:      	mov	x9, #0xe5b9             ; =58809
    c74c:      	movk	x9, #0x1ce4, lsl #16
    c750:      	movk	x9, #0x476d, lsl #32
    c754:      	movk	x9, #0xbf58, lsl #48
    c758:      	mul	x8, x8, x9
    c75c:      	eor	x8, x8, x8, lsr #27
    c760:      	mov	x9, #0x11eb             ; =4587
    c764:      	movk	x9, #0x1331, lsl #16
    c768:      	movk	x9, #0x49bb, lsl #32
    c76c:      	movk	x9, #0x94d0, lsl #48
    c770:      	mul	x8, x8, x9
    c774:      	eor	x8, x8, x8, lsr #31
    c778:      	ldr	x9, [x0]
    c77c:      	cbz	x9, 0xc7e8 <_wf_std.collections.hash_map.hash_map_lookup$instance$7c9d455aedf48152+0xc8>
    c780:      	udiv	x10, x8, x9
    c784:      	msub	x10, x10, x9, x8
    c788:      	ldr	x11, [x0, #0x10]
    c78c:      	mov	w12, #0x18              ; =24
    c790:      	mov	x13, x9
    c794:      	b	0xc7ac <_wf_std.collections.hash_map.hash_map_lookup$instance$7c9d455aedf48152+0x8c>
    c798:      	add	x8, x10, #0x1
    c79c:      	cmp	x8, x9
    c7a0:      	csinc	x10, xzr, x10, hs
    c7a4:      	subs	x13, x13, #0x1
    c7a8:      	b.eq	0xc7e8 <_wf_std.collections.hash_map.hash_map_lookup$instance$7c9d455aedf48152+0xc8>
    c7ac:      	madd	x14, x10, x12, x11
    c7b0:      	ldr	w8, [x14]
    c7b4:      	cmp	w8, #0x1
    c7b8:      	b.eq	0xc798 <_wf_std.collections.hash_map.hash_map_lookup$instance$7c9d455aedf48152+0x78>
    c7bc:      	cmp	w8, #0x2
    c7c0:      	b.ne	0xc7ec <_wf_std.collections.hash_map.hash_map_lookup$instance$7c9d455aedf48152+0xcc>
    c7c4:      	ldr	x8, [x14, #0x8]
    c7c8:      	ldr	x15, [x1]
    c7cc:      	cmp	x8, x15
    c7d0:      	b.ne	0xc798 <_wf_std.collections.hash_map.hash_map_lookup$instance$7c9d455aedf48152+0x78>
    c7d4:      	mov	w0, #0x0                ; =0
    c7d8:      	ldr	x8, [x14, #0x10]
    c7dc:      	mov	x1, x8
    c7e0:      	mov	w2, #0x0                ; =0
    c7e4:      	ret
    c7e8:      	mov	x8, #0x0                ; =0
    c7ec:      	mov	w0, #0x1                ; =1
    c7f0:      	mov	x1, x8
    c7f4:      	mov	w2, #0x0                ; =0
    c7f8:      	ret

000000000000c7fc <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46>:
    c7fc:      	stp	x29, x30, [sp, #-0x10]!
    c800:      	ldp	x15, x8, [x0]
    c804:      	ldr	x0, [x0, #0x10]
    c808:      	cbz	x15, 0xc8b0 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0xb4>
    c80c:      	mov	x9, #0xe5b9             ; =58809
    c810:      	movk	x9, #0x1ce4, lsl #16
    c814:      	movk	x9, #0x476d, lsl #32
    c818:      	movk	x9, #0xbf58, lsl #48
    c81c:      	mov	x10, #0x11eb            ; =4587
    c820:      	movk	x10, #0x1331, lsl #16
    c824:      	movk	x10, #0x49bb, lsl #32
    c828:      	movk	x10, #0x94d0, lsl #48
    c82c:      	ldp	x11, x13, [x1, #0x8]
    c830:      	ldr	x12, [x1, #0x18]
    c834:      	ands	x16, x15, #0x3
    c838:      	b.eq	0xc8a4 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0xa8>
    c83c:      	mov	w14, #0x18              ; =24
    c840:      	madd	x14, x15, x14, x0
    c844:      	sub	x17, x14, #0x8
    c848:      	mov	w2, #0x83               ; =131
    c84c:      	mov	x14, x15
    c850:      	b	0xc864 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0x68>
    c854:      	sub	x17, x17, #0x18
    c858:      	sub	x14, x14, #0x1
    c85c:      	sub	x16, x16, #0x1
    c860:      	cbz	x16, 0xc8a8 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0xac>
    c864:      	ldur	w3, [x17, #-0x10]
    c868:      	cmp	w3, #0x2
    c86c:      	b.ne	0xc854 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0x58>
    c870:      	ldp	x4, x3, [x17, #-0x8]
    c874:      	madd	x3, x4, x2, x3
    c878:      	add	x11, x3, x11
    c87c:      	eor	x3, x3, x3, lsr #30
    c880:      	mul	x3, x3, x9
    c884:      	eor	x3, x3, x3, lsr #27
    c888:      	mul	x3, x3, x10
    c88c:      	eor	x13, x13, x3, lsr #31
    c890:      	eor	x13, x13, x3
    c894:      	stp	x11, x13, [x1, #0x8]
    c898:      	add	x12, x12, #0x1
    c89c:      	str	x12, [x1, #0x18]
    c8a0:      	b	0xc854 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0x58>
    c8a4:      	mov	x14, x15
    c8a8:      	cmp	x15, #0x4
    c8ac:      	b.hs	0xc8c4 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0xc8>
    c8b0:      	cbz	x8, 0xc8b8 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0xbc>
    c8b4:      	bl	0xc8b4 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0xb8>
		000000000000c8b4:  ARM64_RELOC_BRANCH26	_free
    c8b8:      	mov	w0, #0x0                ; =0
    c8bc:      	ldp	x29, x30, [sp], #0x10
    c8c0:      	ret
    c8c4:      	mov	w15, #0x18              ; =24
    c8c8:      	madd	x15, x14, x15, x0
    c8cc:      	sub	x15, x15, #0x30
    c8d0:      	mov	w16, #0x83              ; =131
    c8d4:      	b	0xc8e4 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0xe8>
    c8d8:      	sub	x15, x15, #0x60
    c8dc:      	sub	x14, x14, #0x4
    c8e0:      	cbz	x14, 0xc8b0 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0xb4>
    c8e4:      	ldr	w17, [x15, #0x18]
    c8e8:      	cmp	w17, #0x2
    c8ec:      	b.eq	0xc918 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0x11c>
    c8f0:      	ldr	w17, [x15]
    c8f4:      	cmp	w17, #0x2
    c8f8:      	b.eq	0xc954 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0x158>
    c8fc:      	ldur	w17, [x15, #-0x18]
    c900:      	cmp	w17, #0x2
    c904:      	b.eq	0xc990 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0x194>
    c908:      	ldur	w17, [x15, #-0x30]
    c90c:      	cmp	w17, #0x2
    c910:      	b.ne	0xc8d8 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0xdc>
    c914:      	b	0xc9cc <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0x1d0>
    c918:      	ldp	x2, x17, [x15, #0x20]
    c91c:      	madd	x17, x2, x16, x17
    c920:      	add	x11, x17, x11
    c924:      	eor	x17, x17, x17, lsr #30
    c928:      	mul	x17, x17, x9
    c92c:      	eor	x17, x17, x17, lsr #27
    c930:      	mul	x17, x17, x10
    c934:      	eor	x13, x13, x17, lsr #31
    c938:      	eor	x13, x13, x17
    c93c:      	stp	x11, x13, [x1, #0x8]
    c940:      	add	x12, x12, #0x1
    c944:      	str	x12, [x1, #0x18]
    c948:      	ldr	w17, [x15]
    c94c:      	cmp	w17, #0x2
    c950:      	b.ne	0xc8fc <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0x100>
    c954:      	ldp	x2, x17, [x15, #0x8]
    c958:      	madd	x17, x2, x16, x17
    c95c:      	add	x11, x17, x11
    c960:      	eor	x17, x17, x17, lsr #30
    c964:      	mul	x17, x17, x9
    c968:      	eor	x17, x17, x17, lsr #27
    c96c:      	mul	x17, x17, x10
    c970:      	eor	x13, x13, x17, lsr #31
    c974:      	eor	x13, x13, x17
    c978:      	stp	x11, x13, [x1, #0x8]
    c97c:      	add	x12, x12, #0x1
    c980:      	str	x12, [x1, #0x18]
    c984:      	ldur	w17, [x15, #-0x18]
    c988:      	cmp	w17, #0x2
    c98c:      	b.ne	0xc908 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0x10c>
    c990:      	ldp	x2, x17, [x15, #-0x10]
    c994:      	madd	x17, x2, x16, x17
    c998:      	add	x11, x17, x11
    c99c:      	eor	x17, x17, x17, lsr #30
    c9a0:      	mul	x17, x17, x9
    c9a4:      	eor	x17, x17, x17, lsr #27
    c9a8:      	mul	x17, x17, x10
    c9ac:      	eor	x13, x13, x17, lsr #31
    c9b0:      	eor	x13, x13, x17
    c9b4:      	stp	x11, x13, [x1, #0x8]
    c9b8:      	add	x12, x12, #0x1
    c9bc:      	str	x12, [x1, #0x18]
    c9c0:      	ldur	w17, [x15, #-0x30]
    c9c4:      	cmp	w17, #0x2
    c9c8:      	b.ne	0xc8d8 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0xdc>
    c9cc:      	ldp	x2, x17, [x15, #-0x28]
    c9d0:      	madd	x17, x2, x16, x17
    c9d4:      	add	x11, x17, x11
    c9d8:      	eor	x17, x17, x17, lsr #30
    c9dc:      	mul	x17, x17, x9
    c9e0:      	eor	x17, x17, x17, lsr #27
    c9e4:      	mul	x17, x17, x10
    c9e8:      	eor	x13, x13, x17, lsr #31
    c9ec:      	eor	x13, x13, x17
    c9f0:      	stp	x11, x13, [x1, #0x8]
    c9f4:      	add	x12, x12, #0x1
    c9f8:      	str	x12, [x1, #0x18]
    c9fc:      	b	0xc8d8 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0xdc>

000000000000ca00 <_wf_std.collections.hash_map.hash_map_new$instance$1fa0694bfbd574aa>:
    ca00:      	stp	x20, x19, [sp, #-0x20]!
    ca04:      	stp	x29, x30, [sp, #0x10]
    ca08:      	mov	x20, x1
    ca0c:      	mov	x19, x0
    ca10:      	cbz	x1, 0xca80 <_wf_std.collections.hash_map.hash_map_new$instance$1fa0694bfbd574aa+0x80>
    ca14:      	add	x8, x20, x20, lsl #4
    ca18:      	lsl	x0, x8, #4
    ca1c:      	bl	0xca1c <_wf_std.collections.hash_map.hash_map_new$instance$1fa0694bfbd574aa+0x1c>
		000000000000ca1c:  ARM64_RELOC_BRANCH26	_malloc
    ca20:      	cbz	x0, 0xcaa0 <_wf_std.collections.hash_map.hash_map_new$instance$1fa0694bfbd574aa+0xa0>
    ca24:      	mov	x8, #0x0                ; =0
    ca28:      	add	x9, x0, #0x8
    ca2c:      	movi.2d	v0, #0000000000000000
    ca30:      	stur	wzr, [x9, #-0x8]
    ca34:      	add	x8, x8, #0x1
    ca38:      	stp	q0, q0, [x9]
    ca3c:      	stp	q0, q0, [x9, #0x20]
    ca40:      	stp	q0, q0, [x9, #0x40]
    ca44:      	stp	q0, q0, [x9, #0x60]
    ca48:      	stp	q0, q0, [x9, #0x80]
    ca4c:      	stp	q0, q0, [x9, #0xa0]
    ca50:      	stp	q0, q0, [x9, #0xc0]
    ca54:      	stp	q0, q0, [x9, #0xe0]
    ca58:      	str	xzr, [x9, #0x100]
    ca5c:      	add	x9, x9, #0x110
    ca60:      	cmp	x20, x8
    ca64:      	b.ne	0xca30 <_wf_std.collections.hash_map.hash_map_new$instance$1fa0694bfbd574aa+0x30>
    ca68:      	stp	x20, x20, [x19]
    ca6c:      	stp	xzr, xzr, [x19, #0x18]
    ca70:      	str	x0, [x19, #0x10]
    ca74:      	ldp	x29, x30, [sp, #0x10]
    ca78:      	ldp	x20, x19, [sp], #0x20
    ca7c:      	ret
    ca80:      	adrp	x0, 0xc000 <_wf_box_slots_new$instance$1883e0e22b50fc85+0x48>
		000000000000ca80:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    ca84:      	add	x0, x0, #0x0
		000000000000ca84:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    ca88:      	stp	x20, x20, [x19]
    ca8c:      	stp	xzr, xzr, [x19, #0x18]
    ca90:      	str	x0, [x19, #0x10]
    ca94:      	ldp	x29, x30, [sp, #0x10]
    ca98:      	ldp	x20, x19, [sp], #0x20
    ca9c:      	ret
    caa0:      	bl	0xcaa0 <_wf_std.collections.hash_map.hash_map_new$instance$1fa0694bfbd574aa+0xa0>
		000000000000caa0:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000caa4 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d>:
    caa4:      	sub	sp, sp, #0x120
    caa8:      	stp	x28, x27, [sp, #0x100]
    caac:      	stp	x29, x30, [sp, #0x110]
    cab0:      	mov	x9, x2
    cab4:      	ldp	q0, q1, [x3, #0xc0]
    cab8:      	stp	q0, q1, [sp, #0xc0]
    cabc:      	ldp	q0, q1, [x3, #0xe0]
    cac0:      	stp	q0, q1, [sp, #0xe0]
    cac4:      	ldp	q0, q1, [x3, #0x80]
    cac8:      	stp	q0, q1, [sp, #0x80]
    cacc:      	ldp	q0, q1, [x3, #0xa0]
    cad0:      	stp	q0, q1, [sp, #0xa0]
    cad4:      	ldp	q0, q1, [x3, #0x40]
    cad8:      	stp	q0, q1, [sp, #0x40]
    cadc:      	ldp	q0, q1, [x3, #0x60]
    cae0:      	stp	q0, q1, [sp, #0x60]
    cae4:      	ldp	q0, q1, [x3]
    cae8:      	stp	q0, q1, [sp]
    caec:      	ldp	q0, q1, [x3, #0x20]
    caf0:      	stp	q0, q1, [sp, #0x20]
    caf4:      	ldrb	w8, [x4, #0x8]
    caf8:      	tbz	w8, #0x0, 0xcb84 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xe0>
    cafc:      	mov	x8, #0x0                ; =0
    cb00:      	ldr	x10, [x1]
    cb04:      	cbz	x10, 0xcbc8 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x124>
    cb08:      	udiv	x11, x8, x10
    cb0c:      	msub	x8, x11, x10, x8
    cb10:      	ldr	x11, [x1, #0x10]
    cb14:      	mov	w12, #0x110             ; =272
    cb18:      	mov	x13, x10
    cb1c:      	mov	x2, x10
    cb20:      	b	0xcb40 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x9c>
    cb24:      	cmp	x2, x10
    cb28:      	csel	x2, x8, x2, eq
    cb2c:      	add	x14, x8, #0x1
    cb30:      	cmp	x14, x10
    cb34:      	csinc	x8, xzr, x8, hs
    cb38:      	subs	x13, x13, #0x1
    cb3c:      	b.eq	0xcbcc <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x128>
    cb40:      	madd	x14, x8, x12, x11
    cb44:      	ldr	w15, [x14]
    cb48:      	cmp	w15, #0x1
    cb4c:      	b.eq	0xcb24 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x80>
    cb50:      	cmp	w15, #0x2
    cb54:      	b.ne	0xcc2c <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x188>
    cb58:      	ldr	x14, [x14, #0x8]
    cb5c:      	cmp	x14, x9
    cb60:      	b.ne	0xcb2c <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x88>
    cb64:      	mov	x4, sp
    cb68:      	mov	x2, x8
    cb6c:      	mov	x3, x9
    cb70:      	bl	0xcb70 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xcc>
		000000000000cb70:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    cb74:      	ldp	x29, x30, [sp, #0x110]
    cb78:      	ldp	x28, x27, [sp, #0x100]
    cb7c:      	add	sp, sp, #0x120
    cb80:      	ret
    cb84:      	ldr	x8, [x4]
    cb88:      	eor	x8, x8, x9
    cb8c:      	eor	x8, x8, x8, lsr #30
    cb90:      	mov	x10, #0xe5b9            ; =58809
    cb94:      	movk	x10, #0x1ce4, lsl #16
    cb98:      	movk	x10, #0x476d, lsl #32
    cb9c:      	movk	x10, #0xbf58, lsl #48
    cba0:      	mul	x8, x8, x10
    cba4:      	eor	x8, x8, x8, lsr #27
    cba8:      	mov	x10, #0x11eb            ; =4587
    cbac:      	movk	x10, #0x1331, lsl #16
    cbb0:      	movk	x10, #0x49bb, lsl #32
    cbb4:      	movk	x10, #0x94d0, lsl #48
    cbb8:      	mul	x8, x8, x10
    cbbc:      	eor	x8, x8, x8, lsr #31
    cbc0:      	ldr	x10, [x1]
    cbc4:      	cbnz	x10, 0xcb08 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x64>
    cbc8:      	mov	x2, #0x0                ; =0
    cbcc:      	cmp	x2, x10
    cbd0:      	b.hs	0xcc3c <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x198>
    cbd4:      	ldr	x8, [x1, #0x18]
    cbd8:      	lsr	x10, x8, #13
    cbdc:      	cbnz	x10, 0xcc3c <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x198>
    cbe0:      	add	x8, x8, #0x1
    cbe4:      	str	x8, [x1, #0x18]
    cbe8:      	ldr	x8, [x1, #0x10]
    cbec:      	mov	w10, #0x110             ; =272
    cbf0:      	mul	x10, x2, x10
    cbf4:      	ldr	w8, [x8, x10]
    cbf8:      	cmp	w8, #0x1
    cbfc:      	b.ne	0xcc10 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x16c>
    cc00:      	ldr	x8, [x1, #0x20]
    cc04:      	subs	x8, x8, #0x1
    cc08:      	csel	x8, xzr, x8, lo
    cc0c:      	str	x8, [x1, #0x20]
    cc10:      	mov	x4, sp
    cc14:      	mov	x3, x9
    cc18:      	bl	0xcc18 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x174>
		000000000000cc18:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    cc1c:      	ldp	x29, x30, [sp, #0x110]
    cc20:      	ldp	x28, x27, [sp, #0x100]
    cc24:      	add	sp, sp, #0x120
    cc28:      	ret
    cc2c:      	cmp	x2, x10
    cc30:      	csel	x2, x8, x2, eq
    cc34:      	cmp	x2, x10
    cc38:      	b.lo	0xcbd4 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x130>
    cc3c:      	stp	xzr, x9, [x0]
    cc40:      	mov	w8, #0x1                ; =1
    cc44:      	str	w8, [x0]
    cc48:      	strb	w8, [x0, #0x4]
    cc4c:      	ldp	q0, q1, [sp]
    cc50:      	stp	q0, q1, [x0, #0x10]
    cc54:      	ldp	q0, q1, [sp, #0x20]
    cc58:      	stp	q0, q1, [x0, #0x30]
    cc5c:      	ldp	q0, q1, [sp, #0x40]
    cc60:      	stp	q0, q1, [x0, #0x50]
    cc64:      	ldp	q0, q1, [sp, #0x60]
    cc68:      	stp	q0, q1, [x0, #0x70]
    cc6c:      	ldp	q0, q1, [sp, #0x80]
    cc70:      	stp	q0, q1, [x0, #0x90]
    cc74:      	ldp	q0, q1, [sp, #0xa0]
    cc78:      	stp	q0, q1, [x0, #0xb0]
    cc7c:      	ldp	q0, q1, [sp, #0xc0]
    cc80:      	stp	q0, q1, [x0, #0xd0]
    cc84:      	ldp	q0, q1, [sp, #0xe0]
    cc88:      	stp	q0, q1, [x0, #0xf0]
    cc8c:      	ldp	x29, x30, [sp, #0x110]
    cc90:      	ldp	x28, x27, [sp, #0x100]
    cc94:      	add	sp, sp, #0x120
    cc98:      	ret

000000000000cc9c <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d>:
    cc9c:      	ldr	x8, [x1, #0x18]
    cca0:      	cbz	x8, 0xce08 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x16c>
    cca4:      	ldrb	w9, [x3, #0x8]
    cca8:      	tbz	w9, #0x0, 0xccbc <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x20>
    ccac:      	mov	x9, #0x0                ; =0
    ccb0:      	ldr	x11, [x1]
    ccb4:      	cbnz	x11, 0xcd04 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x68>
    ccb8:      	b	0xce08 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x16c>
    ccbc:      	ldr	x9, [x3]
    ccc0:      	ldr	x10, [x2]
    ccc4:      	eor	x9, x10, x9
    ccc8:      	eor	x9, x9, x9, lsr #30
    cccc:      	mov	x10, #0xe5b9            ; =58809
    ccd0:      	movk	x10, #0x1ce4, lsl #16
    ccd4:      	movk	x10, #0x476d, lsl #32
    ccd8:      	movk	x10, #0xbf58, lsl #48
    ccdc:      	mul	x9, x9, x10
    cce0:      	eor	x9, x9, x9, lsr #27
    cce4:      	mov	x10, #0x11eb            ; =4587
    cce8:      	movk	x10, #0x1331, lsl #16
    ccec:      	movk	x10, #0x49bb, lsl #32
    ccf0:      	movk	x10, #0x94d0, lsl #48
    ccf4:      	mul	x9, x9, x10
    ccf8:      	eor	x9, x9, x9, lsr #31
    ccfc:      	ldr	x11, [x1]
    cd00:      	cbz	x11, 0xce08 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x16c>
    cd04:      	udiv	x10, x9, x11
    cd08:      	msub	x12, x10, x11, x9
    cd0c:      	ldr	x13, [x1, #0x10]
    cd10:      	mov	w14, #0x110             ; =272
    cd14:      	mov	x15, x11
    cd18:      	b	0xcd30 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x94>
    cd1c:      	add	x9, x12, #0x1
    cd20:      	cmp	x9, x11
    cd24:      	csinc	x12, xzr, x12, hs
    cd28:      	subs	x15, x15, #0x1
    cd2c:      	b.eq	0xce08 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x16c>
    cd30:      	madd	x9, x12, x14, x13
    cd34:      	ldr	w10, [x9]
    cd38:      	cmp	w10, #0x1
    cd3c:      	b.eq	0xcd1c <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x80>
    cd40:      	cmp	w10, #0x2
    cd44:      	b.ne	0xce08 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x16c>
    cd48:      	ldr	x10, [x9, #0x8]
    cd4c:      	ldr	x16, [x2]
    cd50:      	cmp	x10, x16
    cd54:      	b.ne	0xcd1c <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x80>
    cd58:      	mov	w11, #0x1               ; =1
    cd5c:      	str	w11, [x9]
    cd60:      	sub	x8, x8, #0x1
    cd64:      	ldp	q0, q1, [x9, #0x10]
    cd68:      	ldp	q2, q3, [x9, #0x30]
    cd6c:      	ldp	q4, q5, [x9, #0x50]
    cd70:      	ldp	q6, q7, [x9, #0x70]
    cd74:      	ldp	q16, q17, [x9, #0x90]
    cd78:      	ldp	q18, q19, [x9, #0xb0]
    cd7c:      	ldp	q20, q21, [x9, #0xd0]
    cd80:      	ldp	q22, q23, [x9, #0xf0]
    cd84:      	movi.2d	v24, #0000000000000000
    cd88:      	stur	q24, [x9, #0x18]
    cd8c:      	stur	q24, [x9, #0x28]
    cd90:      	stur	q24, [x9, #0x38]
    cd94:      	stur	q24, [x9, #0x48]
    cd98:      	stur	q24, [x9, #0x58]
    cd9c:      	stur	q24, [x9, #0x68]
    cda0:      	stur	q24, [x9, #0x78]
    cda4:      	stur	q24, [x9, #0x88]
    cda8:      	stur	q24, [x9, #0x98]
    cdac:      	stur	q24, [x9, #0xa8]
    cdb0:      	stur	q24, [x9, #0xb8]
    cdb4:      	stur	q24, [x9, #0xc8]
    cdb8:      	stur	q24, [x9, #0xd8]
    cdbc:      	stur	q24, [x9, #0xe8]
    cdc0:      	stur	q24, [x9, #0xf8]
    cdc4:      	stur	q24, [x9, #0x8]
    cdc8:      	str	xzr, [x9, #0x108]
    cdcc:      	ldr	x9, [x1, #0x20]
    cdd0:      	adds	x9, x9, #0x1
    cdd4:      	csinv	x9, x9, xzr, lo
    cdd8:      	stp	x8, x9, [x1, #0x18]
    cddc:      	stp	xzr, x10, [x0]
    cde0:      	str	w11, [x0]
    cde4:      	stp	q0, q1, [x0, #0x10]
    cde8:      	stp	q2, q3, [x0, #0x30]
    cdec:      	stp	q4, q5, [x0, #0x50]
    cdf0:      	stp	q6, q7, [x0, #0x70]
    cdf4:      	stp	q16, q17, [x0, #0x90]
    cdf8:      	stp	q18, q19, [x0, #0xb0]
    cdfc:      	stp	q20, q21, [x0, #0xd0]
    ce00:      	stp	q22, q23, [x0, #0xf0]
    ce04:      	ret
    ce08:      	movi.2d	v0, #0000000000000000
    ce0c:      	stp	q0, q0, [x0, #0xf0]
    ce10:      	stp	q0, q0, [x0, #0xd0]
    ce14:      	stp	q0, q0, [x0, #0xb0]
    ce18:      	stp	q0, q0, [x0, #0x90]
    ce1c:      	stp	q0, q0, [x0, #0x70]
    ce20:      	stp	q0, q0, [x0, #0x50]
    ce24:      	stp	q0, q0, [x0, #0x30]
    ce28:      	stp	q0, q0, [x0, #0x10]
    ce2c:      	str	q0, [x0]
    ce30:      	ret

000000000000ce34 <_wf_std.collections.hash_map.hash_map_capacity$instance$1fa0694bfbd574aa>:
    ce34:      	ldr	x0, [x0]
    ce38:      	ret

000000000000ce3c <_wf_std.collections.hash_map.hash_map_len$instance$1fa0694bfbd574aa>:
    ce3c:      	ldr	x0, [x0, #0x18]
    ce40:      	ret

000000000000ce44 <_wf_std.collections.hash_map.hash_map_lookup$instance$45d862e2288df95e>:
    ce44:      	ldrb	w8, [x2, #0x8]
    ce48:      	tbz	w8, #0x0, 0xce5c <_wf_std.collections.hash_map.hash_map_lookup$instance$45d862e2288df95e+0x18>
    ce4c:      	mov	x8, #0x0                ; =0
    ce50:      	ldr	x9, [x0]
    ce54:      	cbnz	x9, 0xcea4 <_wf_std.collections.hash_map.hash_map_lookup$instance$45d862e2288df95e+0x60>
    ce58:      	b	0xcf0c <_wf_std.collections.hash_map.hash_map_lookup$instance$45d862e2288df95e+0xc8>
    ce5c:      	ldr	x8, [x2]
    ce60:      	ldr	x9, [x1]
    ce64:      	eor	x8, x9, x8
    ce68:      	eor	x8, x8, x8, lsr #30
    ce6c:      	mov	x9, #0xe5b9             ; =58809
    ce70:      	movk	x9, #0x1ce4, lsl #16
    ce74:      	movk	x9, #0x476d, lsl #32
    ce78:      	movk	x9, #0xbf58, lsl #48
    ce7c:      	mul	x8, x8, x9
    ce80:      	eor	x8, x8, x8, lsr #27
    ce84:      	mov	x9, #0x11eb             ; =4587
    ce88:      	movk	x9, #0x1331, lsl #16
    ce8c:      	movk	x9, #0x49bb, lsl #32
    ce90:      	movk	x9, #0x94d0, lsl #48
    ce94:      	mul	x8, x8, x9
    ce98:      	eor	x8, x8, x8, lsr #31
    ce9c:      	ldr	x9, [x0]
    cea0:      	cbz	x9, 0xcf0c <_wf_std.collections.hash_map.hash_map_lookup$instance$45d862e2288df95e+0xc8>
    cea4:      	udiv	x10, x8, x9
    cea8:      	msub	x10, x10, x9, x8
    ceac:      	ldr	x11, [x0, #0x10]
    ceb0:      	mov	w12, #0x110             ; =272
    ceb4:      	mov	x13, x9
    ceb8:      	b	0xced0 <_wf_std.collections.hash_map.hash_map_lookup$instance$45d862e2288df95e+0x8c>
    cebc:      	add	x8, x10, #0x1
    cec0:      	cmp	x8, x9
    cec4:      	csinc	x10, xzr, x10, hs
    cec8:      	subs	x13, x13, #0x1
    cecc:      	b.eq	0xcf0c <_wf_std.collections.hash_map.hash_map_lookup$instance$45d862e2288df95e+0xc8>
    ced0:      	madd	x14, x10, x12, x11
    ced4:      	ldr	w8, [x14]
    ced8:      	cmp	w8, #0x1
    cedc:      	b.eq	0xcebc <_wf_std.collections.hash_map.hash_map_lookup$instance$45d862e2288df95e+0x78>
    cee0:      	cmp	w8, #0x2
    cee4:      	b.ne	0xcf10 <_wf_std.collections.hash_map.hash_map_lookup$instance$45d862e2288df95e+0xcc>
    cee8:      	ldr	x8, [x14, #0x8]
    ceec:      	ldr	x15, [x1]
    cef0:      	cmp	x8, x15
    cef4:      	b.ne	0xcebc <_wf_std.collections.hash_map.hash_map_lookup$instance$45d862e2288df95e+0x78>
    cef8:      	mov	w0, #0x0                ; =0
    cefc:      	ldr	x8, [x14, #0x10]
    cf00:      	mov	x1, x8
    cf04:      	mov	w2, #0x0                ; =0
    cf08:      	ret
    cf0c:      	mov	x8, #0x0                ; =0
    cf10:      	mov	w0, #0x1                ; =1
    cf14:      	mov	x1, x8
    cf18:      	mov	w2, #0x0                ; =0
    cf1c:      	ret

000000000000cf20 <_wf_std.collections.hash_map.hash_map_free$instance$e1a21e22af512733>:
    cf20:      	stp	x29, x30, [sp, #-0x10]!
    cf24:      	ldp	x9, x8, [x0]
    cf28:      	ldr	x0, [x0, #0x10]
    cf2c:      	cbz	x9, 0xd074 <_wf_std.collections.hash_map.hash_map_free$instance$e1a21e22af512733+0x154>
    cf30:      	ldp	x10, x11, [x1, #0x8]
    cf34:      	mov	w12, #0x110             ; =272
    cf38:      	madd	x13, x9, x12, x0
    cf3c:      	ldr	x12, [x1, #0x18]
    cf40:      	sub	x13, x13, #0x88
    cf44:      	mov	w14, #0x83              ; =131
    cf48:      	mov	x15, #0xe5b9            ; =58809
    cf4c:      	movk	x15, #0x1ce4, lsl #16
    cf50:      	movk	x15, #0x476d, lsl #32
    cf54:      	movk	x15, #0xbf58, lsl #48
    cf58:      	mov	x16, #0x11eb            ; =4587
    cf5c:      	movk	x16, #0x1331, lsl #16
    cf60:      	movk	x16, #0x49bb, lsl #32
    cf64:      	movk	x16, #0x94d0, lsl #48
    cf68:      	b	0xcf78 <_wf_std.collections.hash_map.hash_map_free$instance$e1a21e22af512733+0x58>
    cf6c:      	sub	x13, x13, #0x110
    cf70:      	sub	x9, x9, #0x1
    cf74:      	cbz	x9, 0xd074 <_wf_std.collections.hash_map.hash_map_free$instance$e1a21e22af512733+0x154>
    cf78:      	ldur	w17, [x13, #-0x88]
    cf7c:      	cmp	w17, #0x2
    cf80:      	b.ne	0xcf6c <_wf_std.collections.hash_map.hash_map_free$instance$e1a21e22af512733+0x4c>
    cf84:      	ldp	x2, x17, [x13, #-0x80]
    cf88:      	madd	x17, x2, x14, x17
    cf8c:      	ldp	x3, x2, [x13, #-0x70]
    cf90:      	madd	x17, x17, x14, x3
    cf94:      	madd	x17, x17, x14, x2
    cf98:      	ldp	x3, x2, [x13, #-0x60]
    cf9c:      	madd	x17, x17, x14, x3
    cfa0:      	madd	x17, x17, x14, x2
    cfa4:      	ldp	x3, x2, [x13, #-0x50]
    cfa8:      	madd	x17, x17, x14, x3
    cfac:      	madd	x17, x17, x14, x2
    cfb0:      	ldp	x3, x2, [x13, #-0x40]
    cfb4:      	madd	x17, x17, x14, x3
    cfb8:      	madd	x17, x17, x14, x2
    cfbc:      	ldp	x3, x2, [x13, #-0x30]
    cfc0:      	madd	x17, x17, x14, x3
    cfc4:      	madd	x17, x17, x14, x2
    cfc8:      	ldp	x3, x2, [x13, #-0x20]
    cfcc:      	madd	x17, x17, x14, x3
    cfd0:      	madd	x17, x17, x14, x2
    cfd4:      	ldp	x3, x2, [x13, #-0x10]
    cfd8:      	madd	x17, x17, x14, x3
    cfdc:      	madd	x17, x17, x14, x2
    cfe0:      	ldp	x3, x2, [x13]
    cfe4:      	madd	x17, x17, x14, x3
    cfe8:      	madd	x17, x17, x14, x2
    cfec:      	ldp	x3, x2, [x13, #0x10]
    cff0:      	madd	x17, x17, x14, x3
    cff4:      	madd	x17, x17, x14, x2
    cff8:      	ldp	x3, x2, [x13, #0x20]
    cffc:      	madd	x17, x17, x14, x3
    d000:      	madd	x17, x17, x14, x2
    d004:      	ldp	x3, x2, [x13, #0x30]
    d008:      	madd	x17, x17, x14, x3
    d00c:      	madd	x17, x17, x14, x2
    d010:      	ldp	x3, x2, [x13, #0x40]
    d014:      	madd	x17, x17, x14, x3
    d018:      	madd	x17, x17, x14, x2
    d01c:      	ldp	x3, x2, [x13, #0x50]
    d020:      	madd	x17, x17, x14, x3
    d024:      	madd	x17, x17, x14, x2
    d028:      	ldp	x3, x2, [x13, #0x60]
    d02c:      	madd	x17, x17, x14, x3
    d030:      	madd	x17, x17, x14, x2
    d034:      	ldp	x3, x2, [x13, #0x70]
    d038:      	madd	x17, x17, x14, x3
    d03c:      	madd	x17, x17, x14, x2
    d040:      	ldr	x2, [x13, #0x80]
    d044:      	madd	x17, x17, x14, x2
    d048:      	add	x10, x17, x10
    d04c:      	eor	x17, x17, x17, lsr #30
    d050:      	mul	x17, x17, x15
    d054:      	eor	x17, x17, x17, lsr #27
    d058:      	mul	x17, x17, x16
    d05c:      	eor	x11, x11, x17, lsr #31
    d060:      	eor	x11, x11, x17
    d064:      	stp	x10, x11, [x1, #0x8]
    d068:      	add	x12, x12, #0x1
    d06c:      	str	x12, [x1, #0x18]
    d070:      	b	0xcf6c <_wf_std.collections.hash_map.hash_map_free$instance$e1a21e22af512733+0x4c>
    d074:      	cbz	x8, 0xd07c <_wf_std.collections.hash_map.hash_map_free$instance$e1a21e22af512733+0x15c>
    d078:      	bl	0xd078 <_wf_std.collections.hash_map.hash_map_free$instance$e1a21e22af512733+0x158>
		000000000000d078:  ARM64_RELOC_BRANCH26	_free
    d07c:      	mov	w0, #0x0                ; =0
    d080:      	ldp	x29, x30, [sp], #0x10
    d084:      	ret

000000000000d088 <_wf_full_chain_new$instance$e85fc351f8333b14>:
    d088:      	stp	x22, x21, [sp, #-0x30]!
    d08c:      	stp	x20, x19, [sp, #0x10]
    d090:      	stp	x29, x30, [sp, #0x20]
    d094:      	mov	x20, x1
    d098:      	mov	x19, x0
    d09c:      	cbz	x1, 0xd0d4 <_wf_full_chain_new$instance$e85fc351f8333b14+0x4c>
    d0a0:      	lsl	x22, x20, #3
    d0a4:      	mov	x0, x22
    d0a8:      	bl	0xd0a8 <_wf_full_chain_new$instance$e85fc351f8333b14+0x20>
		000000000000d0a8:  ARM64_RELOC_BRANCH26	_malloc
    d0ac:      	cbz	x0, 0xd0d0 <_wf_full_chain_new$instance$e85fc351f8333b14+0x48>
    d0b0:      	mov	x21, x0
    d0b4:      	mov	w1, #0xff               ; =255
    d0b8:      	mov	x2, x22
    d0bc:      	bl	0xd0bc <_wf_full_chain_new$instance$e85fc351f8333b14+0x34>
		000000000000d0bc:  ARM64_RELOC_BRANCH26	_memset
    d0c0:      	add	x8, x20, x20, lsl #1
    d0c4:      	lsl	x0, x8, #3
    d0c8:      	bl	0xd0c8 <_wf_full_chain_new$instance$e85fc351f8333b14+0x40>
		000000000000d0c8:  ARM64_RELOC_BRANCH26	_malloc
    d0cc:      	cbnz	x0, 0xd0e0 <_wf_full_chain_new$instance$e85fc351f8333b14+0x58>
    d0d0:      	bl	0xd0d0 <_wf_full_chain_new$instance$e85fc351f8333b14+0x48>
		000000000000d0d0:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
    d0d4:      	adrp	x21, 0xd000 <_wf_std.collections.hash_map.hash_map_free$instance$e1a21e22af512733+0xe0>
		000000000000d0d4:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    d0d8:      	add	x21, x21, #0x0
		000000000000d0d8:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    d0dc:      	mov	x0, x21
    d0e0:      	stp	x20, x20, [x19]
    d0e4:      	stp	x21, xzr, [x19, #0x10]
    d0e8:      	stp	x20, x0, [x19, #0x20]
    d0ec:      	ldp	x29, x30, [sp, #0x20]
    d0f0:      	ldp	x20, x19, [sp, #0x10]
    d0f4:      	ldp	x22, x21, [sp], #0x30
    d0f8:      	ret

000000000000d0fc <_wf_full_chain_try_put$instance$29255544f66aec6e>:
    d0fc:      	ldrb	w8, [x4, #0x8]
    d100:      	tbz	w8, #0x0, 0xd114 <_wf_full_chain_try_put$instance$29255544f66aec6e+0x18>
    d104:      	mov	x8, #0x0                ; =0
    d108:      	ldr	x12, [x1]
    d10c:      	cbnz	x12, 0xd158 <_wf_full_chain_try_put$instance$29255544f66aec6e+0x5c>
    d110:      	b	0xd1f4 <_wf_full_chain_try_put$instance$29255544f66aec6e+0xf8>
    d114:      	ldr	x8, [x4]
    d118:      	eor	x8, x8, x2
    d11c:      	eor	x8, x8, x8, lsr #30
    d120:      	mov	x9, #0xe5b9             ; =58809
    d124:      	movk	x9, #0x1ce4, lsl #16
    d128:      	movk	x9, #0x476d, lsl #32
    d12c:      	movk	x9, #0xbf58, lsl #48
    d130:      	mul	x8, x8, x9
    d134:      	eor	x8, x8, x8, lsr #27
    d138:      	mov	x9, #0x11eb             ; =4587
    d13c:      	movk	x9, #0x1331, lsl #16
    d140:      	movk	x9, #0x49bb, lsl #32
    d144:      	movk	x9, #0x94d0, lsl #48
    d148:      	mul	x8, x8, x9
    d14c:      	eor	x8, x8, x8, lsr #31
    d150:      	ldr	x12, [x1]
    d154:      	cbz	x12, 0xd1f4 <_wf_full_chain_try_put$instance$29255544f66aec6e+0xf8>
    d158:      	udiv	x9, x8, x12
    d15c:      	msub	x8, x9, x12, x8
    d160:      	ldp	x9, x10, [x1, #0x10]
    d164:      	ldr	x11, [x9, x8, lsl #3]
    d168:      	cbz	x10, 0xd1ac <_wf_full_chain_try_put$instance$29255544f66aec6e+0xb0>
    d16c:      	cmp	x11, x10
    d170:      	b.hs	0xd1ac <_wf_full_chain_try_put$instance$29255544f66aec6e+0xb0>
    d174:      	ldr	x13, [x1, #0x28]
    d178:      	mov	w14, #0x1               ; =1
    d17c:      	mov	w15, #0x18              ; =24
    d180:      	mov	x16, x11
    d184:      	madd	x16, x16, x15, x13
    d188:      	ldr	x17, [x16]
    d18c:      	cmp	x17, x2
    d190:      	b.eq	0xd20c <_wf_full_chain_try_put$instance$29255544f66aec6e+0x110>
    d194:      	cmp	x14, x10
    d198:      	b.hs	0xd1ac <_wf_full_chain_try_put$instance$29255544f66aec6e+0xb0>
    d19c:      	ldr	x16, [x16, #0x10]
    d1a0:      	add	x14, x14, #0x1
    d1a4:      	cmp	x16, x10
    d1a8:      	b.lo	0xd184 <_wf_full_chain_try_put$instance$29255544f66aec6e+0x88>
    d1ac:      	cmp	x10, x12
    d1b0:      	b.hs	0xd1f4 <_wf_full_chain_try_put$instance$29255544f66aec6e+0xf8>
    d1b4:      	cmp	x10, #0x2, lsl #12      ; =0x2000
    d1b8:      	b.hs	0xd1f4 <_wf_full_chain_try_put$instance$29255544f66aec6e+0xf8>
    d1bc:      	ldr	x12, [x1, #0x20]
    d1c0:      	cmp	x10, x12
    d1c4:      	b.hs	0xd1f4 <_wf_full_chain_try_put$instance$29255544f66aec6e+0xf8>
    d1c8:      	ldr	x12, [x1, #0x28]
    d1cc:      	mov	w13, #0x18              ; =24
    d1d0:      	madd	x12, x10, x13, x12
    d1d4:      	stp	x2, x3, [x12]
    d1d8:      	str	x11, [x12, #0x10]
    d1dc:      	add	x11, x10, #0x1
    d1e0:      	str	x11, [x1, #0x18]
    d1e4:      	str	x10, [x9, x8, lsl #3]
    d1e8:      	stp	xzr, xzr, [x0]
    d1ec:      	str	xzr, [x0, #0x10]
    d1f0:      	ret
    d1f4:      	stp	xzr, x2, [x0]
    d1f8:      	mov	w8, #0x1                ; =1
    d1fc:      	str	w8, [x0]
    d200:      	strb	w8, [x0, #0x4]
    d204:      	str	x3, [x0, #0x10]
    d208:      	ret
    d20c:      	ldr	x8, [x16, #0x8]
    d210:      	str	x3, [x16, #0x8]
    d214:      	stp	xzr, x2, [x0]
    d218:      	mov	w9, #0x1                ; =1
    d21c:      	str	w9, [x0]
    d220:      	str	x8, [x0, #0x10]
    d224:      	ret

000000000000d228 <_wf_full_chain_remove$instance$29255544f66aec6e>:
    d228:      	ldr	x14, [x0, #0x18]
    d22c:      	cbz	x14, 0xd2e4 <_wf_full_chain_remove$instance$29255544f66aec6e+0xbc>
    d230:      	ldr	x10, [x2]
    d234:      	ldrb	w13, [x2, #0x8]
    d238:      	tbz	w13, #0x0, 0xd24c <_wf_full_chain_remove$instance$29255544f66aec6e+0x24>
    d23c:      	mov	x8, #0x0                ; =0
    d240:      	ldr	x12, [x0]
    d244:      	cbnz	x12, 0xd290 <_wf_full_chain_remove$instance$29255544f66aec6e+0x68>
    d248:      	b	0xd2e4 <_wf_full_chain_remove$instance$29255544f66aec6e+0xbc>
    d24c:      	ldr	x8, [x1]
    d250:      	eor	x8, x8, x10
    d254:      	eor	x8, x8, x8, lsr #30
    d258:      	mov	x9, #0xe5b9             ; =58809
    d25c:      	movk	x9, #0x1ce4, lsl #16
    d260:      	movk	x9, #0x476d, lsl #32
    d264:      	movk	x9, #0xbf58, lsl #48
    d268:      	mul	x8, x8, x9
    d26c:      	eor	x8, x8, x8, lsr #27
    d270:      	mov	x9, #0x11eb             ; =4587
    d274:      	movk	x9, #0x1331, lsl #16
    d278:      	movk	x9, #0x49bb, lsl #32
    d27c:      	movk	x9, #0x94d0, lsl #48
    d280:      	mul	x8, x8, x9
    d284:      	eor	x8, x8, x8, lsr #31
    d288:      	ldr	x12, [x0]
    d28c:      	cbz	x12, 0xd2e4 <_wf_full_chain_remove$instance$29255544f66aec6e+0xbc>
    d290:      	udiv	x9, x8, x12
    d294:      	msub	x8, x9, x12, x8
    d298:      	ldr	x11, [x0, #0x10]
    d29c:      	add	x15, x11, x8, lsl #3
    d2a0:      	mov	w16, #0x18              ; =24
    d2a4:      	mov	x3, x14
    d2a8:      	mov	x4, x15
    d2ac:      	mov	x2, x14
    d2b0:      	ldr	x8, [x4]
    d2b4:      	cmp	x8, x14
    d2b8:      	b.hs	0xd2e4 <_wf_full_chain_remove$instance$29255544f66aec6e+0xbc>
    d2bc:      	ldr	x9, [x0, #0x28]
    d2c0:      	madd	x17, x8, x16, x9
    d2c4:      	mov	x4, x17
    d2c8:      	ldr	x5, [x4], #0x10
    d2cc:      	ldr	x6, [x1]
    d2d0:      	cmp	x5, x6
    d2d4:      	b.eq	0xd2f4 <_wf_full_chain_remove$instance$29255544f66aec6e+0xcc>
    d2d8:      	mov	x2, x8
    d2dc:      	subs	x3, x3, #0x1
    d2e0:      	b.ne	0xd2b0 <_wf_full_chain_remove$instance$29255544f66aec6e+0x88>
    d2e4:      	mov	w0, #0x0                ; =0
    d2e8:      	mov	x1, #0x0                ; =0
    d2ec:      	mov	x2, #0x0                ; =0
    d2f0:      	ret
    d2f4:      	ldr	x16, [x4]
    d2f8:      	cmp	x2, x14
    d2fc:      	b.hs	0xd310 <_wf_full_chain_remove$instance$29255544f66aec6e+0xe8>
    d300:      	mov	w15, #0x18              ; =24
    d304:      	madd	x15, x2, x15, x9
    d308:      	str	x16, [x15, #0x10]
    d30c:      	b	0xd314 <_wf_full_chain_remove$instance$29255544f66aec6e+0xec>
    d310:      	str	x16, [x15]
    d314:      	sub	x16, x14, #0x1
    d318:      	mov	w14, #0x18              ; =24
    d31c:      	madd	x14, x16, x14, x9
    d320:      	str	x16, [x0, #0x18]
    d324:      	ldp	x1, x2, [x14]
    d328:      	cmp	x8, x16
    d32c:      	b.hs	0xd394 <_wf_full_chain_remove$instance$29255544f66aec6e+0x16c>
    d330:      	ldr	x0, [x14, #0x10]
    d334:      	ldp	x15, x14, [x17]
    d338:      	stp	x1, x2, [x17]
    d33c:      	str	x0, [x17, #0x10]
    d340:      	tbz	w13, #0x0, 0xd39c <_wf_full_chain_remove$instance$29255544f66aec6e+0x174>
    d344:      	mov	x10, #0x0               ; =0
    d348:      	udiv	x13, x10, x12
    d34c:      	msub	x12, x13, x12, x10
    d350:      	ldr	x10, [x11, x12, lsl #3]
    d354:      	cmp	x10, x16
    d358:      	b.eq	0xd3e8 <_wf_full_chain_remove$instance$29255544f66aec6e+0x1c0>
    d35c:      	b.hs	0xd3fc <_wf_full_chain_remove$instance$29255544f66aec6e+0x1d4>
    d360:      	mov	w11, #0x1               ; =1
    d364:      	mov	w12, #0x18              ; =24
    d368:      	mov	w0, #0x1                ; =1
    d36c:      	madd	x13, x10, x12, x9
    d370:      	ldr	x10, [x13, #0x10]!
    d374:      	cmp	x10, x16
    d378:      	b.eq	0xd40c <_wf_full_chain_remove$instance$29255544f66aec6e+0x1e4>
    d37c:      	cmp	x11, x16
    d380:      	b.hs	0xd3f0 <_wf_full_chain_remove$instance$29255544f66aec6e+0x1c8>
    d384:      	add	x11, x11, #0x1
    d388:      	cmp	x10, x16
    d38c:      	b.lo	0xd36c <_wf_full_chain_remove$instance$29255544f66aec6e+0x144>
    d390:      	b	0xd3f0 <_wf_full_chain_remove$instance$29255544f66aec6e+0x1c8>
    d394:      	mov	w0, #0x1                ; =1
    d398:      	ret
    d39c:      	eor	x10, x1, x10
    d3a0:      	eor	x10, x10, x10, lsr #30
    d3a4:      	mov	x13, #0xe5b9            ; =58809
    d3a8:      	movk	x13, #0x1ce4, lsl #16
    d3ac:      	movk	x13, #0x476d, lsl #32
    d3b0:      	movk	x13, #0xbf58, lsl #48
    d3b4:      	mul	x10, x10, x13
    d3b8:      	eor	x10, x10, x10, lsr #27
    d3bc:      	mov	x13, #0x11eb            ; =4587
    d3c0:      	movk	x13, #0x1331, lsl #16
    d3c4:      	movk	x13, #0x49bb, lsl #32
    d3c8:      	movk	x13, #0x94d0, lsl #48
    d3cc:      	mul	x10, x10, x13
    d3d0:      	eor	x10, x10, x10, lsr #31
    d3d4:      	udiv	x13, x10, x12
    d3d8:      	msub	x12, x13, x12, x10
    d3dc:      	ldr	x10, [x11, x12, lsl #3]
    d3e0:      	cmp	x10, x16
    d3e4:      	b.ne	0xd35c <_wf_full_chain_remove$instance$29255544f66aec6e+0x134>
    d3e8:      	str	x8, [x11, x12, lsl #3]
    d3ec:      	mov	w0, #0x1                ; =1
    d3f0:      	mov	x1, x15
    d3f4:      	mov	x2, x14
    d3f8:      	ret
    d3fc:      	mov	w0, #0x1                ; =1
    d400:      	mov	x1, x15
    d404:      	mov	x2, x14
    d408:      	ret
    d40c:      	str	x8, [x13]
    d410:      	mov	w0, #0x1                ; =1
    d414:      	mov	x1, x15
    d418:      	mov	x2, x14
    d41c:      	ret

000000000000d420 <_wf_full_chain_capacity$instance$e85fc351f8333b14>:
    d420:      	ldr	x0, [x0]
    d424:      	ret

000000000000d428 <_wf_full_chain_len$instance$e85fc351f8333b14>:
    d428:      	ldr	x0, [x0, #0x18]
    d42c:      	ret

000000000000d430 <_wf_full_chain_lookup$instance$7c9d455aedf48152>:
    d430:      	ldrb	w8, [x2, #0x8]
    d434:      	tbz	w8, #0x0, 0xd448 <_wf_full_chain_lookup$instance$7c9d455aedf48152+0x18>
    d438:      	mov	x9, #0x0                ; =0
    d43c:      	ldr	x10, [x0]
    d440:      	cbnz	x10, 0xd490 <_wf_full_chain_lookup$instance$7c9d455aedf48152+0x60>
    d444:      	b	0xd4e0 <_wf_full_chain_lookup$instance$7c9d455aedf48152+0xb0>
    d448:      	ldr	x8, [x2]
    d44c:      	ldr	x9, [x1]
    d450:      	eor	x8, x9, x8
    d454:      	eor	x8, x8, x8, lsr #30
    d458:      	mov	x9, #0xe5b9             ; =58809
    d45c:      	movk	x9, #0x1ce4, lsl #16
    d460:      	movk	x9, #0x476d, lsl #32
    d464:      	movk	x9, #0xbf58, lsl #48
    d468:      	mul	x8, x8, x9
    d46c:      	eor	x8, x8, x8, lsr #27
    d470:      	mov	x9, #0x11eb             ; =4587
    d474:      	movk	x9, #0x1331, lsl #16
    d478:      	movk	x9, #0x49bb, lsl #32
    d47c:      	movk	x9, #0x94d0, lsl #48
    d480:      	mul	x8, x8, x9
    d484:      	eor	x9, x8, x8, lsr #31
    d488:      	ldr	x10, [x0]
    d48c:      	cbz	x10, 0xd4e0 <_wf_full_chain_lookup$instance$7c9d455aedf48152+0xb0>
    d490:      	ldr	x8, [x0, #0x18]
    d494:      	cbz	x8, 0xd4e0 <_wf_full_chain_lookup$instance$7c9d455aedf48152+0xb0>
    d498:      	udiv	x11, x9, x10
    d49c:      	msub	x9, x11, x10, x9
    d4a0:      	ldr	x10, [x0, #0x10]
    d4a4:      	add	x11, x10, x9, lsl #3
    d4a8:      	mov	w9, #0x18               ; =24
    d4ac:      	mov	x10, x8
    d4b0:      	ldr	x11, [x11]
    d4b4:      	cmp	x11, x8
    d4b8:      	b.hs	0xd4e0 <_wf_full_chain_lookup$instance$7c9d455aedf48152+0xb0>
    d4bc:      	ldr	x12, [x0, #0x28]
    d4c0:      	madd	x13, x11, x9, x12
    d4c4:      	ldr	x14, [x13]
    d4c8:      	ldr	x15, [x1]
    d4cc:      	cmp	x14, x15
    d4d0:      	b.eq	0xd4f0 <_wf_full_chain_lookup$instance$7c9d455aedf48152+0xc0>
    d4d4:      	add	x11, x13, #0x10
    d4d8:      	subs	x10, x10, #0x1
    d4dc:      	b.ne	0xd4b0 <_wf_full_chain_lookup$instance$7c9d455aedf48152+0x80>
    d4e0:      	mov	x1, #0x0                ; =0
    d4e4:      	mov	w0, #0x1                ; =1
    d4e8:      	mov	w2, #0x0                ; =0
    d4ec:      	ret
    d4f0:      	mov	w0, #0x0                ; =0
    d4f4:      	mov	w8, #0x18               ; =24
    d4f8:      	madd	x8, x11, x8, x12
    d4fc:      	ldr	x1, [x8, #0x8]
    d500:      	mov	w2, #0x0                ; =0
    d504:      	ret

000000000000d508 <_wf_full_chain_free$instance$d30acb1e89e19e46>:
    d508:      	stp	x28, x27, [sp, #-0x60]!
    d50c:      	stp	x26, x25, [sp, #0x10]
    d510:      	stp	x24, x23, [sp, #0x20]
    d514:      	stp	x22, x21, [sp, #0x30]
    d518:      	stp	x20, x19, [sp, #0x40]
    d51c:      	stp	x29, x30, [sp, #0x50]
    d520:      	mov	x8, x0
    d524:      	ldp	x10, x9, [x0, #0x18]
    d528:      	ldr	x0, [x0, #0x28]
    d52c:      	cbz	x10, 0xd6a0 <_wf_full_chain_free$instance$d30acb1e89e19e46+0x198>
    d530:      	mov	x12, #0xe5b9            ; =58809
    d534:      	movk	x12, #0x1ce4, lsl #16
    d538:      	movk	x12, #0x476d, lsl #32
    d53c:      	movk	x12, #0xbf58, lsl #48
    d540:      	mov	x13, #0x11eb            ; =4587
    d544:      	movk	x13, #0x1331, lsl #16
    d548:      	movk	x13, #0x49bb, lsl #32
    d54c:      	movk	x13, #0x94d0, lsl #48
    d550:      	ldp	x11, x15, [x1, #0x8]
    d554:      	ldr	x14, [x1, #0x18]
    d558:      	cmp	x10, #0x4
    d55c:      	b.hs	0xd568 <_wf_full_chain_free$instance$d30acb1e89e19e46+0x60>
    d560:      	mov	x16, x10
    d564:      	b	0xd658 <_wf_full_chain_free$instance$d30acb1e89e19e46+0x150>
    d568:      	mov	x5, #0x0                ; =0
    d56c:      	mov	x6, #0x0                ; =0
    d570:      	mov	x7, #0x0                ; =0
    d574:      	mov	x2, #0x0                ; =0
    d578:      	mov	x3, #0x0                ; =0
    d57c:      	mov	x4, #0x0                ; =0
    d580:      	and	x17, x10, #0xfffffffffffffffc
    d584:      	and	x16, x10, #0x3
    d588:      	mov	w19, #0x18              ; =24
    d58c:      	madd	x19, x10, x19, x0
    d590:      	sub	x19, x19, #0x30
    d594:      	mov	w20, #0x83              ; =131
    d598:      	mov	x21, x17
    d59c:      	ldp	x22, x23, [x19, #0x18]
    d5a0:      	ldp	x24, x25, [x19]
    d5a4:      	ldp	x26, x27, [x19, #-0x18]
    d5a8:      	ldp	x28, x30, [x19, #-0x30]
    d5ac:      	madd	x22, x22, x20, x23
    d5b0:      	madd	x23, x24, x20, x25
    d5b4:      	madd	x24, x26, x20, x27
    d5b8:      	madd	x25, x28, x20, x30
    d5bc:      	add	x11, x11, x22
    d5c0:      	add	x2, x2, x23
    d5c4:      	add	x3, x3, x24
    d5c8:      	add	x4, x4, x25
    d5cc:      	eor	x22, x22, x22, lsr #30
    d5d0:      	eor	x23, x23, x23, lsr #30
    d5d4:      	eor	x24, x24, x24, lsr #30
    d5d8:      	eor	x25, x25, x25, lsr #30
    d5dc:      	mul	x22, x22, x12
    d5e0:      	mul	x23, x23, x12
    d5e4:      	mul	x24, x24, x12
    d5e8:      	mul	x25, x25, x12
    d5ec:      	eor	x22, x22, x22, lsr #27
    d5f0:      	eor	x23, x23, x23, lsr #27
    d5f4:      	eor	x24, x24, x24, lsr #27
    d5f8:      	eor	x25, x25, x25, lsr #27
    d5fc:      	mul	x22, x22, x13
    d600:      	mul	x23, x23, x13
    d604:      	mul	x24, x24, x13
    d608:      	eor	x15, x15, x22, lsr #31
    d60c:      	mul	x25, x25, x13
    d610:      	eor	x5, x5, x23, lsr #31
    d614:      	eor	x6, x6, x24, lsr #31
    d618:      	eor	x7, x7, x25, lsr #31
    d61c:      	eor	x15, x15, x22
    d620:      	eor	x5, x5, x23
    d624:      	eor	x6, x6, x24
    d628:      	eor	x7, x7, x25
    d62c:      	sub	x19, x19, #0x60
    d630:      	sub	x21, x21, #0x4
    d634:      	cbnz	x21, 0xd59c <_wf_full_chain_free$instance$d30acb1e89e19e46+0x94>
    d638:      	eor	x15, x5, x15
    d63c:      	eor	x5, x7, x6
    d640:      	eor	x15, x5, x15
    d644:      	add	x11, x2, x11
    d648:      	add	x2, x4, x3
    d64c:      	add	x11, x2, x11
    d650:      	cmp	x10, x17
    d654:      	b.eq	0xd694 <_wf_full_chain_free$instance$d30acb1e89e19e46+0x18c>
    d658:      	mov	w17, #0x18              ; =24
    d65c:      	madd	x17, x16, x17, x0
    d660:      	sub	x17, x17, #0x18
    d664:      	mov	w2, #0x83               ; =131
    d668:      	ldp	x3, x4, [x17], #-0x18
    d66c:      	madd	x3, x3, x2, x4
    d670:      	add	x11, x11, x3
    d674:      	eor	x3, x3, x3, lsr #30
    d678:      	mul	x3, x3, x12
    d67c:      	eor	x3, x3, x3, lsr #27
    d680:      	mul	x3, x3, x13
    d684:      	eor	x15, x15, x3, lsr #31
    d688:      	eor	x15, x15, x3
    d68c:      	sub	x16, x16, #0x1
    d690:      	cbnz	x16, 0xd668 <_wf_full_chain_free$instance$d30acb1e89e19e46+0x160>
    d694:      	add	x10, x10, x14
    d698:      	stp	x11, x15, [x1, #0x8]
    d69c:      	str	x10, [x1, #0x18]
    d6a0:      	ldp	x20, x19, [x8, #0x8]
    d6a4:      	cbz	x9, 0xd6ac <_wf_full_chain_free$instance$d30acb1e89e19e46+0x1a4>
    d6a8:      	bl	0xd6a8 <_wf_full_chain_free$instance$d30acb1e89e19e46+0x1a0>
		000000000000d6a8:  ARM64_RELOC_BRANCH26	_free
    d6ac:      	cbz	x20, 0xd6b8 <_wf_full_chain_free$instance$d30acb1e89e19e46+0x1b0>
    d6b0:      	mov	x0, x19
    d6b4:      	bl	0xd6b4 <_wf_full_chain_free$instance$d30acb1e89e19e46+0x1ac>
		000000000000d6b4:  ARM64_RELOC_BRANCH26	_free
    d6b8:      	mov	w0, #0x0                ; =0
    d6bc:      	ldp	x29, x30, [sp, #0x50]
    d6c0:      	ldp	x20, x19, [sp, #0x40]
    d6c4:      	ldp	x22, x21, [sp, #0x30]
    d6c8:      	ldp	x24, x23, [sp, #0x20]
    d6cc:      	ldp	x26, x25, [sp, #0x10]
    d6d0:      	ldp	x28, x27, [sp], #0x60
    d6d4:      	ret

000000000000d6d8 <_wf_full_chain_new$instance$1fa0694bfbd574aa>:
    d6d8:      	stp	x22, x21, [sp, #-0x30]!
    d6dc:      	stp	x20, x19, [sp, #0x10]
    d6e0:      	stp	x29, x30, [sp, #0x20]
    d6e4:      	mov	x20, x1
    d6e8:      	mov	x19, x0
    d6ec:      	cbz	x1, 0xd724 <_wf_full_chain_new$instance$1fa0694bfbd574aa+0x4c>
    d6f0:      	lsl	x22, x20, #3
    d6f4:      	mov	x0, x22
    d6f8:      	bl	0xd6f8 <_wf_full_chain_new$instance$1fa0694bfbd574aa+0x20>
		000000000000d6f8:  ARM64_RELOC_BRANCH26	_malloc
    d6fc:      	cbz	x0, 0xd720 <_wf_full_chain_new$instance$1fa0694bfbd574aa+0x48>
    d700:      	mov	x21, x0
    d704:      	mov	w1, #0xff               ; =255
    d708:      	mov	x2, x22
    d70c:      	bl	0xd70c <_wf_full_chain_new$instance$1fa0694bfbd574aa+0x34>
		000000000000d70c:  ARM64_RELOC_BRANCH26	_memset
    d710:      	add	x8, x20, x20, lsl #4
    d714:      	lsl	x0, x8, #4
    d718:      	bl	0xd718 <_wf_full_chain_new$instance$1fa0694bfbd574aa+0x40>
		000000000000d718:  ARM64_RELOC_BRANCH26	_malloc
    d71c:      	cbnz	x0, 0xd730 <_wf_full_chain_new$instance$1fa0694bfbd574aa+0x58>
    d720:      	bl	0xd720 <_wf_full_chain_new$instance$1fa0694bfbd574aa+0x48>
		000000000000d720:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
    d724:      	adrp	x21, 0xd000 <_wf_std.collections.hash_map.hash_map_free$instance$e1a21e22af512733+0xe0>
		000000000000d724:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    d728:      	add	x21, x21, #0x0
		000000000000d728:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    d72c:      	mov	x0, x21
    d730:      	stp	x20, x20, [x19]
    d734:      	stp	x21, xzr, [x19, #0x10]
    d738:      	stp	x20, x0, [x19, #0x20]
    d73c:      	ldp	x29, x30, [sp, #0x20]
    d740:      	ldp	x20, x19, [sp, #0x10]
    d744:      	ldp	x22, x21, [sp], #0x30
    d748:      	ret

000000000000d74c <_wf_full_chain_try_put$instance$58dd6ca826103b6d>:
    d74c:      	sub	sp, sp, #0xe0
    d750:      	stp	x28, x27, [sp, #0x80]
    d754:      	stp	x26, x25, [sp, #0x90]
    d758:      	stp	x24, x23, [sp, #0xa0]
    d75c:      	stp	x22, x21, [sp, #0xb0]
    d760:      	stp	x20, x19, [sp, #0xc0]
    d764:      	stp	x29, x30, [sp, #0xd0]
    d768:      	ldrb	w8, [x4, #0x8]
    d76c:      	tbz	w8, #0x0, 0xd778 <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x2c>
    d770:      	mov	x15, #0x0               ; =0
    d774:      	b	0xd7b4 <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x68>
    d778:      	ldr	x8, [x4]
    d77c:      	eor	x8, x8, x2
    d780:      	eor	x8, x8, x8, lsr #30
    d784:      	mov	x9, #0xe5b9             ; =58809
    d788:      	movk	x9, #0x1ce4, lsl #16
    d78c:      	movk	x9, #0x476d, lsl #32
    d790:      	movk	x9, #0xbf58, lsl #48
    d794:      	mul	x8, x8, x9
    d798:      	eor	x8, x8, x8, lsr #27
    d79c:      	mov	x9, #0x11eb             ; =4587
    d7a0:      	movk	x9, #0x1331, lsl #16
    d7a4:      	movk	x9, #0x49bb, lsl #32
    d7a8:      	movk	x9, #0x94d0, lsl #48
    d7ac:      	mul	x8, x8, x9
    d7b0:      	eor	x15, x8, x8, lsr #31
    d7b4:      	ldp	x14, x13, [x3]
    d7b8:      	ldp	x12, x11, [x3, #0x10]
    d7bc:      	ldp	x10, x9, [x3, #0x20]
    d7c0:      	ldp	x8, x30, [x3, #0x30]
    d7c4:      	ldp	x28, x27, [x3, #0x40]
    d7c8:      	ldp	x26, x25, [x3, #0x50]
    d7cc:      	ldp	x24, x23, [x3, #0x60]
    d7d0:      	ldp	x22, x21, [x3, #0x70]
    d7d4:      	ldp	x20, x17, [x3, #0x80]
    d7d8:      	ldr	x16, [x3, #0x90]
    d7dc:      	stp	x17, x16, [sp, #0x28]
    d7e0:      	ldp	x17, x16, [x3, #0x98]
    d7e4:      	stp	x17, x16, [sp, #0x38]
    d7e8:      	ldp	x17, x16, [x3, #0xa8]
    d7ec:      	stp	x17, x16, [sp, #0x48]
    d7f0:      	ldp	x17, x16, [x3, #0xb8]
    d7f4:      	stp	x17, x16, [sp, #0x58]
    d7f8:      	ldp	x17, x16, [x3, #0xc8]
    d7fc:      	stp	x17, x16, [sp, #0x68]
    d800:      	ldp	x16, x4, [x3, #0xd8]
    d804:      	str	x16, [sp, #0x78]
    d808:      	ldp	x19, x7, [x3, #0xe8]
    d80c:      	ldr	x6, [x3, #0xf8]
    d810:      	ldr	x5, [x1]
    d814:      	cbz	x5, 0xd944 <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x1f8>
    d818:      	stp	x4, x19, [sp, #0x8]
    d81c:      	stp	x7, x6, [sp, #0x18]
    d820:      	udiv	x16, x15, x5
    d824:      	msub	x17, x16, x5, x15
    d828:      	ldp	x15, x16, [x1, #0x10]
    d82c:      	str	x17, [sp]
    d830:      	ldr	x17, [x15, x17, lsl #3]
    d834:      	cbz	x16, 0xd878 <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x12c>
    d838:      	cmp	x17, x16
    d83c:      	b.hs	0xd878 <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x12c>
    d840:      	ldr	x6, [x1, #0x28]
    d844:      	mov	w7, #0x1                ; =1
    d848:      	mov	w3, #0x110              ; =272
    d84c:      	mov	x4, x17
    d850:      	madd	x4, x4, x3, x6
    d854:      	ldr	x19, [x4]
    d858:      	cmp	x19, x2
    d85c:      	b.eq	0xd9cc <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x280>
    d860:      	cmp	x7, x16
    d864:      	b.hs	0xd878 <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x12c>
    d868:      	ldr	x4, [x4, #0x108]
    d86c:      	add	x7, x7, #0x1
    d870:      	cmp	x4, x16
    d874:      	b.lo	0xd850 <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x104>
    d878:      	cmp	x16, x5
    d87c:      	ldp	x7, x6, [sp, #0x18]
    d880:      	ldp	x4, x19, [sp, #0x8]
    d884:      	b.hs	0xd944 <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x1f8>
    d888:      	cmp	x16, #0x2, lsl #12      ; =0x2000
    d88c:      	b.hs	0xd944 <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x1f8>
    d890:      	ldr	x3, [x1, #0x20]
    d894:      	cmp	x16, x3
    d898:      	b.hs	0xd944 <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x1f8>
    d89c:      	ldr	x3, [x1, #0x28]
    d8a0:      	mov	x5, x4
    d8a4:      	mov	w4, #0x110              ; =272
    d8a8:      	madd	x3, x16, x4, x3
    d8ac:      	stp	x2, x14, [x3]
    d8b0:      	stp	x13, x12, [x3, #0x10]
    d8b4:      	stp	x11, x10, [x3, #0x20]
    d8b8:      	stp	x9, x8, [x3, #0x30]
    d8bc:      	stp	x30, x28, [x3, #0x40]
    d8c0:      	stp	x27, x26, [x3, #0x50]
    d8c4:      	stp	x25, x24, [x3, #0x60]
    d8c8:      	stp	x23, x22, [x3, #0x70]
    d8cc:      	stp	x21, x20, [x3, #0x80]
    d8d0:      	ldp	x9, x8, [sp, #0x28]
    d8d4:      	stp	x9, x8, [x3, #0x90]
    d8d8:      	ldp	x9, x8, [sp, #0x38]
    d8dc:      	stp	x9, x8, [x3, #0xa0]
    d8e0:      	ldp	x9, x8, [sp, #0x48]
    d8e4:      	stp	x9, x8, [x3, #0xb0]
    d8e8:      	ldp	x9, x8, [sp, #0x58]
    d8ec:      	stp	x9, x8, [x3, #0xc0]
    d8f0:      	ldp	x9, x8, [sp, #0x68]
    d8f4:      	stp	x9, x8, [x3, #0xd0]
    d8f8:      	ldr	x8, [sp, #0x78]
    d8fc:      	stp	x8, x5, [x3, #0xe0]
    d900:      	stp	x19, x7, [x3, #0xf0]
    d904:      	stp	x6, x17, [x3, #0x100]
    d908:      	ldr	x8, [sp]
    d90c:      	str	x16, [x15, x8, lsl #3]
    d910:      	add	x8, x16, #0x1
    d914:      	str	x8, [x1, #0x18]
    d918:      	movi.2d	v0, #0000000000000000
    d91c:      	stp	q0, q0, [x0]
    d920:      	stp	q0, q0, [x0, #0x20]
    d924:      	stp	q0, q0, [x0, #0x40]
    d928:      	stp	q0, q0, [x0, #0x60]
    d92c:      	stp	q0, q0, [x0, #0x80]
    d930:      	stp	q0, q0, [x0, #0xa0]
    d934:      	stp	q0, q0, [x0, #0xc0]
    d938:      	stp	q0, q0, [x0, #0xe0]
    d93c:      	str	q0, [x0, #0x100]
    d940:      	b	0xd9ac <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x260>
    d944:      	stp	x14, x13, [x0, #0x10]
    d948:      	stp	x12, x11, [x0, #0x20]
    d94c:      	stp	xzr, x2, [x0]
    d950:      	mov	w11, #0x1               ; =1
    d954:      	str	w11, [x0]
    d958:      	strb	w11, [x0, #0x4]
    d95c:      	stp	x10, x9, [x0, #0x30]
    d960:      	stp	x8, x30, [x0, #0x40]
    d964:      	stp	x28, x27, [x0, #0x50]
    d968:      	stp	x26, x25, [x0, #0x60]
    d96c:      	stp	x24, x23, [x0, #0x70]
    d970:      	stp	x22, x21, [x0, #0x80]
    d974:      	ldp	x9, x10, [sp, #0x28]
    d978:      	stp	x20, x9, [x0, #0x90]
    d97c:      	ldp	x9, x11, [sp, #0x38]
    d980:      	stp	x10, x9, [x0, #0xa0]
    d984:      	ldp	x9, x10, [sp, #0x48]
    d988:      	stp	x11, x9, [x0, #0xb0]
    d98c:      	ldp	x9, x11, [sp, #0x58]
    d990:      	stp	x10, x9, [x0, #0xc0]
    d994:      	ldp	x9, x10, [sp, #0x68]
    d998:      	stp	x11, x9, [x0, #0xd0]
    d99c:      	ldr	x8, [sp, #0x78]
    d9a0:      	stp	x10, x8, [x0, #0xe0]
    d9a4:      	stp	x4, x19, [x0, #0xf0]
    d9a8:      	stp	x7, x6, [x0, #0x100]
    d9ac:      	ldp	x29, x30, [sp, #0xd0]
    d9b0:      	ldp	x20, x19, [sp, #0xc0]
    d9b4:      	ldp	x22, x21, [sp, #0xb0]
    d9b8:      	ldp	x24, x23, [sp, #0xa0]
    d9bc:      	ldp	x26, x25, [sp, #0x90]
    d9c0:      	ldp	x28, x27, [sp, #0x80]
    d9c4:      	add	sp, sp, #0xe0
    d9c8:      	ret
    d9cc:      	ldur	q0, [x4, #0x8]
    d9d0:      	stp	x14, x13, [x4, #0x8]
    d9d4:      	ldur	q1, [x4, #0x18]
    d9d8:      	stp	x12, x11, [x4, #0x18]
    d9dc:      	ldur	q2, [x4, #0x28]
    d9e0:      	stp	x10, x9, [x4, #0x28]
    d9e4:      	ldur	q3, [x4, #0x38]
    d9e8:      	stp	x8, x30, [x4, #0x38]
    d9ec:      	ldur	q4, [x4, #0x48]
    d9f0:      	stp	x28, x27, [x4, #0x48]
    d9f4:      	ldur	q5, [x4, #0x58]
    d9f8:      	stp	x26, x25, [x4, #0x58]
    d9fc:      	ldur	q6, [x4, #0x68]
    da00:      	stp	x24, x23, [x4, #0x68]
    da04:      	ldur	q7, [x4, #0x78]
    da08:      	stp	x22, x21, [x4, #0x78]
    da0c:      	ldur	q16, [x4, #0x88]
    da10:      	ldp	x9, x10, [sp, #0x28]
    da14:      	stp	x20, x9, [x4, #0x88]
    da18:      	ldur	q17, [x4, #0x98]
    da1c:      	ldp	x9, x11, [sp, #0x38]
    da20:      	stp	x10, x9, [x4, #0x98]
    da24:      	ldur	q18, [x4, #0xa8]
    da28:      	ldp	x9, x10, [sp, #0x48]
    da2c:      	stp	x11, x9, [x4, #0xa8]
    da30:      	ldur	q19, [x4, #0xb8]
    da34:      	ldp	x9, x11, [sp, #0x58]
    da38:      	stp	x10, x9, [x4, #0xb8]
    da3c:      	ldur	q20, [x4, #0xc8]
    da40:      	ldp	x9, x10, [sp, #0x68]
    da44:      	stp	x11, x9, [x4, #0xc8]
    da48:      	ldur	q21, [x4, #0xd8]
    da4c:      	ldr	x8, [sp, #0x78]
    da50:      	stp	x10, x8, [x4, #0xd8]
    da54:      	ldur	q22, [x4, #0xe8]
    da58:      	ldp	x9, x8, [sp, #0x8]
    da5c:      	stp	x9, x8, [x4, #0xe8]
    da60:      	ldur	q23, [x4, #0xf8]
    da64:      	ldp	x9, x8, [sp, #0x18]
    da68:      	stp	x9, x8, [x4, #0xf8]
    da6c:      	stp	xzr, x2, [x0]
    da70:      	mov	w8, #0x1                ; =1
    da74:      	str	w8, [x0]
    da78:      	stp	q0, q1, [x0, #0x10]
    da7c:      	stp	q2, q3, [x0, #0x30]
    da80:      	stp	q4, q5, [x0, #0x50]
    da84:      	stp	q6, q7, [x0, #0x70]
    da88:      	stp	q16, q17, [x0, #0x90]
    da8c:      	stp	q18, q19, [x0, #0xb0]
    da90:      	stp	q20, q21, [x0, #0xd0]
    da94:      	stp	q22, q23, [x0, #0xf0]
    da98:      	b	0xd9ac <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x260>

000000000000da9c <_wf_full_chain_remove$instance$58dd6ca826103b6d>:
    da9c:      	stp	d15, d14, [sp, #-0x40]!
    daa0:      	stp	d13, d12, [sp, #0x10]
    daa4:      	stp	d11, d10, [sp, #0x20]
    daa8:      	stp	d9, d8, [sp, #0x30]
    daac:      	ldr	x8, [x1, #0x18]
    dab0:      	cbz	x8, 0xdb68 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0xcc>
    dab4:      	ldrb	w10, [x3, #0x8]
    dab8:      	tbz	w10, #0x0, 0xdacc <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x30>
    dabc:      	mov	x9, #0x0                ; =0
    dac0:      	ldr	x11, [x1]
    dac4:      	cbnz	x11, 0xdb14 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x78>
    dac8:      	b	0xdb68 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0xcc>
    dacc:      	ldr	x9, [x2]
    dad0:      	ldr	x11, [x3]
    dad4:      	eor	x9, x11, x9
    dad8:      	eor	x9, x9, x9, lsr #30
    dadc:      	mov	x11, #0xe5b9            ; =58809
    dae0:      	movk	x11, #0x1ce4, lsl #16
    dae4:      	movk	x11, #0x476d, lsl #32
    dae8:      	movk	x11, #0xbf58, lsl #48
    daec:      	mul	x9, x9, x11
    daf0:      	eor	x9, x9, x9, lsr #27
    daf4:      	mov	x11, #0x11eb            ; =4587
    daf8:      	movk	x11, #0x1331, lsl #16
    dafc:      	movk	x11, #0x49bb, lsl #32
    db00:      	movk	x11, #0x94d0, lsl #48
    db04:      	mul	x9, x9, x11
    db08:      	eor	x9, x9, x9, lsr #31
    db0c:      	ldr	x11, [x1]
    db10:      	cbz	x11, 0xdb68 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0xcc>
    db14:      	udiv	x12, x9, x11
    db18:      	msub	x9, x12, x11, x9
    db1c:      	ldr	x12, [x1, #0x10]
    db20:      	add	x14, x12, x9, lsl #3
    db24:      	mov	w16, #0x110             ; =272
    db28:      	mov	x4, x8
    db2c:      	mov	x5, x14
    db30:      	mov	x17, x8
    db34:      	ldr	x9, [x5]
    db38:      	cmp	x9, x8
    db3c:      	b.hs	0xdb68 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0xcc>
    db40:      	ldr	x13, [x1, #0x28]
    db44:      	madd	x15, x9, x16, x13
    db48:      	ldr	x6, [x15]
    db4c:      	ldr	x7, [x2]
    db50:      	add	x5, x15, #0x108
    db54:      	cmp	x6, x7
    db58:      	b.eq	0xdba4 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x108>
    db5c:      	mov	x17, x9
    db60:      	subs	x4, x4, #0x1
    db64:      	b.ne	0xdb34 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x98>
    db68:      	movi.2d	v0, #0000000000000000
    db6c:      	stp	q0, q0, [x0, #0xf0]
    db70:      	stp	q0, q0, [x0, #0xd0]
    db74:      	stp	q0, q0, [x0, #0xb0]
    db78:      	stp	q0, q0, [x0, #0x90]
    db7c:      	stp	q0, q0, [x0, #0x70]
    db80:      	stp	q0, q0, [x0, #0x50]
    db84:      	stp	q0, q0, [x0, #0x30]
    db88:      	stp	q0, q0, [x0, #0x10]
    db8c:      	str	q0, [x0]
    db90:      	ldp	d9, d8, [sp, #0x30]
    db94:      	ldp	d11, d10, [sp, #0x20]
    db98:      	ldp	d13, d12, [sp, #0x10]
    db9c:      	ldp	d15, d14, [sp], #0x40
    dba0:      	ret
    dba4:      	ldr	x16, [x5]
    dba8:      	cmp	x17, x8
    dbac:      	b.hs	0xdbc0 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x124>
    dbb0:      	mov	w14, #0x110             ; =272
    dbb4:      	madd	x14, x17, x14, x13
    dbb8:      	str	x16, [x14, #0x108]
    dbbc:      	b	0xdbc4 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x128>
    dbc0:      	str	x16, [x14]
    dbc4:      	sub	x14, x8, #0x1
    dbc8:      	mov	w8, #0x110              ; =272
    dbcc:      	str	x14, [x1, #0x18]
    dbd0:      	madd	x8, x14, x8, x13
    dbd4:      	ldp	q15, q14, [x8]
    dbd8:      	ldp	q13, q12, [x8, #0x20]
    dbdc:      	ldp	q11, q10, [x8, #0x40]
    dbe0:      	ldp	q9, q8, [x8, #0x60]
    dbe4:      	ldp	q31, q30, [x8, #0x80]
    dbe8:      	ldp	q29, q28, [x8, #0xa0]
    dbec:      	ldp	q27, q26, [x8, #0xc0]
    dbf0:      	ldp	q25, q24, [x8, #0xe0]
    dbf4:      	ldr	x16, [x8, #0x100]
    dbf8:      	cmp	x9, x14
    dbfc:      	b.hs	0xdc98 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x1fc>
    dc00:      	ldr	x17, [x8]
    dc04:      	ldr	x1, [x8, #0x108]
    dc08:      	ldp	q0, q1, [x15]
    dc0c:      	ldp	q2, q3, [x15, #0x20]
    dc10:      	ldp	q4, q5, [x15, #0x40]
    dc14:      	ldp	q6, q7, [x15, #0x60]
    dc18:      	ldp	q16, q17, [x15, #0x80]
    dc1c:      	ldp	q18, q19, [x15, #0xa0]
    dc20:      	ldp	q20, q21, [x15, #0xc0]
    dc24:      	ldp	q22, q23, [x15, #0xe0]
    dc28:      	ldr	x8, [x15, #0x100]
    dc2c:      	stp	q15, q14, [x15]
    dc30:      	stp	q13, q12, [x15, #0x20]
    dc34:      	stp	q11, q10, [x15, #0x40]
    dc38:      	stp	q9, q8, [x15, #0x60]
    dc3c:      	stp	q31, q30, [x15, #0x80]
    dc40:      	stp	q29, q28, [x15, #0xa0]
    dc44:      	stp	q27, q26, [x15, #0xc0]
    dc48:      	stp	q25, q24, [x15, #0xe0]
    dc4c:      	stp	x16, x1, [x15, #0x100]
    dc50:      	tbz	w10, #0x0, 0xdce0 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x244>
    dc54:      	mov	x10, #0x0               ; =0
    dc58:      	udiv	x15, x10, x11
    dc5c:      	msub	x11, x15, x11, x10
    dc60:      	ldr	x10, [x12, x11, lsl #3]
    dc64:      	cmp	x10, x14
    dc68:      	b.eq	0xdd30 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x294>
    dc6c:      	b.hs	0xdd3c <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x2a0>
    dc70:      	mov	w11, #0x1               ; =1
    dc74:      	mov	w12, #0x110             ; =272
    dc78:      	madd	x15, x10, x12, x13
    dc7c:      	ldr	x10, [x15, #0x108]
    dc80:      	cmp	x10, x14
    dc84:      	b.eq	0xdd38 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x29c>
    dc88:      	ccmp	x11, x14, #0x2, lo
    dc8c:      	add	x11, x11, #0x1
    dc90:      	b.lo	0xdc78 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x1dc>
    dc94:      	b	0xdd3c <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x2a0>
    dc98:      	mov	x8, x16
    dc9c:      	mov.16b	v0, v15
    dca0:      	mov.16b	v1, v14
    dca4:      	mov.16b	v2, v13
    dca8:      	mov.16b	v3, v12
    dcac:      	mov.16b	v4, v11
    dcb0:      	mov.16b	v5, v10
    dcb4:      	mov.16b	v6, v9
    dcb8:      	mov.16b	v7, v8
    dcbc:      	mov.16b	v16, v31
    dcc0:      	mov.16b	v17, v30
    dcc4:      	mov.16b	v18, v29
    dcc8:      	mov.16b	v19, v28
    dccc:      	mov.16b	v20, v27
    dcd0:      	mov.16b	v21, v26
    dcd4:      	mov.16b	v22, v25
    dcd8:      	mov.16b	v23, v24
    dcdc:      	b	0xdd3c <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x2a0>
    dce0:      	ldr	x10, [x3]
    dce4:      	eor	x10, x10, x17
    dce8:      	eor	x10, x10, x10, lsr #30
    dcec:      	mov	x15, #0xe5b9            ; =58809
    dcf0:      	movk	x15, #0x1ce4, lsl #16
    dcf4:      	movk	x15, #0x476d, lsl #32
    dcf8:      	movk	x15, #0xbf58, lsl #48
    dcfc:      	mul	x10, x10, x15
    dd00:      	eor	x10, x10, x10, lsr #27
    dd04:      	mov	x15, #0x11eb            ; =4587
    dd08:      	movk	x15, #0x1331, lsl #16
    dd0c:      	movk	x15, #0x49bb, lsl #32
    dd10:      	movk	x15, #0x94d0, lsl #48
    dd14:      	mul	x10, x10, x15
    dd18:      	eor	x10, x10, x10, lsr #31
    dd1c:      	udiv	x15, x10, x11
    dd20:      	msub	x11, x15, x11, x10
    dd24:      	ldr	x10, [x12, x11, lsl #3]
    dd28:      	cmp	x10, x14
    dd2c:      	b.ne	0xdc6c <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x1d0>
    dd30:      	str	x9, [x12, x11, lsl #3]
    dd34:      	b	0xdd3c <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x2a0>
    dd38:      	str	x9, [x15, #0x108]
    dd3c:      	str	xzr, [x0]
    dd40:      	mov	w9, #0x1                ; =1
    dd44:      	str	w9, [x0]
    dd48:      	stur	q0, [x0, #0x8]
    dd4c:      	stur	q1, [x0, #0x18]
    dd50:      	stur	q2, [x0, #0x28]
    dd54:      	stur	q3, [x0, #0x38]
    dd58:      	stur	q4, [x0, #0x48]
    dd5c:      	stur	q5, [x0, #0x58]
    dd60:      	stur	q6, [x0, #0x68]
    dd64:      	stur	q7, [x0, #0x78]
    dd68:      	stur	q16, [x0, #0x88]
    dd6c:      	stur	q17, [x0, #0x98]
    dd70:      	stur	q18, [x0, #0xa8]
    dd74:      	stur	q19, [x0, #0xb8]
    dd78:      	stur	q20, [x0, #0xc8]
    dd7c:      	stur	q21, [x0, #0xd8]
    dd80:      	stur	q22, [x0, #0xe8]
    dd84:      	stur	q23, [x0, #0xf8]
    dd88:      	str	x8, [x0, #0x108]
    dd8c:      	ldp	d9, d8, [sp, #0x30]
    dd90:      	ldp	d11, d10, [sp, #0x20]
    dd94:      	ldp	d13, d12, [sp, #0x10]
    dd98:      	ldp	d15, d14, [sp], #0x40
    dd9c:      	ret

000000000000dda0 <_wf_full_chain_capacity$instance$1fa0694bfbd574aa>:
    dda0:      	ldr	x0, [x0]
    dda4:      	ret

000000000000dda8 <_wf_full_chain_len$instance$1fa0694bfbd574aa>:
    dda8:      	ldr	x0, [x0, #0x18]
    ddac:      	ret

000000000000ddb0 <_wf_full_chain_lookup$instance$45d862e2288df95e>:
    ddb0:      	ldrb	w8, [x2, #0x8]
    ddb4:      	tbz	w8, #0x0, 0xddc8 <_wf_full_chain_lookup$instance$45d862e2288df95e+0x18>
    ddb8:      	mov	x9, #0x0                ; =0
    ddbc:      	ldr	x10, [x0]
    ddc0:      	cbnz	x10, 0xde10 <_wf_full_chain_lookup$instance$45d862e2288df95e+0x60>
    ddc4:      	b	0xde60 <_wf_full_chain_lookup$instance$45d862e2288df95e+0xb0>
    ddc8:      	ldr	x8, [x2]
    ddcc:      	ldr	x9, [x1]
    ddd0:      	eor	x8, x9, x8
    ddd4:      	eor	x8, x8, x8, lsr #30
    ddd8:      	mov	x9, #0xe5b9             ; =58809
    dddc:      	movk	x9, #0x1ce4, lsl #16
    dde0:      	movk	x9, #0x476d, lsl #32
    dde4:      	movk	x9, #0xbf58, lsl #48
    dde8:      	mul	x8, x8, x9
    ddec:      	eor	x8, x8, x8, lsr #27
    ddf0:      	mov	x9, #0x11eb             ; =4587
    ddf4:      	movk	x9, #0x1331, lsl #16
    ddf8:      	movk	x9, #0x49bb, lsl #32
    ddfc:      	movk	x9, #0x94d0, lsl #48
    de00:      	mul	x8, x8, x9
    de04:      	eor	x9, x8, x8, lsr #31
    de08:      	ldr	x10, [x0]
    de0c:      	cbz	x10, 0xde60 <_wf_full_chain_lookup$instance$45d862e2288df95e+0xb0>
    de10:      	ldr	x8, [x0, #0x18]
    de14:      	cbz	x8, 0xde60 <_wf_full_chain_lookup$instance$45d862e2288df95e+0xb0>
    de18:      	udiv	x11, x9, x10
    de1c:      	msub	x9, x11, x10, x9
    de20:      	ldr	x10, [x0, #0x10]
    de24:      	add	x11, x10, x9, lsl #3
    de28:      	mov	w9, #0x110              ; =272
    de2c:      	mov	x10, x8
    de30:      	ldr	x11, [x11]
    de34:      	cmp	x11, x8
    de38:      	b.hs	0xde60 <_wf_full_chain_lookup$instance$45d862e2288df95e+0xb0>
    de3c:      	ldr	x12, [x0, #0x28]
    de40:      	madd	x13, x11, x9, x12
    de44:      	ldr	x14, [x13]
    de48:      	ldr	x15, [x1]
    de4c:      	cmp	x14, x15
    de50:      	b.eq	0xde70 <_wf_full_chain_lookup$instance$45d862e2288df95e+0xc0>
    de54:      	add	x11, x13, #0x108
    de58:      	subs	x10, x10, #0x1
    de5c:      	b.ne	0xde30 <_wf_full_chain_lookup$instance$45d862e2288df95e+0x80>
    de60:      	mov	x1, #0x0                ; =0
    de64:      	mov	w0, #0x1                ; =1
    de68:      	mov	w2, #0x0                ; =0
    de6c:      	ret
    de70:      	mov	w0, #0x0                ; =0
    de74:      	mov	w8, #0x110              ; =272
    de78:      	madd	x8, x11, x8, x12
    de7c:      	ldr	x1, [x8, #0x8]
    de80:      	mov	w2, #0x0                ; =0
    de84:      	ret

000000000000de88 <_wf_full_chain_free$instance$e1a21e22af512733>:
    de88:      	stp	x20, x19, [sp, #-0x20]!
    de8c:      	stp	x29, x30, [sp, #0x10]
    de90:      	mov	x8, x0
    de94:      	ldp	x10, x9, [x0, #0x18]
    de98:      	ldr	x0, [x0, #0x28]
    de9c:      	cbz	x10, 0xdfd4 <_wf_full_chain_free$instance$e1a21e22af512733+0x14c>
    dea0:      	ldp	x11, x12, [x1, #0x8]
    dea4:      	mov	w13, #0x110             ; =272
    dea8:      	madd	x13, x10, x13, x0
    deac:      	sub	x14, x13, #0x88
    deb0:      	ldr	x13, [x1, #0x18]
    deb4:      	mov	w15, #0x83              ; =131
    deb8:      	mov	x16, #0xe5b9            ; =58809
    debc:      	movk	x16, #0x1ce4, lsl #16
    dec0:      	movk	x16, #0x476d, lsl #32
    dec4:      	movk	x16, #0xbf58, lsl #48
    dec8:      	mov	x17, #0x11eb            ; =4587
    decc:      	movk	x17, #0x1331, lsl #16
    ded0:      	movk	x17, #0x49bb, lsl #32
    ded4:      	movk	x17, #0x94d0, lsl #48
    ded8:      	mov	x2, x10
    dedc:      	ldp	x3, x4, [x14, #-0x88]
    dee0:      	madd	x3, x3, x15, x4
    dee4:      	ldp	x4, x5, [x14, #-0x78]
    dee8:      	madd	x3, x3, x15, x4
    deec:      	madd	x3, x3, x15, x5
    def0:      	ldp	x4, x5, [x14, #-0x68]
    def4:      	madd	x3, x3, x15, x4
    def8:      	madd	x3, x3, x15, x5
    defc:      	ldp	x4, x5, [x14, #-0x58]
    df00:      	madd	x3, x3, x15, x4
    df04:      	madd	x3, x3, x15, x5
    df08:      	ldp	x4, x5, [x14, #-0x48]
    df0c:      	madd	x3, x3, x15, x4
    df10:      	madd	x3, x3, x15, x5
    df14:      	ldp	x4, x5, [x14, #-0x38]
    df18:      	madd	x3, x3, x15, x4
    df1c:      	madd	x3, x3, x15, x5
    df20:      	ldp	x4, x5, [x14, #-0x28]
    df24:      	madd	x3, x3, x15, x4
    df28:      	madd	x3, x3, x15, x5
    df2c:      	ldp	x4, x5, [x14, #-0x18]
    df30:      	madd	x3, x3, x15, x4
    df34:      	madd	x3, x3, x15, x5
    df38:      	ldp	x4, x5, [x14, #-0x8]
    df3c:      	madd	x3, x3, x15, x4
    df40:      	madd	x3, x3, x15, x5
    df44:      	ldp	x4, x5, [x14, #0x8]
    df48:      	madd	x3, x3, x15, x4
    df4c:      	madd	x3, x3, x15, x5
    df50:      	ldp	x4, x5, [x14, #0x18]
    df54:      	madd	x3, x3, x15, x4
    df58:      	madd	x3, x3, x15, x5
    df5c:      	ldp	x4, x5, [x14, #0x28]
    df60:      	madd	x3, x3, x15, x4
    df64:      	madd	x3, x3, x15, x5
    df68:      	ldp	x4, x5, [x14, #0x38]
    df6c:      	madd	x3, x3, x15, x4
    df70:      	madd	x3, x3, x15, x5
    df74:      	ldp	x4, x5, [x14, #0x48]
    df78:      	madd	x3, x3, x15, x4
    df7c:      	madd	x3, x3, x15, x5
    df80:      	ldp	x4, x5, [x14, #0x58]
    df84:      	madd	x3, x3, x15, x4
    df88:      	madd	x3, x3, x15, x5
    df8c:      	ldp	x4, x5, [x14, #0x68]
    df90:      	madd	x3, x3, x15, x4
    df94:      	madd	x3, x3, x15, x5
    df98:      	ldr	x4, [x14, #0x78]
    df9c:      	madd	x3, x3, x15, x4
    dfa0:      	add	x11, x3, x11
    dfa4:      	eor	x3, x3, x3, lsr #30
    dfa8:      	mul	x3, x3, x16
    dfac:      	eor	x3, x3, x3, lsr #27
    dfb0:      	mul	x3, x3, x17
    dfb4:      	eor	x12, x12, x3, lsr #31
    dfb8:      	eor	x12, x12, x3
    dfbc:      	sub	x14, x14, #0x110
    dfc0:      	sub	x2, x2, #0x1
    dfc4:      	cbnz	x2, 0xdedc <_wf_full_chain_free$instance$e1a21e22af512733+0x54>
    dfc8:      	add	x10, x10, x13
    dfcc:      	stp	x11, x12, [x1, #0x8]
    dfd0:      	str	x10, [x1, #0x18]
    dfd4:      	ldp	x20, x19, [x8, #0x8]
    dfd8:      	cbz	x9, 0xdfe0 <_wf_full_chain_free$instance$e1a21e22af512733+0x158>
    dfdc:      	bl	0xdfdc <_wf_full_chain_free$instance$e1a21e22af512733+0x154>
		000000000000dfdc:  ARM64_RELOC_BRANCH26	_free
    dfe0:      	cbz	x20, 0xdfec <_wf_full_chain_free$instance$e1a21e22af512733+0x164>
    dfe4:      	mov	x0, x19
    dfe8:      	bl	0xdfe8 <_wf_full_chain_free$instance$e1a21e22af512733+0x160>
		000000000000dfe8:  ARM64_RELOC_BRANCH26	_free
    dfec:      	mov	w0, #0x0                ; =0
    dff0:      	ldp	x29, x30, [sp, #0x10]
    dff4:      	ldp	x20, x19, [sp], #0x20
    dff8:      	ret

000000000000dffc <_wf_box_slots_new$instance$b45b69d9d0c6bbd0>:
    dffc:      	stp	x20, x19, [sp, #-0x20]!
    e000:      	stp	x29, x30, [sp, #0x10]
    e004:      	mov	x19, x0
    e008:      	cbz	x0, 0xe034 <_wf_box_slots_new$instance$b45b69d9d0c6bbd0+0x38>
    e00c:      	add	x8, x19, x19, lsl #1
    e010:      	lsl	x0, x8, #3
    e014:      	bl	0xe014 <_wf_box_slots_new$instance$b45b69d9d0c6bbd0+0x18>
		000000000000e014:  ARM64_RELOC_BRANCH26	_malloc
    e018:      	mov	x2, x0
    e01c:      	cbz	x0, 0xe050 <_wf_box_slots_new$instance$b45b69d9d0c6bbd0+0x54>
    e020:      	mov	x0, #0x0                ; =0
    e024:      	mov	x1, x19
    e028:      	ldp	x29, x30, [sp, #0x10]
    e02c:      	ldp	x20, x19, [sp], #0x20
    e030:      	ret
    e034:      	adrp	x2, 0xe000 <_wf_box_slots_new$instance$b45b69d9d0c6bbd0+0x4>
		000000000000e034:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    e038:      	add	x2, x2, #0x0
		000000000000e038:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    e03c:      	mov	x0, #0x0                ; =0
    e040:      	mov	x1, x19
    e044:      	ldp	x29, x30, [sp, #0x10]
    e048:      	ldp	x20, x19, [sp], #0x20
    e04c:      	ret
    e050:      	bl	0xe050 <_wf_box_slots_new$instance$b45b69d9d0c6bbd0+0x54>
		000000000000e050:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000e054 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca>:
    e054:      	stp	x24, x23, [sp, #-0x40]!
    e058:      	stp	x22, x21, [sp, #0x10]
    e05c:      	stp	x20, x19, [sp, #0x20]
    e060:      	stp	x29, x30, [sp, #0x30]
    e064:      	mov	x20, x1
    e068:      	mov	x19, x0
    e06c:      	ldp	x23, x22, [x0]
    e070:      	cmp	x22, x1
    e074:      	b.hs	0xe0d4 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x80>
    e078:      	ldr	x21, [x19, #0x10]
    e07c:      	add	x8, x20, x20, lsl #1
    e080:      	lsl	x1, x8, #3
    e084:      	cmp	x22, #0x0
    e088:      	ccmp	x23, x22, #0x0, ne
    e08c:      	b.eq	0xe0c4 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x70>
    e090:      	mov	x0, x1
    e094:      	bl	0xe094 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x40>
		000000000000e094:  ARM64_RELOC_BRANCH26	_malloc
    e098:      	cbz	x0, 0xe11c <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xc8>
    e09c:      	cbz	x22, 0xe0d0 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x7c>
    e0a0:      	add	x8, x23, x23, lsl #1
    e0a4:      	lsl	x2, x8, #3
    e0a8:      	mov	x22, x0
    e0ac:      	mov	x1, x21
    e0b0:      	bl	0xe0b0 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x5c>
		000000000000e0b0:  ARM64_RELOC_BRANCH26	_memcpy
    e0b4:      	mov	x0, x21
    e0b8:      	bl	0xe0b8 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x64>
		000000000000e0b8:  ARM64_RELOC_BRANCH26	_free
    e0bc:      	mov	x0, x22
    e0c0:      	b	0xe0d0 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x7c>
    e0c4:      	mov	x0, x21
    e0c8:      	bl	0xe0c8 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x74>
		000000000000e0c8:  ARM64_RELOC_BRANCH26	_realloc
    e0cc:      	cbz	x0, 0xe11c <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xc8>
    e0d0:      	stp	x20, x0, [x19, #0x8]
    e0d4:      	cmp	x23, x20
    e0d8:      	b.hs	0xe104 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xb0>
    e0dc:      	ldr	x8, [x19, #0x10]
    e0e0:      	mov	w9, #0x18               ; =24
    e0e4:      	madd	x8, x23, x9, x8
    e0e8:      	add	x8, x8, #0x8
    e0ec:      	stur	wzr, [x8, #-0x8]
    e0f0:      	add	x23, x23, #0x1
    e0f4:      	stp	xzr, xzr, [x8], #0x18
    e0f8:      	cmp	x20, x23
    e0fc:      	b.ne	0xe0ec <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x98>
    e100:      	str	x23, [x19]
    e104:      	mov	w0, #0x0                ; =0
    e108:      	ldp	x29, x30, [sp, #0x30]
    e10c:      	ldp	x20, x19, [sp, #0x20]
    e110:      	ldp	x22, x21, [sp, #0x10]
    e114:      	ldp	x24, x23, [sp], #0x40
    e118:      	ret
    e11c:      	bl	0xe11c <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xc8>
		000000000000e11c:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000e120 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6>:
    e120:      	sub	sp, sp, #0x60
    e124:      	stp	x24, x23, [sp, #0x20]
    e128:      	stp	x22, x21, [sp, #0x30]
    e12c:      	stp	x20, x19, [sp, #0x40]
    e130:      	stp	x29, x30, [sp, #0x50]
    e134:      	cmp	x1, #0x3
    e138:      	b.hi	0xe148 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x28>
    e13c:      	ldr	x20, [x0]
    e140:      	cmp	x1, x20
    e144:      	b.hs	0xe16c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x4c>
    e148:      	mov	w0, #0x1                ; =1
    e14c:      	mov	w1, #0x0                ; =0
    e150:      	mov	w2, #0x0                ; =0
    e154:      	ldp	x29, x30, [sp, #0x50]
    e158:      	ldp	x20, x19, [sp, #0x40]
    e15c:      	ldp	x22, x21, [sp, #0x30]
    e160:      	ldp	x24, x23, [sp, #0x20]
    e164:      	add	sp, sp, #0x60
    e168:      	ret
    e16c:      	cbz	x1, 0xe240 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x120>
    e170:      	mov	x19, x0
    e174:      	ldr	x21, [x2]
    e178:      	ldrb	w22, [x2, #0x8]
    e17c:      	mov	x23, x1
    e180:      	add	x8, x1, x1, lsl #1
    e184:      	lsl	x0, x8, #3
    e188:      	bl	0xe188 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x68>
		000000000000e188:  ARM64_RELOC_BRANCH26	_malloc
    e18c:      	cbz	x0, 0xe330 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x210>
    e190:      	mov	x8, #0x0                ; =0
    e194:      	add	x11, x0, #0x8
    e198:      	mov	x9, x19
    e19c:      	mov	x10, x23
    e1a0:      	stur	wzr, [x11, #-0x8]
    e1a4:      	add	x8, x8, #0x1
    e1a8:      	stp	xzr, xzr, [x11], #0x18
    e1ac:      	cmp	x10, x8
    e1b0:      	b.ne	0xe1a0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x80>
    e1b4:      	ldp	x11, x8, [x9, #0x8]
    e1b8:      	stp	x10, x10, [x9]
    e1bc:      	str	x0, [x9, #0x10]
    e1c0:      	cbz	x20, 0xe314 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1f4>
    e1c4:      	mov	w12, #0x18              ; =24
    e1c8:      	tbz	w22, #0x0, 0xe248 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x128>
    e1cc:      	add	x13, sp, #0x8
    e1d0:      	mov	w14, #0x2               ; =2
    e1d4:      	b	0xe1dc <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xbc>
    e1d8:      	cbz	x20, 0xe314 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1f4>
    e1dc:      	sub	x20, x20, #0x1
    e1e0:      	madd	x15, x20, x12, x8
    e1e4:      	ldr	w16, [x15]
    e1e8:      	cmp	w16, #0x2
    e1ec:      	b.lo	0xe1d8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xb8>
    e1f0:      	ldur	q0, [x15, #0x8]
    e1f4:      	stur	q0, [sp, #0x10]
    e1f8:      	mov	w15, #0x1               ; =1
    e1fc:      	b	0xe21c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xfc>
    e200:      	sub	x15, x15, #0x1
    e204:      	add	x17, x13, x15, lsl #4
    e208:      	str	x15, [sp, #0x8]
    e20c:      	str	w14, [x16]
    e210:      	ldur	q0, [x17, #0x8]
    e214:      	stur	q0, [x16, #0x8]
    e218:      	cbz	x15, 0xe1d8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xb8>
    e21c:      	mov	x16, x0
    e220:      	mov	x17, x10
    e224:      	ldr	w1, [x16]
    e228:      	cmp	w1, #0x1
    e22c:      	b.ls	0xe200 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xe0>
    e230:      	add	x16, x16, #0x18
    e234:      	subs	x17, x17, #0x1
    e238:      	b.ne	0xe224 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x104>
    e23c:      	b	0xe218 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xf8>
    e240:      	mov	w0, #0x0                ; =0
    e244:      	b	0xe14c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x2c>
    e248:      	mov	x13, #0xe5b9            ; =58809
    e24c:      	movk	x13, #0x1ce4, lsl #16
    e250:      	movk	x13, #0x476d, lsl #32
    e254:      	movk	x13, #0xbf58, lsl #48
    e258:      	mov	x14, #0x11eb            ; =4587
    e25c:      	movk	x14, #0x1331, lsl #16
    e260:      	movk	x14, #0x49bb, lsl #32
    e264:      	movk	x14, #0x94d0, lsl #48
    e268:      	add	x15, sp, #0x8
    e26c:      	mov	w16, #0x2               ; =2
    e270:      	b	0xe278 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x158>
    e274:      	cbz	x20, 0xe314 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1f4>
    e278:      	sub	x20, x20, #0x1
    e27c:      	madd	x17, x20, x12, x8
    e280:      	ldr	w1, [x17]
    e284:      	cmp	w1, #0x1
    e288:      	b.ls	0xe274 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x154>
    e28c:      	ldur	q0, [x17, #0x8]
    e290:      	ldr	x17, [x17, #0x8]
    e294:      	stur	q0, [sp, #0x10]
    e298:      	eor	x17, x17, x21
    e29c:      	eor	x17, x17, x17, lsr #30
    e2a0:      	mul	x17, x17, x13
    e2a4:      	eor	x17, x17, x17, lsr #27
    e2a8:      	mul	x17, x17, x14
    e2ac:      	eor	x17, x17, x17, lsr #31
    e2b0:      	udiv	x1, x17, x10
    e2b4:      	msub	x17, x1, x10, x17
    e2b8:      	sub	x1, x10, x17
    e2bc:      	neg	x2, x1
    e2c0:      	mov	w3, #0x1                ; =1
    e2c4:      	b	0xe2e4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1c4>
    e2c8:      	sub	x3, x3, #0x1
    e2cc:      	add	x4, x15, x3, lsl #4
    e2d0:      	str	x3, [sp, #0x8]
    e2d4:      	str	w16, [x5]
    e2d8:      	ldur	q0, [x4, #0x8]
    e2dc:      	stur	q0, [x5, #0x8]
    e2e0:      	cbz	x3, 0xe274 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x154>
    e2e4:      	mov	x4, #0x0                ; =0
    e2e8:      	cmp	x4, x1
    e2ec:      	csel	x5, x17, x2, lo
    e2f0:      	add	x5, x5, x4
    e2f4:      	madd	x5, x5, x12, x0
    e2f8:      	ldr	w6, [x5]
    e2fc:      	cmp	w6, #0x2
    e300:      	b.lo	0xe2c8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1a8>
    e304:      	add	x4, x4, #0x1
    e308:      	cmp	x10, x4
    e30c:      	b.ne	0xe2e8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1c8>
    e310:      	b	0xe2e0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1c0>
    e314:      	cbz	x11, 0xe324 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x204>
    e318:      	mov	x0, x8
    e31c:      	bl	0xe31c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1fc>
		000000000000e31c:  ARM64_RELOC_BRANCH26	_free
    e320:      	mov	x9, x19
    e324:      	mov	w0, #0x0                ; =0
    e328:      	str	xzr, [x9, #0x20]
    e32c:      	b	0xe14c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x2c>
    e330:      	bl	0xe330 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x210>
		000000000000e330:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000e334 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6>:
    e334:      	ldrb	w8, [x4, #0x8]
    e338:      	tbz	w8, #0x0, 0xe3c4 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0x90>
    e33c:      	mov	x9, #0x0                ; =0
    e340:      	ldr	x8, [x1]
    e344:      	cbz	x8, 0xe408 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0xd4>
    e348:      	udiv	x10, x9, x8
    e34c:      	msub	x10, x10, x8, x9
    e350:      	ldr	x11, [x1, #0x10]
    e354:      	mov	w12, #0x18              ; =24
    e358:      	mov	x13, x8
    e35c:      	mov	x9, x8
    e360:      	b	0xe380 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0x4c>
    e364:      	cmp	x9, x8
    e368:      	csel	x9, x10, x9, eq
    e36c:      	add	x14, x10, #0x1
    e370:      	cmp	x14, x8
    e374:      	csinc	x10, xzr, x10, hs
    e378:      	subs	x13, x13, #0x1
    e37c:      	b.eq	0xe40c <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0xd8>
    e380:      	madd	x14, x10, x12, x11
    e384:      	ldr	w15, [x14]
    e388:      	cmp	w15, #0x1
    e38c:      	b.eq	0xe364 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0x30>
    e390:      	cmp	w15, #0x2
    e394:      	b.ne	0xe468 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0x134>
    e398:      	ldr	x15, [x14, #0x8]
    e39c:      	cmp	x15, x2
    e3a0:      	b.ne	0xe36c <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0x38>
    e3a4:      	ldr	x8, [x14, #0x10]
    e3a8:      	mov	w9, #0x2                ; =2
    e3ac:      	str	w9, [x14]
    e3b0:      	str	x3, [x14, #0x10]
    e3b4:      	mov	w9, #0x1                ; =1
    e3b8:      	stp	x9, x2, [x0]
    e3bc:      	str	x8, [x0, #0x10]
    e3c0:      	ret
    e3c4:      	ldr	x8, [x4]
    e3c8:      	eor	x8, x8, x2
    e3cc:      	eor	x8, x8, x8, lsr #30
    e3d0:      	mov	x9, #0xe5b9             ; =58809
    e3d4:      	movk	x9, #0x1ce4, lsl #16
    e3d8:      	movk	x9, #0x476d, lsl #32
    e3dc:      	movk	x9, #0xbf58, lsl #48
    e3e0:      	mul	x8, x8, x9
    e3e4:      	eor	x8, x8, x8, lsr #27
    e3e8:      	mov	x9, #0x11eb             ; =4587
    e3ec:      	movk	x9, #0x1331, lsl #16
    e3f0:      	movk	x9, #0x49bb, lsl #32
    e3f4:      	movk	x9, #0x94d0, lsl #48
    e3f8:      	mul	x8, x8, x9
    e3fc:      	eor	x9, x8, x8, lsr #31
    e400:      	ldr	x8, [x1]
    e404:      	cbnz	x8, 0xe348 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0x14>
    e408:      	mov	x9, #0x0                ; =0
    e40c:      	cmp	x9, x8
    e410:      	b.hs	0xe478 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0x144>
    e414:      	ldr	x8, [x1, #0x18]
    e418:      	cmp	x8, #0x2
    e41c:      	b.hi	0xe478 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0x144>
    e420:      	add	x8, x8, #0x1
    e424:      	str	x8, [x1, #0x18]
    e428:      	ldr	x8, [x1, #0x10]
    e42c:      	mov	w10, #0x18              ; =24
    e430:      	madd	x8, x9, x10, x8
    e434:      	ldr	w9, [x8]
    e438:      	cmp	w9, #0x1
    e43c:      	b.ne	0xe490 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0x15c>
    e440:      	ldr	x9, [x1, #0x20]
    e444:      	subs	x9, x9, #0x1
    e448:      	csel	x9, xzr, x9, lo
    e44c:      	str	x9, [x1, #0x20]
    e450:      	mov	w9, #0x2                ; =2
    e454:      	str	w9, [x8]
    e458:      	stp	x2, x3, [x8, #0x8]
    e45c:      	stp	xzr, xzr, [x0, #0x8]
    e460:      	str	xzr, [x0]
    e464:      	ret
    e468:      	cmp	x9, x8
    e46c:      	csel	x9, x10, x9, eq
    e470:      	cmp	x9, x8
    e474:      	b.lo	0xe414 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0xe0>
    e478:      	stp	xzr, x2, [x0]
    e47c:      	mov	w8, #0x1                ; =1
    e480:      	str	w8, [x0]
    e484:      	strb	w8, [x0, #0x4]
    e488:      	str	x3, [x0, #0x10]
    e48c:      	ret
    e490:      	ldur	q0, [x8, #0x8]
    e494:      	mov	w10, #0x2               ; =2
    e498:      	str	w10, [x8]
    e49c:      	stp	x2, x3, [x8, #0x8]
    e4a0:      	cbz	w9, 0xe4b4 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0x180>
    e4a4:      	mov	w8, #0x1                ; =1
    e4a8:      	str	x8, [x0]
    e4ac:      	stur	q0, [x0, #0x8]
    e4b0:      	ret
    e4b4:      	stp	xzr, xzr, [x0]
    e4b8:      	str	xzr, [x0, #0x10]
    e4bc:      	ret

000000000000e4c0 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd>:
    e4c0:      	stp	x24, x23, [sp, #-0x40]!
    e4c4:      	stp	x22, x21, [sp, #0x10]
    e4c8:      	stp	x20, x19, [sp, #0x20]
    e4cc:      	stp	x29, x30, [sp, #0x30]
    e4d0:      	mov	x20, x1
    e4d4:      	mov	x19, x0
    e4d8:      	ldp	x23, x22, [x0]
    e4dc:      	cmp	x22, x1
    e4e0:      	b.hs	0xe540 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x80>
    e4e4:      	ldr	x21, [x19, #0x10]
    e4e8:      	add	x8, x20, x20, lsl #1
    e4ec:      	lsl	x1, x8, #3
    e4f0:      	cmp	x22, #0x0
    e4f4:      	ccmp	x23, x22, #0x0, ne
    e4f8:      	b.eq	0xe530 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x70>
    e4fc:      	mov	x0, x1
    e500:      	bl	0xe500 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x40>
		000000000000e500:  ARM64_RELOC_BRANCH26	_malloc
    e504:      	cbz	x0, 0xe588 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xc8>
    e508:      	cbz	x22, 0xe53c <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x7c>
    e50c:      	add	x8, x23, x23, lsl #1
    e510:      	lsl	x2, x8, #3
    e514:      	mov	x22, x0
    e518:      	mov	x1, x21
    e51c:      	bl	0xe51c <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x5c>
		000000000000e51c:  ARM64_RELOC_BRANCH26	_memcpy
    e520:      	mov	x0, x21
    e524:      	bl	0xe524 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x64>
		000000000000e524:  ARM64_RELOC_BRANCH26	_free
    e528:      	mov	x0, x22
    e52c:      	b	0xe53c <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x7c>
    e530:      	mov	x0, x21
    e534:      	bl	0xe534 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x74>
		000000000000e534:  ARM64_RELOC_BRANCH26	_realloc
    e538:      	cbz	x0, 0xe588 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xc8>
    e53c:      	stp	x20, x0, [x19, #0x8]
    e540:      	cmp	x23, x20
    e544:      	b.hs	0xe570 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xb0>
    e548:      	ldr	x8, [x19, #0x10]
    e54c:      	mov	w9, #0x18               ; =24
    e550:      	madd	x8, x23, x9, x8
    e554:      	add	x8, x8, #0x8
    e558:      	stur	wzr, [x8, #-0x8]
    e55c:      	add	x23, x23, #0x1
    e560:      	stp	xzr, xzr, [x8], #0x18
    e564:      	cmp	x20, x23
    e568:      	b.ne	0xe558 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x98>
    e56c:      	str	x23, [x19]
    e570:      	mov	w0, #0x0                ; =0
    e574:      	ldp	x29, x30, [sp, #0x30]
    e578:      	ldp	x20, x19, [sp, #0x20]
    e57c:      	ldp	x22, x21, [sp, #0x10]
    e580:      	ldp	x24, x23, [sp], #0x40
    e584:      	ret
    e588:      	bl	0xe588 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xc8>
		000000000000e588:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000e58c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad>:
    e58c:      	sub	sp, sp, #0x60
    e590:      	stp	x24, x23, [sp, #0x20]
    e594:      	stp	x22, x21, [sp, #0x30]
    e598:      	stp	x20, x19, [sp, #0x40]
    e59c:      	stp	x29, x30, [sp, #0x50]
    e5a0:      	cmp	x1, #0x4, lsl #12       ; =0x4000
    e5a4:      	b.hi	0xe5b4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x28>
    e5a8:      	ldr	x20, [x0]
    e5ac:      	cmp	x1, x20
    e5b0:      	b.hs	0xe5d8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x4c>
    e5b4:      	mov	w0, #0x1                ; =1
    e5b8:      	mov	w1, #0x0                ; =0
    e5bc:      	mov	w2, #0x0                ; =0
    e5c0:      	ldp	x29, x30, [sp, #0x50]
    e5c4:      	ldp	x20, x19, [sp, #0x40]
    e5c8:      	ldp	x22, x21, [sp, #0x30]
    e5cc:      	ldp	x24, x23, [sp, #0x20]
    e5d0:      	add	sp, sp, #0x60
    e5d4:      	ret
    e5d8:      	cbz	x1, 0xe6ac <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x120>
    e5dc:      	mov	x19, x0
    e5e0:      	ldr	x21, [x2]
    e5e4:      	ldrb	w22, [x2, #0x8]
    e5e8:      	mov	x23, x1
    e5ec:      	add	x8, x1, x1, lsl #1
    e5f0:      	lsl	x0, x8, #3
    e5f4:      	bl	0xe5f4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x68>
		000000000000e5f4:  ARM64_RELOC_BRANCH26	_malloc
    e5f8:      	cbz	x0, 0xe79c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x210>
    e5fc:      	mov	x8, #0x0                ; =0
    e600:      	add	x11, x0, #0x8
    e604:      	mov	x9, x19
    e608:      	mov	x10, x23
    e60c:      	stur	wzr, [x11, #-0x8]
    e610:      	add	x8, x8, #0x1
    e614:      	stp	xzr, xzr, [x11], #0x18
    e618:      	cmp	x10, x8
    e61c:      	b.ne	0xe60c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x80>
    e620:      	ldp	x11, x8, [x9, #0x8]
    e624:      	stp	x10, x10, [x9]
    e628:      	str	x0, [x9, #0x10]
    e62c:      	cbz	x20, 0xe780 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1f4>
    e630:      	mov	w12, #0x18              ; =24
    e634:      	tbz	w22, #0x0, 0xe6b4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x128>
    e638:      	add	x13, sp, #0x8
    e63c:      	mov	w14, #0x2               ; =2
    e640:      	b	0xe648 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xbc>
    e644:      	cbz	x20, 0xe780 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1f4>
    e648:      	sub	x20, x20, #0x1
    e64c:      	madd	x15, x20, x12, x8
    e650:      	ldr	w16, [x15]
    e654:      	cmp	w16, #0x2
    e658:      	b.lo	0xe644 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xb8>
    e65c:      	ldur	q0, [x15, #0x8]
    e660:      	stur	q0, [sp, #0x10]
    e664:      	mov	w15, #0x1               ; =1
    e668:      	b	0xe688 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xfc>
    e66c:      	sub	x15, x15, #0x1
    e670:      	add	x17, x13, x15, lsl #4
    e674:      	str	x15, [sp, #0x8]
    e678:      	str	w14, [x16]
    e67c:      	ldur	q0, [x17, #0x8]
    e680:      	stur	q0, [x16, #0x8]
    e684:      	cbz	x15, 0xe644 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xb8>
    e688:      	mov	x16, x0
    e68c:      	mov	x17, x10
    e690:      	ldr	w1, [x16]
    e694:      	cmp	w1, #0x1
    e698:      	b.ls	0xe66c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xe0>
    e69c:      	add	x16, x16, #0x18
    e6a0:      	subs	x17, x17, #0x1
    e6a4:      	b.ne	0xe690 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x104>
    e6a8:      	b	0xe684 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xf8>
    e6ac:      	mov	w0, #0x0                ; =0
    e6b0:      	b	0xe5b8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x2c>
    e6b4:      	mov	x13, #0xe5b9            ; =58809
    e6b8:      	movk	x13, #0x1ce4, lsl #16
    e6bc:      	movk	x13, #0x476d, lsl #32
    e6c0:      	movk	x13, #0xbf58, lsl #48
    e6c4:      	mov	x14, #0x11eb            ; =4587
    e6c8:      	movk	x14, #0x1331, lsl #16
    e6cc:      	movk	x14, #0x49bb, lsl #32
    e6d0:      	movk	x14, #0x94d0, lsl #48
    e6d4:      	add	x15, sp, #0x8
    e6d8:      	mov	w16, #0x2               ; =2
    e6dc:      	b	0xe6e4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x158>
    e6e0:      	cbz	x20, 0xe780 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1f4>
    e6e4:      	sub	x20, x20, #0x1
    e6e8:      	madd	x17, x20, x12, x8
    e6ec:      	ldr	w1, [x17]
    e6f0:      	cmp	w1, #0x1
    e6f4:      	b.ls	0xe6e0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x154>
    e6f8:      	ldur	q0, [x17, #0x8]
    e6fc:      	ldr	x17, [x17, #0x8]
    e700:      	stur	q0, [sp, #0x10]
    e704:      	eor	x17, x17, x21
    e708:      	eor	x17, x17, x17, lsr #30
    e70c:      	mul	x17, x17, x13
    e710:      	eor	x17, x17, x17, lsr #27
    e714:      	mul	x17, x17, x14
    e718:      	eor	x17, x17, x17, lsr #31
    e71c:      	udiv	x1, x17, x10
    e720:      	msub	x17, x1, x10, x17
    e724:      	sub	x1, x10, x17
    e728:      	neg	x2, x1
    e72c:      	mov	w3, #0x1                ; =1
    e730:      	b	0xe750 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1c4>
    e734:      	sub	x3, x3, #0x1
    e738:      	add	x4, x15, x3, lsl #4
    e73c:      	str	x3, [sp, #0x8]
    e740:      	str	w16, [x5]
    e744:      	ldur	q0, [x4, #0x8]
    e748:      	stur	q0, [x5, #0x8]
    e74c:      	cbz	x3, 0xe6e0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x154>
    e750:      	mov	x4, #0x0                ; =0
    e754:      	cmp	x4, x1
    e758:      	csel	x5, x17, x2, lo
    e75c:      	add	x5, x5, x4
    e760:      	madd	x5, x5, x12, x0
    e764:      	ldr	w6, [x5]
    e768:      	cmp	w6, #0x2
    e76c:      	b.lo	0xe734 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1a8>
    e770:      	add	x4, x4, #0x1
    e774:      	cmp	x10, x4
    e778:      	b.ne	0xe754 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1c8>
    e77c:      	b	0xe74c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1c0>
    e780:      	cbz	x11, 0xe790 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x204>
    e784:      	mov	x0, x8
    e788:      	bl	0xe788 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1fc>
		000000000000e788:  ARM64_RELOC_BRANCH26	_free
    e78c:      	mov	x9, x19
    e790:      	mov	w0, #0x0                ; =0
    e794:      	str	xzr, [x9, #0x20]
    e798:      	b	0xe5b8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x2c>
    e79c:      	bl	0xe79c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x210>
		000000000000e79c:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000e7a0 <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad>:
    e7a0:      	ldrb	w8, [x4, #0x8]
    e7a4:      	tbz	w8, #0x0, 0xe830 <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0x90>
    e7a8:      	mov	x9, #0x0                ; =0
    e7ac:      	ldr	x8, [x1]
    e7b0:      	cbz	x8, 0xe874 <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0xd4>
    e7b4:      	udiv	x10, x9, x8
    e7b8:      	msub	x10, x10, x8, x9
    e7bc:      	ldr	x11, [x1, #0x10]
    e7c0:      	mov	w12, #0x18              ; =24
    e7c4:      	mov	x13, x8
    e7c8:      	mov	x9, x8
    e7cc:      	b	0xe7ec <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0x4c>
    e7d0:      	cmp	x9, x8
    e7d4:      	csel	x9, x10, x9, eq
    e7d8:      	add	x14, x10, #0x1
    e7dc:      	cmp	x14, x8
    e7e0:      	csinc	x10, xzr, x10, hs
    e7e4:      	subs	x13, x13, #0x1
    e7e8:      	b.eq	0xe878 <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0xd8>
    e7ec:      	madd	x14, x10, x12, x11
    e7f0:      	ldr	w15, [x14]
    e7f4:      	cmp	w15, #0x1
    e7f8:      	b.eq	0xe7d0 <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0x30>
    e7fc:      	cmp	w15, #0x2
    e800:      	b.ne	0xe8d4 <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0x134>
    e804:      	ldr	x15, [x14, #0x8]
    e808:      	cmp	x15, x2
    e80c:      	b.ne	0xe7d8 <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0x38>
    e810:      	ldr	x8, [x14, #0x10]
    e814:      	mov	w9, #0x2                ; =2
    e818:      	str	w9, [x14]
    e81c:      	str	x3, [x14, #0x10]
    e820:      	mov	w9, #0x1                ; =1
    e824:      	stp	x9, x2, [x0]
    e828:      	str	x8, [x0, #0x10]
    e82c:      	ret
    e830:      	ldr	x8, [x4]
    e834:      	eor	x8, x8, x2
    e838:      	eor	x8, x8, x8, lsr #30
    e83c:      	mov	x9, #0xe5b9             ; =58809
    e840:      	movk	x9, #0x1ce4, lsl #16
    e844:      	movk	x9, #0x476d, lsl #32
    e848:      	movk	x9, #0xbf58, lsl #48
    e84c:      	mul	x8, x8, x9
    e850:      	eor	x8, x8, x8, lsr #27
    e854:      	mov	x9, #0x11eb             ; =4587
    e858:      	movk	x9, #0x1331, lsl #16
    e85c:      	movk	x9, #0x49bb, lsl #32
    e860:      	movk	x9, #0x94d0, lsl #48
    e864:      	mul	x8, x8, x9
    e868:      	eor	x9, x8, x8, lsr #31
    e86c:      	ldr	x8, [x1]
    e870:      	cbnz	x8, 0xe7b4 <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0x14>
    e874:      	mov	x9, #0x0                ; =0
    e878:      	cmp	x9, x8
    e87c:      	b.hs	0xe8e4 <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0x144>
    e880:      	ldr	x8, [x1, #0x18]
    e884:      	lsr	x10, x8, #14
    e888:      	cbnz	x10, 0xe8e4 <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0x144>
    e88c:      	add	x8, x8, #0x1
    e890:      	str	x8, [x1, #0x18]
    e894:      	ldr	x8, [x1, #0x10]
    e898:      	mov	w10, #0x18              ; =24
    e89c:      	madd	x8, x9, x10, x8
    e8a0:      	ldr	w9, [x8]
    e8a4:      	cmp	w9, #0x1
    e8a8:      	b.ne	0xe8fc <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0x15c>
    e8ac:      	ldr	x9, [x1, #0x20]
    e8b0:      	subs	x9, x9, #0x1
    e8b4:      	csel	x9, xzr, x9, lo
    e8b8:      	str	x9, [x1, #0x20]
    e8bc:      	mov	w9, #0x2                ; =2
    e8c0:      	str	w9, [x8]
    e8c4:      	stp	x2, x3, [x8, #0x8]
    e8c8:      	stp	xzr, xzr, [x0, #0x8]
    e8cc:      	str	xzr, [x0]
    e8d0:      	ret
    e8d4:      	cmp	x9, x8
    e8d8:      	csel	x9, x10, x9, eq
    e8dc:      	cmp	x9, x8
    e8e0:      	b.lo	0xe880 <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0xe0>
    e8e4:      	stp	xzr, x2, [x0]
    e8e8:      	mov	w8, #0x1                ; =1
    e8ec:      	str	w8, [x0]
    e8f0:      	strb	w8, [x0, #0x4]
    e8f4:      	str	x3, [x0, #0x10]
    e8f8:      	ret
    e8fc:      	ldur	q0, [x8, #0x8]
    e900:      	mov	w10, #0x2               ; =2
    e904:      	str	w10, [x8]
    e908:      	stp	x2, x3, [x8, #0x8]
    e90c:      	cbz	w9, 0xe920 <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0x180>
    e910:      	mov	w8, #0x1                ; =1
    e914:      	str	x8, [x0]
    e918:      	stur	q0, [x0, #0x8]
    e91c:      	ret
    e920:      	stp	xzr, xzr, [x0]
    e924:      	str	xzr, [x0, #0x10]
    e928:      	ret

000000000000e92c <_wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad>:
    e92c:      	ldrb	w8, [x2, #0x8]
    e930:      	tbz	w8, #0x0, 0xe944 <_wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad+0x18>
    e934:      	mov	x8, #0x0                ; =0
    e938:      	ldr	x9, [x0]
    e93c:      	cbnz	x9, 0xe98c <_wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad+0x60>
    e940:      	b	0xe9f0 <_wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad+0xc4>
    e944:      	ldr	x8, [x2]
    e948:      	ldr	x9, [x1]
    e94c:      	eor	x8, x9, x8
    e950:      	eor	x8, x8, x8, lsr #30
    e954:      	mov	x9, #0xe5b9             ; =58809
    e958:      	movk	x9, #0x1ce4, lsl #16
    e95c:      	movk	x9, #0x476d, lsl #32
    e960:      	movk	x9, #0xbf58, lsl #48
    e964:      	mul	x8, x8, x9
    e968:      	eor	x8, x8, x8, lsr #27
    e96c:      	mov	x9, #0x11eb             ; =4587
    e970:      	movk	x9, #0x1331, lsl #16
    e974:      	movk	x9, #0x49bb, lsl #32
    e978:      	movk	x9, #0x94d0, lsl #48
    e97c:      	mul	x8, x8, x9
    e980:      	eor	x8, x8, x8, lsr #31
    e984:      	ldr	x9, [x0]
    e988:      	cbz	x9, 0xe9f0 <_wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad+0xc4>
    e98c:      	udiv	x10, x8, x9
    e990:      	msub	x8, x10, x9, x8
    e994:      	ldr	x10, [x0, #0x10]
    e998:      	mov	w11, #0x18              ; =24
    e99c:      	mov	x12, x9
    e9a0:      	b	0xe9b8 <_wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad+0x8c>
    e9a4:      	add	x13, x8, #0x1
    e9a8:      	cmp	x13, x9
    e9ac:      	csinc	x8, xzr, x8, hs
    e9b0:      	subs	x12, x12, #0x1
    e9b4:      	b.eq	0xe9f0 <_wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad+0xc4>
    e9b8:      	madd	x14, x8, x11, x10
    e9bc:      	ldr	w13, [x14]
    e9c0:      	cmp	w13, #0x1
    e9c4:      	b.eq	0xe9a4 <_wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad+0x78>
    e9c8:      	cmp	w13, #0x2
    e9cc:      	b.ne	0xea04 <_wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad+0xd8>
    e9d0:      	ldr	x13, [x14, #0x8]
    e9d4:      	ldr	x14, [x1]
    e9d8:      	cmp	x13, x14
    e9dc:      	b.ne	0xe9a4 <_wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad+0x78>
    e9e0:      	mov	w0, #0x0                ; =0
    e9e4:      	mov	x1, x8
    e9e8:      	mov	w2, #0x0                ; =0
    e9ec:      	ret
    e9f0:      	mov	x8, #0x0                ; =0
    e9f4:      	mov	w0, #0x1                ; =1
    e9f8:      	mov	x1, x8
    e9fc:      	mov	w2, #0x0                ; =0
    ea00:      	ret
    ea04:      	mov	w0, #0x1                ; =1
    ea08:      	mov	x8, x13
    ea0c:      	mov	x1, x8
    ea10:      	mov	w2, #0x0                ; =0
    ea14:      	ret

000000000000ea18 <_wf_box_slots_new$instance$9eabc50a9cce2251>:
    ea18:      	stp	x20, x19, [sp, #-0x20]!
    ea1c:      	stp	x29, x30, [sp, #0x10]
    ea20:      	mov	x19, x0
    ea24:      	cbz	x0, 0xea50 <_wf_box_slots_new$instance$9eabc50a9cce2251+0x38>
    ea28:      	add	x8, x19, x19, lsl #4
    ea2c:      	lsl	x0, x8, #4
    ea30:      	bl	0xea30 <_wf_box_slots_new$instance$9eabc50a9cce2251+0x18>
		000000000000ea30:  ARM64_RELOC_BRANCH26	_malloc
    ea34:      	mov	x2, x0
    ea38:      	cbz	x0, 0xea6c <_wf_box_slots_new$instance$9eabc50a9cce2251+0x54>
    ea3c:      	mov	x0, #0x0                ; =0
    ea40:      	mov	x1, x19
    ea44:      	ldp	x29, x30, [sp, #0x10]
    ea48:      	ldp	x20, x19, [sp], #0x20
    ea4c:      	ret
    ea50:      	adrp	x2, 0xe000 <_wf_box_slots_new$instance$b45b69d9d0c6bbd0+0x4>
		000000000000ea50:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    ea54:      	add	x2, x2, #0x0
		000000000000ea54:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    ea58:      	mov	x0, #0x0                ; =0
    ea5c:      	mov	x1, x19
    ea60:      	ldp	x29, x30, [sp, #0x10]
    ea64:      	ldp	x20, x19, [sp], #0x20
    ea68:      	ret
    ea6c:      	bl	0xea6c <_wf_box_slots_new$instance$9eabc50a9cce2251+0x54>
		000000000000ea6c:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000ea70 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743>:
    ea70:      	stp	x24, x23, [sp, #-0x40]!
    ea74:      	stp	x22, x21, [sp, #0x10]
    ea78:      	stp	x20, x19, [sp, #0x20]
    ea7c:      	stp	x29, x30, [sp, #0x30]
    ea80:      	mov	x20, x1
    ea84:      	mov	x19, x0
    ea88:      	ldp	x23, x22, [x0]
    ea8c:      	cmp	x22, x1
    ea90:      	b.hs	0xeaf0 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x80>
    ea94:      	ldr	x21, [x19, #0x10]
    ea98:      	add	x8, x20, x20, lsl #4
    ea9c:      	lsl	x1, x8, #4
    eaa0:      	cmp	x22, #0x0
    eaa4:      	ccmp	x23, x22, #0x0, ne
    eaa8:      	b.eq	0xeae0 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x70>
    eaac:      	mov	x0, x1
    eab0:      	bl	0xeab0 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x40>
		000000000000eab0:  ARM64_RELOC_BRANCH26	_malloc
    eab4:      	cbz	x0, 0xeb60 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xf0>
    eab8:      	cbz	x22, 0xeaec <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x7c>
    eabc:      	add	x8, x23, x23, lsl #4
    eac0:      	lsl	x2, x8, #4
    eac4:      	mov	x22, x0
    eac8:      	mov	x1, x21
    eacc:      	bl	0xeacc <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x5c>
		000000000000eacc:  ARM64_RELOC_BRANCH26	_memcpy
    ead0:      	mov	x0, x21
    ead4:      	bl	0xead4 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x64>
		000000000000ead4:  ARM64_RELOC_BRANCH26	_free
    ead8:      	mov	x0, x22
    eadc:      	b	0xeaec <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x7c>
    eae0:      	mov	x0, x21
    eae4:      	bl	0xeae4 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x74>
		000000000000eae4:  ARM64_RELOC_BRANCH26	_realloc
    eae8:      	cbz	x0, 0xeb60 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xf0>
    eaec:      	stp	x20, x0, [x19, #0x8]
    eaf0:      	cmp	x23, x20
    eaf4:      	b.hs	0xeb48 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xd8>
    eaf8:      	ldr	x8, [x19, #0x10]
    eafc:      	mov	w9, #0x110              ; =272
    eb00:      	madd	x8, x23, x9, x8
    eb04:      	add	x8, x8, #0x8
    eb08:      	movi.2d	v0, #0000000000000000
    eb0c:      	stur	wzr, [x8, #-0x8]
    eb10:      	add	x23, x23, #0x1
    eb14:      	stp	q0, q0, [x8]
    eb18:      	stp	q0, q0, [x8, #0x20]
    eb1c:      	stp	q0, q0, [x8, #0x40]
    eb20:      	stp	q0, q0, [x8, #0x60]
    eb24:      	stp	q0, q0, [x8, #0x80]
    eb28:      	stp	q0, q0, [x8, #0xa0]
    eb2c:      	stp	q0, q0, [x8, #0xc0]
    eb30:      	stp	q0, q0, [x8, #0xe0]
    eb34:      	str	xzr, [x8, #0x100]
    eb38:      	add	x8, x8, #0x110
    eb3c:      	cmp	x20, x23
    eb40:      	b.ne	0xeb0c <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x9c>
    eb44:      	str	x23, [x19]
    eb48:      	mov	w0, #0x0                ; =0
    eb4c:      	ldp	x29, x30, [sp, #0x30]
    eb50:      	ldp	x20, x19, [sp, #0x20]
    eb54:      	ldp	x22, x21, [sp, #0x10]
    eb58:      	ldp	x24, x23, [sp], #0x40
    eb5c:      	ret
    eb60:      	bl	0xeb60 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xf0>
		000000000000eb60:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000eb64 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07>:
    eb64:      	stp	x28, x27, [sp, #-0x60]!
    eb68:      	stp	x26, x25, [sp, #0x10]
    eb6c:      	stp	x24, x23, [sp, #0x20]
    eb70:      	stp	x22, x21, [sp, #0x30]
    eb74:      	stp	x20, x19, [sp, #0x40]
    eb78:      	stp	x29, x30, [sp, #0x50]
    eb7c:      	sub	sp, sp, #0x250
    eb80:      	cmp	x1, #0x3
    eb84:      	b.hi	0xeb9c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x38>
    eb88:      	mov	x20, x1
    eb8c:      	mov	x19, x0
    eb90:      	ldr	x22, [x0]
    eb94:      	cmp	x1, x22
    eb98:      	b.hs	0xebc8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x64>
    eb9c:      	mov	w0, #0x1                ; =1
    eba0:      	mov	w1, #0x0                ; =0
    eba4:      	mov	w2, #0x0                ; =0
    eba8:      	add	sp, sp, #0x250
    ebac:      	ldp	x29, x30, [sp, #0x50]
    ebb0:      	ldp	x20, x19, [sp, #0x40]
    ebb4:      	ldp	x22, x21, [sp, #0x30]
    ebb8:      	ldp	x24, x23, [sp, #0x20]
    ebbc:      	ldp	x26, x25, [sp, #0x10]
    ebc0:      	ldp	x28, x27, [sp], #0x60
    ebc4:      	ret
    ebc8:      	cbz	x20, 0xee8c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x328>
    ebcc:      	ldr	x25, [x2]
    ebd0:      	ldrb	w8, [x2, #0x8]
    ebd4:      	str	w8, [sp, #0x1c]
    ebd8:      	add	x8, x20, x20, lsl #4
    ebdc:      	lsl	x0, x8, #4
    ebe0:      	bl	0xebe0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x7c>
		000000000000ebe0:  ARM64_RELOC_BRANCH26	_malloc
    ebe4:      	cbz	x0, 0xee94 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x330>
    ebe8:      	mov	x21, x0
    ebec:      	mov	x8, #0x0                ; =0
    ebf0:      	add	x9, x0, #0x8
    ebf4:      	movi.2d	v0, #0000000000000000
    ebf8:      	stur	wzr, [x9, #-0x8]
    ebfc:      	add	x8, x8, #0x1
    ec00:      	stp	q0, q0, [x9]
    ec04:      	stp	q0, q0, [x9, #0x20]
    ec08:      	stp	q0, q0, [x9, #0x40]
    ec0c:      	stp	q0, q0, [x9, #0x60]
    ec10:      	stp	q0, q0, [x9, #0x80]
    ec14:      	stp	q0, q0, [x9, #0xa0]
    ec18:      	stp	q0, q0, [x9, #0xc0]
    ec1c:      	stp	q0, q0, [x9, #0xe0]
    ec20:      	str	xzr, [x9, #0x100]
    ec24:      	add	x9, x9, #0x110
    ec28:      	cmp	x20, x8
    ec2c:      	b.ne	0xebf8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x94>
    ec30:      	ldp	x9, x8, [x19, #0x8]
    ec34:      	str	x9, [sp, #0x10]
    ec38:      	str	x8, [sp, #0x20]
    ec3c:      	stp	x20, x20, [x19]
    ec40:      	str	x21, [x19, #0x10]
    ec44:      	cbz	x22, 0xee70 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x30c>
    ec48:      	mov	w26, #0x110             ; =272
    ec4c:      	add	x27, sp, #0x30
    ec50:      	mov	x24, #0x11eb            ; =4587
    ec54:      	movk	x24, #0x1331, lsl #16
    ec58:      	movk	x24, #0x49bb, lsl #32
    ec5c:      	movk	x24, #0x94d0, lsl #48
    ec60:      	b	0xec6c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x108>
    ec64:      	ldr	x22, [sp, #0x28]
    ec68:      	cbz	x22, 0xee70 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x30c>
    ec6c:      	sub	x22, x22, #0x1
    ec70:      	str	x22, [sp, #0x28]
    ec74:      	ldr	x8, [sp, #0x20]
    ec78:      	madd	x8, x22, x26, x8
    ec7c:      	ldr	w9, [x8]
    ec80:      	cmp	w9, #0x1
    ec84:      	b.ls	0xec64 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x100>
    ec88:      	ldr	x9, [x8, #0x108]
    ec8c:      	ldur	q0, [x8, #0x8]
    ec90:      	stur	q0, [sp, #0x38]
    ec94:      	ldur	q0, [x8, #0x18]
    ec98:      	stur	q0, [sp, #0x48]
    ec9c:      	ldur	q0, [x8, #0x28]
    eca0:      	stur	q0, [sp, #0x58]
    eca4:      	ldur	q0, [x8, #0x38]
    eca8:      	stur	q0, [sp, #0x68]
    ecac:      	ldur	q0, [x8, #0x48]
    ecb0:      	stur	q0, [sp, #0x78]
    ecb4:      	ldur	q0, [x8, #0x58]
    ecb8:      	stur	q0, [sp, #0x88]
    ecbc:      	ldur	q0, [x8, #0x68]
    ecc0:      	stur	q0, [sp, #0x98]
    ecc4:      	ldur	q0, [x8, #0x78]
    ecc8:      	stur	q0, [sp, #0xa8]
    eccc:      	ldur	q0, [x8, #0x88]
    ecd0:      	add	x10, sp, #0x30
    ecd4:      	stur	q0, [x10, #0x88]
    ecd8:      	ldur	q0, [x8, #0x98]
    ecdc:      	stur	q0, [x10, #0x98]
    ece0:      	ldur	q0, [x8, #0xa8]
    ece4:      	stur	q0, [x10, #0xa8]
    ece8:      	ldur	q0, [x8, #0xb8]
    ecec:      	stur	q0, [x10, #0xb8]
    ecf0:      	ldur	q0, [x8, #0xc8]
    ecf4:      	stur	q0, [x10, #0xc8]
    ecf8:      	ldur	q0, [x8, #0xd8]
    ecfc:      	stur	q0, [x10, #0xd8]
    ed00:      	ldur	q0, [x8, #0xe8]
    ed04:      	stur	q0, [x10, #0xe8]
    ed08:      	ldur	q0, [x8, #0xf8]
    ed0c:      	stur	q0, [x10, #0xf8]
    ed10:      	str	x9, [sp, #0x138]
    ed14:      	mov	w8, #0x1                ; =1
    ed18:      	str	x8, [sp, #0x30]
    ed1c:      	ldr	w8, [sp, #0x1c]
    ed20:      	tbz	w8, #0x0, 0xeda8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x244>
    ed24:      	mov	w28, #0x1               ; =1
    ed28:      	b	0xed74 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x210>
    ed2c:      	sub	x22, x28, #0x1
    ed30:      	str	x22, [sp, #0x30]
    ed34:      	mov	w8, #0x108              ; =264
    ed38:      	madd	x23, x28, x8, x27
    ed3c:      	ldr	x3, [x23, #-0x100]!
    ed40:      	add	x0, sp, #0x140
    ed44:      	add	x4, x23, #0x8
    ed48:      	mov	x1, x19
    ed4c:      	bl	0xed4c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x1e8>
		000000000000ed4c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    ed50:      	ldr	w8, [sp, #0x140]
    ed54:      	cbz	w8, 0xed9c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x238>
    ed58:      	add	x8, sp, #0x140
    ed5c:      	add	x1, x8, #0x8
    ed60:      	mov	x0, x23
    ed64:      	mov	w2, #0x108              ; =264
    ed68:      	bl	0xed68 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x204>
		000000000000ed68:  ARM64_RELOC_BRANCH26	_memcpy
    ed6c:      	str	x28, [sp, #0x30]
    ed70:      	cbz	x28, 0xec64 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x100>
    ed74:      	mov	x2, #0x0                ; =0
    ed78:      	mov	x8, x21
    ed7c:      	ldr	w9, [x8]
    ed80:      	cmp	w9, #0x2
    ed84:      	b.lo	0xed2c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x1c8>
    ed88:      	add	x8, x8, #0x110
    ed8c:      	add	x2, x2, #0x1
    ed90:      	cmp	x20, x2
    ed94:      	b.ne	0xed7c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x218>
    ed98:      	b	0xed70 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x20c>
    ed9c:      	mov	x28, x22
    eda0:      	cbnz	x22, 0xed74 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x210>
    eda4:      	b	0xec64 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x100>
    eda8:      	mov	w22, #0x1               ; =1
    edac:      	b	0xedf8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x294>
    edb0:      	sub	x28, x22, #0x1
    edb4:      	str	x28, [sp, #0x30]
    edb8:      	mov	w8, #0x108              ; =264
    edbc:      	madd	x23, x22, x8, x27
    edc0:      	ldr	x3, [x23, #-0x100]!
    edc4:      	add	x0, sp, #0x140
    edc8:      	add	x4, x23, #0x8
    edcc:      	mov	x1, x19
    edd0:      	bl	0xedd0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x26c>
		000000000000edd0:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    edd4:      	ldr	w8, [sp, #0x140]
    edd8:      	cbz	w8, 0xee64 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x300>
    eddc:      	add	x8, sp, #0x140
    ede0:      	add	x1, x8, #0x8
    ede4:      	mov	x0, x23
    ede8:      	mov	w2, #0x108              ; =264
    edec:      	bl	0xedec <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x288>
		000000000000edec:  ARM64_RELOC_BRANCH26	_memcpy
    edf0:      	str	x22, [sp, #0x30]
    edf4:      	cbz	x22, 0xec64 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x100>
    edf8:      	mov	x8, #0x0                ; =0
    edfc:      	ldr	x9, [sp, #0x38]
    ee00:      	eor	x9, x9, x25
    ee04:      	eor	x9, x9, x9, lsr #30
    ee08:      	mov	x10, #0xe5b9            ; =58809
    ee0c:      	movk	x10, #0x1ce4, lsl #16
    ee10:      	movk	x10, #0x476d, lsl #32
    ee14:      	movk	x10, #0xbf58, lsl #48
    ee18:      	mul	x9, x9, x10
    ee1c:      	eor	x9, x9, x9, lsr #27
    ee20:      	mul	x9, x9, x24
    ee24:      	eor	x9, x9, x9, lsr #31
    ee28:      	udiv	x10, x9, x20
    ee2c:      	msub	x9, x10, x20, x9
    ee30:      	sub	x10, x20, x9
    ee34:      	neg	x11, x10
    ee38:      	cmp	x8, x10
    ee3c:      	csel	x12, x9, x11, lo
    ee40:      	add	x2, x12, x8
    ee44:      	mul	x12, x2, x26
    ee48:      	ldr	w12, [x21, x12]
    ee4c:      	cmp	w12, #0x2
    ee50:      	b.lo	0xedb0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x24c>
    ee54:      	add	x8, x8, #0x1
    ee58:      	cmp	x20, x8
    ee5c:      	b.ne	0xee38 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x2d4>
    ee60:      	b	0xedf4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x290>
    ee64:      	mov	x22, x28
    ee68:      	cbnz	x28, 0xedf8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x294>
    ee6c:      	b	0xec64 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x100>
    ee70:      	ldr	x8, [sp, #0x10]
    ee74:      	cbz	x8, 0xee80 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x31c>
    ee78:      	ldr	x0, [sp, #0x20]
    ee7c:      	bl	0xee7c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x318>
		000000000000ee7c:  ARM64_RELOC_BRANCH26	_free
    ee80:      	mov	w0, #0x0                ; =0
    ee84:      	str	xzr, [x19, #0x20]
    ee88:      	b	0xeba0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x3c>
    ee8c:      	mov	w0, #0x0                ; =0
    ee90:      	b	0xeba0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x3c>
    ee94:      	bl	0xee94 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x330>
		000000000000ee94:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000ee98 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07>:
    ee98:      	sub	sp, sp, #0x120
    ee9c:      	stp	x28, x27, [sp, #0x100]
    eea0:      	stp	x29, x30, [sp, #0x110]
    eea4:      	mov	x9, x2
    eea8:      	ldp	q0, q1, [x3, #0xc0]
    eeac:      	stp	q0, q1, [sp, #0xc0]
    eeb0:      	ldp	q0, q1, [x3, #0xe0]
    eeb4:      	stp	q0, q1, [sp, #0xe0]
    eeb8:      	ldp	q0, q1, [x3, #0x80]
    eebc:      	stp	q0, q1, [sp, #0x80]
    eec0:      	ldp	q0, q1, [x3, #0xa0]
    eec4:      	stp	q0, q1, [sp, #0xa0]
    eec8:      	ldp	q0, q1, [x3, #0x40]
    eecc:      	stp	q0, q1, [sp, #0x40]
    eed0:      	ldp	q0, q1, [x3, #0x60]
    eed4:      	stp	q0, q1, [sp, #0x60]
    eed8:      	ldp	q0, q1, [x3]
    eedc:      	stp	q0, q1, [sp]
    eee0:      	ldp	q0, q1, [x3, #0x20]
    eee4:      	stp	q0, q1, [sp, #0x20]
    eee8:      	ldrb	w8, [x4, #0x8]
    eeec:      	tbz	w8, #0x0, 0xef78 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0xe0>
    eef0:      	mov	x8, #0x0                ; =0
    eef4:      	ldr	x10, [x1]
    eef8:      	cbz	x10, 0xefbc <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x124>
    eefc:      	udiv	x11, x8, x10
    ef00:      	msub	x8, x11, x10, x8
    ef04:      	ldr	x11, [x1, #0x10]
    ef08:      	mov	w12, #0x110             ; =272
    ef0c:      	mov	x13, x10
    ef10:      	mov	x2, x10
    ef14:      	b	0xef34 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x9c>
    ef18:      	cmp	x2, x10
    ef1c:      	csel	x2, x8, x2, eq
    ef20:      	add	x14, x8, #0x1
    ef24:      	cmp	x14, x10
    ef28:      	csinc	x8, xzr, x8, hs
    ef2c:      	subs	x13, x13, #0x1
    ef30:      	b.eq	0xefc0 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x128>
    ef34:      	madd	x14, x8, x12, x11
    ef38:      	ldr	w15, [x14]
    ef3c:      	cmp	w15, #0x1
    ef40:      	b.eq	0xef18 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x80>
    ef44:      	cmp	w15, #0x2
    ef48:      	b.ne	0xf020 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x188>
    ef4c:      	ldr	x14, [x14, #0x8]
    ef50:      	cmp	x14, x9
    ef54:      	b.ne	0xef20 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x88>
    ef58:      	mov	x4, sp
    ef5c:      	mov	x2, x8
    ef60:      	mov	x3, x9
    ef64:      	bl	0xef64 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0xcc>
		000000000000ef64:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    ef68:      	ldp	x29, x30, [sp, #0x110]
    ef6c:      	ldp	x28, x27, [sp, #0x100]
    ef70:      	add	sp, sp, #0x120
    ef74:      	ret
    ef78:      	ldr	x8, [x4]
    ef7c:      	eor	x8, x8, x9
    ef80:      	eor	x8, x8, x8, lsr #30
    ef84:      	mov	x10, #0xe5b9            ; =58809
    ef88:      	movk	x10, #0x1ce4, lsl #16
    ef8c:      	movk	x10, #0x476d, lsl #32
    ef90:      	movk	x10, #0xbf58, lsl #48
    ef94:      	mul	x8, x8, x10
    ef98:      	eor	x8, x8, x8, lsr #27
    ef9c:      	mov	x10, #0x11eb            ; =4587
    efa0:      	movk	x10, #0x1331, lsl #16
    efa4:      	movk	x10, #0x49bb, lsl #32
    efa8:      	movk	x10, #0x94d0, lsl #48
    efac:      	mul	x8, x8, x10
    efb0:      	eor	x8, x8, x8, lsr #31
    efb4:      	ldr	x10, [x1]
    efb8:      	cbnz	x10, 0xeefc <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x64>
    efbc:      	mov	x2, #0x0                ; =0
    efc0:      	cmp	x2, x10
    efc4:      	b.hs	0xf030 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x198>
    efc8:      	ldr	x8, [x1, #0x18]
    efcc:      	cmp	x8, #0x2
    efd0:      	b.hi	0xf030 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x198>
    efd4:      	add	x8, x8, #0x1
    efd8:      	str	x8, [x1, #0x18]
    efdc:      	ldr	x8, [x1, #0x10]
    efe0:      	mov	w10, #0x110             ; =272
    efe4:      	mul	x10, x2, x10
    efe8:      	ldr	w8, [x8, x10]
    efec:      	cmp	w8, #0x1
    eff0:      	b.ne	0xf004 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x16c>
    eff4:      	ldr	x8, [x1, #0x20]
    eff8:      	subs	x8, x8, #0x1
    effc:      	csel	x8, xzr, x8, lo
    f000:      	str	x8, [x1, #0x20]
    f004:      	mov	x4, sp
    f008:      	mov	x3, x9
    f00c:      	bl	0xf00c <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x174>
		000000000000f00c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    f010:      	ldp	x29, x30, [sp, #0x110]
    f014:      	ldp	x28, x27, [sp, #0x100]
    f018:      	add	sp, sp, #0x120
    f01c:      	ret
    f020:      	cmp	x2, x10
    f024:      	csel	x2, x8, x2, eq
    f028:      	cmp	x2, x10
    f02c:      	b.lo	0xefc8 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x130>
    f030:      	stp	xzr, x9, [x0]
    f034:      	mov	w8, #0x1                ; =1
    f038:      	str	w8, [x0]
    f03c:      	strb	w8, [x0, #0x4]
    f040:      	ldp	q0, q1, [sp]
    f044:      	stp	q0, q1, [x0, #0x10]
    f048:      	ldp	q0, q1, [sp, #0x20]
    f04c:      	stp	q0, q1, [x0, #0x30]
    f050:      	ldp	q0, q1, [sp, #0x40]
    f054:      	stp	q0, q1, [x0, #0x50]
    f058:      	ldp	q0, q1, [sp, #0x60]
    f05c:      	stp	q0, q1, [x0, #0x70]
    f060:      	ldp	q0, q1, [sp, #0x80]
    f064:      	stp	q0, q1, [x0, #0x90]
    f068:      	ldp	q0, q1, [sp, #0xa0]
    f06c:      	stp	q0, q1, [x0, #0xb0]
    f070:      	ldp	q0, q1, [sp, #0xc0]
    f074:      	stp	q0, q1, [x0, #0xd0]
    f078:      	ldp	q0, q1, [sp, #0xe0]
    f07c:      	stp	q0, q1, [x0, #0xf0]
    f080:      	ldp	x29, x30, [sp, #0x110]
    f084:      	ldp	x28, x27, [sp, #0x100]
    f088:      	add	sp, sp, #0x120
    f08c:      	ret

000000000000f090 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374>:
    f090:      	stp	x24, x23, [sp, #-0x40]!
    f094:      	stp	x22, x21, [sp, #0x10]
    f098:      	stp	x20, x19, [sp, #0x20]
    f09c:      	stp	x29, x30, [sp, #0x30]
    f0a0:      	mov	x20, x1
    f0a4:      	mov	x19, x0
    f0a8:      	ldp	x23, x22, [x0]
    f0ac:      	cmp	x22, x1
    f0b0:      	b.hs	0xf110 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x80>
    f0b4:      	ldr	x21, [x19, #0x10]
    f0b8:      	add	x8, x20, x20, lsl #4
    f0bc:      	lsl	x1, x8, #4
    f0c0:      	cmp	x22, #0x0
    f0c4:      	ccmp	x23, x22, #0x0, ne
    f0c8:      	b.eq	0xf100 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x70>
    f0cc:      	mov	x0, x1
    f0d0:      	bl	0xf0d0 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x40>
		000000000000f0d0:  ARM64_RELOC_BRANCH26	_malloc
    f0d4:      	cbz	x0, 0xf180 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xf0>
    f0d8:      	cbz	x22, 0xf10c <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x7c>
    f0dc:      	add	x8, x23, x23, lsl #4
    f0e0:      	lsl	x2, x8, #4
    f0e4:      	mov	x22, x0
    f0e8:      	mov	x1, x21
    f0ec:      	bl	0xf0ec <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x5c>
		000000000000f0ec:  ARM64_RELOC_BRANCH26	_memcpy
    f0f0:      	mov	x0, x21
    f0f4:      	bl	0xf0f4 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x64>
		000000000000f0f4:  ARM64_RELOC_BRANCH26	_free
    f0f8:      	mov	x0, x22
    f0fc:      	b	0xf10c <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x7c>
    f100:      	mov	x0, x21
    f104:      	bl	0xf104 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x74>
		000000000000f104:  ARM64_RELOC_BRANCH26	_realloc
    f108:      	cbz	x0, 0xf180 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xf0>
    f10c:      	stp	x20, x0, [x19, #0x8]
    f110:      	cmp	x23, x20
    f114:      	b.hs	0xf168 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xd8>
    f118:      	ldr	x8, [x19, #0x10]
    f11c:      	mov	w9, #0x110              ; =272
    f120:      	madd	x8, x23, x9, x8
    f124:      	add	x8, x8, #0x8
    f128:      	movi.2d	v0, #0000000000000000
    f12c:      	stur	wzr, [x8, #-0x8]
    f130:      	add	x23, x23, #0x1
    f134:      	stp	q0, q0, [x8]
    f138:      	stp	q0, q0, [x8, #0x20]
    f13c:      	stp	q0, q0, [x8, #0x40]
    f140:      	stp	q0, q0, [x8, #0x60]
    f144:      	stp	q0, q0, [x8, #0x80]
    f148:      	stp	q0, q0, [x8, #0xa0]
    f14c:      	stp	q0, q0, [x8, #0xc0]
    f150:      	stp	q0, q0, [x8, #0xe0]
    f154:      	str	xzr, [x8, #0x100]
    f158:      	add	x8, x8, #0x110
    f15c:      	cmp	x20, x23
    f160:      	b.ne	0xf12c <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x9c>
    f164:      	str	x23, [x19]
    f168:      	mov	w0, #0x0                ; =0
    f16c:      	ldp	x29, x30, [sp, #0x30]
    f170:      	ldp	x20, x19, [sp, #0x20]
    f174:      	ldp	x22, x21, [sp, #0x10]
    f178:      	ldp	x24, x23, [sp], #0x40
    f17c:      	ret
    f180:      	bl	0xf180 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xf0>
		000000000000f180:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000f184 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65>:
    f184:      	stp	x28, x27, [sp, #-0x60]!
    f188:      	stp	x26, x25, [sp, #0x10]
    f18c:      	stp	x24, x23, [sp, #0x20]
    f190:      	stp	x22, x21, [sp, #0x30]
    f194:      	stp	x20, x19, [sp, #0x40]
    f198:      	stp	x29, x30, [sp, #0x50]
    f19c:      	sub	sp, sp, #0x250
    f1a0:      	cmp	x1, #0x4, lsl #12       ; =0x4000
    f1a4:      	b.hi	0xf1bc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x38>
    f1a8:      	mov	x20, x1
    f1ac:      	mov	x19, x0
    f1b0:      	ldr	x22, [x0]
    f1b4:      	cmp	x1, x22
    f1b8:      	b.hs	0xf1e8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x64>
    f1bc:      	mov	w0, #0x1                ; =1
    f1c0:      	mov	w1, #0x0                ; =0
    f1c4:      	mov	w2, #0x0                ; =0
    f1c8:      	add	sp, sp, #0x250
    f1cc:      	ldp	x29, x30, [sp, #0x50]
    f1d0:      	ldp	x20, x19, [sp, #0x40]
    f1d4:      	ldp	x22, x21, [sp, #0x30]
    f1d8:      	ldp	x24, x23, [sp, #0x20]
    f1dc:      	ldp	x26, x25, [sp, #0x10]
    f1e0:      	ldp	x28, x27, [sp], #0x60
    f1e4:      	ret
    f1e8:      	cbz	x20, 0xf4ac <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x328>
    f1ec:      	ldr	x25, [x2]
    f1f0:      	ldrb	w8, [x2, #0x8]
    f1f4:      	str	w8, [sp, #0x1c]
    f1f8:      	add	x8, x20, x20, lsl #4
    f1fc:      	lsl	x0, x8, #4
    f200:      	bl	0xf200 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x7c>
		000000000000f200:  ARM64_RELOC_BRANCH26	_malloc
    f204:      	cbz	x0, 0xf4b4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x330>
    f208:      	mov	x21, x0
    f20c:      	mov	x8, #0x0                ; =0
    f210:      	add	x9, x0, #0x8
    f214:      	movi.2d	v0, #0000000000000000
    f218:      	stur	wzr, [x9, #-0x8]
    f21c:      	add	x8, x8, #0x1
    f220:      	stp	q0, q0, [x9]
    f224:      	stp	q0, q0, [x9, #0x20]
    f228:      	stp	q0, q0, [x9, #0x40]
    f22c:      	stp	q0, q0, [x9, #0x60]
    f230:      	stp	q0, q0, [x9, #0x80]
    f234:      	stp	q0, q0, [x9, #0xa0]
    f238:      	stp	q0, q0, [x9, #0xc0]
    f23c:      	stp	q0, q0, [x9, #0xe0]
    f240:      	str	xzr, [x9, #0x100]
    f244:      	add	x9, x9, #0x110
    f248:      	cmp	x20, x8
    f24c:      	b.ne	0xf218 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x94>
    f250:      	ldp	x9, x8, [x19, #0x8]
    f254:      	str	x9, [sp, #0x10]
    f258:      	str	x8, [sp, #0x20]
    f25c:      	stp	x20, x20, [x19]
    f260:      	str	x21, [x19, #0x10]
    f264:      	cbz	x22, 0xf490 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x30c>
    f268:      	mov	w26, #0x110             ; =272
    f26c:      	add	x27, sp, #0x30
    f270:      	mov	x24, #0x11eb            ; =4587
    f274:      	movk	x24, #0x1331, lsl #16
    f278:      	movk	x24, #0x49bb, lsl #32
    f27c:      	movk	x24, #0x94d0, lsl #48
    f280:      	b	0xf28c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x108>
    f284:      	ldr	x22, [sp, #0x28]
    f288:      	cbz	x22, 0xf490 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x30c>
    f28c:      	sub	x22, x22, #0x1
    f290:      	str	x22, [sp, #0x28]
    f294:      	ldr	x8, [sp, #0x20]
    f298:      	madd	x8, x22, x26, x8
    f29c:      	ldr	w9, [x8]
    f2a0:      	cmp	w9, #0x1
    f2a4:      	b.ls	0xf284 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x100>
    f2a8:      	ldr	x9, [x8, #0x108]
    f2ac:      	ldur	q0, [x8, #0x8]
    f2b0:      	stur	q0, [sp, #0x38]
    f2b4:      	ldur	q0, [x8, #0x18]
    f2b8:      	stur	q0, [sp, #0x48]
    f2bc:      	ldur	q0, [x8, #0x28]
    f2c0:      	stur	q0, [sp, #0x58]
    f2c4:      	ldur	q0, [x8, #0x38]
    f2c8:      	stur	q0, [sp, #0x68]
    f2cc:      	ldur	q0, [x8, #0x48]
    f2d0:      	stur	q0, [sp, #0x78]
    f2d4:      	ldur	q0, [x8, #0x58]
    f2d8:      	stur	q0, [sp, #0x88]
    f2dc:      	ldur	q0, [x8, #0x68]
    f2e0:      	stur	q0, [sp, #0x98]
    f2e4:      	ldur	q0, [x8, #0x78]
    f2e8:      	stur	q0, [sp, #0xa8]
    f2ec:      	ldur	q0, [x8, #0x88]
    f2f0:      	add	x10, sp, #0x30
    f2f4:      	stur	q0, [x10, #0x88]
    f2f8:      	ldur	q0, [x8, #0x98]
    f2fc:      	stur	q0, [x10, #0x98]
    f300:      	ldur	q0, [x8, #0xa8]
    f304:      	stur	q0, [x10, #0xa8]
    f308:      	ldur	q0, [x8, #0xb8]
    f30c:      	stur	q0, [x10, #0xb8]
    f310:      	ldur	q0, [x8, #0xc8]
    f314:      	stur	q0, [x10, #0xc8]
    f318:      	ldur	q0, [x8, #0xd8]
    f31c:      	stur	q0, [x10, #0xd8]
    f320:      	ldur	q0, [x8, #0xe8]
    f324:      	stur	q0, [x10, #0xe8]
    f328:      	ldur	q0, [x8, #0xf8]
    f32c:      	stur	q0, [x10, #0xf8]
    f330:      	str	x9, [sp, #0x138]
    f334:      	mov	w8, #0x1                ; =1
    f338:      	str	x8, [sp, #0x30]
    f33c:      	ldr	w8, [sp, #0x1c]
    f340:      	tbz	w8, #0x0, 0xf3c8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x244>
    f344:      	mov	w28, #0x1               ; =1
    f348:      	b	0xf394 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x210>
    f34c:      	sub	x22, x28, #0x1
    f350:      	str	x22, [sp, #0x30]
    f354:      	mov	w8, #0x108              ; =264
    f358:      	madd	x23, x28, x8, x27
    f35c:      	ldr	x3, [x23, #-0x100]!
    f360:      	add	x0, sp, #0x140
    f364:      	add	x4, x23, #0x8
    f368:      	mov	x1, x19
    f36c:      	bl	0xf36c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x1e8>
		000000000000f36c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    f370:      	ldr	w8, [sp, #0x140]
    f374:      	cbz	w8, 0xf3bc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x238>
    f378:      	add	x8, sp, #0x140
    f37c:      	add	x1, x8, #0x8
    f380:      	mov	x0, x23
    f384:      	mov	w2, #0x108              ; =264
    f388:      	bl	0xf388 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x204>
		000000000000f388:  ARM64_RELOC_BRANCH26	_memcpy
    f38c:      	str	x28, [sp, #0x30]
    f390:      	cbz	x28, 0xf284 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x100>
    f394:      	mov	x2, #0x0                ; =0
    f398:      	mov	x8, x21
    f39c:      	ldr	w9, [x8]
    f3a0:      	cmp	w9, #0x2
    f3a4:      	b.lo	0xf34c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x1c8>
    f3a8:      	add	x8, x8, #0x110
    f3ac:      	add	x2, x2, #0x1
    f3b0:      	cmp	x20, x2
    f3b4:      	b.ne	0xf39c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x218>
    f3b8:      	b	0xf390 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x20c>
    f3bc:      	mov	x28, x22
    f3c0:      	cbnz	x22, 0xf394 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x210>
    f3c4:      	b	0xf284 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x100>
    f3c8:      	mov	w22, #0x1               ; =1
    f3cc:      	b	0xf418 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x294>
    f3d0:      	sub	x28, x22, #0x1
    f3d4:      	str	x28, [sp, #0x30]
    f3d8:      	mov	w8, #0x108              ; =264
    f3dc:      	madd	x23, x22, x8, x27
    f3e0:      	ldr	x3, [x23, #-0x100]!
    f3e4:      	add	x0, sp, #0x140
    f3e8:      	add	x4, x23, #0x8
    f3ec:      	mov	x1, x19
    f3f0:      	bl	0xf3f0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x26c>
		000000000000f3f0:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    f3f4:      	ldr	w8, [sp, #0x140]
    f3f8:      	cbz	w8, 0xf484 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x300>
    f3fc:      	add	x8, sp, #0x140
    f400:      	add	x1, x8, #0x8
    f404:      	mov	x0, x23
    f408:      	mov	w2, #0x108              ; =264
    f40c:      	bl	0xf40c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x288>
		000000000000f40c:  ARM64_RELOC_BRANCH26	_memcpy
    f410:      	str	x22, [sp, #0x30]
    f414:      	cbz	x22, 0xf284 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x100>
    f418:      	mov	x8, #0x0                ; =0
    f41c:      	ldr	x9, [sp, #0x38]
    f420:      	eor	x9, x9, x25
    f424:      	eor	x9, x9, x9, lsr #30
    f428:      	mov	x10, #0xe5b9            ; =58809
    f42c:      	movk	x10, #0x1ce4, lsl #16
    f430:      	movk	x10, #0x476d, lsl #32
    f434:      	movk	x10, #0xbf58, lsl #48
    f438:      	mul	x9, x9, x10
    f43c:      	eor	x9, x9, x9, lsr #27
    f440:      	mul	x9, x9, x24
    f444:      	eor	x9, x9, x9, lsr #31
    f448:      	udiv	x10, x9, x20
    f44c:      	msub	x9, x10, x20, x9
    f450:      	sub	x10, x20, x9
    f454:      	neg	x11, x10
    f458:      	cmp	x8, x10
    f45c:      	csel	x12, x9, x11, lo
    f460:      	add	x2, x12, x8
    f464:      	mul	x12, x2, x26
    f468:      	ldr	w12, [x21, x12]
    f46c:      	cmp	w12, #0x2
    f470:      	b.lo	0xf3d0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x24c>
    f474:      	add	x8, x8, #0x1
    f478:      	cmp	x20, x8
    f47c:      	b.ne	0xf458 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x2d4>
    f480:      	b	0xf414 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x290>
    f484:      	mov	x22, x28
    f488:      	cbnz	x28, 0xf418 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x294>
    f48c:      	b	0xf284 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x100>
    f490:      	ldr	x8, [sp, #0x10]
    f494:      	cbz	x8, 0xf4a0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x31c>
    f498:      	ldr	x0, [sp, #0x20]
    f49c:      	bl	0xf49c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x318>
		000000000000f49c:  ARM64_RELOC_BRANCH26	_free
    f4a0:      	mov	w0, #0x0                ; =0
    f4a4:      	str	xzr, [x19, #0x20]
    f4a8:      	b	0xf1c0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x3c>
    f4ac:      	mov	w0, #0x0                ; =0
    f4b0:      	b	0xf1c0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x3c>
    f4b4:      	bl	0xf4b4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x330>
		000000000000f4b4:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000f4b8 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65>:
    f4b8:      	sub	sp, sp, #0x120
    f4bc:      	stp	x28, x27, [sp, #0x100]
    f4c0:      	stp	x29, x30, [sp, #0x110]
    f4c4:      	mov	x9, x2
    f4c8:      	ldp	q0, q1, [x3, #0xc0]
    f4cc:      	stp	q0, q1, [sp, #0xc0]
    f4d0:      	ldp	q0, q1, [x3, #0xe0]
    f4d4:      	stp	q0, q1, [sp, #0xe0]
    f4d8:      	ldp	q0, q1, [x3, #0x80]
    f4dc:      	stp	q0, q1, [sp, #0x80]
    f4e0:      	ldp	q0, q1, [x3, #0xa0]
    f4e4:      	stp	q0, q1, [sp, #0xa0]
    f4e8:      	ldp	q0, q1, [x3, #0x40]
    f4ec:      	stp	q0, q1, [sp, #0x40]
    f4f0:      	ldp	q0, q1, [x3, #0x60]
    f4f4:      	stp	q0, q1, [sp, #0x60]
    f4f8:      	ldp	q0, q1, [x3]
    f4fc:      	stp	q0, q1, [sp]
    f500:      	ldp	q0, q1, [x3, #0x20]
    f504:      	stp	q0, q1, [sp, #0x20]
    f508:      	ldrb	w8, [x4, #0x8]
    f50c:      	tbz	w8, #0x0, 0xf598 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0xe0>
    f510:      	mov	x8, #0x0                ; =0
    f514:      	ldr	x10, [x1]
    f518:      	cbz	x10, 0xf5dc <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x124>
    f51c:      	udiv	x11, x8, x10
    f520:      	msub	x8, x11, x10, x8
    f524:      	ldr	x11, [x1, #0x10]
    f528:      	mov	w12, #0x110             ; =272
    f52c:      	mov	x13, x10
    f530:      	mov	x2, x10
    f534:      	b	0xf554 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x9c>
    f538:      	cmp	x2, x10
    f53c:      	csel	x2, x8, x2, eq
    f540:      	add	x14, x8, #0x1
    f544:      	cmp	x14, x10
    f548:      	csinc	x8, xzr, x8, hs
    f54c:      	subs	x13, x13, #0x1
    f550:      	b.eq	0xf5e0 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x128>
    f554:      	madd	x14, x8, x12, x11
    f558:      	ldr	w15, [x14]
    f55c:      	cmp	w15, #0x1
    f560:      	b.eq	0xf538 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x80>
    f564:      	cmp	w15, #0x2
    f568:      	b.ne	0xf640 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x188>
    f56c:      	ldr	x14, [x14, #0x8]
    f570:      	cmp	x14, x9
    f574:      	b.ne	0xf540 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x88>
    f578:      	mov	x4, sp
    f57c:      	mov	x2, x8
    f580:      	mov	x3, x9
    f584:      	bl	0xf584 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0xcc>
		000000000000f584:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    f588:      	ldp	x29, x30, [sp, #0x110]
    f58c:      	ldp	x28, x27, [sp, #0x100]
    f590:      	add	sp, sp, #0x120
    f594:      	ret
    f598:      	ldr	x8, [x4]
    f59c:      	eor	x8, x8, x9
    f5a0:      	eor	x8, x8, x8, lsr #30
    f5a4:      	mov	x10, #0xe5b9            ; =58809
    f5a8:      	movk	x10, #0x1ce4, lsl #16
    f5ac:      	movk	x10, #0x476d, lsl #32
    f5b0:      	movk	x10, #0xbf58, lsl #48
    f5b4:      	mul	x8, x8, x10
    f5b8:      	eor	x8, x8, x8, lsr #27
    f5bc:      	mov	x10, #0x11eb            ; =4587
    f5c0:      	movk	x10, #0x1331, lsl #16
    f5c4:      	movk	x10, #0x49bb, lsl #32
    f5c8:      	movk	x10, #0x94d0, lsl #48
    f5cc:      	mul	x8, x8, x10
    f5d0:      	eor	x8, x8, x8, lsr #31
    f5d4:      	ldr	x10, [x1]
    f5d8:      	cbnz	x10, 0xf51c <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x64>
    f5dc:      	mov	x2, #0x0                ; =0
    f5e0:      	cmp	x2, x10
    f5e4:      	b.hs	0xf650 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x198>
    f5e8:      	ldr	x8, [x1, #0x18]
    f5ec:      	lsr	x10, x8, #14
    f5f0:      	cbnz	x10, 0xf650 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x198>
    f5f4:      	add	x8, x8, #0x1
    f5f8:      	str	x8, [x1, #0x18]
    f5fc:      	ldr	x8, [x1, #0x10]
    f600:      	mov	w10, #0x110             ; =272
    f604:      	mul	x10, x2, x10
    f608:      	ldr	w8, [x8, x10]
    f60c:      	cmp	w8, #0x1
    f610:      	b.ne	0xf624 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x16c>
    f614:      	ldr	x8, [x1, #0x20]
    f618:      	subs	x8, x8, #0x1
    f61c:      	csel	x8, xzr, x8, lo
    f620:      	str	x8, [x1, #0x20]
    f624:      	mov	x4, sp
    f628:      	mov	x3, x9
    f62c:      	bl	0xf62c <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x174>
		000000000000f62c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    f630:      	ldp	x29, x30, [sp, #0x110]
    f634:      	ldp	x28, x27, [sp, #0x100]
    f638:      	add	sp, sp, #0x120
    f63c:      	ret
    f640:      	cmp	x2, x10
    f644:      	csel	x2, x8, x2, eq
    f648:      	cmp	x2, x10
    f64c:      	b.lo	0xf5e8 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x130>
    f650:      	stp	xzr, x9, [x0]
    f654:      	mov	w8, #0x1                ; =1
    f658:      	str	w8, [x0]
    f65c:      	strb	w8, [x0, #0x4]
    f660:      	ldp	q0, q1, [sp]
    f664:      	stp	q0, q1, [x0, #0x10]
    f668:      	ldp	q0, q1, [sp, #0x20]
    f66c:      	stp	q0, q1, [x0, #0x30]
    f670:      	ldp	q0, q1, [sp, #0x40]
    f674:      	stp	q0, q1, [x0, #0x50]
    f678:      	ldp	q0, q1, [sp, #0x60]
    f67c:      	stp	q0, q1, [x0, #0x70]
    f680:      	ldp	q0, q1, [sp, #0x80]
    f684:      	stp	q0, q1, [x0, #0x90]
    f688:      	ldp	q0, q1, [sp, #0xa0]
    f68c:      	stp	q0, q1, [x0, #0xb0]
    f690:      	ldp	q0, q1, [sp, #0xc0]
    f694:      	stp	q0, q1, [x0, #0xd0]
    f698:      	ldp	q0, q1, [sp, #0xe0]
    f69c:      	stp	q0, q1, [x0, #0xf0]
    f6a0:      	ldp	x29, x30, [sp, #0x110]
    f6a4:      	ldp	x28, x27, [sp, #0x100]
    f6a8:      	add	sp, sp, #0x120
    f6ac:      	ret

000000000000f6b0 <_wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65>:
    f6b0:      	ldrb	w8, [x2, #0x8]
    f6b4:      	tbz	w8, #0x0, 0xf6c8 <_wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65+0x18>
    f6b8:      	mov	x8, #0x0                ; =0
    f6bc:      	ldr	x9, [x0]
    f6c0:      	cbnz	x9, 0xf710 <_wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65+0x60>
    f6c4:      	b	0xf774 <_wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65+0xc4>
    f6c8:      	ldr	x8, [x2]
    f6cc:      	ldr	x9, [x1]
    f6d0:      	eor	x8, x9, x8
    f6d4:      	eor	x8, x8, x8, lsr #30
    f6d8:      	mov	x9, #0xe5b9             ; =58809
    f6dc:      	movk	x9, #0x1ce4, lsl #16
    f6e0:      	movk	x9, #0x476d, lsl #32
    f6e4:      	movk	x9, #0xbf58, lsl #48
    f6e8:      	mul	x8, x8, x9
    f6ec:      	eor	x8, x8, x8, lsr #27
    f6f0:      	mov	x9, #0x11eb             ; =4587
    f6f4:      	movk	x9, #0x1331, lsl #16
    f6f8:      	movk	x9, #0x49bb, lsl #32
    f6fc:      	movk	x9, #0x94d0, lsl #48
    f700:      	mul	x8, x8, x9
    f704:      	eor	x8, x8, x8, lsr #31
    f708:      	ldr	x9, [x0]
    f70c:      	cbz	x9, 0xf774 <_wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65+0xc4>
    f710:      	udiv	x10, x8, x9
    f714:      	msub	x8, x10, x9, x8
    f718:      	ldr	x10, [x0, #0x10]
    f71c:      	mov	w11, #0x110             ; =272
    f720:      	mov	x12, x9
    f724:      	b	0xf73c <_wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65+0x8c>
    f728:      	add	x13, x8, #0x1
    f72c:      	cmp	x13, x9
    f730:      	csinc	x8, xzr, x8, hs
    f734:      	subs	x12, x12, #0x1
    f738:      	b.eq	0xf774 <_wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65+0xc4>
    f73c:      	madd	x14, x8, x11, x10
    f740:      	ldr	w13, [x14]
    f744:      	cmp	w13, #0x1
    f748:      	b.eq	0xf728 <_wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65+0x78>
    f74c:      	cmp	w13, #0x2
    f750:      	b.ne	0xf788 <_wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65+0xd8>
    f754:      	ldr	x13, [x14, #0x8]
    f758:      	ldr	x14, [x1]
    f75c:      	cmp	x13, x14
    f760:      	b.ne	0xf728 <_wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65+0x78>
    f764:      	mov	w0, #0x0                ; =0
    f768:      	mov	x1, x8
    f76c:      	mov	w2, #0x0                ; =0
    f770:      	ret
    f774:      	mov	x8, #0x0                ; =0
    f778:      	mov	w0, #0x1                ; =1
    f77c:      	mov	x1, x8
    f780:      	mov	w2, #0x0                ; =0
    f784:      	ret
    f788:      	mov	w0, #0x1                ; =1
    f78c:      	mov	x8, x13
    f790:      	mov	x1, x8
    f794:      	mov	w2, #0x0                ; =0
    f798:      	ret

000000000000f79c <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14>:
    f79c:      	stp	x24, x23, [sp, #-0x40]!
    f7a0:      	stp	x22, x21, [sp, #0x10]
    f7a4:      	stp	x20, x19, [sp, #0x20]
    f7a8:      	stp	x29, x30, [sp, #0x30]
    f7ac:      	mov	x20, x1
    f7b0:      	mov	x19, x0
    f7b4:      	ldp	x23, x22, [x0]
    f7b8:      	cmp	x22, x1
    f7bc:      	b.hs	0xf81c <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0x80>
    f7c0:      	ldr	x21, [x19, #0x10]
    f7c4:      	add	x8, x20, x20, lsl #1
    f7c8:      	lsl	x1, x8, #3
    f7cc:      	cmp	x22, #0x0
    f7d0:      	ccmp	x23, x22, #0x0, ne
    f7d4:      	b.eq	0xf80c <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0x70>
    f7d8:      	mov	x0, x1
    f7dc:      	bl	0xf7dc <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0x40>
		000000000000f7dc:  ARM64_RELOC_BRANCH26	_malloc
    f7e0:      	cbz	x0, 0xf864 <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0xc8>
    f7e4:      	cbz	x22, 0xf818 <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0x7c>
    f7e8:      	add	x8, x23, x23, lsl #1
    f7ec:      	lsl	x2, x8, #3
    f7f0:      	mov	x22, x0
    f7f4:      	mov	x1, x21
    f7f8:      	bl	0xf7f8 <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0x5c>
		000000000000f7f8:  ARM64_RELOC_BRANCH26	_memcpy
    f7fc:      	mov	x0, x21
    f800:      	bl	0xf800 <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0x64>
		000000000000f800:  ARM64_RELOC_BRANCH26	_free
    f804:      	mov	x0, x22
    f808:      	b	0xf818 <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0x7c>
    f80c:      	mov	x0, x21
    f810:      	bl	0xf810 <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0x74>
		000000000000f810:  ARM64_RELOC_BRANCH26	_realloc
    f814:      	cbz	x0, 0xf864 <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0xc8>
    f818:      	stp	x20, x0, [x19, #0x8]
    f81c:      	cmp	x23, x20
    f820:      	b.hs	0xf84c <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0xb0>
    f824:      	ldr	x8, [x19, #0x10]
    f828:      	mov	w9, #0x18               ; =24
    f82c:      	madd	x8, x23, x9, x8
    f830:      	add	x8, x8, #0x8
    f834:      	stur	wzr, [x8, #-0x8]
    f838:      	add	x23, x23, #0x1
    f83c:      	stp	xzr, xzr, [x8], #0x18
    f840:      	cmp	x20, x23
    f844:      	b.ne	0xf834 <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0x98>
    f848:      	str	x23, [x19]
    f84c:      	mov	w0, #0x0                ; =0
    f850:      	ldp	x29, x30, [sp, #0x30]
    f854:      	ldp	x20, x19, [sp, #0x20]
    f858:      	ldp	x22, x21, [sp, #0x10]
    f85c:      	ldp	x24, x23, [sp], #0x40
    f860:      	ret
    f864:      	bl	0xf864 <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0xc8>
		000000000000f864:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000f868 <_wf_std.collections.hash_map.hash_map_action$instance$fc5e3cb62bdf3601>:
    f868:      	mov	x8, x0
    f86c:      	ldr	w0, [x0]
    f870:      	cmp	w0, #0x1
    f874:      	b.ls	0xf88c <_wf_std.collections.hash_map.hash_map_action$instance$fc5e3cb62bdf3601+0x24>
    f878:      	ldr	x8, [x8, #0x8]
    f87c:      	ldr	x9, [x1]
    f880:      	cmp	x8, x9
    f884:      	mov	w8, #0x2                ; =2
    f888:      	cinc	w0, w8, eq
    f88c:      	ret

000000000000f890 <_wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3>:
    f890:      	ldr	x8, [x1, #0x10]
    f894:      	mov	w9, #0x18               ; =24
    f898:      	madd	x9, x2, x9, x8
    f89c:      	ldr	w8, [x9]
    f8a0:      	ldur	q0, [x9, #0x8]
    f8a4:      	mov	w10, #0x2               ; =2
    f8a8:      	str	w10, [x9]
    f8ac:      	stp	x3, x4, [x9, #0x8]
    f8b0:      	cbz	w8, 0xf8bc <_wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3+0x2c>
    f8b4:      	cmp	w8, #0x1
    f8b8:      	b.ne	0xf8c8 <_wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3+0x38>
    f8bc:      	stp	xzr, xzr, [x0]
    f8c0:      	str	xzr, [x0, #0x10]
    f8c4:      	ret
    f8c8:      	str	xzr, [x0]
    f8cc:      	mov	w8, #0x1                ; =1
    f8d0:      	str	w8, [x0]
    f8d4:      	stur	q0, [x0, #0x8]
    f8d8:      	ret

000000000000f8dc <_wf_std.collections.hash_map.hash_map_is_deleted$instance$0ed342445dd803f3>:
    f8dc:      	ldr	w8, [x0]
    f8e0:      	cmp	w8, #0x1
    f8e4:      	cset	w0, eq
    f8e8:      	ret

000000000000f8ec <_wf_std.collections.hash_map.hash_map_find$instance$29255544f66aec6e>:
    f8ec:      	ldrb	w8, [x2, #0x8]
    f8f0:      	tbz	w8, #0x0, 0xf904 <_wf_std.collections.hash_map.hash_map_find$instance$29255544f66aec6e+0x18>
    f8f4:      	mov	x8, #0x0                ; =0
    f8f8:      	ldr	x9, [x0]
    f8fc:      	cbnz	x9, 0xf94c <_wf_std.collections.hash_map.hash_map_find$instance$29255544f66aec6e+0x60>
    f900:      	b	0xf9b0 <_wf_std.collections.hash_map.hash_map_find$instance$29255544f66aec6e+0xc4>
    f904:      	ldr	x8, [x2]
    f908:      	ldr	x9, [x1]
    f90c:      	eor	x8, x9, x8
    f910:      	eor	x8, x8, x8, lsr #30
    f914:      	mov	x9, #0xe5b9             ; =58809
    f918:      	movk	x9, #0x1ce4, lsl #16
    f91c:      	movk	x9, #0x476d, lsl #32
    f920:      	movk	x9, #0xbf58, lsl #48
    f924:      	mul	x8, x8, x9
    f928:      	eor	x8, x8, x8, lsr #27
    f92c:      	mov	x9, #0x11eb             ; =4587
    f930:      	movk	x9, #0x1331, lsl #16
    f934:      	movk	x9, #0x49bb, lsl #32
    f938:      	movk	x9, #0x94d0, lsl #48
    f93c:      	mul	x8, x8, x9
    f940:      	eor	x8, x8, x8, lsr #31
    f944:      	ldr	x9, [x0]
    f948:      	cbz	x9, 0xf9b0 <_wf_std.collections.hash_map.hash_map_find$instance$29255544f66aec6e+0xc4>
    f94c:      	udiv	x10, x8, x9
    f950:      	msub	x8, x10, x9, x8
    f954:      	ldr	x10, [x0, #0x10]
    f958:      	mov	w11, #0x18              ; =24
    f95c:      	mov	x12, x9
    f960:      	b	0xf978 <_wf_std.collections.hash_map.hash_map_find$instance$29255544f66aec6e+0x8c>
    f964:      	add	x13, x8, #0x1
    f968:      	cmp	x13, x9
    f96c:      	csinc	x8, xzr, x8, hs
    f970:      	subs	x12, x12, #0x1
    f974:      	b.eq	0xf9b0 <_wf_std.collections.hash_map.hash_map_find$instance$29255544f66aec6e+0xc4>
    f978:      	madd	x14, x8, x11, x10
    f97c:      	ldr	w13, [x14]
    f980:      	cmp	w13, #0x1
    f984:      	b.eq	0xf964 <_wf_std.collections.hash_map.hash_map_find$instance$29255544f66aec6e+0x78>
    f988:      	cmp	w13, #0x2
    f98c:      	b.ne	0xf9c4 <_wf_std.collections.hash_map.hash_map_find$instance$29255544f66aec6e+0xd8>
    f990:      	ldr	x13, [x14, #0x8]
    f994:      	ldr	x14, [x1]
    f998:      	cmp	x13, x14
    f99c:      	b.ne	0xf964 <_wf_std.collections.hash_map.hash_map_find$instance$29255544f66aec6e+0x78>
    f9a0:      	mov	w0, #0x0                ; =0
    f9a4:      	mov	x1, x8
    f9a8:      	mov	w2, #0x0                ; =0
    f9ac:      	ret
    f9b0:      	mov	x8, #0x0                ; =0
    f9b4:      	mov	w0, #0x1                ; =1
    f9b8:      	mov	x1, x8
    f9bc:      	mov	w2, #0x0                ; =0
    f9c0:      	ret
    f9c4:      	mov	w0, #0x1                ; =1
    f9c8:      	mov	x8, x13
    f9cc:      	mov	x1, x8
    f9d0:      	mov	w2, #0x0                ; =0
    f9d4:      	ret

000000000000f9d8 <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa>:
    f9d8:      	stp	x24, x23, [sp, #-0x40]!
    f9dc:      	stp	x22, x21, [sp, #0x10]
    f9e0:      	stp	x20, x19, [sp, #0x20]
    f9e4:      	stp	x29, x30, [sp, #0x30]
    f9e8:      	mov	x20, x1
    f9ec:      	mov	x19, x0
    f9f0:      	ldp	x23, x22, [x0]
    f9f4:      	cmp	x22, x1
    f9f8:      	b.hs	0xfa58 <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0x80>
    f9fc:      	ldr	x21, [x19, #0x10]
    fa00:      	add	x8, x20, x20, lsl #4
    fa04:      	lsl	x1, x8, #4
    fa08:      	cmp	x22, #0x0
    fa0c:      	ccmp	x23, x22, #0x0, ne
    fa10:      	b.eq	0xfa48 <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0x70>
    fa14:      	mov	x0, x1
    fa18:      	bl	0xfa18 <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0x40>
		000000000000fa18:  ARM64_RELOC_BRANCH26	_malloc
    fa1c:      	cbz	x0, 0xfac8 <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0xf0>
    fa20:      	cbz	x22, 0xfa54 <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0x7c>
    fa24:      	add	x8, x23, x23, lsl #4
    fa28:      	lsl	x2, x8, #4
    fa2c:      	mov	x22, x0
    fa30:      	mov	x1, x21
    fa34:      	bl	0xfa34 <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0x5c>
		000000000000fa34:  ARM64_RELOC_BRANCH26	_memcpy
    fa38:      	mov	x0, x21
    fa3c:      	bl	0xfa3c <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0x64>
		000000000000fa3c:  ARM64_RELOC_BRANCH26	_free
    fa40:      	mov	x0, x22
    fa44:      	b	0xfa54 <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0x7c>
    fa48:      	mov	x0, x21
    fa4c:      	bl	0xfa4c <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0x74>
		000000000000fa4c:  ARM64_RELOC_BRANCH26	_realloc
    fa50:      	cbz	x0, 0xfac8 <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0xf0>
    fa54:      	stp	x20, x0, [x19, #0x8]
    fa58:      	cmp	x23, x20
    fa5c:      	b.hs	0xfab0 <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0xd8>
    fa60:      	ldr	x8, [x19, #0x10]
    fa64:      	mov	w9, #0x110              ; =272
    fa68:      	madd	x8, x23, x9, x8
    fa6c:      	add	x8, x8, #0x8
    fa70:      	movi.2d	v0, #0000000000000000
    fa74:      	stur	wzr, [x8, #-0x8]
    fa78:      	add	x23, x23, #0x1
    fa7c:      	stp	q0, q0, [x8]
    fa80:      	stp	q0, q0, [x8, #0x20]
    fa84:      	stp	q0, q0, [x8, #0x40]
    fa88:      	stp	q0, q0, [x8, #0x60]
    fa8c:      	stp	q0, q0, [x8, #0x80]
    fa90:      	stp	q0, q0, [x8, #0xa0]
    fa94:      	stp	q0, q0, [x8, #0xc0]
    fa98:      	stp	q0, q0, [x8, #0xe0]
    fa9c:      	str	xzr, [x8, #0x100]
    faa0:      	add	x8, x8, #0x110
    faa4:      	cmp	x20, x23
    faa8:      	b.ne	0xfa74 <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0x9c>
    faac:      	str	x23, [x19]
    fab0:      	mov	w0, #0x0                ; =0
    fab4:      	ldp	x29, x30, [sp, #0x30]
    fab8:      	ldp	x20, x19, [sp, #0x20]
    fabc:      	ldp	x22, x21, [sp, #0x10]
    fac0:      	ldp	x24, x23, [sp], #0x40
    fac4:      	ret
    fac8:      	bl	0xfac8 <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0xf0>
		000000000000fac8:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000facc <_wf_std.collections.hash_map.hash_map_action$instance$c6df3d8464f8cde0>:
    facc:      	mov	x8, x0
    fad0:      	ldr	w0, [x0]
    fad4:      	cmp	w0, #0x1
    fad8:      	b.ls	0xfaf0 <_wf_std.collections.hash_map.hash_map_action$instance$c6df3d8464f8cde0+0x24>
    fadc:      	ldr	x8, [x8, #0x8]
    fae0:      	ldr	x9, [x1]
    fae4:      	cmp	x8, x9
    fae8:      	mov	w8, #0x2                ; =2
    faec:      	cinc	w0, w8, eq
    faf0:      	ret

000000000000faf4 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449>:
    faf4:      	stp	d15, d14, [sp, #-0x40]!
    faf8:      	stp	d13, d12, [sp, #0x10]
    fafc:      	stp	d11, d10, [sp, #0x20]
    fb00:      	stp	d9, d8, [sp, #0x30]
    fb04:      	ldr	x8, [x1, #0x10]
    fb08:      	mov	w9, #0x110              ; =272
    fb0c:      	madd	x10, x2, x9, x8
    fb10:      	ldr	w9, [x10]
    fb14:      	ldur	q0, [x10, #0x8]
    fb18:      	ldur	q1, [x10, #0x18]
    fb1c:      	ldur	q2, [x10, #0x28]
    fb20:      	ldur	q3, [x10, #0x38]
    fb24:      	ldur	q4, [x10, #0x48]
    fb28:      	ldur	q5, [x10, #0x58]
    fb2c:      	ldur	q6, [x10, #0x68]
    fb30:      	ldur	q7, [x10, #0x78]
    fb34:      	ldur	q16, [x10, #0x88]
    fb38:      	ldur	q17, [x10, #0x98]
    fb3c:      	ldur	q18, [x10, #0xa8]
    fb40:      	ldur	q19, [x10, #0xb8]
    fb44:      	ldur	q20, [x10, #0xc8]
    fb48:      	ldur	q21, [x10, #0xd8]
    fb4c:      	ldur	q22, [x10, #0xe8]
    fb50:      	ldur	q23, [x10, #0xf8]
    fb54:      	ldr	x8, [x10, #0x108]
    fb58:      	ldp	q24, q25, [x4]
    fb5c:      	ldp	q26, q27, [x4, #0x20]
    fb60:      	ldp	q28, q29, [x4, #0x40]
    fb64:      	ldp	q30, q31, [x4, #0x60]
    fb68:      	ldp	q8, q9, [x4, #0x80]
    fb6c:      	ldp	q10, q11, [x4, #0xa0]
    fb70:      	ldp	q12, q13, [x4, #0xc0]
    fb74:      	ldp	q14, q15, [x4, #0xe0]
    fb78:      	mov	w11, #0x2               ; =2
    fb7c:      	str	w11, [x10]
    fb80:      	str	x3, [x10, #0x8]
    fb84:      	stp	q24, q25, [x10, #0x10]
    fb88:      	stp	q26, q27, [x10, #0x30]
    fb8c:      	stp	q28, q29, [x10, #0x50]
    fb90:      	stp	q30, q31, [x10, #0x70]
    fb94:      	stp	q8, q9, [x10, #0x90]
    fb98:      	stp	q10, q11, [x10, #0xb0]
    fb9c:      	stp	q12, q13, [x10, #0xd0]
    fba0:      	stp	q14, q15, [x10, #0xf0]
    fba4:      	cbz	w9, 0xfbb0 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449+0xbc>
    fba8:      	cmp	w9, #0x1
    fbac:      	b.ne	0xfbec <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449+0xf8>
    fbb0:      	movi.2d	v0, #0000000000000000
    fbb4:      	stp	q0, q0, [x0, #0xf0]
    fbb8:      	stp	q0, q0, [x0, #0xd0]
    fbbc:      	stp	q0, q0, [x0, #0xb0]
    fbc0:      	stp	q0, q0, [x0, #0x90]
    fbc4:      	stp	q0, q0, [x0, #0x70]
    fbc8:      	stp	q0, q0, [x0, #0x50]
    fbcc:      	stp	q0, q0, [x0, #0x30]
    fbd0:      	stp	q0, q0, [x0, #0x10]
    fbd4:      	str	q0, [x0]
    fbd8:      	ldp	d9, d8, [sp, #0x30]
    fbdc:      	ldp	d11, d10, [sp, #0x20]
    fbe0:      	ldp	d13, d12, [sp, #0x10]
    fbe4:      	ldp	d15, d14, [sp], #0x40
    fbe8:      	ret
    fbec:      	str	xzr, [x0]
    fbf0:      	mov	w9, #0x1                ; =1
    fbf4:      	str	w9, [x0]
    fbf8:      	stur	q0, [x0, #0x8]
    fbfc:      	stur	q1, [x0, #0x18]
    fc00:      	stur	q2, [x0, #0x28]
    fc04:      	stur	q3, [x0, #0x38]
    fc08:      	stur	q4, [x0, #0x48]
    fc0c:      	stur	q5, [x0, #0x58]
    fc10:      	stur	q6, [x0, #0x68]
    fc14:      	stur	q7, [x0, #0x78]
    fc18:      	stur	q16, [x0, #0x88]
    fc1c:      	stur	q17, [x0, #0x98]
    fc20:      	stur	q18, [x0, #0xa8]
    fc24:      	stur	q19, [x0, #0xb8]
    fc28:      	stur	q20, [x0, #0xc8]
    fc2c:      	stur	q21, [x0, #0xd8]
    fc30:      	stur	q22, [x0, #0xe8]
    fc34:      	stur	q23, [x0, #0xf8]
    fc38:      	str	x8, [x0, #0x108]
    fc3c:      	ldp	d9, d8, [sp, #0x30]
    fc40:      	ldp	d11, d10, [sp, #0x20]
    fc44:      	ldp	d13, d12, [sp, #0x10]
    fc48:      	ldp	d15, d14, [sp], #0x40
    fc4c:      	ret

000000000000fc50 <_wf_std.collections.hash_map.hash_map_is_deleted$instance$d7a1a90c27bba449>:
    fc50:      	ldr	w8, [x0]
    fc54:      	cmp	w8, #0x1
    fc58:      	cset	w0, eq
    fc5c:      	ret

000000000000fc60 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d>:
    fc60:      	ldrb	w8, [x2, #0x8]
    fc64:      	tbz	w8, #0x0, 0xfc78 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0x18>
    fc68:      	mov	x8, #0x0                ; =0
    fc6c:      	ldr	x9, [x0]
    fc70:      	cbnz	x9, 0xfcc0 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0x60>
    fc74:      	b	0xfd24 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0xc4>
    fc78:      	ldr	x8, [x2]
    fc7c:      	ldr	x9, [x1]
    fc80:      	eor	x8, x9, x8
    fc84:      	eor	x8, x8, x8, lsr #30
    fc88:      	mov	x9, #0xe5b9             ; =58809
    fc8c:      	movk	x9, #0x1ce4, lsl #16
    fc90:      	movk	x9, #0x476d, lsl #32
    fc94:      	movk	x9, #0xbf58, lsl #48
    fc98:      	mul	x8, x8, x9
    fc9c:      	eor	x8, x8, x8, lsr #27
    fca0:      	mov	x9, #0x11eb             ; =4587
    fca4:      	movk	x9, #0x1331, lsl #16
    fca8:      	movk	x9, #0x49bb, lsl #32
    fcac:      	movk	x9, #0x94d0, lsl #48
    fcb0:      	mul	x8, x8, x9
    fcb4:      	eor	x8, x8, x8, lsr #31
    fcb8:      	ldr	x9, [x0]
    fcbc:      	cbz	x9, 0xfd24 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0xc4>
    fcc0:      	udiv	x10, x8, x9
    fcc4:      	msub	x8, x10, x9, x8
    fcc8:      	ldr	x10, [x0, #0x10]
    fccc:      	mov	w11, #0x110             ; =272
    fcd0:      	mov	x12, x9
    fcd4:      	b	0xfcec <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0x8c>
    fcd8:      	add	x13, x8, #0x1
    fcdc:      	cmp	x13, x9
    fce0:      	csinc	x8, xzr, x8, hs
    fce4:      	subs	x12, x12, #0x1
    fce8:      	b.eq	0xfd24 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0xc4>
    fcec:      	madd	x14, x8, x11, x10
    fcf0:      	ldr	w13, [x14]
    fcf4:      	cmp	w13, #0x1
    fcf8:      	b.eq	0xfcd8 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0x78>
    fcfc:      	cmp	w13, #0x2
    fd00:      	b.ne	0xfd38 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0xd8>
    fd04:      	ldr	x13, [x14, #0x8]
    fd08:      	ldr	x14, [x1]
    fd0c:      	cmp	x13, x14
    fd10:      	b.ne	0xfcd8 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0x78>
    fd14:      	mov	w0, #0x0                ; =0
    fd18:      	mov	x1, x8
    fd1c:      	mov	w2, #0x0                ; =0
    fd20:      	ret
    fd24:      	mov	x8, #0x0                ; =0
    fd28:      	mov	w0, #0x1                ; =1
    fd2c:      	mov	x1, x8
    fd30:      	mov	w2, #0x0                ; =0
    fd34:      	ret
    fd38:      	mov	w0, #0x1                ; =1
    fd3c:      	mov	x8, x13
    fd40:      	mov	x1, x8
    fd44:      	mov	w2, #0x0                ; =0
    fd48:      	ret

000000000000fd4c <_wf_full_chain_heads$instance$1dd16a80e802bd86>:
    fd4c:      	stp	x22, x21, [sp, #-0x30]!
    fd50:      	stp	x20, x19, [sp, #0x10]
    fd54:      	stp	x29, x30, [sp, #0x20]
    fd58:      	mov	x19, x0
    fd5c:      	cbz	x0, 0xfd84 <_wf_full_chain_heads$instance$1dd16a80e802bd86+0x38>
    fd60:      	lsl	x21, x19, #3
    fd64:      	mov	x0, x21
    fd68:      	bl	0xfd68 <_wf_full_chain_heads$instance$1dd16a80e802bd86+0x1c>
		000000000000fd68:  ARM64_RELOC_BRANCH26	_malloc
    fd6c:      	cbz	x0, 0xfda8 <_wf_full_chain_heads$instance$1dd16a80e802bd86+0x5c>
    fd70:      	mov	x20, x0
    fd74:      	mov	w1, #0xff               ; =255
    fd78:      	mov	x2, x21
    fd7c:      	bl	0xfd7c <_wf_full_chain_heads$instance$1dd16a80e802bd86+0x30>
		000000000000fd7c:  ARM64_RELOC_BRANCH26	_memset
    fd80:      	b	0xfd8c <_wf_full_chain_heads$instance$1dd16a80e802bd86+0x40>
    fd84:      	adrp	x20, 0xf000 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x168>
		000000000000fd84:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    fd88:      	add	x20, x20, #0x0
		000000000000fd88:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    fd8c:      	mov	x0, x19
    fd90:      	mov	x1, x19
    fd94:      	mov	x2, x20
    fd98:      	ldp	x29, x30, [sp, #0x20]
    fd9c:      	ldp	x20, x19, [sp, #0x10]
    fda0:      	ldp	x22, x21, [sp], #0x30
    fda4:      	ret
    fda8:      	bl	0xfda8 <_wf_full_chain_heads$instance$1dd16a80e802bd86+0x5c>
		000000000000fda8:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000fdac <_wf_box_slots_new$instance$6587598b151ba54d>:
    fdac:      	stp	x20, x19, [sp, #-0x20]!
    fdb0:      	stp	x29, x30, [sp, #0x10]
    fdb4:      	mov	x19, x0
    fdb8:      	cbz	x0, 0xfde4 <_wf_box_slots_new$instance$6587598b151ba54d+0x38>
    fdbc:      	add	x8, x19, x19, lsl #1
    fdc0:      	lsl	x0, x8, #3
    fdc4:      	bl	0xfdc4 <_wf_box_slots_new$instance$6587598b151ba54d+0x18>
		000000000000fdc4:  ARM64_RELOC_BRANCH26	_malloc
    fdc8:      	mov	x2, x0
    fdcc:      	cbz	x0, 0xfe00 <_wf_box_slots_new$instance$6587598b151ba54d+0x54>
    fdd0:      	mov	x0, #0x0                ; =0
    fdd4:      	mov	x1, x19
    fdd8:      	ldp	x29, x30, [sp, #0x10]
    fddc:      	ldp	x20, x19, [sp], #0x20
    fde0:      	ret
    fde4:      	adrp	x2, 0xf000 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x168>
		000000000000fde4:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    fde8:      	add	x2, x2, #0x0
		000000000000fde8:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    fdec:      	mov	x0, #0x0                ; =0
    fdf0:      	mov	x1, x19
    fdf4:      	ldp	x29, x30, [sp, #0x10]
    fdf8:      	ldp	x20, x19, [sp], #0x20
    fdfc:      	ret
    fe00:      	bl	0xfe00 <_wf_box_slots_new$instance$6587598b151ba54d+0x54>
		000000000000fe00:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000fe04 <_wf_full_chain_find$instance$29255544f66aec6e>:
    fe04:      	ldrb	w8, [x2, #0x8]
    fe08:      	tbz	w8, #0x0, 0xfe1c <_wf_full_chain_find$instance$29255544f66aec6e+0x18>
    fe0c:      	mov	x8, #0x0                ; =0
    fe10:      	ldr	x10, [x0]
    fe14:      	cbnz	x10, 0xfe64 <_wf_full_chain_find$instance$29255544f66aec6e+0x60>
    fe18:      	b	0xfeb4 <_wf_full_chain_find$instance$29255544f66aec6e+0xb0>
    fe1c:      	ldr	x8, [x2]
    fe20:      	ldr	x9, [x1]
    fe24:      	eor	x8, x9, x8
    fe28:      	eor	x8, x8, x8, lsr #30
    fe2c:      	mov	x9, #0xe5b9             ; =58809
    fe30:      	movk	x9, #0x1ce4, lsl #16
    fe34:      	movk	x9, #0x476d, lsl #32
    fe38:      	movk	x9, #0xbf58, lsl #48
    fe3c:      	mul	x8, x8, x9
    fe40:      	eor	x8, x8, x8, lsr #27
    fe44:      	mov	x9, #0x11eb             ; =4587
    fe48:      	movk	x9, #0x1331, lsl #16
    fe4c:      	movk	x9, #0x49bb, lsl #32
    fe50:      	movk	x9, #0x94d0, lsl #48
    fe54:      	mul	x8, x8, x9
    fe58:      	eor	x8, x8, x8, lsr #31
    fe5c:      	ldr	x10, [x0]
    fe60:      	cbz	x10, 0xfeb4 <_wf_full_chain_find$instance$29255544f66aec6e+0xb0>
    fe64:      	ldr	x9, [x0, #0x18]
    fe68:      	cbz	x9, 0xfeb4 <_wf_full_chain_find$instance$29255544f66aec6e+0xb0>
    fe6c:      	udiv	x11, x8, x10
    fe70:      	msub	x8, x11, x10, x8
    fe74:      	ldr	x10, [x0, #0x10]
    fe78:      	add	x8, x10, x8, lsl #3
    fe7c:      	mov	w10, #0x18              ; =24
    fe80:      	mov	x11, x9
    fe84:      	ldr	x8, [x8]
    fe88:      	cmp	x8, x9
    fe8c:      	b.hs	0xfeb4 <_wf_full_chain_find$instance$29255544f66aec6e+0xb0>
    fe90:      	ldr	x12, [x0, #0x28]
    fe94:      	madd	x12, x8, x10, x12
    fe98:      	ldr	x13, [x12]
    fe9c:      	ldr	x14, [x1]
    fea0:      	cmp	x13, x14
    fea4:      	b.eq	0xfec8 <_wf_full_chain_find$instance$29255544f66aec6e+0xc4>
    fea8:      	add	x8, x12, #0x10
    feac:      	subs	x11, x11, #0x1
    feb0:      	b.ne	0xfe84 <_wf_full_chain_find$instance$29255544f66aec6e+0x80>
    feb4:      	mov	x8, #0x0                ; =0
    feb8:      	mov	w0, #0x1                ; =1
    febc:      	mov	x1, x8
    fec0:      	mov	w2, #0x0                ; =0
    fec4:      	ret
    fec8:      	mov	w0, #0x0                ; =0
    fecc:      	mov	x1, x8
    fed0:      	mov	w2, #0x0                ; =0
    fed4:      	ret

000000000000fed8 <_wf_box_slots_new$instance$c630f48ffb9953bf>:
    fed8:      	stp	x20, x19, [sp, #-0x20]!
    fedc:      	stp	x29, x30, [sp, #0x10]
    fee0:      	mov	x19, x0
    fee4:      	cbz	x0, 0xff10 <_wf_box_slots_new$instance$c630f48ffb9953bf+0x38>
    fee8:      	add	x8, x19, x19, lsl #4
    feec:      	lsl	x0, x8, #4
    fef0:      	bl	0xfef0 <_wf_box_slots_new$instance$c630f48ffb9953bf+0x18>
		000000000000fef0:  ARM64_RELOC_BRANCH26	_malloc
    fef4:      	mov	x2, x0
    fef8:      	cbz	x0, 0xff2c <_wf_box_slots_new$instance$c630f48ffb9953bf+0x54>
    fefc:      	mov	x0, #0x0                ; =0
    ff00:      	mov	x1, x19
    ff04:      	ldp	x29, x30, [sp, #0x10]
    ff08:      	ldp	x20, x19, [sp], #0x20
    ff0c:      	ret
    ff10:      	adrp	x2, 0xf000 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x168>
		000000000000ff10:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    ff14:      	add	x2, x2, #0x0
		000000000000ff14:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    ff18:      	mov	x0, #0x0                ; =0
    ff1c:      	mov	x1, x19
    ff20:      	ldp	x29, x30, [sp, #0x10]
    ff24:      	ldp	x20, x19, [sp], #0x20
    ff28:      	ret
    ff2c:      	bl	0xff2c <_wf_box_slots_new$instance$c630f48ffb9953bf+0x54>
		000000000000ff2c:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000ff30 <_wf_full_chain_find$instance$58dd6ca826103b6d>:
    ff30:      	ldrb	w8, [x2, #0x8]
    ff34:      	tbz	w8, #0x0, 0xff48 <_wf_full_chain_find$instance$58dd6ca826103b6d+0x18>
    ff38:      	mov	x8, #0x0                ; =0
    ff3c:      	ldr	x10, [x0]
    ff40:      	cbnz	x10, 0xff90 <_wf_full_chain_find$instance$58dd6ca826103b6d+0x60>
    ff44:      	b	0xffe0 <_wf_full_chain_find$instance$58dd6ca826103b6d+0xb0>
    ff48:      	ldr	x8, [x2]
    ff4c:      	ldr	x9, [x1]
    ff50:      	eor	x8, x9, x8
    ff54:      	eor	x8, x8, x8, lsr #30
    ff58:      	mov	x9, #0xe5b9             ; =58809
    ff5c:      	movk	x9, #0x1ce4, lsl #16
    ff60:      	movk	x9, #0x476d, lsl #32
    ff64:      	movk	x9, #0xbf58, lsl #48
    ff68:      	mul	x8, x8, x9
    ff6c:      	eor	x8, x8, x8, lsr #27
    ff70:      	mov	x9, #0x11eb             ; =4587
    ff74:      	movk	x9, #0x1331, lsl #16
    ff78:      	movk	x9, #0x49bb, lsl #32
    ff7c:      	movk	x9, #0x94d0, lsl #48
    ff80:      	mul	x8, x8, x9
    ff84:      	eor	x8, x8, x8, lsr #31
    ff88:      	ldr	x10, [x0]
    ff8c:      	cbz	x10, 0xffe0 <_wf_full_chain_find$instance$58dd6ca826103b6d+0xb0>
    ff90:      	ldr	x9, [x0, #0x18]
    ff94:      	cbz	x9, 0xffe0 <_wf_full_chain_find$instance$58dd6ca826103b6d+0xb0>
    ff98:      	udiv	x11, x8, x10
    ff9c:      	msub	x8, x11, x10, x8
    ffa0:      	ldr	x10, [x0, #0x10]
    ffa4:      	add	x8, x10, x8, lsl #3
    ffa8:      	mov	w10, #0x110             ; =272
    ffac:      	mov	x11, x9
    ffb0:      	ldr	x8, [x8]
    ffb4:      	cmp	x8, x9
    ffb8:      	b.hs	0xffe0 <_wf_full_chain_find$instance$58dd6ca826103b6d+0xb0>
    ffbc:      	ldr	x12, [x0, #0x28]
    ffc0:      	madd	x12, x8, x10, x12
    ffc4:      	ldr	x13, [x12]
    ffc8:      	ldr	x14, [x1]
    ffcc:      	cmp	x13, x14
    ffd0:      	b.eq	0xfff4 <_wf_full_chain_find$instance$58dd6ca826103b6d+0xc4>
    ffd4:      	add	x8, x12, #0x108
    ffd8:      	subs	x11, x11, #0x1
    ffdc:      	b.ne	0xffb0 <_wf_full_chain_find$instance$58dd6ca826103b6d+0x80>
    ffe0:      	mov	x8, #0x0                ; =0
    ffe4:      	mov	w0, #0x1                ; =1
    ffe8:      	mov	x1, x8
    ffec:      	mov	w2, #0x0                ; =0
    fff0:      	ret
    fff4:      	mov	w0, #0x0                ; =0
    fff8:      	mov	x1, x8
    fffc:      	mov	w2, #0x0                ; =0
   10000:      	ret

0000000000010004 <_wf_slots_new$instance$15df03c28018958d>:
   10004:      	mov	x0, #0x0                ; =0
   10008:      	mov	x1, #0x0                ; =0
   1000c:      	mov	x2, #0x0                ; =0
   10010:      	ret

0000000000010014 <_wf_std.collections.hash_map.hash_map_is_available$instance$0ed342445dd803f3>:
   10014:      	ldr	w8, [x0]
   10018:      	cmp	w8, #0x2
   1001c:      	cset	w0, lo
   10020:      	ret

0000000000010024 <_wf_slots_new$instance$8ac6e57475a1cbbb>:
   10024:      	movi.2d	v0, #0000000000000000
   10028:      	stp	q0, q0, [x0, #0xf0]
   1002c:      	stp	q0, q0, [x0, #0xd0]
   10030:      	stp	q0, q0, [x0, #0xb0]
   10034:      	stp	q0, q0, [x0, #0x90]
   10038:      	stp	q0, q0, [x0, #0x70]
   1003c:      	stp	q0, q0, [x0, #0x50]
   10040:      	stp	q0, q0, [x0, #0x30]
   10044:      	stp	q0, q0, [x0, #0x10]
   10048:      	str	q0, [x0]
   1004c:      	ret

0000000000010050 <_wf_std.collections.hash_map.hash_map_is_available$instance$d7a1a90c27bba449>:
   10050:      	ldr	w8, [x0]
   10054:      	cmp	w8, #0x2
   10058:      	cset	w0, lo
   1005c:      	ret

0000000000010060 <_wf_place_back$instance$b128cca62ef74569>:
   10060:      	ldr	x8, [x0]
   10064:      	ldr	x9, [x0, #0x10]
   10068:      	str	x1, [x9, x8, lsl #3]
   1006c:      	add	x8, x8, #0x1
   10070:      	str	x8, [x0]
   10074:      	mov	w0, #0x0                ; =0
   10078:      	ret

000000000001007c <_wf_take_back$instance$af662f3d444ff600>:
   1007c:      	ldr	x8, [x0]
   10080:      	sub	x8, x8, #0x1
   10084:      	ldr	x9, [x0, #0x10]
   10088:      	mov	w10, #0x18              ; =24
   1008c:      	madd	x9, x8, x10, x9
   10090:      	str	x8, [x0]
   10094:      	ldp	x0, x1, [x9]
   10098:      	ldr	x2, [x9, #0x10]
   1009c:      	ret

00000000000100a0 <_wf_free_empty$instance$6dd04c483b97c747>:
   100a0:      	ldr	x8, [x0, #0x8]
   100a4:      	cbz	x8, 0x100b8 <_wf_free_empty$instance$6dd04c483b97c747+0x18>
   100a8:      	stp	x29, x30, [sp, #-0x10]!
   100ac:      	ldr	x0, [x0, #0x10]
   100b0:      	bl	0x100b0 <_wf_free_empty$instance$6dd04c483b97c747+0x10>
		00000000000100b0:  ARM64_RELOC_BRANCH26	_free
   100b4:      	ldp	x29, x30, [sp], #0x10
   100b8:      	mov	w0, #0x0                ; =0
   100bc:      	ret

00000000000100c0 <_wf_take_back$instance$b37b665fdb22758d>:
   100c0:      	ldr	x8, [x1]
   100c4:      	sub	x9, x8, #0x1
   100c8:      	ldr	x8, [x1, #0x10]
   100cc:      	mov	w10, #0x110             ; =272
   100d0:      	madd	x8, x9, x10, x8
   100d4:      	str	x9, [x1]
   100d8:      	mov	x1, x8
   100dc:      	mov	w2, #0x110              ; =272
   100e0:      	b	0x100e0 <_wf_take_back$instance$b37b665fdb22758d+0x20>
		00000000000100e0:  ARM64_RELOC_BRANCH26	_memmove

00000000000100e4 <_wf_free_empty$instance$85bf88ba50f5d3e1>:
   100e4:      	ldr	x8, [x0, #0x8]
   100e8:      	cbz	x8, 0x100fc <_wf_free_empty$instance$85bf88ba50f5d3e1+0x18>
   100ec:      	stp	x29, x30, [sp, #-0x10]!
   100f0:      	ldr	x0, [x0, #0x10]
   100f4:      	bl	0x100f4 <_wf_free_empty$instance$85bf88ba50f5d3e1+0x10>
		00000000000100f4:  ARM64_RELOC_BRANCH26	_free
   100f8:      	ldp	x29, x30, [sp], #0x10
   100fc:      	mov	w0, #0x0                ; =0
   10100:      	ret

0000000000010104 <_wf_take_back$instance$9985a87b1cb96650>:
   10104:      	ldr	x8, [x0]
   10108:      	sub	x8, x8, #0x1
   1010c:      	ldr	x9, [x0, #0x10]
   10110:      	mov	w10, #0x18              ; =24
   10114:      	madd	x9, x8, x10, x9
   10118:      	str	x8, [x0]
   1011c:      	ldr	w0, [x9]
   10120:      	ldp	x1, x2, [x9, #0x8]
   10124:      	ret

0000000000010128 <_wf_free_empty$instance$43608765810d87c7>:
   10128:      	ldr	x8, [x0, #0x8]
   1012c:      	cbz	x8, 0x10140 <_wf_free_empty$instance$43608765810d87c7+0x18>
   10130:      	stp	x29, x30, [sp, #-0x10]!
   10134:      	ldr	x0, [x0, #0x10]
   10138:      	bl	0x10138 <_wf_free_empty$instance$43608765810d87c7+0x10>
		0000000000010138:  ARM64_RELOC_BRANCH26	_free
   1013c:      	ldp	x29, x30, [sp], #0x10
   10140:      	mov	w0, #0x0                ; =0
   10144:      	ret

0000000000010148 <_wf_swap$instance$b45b69d9d0c6bbd0>:
   10148:      	ldr	q0, [x0]
   1014c:      	str	q0, [sp, #-0x20]!
   10150:      	ldr	x8, [x0, #0x10]
   10154:      	str	x8, [sp, #0x10]
   10158:      	ldr	x9, [x1, #0x10]
   1015c:      	ldr	q1, [x1]
   10160:      	str	q1, [x0]
   10164:      	str	x9, [x0, #0x10]
   10168:      	str	q0, [x1]
   1016c:      	str	x8, [x1, #0x10]
   10170:      	mov	w0, #0x0                ; =0
   10174:      	add	sp, sp, #0x20
   10178:      	ret

000000000001017c <_wf_take_back$instance$d5bb00f00cd669fb>:
   1017c:      	ldr	x8, [x1]
   10180:      	sub	x9, x8, #0x1
   10184:      	ldr	x8, [x1, #0x10]
   10188:      	mov	w10, #0x110             ; =272
   1018c:      	madd	x8, x9, x10, x8
   10190:      	str	x9, [x1]
   10194:      	mov	x1, x8
   10198:      	mov	w2, #0x110              ; =272
   1019c:      	b	0x1019c <_wf_take_back$instance$d5bb00f00cd669fb+0x20>
		000000000001019c:  ARM64_RELOC_BRANCH26	_memmove

00000000000101a0 <_wf_free_empty$instance$d692d011b23a4a18>:
   101a0:      	ldr	x8, [x0, #0x8]
   101a4:      	cbz	x8, 0x101b8 <_wf_free_empty$instance$d692d011b23a4a18+0x18>
   101a8:      	stp	x29, x30, [sp, #-0x10]!
   101ac:      	ldr	x0, [x0, #0x10]
   101b0:      	bl	0x101b0 <_wf_free_empty$instance$d692d011b23a4a18+0x10>
		00000000000101b0:  ARM64_RELOC_BRANCH26	_free
   101b4:      	ldp	x29, x30, [sp], #0x10
   101b8:      	mov	w0, #0x0                ; =0
   101bc:      	ret

00000000000101c0 <_wf_swap$instance$9eabc50a9cce2251>:
   101c0:      	sub	sp, sp, #0x140
   101c4:      	stp	x28, x27, [sp, #0x110]
   101c8:      	stp	x20, x19, [sp, #0x120]
   101cc:      	stp	x29, x30, [sp, #0x130]
   101d0:      	mov	x19, x1
   101d4:      	mov	x20, x0
   101d8:      	mov	x0, sp
   101dc:      	mov	x1, x20
   101e0:      	mov	w2, #0x110              ; =272
   101e4:      	bl	0x101e4 <_wf_swap$instance$9eabc50a9cce2251+0x24>
		00000000000101e4:  ARM64_RELOC_BRANCH26	_memcpy
   101e8:      	mov	x0, x20
   101ec:      	mov	x1, x19
   101f0:      	mov	w2, #0x110              ; =272
   101f4:      	bl	0x101f4 <_wf_swap$instance$9eabc50a9cce2251+0x34>
		00000000000101f4:  ARM64_RELOC_BRANCH26	_memmove
   101f8:      	mov	x1, sp
   101fc:      	mov	x0, x19
   10200:      	mov	w2, #0x110              ; =272
   10204:      	bl	0x10204 <_wf_swap$instance$9eabc50a9cce2251+0x44>
		0000000000010204:  ARM64_RELOC_BRANCH26	_memcpy
   10208:      	mov	w0, #0x0                ; =0
   1020c:      	ldp	x29, x30, [sp, #0x130]
   10210:      	ldp	x20, x19, [sp, #0x120]
   10214:      	ldp	x28, x27, [sp, #0x110]
   10218:      	add	sp, sp, #0x140
   1021c:      	ret

0000000000010220 <_wf_place_back$instance$af662f3d444ff600>:
   10220:      	ldr	x8, [x0]
   10224:      	ldr	x9, [x0, #0x10]
   10228:      	mov	w10, #0x18              ; =24
   1022c:      	madd	x9, x8, x10, x9
   10230:      	ldr	x10, [x1, #0x10]
   10234:      	ldr	q0, [x1]
   10238:      	str	q0, [x9]
   1023c:      	str	x10, [x9, #0x10]
   10240:      	add	x8, x8, #0x1
   10244:      	str	x8, [x0]
   10248:      	mov	w0, #0x0                ; =0
   1024c:      	ret

0000000000010250 <_wf_place_back$instance$b37b665fdb22758d>:
   10250:      	stp	x20, x19, [sp, #-0x20]!
   10254:      	stp	x29, x30, [sp, #0x10]
   10258:      	mov	x19, x0
   1025c:      	ldr	x20, [x0]
   10260:      	ldr	x8, [x0, #0x10]
   10264:      	mov	w9, #0x110              ; =272
   10268:      	madd	x0, x20, x9, x8
   1026c:      	mov	w2, #0x110              ; =272
   10270:      	bl	0x10270 <_wf_place_back$instance$b37b665fdb22758d+0x20>
		0000000000010270:  ARM64_RELOC_BRANCH26	_memmove
   10274:      	add	x8, x20, #0x1
   10278:      	str	x8, [x19]
   1027c:      	mov	w0, #0x0                ; =0
   10280:      	ldp	x29, x30, [sp, #0x10]
   10284:      	ldp	x20, x19, [sp], #0x20
   10288:      	ret

000000000001028c <_wf_swap$instance$e194368921a477a7>:
   1028c:      	ldr	x8, [x0]
   10290:      	ldr	x9, [x1]
   10294:      	str	x9, [x0]
   10298:      	str	x8, [x1]
   1029c:      	mov	w0, #0x0                ; =0
   102a0:      	ret

00000000000102a4 <_wf_place_back$instance$35b9fd6def1fa8a6>:
   102a4:      	ldr	x8, [x0]
   102a8:      	ldr	x9, [x0, #0x10]
   102ac:      	mov	w10, #0x18              ; =24
   102b0:      	madd	x9, x8, x10, x9
   102b4:      	ldr	x10, [x1, #0x10]
   102b8:      	ldr	q0, [x1]
   102bc:      	str	q0, [x9]
   102c0:      	str	x10, [x9, #0x10]
   102c4:      	add	x8, x8, #0x1
   102c8:      	str	x8, [x0]
   102cc:      	mov	w0, #0x0                ; =0
   102d0:      	ret

00000000000102d4 <_wf_take_back$instance$35b9fd6def1fa8a6>:
   102d4:      	ldr	x8, [x0]
   102d8:      	sub	x8, x8, #0x1
   102dc:      	ldr	x9, [x0, #0x10]
   102e0:      	mov	w10, #0x18              ; =24
   102e4:      	madd	x9, x8, x10, x9
   102e8:      	str	x8, [x0]
   102ec:      	ldp	x0, x1, [x9]
   102f0:      	ldr	x2, [x9, #0x10]
   102f4:      	ret

00000000000102f8 <_wf_swap$instance$6587598b151ba54d>:
   102f8:      	ldr	q0, [x0]
   102fc:      	str	q0, [sp, #-0x20]!
   10300:      	ldr	x8, [x0, #0x10]
   10304:      	str	x8, [sp, #0x10]
   10308:      	ldr	x9, [x1, #0x10]
   1030c:      	ldr	q1, [x1]
   10310:      	str	q1, [x0]
   10314:      	str	x9, [x0, #0x10]
   10318:      	str	q0, [x1]
   1031c:      	str	x8, [x1, #0x10]
   10320:      	mov	w0, #0x0                ; =0
   10324:      	add	sp, sp, #0x20
   10328:      	ret

000000000001032c <_wf_free_empty$instance$285db5ca5cf1fc4f>:
   1032c:      	ldr	x8, [x0, #0x8]
   10330:      	cbz	x8, 0x10344 <_wf_free_empty$instance$285db5ca5cf1fc4f+0x18>
   10334:      	stp	x29, x30, [sp, #-0x10]!
   10338:      	ldr	x0, [x0, #0x10]
   1033c:      	bl	0x1033c <_wf_free_empty$instance$285db5ca5cf1fc4f+0x10>
		000000000001033c:  ARM64_RELOC_BRANCH26	_free
   10340:      	ldp	x29, x30, [sp], #0x10
   10344:      	mov	w0, #0x0                ; =0
   10348:      	ret

000000000001034c <_wf_swap$instance$9fed7d4c5d7cc122>:
   1034c:      	sub	sp, sp, #0x110
   10350:      	stp	x28, x27, [sp, #0x100]
   10354:      	ldp	q0, q1, [x0, #0xc0]
   10358:      	stp	q0, q1, [sp, #0xc0]
   1035c:      	ldp	q0, q1, [x0, #0xe0]
   10360:      	stp	q0, q1, [sp, #0xe0]
   10364:      	ldp	q0, q1, [x0, #0x80]
   10368:      	stp	q0, q1, [sp, #0x80]
   1036c:      	ldp	q0, q1, [x0, #0xa0]
   10370:      	stp	q0, q1, [sp, #0xa0]
   10374:      	ldp	q0, q1, [x0, #0x40]
   10378:      	stp	q0, q1, [sp, #0x40]
   1037c:      	ldp	q0, q1, [x0, #0x60]
   10380:      	stp	q0, q1, [sp, #0x60]
   10384:      	ldp	q0, q1, [x0]
   10388:      	stp	q0, q1, [sp]
   1038c:      	ldp	q0, q1, [x0, #0x20]
   10390:      	stp	q0, q1, [sp, #0x20]
   10394:      	ldp	q0, q1, [x1]
   10398:      	ldp	q2, q3, [x1, #0x20]
   1039c:      	ldp	q4, q5, [x1, #0x40]
   103a0:      	ldp	q6, q7, [x1, #0x60]
   103a4:      	ldp	q16, q17, [x1, #0x80]
   103a8:      	ldp	q18, q19, [x1, #0xa0]
   103ac:      	ldp	q20, q21, [x1, #0xc0]
   103b0:      	ldp	q22, q23, [x1, #0xe0]
   103b4:      	stp	q22, q23, [x0, #0xe0]
   103b8:      	stp	q20, q21, [x0, #0xc0]
   103bc:      	stp	q18, q19, [x0, #0xa0]
   103c0:      	stp	q16, q17, [x0, #0x80]
   103c4:      	stp	q6, q7, [x0, #0x60]
   103c8:      	stp	q4, q5, [x0, #0x40]
   103cc:      	stp	q2, q3, [x0, #0x20]
   103d0:      	stp	q0, q1, [x0]
   103d4:      	ldp	q0, q1, [sp, #0xc0]
   103d8:      	stp	q0, q1, [x1, #0xc0]
   103dc:      	ldp	q0, q1, [sp, #0xe0]
   103e0:      	stp	q0, q1, [x1, #0xe0]
   103e4:      	ldp	q0, q1, [sp, #0x80]
   103e8:      	stp	q0, q1, [x1, #0x80]
   103ec:      	ldp	q0, q1, [sp, #0xa0]
   103f0:      	stp	q0, q1, [x1, #0xa0]
   103f4:      	ldp	q0, q1, [sp, #0x40]
   103f8:      	stp	q0, q1, [x1, #0x40]
   103fc:      	ldp	q0, q1, [sp, #0x60]
   10400:      	stp	q0, q1, [x1, #0x60]
   10404:      	ldp	q0, q1, [sp]
   10408:      	stp	q0, q1, [x1]
   1040c:      	ldp	q0, q1, [sp, #0x20]
   10410:      	stp	q0, q1, [x1, #0x20]
   10414:      	mov	w0, #0x0                ; =0
   10418:      	ldp	x28, x27, [sp, #0x100]
   1041c:      	add	sp, sp, #0x110
   10420:      	ret

0000000000010424 <_wf_place_back$instance$96bbd2925df9d964>:
   10424:      	stp	x20, x19, [sp, #-0x20]!
   10428:      	stp	x29, x30, [sp, #0x10]
   1042c:      	mov	x19, x0
   10430:      	ldr	x20, [x0]
   10434:      	ldr	x8, [x0, #0x10]
   10438:      	mov	w9, #0x110              ; =272
   1043c:      	madd	x0, x20, x9, x8
   10440:      	mov	w2, #0x110              ; =272
   10444:      	bl	0x10444 <_wf_place_back$instance$96bbd2925df9d964+0x20>
		0000000000010444:  ARM64_RELOC_BRANCH26	_memmove
   10448:      	add	x8, x20, #0x1
   1044c:      	str	x8, [x19]
   10450:      	mov	w0, #0x0                ; =0
   10454:      	ldp	x29, x30, [sp, #0x10]
   10458:      	ldp	x20, x19, [sp], #0x20
   1045c:      	ret

0000000000010460 <_wf_take_back$instance$96bbd2925df9d964>:
   10460:      	ldr	x8, [x1]
   10464:      	sub	x9, x8, #0x1
   10468:      	ldr	x8, [x1, #0x10]
   1046c:      	mov	w10, #0x110             ; =272
   10470:      	madd	x8, x9, x10, x8
   10474:      	str	x9, [x1]
   10478:      	mov	x1, x8
   1047c:      	mov	w2, #0x110              ; =272
   10480:      	b	0x10480 <_wf_take_back$instance$96bbd2925df9d964+0x20>
		0000000000010480:  ARM64_RELOC_BRANCH26	_memmove

0000000000010484 <_wf_swap$instance$c630f48ffb9953bf>:
   10484:      	sub	sp, sp, #0x140
   10488:      	stp	x28, x27, [sp, #0x110]
   1048c:      	stp	x20, x19, [sp, #0x120]
   10490:      	stp	x29, x30, [sp, #0x130]
   10494:      	mov	x19, x1
   10498:      	mov	x20, x0
   1049c:      	mov	x0, sp
   104a0:      	mov	x1, x20
   104a4:      	mov	w2, #0x110              ; =272
   104a8:      	bl	0x104a8 <_wf_swap$instance$c630f48ffb9953bf+0x24>
		00000000000104a8:  ARM64_RELOC_BRANCH26	_memcpy
   104ac:      	mov	x0, x20
   104b0:      	mov	x1, x19
   104b4:      	mov	w2, #0x110              ; =272
   104b8:      	bl	0x104b8 <_wf_swap$instance$c630f48ffb9953bf+0x34>
		00000000000104b8:  ARM64_RELOC_BRANCH26	_memmove
   104bc:      	mov	x1, sp
   104c0:      	mov	x0, x19
   104c4:      	mov	w2, #0x110              ; =272
   104c8:      	bl	0x104c8 <_wf_swap$instance$c630f48ffb9953bf+0x44>
		00000000000104c8:  ARM64_RELOC_BRANCH26	_memcpy
   104cc:      	mov	w0, #0x0                ; =0
   104d0:      	ldp	x29, x30, [sp, #0x130]
   104d4:      	ldp	x20, x19, [sp, #0x120]
   104d8:      	ldp	x28, x27, [sp, #0x110]
   104dc:      	add	sp, sp, #0x140
   104e0:      	ret

00000000000104e4 <_wf_free_empty$instance$3b253a6d70922bfd>:
   104e4:      	ldr	x8, [x0, #0x8]
   104e8:      	cbz	x8, 0x104fc <_wf_free_empty$instance$3b253a6d70922bfd+0x18>
   104ec:      	stp	x29, x30, [sp, #-0x10]!
   104f0:      	ldr	x0, [x0, #0x10]
   104f4:      	bl	0x104f4 <_wf_free_empty$instance$3b253a6d70922bfd+0x10>
		00000000000104f4:  ARM64_RELOC_BRANCH26	_free
   104f8:      	ldp	x29, x30, [sp], #0x10
   104fc:      	mov	w0, #0x0                ; =0
   10500:      	ret

0000000000010504 <_wf_grow$instance$b45b69d9d0c6bbd0>:
   10504:      	stp	x24, x23, [sp, #-0x40]!
   10508:      	stp	x22, x21, [sp, #0x10]
   1050c:      	stp	x20, x19, [sp, #0x20]
   10510:      	stp	x29, x30, [sp, #0x30]
   10514:      	mov	x19, x1
   10518:      	mov	x20, x0
   1051c:      	ldr	x21, [x0, #0x10]
   10520:      	cbz	x1, 0x10570 <_wf_grow$instance$b45b69d9d0c6bbd0+0x6c>
   10524:      	add	x8, x19, x19, lsl #1
   10528:      	lsl	x1, x8, #3
   1052c:      	ldp	x22, x23, [x20]
   10530:      	cmp	x22, x23
   10534:      	ccmp	x23, #0x0, #0x4, eq
   10538:      	b.ne	0x10578 <_wf_grow$instance$b45b69d9d0c6bbd0+0x74>
   1053c:      	mov	x0, x1
   10540:      	bl	0x10540 <_wf_grow$instance$b45b69d9d0c6bbd0+0x3c>
		0000000000010540:  ARM64_RELOC_BRANCH26	_malloc
   10544:      	cbz	x0, 0x105a0 <_wf_grow$instance$b45b69d9d0c6bbd0+0x9c>
   10548:      	cbz	x23, 0x10584 <_wf_grow$instance$b45b69d9d0c6bbd0+0x80>
   1054c:      	add	x8, x22, x22, lsl #1
   10550:      	lsl	x2, x8, #3
   10554:      	mov	x22, x0
   10558:      	mov	x1, x21
   1055c:      	bl	0x1055c <_wf_grow$instance$b45b69d9d0c6bbd0+0x58>
		000000000001055c:  ARM64_RELOC_BRANCH26	_memcpy
   10560:      	mov	x0, x21
   10564:      	bl	0x10564 <_wf_grow$instance$b45b69d9d0c6bbd0+0x60>
		0000000000010564:  ARM64_RELOC_BRANCH26	_free
   10568:      	mov	x0, x22
   1056c:      	b	0x10584 <_wf_grow$instance$b45b69d9d0c6bbd0+0x80>
   10570:      	mov	x0, x21
   10574:      	b	0x10584 <_wf_grow$instance$b45b69d9d0c6bbd0+0x80>
   10578:      	mov	x0, x21
   1057c:      	bl	0x1057c <_wf_grow$instance$b45b69d9d0c6bbd0+0x78>
		000000000001057c:  ARM64_RELOC_BRANCH26	_realloc
   10580:      	cbz	x0, 0x105a0 <_wf_grow$instance$b45b69d9d0c6bbd0+0x9c>
   10584:      	stp	x19, x0, [x20, #0x8]
   10588:      	mov	w0, #0x0                ; =0
   1058c:      	ldp	x29, x30, [sp, #0x30]
   10590:      	ldp	x20, x19, [sp, #0x20]
   10594:      	ldp	x22, x21, [sp, #0x10]
   10598:      	ldp	x24, x23, [sp], #0x40
   1059c:      	ret
   105a0:      	bl	0x105a0 <_wf_grow$instance$b45b69d9d0c6bbd0+0x9c>
		00000000000105a0:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

00000000000105a4 <_wf_place_back$instance$9985a87b1cb96650>:
   105a4:      	ldr	x8, [x0]
   105a8:      	ldr	x9, [x0, #0x10]
   105ac:      	mov	w10, #0x18              ; =24
   105b0:      	madd	x9, x8, x10, x9
   105b4:      	ldr	x10, [x1, #0x10]
   105b8:      	ldr	q0, [x1]
   105bc:      	str	q0, [x9]
   105c0:      	str	x10, [x9, #0x10]
   105c4:      	add	x8, x8, #0x1
   105c8:      	str	x8, [x0]
   105cc:      	mov	w0, #0x0                ; =0
   105d0:      	ret

00000000000105d4 <_wf_swap$instance$43608765810d87c7>:
   105d4:      	ldr	q0, [x0]
   105d8:      	str	q0, [sp, #-0x20]!
   105dc:      	ldr	x8, [x0, #0x10]
   105e0:      	str	x8, [sp, #0x10]
   105e4:      	ldr	x9, [x1, #0x10]
   105e8:      	ldr	q1, [x1]
   105ec:      	str	q1, [x0]
   105f0:      	str	x9, [x0, #0x10]
   105f4:      	str	q0, [x1]
   105f8:      	str	x8, [x1, #0x10]
   105fc:      	mov	w0, #0x0                ; =0
   10600:      	add	sp, sp, #0x20
   10604:      	ret

0000000000010608 <_wf_place_back$instance$a6542e06bf5acd99>:
   10608:      	ldr	x8, [x0]
   1060c:      	add	x9, x0, x8, lsl #4
   10610:      	ldr	q0, [x1]
   10614:      	stur	q0, [x9, #0x8]
   10618:      	add	x8, x8, #0x1
   1061c:      	str	x8, [x0]
   10620:      	mov	w0, #0x0                ; =0
   10624:      	ret

0000000000010628 <_wf_take_back$instance$a6542e06bf5acd99>:
   10628:      	ldr	x8, [x0]
   1062c:      	sub	x8, x8, #0x1
   10630:      	add	x9, x0, x8, lsl #4
   10634:      	str	x8, [x0]
   10638:      	ldp	x0, x1, [x9, #0x8]
   1063c:      	ret

0000000000010640 <_wf_free_empty$instance$bb96e2f57d31495e>:
   10640:      	mov	w0, #0x0                ; =0
   10644:      	ret

0000000000010648 <_wf_grow$instance$9eabc50a9cce2251>:
   10648:      	stp	x24, x23, [sp, #-0x40]!
   1064c:      	stp	x22, x21, [sp, #0x10]
   10650:      	stp	x20, x19, [sp, #0x20]
   10654:      	stp	x29, x30, [sp, #0x30]
   10658:      	mov	x19, x1
   1065c:      	mov	x20, x0
   10660:      	ldr	x21, [x0, #0x10]
   10664:      	cbz	x1, 0x106b4 <_wf_grow$instance$9eabc50a9cce2251+0x6c>
   10668:      	add	x8, x19, x19, lsl #4
   1066c:      	lsl	x1, x8, #4
   10670:      	ldp	x22, x23, [x20]
   10674:      	cmp	x22, x23
   10678:      	ccmp	x23, #0x0, #0x4, eq
   1067c:      	b.ne	0x106bc <_wf_grow$instance$9eabc50a9cce2251+0x74>
   10680:      	mov	x0, x1
   10684:      	bl	0x10684 <_wf_grow$instance$9eabc50a9cce2251+0x3c>
		0000000000010684:  ARM64_RELOC_BRANCH26	_malloc
   10688:      	cbz	x0, 0x106e4 <_wf_grow$instance$9eabc50a9cce2251+0x9c>
   1068c:      	cbz	x23, 0x106c8 <_wf_grow$instance$9eabc50a9cce2251+0x80>
   10690:      	add	x8, x22, x22, lsl #4
   10694:      	lsl	x2, x8, #4
   10698:      	mov	x22, x0
   1069c:      	mov	x1, x21
   106a0:      	bl	0x106a0 <_wf_grow$instance$9eabc50a9cce2251+0x58>
		00000000000106a0:  ARM64_RELOC_BRANCH26	_memcpy
   106a4:      	mov	x0, x21
   106a8:      	bl	0x106a8 <_wf_grow$instance$9eabc50a9cce2251+0x60>
		00000000000106a8:  ARM64_RELOC_BRANCH26	_free
   106ac:      	mov	x0, x22
   106b0:      	b	0x106c8 <_wf_grow$instance$9eabc50a9cce2251+0x80>
   106b4:      	mov	x0, x21
   106b8:      	b	0x106c8 <_wf_grow$instance$9eabc50a9cce2251+0x80>
   106bc:      	mov	x0, x21
   106c0:      	bl	0x106c0 <_wf_grow$instance$9eabc50a9cce2251+0x78>
		00000000000106c0:  ARM64_RELOC_BRANCH26	_realloc
   106c4:      	cbz	x0, 0x106e4 <_wf_grow$instance$9eabc50a9cce2251+0x9c>
   106c8:      	stp	x19, x0, [x20, #0x8]
   106cc:      	mov	w0, #0x0                ; =0
   106d0:      	ldp	x29, x30, [sp, #0x30]
   106d4:      	ldp	x20, x19, [sp, #0x20]
   106d8:      	ldp	x22, x21, [sp, #0x10]
   106dc:      	ldp	x24, x23, [sp], #0x40
   106e0:      	ret
   106e4:      	bl	0x106e4 <_wf_grow$instance$9eabc50a9cce2251+0x9c>
		00000000000106e4:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

00000000000106e8 <_wf_place_back$instance$d5bb00f00cd669fb>:
   106e8:      	stp	x20, x19, [sp, #-0x20]!
   106ec:      	stp	x29, x30, [sp, #0x10]
   106f0:      	mov	x19, x0
   106f4:      	ldr	x20, [x0]
   106f8:      	ldr	x8, [x0, #0x10]
   106fc:      	mov	w9, #0x110              ; =272
   10700:      	madd	x0, x20, x9, x8
   10704:      	mov	w2, #0x110              ; =272
   10708:      	bl	0x10708 <_wf_place_back$instance$d5bb00f00cd669fb+0x20>
		0000000000010708:  ARM64_RELOC_BRANCH26	_memmove
   1070c:      	add	x8, x20, #0x1
   10710:      	str	x8, [x19]
   10714:      	mov	w0, #0x0                ; =0
   10718:      	ldp	x29, x30, [sp, #0x10]
   1071c:      	ldp	x20, x19, [sp], #0x20
   10720:      	ret

0000000000010724 <_wf_swap$instance$d692d011b23a4a18>:
   10724:      	ldr	q0, [x0]
   10728:      	str	q0, [sp, #-0x20]!
   1072c:      	ldr	x8, [x0, #0x10]
   10730:      	str	x8, [sp, #0x10]
   10734:      	ldr	x9, [x1, #0x10]
   10738:      	ldr	q1, [x1]
   1073c:      	str	q1, [x0]
   10740:      	str	x9, [x0, #0x10]
   10744:      	str	q0, [x1]
   10748:      	str	x8, [x1, #0x10]
   1074c:      	mov	w0, #0x0                ; =0
   10750:      	add	sp, sp, #0x20
   10754:      	ret

0000000000010758 <_wf_place_back$instance$c189ec082e7c2a1f>:
   10758:      	stp	x20, x19, [sp, #-0x20]!
   1075c:      	stp	x29, x30, [sp, #0x10]
   10760:      	mov	x19, x0
   10764:      	ldr	x20, [x0]
   10768:      	mov	w8, #0x108              ; =264
   1076c:      	madd	x8, x20, x8, x0
   10770:      	add	x0, x8, #0x8
   10774:      	mov	w2, #0x108              ; =264
   10778:      	bl	0x10778 <_wf_place_back$instance$c189ec082e7c2a1f+0x20>
		0000000000010778:  ARM64_RELOC_BRANCH26	_memcpy
   1077c:      	add	x8, x20, #0x1
   10780:      	str	x8, [x19]
   10784:      	mov	w0, #0x0                ; =0
   10788:      	ldp	x29, x30, [sp, #0x10]
   1078c:      	ldp	x20, x19, [sp], #0x20
   10790:      	ret

0000000000010794 <_wf_take_back$instance$c189ec082e7c2a1f>:
   10794:      	ldr	x8, [x1]
   10798:      	sub	x9, x8, #0x1
   1079c:      	mov	w10, #0x108             ; =264
   107a0:      	madd	x8, x8, x10, x1
   107a4:      	sub	x8, x8, #0x100
   107a8:      	str	x9, [x1]
   107ac:      	mov	x1, x8
   107b0:      	mov	w2, #0x108              ; =264
   107b4:      	b	0x107b4 <_wf_take_back$instance$c189ec082e7c2a1f+0x20>
		00000000000107b4:  ARM64_RELOC_BRANCH26	_memcpy

00000000000107b8 <_wf_free_empty$instance$41f1fc367c8c34ad>:
   107b8:      	mov	w0, #0x0                ; =0
   107bc:      	ret

00000000000107c0 <_wf__floor_run>:
   107c0:      	b	0x107c0 <_wf__floor_run>
		00000000000107c0:  ARM64_RELOC_BRANCH26	_wf__main_body

00000000000107c4 <_wf__main_body>:
   107c4:      	sub	sp, sp, #0x30
   107c8:      	stp	x29, x30, [sp, #0x20]
   107cc:      	mov	w0, #0x3                ; =3
   107d0:      	mov	w1, #0x2                ; =2
   107d4:      	mov	w2, #0x2                ; =2
   107d8:      	mov	w3, #0x11               ; =17
   107dc:      	mov	x5, #0x0                ; =0
   107e0:      	mov	w4, #0x7                ; =7
   107e4:      	bl	0x107e4 <_wf__main_body+0x20>
		00000000000107e4:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd
   107e8:      	mov	w0, #0x3                ; =3
   107ec:      	mov	w1, #0x2                ; =2
   107f0:      	mov	w2, #0x2                ; =2
   107f4:      	mov	w3, #0x11               ; =17
   107f8:      	mov	w4, #0x3                ; =3
   107fc:      	mov	w5, #0x1                ; =1
   10800:      	bl	0x10800 <_wf__main_body+0x3c>
		0000000000010800:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_trace$instance$4250cb78d3f44027
   10804:      	mov	x0, sp
   10808:      	mov	w1, #0x0                ; =0
   1080c:      	bl	0x1080c <_wf__main_body+0x48>
		000000000001080c:  ARM64_RELOC_BRANCH26	_wf_std.process.exit_status
   10810:      	mov	x0, sp
   10814:      	bl	0x10814 <_wf__main_body+0x50>
		0000000000010814:  ARM64_RELOC_BRANCH26	_wf__ordinary_exit_code
   10818:      	and	w0, w0, #0xff
   1081c:      	ldp	x29, x30, [sp, #0x20]
   10820:      	add	sp, sp, #0x30
   10824:      	ret

0000000000010828 <_main>:
   10828:      	b	0x10828 <_main>
		0000000000010828:  ARM64_RELOC_BRANCH26	_wf__floor_run
