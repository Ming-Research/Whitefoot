
research/experiments/container-representation/map-library/.build/lookup-api/mutation-screen/entry-forward.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	x20, x19, [sp, #-0x20]!
       4:      	stp	x29, x30, [sp, #0x10]
       8:      	adrp	x19, 0x0 <ltmp0>
		0000000000000008:  ARM64_RELOC_PAGE21	l_.wf_resource.heap
       c:      	add	x19, x19, #0x0
		000000000000000c:  ARM64_RELOC_PAGEOFF12	l_.wf_resource.heap
      10:      	mov	w20, #0x14              ; =20
      14:      	mov	w0, #0x2                ; =2
      18:      	mov	x1, x19
      1c:      	mov	x2, x20
      20:      	bl	0x20 <ltmp0+0x20>
		0000000000000020:  ARM64_RELOC_BRANCH26	_write
      24:      	tbz	x0, #0x3f, 0x4c <ltmp0+0x4c>
      28:      	bl	0x28 <ltmp0+0x28>
		0000000000000028:  ARM64_RELOC_BRANCH26	___error
      2c:      	ldr	w8, [x0]
      30:      	cmp	w8, #0x4
      34:      	b.ne	0x74 <ltmp0+0x74>
      38:      	mov	w0, #0x2                ; =2
      3c:      	mov	x1, x19
      40:      	mov	x2, x20
      44:      	bl	0x44 <ltmp0+0x44>
		0000000000000044:  ARM64_RELOC_BRANCH26	_write
      48:      	tbnz	x0, #0x3f, 0x28 <ltmp0+0x28>
      4c:      	subs	x20, x20, x0
      50:      	b.eq	0x74 <ltmp0+0x74>
      54:      	cbz	x0, 0x74 <ltmp0+0x74>
      58:      	add	x19, x19, x0
      5c:      	mov	w0, #0x2                ; =2
      60:      	mov	x1, x19
      64:      	mov	x2, x20
      68:      	bl	0x68 <ltmp0+0x68>
		0000000000000068:  ARM64_RELOC_BRANCH26	_write
      6c:      	tbnz	x0, #0x3f, 0x28 <ltmp0+0x28>
      70:      	b	0x4c <ltmp0+0x4c>
      74:      	bl	0x74 <ltmp0+0x74>
		0000000000000074:  ARM64_RELOC_BRANCH26	_abort

0000000000000078 <l_wf_resource_abort>:
      78:      	stp	x29, x30, [sp, #-0x10]!
      7c:      	bl	0x7c <l_wf_resource_abort+0x4>
		000000000000007c:  ARM64_RELOC_BRANCH26	l_wf_resource_record_abort

0000000000000080 <_wf_map_cost_mix>:
      80:      	eor	x8, x0, x0, lsr #30
      84:      	mov	x9, #0xe5b9             ; =58809
      88:      	movk	x9, #0x1ce4, lsl #16
      8c:      	movk	x9, #0x476d, lsl #32
      90:      	movk	x9, #0xbf58, lsl #48
      94:      	mul	x8, x8, x9
      98:      	eor	x8, x8, x8, lsr #27
      9c:      	mov	x9, #0x11eb             ; =4587
      a0:      	movk	x9, #0x1331, lsl #16
      a4:      	movk	x9, #0x49bb, lsl #32
      a8:      	movk	x9, #0x94d0, lsl #48
      ac:      	mul	x8, x8, x9
      b0:      	eor	x0, x8, x8, lsr #31
      b4:      	ret

00000000000000b8 <_wf_map_cost_hash>:
      b8:      	ldrb	w8, [x0, #0x8]
      bc:      	tbz	w8, #0x0, 0xc8 <_wf_map_cost_hash+0x10>
      c0:      	mov	x0, #0x0                ; =0
      c4:      	ret
      c8:      	ldr	x8, [x1]
      cc:      	ldr	x9, [x0]
      d0:      	eor	x8, x9, x8
      d4:      	eor	x8, x8, x8, lsr #30
      d8:      	mov	x9, #0xe5b9             ; =58809
      dc:      	movk	x9, #0x1ce4, lsl #16
      e0:      	movk	x9, #0x476d, lsl #32
      e4:      	movk	x9, #0xbf58, lsl #48
      e8:      	mul	x8, x8, x9
      ec:      	eor	x8, x8, x8, lsr #27
      f0:      	mov	x9, #0x11eb             ; =4587
      f4:      	movk	x9, #0x1331, lsl #16
      f8:      	movk	x9, #0x49bb, lsl #32
      fc:      	movk	x9, #0x94d0, lsl #48
     100:      	mul	x8, x8, x9
     104:      	eor	x0, x8, x8, lsr #31
     108:      	ret

000000000000010c <_wf_map_cost_equal>:
     10c:      	ldr	x8, [x1]
     110:      	ldr	x9, [x2]
     114:      	cmp	x8, x9
     118:      	cset	w0, eq
     11c:      	ret

0000000000000120 <_wf_map_cost_key>:
     120:      	mov	w8, #0x1                ; =1
     124:      	orr	x0, x8, x0, lsl #1
     128:      	ret

000000000000012c <_wf_map_cost_ordered>:
     12c:      	ldr	x8, [x0]
     130:      	mov	w9, #0x83               ; =131
     134:      	madd	x8, x8, x9, x1
     138:      	str	x8, [x0]
     13c:      	mov	w0, #0x0                ; =0
     140:      	ret

0000000000000144 <_wf_map_cost_final>:
     144:      	ldp	x8, x9, [x0, #0x8]
     148:      	add	x8, x8, x1
     14c:      	eor	x10, x1, x1, lsr #30
     150:      	mov	x11, #0xe5b9            ; =58809
     154:      	movk	x11, #0x1ce4, lsl #16
     158:      	movk	x11, #0x476d, lsl #32
     15c:      	movk	x11, #0xbf58, lsl #48
     160:      	mul	x10, x10, x11
     164:      	eor	x10, x10, x10, lsr #27
     168:      	mov	x11, #0x11eb            ; =4587
     16c:      	movk	x11, #0x1331, lsl #16
     170:      	movk	x11, #0x49bb, lsl #32
     174:      	movk	x11, #0x94d0, lsl #48
     178:      	mul	x10, x10, x11
     17c:      	eor	x9, x9, x10, lsr #31
     180:      	eor	x9, x9, x10
     184:      	stp	x8, x9, [x0, #0x8]
     188:      	ldr	x8, [x0, #0x18]
     18c:      	add	x8, x8, #0x1
     190:      	str	x8, [x0, #0x18]
     194:      	mov	w0, #0x0                ; =0
     198:      	ret

000000000000019c <_wf_map_cost_finish>:
     19c:      	ldp	x8, x9, [x0]
     1a0:      	ldp	x10, x11, [x0, #0x10]
     1a4:      	eor	x8, x8, x8, lsr #30
     1a8:      	mov	x12, #0xe5b9            ; =58809
     1ac:      	movk	x12, #0x1ce4, lsl #16
     1b0:      	movk	x12, #0x476d, lsl #32
     1b4:      	movk	x12, #0xbf58, lsl #48
     1b8:      	mul	x8, x8, x12
     1bc:      	eor	x8, x8, x8, lsr #27
     1c0:      	mov	x13, #0x11eb            ; =4587
     1c4:      	movk	x13, #0x1331, lsl #16
     1c8:      	movk	x13, #0x49bb, lsl #32
     1cc:      	movk	x13, #0x94d0, lsl #48
     1d0:      	mul	x8, x8, x13
     1d4:      	eor	x9, x9, x9, lsr #30
     1d8:      	mul	x9, x9, x12
     1dc:      	eor	x9, x9, x9, lsr #27
     1e0:      	mul	x9, x9, x13
     1e4:      	eor	x12, x9, x8
     1e8:      	mov	x13, #0x7c15            ; =31765
     1ec:      	movk	x13, #0x7f4a, lsl #16
     1f0:      	movk	x13, #0x79b9, lsl #32
     1f4:      	movk	x13, #0x9e37, lsl #48
     1f8:      	mul	x11, x11, x13
     1fc:      	eor	x10, x10, x11
     200:      	eor	x10, x10, x12, lsr #31
     204:      	eor	x8, x8, x9
     208:      	eor	x0, x10, x8
     20c:      	ret

0000000000000210 <_wf_map_cost_word_make>:
     210:      	ret

0000000000000214 <_wf_map_cost_word_content>:
     214:      	mov	w8, #0x83               ; =131
     218:      	madd	x0, x0, x8, x1
     21c:      	ret

0000000000000220 <_wf_map_cost_word_observe>:
     220:      	ldr	x0, [x2]
     224:      	ret

0000000000000228 <_wf_map_cost_word_edit>:
     228:      	ldr	x8, [x2]
     22c:      	add	x0, x8, #0x1
     230:      	str	x0, [x2]
     234:      	ret

0000000000000238 <_wf_map_cost_word_consume>:
     238:      	mov	w8, #0x83               ; =131
     23c:      	madd	x8, x1, x8, x2
     240:      	ldp	x9, x10, [x0, #0x8]
     244:      	add	x9, x9, x8
     248:      	eor	x8, x8, x8, lsr #30
     24c:      	mov	x11, #0xe5b9            ; =58809
     250:      	movk	x11, #0x1ce4, lsl #16
     254:      	movk	x11, #0x476d, lsl #32
     258:      	movk	x11, #0xbf58, lsl #48
     25c:      	mul	x8, x8, x11
     260:      	eor	x8, x8, x8, lsr #27
     264:      	mov	x11, #0x11eb            ; =4587
     268:      	movk	x11, #0x1331, lsl #16
     26c:      	movk	x11, #0x49bb, lsl #32
     270:      	movk	x11, #0x94d0, lsl #48
     274:      	mul	x8, x8, x11
     278:      	eor	x10, x10, x8, lsr #31
     27c:      	eor	x8, x10, x8
     280:      	stp	x9, x8, [x0, #0x8]
     284:      	ldr	x8, [x0, #0x18]
     288:      	add	x8, x8, #0x1
     28c:      	str	x8, [x0, #0x18]
     290:      	mov	w0, #0x0                ; =0
     294:      	ret

0000000000000298 <_wf_map_cost_record_make>:
     298:      	dup.2d	v0, x1
     29c:      	adrp	x8, 0x0 <ltmp0>
		000000000000029c:  ARM64_RELOC_PAGE21	lCPI14_0
     2a0:      	ldr	q1, [x8]
		00000000000002a0:  ARM64_RELOC_PAGEOFF12	lCPI14_0
     2a4:      	adrp	x8, 0x0 <ltmp0>
		00000000000002a4:  ARM64_RELOC_PAGE21	lCPI14_1
     2a8:      	ldr	q2, [x8]
		00000000000002a8:  ARM64_RELOC_PAGEOFF12	lCPI14_1
     2ac:      	add.2d	v1, v0, v1
     2b0:      	adrp	x8, 0x0 <ltmp0>
		00000000000002b0:  ARM64_RELOC_PAGE21	lCPI14_2
     2b4:      	ldr	q3, [x8]
		00000000000002b4:  ARM64_RELOC_PAGEOFF12	lCPI14_2
     2b8:      	add.2d	v2, v0, v2
     2bc:      	adrp	x8, 0x0 <ltmp0>
		00000000000002bc:  ARM64_RELOC_PAGE21	lCPI14_3
     2c0:      	ldr	q4, [x8]
		00000000000002c0:  ARM64_RELOC_PAGEOFF12	lCPI14_3
     2c4:      	add.2d	v3, v0, v3
     2c8:      	adrp	x8, 0x0 <ltmp0>
		00000000000002c8:  ARM64_RELOC_PAGE21	lCPI14_4
     2cc:      	ldr	q5, [x8]
		00000000000002cc:  ARM64_RELOC_PAGEOFF12	lCPI14_4
     2d0:      	add.2d	v4, v0, v4
     2d4:      	adrp	x8, 0x0 <ltmp0>
		00000000000002d4:  ARM64_RELOC_PAGE21	lCPI14_5
     2d8:      	ldr	q6, [x8]
		00000000000002d8:  ARM64_RELOC_PAGEOFF12	lCPI14_5
     2dc:      	add.2d	v5, v0, v5
     2e0:      	adrp	x8, 0x0 <ltmp0>
		00000000000002e0:  ARM64_RELOC_PAGE21	lCPI14_6
     2e4:      	ldr	q7, [x8]
		00000000000002e4:  ARM64_RELOC_PAGEOFF12	lCPI14_6
     2e8:      	add.2d	v6, v0, v6
     2ec:      	adrp	x8, 0x0 <ltmp0>
		00000000000002ec:  ARM64_RELOC_PAGE21	lCPI14_7
     2f0:      	ldr	q16, [x8]
		00000000000002f0:  ARM64_RELOC_PAGEOFF12	lCPI14_7
     2f4:      	add.2d	v7, v0, v7
     2f8:      	adrp	x8, 0x0 <ltmp0>
		00000000000002f8:  ARM64_RELOC_PAGE21	lCPI14_8
     2fc:      	ldr	q17, [x8]
		00000000000002fc:  ARM64_RELOC_PAGEOFF12	lCPI14_8
     300:      	add.2d	v16, v0, v16
     304:      	adrp	x8, 0x0 <ltmp0>
		0000000000000304:  ARM64_RELOC_PAGE21	lCPI14_9
     308:      	ldr	q18, [x8]
		0000000000000308:  ARM64_RELOC_PAGEOFF12	lCPI14_9
     30c:      	add.2d	v17, v0, v17
     310:      	adrp	x8, 0x0 <ltmp0>
		0000000000000310:  ARM64_RELOC_PAGE21	lCPI14_10
     314:      	ldr	q19, [x8]
		0000000000000314:  ARM64_RELOC_PAGEOFF12	lCPI14_10
     318:      	add.2d	v18, v0, v18
     31c:      	adrp	x8, 0x0 <ltmp0>
		000000000000031c:  ARM64_RELOC_PAGE21	lCPI14_11
     320:      	ldr	q20, [x8]
		0000000000000320:  ARM64_RELOC_PAGEOFF12	lCPI14_11
     324:      	add.2d	v19, v0, v19
     328:      	adrp	x8, 0x0 <ltmp0>
		0000000000000328:  ARM64_RELOC_PAGE21	lCPI14_12
     32c:      	ldr	q21, [x8]
		000000000000032c:  ARM64_RELOC_PAGEOFF12	lCPI14_12
     330:      	add.2d	v20, v0, v20
     334:      	adrp	x8, 0x0 <ltmp0>
		0000000000000334:  ARM64_RELOC_PAGE21	lCPI14_13
     338:      	ldr	q22, [x8]
		0000000000000338:  ARM64_RELOC_PAGEOFF12	lCPI14_13
     33c:      	add.2d	v21, v0, v21
     340:      	adrp	x8, 0x0 <ltmp0>
		0000000000000340:  ARM64_RELOC_PAGE21	lCPI14_14
     344:      	ldr	q23, [x8]
		0000000000000344:  ARM64_RELOC_PAGEOFF12	lCPI14_14
     348:      	add.2d	v22, v0, v22
     34c:      	add.2d	v0, v0, v23
     350:      	str	x1, [x0]
     354:      	add	x8, x1, #0x1f
     358:      	stur	q1, [x0, #0x8]
     35c:      	stur	q2, [x0, #0x18]
     360:      	stur	q3, [x0, #0x28]
     364:      	stur	q4, [x0, #0x38]
     368:      	stur	q5, [x0, #0x48]
     36c:      	stur	q6, [x0, #0x58]
     370:      	stur	q7, [x0, #0x68]
     374:      	stur	q16, [x0, #0x78]
     378:      	stur	q17, [x0, #0x88]
     37c:      	stur	q18, [x0, #0x98]
     380:      	stur	q19, [x0, #0xa8]
     384:      	stur	q20, [x0, #0xb8]
     388:      	stur	q21, [x0, #0xc8]
     38c:      	stur	q22, [x0, #0xd8]
     390:      	stur	q0, [x0, #0xe8]
     394:      	str	x8, [x0, #0xf8]
     398:      	ret

000000000000039c <_wf_map_cost_record_content>:
     39c:      	ldp	x9, x10, [x1]
     3a0:      	mov	w8, #0x83               ; =131
     3a4:      	madd	x9, x0, x8, x9
     3a8:      	madd	x9, x9, x8, x10
     3ac:      	ldp	x10, x11, [x1, #0x10]
     3b0:      	madd	x9, x9, x8, x10
     3b4:      	madd	x9, x9, x8, x11
     3b8:      	ldp	x10, x11, [x1, #0x20]
     3bc:      	madd	x9, x9, x8, x10
     3c0:      	madd	x9, x9, x8, x11
     3c4:      	ldp	x10, x11, [x1, #0x30]
     3c8:      	madd	x9, x9, x8, x10
     3cc:      	madd	x9, x9, x8, x11
     3d0:      	ldp	x10, x11, [x1, #0x40]
     3d4:      	madd	x9, x9, x8, x10
     3d8:      	madd	x9, x9, x8, x11
     3dc:      	ldp	x10, x11, [x1, #0x50]
     3e0:      	madd	x9, x9, x8, x10
     3e4:      	madd	x9, x9, x8, x11
     3e8:      	ldp	x10, x11, [x1, #0x60]
     3ec:      	madd	x9, x9, x8, x10
     3f0:      	madd	x9, x9, x8, x11
     3f4:      	ldp	x10, x11, [x1, #0x70]
     3f8:      	madd	x9, x9, x8, x10
     3fc:      	madd	x9, x9, x8, x11
     400:      	ldp	x10, x11, [x1, #0x80]
     404:      	madd	x9, x9, x8, x10
     408:      	madd	x9, x9, x8, x11
     40c:      	ldp	x10, x11, [x1, #0x90]
     410:      	madd	x9, x9, x8, x10
     414:      	madd	x9, x9, x8, x11
     418:      	ldp	x10, x11, [x1, #0xa0]
     41c:      	madd	x9, x9, x8, x10
     420:      	madd	x9, x9, x8, x11
     424:      	ldp	x10, x11, [x1, #0xb0]
     428:      	madd	x9, x9, x8, x10
     42c:      	madd	x9, x9, x8, x11
     430:      	ldp	x10, x11, [x1, #0xc0]
     434:      	madd	x9, x9, x8, x10
     438:      	madd	x9, x9, x8, x11
     43c:      	ldp	x10, x11, [x1, #0xd0]
     440:      	madd	x9, x9, x8, x10
     444:      	madd	x9, x9, x8, x11
     448:      	ldp	x10, x11, [x1, #0xe0]
     44c:      	madd	x9, x9, x8, x10
     450:      	madd	x9, x9, x8, x11
     454:      	ldp	x10, x11, [x1, #0xf0]
     458:      	madd	x9, x9, x8, x10
     45c:      	madd	x0, x9, x8, x11
     460:      	ret

0000000000000464 <_wf_map_cost_record_observe>:
     464:      	ldr	x0, [x2]
     468:      	ret

000000000000046c <_wf_map_cost_record_edit>:
     46c:      	ldr	x8, [x2]
     470:      	add	x0, x8, #0x1
     474:      	str	x0, [x2]
     478:      	ret

000000000000047c <_wf_map_cost_record_consume>:
     47c:      	stp	x20, x19, [sp, #-0x20]!
     480:      	stp	x29, x30, [sp, #0x10]
     484:      	mov	x19, x0
     488:      	mov	x0, x1
     48c:      	mov	x1, x2
     490:      	bl	0x490 <_wf_map_cost_record_consume+0x14>
		0000000000000490:  ARM64_RELOC_BRANCH26	_wf_map_cost_record_content
     494:      	ldp	x8, x9, [x19, #0x8]
     498:      	add	x8, x8, x0
     49c:      	eor	x10, x0, x0, lsr #30
     4a0:      	mov	x11, #0xe5b9            ; =58809
     4a4:      	movk	x11, #0x1ce4, lsl #16
     4a8:      	movk	x11, #0x476d, lsl #32
     4ac:      	movk	x11, #0xbf58, lsl #48
     4b0:      	mul	x10, x10, x11
     4b4:      	eor	x10, x10, x10, lsr #27
     4b8:      	mov	x11, #0x11eb            ; =4587
     4bc:      	movk	x11, #0x1331, lsl #16
     4c0:      	movk	x11, #0x49bb, lsl #32
     4c4:      	movk	x11, #0x94d0, lsl #48
     4c8:      	mul	x10, x10, x11
     4cc:      	eor	x9, x9, x10, lsr #31
     4d0:      	eor	x9, x9, x10
     4d4:      	stp	x8, x9, [x19, #0x8]
     4d8:      	ldr	x8, [x19, #0x18]
     4dc:      	add	x8, x8, #0x1
     4e0:      	str	x8, [x19, #0x18]
     4e4:      	mov	w0, #0x0                ; =0
     4e8:      	ldp	x29, x30, [sp, #0x10]
     4ec:      	ldp	x20, x19, [sp], #0x20
     4f0:      	ret

00000000000004f4 <_wf_map_cost_lookup_result>:
     4f4:      	ldr	w8, [x0]
     4f8:      	cbz	w8, 0x514 <_wf_map_cost_lookup_result+0x20>
     4fc:      	ldr	x8, [x1]
     500:      	mov	w9, #0x83               ; =131
     504:      	mul	x8, x8, x9
     508:      	str	x8, [x1]
     50c:      	mov	w0, #0x0                ; =0
     510:      	ret
     514:      	ldr	x8, [x0, #0x8]
     518:      	ldr	x9, [x1]
     51c:      	mov	w10, #0x4309            ; =17161
     520:      	madd	x8, x9, x10, x8
     524:      	add	x8, x8, #0x83
     528:      	str	x8, [x1]
     52c:      	mov	w0, #0x0                ; =0
     530:      	ret

0000000000000534 <_wf_map_cost_rebuild_result>:
     534:      	ldr	w8, [x0]
     538:      	cmp	w8, #0x0
     53c:      	ldr	x8, [x1]
     540:      	mov	w9, #0x83               ; =131
     544:      	mul	x8, x8, x9
     548:      	cinc	x8, x8, eq
     54c:      	str	x8, [x1]
     550:      	mov	w0, #0x0                ; =0
     554:      	ret

0000000000000558 <_wf_map_cost_library_word_trace>:
     558:      	cmp	x4, #0x8
     55c:      	b.ne	0x56c <_wf_map_cost_library_word_trace+0x14>
     560:      	mov	x0, x3
     564:      	mov	x1, x5
     568:      	b	0x568 <_wf_map_cost_library_word_trace+0x10>
		0000000000000568:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd
     56c:      	b	0x56c <_wf_map_cost_library_word_trace+0x14>
		000000000000056c:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd

0000000000000570 <_wf_map_cost_library_record_trace>:
     570:      	cmp	x4, #0x8
     574:      	b.ne	0x584 <_wf_map_cost_library_record_trace+0x14>
     578:      	mov	x0, x3
     57c:      	mov	x1, x5
     580:      	b	0x580 <_wf_map_cost_library_record_trace+0x10>
		0000000000000580:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_policy$instance$4250cb78d3f44027
     584:      	b	0x584 <_wf_map_cost_library_record_trace+0x14>
		0000000000000584:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_trace$instance$4250cb78d3f44027

0000000000000588 <_wf_map_cost_library_word_geometry>:
     588:      	b	0x588 <_wf_map_cost_library_word_geometry>
		0000000000000588:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd

000000000000058c <_wf_map_cost_library_record_geometry>:
     58c:      	b	0x58c <_wf_map_cost_library_record_geometry>
		000000000000058c:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_geometry$instance$4250cb78d3f44027

0000000000000590 <_wf_map_cost_lookup_word_prepare>:
     590:      	b	0x590 <_wf_map_cost_lookup_word_prepare>
		0000000000000590:  ARM64_RELOC_BRANCH26	_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd

0000000000000594 <_wf_map_cost_lookup_record_prepare>:
     594:      	b	0x594 <_wf_map_cost_lookup_record_prepare>
		0000000000000594:  ARM64_RELOC_BRANCH26	_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027

0000000000000598 <_wf_map_cost_lookup_word_query>:
     598:      	b	0x598 <_wf_map_cost_lookup_word_query>
		0000000000000598:  ARM64_RELOC_BRANCH26	_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd

000000000000059c <_wf_map_cost_lookup_record_query>:
     59c:      	b	0x59c <_wf_map_cost_lookup_record_query>
		000000000000059c:  ARM64_RELOC_BRANCH26	_wf_map_cost_lookup_query$instance$4250cb78d3f44027

00000000000005a0 <_wf_map_cost_lookup_word_geometry>:
     5a0:      	ldr	x8, [x0]
     5a4:      	ldr	x9, [x0, #0x18]
     5a8:      	add	x0, x9, x8, lsl #32
     5ac:      	ret

00000000000005b0 <_wf_map_cost_lookup_record_geometry>:
     5b0:      	ldr	x8, [x0]
     5b4:      	ldr	x9, [x0, #0x18]
     5b8:      	add	x0, x9, x8, lsl #32
     5bc:      	ret

00000000000005c0 <_wf_map_cost_lookup_word_finish>:
     5c0:      	stp	x24, x23, [sp, #-0x40]!
     5c4:      	stp	x22, x21, [sp, #0x10]
     5c8:      	stp	x20, x19, [sp, #0x20]
     5cc:      	stp	x29, x30, [sp, #0x30]
     5d0:      	mov	x8, x0
     5d4:      	mov	x20, #0xe5b9            ; =58809
     5d8:      	movk	x20, #0x1ce4, lsl #16
     5dc:      	movk	x20, #0x476d, lsl #32
     5e0:      	movk	x20, #0xbf58, lsl #48
     5e4:      	mov	x19, #0x11eb            ; =4587
     5e8:      	movk	x19, #0x1331, lsl #16
     5ec:      	movk	x19, #0x49bb, lsl #32
     5f0:      	movk	x19, #0x94d0, lsl #48
     5f4:      	ldp	x12, x9, [x0]
     5f8:      	ldr	x0, [x0, #0x10]
     5fc:      	cbz	x12, 0x6dc <_wf_map_cost_lookup_word_finish+0x11c>
     600:      	and	x10, x12, #0x3
     604:      	cmp	x12, #0x4
     608:      	b.hs	0x6f4 <_wf_map_cost_lookup_word_finish+0x134>
     60c:      	mov	x11, #0x0               ; =0
     610:      	mov	x21, #0x0               ; =0
     614:      	mov	x22, #0x0               ; =0
     618:      	cbz	x10, 0x674 <_wf_map_cost_lookup_word_finish+0xb4>
     61c:      	mov	w13, #0x18              ; =24
     620:      	madd	x12, x12, x13, x0
     624:      	sub	x12, x12, #0x8
     628:      	mov	w13, #0x83              ; =131
     62c:      	b	0x63c <_wf_map_cost_lookup_word_finish+0x7c>
     630:      	sub	x12, x12, #0x18
     634:      	subs	x10, x10, #0x1
     638:      	b.eq	0x674 <_wf_map_cost_lookup_word_finish+0xb4>
     63c:      	ldur	w14, [x12, #-0x10]
     640:      	cmp	w14, #0x2
     644:      	b.ne	0x630 <_wf_map_cost_lookup_word_finish+0x70>
     648:      	ldp	x15, x14, [x12, #-0x8]
     64c:      	madd	x14, x15, x13, x14
     650:      	add	x22, x14, x22
     654:      	eor	x14, x14, x14, lsr #30
     658:      	mul	x14, x14, x20
     65c:      	eor	x14, x14, x14, lsr #27
     660:      	mul	x14, x14, x19
     664:      	eor	x15, x21, x14, lsr #31
     668:      	eor	x21, x15, x14
     66c:      	add	x11, x11, #0x1
     670:      	b	0x630 <_wf_map_cost_lookup_word_finish+0x70>
     674:      	mov	x10, #0x7c15            ; =31765
     678:      	movk	x10, #0x7f4a, lsl #16
     67c:      	movk	x10, #0x79b9, lsl #32
     680:      	movk	x10, #0x9e37, lsl #48
     684:      	mul	x23, x11, x10
     688:      	ldr	x24, [x8, #0x38]
     68c:      	cbz	x9, 0x694 <_wf_map_cost_lookup_word_finish+0xd4>
     690:      	bl	0x690 <_wf_map_cost_lookup_word_finish+0xd0>
		0000000000000690:  ARM64_RELOC_BRANCH26	_free
     694:      	eor	x8, x24, x24, lsr #30
     698:      	mul	x8, x8, x20
     69c:      	eor	x8, x8, x8, lsr #27
     6a0:      	mul	x8, x8, x19
     6a4:      	eor	x9, x22, x22, lsr #30
     6a8:      	mul	x9, x9, x20
     6ac:      	eor	x9, x9, x9, lsr #27
     6b0:      	mul	x9, x9, x19
     6b4:      	eor	x10, x9, x8
     6b8:      	eor	x11, x23, x21
     6bc:      	eor	x10, x11, x10, lsr #31
     6c0:      	eor	x8, x8, x9
     6c4:      	eor	x0, x10, x8
     6c8:      	ldp	x29, x30, [sp, #0x30]
     6cc:      	ldp	x20, x19, [sp, #0x20]
     6d0:      	ldp	x22, x21, [sp, #0x10]
     6d4:      	ldp	x24, x23, [sp], #0x40
     6d8:      	ret
     6dc:      	mov	x23, #0x0               ; =0
     6e0:      	mov	x21, #0x0               ; =0
     6e4:      	mov	x22, #0x0               ; =0
     6e8:      	ldr	x24, [x8, #0x38]
     6ec:      	cbnz	x9, 0x690 <_wf_map_cost_lookup_word_finish+0xd0>
     6f0:      	b	0x694 <_wf_map_cost_lookup_word_finish+0xd4>
     6f4:      	mov	x11, #0x0               ; =0
     6f8:      	mov	x21, #0x0               ; =0
     6fc:      	mov	x22, #0x0               ; =0
     700:      	and	x13, x12, #0xfffffffffffffffc
     704:      	mov	w14, #0x18              ; =24
     708:      	madd	x14, x12, x14, x0
     70c:      	sub	x14, x14, #0x30
     710:      	mov	w15, #0x83              ; =131
     714:      	b	0x728 <_wf_map_cost_lookup_word_finish+0x168>
     718:      	sub	x14, x14, #0x60
     71c:      	sub	x12, x12, #0x4
     720:      	sub	x13, x13, #0x4
     724:      	cbz	x13, 0x618 <_wf_map_cost_lookup_word_finish+0x58>
     728:      	ldr	w16, [x14, #0x18]
     72c:      	cmp	w16, #0x2
     730:      	b.eq	0x75c <_wf_map_cost_lookup_word_finish+0x19c>
     734:      	ldr	w16, [x14]
     738:      	cmp	w16, #0x2
     73c:      	b.eq	0x790 <_wf_map_cost_lookup_word_finish+0x1d0>
     740:      	ldur	w16, [x14, #-0x18]
     744:      	cmp	w16, #0x2
     748:      	b.eq	0x7c4 <_wf_map_cost_lookup_word_finish+0x204>
     74c:      	ldur	w16, [x14, #-0x30]
     750:      	cmp	w16, #0x2
     754:      	b.ne	0x718 <_wf_map_cost_lookup_word_finish+0x158>
     758:      	b	0x7f8 <_wf_map_cost_lookup_word_finish+0x238>
     75c:      	ldp	x17, x16, [x14, #0x20]
     760:      	madd	x16, x17, x15, x16
     764:      	add	x22, x16, x22
     768:      	eor	x16, x16, x16, lsr #30
     76c:      	mul	x16, x16, x20
     770:      	eor	x16, x16, x16, lsr #27
     774:      	mul	x16, x16, x19
     778:      	eor	x17, x21, x16, lsr #31
     77c:      	eor	x21, x17, x16
     780:      	add	x11, x11, #0x1
     784:      	ldr	w16, [x14]
     788:      	cmp	w16, #0x2
     78c:      	b.ne	0x740 <_wf_map_cost_lookup_word_finish+0x180>
     790:      	ldp	x17, x16, [x14, #0x8]
     794:      	madd	x16, x17, x15, x16
     798:      	add	x22, x16, x22
     79c:      	eor	x16, x16, x16, lsr #30
     7a0:      	mul	x16, x16, x20
     7a4:      	eor	x16, x16, x16, lsr #27
     7a8:      	mul	x16, x16, x19
     7ac:      	eor	x17, x21, x16, lsr #31
     7b0:      	eor	x21, x17, x16
     7b4:      	add	x11, x11, #0x1
     7b8:      	ldur	w16, [x14, #-0x18]
     7bc:      	cmp	w16, #0x2
     7c0:      	b.ne	0x74c <_wf_map_cost_lookup_word_finish+0x18c>
     7c4:      	ldp	x17, x16, [x14, #-0x10]
     7c8:      	madd	x16, x17, x15, x16
     7cc:      	add	x22, x16, x22
     7d0:      	eor	x16, x16, x16, lsr #30
     7d4:      	mul	x16, x16, x20
     7d8:      	eor	x16, x16, x16, lsr #27
     7dc:      	mul	x16, x16, x19
     7e0:      	eor	x17, x21, x16, lsr #31
     7e4:      	eor	x21, x17, x16
     7e8:      	add	x11, x11, #0x1
     7ec:      	ldur	w16, [x14, #-0x30]
     7f0:      	cmp	w16, #0x2
     7f4:      	b.ne	0x718 <_wf_map_cost_lookup_word_finish+0x158>
     7f8:      	ldp	x17, x16, [x14, #-0x28]
     7fc:      	madd	x16, x17, x15, x16
     800:      	add	x22, x16, x22
     804:      	eor	x16, x16, x16, lsr #30
     808:      	mul	x16, x16, x20
     80c:      	eor	x16, x16, x16, lsr #27
     810:      	mul	x16, x16, x19
     814:      	eor	x17, x21, x16, lsr #31
     818:      	eor	x21, x17, x16
     81c:      	add	x11, x11, #0x1
     820:      	b	0x718 <_wf_map_cost_lookup_word_finish+0x158>

0000000000000824 <_wf_map_cost_lookup_record_finish>:
     824:      	sub	sp, sp, #0x60
     828:      	stp	x29, x30, [sp, #0x50]
     82c:      	ldr	x8, [x0, #0x38]
     830:      	ldp	q0, q1, [x0]
     834:      	stp	q0, q1, [sp, #0x20]
     838:      	ldr	x9, [x0, #0x20]
     83c:      	str	x9, [sp, #0x40]
     840:      	stp	x8, xzr, [sp]
     844:      	stp	xzr, xzr, [sp, #0x10]
     848:      	add	x0, sp, #0x20
     84c:      	mov	x1, sp
     850:      	bl	0x850 <_wf_map_cost_lookup_record_finish+0x2c>
		0000000000000850:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71
     854:      	ldp	x8, x9, [sp]
     858:      	ldp	x10, x11, [sp, #0x10]
     85c:      	eor	x8, x8, x8, lsr #30
     860:      	mov	x12, #0xe5b9            ; =58809
     864:      	movk	x12, #0x1ce4, lsl #16
     868:      	movk	x12, #0x476d, lsl #32
     86c:      	movk	x12, #0xbf58, lsl #48
     870:      	mul	x8, x8, x12
     874:      	eor	x8, x8, x8, lsr #27
     878:      	mov	x13, #0x11eb            ; =4587
     87c:      	movk	x13, #0x1331, lsl #16
     880:      	movk	x13, #0x49bb, lsl #32
     884:      	movk	x13, #0x94d0, lsl #48
     888:      	mul	x8, x8, x13
     88c:      	eor	x9, x9, x9, lsr #30
     890:      	mul	x9, x9, x12
     894:      	eor	x9, x9, x9, lsr #27
     898:      	mul	x9, x9, x13
     89c:      	eor	x12, x9, x8
     8a0:      	mov	x13, #0x7c15            ; =31765
     8a4:      	movk	x13, #0x7f4a, lsl #16
     8a8:      	movk	x13, #0x79b9, lsl #32
     8ac:      	movk	x13, #0x9e37, lsl #48
     8b0:      	mul	x11, x11, x13
     8b4:      	eor	x10, x10, x11
     8b8:      	eor	x10, x10, x12, lsr #31
     8bc:      	eor	x8, x8, x9
     8c0:      	eor	x0, x10, x8
     8c4:      	ldp	x29, x30, [sp, #0x50]
     8c8:      	add	sp, sp, #0x60
     8cc:      	ret

00000000000008d0 <_wf_main>:
     8d0:      	stp	x20, x19, [sp, #-0x20]!
     8d4:      	stp	x29, x30, [sp, #0x10]
     8d8:      	mov	x19, x0
     8dc:      	mov	w0, #0x3                ; =3
     8e0:      	mov	w1, #0x2                ; =2
     8e4:      	mov	w2, #0x2                ; =2
     8e8:      	mov	w3, #0x11               ; =17
     8ec:      	mov	x5, #0x0                ; =0
     8f0:      	mov	w4, #0x7                ; =7
     8f4:      	bl	0x8f4 <_wf_main+0x24>
		00000000000008f4:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd
     8f8:      	mov	w0, #0x3                ; =3
     8fc:      	mov	w1, #0x2                ; =2
     900:      	mov	w2, #0x2                ; =2
     904:      	mov	w3, #0x11               ; =17
     908:      	mov	w4, #0x3                ; =3
     90c:      	mov	w5, #0x1                ; =1
     910:      	bl	0x910 <_wf_main+0x40>
		0000000000000910:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_trace$instance$4250cb78d3f44027
     914:      	mov	x0, x19
     918:      	mov	w1, #0x0                ; =0
     91c:      	ldp	x29, x30, [sp, #0x10]
     920:      	ldp	x20, x19, [sp], #0x20
     924:      	b	0x924 <_wf_main+0x54>
		0000000000000924:  ARM64_RELOC_BRANCH26	_wf_std.process.exit_status

0000000000000928 <_wf_chain_heads_new>:
     928:      	stp	x22, x21, [sp, #-0x30]!
     92c:      	stp	x20, x19, [sp, #0x10]
     930:      	stp	x29, x30, [sp, #0x20]
     934:      	mov	x19, x0
     938:      	cbz	x0, 0x960 <_wf_chain_heads_new+0x38>
     93c:      	lsl	x21, x19, #3
     940:      	mov	x0, x21
     944:      	bl	0x944 <_wf_chain_heads_new+0x1c>
		0000000000000944:  ARM64_RELOC_BRANCH26	_malloc
     948:      	cbz	x0, 0x984 <_wf_chain_heads_new+0x5c>
     94c:      	mov	x20, x0
     950:      	mov	w1, #0xff               ; =255
     954:      	mov	x2, x21
     958:      	bl	0x958 <_wf_chain_heads_new+0x30>
		0000000000000958:  ARM64_RELOC_BRANCH26	_memset
     95c:      	b	0x968 <_wf_chain_heads_new+0x40>
     960:      	adrp	x20, 0x0 <ltmp0>
		0000000000000960:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
     964:      	add	x20, x20, #0x0
		0000000000000964:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
     968:      	mov	x0, x19
     96c:      	mov	x1, x19
     970:      	mov	x2, x20
     974:      	ldp	x29, x30, [sp, #0x20]
     978:      	ldp	x20, x19, [sp, #0x10]
     97c:      	ldp	x22, x21, [sp], #0x30
     980:      	ret
     984:      	bl	0x984 <_wf_chain_heads_new+0x5c>
		0000000000000984:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

0000000000000988 <_wf_chain_lookup_word_prepare>:
     988:      	b	0x988 <_wf_chain_lookup_word_prepare>
		0000000000000988:  ARM64_RELOC_BRANCH26	_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd

000000000000098c <_wf_chain_lookup_word_query>:
     98c:      	b	0x98c <_wf_chain_lookup_word_query>
		000000000000098c:  ARM64_RELOC_BRANCH26	_wf_chain_lookup_query$instance$c7c8cd11e7f079bd

0000000000000990 <_wf_chain_lookup_word_finish>:
     990:      	b	0x990 <_wf_chain_lookup_word_finish>
		0000000000000990:  ARM64_RELOC_BRANCH26	_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd

0000000000000994 <_wf_chain_lookup_word_geometry>:
     994:      	ldr	x8, [x0]
     998:      	ldr	x9, [x0, #0x18]
     99c:      	add	x0, x9, x8, lsl #32
     9a0:      	ret

00000000000009a4 <_wf_chain_lookup_record_prepare>:
     9a4:      	b	0x9a4 <_wf_chain_lookup_record_prepare>
		00000000000009a4:  ARM64_RELOC_BRANCH26	_wf_chain_lookup_prepare$instance$4250cb78d3f44027

00000000000009a8 <_wf_chain_lookup_record_query>:
     9a8:      	b	0x9a8 <_wf_chain_lookup_record_query>
		00000000000009a8:  ARM64_RELOC_BRANCH26	_wf_chain_lookup_query$instance$4250cb78d3f44027

00000000000009ac <_wf_chain_lookup_record_finish>:
     9ac:      	b	0x9ac <_wf_chain_lookup_record_finish>
		00000000000009ac:  ARM64_RELOC_BRANCH26	_wf_chain_lookup_finish$instance$4250cb78d3f44027

00000000000009b0 <_wf_chain_lookup_record_geometry>:
     9b0:      	ldr	x8, [x0]
     9b4:      	ldr	x9, [x0, #0x18]
     9b8:      	add	x0, x9, x8, lsl #32
     9bc:      	ret

00000000000009c0 <_wf_flat_mutation_word_prepare>:
     9c0:      	b	0x9c0 <_wf_flat_mutation_word_prepare>
		00000000000009c0:  ARM64_RELOC_BRANCH26	_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd

00000000000009c4 <_wf_flat_mutation_word_batch>:
     9c4:      	b	0x9c4 <_wf_flat_mutation_word_batch>
		00000000000009c4:  ARM64_RELOC_BRANCH26	_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd

00000000000009c8 <_wf_flat_mutation_word_geometry>:
     9c8:      	ldr	x8, [x0]
     9cc:      	ldr	x9, [x0, #0x18]
     9d0:      	add	x0, x9, x8, lsl #32
     9d4:      	ret

00000000000009d8 <_wf_flat_mutation_word_verify>:
     9d8:      	b	0x9d8 <_wf_flat_mutation_word_verify>
		00000000000009d8:  ARM64_RELOC_BRANCH26	_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd

00000000000009dc <_wf_flat_mutation_word_finish>:
     9dc:      	stp	x24, x23, [sp, #-0x40]!
     9e0:      	stp	x22, x21, [sp, #0x10]
     9e4:      	stp	x20, x19, [sp, #0x20]
     9e8:      	stp	x29, x30, [sp, #0x30]
     9ec:      	mov	x8, x0
     9f0:      	mov	x20, #0xe5b9            ; =58809
     9f4:      	movk	x20, #0x1ce4, lsl #16
     9f8:      	movk	x20, #0x476d, lsl #32
     9fc:      	movk	x20, #0xbf58, lsl #48
     a00:      	mov	x19, #0x11eb            ; =4587
     a04:      	movk	x19, #0x1331, lsl #16
     a08:      	movk	x19, #0x49bb, lsl #32
     a0c:      	movk	x19, #0x94d0, lsl #48
     a10:      	ldp	x12, x9, [x0]
     a14:      	ldr	x0, [x0, #0x10]
     a18:      	cbz	x12, 0xaf8 <_wf_flat_mutation_word_finish+0x11c>
     a1c:      	and	x10, x12, #0x3
     a20:      	cmp	x12, #0x4
     a24:      	b.hs	0xb10 <_wf_flat_mutation_word_finish+0x134>
     a28:      	mov	x11, #0x0               ; =0
     a2c:      	mov	x21, #0x0               ; =0
     a30:      	mov	x22, #0x0               ; =0
     a34:      	cbz	x10, 0xa90 <_wf_flat_mutation_word_finish+0xb4>
     a38:      	mov	w13, #0x18              ; =24
     a3c:      	madd	x12, x12, x13, x0
     a40:      	sub	x12, x12, #0x8
     a44:      	mov	w13, #0x83              ; =131
     a48:      	b	0xa58 <_wf_flat_mutation_word_finish+0x7c>
     a4c:      	sub	x12, x12, #0x18
     a50:      	subs	x10, x10, #0x1
     a54:      	b.eq	0xa90 <_wf_flat_mutation_word_finish+0xb4>
     a58:      	ldur	w14, [x12, #-0x10]
     a5c:      	cmp	w14, #0x2
     a60:      	b.ne	0xa4c <_wf_flat_mutation_word_finish+0x70>
     a64:      	ldp	x15, x14, [x12, #-0x8]
     a68:      	madd	x14, x15, x13, x14
     a6c:      	add	x22, x14, x22
     a70:      	eor	x14, x14, x14, lsr #30
     a74:      	mul	x14, x14, x20
     a78:      	eor	x14, x14, x14, lsr #27
     a7c:      	mul	x14, x14, x19
     a80:      	eor	x15, x21, x14, lsr #31
     a84:      	eor	x21, x15, x14
     a88:      	add	x11, x11, #0x1
     a8c:      	b	0xa4c <_wf_flat_mutation_word_finish+0x70>
     a90:      	mov	x10, #0x7c15            ; =31765
     a94:      	movk	x10, #0x7f4a, lsl #16
     a98:      	movk	x10, #0x79b9, lsl #32
     a9c:      	movk	x10, #0x9e37, lsl #48
     aa0:      	mul	x23, x11, x10
     aa4:      	ldr	x24, [x8, #0x38]
     aa8:      	cbz	x9, 0xab0 <_wf_flat_mutation_word_finish+0xd4>
     aac:      	bl	0xaac <_wf_flat_mutation_word_finish+0xd0>
		0000000000000aac:  ARM64_RELOC_BRANCH26	_free
     ab0:      	eor	x8, x24, x24, lsr #30
     ab4:      	mul	x8, x8, x20
     ab8:      	eor	x8, x8, x8, lsr #27
     abc:      	mul	x8, x8, x19
     ac0:      	eor	x9, x22, x22, lsr #30
     ac4:      	mul	x9, x9, x20
     ac8:      	eor	x9, x9, x9, lsr #27
     acc:      	mul	x9, x9, x19
     ad0:      	eor	x10, x9, x8
     ad4:      	eor	x11, x23, x21
     ad8:      	eor	x10, x11, x10, lsr #31
     adc:      	eor	x8, x8, x9
     ae0:      	eor	x0, x10, x8
     ae4:      	ldp	x29, x30, [sp, #0x30]
     ae8:      	ldp	x20, x19, [sp, #0x20]
     aec:      	ldp	x22, x21, [sp, #0x10]
     af0:      	ldp	x24, x23, [sp], #0x40
     af4:      	ret
     af8:      	mov	x23, #0x0               ; =0
     afc:      	mov	x21, #0x0               ; =0
     b00:      	mov	x22, #0x0               ; =0
     b04:      	ldr	x24, [x8, #0x38]
     b08:      	cbnz	x9, 0xaac <_wf_flat_mutation_word_finish+0xd0>
     b0c:      	b	0xab0 <_wf_flat_mutation_word_finish+0xd4>
     b10:      	mov	x11, #0x0               ; =0
     b14:      	mov	x21, #0x0               ; =0
     b18:      	mov	x22, #0x0               ; =0
     b1c:      	and	x13, x12, #0xfffffffffffffffc
     b20:      	mov	w14, #0x18              ; =24
     b24:      	madd	x14, x12, x14, x0
     b28:      	sub	x14, x14, #0x30
     b2c:      	mov	w15, #0x83              ; =131
     b30:      	b	0xb44 <_wf_flat_mutation_word_finish+0x168>
     b34:      	sub	x14, x14, #0x60
     b38:      	sub	x12, x12, #0x4
     b3c:      	sub	x13, x13, #0x4
     b40:      	cbz	x13, 0xa34 <_wf_flat_mutation_word_finish+0x58>
     b44:      	ldr	w16, [x14, #0x18]
     b48:      	cmp	w16, #0x2
     b4c:      	b.eq	0xb78 <_wf_flat_mutation_word_finish+0x19c>
     b50:      	ldr	w16, [x14]
     b54:      	cmp	w16, #0x2
     b58:      	b.eq	0xbac <_wf_flat_mutation_word_finish+0x1d0>
     b5c:      	ldur	w16, [x14, #-0x18]
     b60:      	cmp	w16, #0x2
     b64:      	b.eq	0xbe0 <_wf_flat_mutation_word_finish+0x204>
     b68:      	ldur	w16, [x14, #-0x30]
     b6c:      	cmp	w16, #0x2
     b70:      	b.ne	0xb34 <_wf_flat_mutation_word_finish+0x158>
     b74:      	b	0xc14 <_wf_flat_mutation_word_finish+0x238>
     b78:      	ldp	x17, x16, [x14, #0x20]
     b7c:      	madd	x16, x17, x15, x16
     b80:      	add	x22, x16, x22
     b84:      	eor	x16, x16, x16, lsr #30
     b88:      	mul	x16, x16, x20
     b8c:      	eor	x16, x16, x16, lsr #27
     b90:      	mul	x16, x16, x19
     b94:      	eor	x17, x21, x16, lsr #31
     b98:      	eor	x21, x17, x16
     b9c:      	add	x11, x11, #0x1
     ba0:      	ldr	w16, [x14]
     ba4:      	cmp	w16, #0x2
     ba8:      	b.ne	0xb5c <_wf_flat_mutation_word_finish+0x180>
     bac:      	ldp	x17, x16, [x14, #0x8]
     bb0:      	madd	x16, x17, x15, x16
     bb4:      	add	x22, x16, x22
     bb8:      	eor	x16, x16, x16, lsr #30
     bbc:      	mul	x16, x16, x20
     bc0:      	eor	x16, x16, x16, lsr #27
     bc4:      	mul	x16, x16, x19
     bc8:      	eor	x17, x21, x16, lsr #31
     bcc:      	eor	x21, x17, x16
     bd0:      	add	x11, x11, #0x1
     bd4:      	ldur	w16, [x14, #-0x18]
     bd8:      	cmp	w16, #0x2
     bdc:      	b.ne	0xb68 <_wf_flat_mutation_word_finish+0x18c>
     be0:      	ldp	x17, x16, [x14, #-0x10]
     be4:      	madd	x16, x17, x15, x16
     be8:      	add	x22, x16, x22
     bec:      	eor	x16, x16, x16, lsr #30
     bf0:      	mul	x16, x16, x20
     bf4:      	eor	x16, x16, x16, lsr #27
     bf8:      	mul	x16, x16, x19
     bfc:      	eor	x17, x21, x16, lsr #31
     c00:      	eor	x21, x17, x16
     c04:      	add	x11, x11, #0x1
     c08:      	ldur	w16, [x14, #-0x30]
     c0c:      	cmp	w16, #0x2
     c10:      	b.ne	0xb34 <_wf_flat_mutation_word_finish+0x158>
     c14:      	ldp	x17, x16, [x14, #-0x28]
     c18:      	madd	x16, x17, x15, x16
     c1c:      	add	x22, x16, x22
     c20:      	eor	x16, x16, x16, lsr #30
     c24:      	mul	x16, x16, x20
     c28:      	eor	x16, x16, x16, lsr #27
     c2c:      	mul	x16, x16, x19
     c30:      	eor	x17, x21, x16, lsr #31
     c34:      	eor	x21, x17, x16
     c38:      	add	x11, x11, #0x1
     c3c:      	b	0xb34 <_wf_flat_mutation_word_finish+0x158>

0000000000000c40 <_wf_flat_mutation_record_prepare>:
     c40:      	b	0xc40 <_wf_flat_mutation_record_prepare>
		0000000000000c40:  ARM64_RELOC_BRANCH26	_wf_flat_mutation_prepare$instance$4250cb78d3f44027

0000000000000c44 <_wf_flat_mutation_record_batch>:
     c44:      	b	0xc44 <_wf_flat_mutation_record_batch>
		0000000000000c44:  ARM64_RELOC_BRANCH26	_wf_flat_mutation_batch$instance$4250cb78d3f44027

0000000000000c48 <_wf_flat_mutation_record_geometry>:
     c48:      	ldr	x8, [x0]
     c4c:      	ldr	x9, [x0, #0x18]
     c50:      	add	x0, x9, x8, lsl #32
     c54:      	ret

0000000000000c58 <_wf_flat_mutation_record_verify>:
     c58:      	b	0xc58 <_wf_flat_mutation_record_verify>
		0000000000000c58:  ARM64_RELOC_BRANCH26	_wf_flat_mutation_verify$instance$4250cb78d3f44027

0000000000000c5c <_wf_flat_mutation_record_finish>:
     c5c:      	sub	sp, sp, #0x60
     c60:      	stp	x29, x30, [sp, #0x50]
     c64:      	ldr	x8, [x0, #0x38]
     c68:      	ldp	q0, q1, [x0]
     c6c:      	stp	q0, q1, [sp, #0x20]
     c70:      	ldr	x9, [x0, #0x20]
     c74:      	str	x9, [sp, #0x40]
     c78:      	stp	x8, xzr, [sp]
     c7c:      	stp	xzr, xzr, [sp, #0x10]
     c80:      	add	x0, sp, #0x20
     c84:      	mov	x1, sp
     c88:      	bl	0xc88 <_wf_flat_mutation_record_finish+0x2c>
		0000000000000c88:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_free$instance$e1a21e22af512733
     c8c:      	ldp	x8, x9, [sp]
     c90:      	ldp	x10, x11, [sp, #0x10]
     c94:      	eor	x8, x8, x8, lsr #30
     c98:      	mov	x12, #0xe5b9            ; =58809
     c9c:      	movk	x12, #0x1ce4, lsl #16
     ca0:      	movk	x12, #0x476d, lsl #32
     ca4:      	movk	x12, #0xbf58, lsl #48
     ca8:      	mul	x8, x8, x12
     cac:      	eor	x8, x8, x8, lsr #27
     cb0:      	mov	x13, #0x11eb            ; =4587
     cb4:      	movk	x13, #0x1331, lsl #16
     cb8:      	movk	x13, #0x49bb, lsl #32
     cbc:      	movk	x13, #0x94d0, lsl #48
     cc0:      	mul	x8, x8, x13
     cc4:      	eor	x9, x9, x9, lsr #30
     cc8:      	mul	x9, x9, x12
     ccc:      	eor	x9, x9, x9, lsr #27
     cd0:      	mul	x9, x9, x13
     cd4:      	eor	x12, x9, x8
     cd8:      	mov	x13, #0x7c15            ; =31765
     cdc:      	movk	x13, #0x7f4a, lsl #16
     ce0:      	movk	x13, #0x79b9, lsl #32
     ce4:      	movk	x13, #0x9e37, lsl #48
     ce8:      	mul	x11, x11, x13
     cec:      	eor	x10, x10, x11
     cf0:      	eor	x10, x10, x12, lsr #31
     cf4:      	eor	x8, x8, x9
     cf8:      	eor	x0, x10, x8
     cfc:      	ldp	x29, x30, [sp, #0x50]
     d00:      	add	sp, sp, #0x60
     d04:      	ret

0000000000000d08 <_wf_chain_mutation_word_prepare>:
     d08:      	b	0xd08 <_wf_chain_mutation_word_prepare>
		0000000000000d08:  ARM64_RELOC_BRANCH26	_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd

0000000000000d0c <_wf_chain_mutation_word_batch>:
     d0c:      	b	0xd0c <_wf_chain_mutation_word_batch>
		0000000000000d0c:  ARM64_RELOC_BRANCH26	_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd

0000000000000d10 <_wf_chain_mutation_word_geometry>:
     d10:      	ldr	x8, [x0]
     d14:      	ldr	x9, [x0, #0x18]
     d18:      	add	x0, x9, x8, lsl #32
     d1c:      	ret

0000000000000d20 <_wf_chain_mutation_word_verify>:
     d20:      	b	0xd20 <_wf_chain_mutation_word_verify>
		0000000000000d20:  ARM64_RELOC_BRANCH26	_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd

0000000000000d24 <_wf_chain_mutation_word_finish>:
     d24:      	b	0xd24 <_wf_chain_mutation_word_finish>
		0000000000000d24:  ARM64_RELOC_BRANCH26	_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd

0000000000000d28 <_wf_chain_mutation_record_prepare>:
     d28:      	b	0xd28 <_wf_chain_mutation_record_prepare>
		0000000000000d28:  ARM64_RELOC_BRANCH26	_wf_chain_mutation_prepare$instance$4250cb78d3f44027

0000000000000d2c <_wf_chain_mutation_record_batch>:
     d2c:      	b	0xd2c <_wf_chain_mutation_record_batch>
		0000000000000d2c:  ARM64_RELOC_BRANCH26	_wf_chain_mutation_batch$instance$4250cb78d3f44027

0000000000000d30 <_wf_chain_mutation_record_geometry>:
     d30:      	ldr	x8, [x0]
     d34:      	ldr	x9, [x0, #0x18]
     d38:      	add	x0, x9, x8, lsl #32
     d3c:      	ret

0000000000000d40 <_wf_chain_mutation_record_verify>:
     d40:      	b	0xd40 <_wf_chain_mutation_record_verify>
		0000000000000d40:  ARM64_RELOC_BRANCH26	_wf_chain_mutation_verify$instance$4250cb78d3f44027

0000000000000d44 <_wf_chain_mutation_record_finish>:
     d44:      	sub	sp, sp, #0x60
     d48:      	stp	x29, x30, [sp, #0x50]
     d4c:      	ldr	x8, [x0, #0x40]
     d50:      	ldp	q0, q1, [x0]
     d54:      	stp	q0, q1, [sp, #0x20]
     d58:      	ldr	q0, [x0, #0x20]
     d5c:      	str	q0, [sp, #0x40]
     d60:      	stp	x8, xzr, [sp]
     d64:      	stp	xzr, xzr, [sp, #0x10]
     d68:      	add	x0, sp, #0x20
     d6c:      	mov	x1, sp
     d70:      	bl	0xd70 <_wf_chain_mutation_record_finish+0x2c>
		0000000000000d70:  ARM64_RELOC_BRANCH26	_wf_full_chain_free$instance$e1a21e22af512733
     d74:      	ldp	x8, x9, [sp]
     d78:      	ldp	x10, x11, [sp, #0x10]
     d7c:      	eor	x8, x8, x8, lsr #30
     d80:      	mov	x12, #0xe5b9            ; =58809
     d84:      	movk	x12, #0x1ce4, lsl #16
     d88:      	movk	x12, #0x476d, lsl #32
     d8c:      	movk	x12, #0xbf58, lsl #48
     d90:      	mul	x8, x8, x12
     d94:      	eor	x8, x8, x8, lsr #27
     d98:      	mov	x13, #0x11eb            ; =4587
     d9c:      	movk	x13, #0x1331, lsl #16
     da0:      	movk	x13, #0x49bb, lsl #32
     da4:      	movk	x13, #0x94d0, lsl #48
     da8:      	mul	x8, x8, x13
     dac:      	eor	x9, x9, x9, lsr #30
     db0:      	mul	x9, x9, x12
     db4:      	eor	x9, x9, x9, lsr #27
     db8:      	mul	x9, x9, x13
     dbc:      	eor	x12, x9, x8
     dc0:      	mov	x13, #0x7c15            ; =31765
     dc4:      	movk	x13, #0x7f4a, lsl #16
     dc8:      	movk	x13, #0x79b9, lsl #32
     dcc:      	movk	x13, #0x9e37, lsl #48
     dd0:      	mul	x11, x11, x13
     dd4:      	eor	x10, x10, x11
     dd8:      	eor	x10, x10, x12, lsr #31
     ddc:      	eor	x8, x8, x9
     de0:      	eor	x0, x10, x8
     de4:      	ldp	x29, x30, [sp, #0x50]
     de8:      	add	sp, sp, #0x60
     dec:      	ret

0000000000000df0 <_wf_std.collections.hash_map.hash_map_probe>:
     df0:      	sub	x8, x2, x0
     df4:      	cmp	x1, x8
     df8:      	csneg	x8, x0, x8, lo
     dfc:      	add	x0, x8, x1
     e00:      	ret

0000000000000e04 <_wf_array_filled$instance$581665c886d1d2c8>:
     e04:      	dup.2d	v0, x1
     e08:      	stp	q0, q0, [x0]
     e0c:      	stp	q0, q0, [x0, #0x20]
     e10:      	stp	q0, q0, [x0, #0x40]
     e14:      	stp	q0, q0, [x0, #0x60]
     e18:      	stp	q0, q0, [x0, #0x80]
     e1c:      	stp	q0, q0, [x0, #0xa0]
     e20:      	stp	q0, q0, [x0, #0xc0]
     e24:      	stp	q0, q0, [x0, #0xe0]
     e28:      	ret

0000000000000e2c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd>:
     e2c:      	sub	sp, sp, #0xb0
     e30:      	stp	x28, x27, [sp, #0x50]
     e34:      	stp	x26, x25, [sp, #0x60]
     e38:      	stp	x24, x23, [sp, #0x70]
     e3c:      	stp	x22, x21, [sp, #0x80]
     e40:      	stp	x20, x19, [sp, #0x90]
     e44:      	stp	x29, x30, [sp, #0xa0]
     e48:      	mov	x19, x0
     e4c:      	mov	x8, #0x7c15             ; =31765
     e50:      	movk	x8, #0x7f4a, lsl #16
     e54:      	movk	x8, #0x79b9, lsl #32
     e58:      	movk	x8, #0x9e37, lsl #48
     e5c:      	eor	x20, x0, x8
     e60:      	cmp	x1, #0x0
     e64:      	cset	w8, ne
     e68:      	str	x20, [sp, #0x30]
     e6c:      	strb	w8, [sp, #0x38]
     e70:      	mov	w0, #0x48               ; =72
     e74:      	bl	0xe74 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x48>
		0000000000000e74:  ARM64_RELOC_BRANCH26	_malloc
     e78:      	cbz	x0, 0x16a8 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x87c>
     e7c:      	mov	x25, #0x0               ; =0
     e80:      	mov	x21, #0xe5b9            ; =58809
     e84:      	movk	x21, #0x1ce4, lsl #16
     e88:      	movk	x21, #0x476d, lsl #32
     e8c:      	movk	x21, #0xbf58, lsl #48
     e90:      	str	wzr, [x0]
     e94:      	stp	xzr, xzr, [x0, #0x38]
     e98:      	stp	xzr, xzr, [x0, #0x8]
     e9c:      	str	wzr, [x0, #0x18]
     ea0:      	stp	xzr, xzr, [x0, #0x20]
     ea4:      	mov	w1, #0x3                ; =3
     ea8:      	dup.2d	v0, x1
     eac:      	str	wzr, [x0, #0x30]
     eb0:      	str	q0, [sp]
     eb4:      	stp	xzr, xzr, [sp, #0x18]
     eb8:      	str	x0, [sp, #0x10]
     ebc:      	eor	x26, x20, x20, lsr #30
     ec0:      	mov	w27, #0x1               ; =1
     ec4:      	ldrb	w23, [sp, #0x38]
     ec8:      	mov	w28, #0x2               ; =2
     ecc:      	mov	w22, #0x18              ; =24
     ed0:      	mov	w20, #0x83              ; =131
     ed4:      	mov	x24, x19
     ed8:      	b	0xf00 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0xd4>
     edc:      	strb	w27, [sp, #0x4c]
     ee0:      	tst	w27, #0x1
     ee4:      	cinc	x10, x27, ne
     ee8:      	madd	x8, x24, x20, x8
     eec:      	add	x8, x8, x10
     ef0:      	madd	x24, x8, x20, x9
     ef4:      	add	x25, x25, #0x1
     ef8:      	cmp	x25, #0x3
     efc:      	b.eq	0x10a0 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x274>
     f00:      	ldp	x8, x9, [sp, #0x18]
     f04:      	adds	x9, x8, x9
     f08:      	csinv	x9, x9, xzr, lo
     f0c:      	cmp	x1, #0x2
     f10:      	b.hi	0xf48 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x11c>
     f14:      	sub	x10, x1, x1, lsr #2
     f18:      	cmp	x9, x10
     f1c:      	b.lo	0xf48 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x11c>
     f20:      	cmp	x8, x1, lsr #1
     f24:      	b.lo	0xf3c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x110>
     f28:      	cbz	x1, 0xf38 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x10c>
     f2c:      	cmp	x1, #0x1
     f30:      	cinc	x1, x28, ne
     f34:      	b	0xf3c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x110>
     f38:      	mov	w1, #0x1                ; =1
     f3c:      	mov	x0, sp
     f40:      	add	x2, sp, #0x30
     f44:      	bl	0xf44 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x118>
		0000000000000f44:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6
     f48:      	orr	x8, x27, x25, lsl #1
     f4c:      	tbz	w23, #0x0, 0xfd4 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x1a8>
     f50:      	mov	x10, #0x0               ; =0
     f54:      	add	x9, x25, x19
     f58:      	ldr	x1, [sp]
     f5c:      	cbz	x1, 0x1004 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x1d8>
     f60:      	udiv	x11, x10, x1
     f64:      	msub	x11, x11, x1, x10
     f68:      	ldr	x12, [sp, #0x10]
     f6c:      	mov	x13, x1
     f70:      	mov	x10, x1
     f74:      	b	0xf94 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x168>
     f78:      	cmp	x10, x1
     f7c:      	csel	x10, x11, x10, eq
     f80:      	add	x14, x11, #0x1
     f84:      	cmp	x14, x1
     f88:      	csinc	x11, xzr, x11, hs
     f8c:      	subs	x13, x13, #0x1
     f90:      	b.eq	0x1008 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x1dc>
     f94:      	madd	x14, x11, x22, x12
     f98:      	ldr	w15, [x14]
     f9c:      	cmp	w15, #0x1
     fa0:      	b.eq	0xf78 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x14c>
     fa4:      	cmp	w15, #0x2
     fa8:      	b.ne	0x1054 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x228>
     fac:      	ldr	x15, [x14, #0x8]
     fb0:      	cmp	x15, x8
     fb4:      	b.ne	0xf80 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x154>
     fb8:      	ldr	x11, [x14, #0x10]
     fbc:      	str	w28, [x14]
     fc0:      	str	x9, [x14, #0x10]
     fc4:      	strb	wzr, [sp, #0x4c]
     fc8:      	mov	w10, #0x1               ; =1
     fcc:      	mov	x9, x11
     fd0:      	b	0xee8 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0xbc>
     fd4:      	eor	x9, x26, x8
     fd8:      	mul	x9, x9, x21
     fdc:      	eor	x9, x9, x9, lsr #27
     fe0:      	mov	x10, #0x11eb            ; =4587
     fe4:      	movk	x10, #0x1331, lsl #16
     fe8:      	movk	x10, #0x49bb, lsl #32
     fec:      	movk	x10, #0x94d0, lsl #48
     ff0:      	mul	x9, x9, x10
     ff4:      	eor	x10, x9, x9, lsr #31
     ff8:      	add	x9, x25, x19
     ffc:      	ldr	x1, [sp]
    1000:      	cbnz	x1, 0xf60 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x134>
    1004:      	mov	x10, #0x0               ; =0
    1008:      	cmp	x10, x1
    100c:      	b.hs	0xedc <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0xb0>
    1010:      	ldr	x11, [sp, #0x18]
    1014:      	cmp	x11, #0x2
    1018:      	b.hi	0xedc <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0xb0>
    101c:      	add	x11, x11, #0x1
    1020:      	str	x11, [sp, #0x18]
    1024:      	ldr	x11, [sp, #0x10]
    1028:      	madd	x10, x10, x22, x11
    102c:      	ldr	w13, [x10]
    1030:      	cmp	w13, #0x1
    1034:      	b.ne	0x1068 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x23c>
    1038:      	ldr	x11, [sp, #0x20]
    103c:      	subs	x11, x11, #0x1
    1040:      	csel	x11, xzr, x11, lo
    1044:      	str	x11, [sp, #0x20]
    1048:      	str	w28, [x10]
    104c:      	stp	x8, x9, [x10, #0x8]
    1050:      	b	0x108c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x260>
    1054:      	cmp	x10, x1
    1058:      	csel	x10, x11, x10, eq
    105c:      	cmp	x10, x1
    1060:      	b.hs	0xedc <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0xb0>
    1064:      	b	0x1010 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x1e4>
    1068:      	ldp	x11, x12, [x10, #0x8]
    106c:      	str	w28, [x10]
    1070:      	stp	x8, x9, [x10, #0x8]
    1074:      	cbz	w13, 0x108c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x260>
    1078:      	strb	wzr, [sp, #0x4c]
    107c:      	mov	w10, #0x1               ; =1
    1080:      	mov	x9, x12
    1084:      	mov	x8, x11
    1088:      	b	0xee8 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0xbc>
    108c:      	strb	wzr, [sp, #0x4c]
    1090:      	mul	x24, x24, x20
    1094:      	add	x25, x25, #0x1
    1098:      	cmp	x25, #0x3
    109c:      	b.ne	0xf00 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0xd4>
    10a0:      	add	x20, x19, #0xa
    10a4:      	ldp	x8, x9, [sp, #0x18]
    10a8:      	adds	x9, x8, x9
    10ac:      	csinv	x9, x9, xzr, lo
    10b0:      	cmp	x1, #0x2
    10b4:      	b.hi	0x10ec <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x2c0>
    10b8:      	sub	x10, x1, x1, lsr #2
    10bc:      	cmp	x9, x10
    10c0:      	b.lo	0x10ec <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x2c0>
    10c4:      	cmp	x1, #0x1
    10c8:      	mov	w9, #0x2                ; =2
    10cc:      	cinc	x9, x9, ne
    10d0:      	cmp	x1, #0x0
    10d4:      	csinc	x9, x9, xzr, ne
    10d8:      	cmp	x8, x1, lsr #1
    10dc:      	csel	x1, x1, x9, lo
    10e0:      	mov	x0, sp
    10e4:      	add	x2, sp, #0x30
    10e8:      	bl	0x10e8 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x2bc>
		00000000000010e8:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6
    10ec:      	mov	x27, #0x7c15            ; =31765
    10f0:      	movk	x27, #0x7f4a, lsl #16
    10f4:      	movk	x27, #0x79b9, lsl #32
    10f8:      	movk	x27, #0x9e37, lsl #48
    10fc:      	sub	x8, x27, #0x1
    1100:      	eor	x8, x19, x8
    1104:      	eor	x8, x8, x8, lsr #30
    1108:      	mul	x8, x8, x21
    110c:      	eor	x8, x8, x8, lsr #27
    1110:      	mov	x25, #0x11eb            ; =4587
    1114:      	movk	x25, #0x1331, lsl #16
    1118:      	movk	x25, #0x49bb, lsl #32
    111c:      	movk	x25, #0x94d0, lsl #48
    1120:      	mul	x8, x8, x25
    1124:      	eor	x8, x8, x8, lsr #31
    1128:      	tst	w23, #0x1
    112c:      	csel	x9, xzr, x8, ne
    1130:      	ldr	x8, [sp]
    1134:      	cbz	x8, 0x11b8 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x38c>
    1138:      	udiv	x10, x9, x8
    113c:      	msub	x9, x10, x8, x9
    1140:      	ldr	x11, [sp, #0x10]
    1144:      	mov	w12, #0x18              ; =24
    1148:      	mov	x13, x8
    114c:      	mov	x10, x8
    1150:      	b	0x1170 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x344>
    1154:      	cmp	x10, x8
    1158:      	csel	x10, x9, x10, eq
    115c:      	add	x14, x9, #0x1
    1160:      	cmp	x14, x8
    1164:      	csinc	x9, xzr, x9, hs
    1168:      	subs	x13, x13, #0x1
    116c:      	b.eq	0x11bc <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x390>
    1170:      	madd	x14, x9, x12, x11
    1174:      	ldr	w15, [x14]
    1178:      	cmp	w15, #0x1
    117c:      	b.eq	0x1154 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x328>
    1180:      	cmp	w15, #0x2
    1184:      	b.ne	0x1214 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x3e8>
    1188:      	ldr	x15, [x14, #0x8]
    118c:      	cmp	x15, #0x1
    1190:      	b.ne	0x115c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x330>
    1194:      	ldr	x10, [x14, #0x10]
    1198:      	mov	w9, #0x2                ; =2
    119c:      	str	w9, [x14]
    11a0:      	str	x20, [x14, #0x10]
    11a4:      	strb	wzr, [sp, #0x48]
    11a8:      	mov	w9, #0x1                ; =1
    11ac:      	mov	x20, x10
    11b0:      	mov	w10, #0x1               ; =1
    11b4:      	b	0x1234 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x408>
    11b8:      	mov	x10, #0x0               ; =0
    11bc:      	cmp	x10, x8
    11c0:      	b.hs	0x1224 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x3f8>
    11c4:      	ldr	x9, [sp, #0x18]
    11c8:      	cmp	x9, #0x2
    11cc:      	b.hi	0x1224 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x3f8>
    11d0:      	add	x9, x9, #0x1
    11d4:      	str	x9, [sp, #0x18]
    11d8:      	ldr	x11, [sp, #0x10]
    11dc:      	mov	w12, #0x18              ; =24
    11e0:      	madd	x11, x10, x12, x11
    11e4:      	ldr	w13, [x11]
    11e8:      	cmp	w13, #0x1
    11ec:      	b.ne	0x14c0 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x694>
    11f0:      	ldr	x10, [sp, #0x20]
    11f4:      	subs	x10, x10, #0x1
    11f8:      	csel	x10, xzr, x10, lo
    11fc:      	str	x10, [sp, #0x20]
    1200:      	mov	w10, #0x2               ; =2
    1204:      	str	w10, [x11]
    1208:      	mov	w10, #0x1               ; =1
    120c:      	stp	x10, x20, [x11, #0x8]
    1210:      	b	0x14e8 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x6bc>
    1214:      	cmp	x10, x8
    1218:      	csel	x10, x9, x10, eq
    121c:      	cmp	x10, x8
    1220:      	b.lo	0x11c4 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x398>
    1224:      	mov	w10, #0x1               ; =1
    1228:      	strb	w10, [sp, #0x48]
    122c:      	tst	w10, #0x1
    1230:      	cinc	x9, x10, ne
    1234:      	mov	w11, #0x83              ; =131
    1238:      	mul	x12, x24, x11
    123c:      	add	x9, x10, x9
    1240:      	add	x9, x9, x12
    1244:      	madd	x20, x9, x11, x20
    1248:      	ldp	x9, x10, [sp, #0x18]
    124c:      	add	x22, x19, #0x14
    1250:      	adds	x10, x9, x10
    1254:      	csinv	x10, x10, xzr, lo
    1258:      	cmp	x8, #0x2
    125c:      	b.hi	0x1294 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x468>
    1260:      	sub	x11, x8, x8, lsr #2
    1264:      	cmp	x10, x11
    1268:      	b.lo	0x1294 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x468>
    126c:      	cmp	x8, #0x1
    1270:      	mov	w10, #0x2               ; =2
    1274:      	cinc	x10, x10, ne
    1278:      	cmp	x8, #0x0
    127c:      	csinc	x10, x10, xzr, ne
    1280:      	cmp	x9, x8, lsr #1
    1284:      	csel	x1, x8, x10, lo
    1288:      	mov	x0, sp
    128c:      	add	x2, sp, #0x30
    1290:      	bl	0x1290 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x464>
		0000000000001290:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6
    1294:      	sub	x8, x27, #0x3
    1298:      	eor	x8, x19, x8
    129c:      	eor	x8, x8, x8, lsr #30
    12a0:      	mul	x8, x8, x21
    12a4:      	eor	x8, x8, x8, lsr #27
    12a8:      	mul	x8, x8, x25
    12ac:      	eor	x8, x8, x8, lsr #31
    12b0:      	tst	w23, #0x1
    12b4:      	csel	x9, xzr, x8, ne
    12b8:      	ldr	x8, [sp]
    12bc:      	cbz	x8, 0x133c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x510>
    12c0:      	udiv	x10, x9, x8
    12c4:      	msub	x10, x10, x8, x9
    12c8:      	ldr	x0, [sp, #0x10]
    12cc:      	mov	w11, #0x18              ; =24
    12d0:      	mov	x12, x8
    12d4:      	mov	x9, x8
    12d8:      	b	0x12f8 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x4cc>
    12dc:      	cmp	x9, x8
    12e0:      	csel	x9, x10, x9, eq
    12e4:      	add	x13, x10, #0x1
    12e8:      	cmp	x13, x8
    12ec:      	csinc	x10, xzr, x10, hs
    12f0:      	subs	x12, x12, #0x1
    12f4:      	b.eq	0x1340 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x514>
    12f8:      	madd	x13, x10, x11, x0
    12fc:      	ldr	w14, [x13]
    1300:      	cmp	w14, #0x1
    1304:      	b.eq	0x12dc <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x4b0>
    1308:      	cmp	w14, #0x2
    130c:      	b.ne	0x1394 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x568>
    1310:      	ldr	x14, [x13, #0x8]
    1314:      	cmp	x14, #0x7
    1318:      	b.ne	0x12e4 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x4b8>
    131c:      	ldr	x10, [x13, #0x10]
    1320:      	mov	w9, #0x2                ; =2
    1324:      	str	w9, [x13]
    1328:      	str	x22, [x13, #0x10]
    132c:      	strb	wzr, [sp, #0x44]
    1330:      	mov	w9, #0x1                ; =1
    1334:      	mov	x22, x10
    1338:      	b	0x13b8 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x58c>
    133c:      	mov	x9, #0x0                ; =0
    1340:      	cmp	x9, x8
    1344:      	b.hs	0x13a4 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x578>
    1348:      	ldp	x0, x10, [sp, #0x10]
    134c:      	cmp	x10, #0x2
    1350:      	b.hi	0x13a8 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x57c>
    1354:      	add	x10, x10, #0x1
    1358:      	str	x10, [sp, #0x18]
    135c:      	mov	w10, #0x18              ; =24
    1360:      	madd	x9, x9, x10, x0
    1364:      	ldr	w12, [x9]
    1368:      	cmp	w12, #0x1
    136c:      	b.ne	0x1510 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x6e4>
    1370:      	ldr	x10, [sp, #0x20]
    1374:      	subs	x10, x10, #0x1
    1378:      	csel	x10, xzr, x10, lo
    137c:      	str	x10, [sp, #0x20]
    1380:      	mov	w10, #0x2               ; =2
    1384:      	str	w10, [x9]
    1388:      	mov	w10, #0x7               ; =7
    138c:      	stp	x10, x22, [x9, #0x8]
    1390:      	b	0x1558 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x72c>
    1394:      	cmp	x9, x8
    1398:      	csel	x9, x10, x9, eq
    139c:      	cmp	x9, x8
    13a0:      	b.lo	0x1348 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x51c>
    13a4:      	ldr	x0, [sp, #0x10]
    13a8:      	mov	w9, #0x1                ; =1
    13ac:      	strb	w9, [sp, #0x44]
    13b0:      	tst	w9, #0x1
    13b4:      	cinc	x9, x9, ne
    13b8:      	mov	w10, #0x83              ; =131
    13bc:      	mul	x11, x20, x10
    13c0:      	add	x9, x11, x9
    13c4:      	madd	x9, x9, x10, x22
    13c8:      	add	x19, x9, #0x395
    13cc:      	ldr	x9, [sp, #0x8]
    13d0:      	cbz	x8, 0x14ac <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x680>
    13d4:      	sub	x11, x8, #0x1
    13d8:      	and	x10, x8, #0x3
    13dc:      	cmp	x11, #0x3
    13e0:      	b.hs	0x1578 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x74c>
    13e4:      	mov	x11, #0x0               ; =0
    13e8:      	mov	x23, #0x0               ; =0
    13ec:      	mov	x24, #0x0               ; =0
    13f0:      	cbz	x10, 0x144c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x620>
    13f4:      	mov	w12, #0x18              ; =24
    13f8:      	madd	x8, x8, x12, x0
    13fc:      	sub	x8, x8, #0x8
    1400:      	mov	w12, #0x83              ; =131
    1404:      	b	0x1414 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x5e8>
    1408:      	sub	x8, x8, #0x18
    140c:      	subs	x10, x10, #0x1
    1410:      	b.eq	0x144c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x620>
    1414:      	ldur	w13, [x8, #-0x10]
    1418:      	cmp	w13, #0x2
    141c:      	b.ne	0x1408 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x5dc>
    1420:      	ldp	x14, x13, [x8, #-0x8]
    1424:      	madd	x13, x14, x12, x13
    1428:      	add	x24, x13, x24
    142c:      	eor	x13, x13, x13, lsr #30
    1430:      	mul	x13, x13, x21
    1434:      	eor	x13, x13, x13, lsr #27
    1438:      	mul	x13, x13, x25
    143c:      	eor	x14, x23, x13, lsr #31
    1440:      	eor	x23, x14, x13
    1444:      	add	x11, x11, #0x1
    1448:      	b	0x1408 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x5dc>
    144c:      	mul	x20, x11, x27
    1450:      	cbz	x9, 0x1458 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x62c>
    1454:      	bl	0x1454 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x628>
		0000000000001454:  ARM64_RELOC_BRANCH26	_free
    1458:      	eor	x8, x19, x19, lsr #30
    145c:      	mul	x8, x8, x21
    1460:      	eor	x8, x8, x8, lsr #27
    1464:      	mul	x8, x8, x25
    1468:      	eor	x9, x24, x24, lsr #30
    146c:      	mul	x9, x9, x21
    1470:      	eor	x9, x9, x9, lsr #27
    1474:      	mul	x9, x9, x25
    1478:      	eor	x10, x9, x8
    147c:      	eor	x11, x23, x20
    1480:      	eor	x10, x11, x10, lsr #31
    1484:      	eor	x8, x8, x9
    1488:      	eor	x0, x10, x8
    148c:      	ldp	x29, x30, [sp, #0xa0]
    1490:      	ldp	x20, x19, [sp, #0x90]
    1494:      	ldp	x22, x21, [sp, #0x80]
    1498:      	ldp	x24, x23, [sp, #0x70]
    149c:      	ldp	x26, x25, [sp, #0x60]
    14a0:      	ldp	x28, x27, [sp, #0x50]
    14a4:      	add	sp, sp, #0xb0
    14a8:      	ret
    14ac:      	mov	x20, #0x0               ; =0
    14b0:      	mov	x23, #0x0               ; =0
    14b4:      	mov	x24, #0x0               ; =0
    14b8:      	cbnz	x9, 0x1454 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x628>
    14bc:      	b	0x1458 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x62c>
    14c0:      	ldp	x10, x12, [x11, #0x8]
    14c4:      	mov	w14, #0x2               ; =2
    14c8:      	str	w14, [x11]
    14cc:      	mov	w14, #0x1               ; =1
    14d0:      	stp	x14, x20, [x11, #0x8]
    14d4:      	cbz	w13, 0x14e8 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x6bc>
    14d8:      	strb	wzr, [sp, #0x48]
    14dc:      	mov	w9, #0x1                ; =1
    14e0:      	mov	x20, x12
    14e4:      	b	0x1234 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x408>
    14e8:      	strb	wzr, [sp, #0x48]
    14ec:      	mov	w10, #0x83              ; =131
    14f0:      	mul	x20, x24, x10
    14f4:      	add	x22, x19, #0x14
    14f8:      	ldr	x10, [sp, #0x20]
    14fc:      	adds	x10, x9, x10
    1500:      	csinv	x10, x10, xzr, lo
    1504:      	cmp	x8, #0x2
    1508:      	b.ls	0x1260 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x434>
    150c:      	b	0x1294 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x468>
    1510:      	ldp	x10, x11, [x9, #0x8]
    1514:      	mov	w13, #0x2               ; =2
    1518:      	str	w13, [x9]
    151c:      	mov	w13, #0x7               ; =7
    1520:      	stp	x13, x22, [x9, #0x8]
    1524:      	cbz	w12, 0x1558 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x72c>
    1528:      	strb	wzr, [sp, #0x44]
    152c:      	mov	w9, #0x83               ; =131
    1530:      	mul	x12, x20, x9
    1534:      	add	x10, x10, x12
    1538:      	madd	x9, x10, x9, x11
    153c:      	add	x19, x9, #0x83
    1540:      	ldr	x9, [sp, #0x8]
    1544:      	sub	x11, x8, #0x1
    1548:      	and	x10, x8, #0x3
    154c:      	cmp	x11, #0x3
    1550:      	b.lo	0x13e4 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x5b8>
    1554:      	b	0x1578 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x74c>
    1558:      	strb	wzr, [sp, #0x44]
    155c:      	mov	w9, #0x83               ; =131
    1560:      	mul	x19, x20, x9
    1564:      	ldr	x9, [sp, #0x8]
    1568:      	sub	x11, x8, #0x1
    156c:      	and	x10, x8, #0x3
    1570:      	cmp	x11, #0x3
    1574:      	b.lo	0x13e4 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x5b8>
    1578:      	mov	x11, #0x0               ; =0
    157c:      	mov	x23, #0x0               ; =0
    1580:      	mov	x24, #0x0               ; =0
    1584:      	and	x12, x8, #0xfffffffffffffffc
    1588:      	mov	w13, #0x18              ; =24
    158c:      	madd	x13, x8, x13, x0
    1590:      	sub	x13, x13, #0x30
    1594:      	mov	w14, #0x83              ; =131
    1598:      	b	0x15ac <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x780>
    159c:      	sub	x13, x13, #0x60
    15a0:      	sub	x8, x8, #0x4
    15a4:      	sub	x12, x12, #0x4
    15a8:      	cbz	x12, 0x13f0 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x5c4>
    15ac:      	ldr	w15, [x13, #0x18]
    15b0:      	cmp	w15, #0x2
    15b4:      	b.eq	0x15e0 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x7b4>
    15b8:      	ldr	w15, [x13]
    15bc:      	cmp	w15, #0x2
    15c0:      	b.eq	0x1614 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x7e8>
    15c4:      	ldur	w15, [x13, #-0x18]
    15c8:      	cmp	w15, #0x2
    15cc:      	b.eq	0x1648 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x81c>
    15d0:      	ldur	w15, [x13, #-0x30]
    15d4:      	cmp	w15, #0x2
    15d8:      	b.ne	0x159c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x770>
    15dc:      	b	0x167c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x850>
    15e0:      	ldp	x16, x15, [x13, #0x20]
    15e4:      	madd	x15, x16, x14, x15
    15e8:      	add	x24, x15, x24
    15ec:      	eor	x15, x15, x15, lsr #30
    15f0:      	mul	x15, x15, x21
    15f4:      	eor	x15, x15, x15, lsr #27
    15f8:      	mul	x15, x15, x25
    15fc:      	eor	x16, x23, x15, lsr #31
    1600:      	eor	x23, x16, x15
    1604:      	add	x11, x11, #0x1
    1608:      	ldr	w15, [x13]
    160c:      	cmp	w15, #0x2
    1610:      	b.ne	0x15c4 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x798>
    1614:      	ldp	x16, x15, [x13, #0x8]
    1618:      	madd	x15, x16, x14, x15
    161c:      	add	x24, x15, x24
    1620:      	eor	x15, x15, x15, lsr #30
    1624:      	mul	x15, x15, x21
    1628:      	eor	x15, x15, x15, lsr #27
    162c:      	mul	x15, x15, x25
    1630:      	eor	x16, x23, x15, lsr #31
    1634:      	eor	x23, x16, x15
    1638:      	add	x11, x11, #0x1
    163c:      	ldur	w15, [x13, #-0x18]
    1640:      	cmp	w15, #0x2
    1644:      	b.ne	0x15d0 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x7a4>
    1648:      	ldp	x16, x15, [x13, #-0x10]
    164c:      	madd	x15, x16, x14, x15
    1650:      	add	x24, x15, x24
    1654:      	eor	x15, x15, x15, lsr #30
    1658:      	mul	x15, x15, x21
    165c:      	eor	x15, x15, x15, lsr #27
    1660:      	mul	x15, x15, x25
    1664:      	eor	x16, x23, x15, lsr #31
    1668:      	eor	x23, x16, x15
    166c:      	add	x11, x11, #0x1
    1670:      	ldur	w15, [x13, #-0x30]
    1674:      	cmp	w15, #0x2
    1678:      	b.ne	0x159c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x770>
    167c:      	ldp	x16, x15, [x13, #-0x28]
    1680:      	madd	x15, x16, x14, x15
    1684:      	add	x24, x15, x24
    1688:      	eor	x15, x15, x15, lsr #30
    168c:      	mul	x15, x15, x21
    1690:      	eor	x15, x15, x15, lsr #27
    1694:      	mul	x15, x15, x25
    1698:      	eor	x16, x23, x15, lsr #31
    169c:      	eor	x23, x16, x15
    16a0:      	add	x11, x11, #0x1
    16a4:      	b	0x159c <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x770>
    16a8:      	bl	0x16a8 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x87c>
		00000000000016a8:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

00000000000016ac <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd>:
    16ac:      	stp	x28, x27, [sp, #-0x60]!
    16b0:      	stp	x26, x25, [sp, #0x10]
    16b4:      	stp	x24, x23, [sp, #0x20]
    16b8:      	stp	x22, x21, [sp, #0x30]
    16bc:      	stp	x20, x19, [sp, #0x40]
    16c0:      	stp	x29, x30, [sp, #0x50]
    16c4:      	sub	sp, sp, #0x270
    16c8:      	mov	x22, x4
    16cc:      	str	x2, [sp, #0x18]
    16d0:      	mov	x21, x1
    16d4:      	mov	x23, x0
    16d8:      	mov	x8, #0x7c15             ; =31765
    16dc:      	movk	x8, #0x7f4a, lsl #16
    16e0:      	movk	x8, #0x79b9, lsl #32
    16e4:      	movk	x8, #0x9e37, lsl #48
    16e8:      	str	x3, [sp, #0x38]
    16ec:      	eor	x8, x3, x8
    16f0:      	cmp	x5, #0x0
    16f4:      	cset	w9, ne
    16f8:      	str	x8, [sp, #0x200]
    16fc:      	strb	w9, [sp, #0x208]
    1700:      	cbz	x0, 0x1734 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x88>
    1704:      	add	x8, x23, x23, lsl #1
    1708:      	lsl	x0, x8, #3
    170c:      	bl	0x170c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x60>
		000000000000170c:  ARM64_RELOC_BRANCH26	_malloc
    1710:      	cbz	x0, 0x2b1c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1470>
    1714:      	mov	x8, #0x0                ; =0
    1718:      	add	x9, x0, #0x8
    171c:      	stur	wzr, [x9, #-0x8]
    1720:      	add	x8, x8, #0x1
    1724:      	stp	xzr, xzr, [x9], #0x18
    1728:      	cmp	x23, x8
    172c:      	b.ne	0x171c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x70>
    1730:      	b	0x173c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x90>
    1734:      	adrp	x0, 0x1000 <_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd+0x1d4>
		0000000000001734:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    1738:      	add	x0, x0, #0x0
		0000000000001738:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    173c:      	add	x27, sp, #0x40
    1740:      	mov	x6, #0xe5b9             ; =58809
    1744:      	movk	x6, #0x1ce4, lsl #16
    1748:      	movk	x6, #0x476d, lsl #32
    174c:      	movk	x6, #0xbf58, lsl #48
    1750:      	mov	x5, #0x11eb             ; =4587
    1754:      	movk	x5, #0x1331, lsl #16
    1758:      	movk	x5, #0x49bb, lsl #32
    175c:      	movk	x5, #0x94d0, lsl #48
    1760:      	str	x23, [sp, #0x210]
    1764:      	str	x23, [sp, #0x218]
    1768:      	str	x0, [sp, #0x220]
    176c:      	str	xzr, [sp, #0x228]
    1770:      	str	xzr, [sp, #0x230]
    1774:      	ldr	x8, [sp, #0x38]
    1778:      	str	x8, [sp, #0x238]
    177c:      	str	xzr, [sp, #0x240]
    1780:      	str	xzr, [sp, #0x250]
    1784:      	str	xzr, [sp, #0x248]
    1788:      	cbz	x21, 0x19c8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x31c>
    178c:      	mov	x19, #0x0               ; =0
    1790:      	add	x20, sp, #0x40
    1794:      	mov	w24, #0x1               ; =1
    1798:      	mov	w25, #0x18              ; =24
    179c:      	mov	w26, #0x2               ; =2
    17a0:      	mov	w28, #0x83              ; =131
    17a4:      	b	0x17e4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x138>
    17a8:      	stp	x24, x8, [sp, #0x40]
    17ac:      	strb	w24, [sp, #0x44]
    17b0:      	str	x9, [sp, #0x50]
    17b4:      	ldur	q0, [x20, #0x8]
    17b8:      	stur	q0, [x27, #0x18]
    17bc:      	mov	w8, #0x2                ; =2
    17c0:      	ldr	x9, [sp, #0x238]
    17c4:      	madd	x8, x9, x28, x8
    17c8:      	ldp	x9, x10, [sp, #0x58]
    17cc:      	add	x8, x9, x8
    17d0:      	madd	x8, x8, x28, x10
    17d4:      	str	x8, [sp, #0x238]
    17d8:      	add	x19, x19, #0x1
    17dc:      	cmp	x19, x21
    17e0:      	b.eq	0x19c8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x31c>
    17e4:      	ldr	x1, [sp, #0x210]
    17e8:      	ldr	x8, [sp, #0x228]
    17ec:      	ldr	x9, [sp, #0x230]
    17f0:      	adds	x9, x8, x9
    17f4:      	csinv	x10, x9, xzr, lo
    17f8:      	sub	x9, x1, x1, lsr #2
    17fc:      	lsr	x11, x1, #14
    1800:      	cmp	x11, #0x0
    1804:      	ccmp	x10, x9, #0x0, eq
    1808:      	b.lo	0x185c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1b0>
    180c:      	cmp	x8, x9, lsr #1
    1810:      	b.lo	0x1830 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x184>
    1814:      	cbz	x1, 0x182c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x180>
    1818:      	cmp	x1, #0x2, lsl #12       ; =0x2000
    181c:      	mov	w8, #0x2000             ; =8192
    1820:      	csel	x8, x1, x8, lo
    1824:      	lsl	x1, x8, #1
    1828:      	b	0x1830 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x184>
    182c:      	mov	w1, #0x1                ; =1
    1830:      	add	x0, x27, #0x1d0
    1834:      	add	x2, x27, #0x1c0
    1838:      	bl	0x1838 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x18c>
		0000000000001838:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    183c:      	mov	x5, #0x11eb             ; =4587
    1840:      	movk	x5, #0x1331, lsl #16
    1844:      	movk	x5, #0x49bb, lsl #32
    1848:      	movk	x5, #0x94d0, lsl #48
    184c:      	mov	x6, #0xe5b9             ; =58809
    1850:      	movk	x6, #0x1ce4, lsl #16
    1854:      	movk	x6, #0x476d, lsl #32
    1858:      	movk	x6, #0xbf58, lsl #48
    185c:      	orr	x8, x24, x19, lsl #1
    1860:      	ldrb	w9, [sp, #0x208]
    1864:      	tbz	w9, #0x0, 0x18e4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x238>
    1868:      	mov	x11, #0x0               ; =0
    186c:      	ldr	x9, [sp, #0x38]
    1870:      	add	x9, x19, x9
    1874:      	ldr	x10, [sp, #0x210]
    1878:      	cbz	x10, 0x1910 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x264>
    187c:      	udiv	x12, x11, x10
    1880:      	msub	x12, x12, x10, x11
    1884:      	ldr	x13, [sp, #0x220]
    1888:      	mov	x14, x10
    188c:      	mov	x11, x10
    1890:      	b	0x18b0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x204>
    1894:      	cmp	x11, x10
    1898:      	csel	x11, x12, x11, eq
    189c:      	add	x15, x12, #0x1
    18a0:      	cmp	x15, x10
    18a4:      	csinc	x12, xzr, x12, hs
    18a8:      	subs	x14, x14, #0x1
    18ac:      	b.eq	0x1914 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x268>
    18b0:      	madd	x15, x12, x25, x13
    18b4:      	ldr	w16, [x15]
    18b8:      	cmp	w16, #0x1
    18bc:      	b.eq	0x1894 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1e8>
    18c0:      	cmp	w16, #0x2
    18c4:      	b.ne	0x1960 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x2b4>
    18c8:      	ldr	x16, [x15, #0x8]
    18cc:      	cmp	x16, x8
    18d0:      	b.ne	0x189c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1f0>
    18d4:      	ldr	x10, [x15, #0x10]
    18d8:      	str	w26, [x15]
    18dc:      	str	x9, [x15, #0x10]
    18e0:      	b	0x1988 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x2dc>
    18e4:      	ldr	x9, [sp, #0x200]
    18e8:      	eor	x9, x9, x8
    18ec:      	eor	x9, x9, x9, lsr #30
    18f0:      	mul	x9, x9, x6
    18f4:      	eor	x9, x9, x9, lsr #27
    18f8:      	mul	x9, x9, x5
    18fc:      	eor	x11, x9, x9, lsr #31
    1900:      	ldr	x9, [sp, #0x38]
    1904:      	add	x9, x19, x9
    1908:      	ldr	x10, [sp, #0x210]
    190c:      	cbnz	x10, 0x187c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1d0>
    1910:      	mov	x11, #0x0               ; =0
    1914:      	cmp	x11, x10
    1918:      	b.hs	0x17a8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xfc>
    191c:      	ldr	x10, [sp, #0x228]
    1920:      	lsr	x12, x10, #14
    1924:      	cbnz	x12, 0x17a8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xfc>
    1928:      	add	x10, x10, #0x1
    192c:      	str	x10, [sp, #0x228]
    1930:      	ldr	x10, [sp, #0x220]
    1934:      	madd	x11, x11, x25, x10
    1938:      	ldr	w12, [x11]
    193c:      	cmp	w12, #0x1
    1940:      	b.ne	0x1974 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x2c8>
    1944:      	ldr	x10, [sp, #0x230]
    1948:      	subs	x10, x10, #0x1
    194c:      	csel	x10, xzr, x10, lo
    1950:      	str	x10, [sp, #0x230]
    1954:      	str	w26, [x11]
    1958:      	stp	x8, x9, [x11, #0x8]
    195c:      	b	0x19a8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x2fc>
    1960:      	cmp	x11, x10
    1964:      	csel	x11, x12, x11, eq
    1968:      	cmp	x11, x10
    196c:      	b.lo	0x191c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x270>
    1970:      	b	0x17a8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xfc>
    1974:      	ldp	x13, x10, [x11, #0x8]
    1978:      	str	w26, [x11]
    197c:      	stp	x8, x9, [x11, #0x8]
    1980:      	cbz	w12, 0x19a8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x2fc>
    1984:      	mov	x8, x13
    1988:      	stp	x24, x8, [sp, #0x40]
    198c:      	str	x10, [sp, #0x50]
    1990:      	ubfx	x9, x24, #32, #8
    1994:      	ldur	q0, [x20, #0x8]
    1998:      	stur	q0, [x27, #0x18]
    199c:      	mov	w8, #0x1                ; =1
    19a0:      	tbnz	w9, #0x0, 0x17bc <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x110>
    19a4:      	b	0x17c0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x114>
    19a8:      	stp	xzr, xzr, [sp, #0x40]
    19ac:      	str	xzr, [sp, #0x50]
    19b0:      	ldr	x8, [sp, #0x238]
    19b4:      	mul	x8, x8, x28
    19b8:      	str	x8, [sp, #0x238]
    19bc:      	add	x19, x19, #0x1
    19c0:      	cmp	x19, x21
    19c4:      	b.ne	0x17e4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x138>
    19c8:      	ldr	x9, [sp, #0x18]
    19cc:      	cbz	x9, 0x1fa8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x8fc>
    19d0:      	lsl	x9, x23, #1
    19d4:      	cmp	x23, #0x0
    19d8:      	csinc	x25, x9, xzr, ne
    19dc:      	cmp	x22, #0x1
    19e0:      	csel	x24, x21, xzr, eq
    19e4:      	add	x28, sp, #0x40
    19e8:      	cmp	x22, #0x5
    19ec:      	b.ne	0x204c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x9a0>
    19f0:      	mov	x19, #0x0               ; =0
    19f4:      	sub	x8, x21, x21, lsr #1
    19f8:      	cmp	x8, #0x1
    19fc:      	csinc	x20, x8, xzr, hi
    1a00:      	mov	w22, #0x83              ; =131
    1a04:      	mov	w23, #0x1               ; =1
    1a08:      	mov	w24, #0x18              ; =24
    1a0c:      	mov	w25, #0x2               ; =2
    1a10:      	mov	w26, #0x4309            ; =17161
    1a14:      	b	0x1a2c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x380>
    1a18:      	ldr	x19, [sp, #0x30]
    1a1c:      	mov	w26, #0x4309            ; =17161
    1a20:      	ldr	x8, [sp, #0x18]
    1a24:      	cmp	x19, x8
    1a28:      	b.eq	0x1fa8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x8fc>
    1a2c:      	ldr	x8, [sp, #0x210]
    1a30:      	cbz	x21, 0x1c10 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x564>
    1a34:      	mov	x9, #0x0                ; =0
    1a38:      	ldr	x10, [sp, #0x200]
    1a3c:      	ldrb	w11, [sp, #0x208]
    1a40:      	ldr	x12, [sp, #0x228]
    1a44:      	ldr	x13, [sp, #0x220]
    1a48:      	ldr	x14, [sp, #0x230]
    1a4c:      	b	0x1a70 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x3c4>
    1a50:      	str	w23, [sp, #0x90]
    1a54:      	str	xzr, [sp, #0x98]
    1a58:      	mul	x15, x15, x22
    1a5c:      	strb	wzr, [sp, #0xa0]
    1a60:      	str	x15, [sp, #0x238]
    1a64:      	add	x9, x9, #0x1
    1a68:      	cmp	x9, x20
    1a6c:      	b.eq	0x1c14 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x568>
    1a70:      	orr	x15, x23, x9, lsl #2
    1a74:      	str	x15, [sp, #0x258]
    1a78:      	cbz	x12, 0x1b6c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x4c0>
    1a7c:      	tbz	w11, #0x0, 0x1a8c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x3e0>
    1a80:      	mov	x16, #0x0               ; =0
    1a84:      	cbnz	x8, 0x1aa8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x3fc>
    1a88:      	b	0x1b6c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x4c0>
    1a8c:      	eor	x16, x10, x15
    1a90:      	eor	x16, x16, x16, lsr #30
    1a94:      	mul	x16, x16, x6
    1a98:      	eor	x16, x16, x16, lsr #27
    1a9c:      	mul	x16, x16, x5
    1aa0:      	eor	x16, x16, x16, lsr #31
    1aa4:      	cbz	x8, 0x1b6c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x4c0>
    1aa8:      	udiv	x17, x16, x8
    1aac:      	msub	x16, x17, x8, x16
    1ab0:      	mov	x17, x8
    1ab4:      	b	0x1acc <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x420>
    1ab8:      	add	x0, x16, #0x1
    1abc:      	cmp	x0, x8
    1ac0:      	csinc	x16, xzr, x16, hs
    1ac4:      	subs	x17, x17, #0x1
    1ac8:      	b.eq	0x1b6c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x4c0>
    1acc:      	madd	x0, x16, x24, x13
    1ad0:      	ldr	w1, [x0]
    1ad4:      	cmp	w1, #0x1
    1ad8:      	b.eq	0x1ab8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x40c>
    1adc:      	cmp	w1, #0x2
    1ae0:      	b.ne	0x1b6c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x4c0>
    1ae4:      	ldr	x1, [x0, #0x8]
    1ae8:      	cmp	x1, x15
    1aec:      	b.ne	0x1ab8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x40c>
    1af0:      	ldr	x16, [x0, #0x10]
    1af4:      	str	w23, [x0]
    1af8:      	sub	x12, x12, #0x1
    1afc:      	stp	xzr, xzr, [x0, #0x8]
    1b00:      	adds	x14, x14, #0x1
    1b04:      	csinv	x14, x14, xzr, lo
    1b08:      	str	x12, [sp, #0x228]
    1b0c:      	str	x14, [sp, #0x230]
    1b10:      	str	w23, [sp, #0x68]
    1b14:      	stp	x15, x16, [sp, #0x70]
    1b18:      	ldur	q0, [x28, #0x30]
    1b1c:      	stur	q0, [x27, #0x40]
    1b20:      	ldr	x15, [sp, #0x238]
    1b24:      	ldp	x16, x17, [sp, #0x80]
    1b28:      	madd	x15, x15, x22, x16
    1b2c:      	madd	x15, x15, x22, x17
    1b30:      	add	x15, x15, #0x83
    1b34:      	str	x15, [sp, #0x238]
    1b38:      	ldrb	w16, [sp, #0x208]
    1b3c:      	tbnz	w16, #0x0, 0x1b88 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x4dc>
    1b40:      	ldr	x16, [sp, #0x200]
    1b44:      	ldr	x17, [sp, #0x258]
    1b48:      	eor	x16, x17, x16
    1b4c:      	eor	x16, x16, x16, lsr #30
    1b50:      	mul	x16, x16, x6
    1b54:      	eor	x16, x16, x16, lsr #27
    1b58:      	mul	x16, x16, x5
    1b5c:      	eor	x16, x16, x16, lsr #31
    1b60:      	ldr	x1, [sp, #0x210]
    1b64:      	cbnz	x1, 0x1b94 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x4e8>
    1b68:      	b	0x1a50 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x3a4>
    1b6c:      	str	wzr, [sp, #0x68]
    1b70:      	stp	xzr, xzr, [x28, #0x30]
    1b74:      	ldr	x15, [sp, #0x238]
    1b78:      	mul	x15, x15, x22
    1b7c:      	str	x15, [sp, #0x238]
    1b80:      	ldrb	w16, [sp, #0x208]
    1b84:      	tbz	w16, #0x0, 0x1b40 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x494>
    1b88:      	mov	x16, #0x0               ; =0
    1b8c:      	ldr	x1, [sp, #0x210]
    1b90:      	cbz	x1, 0x1a50 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x3a4>
    1b94:      	udiv	x17, x16, x1
    1b98:      	msub	x16, x17, x1, x16
    1b9c:      	ldr	x17, [sp, #0x220]
    1ba0:      	ldr	x0, [sp, #0x258]
    1ba4:      	mov	x2, x1
    1ba8:      	b	0x1bc0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x514>
    1bac:      	add	x3, x16, #0x1
    1bb0:      	cmp	x3, x1
    1bb4:      	csinc	x16, xzr, x16, hs
    1bb8:      	subs	x2, x2, #0x1
    1bbc:      	b.eq	0x1a50 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x3a4>
    1bc0:      	madd	x3, x16, x24, x17
    1bc4:      	ldr	w4, [x3]
    1bc8:      	cmp	w4, #0x1
    1bcc:      	b.eq	0x1bac <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x500>
    1bd0:      	cmp	w4, #0x2
    1bd4:      	b.ne	0x1a50 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x3a4>
    1bd8:      	ldr	x4, [x3, #0x8]
    1bdc:      	cmp	x4, x0
    1be0:      	b.ne	0x1bac <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x500>
    1be4:      	ldr	x16, [x3, #0x10]
    1be8:      	str	wzr, [sp, #0x90]
    1bec:      	str	x16, [sp, #0x98]
    1bf0:      	strb	wzr, [sp, #0xa0]
    1bf4:      	madd	x15, x15, x26, x16
    1bf8:      	add	x15, x15, #0x83
    1bfc:      	str	x15, [sp, #0x238]
    1c00:      	add	x9, x9, #0x1
    1c04:      	cmp	x9, x20
    1c08:      	b.ne	0x1a70 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x3c4>
    1c0c:      	b	0x1c14 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x568>
    1c10:      	mov	x1, x8
    1c14:      	add	x0, x27, #0x1d0
    1c18:      	add	x2, x27, #0x1c0
    1c1c:      	bl	0x1c1c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x570>
		0000000000001c1c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    1c20:      	str	w0, [sp, #0xa8]
    1c24:      	strb	w1, [sp, #0xac]
    1c28:      	strb	w2, [sp, #0xad]
    1c2c:      	cmp	w0, #0x0
    1c30:      	ldr	x8, [sp, #0x238]
    1c34:      	mul	x8, x8, x22
    1c38:      	cinc	x8, x8, eq
    1c3c:      	str	x8, [sp, #0x238]
    1c40:      	cbz	x21, 0x1f78 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x8cc>
    1c44:      	mov	x9, #0x0                ; =0
    1c48:      	ldr	x10, [sp, #0x200]
    1c4c:      	ldrb	w11, [sp, #0x208]
    1c50:      	ldr	x12, [sp, #0x210]
    1c54:      	ldr	x13, [sp, #0x220]
    1c58:      	mov	x5, #0x11eb             ; =4587
    1c5c:      	movk	x5, #0x1331, lsl #16
    1c60:      	movk	x5, #0x49bb, lsl #32
    1c64:      	movk	x5, #0x94d0, lsl #48
    1c68:      	mov	x6, #0xe5b9             ; =58809
    1c6c:      	movk	x6, #0x1ce4, lsl #16
    1c70:      	movk	x6, #0x476d, lsl #32
    1c74:      	movk	x6, #0xbf58, lsl #48
    1c78:      	b	0x1c9c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x5f0>
    1c7c:      	str	w23, [sp, #0xb0]
    1c80:      	str	xzr, [sp, #0xb8]
    1c84:      	mul	x8, x8, x22
    1c88:      	strb	wzr, [sp, #0xc0]
    1c8c:      	str	x8, [sp, #0x238]
    1c90:      	add	x9, x9, #0x1
    1c94:      	cmp	x9, x21
    1c98:      	b.eq	0x1d40 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x694>
    1c9c:      	orr	x14, x23, x9, lsl #1
    1ca0:      	str	x14, [sp, #0x260]
    1ca4:      	tbz	w11, #0x0, 0x1cb4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x608>
    1ca8:      	mov	x15, #0x0               ; =0
    1cac:      	cbnz	x12, 0x1cd0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x624>
    1cb0:      	b	0x1c7c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x5d0>
    1cb4:      	eor	x15, x10, x14
    1cb8:      	eor	x15, x15, x15, lsr #30
    1cbc:      	mul	x15, x15, x6
    1cc0:      	eor	x15, x15, x15, lsr #27
    1cc4:      	mul	x15, x15, x5
    1cc8:      	eor	x15, x15, x15, lsr #31
    1ccc:      	cbz	x12, 0x1c7c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x5d0>
    1cd0:      	udiv	x16, x15, x12
    1cd4:      	msub	x15, x16, x12, x15
    1cd8:      	mov	x16, x12
    1cdc:      	b	0x1cf4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x648>
    1ce0:      	add	x17, x15, #0x1
    1ce4:      	cmp	x17, x12
    1ce8:      	csinc	x15, xzr, x15, hs
    1cec:      	subs	x16, x16, #0x1
    1cf0:      	b.eq	0x1c7c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x5d0>
    1cf4:      	madd	x17, x15, x24, x13
    1cf8:      	ldr	w0, [x17]
    1cfc:      	cmp	w0, #0x1
    1d00:      	b.eq	0x1ce0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x634>
    1d04:      	cmp	w0, #0x2
    1d08:      	b.ne	0x1c7c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x5d0>
    1d0c:      	ldr	x0, [x17, #0x8]
    1d10:      	cmp	x0, x14
    1d14:      	b.ne	0x1ce0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x634>
    1d18:      	ldr	x14, [x17, #0x10]
    1d1c:      	str	wzr, [sp, #0xb0]
    1d20:      	str	x14, [sp, #0xb8]
    1d24:      	strb	wzr, [sp, #0xc0]
    1d28:      	madd	x8, x8, x26, x14
    1d2c:      	add	x8, x8, #0x83
    1d30:      	str	x8, [sp, #0x238]
    1d34:      	add	x9, x9, #0x1
    1d38:      	cmp	x9, x21
    1d3c:      	b.ne	0x1c9c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x5f0>
    1d40:      	mov	x26, #0x0               ; =0
    1d44:      	add	x19, x19, #0x1
    1d48:      	ldr	x8, [sp, #0x38]
    1d4c:      	str	x19, [sp, #0x30]
    1d50:      	madd	x19, x19, x21, x8
    1d54:      	b	0x1d94 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x6e8>
    1d58:      	stp	x23, x8, [sp, #0xc8]
    1d5c:      	strb	w23, [sp, #0xcc]
    1d60:      	str	x9, [sp, #0xd8]
    1d64:      	ldur	q0, [x28, #0x90]
    1d68:      	stur	q0, [x27, #0xa0]
    1d6c:      	mov	w8, #0x2                ; =2
    1d70:      	ldr	x9, [sp, #0x238]
    1d74:      	madd	x8, x9, x22, x8
    1d78:      	ldp	x9, x10, [sp, #0xe0]
    1d7c:      	add	x8, x9, x8
    1d80:      	madd	x8, x8, x22, x10
    1d84:      	str	x8, [sp, #0x238]
    1d88:      	add	x26, x26, #0x1
    1d8c:      	cmp	x26, x20
    1d90:      	b.eq	0x1a18 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x36c>
    1d94:      	ldr	x1, [sp, #0x210]
    1d98:      	ldr	x8, [sp, #0x228]
    1d9c:      	ldr	x9, [sp, #0x230]
    1da0:      	adds	x9, x8, x9
    1da4:      	csinv	x10, x9, xzr, lo
    1da8:      	sub	x9, x1, x1, lsr #2
    1dac:      	lsr	x11, x1, #14
    1db0:      	cmp	x11, #0x0
    1db4:      	ccmp	x10, x9, #0x0, eq
    1db8:      	b.lo	0x1e0c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x760>
    1dbc:      	cmp	x8, x9, lsr #1
    1dc0:      	b.lo	0x1de0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x734>
    1dc4:      	cbz	x1, 0x1ddc <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x730>
    1dc8:      	cmp	x1, #0x2, lsl #12       ; =0x2000
    1dcc:      	mov	w8, #0x2000             ; =8192
    1dd0:      	csel	x8, x1, x8, lo
    1dd4:      	lsl	x1, x8, #1
    1dd8:      	b	0x1de0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x734>
    1ddc:      	mov	w1, #0x1                ; =1
    1de0:      	add	x0, x27, #0x1d0
    1de4:      	add	x2, x27, #0x1c0
    1de8:      	bl	0x1de8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x73c>
		0000000000001de8:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    1dec:      	mov	x5, #0x11eb             ; =4587
    1df0:      	movk	x5, #0x1331, lsl #16
    1df4:      	movk	x5, #0x49bb, lsl #32
    1df8:      	movk	x5, #0x94d0, lsl #48
    1dfc:      	mov	x6, #0xe5b9             ; =58809
    1e00:      	movk	x6, #0x1ce4, lsl #16
    1e04:      	movk	x6, #0x476d, lsl #32
    1e08:      	movk	x6, #0xbf58, lsl #48
    1e0c:      	orr	x8, x23, x26, lsl #2
    1e10:      	ldrb	w9, [sp, #0x208]
    1e14:      	tbz	w9, #0x0, 0x1e90 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x7e4>
    1e18:      	mov	x11, #0x0               ; =0
    1e1c:      	add	x9, x19, x26, lsl #1
    1e20:      	ldr	x10, [sp, #0x210]
    1e24:      	cbz	x10, 0x1eb8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x80c>
    1e28:      	udiv	x12, x11, x10
    1e2c:      	msub	x12, x12, x10, x11
    1e30:      	ldr	x13, [sp, #0x220]
    1e34:      	mov	x14, x10
    1e38:      	mov	x11, x10
    1e3c:      	b	0x1e5c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x7b0>
    1e40:      	cmp	x11, x10
    1e44:      	csel	x11, x12, x11, eq
    1e48:      	add	x15, x12, #0x1
    1e4c:      	cmp	x15, x10
    1e50:      	csinc	x12, xzr, x12, hs
    1e54:      	subs	x14, x14, #0x1
    1e58:      	b.eq	0x1ebc <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x810>
    1e5c:      	madd	x15, x12, x24, x13
    1e60:      	ldr	w16, [x15]
    1e64:      	cmp	w16, #0x1
    1e68:      	b.eq	0x1e40 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x794>
    1e6c:      	cmp	w16, #0x2
    1e70:      	b.ne	0x1f08 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x85c>
    1e74:      	ldr	x16, [x15, #0x8]
    1e78:      	cmp	x16, x8
    1e7c:      	b.ne	0x1e48 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x79c>
    1e80:      	ldr	x10, [x15, #0x10]
    1e84:      	str	w25, [x15]
    1e88:      	str	x9, [x15, #0x10]
    1e8c:      	b	0x1f30 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x884>
    1e90:      	ldr	x9, [sp, #0x200]
    1e94:      	eor	x9, x9, x8
    1e98:      	eor	x9, x9, x9, lsr #30
    1e9c:      	mul	x9, x9, x6
    1ea0:      	eor	x9, x9, x9, lsr #27
    1ea4:      	mul	x9, x9, x5
    1ea8:      	eor	x11, x9, x9, lsr #31
    1eac:      	add	x9, x19, x26, lsl #1
    1eb0:      	ldr	x10, [sp, #0x210]
    1eb4:      	cbnz	x10, 0x1e28 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x77c>
    1eb8:      	mov	x11, #0x0               ; =0
    1ebc:      	cmp	x11, x10
    1ec0:      	b.hs	0x1d58 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x6ac>
    1ec4:      	ldr	x10, [sp, #0x228]
    1ec8:      	cmp	x10, #0x4, lsl #12      ; =0x4000
    1ecc:      	b.hs	0x1d58 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x6ac>
    1ed0:      	add	x10, x10, #0x1
    1ed4:      	str	x10, [sp, #0x228]
    1ed8:      	ldr	x10, [sp, #0x220]
    1edc:      	madd	x11, x11, x24, x10
    1ee0:      	ldr	w12, [x11]
    1ee4:      	cmp	w12, #0x1
    1ee8:      	b.ne	0x1f1c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x870>
    1eec:      	ldr	x10, [sp, #0x230]
    1ef0:      	subs	x10, x10, #0x1
    1ef4:      	csel	x10, xzr, x10, lo
    1ef8:      	str	x10, [sp, #0x230]
    1efc:      	str	w25, [x11]
    1f00:      	stp	x8, x9, [x11, #0x8]
    1f04:      	b	0x1f54 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x8a8>
    1f08:      	cmp	x11, x10
    1f0c:      	csel	x11, x12, x11, eq
    1f10:      	cmp	x11, x10
    1f14:      	b.lo	0x1ec4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x818>
    1f18:      	b	0x1d58 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x6ac>
    1f1c:      	ldp	x13, x10, [x11, #0x8]
    1f20:      	str	w25, [x11]
    1f24:      	stp	x8, x9, [x11, #0x8]
    1f28:      	cbz	w12, 0x1f54 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x8a8>
    1f2c:      	mov	x8, x13
    1f30:      	stp	x23, x8, [sp, #0xc8]
    1f34:      	str	x10, [sp, #0xd8]
    1f38:      	ubfx	x9, x23, #32, #8
    1f3c:      	ldur	q0, [x28, #0x90]
    1f40:      	stur	q0, [x27, #0xa0]
    1f44:      	mov	w8, #0x1                ; =1
    1f48:      	cmp	w9, #0x1
    1f4c:      	b.eq	0x1d6c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x6c0>
    1f50:      	b	0x1d70 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x6c4>
    1f54:      	stp	xzr, xzr, [x27, #0x88]
    1f58:      	stur	xzr, [x27, #0x98]
    1f5c:      	ldr	x8, [sp, #0x238]
    1f60:      	mul	x8, x8, x22
    1f64:      	str	x8, [sp, #0x238]
    1f68:      	add	x26, x26, #0x1
    1f6c:      	cmp	x26, x20
    1f70:      	b.ne	0x1d94 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x6e8>
    1f74:      	b	0x1a18 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x36c>
    1f78:      	add	x19, x19, #0x1
    1f7c:      	mov	x5, #0x11eb             ; =4587
    1f80:      	movk	x5, #0x1331, lsl #16
    1f84:      	movk	x5, #0x49bb, lsl #32
    1f88:      	movk	x5, #0x94d0, lsl #48
    1f8c:      	mov	x6, #0xe5b9             ; =58809
    1f90:      	movk	x6, #0x1ce4, lsl #16
    1f94:      	movk	x6, #0x476d, lsl #32
    1f98:      	movk	x6, #0xbf58, lsl #48
    1f9c:      	ldr	x8, [sp, #0x18]
    1fa0:      	cmp	x19, x8
    1fa4:      	b.ne	0x1a2c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x380>
    1fa8:      	add	x8, sp, #0x40
    1fac:      	add	x8, x8, #0x178
    1fb0:      	ldp	q0, q1, [x27, #0x1d0]
    1fb4:      	stp	q0, q1, [x8]
    1fb8:      	ldr	x8, [x27, #0x1f0]
    1fbc:      	str	x8, [sp, #0x1d8]
    1fc0:      	ldp	x13, x8, [sp, #0x1b8]
    1fc4:      	ldr	x0, [sp, #0x1c8]
    1fc8:      	cbz	x13, 0x292c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1280>
    1fcc:      	ldr	x9, [sp, #0x240]
    1fd0:      	ldr	x11, [sp, #0x248]
    1fd4:      	ldr	x10, [sp, #0x250]
    1fd8:      	ands	x14, x13, #0x3
    1fdc:      	b.eq	0x2920 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1274>
    1fe0:      	mov	w12, #0x18              ; =24
    1fe4:      	madd	x12, x13, x12, x0
    1fe8:      	sub	x15, x12, #0x8
    1fec:      	mov	w16, #0x83              ; =131
    1ff0:      	mov	x12, x13
    1ff4:      	b	0x2008 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x95c>
    1ff8:      	sub	x15, x15, #0x18
    1ffc:      	sub	x12, x12, #0x1
    2000:      	sub	x14, x14, #0x1
    2004:      	cbz	x14, 0x2924 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1278>
    2008:      	ldur	w17, [x15, #-0x10]
    200c:      	cmp	w17, #0x2
    2010:      	b.ne	0x1ff8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x94c>
    2014:      	ldp	x1, x17, [x15, #-0x8]
    2018:      	madd	x17, x1, x16, x17
    201c:      	add	x9, x17, x9
    2020:      	str	x9, [sp, #0x240]
    2024:      	eor	x17, x17, x17, lsr #30
    2028:      	mul	x17, x17, x6
    202c:      	eor	x17, x17, x17, lsr #27
    2030:      	mul	x17, x17, x5
    2034:      	eor	x11, x11, x17, lsr #31
    2038:      	eor	x11, x11, x17
    203c:      	str	x11, [sp, #0x248]
    2040:      	add	x10, x10, #0x1
    2044:      	str	x10, [sp, #0x250]
    2048:      	b	0x1ff8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x94c>
    204c:      	mov	x3, #0x0                ; =0
    2050:      	sub	x4, x22, #0x9
    2054:      	mov	w19, #0x83              ; =131
    2058:      	mov	w20, #0x1               ; =1
    205c:      	mov	w23, #0x18              ; =24
    2060:      	str	x4, [sp, #0x20]
    2064:      	str	x25, [sp, #0x10]
    2068:      	b	0x2078 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x9cc>
    206c:      	ldp	x25, x9, [sp, #0x10]
    2070:      	cmp	x3, x9
    2074:      	b.eq	0x1fa8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x8fc>
    2078:      	cmp	x22, #0x4
    207c:      	b.eq	0x209c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x9f0>
    2080:      	cmp	x22, #0x9
    2084:      	b.eq	0x209c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x9f0>
    2088:      	cmp	x22, #0xa
    208c:      	b.ne	0x2148 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xa9c>
    2090:      	mov	x9, #0x1                ; =1
    2094:      	madd	x8, x8, x19, x9
    2098:      	b	0x2134 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xa88>
    209c:      	cmp	x25, #0x4, lsl #12      ; =0x4000
    20a0:      	b.ls	0x20b4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xa08>
    20a4:      	mov	w2, #0x0                ; =0
    20a8:      	mov	w1, #0x0                ; =0
    20ac:      	mov	w0, #0x1                ; =1
    20b0:      	b	0x2110 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xa64>
    20b4:      	ldr	x9, [sp, #0x210]
    20b8:      	cmp	x25, x9
    20bc:      	b.ls	0x2104 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xa58>
    20c0:      	add	x0, x27, #0x1d0
    20c4:      	add	x2, x27, #0x1c0
    20c8:      	mov	x1, x25
    20cc:      	mov	x26, x3
    20d0:      	bl	0x20d0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xa24>
		00000000000020d0:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    20d4:      	ldr	x4, [sp, #0x20]
    20d8:      	mov	x3, x26
    20dc:      	mov	x6, #0xe5b9             ; =58809
    20e0:      	movk	x6, #0x1ce4, lsl #16
    20e4:      	movk	x6, #0x476d, lsl #32
    20e8:      	movk	x6, #0xbf58, lsl #48
    20ec:      	mov	x5, #0x11eb             ; =4587
    20f0:      	movk	x5, #0x1331, lsl #16
    20f4:      	movk	x5, #0x49bb, lsl #32
    20f8:      	movk	x5, #0x94d0, lsl #48
    20fc:      	ldr	x8, [sp, #0x238]
    2100:      	b	0x2110 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xa64>
    2104:      	mov	w2, #0x0                ; =0
    2108:      	mov	w1, #0x0                ; =0
    210c:      	mov	w0, #0x0                ; =0
    2110:      	str	w0, [sp, #0xf0]
    2114:      	strb	w1, [sp, #0xf4]
    2118:      	strb	w2, [sp, #0xf5]
    211c:      	cmp	w0, #0x0
    2120:      	mul	x8, x8, x19
    2124:      	cinc	x8, x8, eq
    2128:      	str	x8, [sp, #0x238]
    212c:      	cmp	x4, #0x2
    2130:      	b.hs	0x2148 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xa9c>
    2134:      	ldr	x9, [sp, #0x210]
    2138:      	cmp	x9, x25
    213c:      	mul	x8, x8, x19
    2140:      	cinc	x8, x8, hs
    2144:      	str	x8, [sp, #0x238]
    2148:      	add	x3, x3, #0x1
    214c:      	cbz	x21, 0x206c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x9c0>
    2150:      	mov	x25, #0x0               ; =0
    2154:      	ldr	x9, [sp, #0x38]
    2158:      	madd	x0, x3, x21, x9
    215c:      	stp	x0, x3, [sp, #0x28]
    2160:      	b	0x2184 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xad8>
    2164:      	str	w20, [sp, #0xf8]
    2168:      	str	xzr, [sp, #0x100]
    216c:      	mul	x8, x8, x19
    2170:      	strb	wzr, [sp, #0x108]
    2174:      	str	x8, [sp, #0x238]
    2178:      	add	x25, x25, #0x1
    217c:      	cmp	x25, x21
    2180:      	b.eq	0x206c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x9c0>
    2184:      	add	x9, x25, x24
    2188:      	orr	x26, x20, x9, lsl #1
    218c:      	str	x26, [sp, #0x268]
    2190:      	cmp	x22, #0x3
    2194:      	b.gt	0x21d0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xb24>
    2198:      	cmp	x22, #0x2
    219c:      	b.lo	0x21e8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xb3c>
    21a0:      	b.eq	0x2290 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xbe4>
    21a4:      	cmp	x22, #0x3
    21a8:      	b.ne	0x2178 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xacc>
    21ac:      	ldr	x11, [sp, #0x200]
    21b0:      	ldrb	w12, [sp, #0x208]
    21b4:      	ldr	x9, [sp, #0x228]
    21b8:      	cbz	x9, 0x2488 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xddc>
    21bc:      	tbz	w12, #0x0, 0x23ac <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xd00>
    21c0:      	mov	x13, #0x0               ; =0
    21c4:      	ldr	x10, [sp, #0x210]
    21c8:      	cbnz	x10, 0x23cc <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xd20>
    21cc:      	b	0x2488 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xddc>
    21d0:      	cmp	x4, #0x2
    21d4:      	b.lo	0x21e8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xb3c>
    21d8:      	cmp	x22, #0x7
    21dc:      	b.eq	0x22d8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xc2c>
    21e0:      	cmp	x22, #0x4
    21e4:      	b.ne	0x2178 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xacc>
    21e8:      	ldrb	w9, [sp, #0x208]
    21ec:      	tbz	w9, #0x0, 0x2200 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xb54>
    21f0:      	mov	x10, #0x0               ; =0
    21f4:      	ldr	x9, [sp, #0x210]
    21f8:      	cbnz	x9, 0x2224 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xb78>
    21fc:      	b	0x2164 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xab8>
    2200:      	ldr	x9, [sp, #0x200]
    2204:      	eor	x9, x9, x26
    2208:      	eor	x9, x9, x9, lsr #30
    220c:      	mul	x9, x9, x6
    2210:      	eor	x9, x9, x9, lsr #27
    2214:      	mul	x9, x9, x5
    2218:      	eor	x10, x9, x9, lsr #31
    221c:      	ldr	x9, [sp, #0x210]
    2220:      	cbz	x9, 0x2164 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xab8>
    2224:      	udiv	x11, x10, x9
    2228:      	msub	x10, x11, x9, x10
    222c:      	ldr	x11, [sp, #0x220]
    2230:      	mov	x12, x9
    2234:      	b	0x224c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xba0>
    2238:      	add	x13, x10, #0x1
    223c:      	cmp	x13, x9
    2240:      	csinc	x10, xzr, x10, hs
    2244:      	subs	x12, x12, #0x1
    2248:      	b.eq	0x2164 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xab8>
    224c:      	madd	x13, x10, x23, x11
    2250:      	ldr	w14, [x13]
    2254:      	cmp	w14, #0x1
    2258:      	b.eq	0x2238 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xb8c>
    225c:      	cmp	w14, #0x2
    2260:      	b.ne	0x2164 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xab8>
    2264:      	ldr	x14, [x13, #0x8]
    2268:      	cmp	x14, x26
    226c:      	b.ne	0x2238 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xb8c>
    2270:      	ldr	x9, [x13, #0x10]
    2274:      	str	wzr, [sp, #0xf8]
    2278:      	str	x9, [sp, #0x100]
    227c:      	strb	wzr, [sp, #0x108]
    2280:      	mov	w10, #0x4309            ; =17161
    2284:      	madd	x8, x8, x10, x9
    2288:      	add	x8, x8, #0x83
    228c:      	b	0x2174 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xac8>
    2290:      	ldr	x1, [sp, #0x210]
    2294:      	ldr	x8, [sp, #0x228]
    2298:      	ldr	x9, [sp, #0x230]
    229c:      	adds	x9, x8, x9
    22a0:      	csinv	x9, x9, xzr, lo
    22a4:      	lsr	x10, x1, #14
    22a8:      	cbnz	x10, 0x2794 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x10e8>
    22ac:      	sub	x10, x1, x1, lsr #2
    22b0:      	cmp	x9, x10
    22b4:      	b.lo	0x2794 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x10e8>
    22b8:      	cmp	x8, x10, lsr #1
    22bc:      	b.lo	0x2760 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x10b4>
    22c0:      	cbz	x1, 0x275c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x10b0>
    22c4:      	cmp	x1, #0x2, lsl #12       ; =0x2000
    22c8:      	mov	w8, #0x2000             ; =8192
    22cc:      	csel	x8, x1, x8, lo
    22d0:      	lsl	x1, x8, #1
    22d4:      	b	0x2760 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x10b4>
    22d8:      	ldrb	w9, [sp, #0x208]
    22dc:      	tbz	w9, #0x0, 0x22f0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xc44>
    22e0:      	mov	x11, #0x0               ; =0
    22e4:      	ldr	x9, [sp, #0x210]
    22e8:      	cbnz	x9, 0x2314 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xc68>
    22ec:      	b	0x2398 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xcec>
    22f0:      	ldr	x9, [sp, #0x200]
    22f4:      	eor	x9, x9, x26
    22f8:      	eor	x9, x9, x9, lsr #30
    22fc:      	mul	x9, x9, x6
    2300:      	eor	x9, x9, x9, lsr #27
    2304:      	mul	x9, x9, x5
    2308:      	eor	x11, x9, x9, lsr #31
    230c:      	ldr	x9, [sp, #0x210]
    2310:      	cbz	x9, 0x2398 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xcec>
    2314:      	mov	x10, #0x0               ; =0
    2318:      	udiv	x12, x11, x9
    231c:      	msub	x11, x12, x9, x11
    2320:      	sub	x12, x9, x11
    2324:      	neg	x13, x12
    2328:      	ldr	x14, [sp, #0x220]
    232c:      	b	0x233c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xc90>
    2330:      	add	x10, x10, #0x1
    2334:      	cmp	x9, x10
    2338:      	b.eq	0x2398 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xcec>
    233c:      	cmp	x10, x12
    2340:      	csel	x15, x11, x13, lo
    2344:      	add	x15, x15, x10
    2348:      	madd	x15, x15, x23, x14
    234c:      	ldr	w16, [x15]
    2350:      	cmp	w16, #0x1
    2354:      	b.eq	0x2330 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xc84>
    2358:      	cmp	w16, #0x2
    235c:      	b.ne	0x2398 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xcec>
    2360:      	ldr	x16, [x15, #0x8]
    2364:      	cmp	x16, x26
    2368:      	b.ne	0x2330 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xc84>
    236c:      	ldr	x8, [x15, #0x10]
    2370:      	add	x9, x8, #0x1
    2374:      	str	x9, [x15, #0x10]
    2378:      	str	wzr, [sp, #0x1a0]
    237c:      	str	x9, [sp, #0x1a8]
    2380:      	strb	wzr, [sp, #0x1b0]
    2384:      	ldr	x9, [sp, #0x238]
    2388:      	mov	w10, #0x4309            ; =17161
    238c:      	madd	x8, x9, x10, x8
    2390:      	add	x8, x8, #0x84
    2394:      	b	0x2174 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xac8>
    2398:      	str	w20, [sp, #0x1a0]
    239c:      	str	xzr, [sp, #0x1a8]
    23a0:      	mul	x8, x8, x19
    23a4:      	strb	wzr, [sp, #0x1b0]
    23a8:      	b	0x2174 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xac8>
    23ac:      	eor	x10, x11, x26
    23b0:      	eor	x10, x10, x10, lsr #30
    23b4:      	mul	x10, x10, x6
    23b8:      	eor	x10, x10, x10, lsr #27
    23bc:      	mul	x10, x10, x5
    23c0:      	eor	x13, x10, x10, lsr #31
    23c4:      	ldr	x10, [sp, #0x210]
    23c8:      	cbz	x10, 0x2488 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xddc>
    23cc:      	udiv	x14, x13, x10
    23d0:      	msub	x13, x14, x10, x13
    23d4:      	ldr	x14, [sp, #0x220]
    23d8:      	mov	x15, x10
    23dc:      	b	0x23f4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xd48>
    23e0:      	add	x16, x13, #0x1
    23e4:      	cmp	x16, x10
    23e8:      	csinc	x13, xzr, x13, hs
    23ec:      	subs	x15, x15, #0x1
    23f0:      	b.eq	0x2488 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xddc>
    23f4:      	madd	x16, x13, x23, x14
    23f8:      	ldr	w17, [x16]
    23fc:      	cmp	w17, #0x1
    2400:      	b.eq	0x23e0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xd34>
    2404:      	cmp	w17, #0x2
    2408:      	b.ne	0x2488 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xddc>
    240c:      	ldr	x17, [x16, #0x8]
    2410:      	cmp	x17, x26
    2414:      	b.ne	0x23e0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xd34>
    2418:      	ldr	x10, [x16, #0x10]
    241c:      	mov	w8, #0x1                ; =1
    2420:      	str	w8, [x16]
    2424:      	sub	x9, x9, #0x1
    2428:      	stp	xzr, xzr, [x16, #0x8]
    242c:      	ldr	x11, [sp, #0x230]
    2430:      	ldr	x12, [sp, #0x238]
    2434:      	adds	x11, x11, #0x1
    2438:      	csinv	x11, x11, xzr, lo
    243c:      	str	x9, [sp, #0x228]
    2440:      	str	x11, [sp, #0x230]
    2444:      	str	w8, [sp, #0x138]
    2448:      	stp	x26, x10, [sp, #0x140]
    244c:      	ldr	q0, [x28, #0x100]
    2450:      	str	q0, [x27, #0x110]
    2454:      	ldp	x10, x11, [sp, #0x150]
    2458:      	madd	x10, x12, x19, x10
    245c:      	madd	x10, x10, x19, x11
    2460:      	add	x10, x10, #0x83
    2464:      	ldr	x11, [sp, #0x200]
    2468:      	ldrb	w12, [sp, #0x208]
    246c:      	ldr	x26, [sp, #0x268]
    2470:      	str	x10, [sp, #0x238]
    2474:      	tbz	w12, #0x0, 0x24b0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xe04>
    2478:      	mov	x12, #0x0               ; =0
    247c:      	ldr	x11, [sp, #0x210]
    2480:      	cbnz	x11, 0x24d4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xe28>
    2484:      	b	0x2558 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xeac>
    2488:      	str	wzr, [sp, #0x138]
    248c:      	mul	x10, x8, x19
    2490:      	stp	xzr, xzr, [x28, #0x100]
    2494:      	str	x10, [sp, #0x238]
    2498:      	tbz	w12, #0x0, 0x24b0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xe04>
    249c:      	mov	x12, #0x0               ; =0
    24a0:      	mov	w8, #0x1                ; =1
    24a4:      	ldr	x11, [sp, #0x210]
    24a8:      	cbnz	x11, 0x24d4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xe28>
    24ac:      	b	0x2558 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xeac>
    24b0:      	mov	w8, #0x0                ; =0
    24b4:      	eor	x11, x26, x11
    24b8:      	eor	x11, x11, x11, lsr #30
    24bc:      	mul	x11, x11, x6
    24c0:      	eor	x11, x11, x11, lsr #27
    24c4:      	mul	x11, x11, x5
    24c8:      	eor	x12, x11, x11, lsr #31
    24cc:      	ldr	x11, [sp, #0x210]
    24d0:      	cbz	x11, 0x2558 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xeac>
    24d4:      	udiv	x13, x12, x11
    24d8:      	msub	x12, x13, x11, x12
    24dc:      	ldr	x13, [sp, #0x220]
    24e0:      	mov	x14, x11
    24e4:      	b	0x24fc <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xe50>
    24e8:      	add	x15, x12, #0x1
    24ec:      	cmp	x15, x11
    24f0:      	csinc	x12, xzr, x12, hs
    24f4:      	subs	x14, x14, #0x1
    24f8:      	b.eq	0x2558 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xeac>
    24fc:      	madd	x15, x12, x23, x13
    2500:      	ldr	w16, [x15]
    2504:      	cmp	w16, #0x1
    2508:      	b.eq	0x24e8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xe3c>
    250c:      	cmp	w16, #0x2
    2510:      	b.ne	0x2558 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xeac>
    2514:      	ldr	x16, [x15, #0x8]
    2518:      	cmp	x16, x26
    251c:      	b.ne	0x24e8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xe3c>
    2520:      	ldr	x12, [x15, #0x10]
    2524:      	str	wzr, [sp, #0x160]
    2528:      	str	x12, [sp, #0x168]
    252c:      	strb	wzr, [sp, #0x170]
    2530:      	mov	w13, #0x4309            ; =17161
    2534:      	madd	x10, x10, x13, x12
    2538:      	add	x10, x10, #0x83
    253c:      	str	x10, [sp, #0x238]
    2540:      	ldr	x10, [sp, #0x230]
    2544:      	adds	x10, x9, x10
    2548:      	csinv	x12, x10, xzr, lo
    254c:      	lsr	x10, x11, #14
    2550:      	cbz	x10, 0x2580 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xed4>
    2554:      	b	0x2618 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xf6c>
    2558:      	str	w20, [sp, #0x160]
    255c:      	str	xzr, [sp, #0x168]
    2560:      	mul	x10, x10, x19
    2564:      	strb	wzr, [sp, #0x170]
    2568:      	str	x10, [sp, #0x238]
    256c:      	ldr	x10, [sp, #0x230]
    2570:      	adds	x10, x9, x10
    2574:      	csinv	x12, x10, xzr, lo
    2578:      	lsr	x10, x11, #14
    257c:      	cbnz	x10, 0x2618 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xf6c>
    2580:      	sub	x10, x11, x11, lsr #2
    2584:      	cmp	x12, x10
    2588:      	b.lo	0x2618 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xf6c>
    258c:      	cmp	x11, #0x2, lsl #12      ; =0x2000
    2590:      	mov	w8, #0x2000             ; =8192
    2594:      	csel	x8, x11, x8, lo
    2598:      	lsl	x8, x8, #1
    259c:      	cmp	x11, #0x0
    25a0:      	csinc	x8, x8, xzr, ne
    25a4:      	cmp	x9, x10, lsr #1
    25a8:      	csel	x1, x11, x8, lo
    25ac:      	add	x0, x27, #0x1d0
    25b0:      	add	x2, x27, #0x1c0
    25b4:      	bl	0x25b4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xf08>
		00000000000025b4:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    25b8:      	ldp	x4, x0, [sp, #0x20]
    25bc:      	ldr	x3, [sp, #0x30]
    25c0:      	mov	x6, #0xe5b9             ; =58809
    25c4:      	movk	x6, #0x1ce4, lsl #16
    25c8:      	movk	x6, #0x476d, lsl #32
    25cc:      	movk	x6, #0xbf58, lsl #48
    25d0:      	mov	x5, #0x11eb             ; =4587
    25d4:      	movk	x5, #0x1331, lsl #16
    25d8:      	movk	x5, #0x49bb, lsl #32
    25dc:      	movk	x5, #0x94d0, lsl #48
    25e0:      	ldrb	w8, [sp, #0x208]
    25e4:      	tbnz	w8, #0x0, 0x261c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xf70>
    25e8:      	ldr	x8, [sp, #0x200]
    25ec:      	eor	x8, x8, x26
    25f0:      	eor	x8, x8, x8, lsr #30
    25f4:      	mul	x8, x8, x6
    25f8:      	eor	x8, x8, x8, lsr #27
    25fc:      	mul	x8, x8, x5
    2600:      	eor	x10, x8, x8, lsr #31
    2604:      	add	x8, x0, x25
    2608:      	ldr	x9, [sp, #0x210]
    260c:      	cbnz	x9, 0x262c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xf80>
    2610:      	mov	x10, #0x0               ; =0
    2614:      	b	0x26a0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xff4>
    2618:      	tbz	w8, #0x0, 0x25e8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xf3c>
    261c:      	mov	x10, #0x0               ; =0
    2620:      	add	x8, x0, x25
    2624:      	ldr	x9, [sp, #0x210]
    2628:      	cbz	x9, 0x2610 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xf64>
    262c:      	udiv	x11, x10, x9
    2630:      	msub	x11, x11, x9, x10
    2634:      	ldr	x12, [sp, #0x220]
    2638:      	mov	x13, x9
    263c:      	mov	x10, x9
    2640:      	b	0x2660 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xfb4>
    2644:      	cmp	x10, x9
    2648:      	csel	x10, x11, x10, eq
    264c:      	add	x14, x11, #0x1
    2650:      	cmp	x14, x9
    2654:      	csinc	x11, xzr, x11, hs
    2658:      	subs	x13, x13, #0x1
    265c:      	b.eq	0x26a0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xff4>
    2660:      	madd	x14, x11, x23, x12
    2664:      	ldr	w15, [x14]
    2668:      	cmp	w15, #0x1
    266c:      	b.eq	0x2644 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xf98>
    2670:      	cmp	w15, #0x2
    2674:      	b.ne	0x2698 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xfec>
    2678:      	ldr	x15, [x14, #0x8]
    267c:      	cmp	x15, x26
    2680:      	b.ne	0x264c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xfa0>
    2684:      	ldr	x9, [x14, #0x10]
    2688:      	mov	w10, #0x2               ; =2
    268c:      	str	w10, [x14]
    2690:      	str	x8, [x14, #0x10]
    2694:      	b	0x2730 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1084>
    2698:      	cmp	x10, x9
    269c:      	csel	x10, x11, x10, eq
    26a0:      	cmp	x10, x9
    26a4:      	b.hs	0x26f0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1044>
    26a8:      	ldr	x9, [sp, #0x228]
    26ac:      	lsr	x11, x9, #14
    26b0:      	cbnz	x11, 0x26f0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1044>
    26b4:      	add	x9, x9, #0x1
    26b8:      	str	x9, [sp, #0x228]
    26bc:      	ldr	x9, [sp, #0x220]
    26c0:      	madd	x10, x10, x23, x9
    26c4:      	ldr	w11, [x10]
    26c8:      	cmp	w11, #0x1
    26cc:      	b.ne	0x2718 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x106c>
    26d0:      	ldr	x9, [sp, #0x230]
    26d4:      	subs	x9, x9, #0x1
    26d8:      	csel	x9, xzr, x9, lo
    26dc:      	str	x9, [sp, #0x230]
    26e0:      	mov	w9, #0x2                ; =2
    26e4:      	str	w9, [x10]
    26e8:      	stp	x26, x8, [x10, #0x8]
    26ec:      	b	0x2750 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x10a4>
    26f0:      	stp	x20, x26, [sp, #0x178]
    26f4:      	strb	w20, [x27, #0x13c]
    26f8:      	str	x8, [sp, #0x188]
    26fc:      	ldr	q0, [x28, #0x140]
    2700:      	str	q0, [x27, #0x150]
    2704:      	mov	w8, #0x2                ; =2
    2708:      	ldr	x9, [sp, #0x238]
    270c:      	madd	x8, x9, x19, x8
    2710:      	ldp	x9, x10, [sp, #0x190]
    2714:      	b	0x28c8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x121c>
    2718:      	ldp	x12, x9, [x10, #0x8]
    271c:      	mov	w13, #0x2               ; =2
    2720:      	str	w13, [x10]
    2724:      	stp	x26, x8, [x10, #0x8]
    2728:      	cbz	w11, 0x2750 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x10a4>
    272c:      	mov	x26, x12
    2730:      	stp	x20, x26, [sp, #0x178]
    2734:      	str	x9, [sp, #0x188]
    2738:      	ldrb	w9, [x27, #0x13c]
    273c:      	ldr	q0, [x28, #0x140]
    2740:      	str	q0, [x27, #0x150]
    2744:      	mov	w8, #0x1                ; =1
    2748:      	tbnz	w9, #0x0, 0x2704 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1058>
    274c:      	b	0x2708 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x105c>
    2750:      	stp	xzr, xzr, [x27, #0x138]
    2754:      	str	xzr, [x27, #0x148]
    2758:      	b	0x2914 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1268>
    275c:      	mov	w1, #0x1                ; =1
    2760:      	add	x0, x27, #0x1d0
    2764:      	add	x2, x27, #0x1c0
    2768:      	bl	0x2768 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x10bc>
		0000000000002768:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    276c:      	mov	x5, #0x11eb             ; =4587
    2770:      	movk	x5, #0x1331, lsl #16
    2774:      	movk	x5, #0x49bb, lsl #32
    2778:      	movk	x5, #0x94d0, lsl #48
    277c:      	mov	x6, #0xe5b9             ; =58809
    2780:      	movk	x6, #0x1ce4, lsl #16
    2784:      	movk	x6, #0x476d, lsl #32
    2788:      	movk	x6, #0xbf58, lsl #48
    278c:      	ldp	x0, x3, [sp, #0x28]
    2790:      	ldr	x4, [sp, #0x20]
    2794:      	ldrb	w8, [sp, #0x208]
    2798:      	tbz	w8, #0x0, 0x2818 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x116c>
    279c:      	mov	x10, #0x0               ; =0
    27a0:      	add	x8, x0, x25
    27a4:      	ldr	x9, [sp, #0x210]
    27a8:      	cbz	x9, 0x2840 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1194>
    27ac:      	udiv	x11, x10, x9
    27b0:      	msub	x11, x11, x9, x10
    27b4:      	ldr	x12, [sp, #0x220]
    27b8:      	mov	x13, x9
    27bc:      	mov	x10, x9
    27c0:      	b	0x27e0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1134>
    27c4:      	cmp	x10, x9
    27c8:      	csel	x10, x11, x10, eq
    27cc:      	add	x14, x11, #0x1
    27d0:      	cmp	x14, x9
    27d4:      	csinc	x11, xzr, x11, hs
    27d8:      	subs	x13, x13, #0x1
    27dc:      	b.eq	0x2844 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1198>
    27e0:      	madd	x14, x11, x23, x12
    27e4:      	ldr	w15, [x14]
    27e8:      	cmp	w15, #0x1
    27ec:      	b.eq	0x27c4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1118>
    27f0:      	cmp	w15, #0x2
    27f4:      	b.ne	0x2894 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x11e8>
    27f8:      	ldr	x15, [x14, #0x8]
    27fc:      	cmp	x15, x26
    2800:      	b.ne	0x27cc <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1120>
    2804:      	ldr	x9, [x14, #0x10]
    2808:      	mov	w10, #0x2               ; =2
    280c:      	str	w10, [x14]
    2810:      	str	x8, [x14, #0x10]
    2814:      	b	0x28ec <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1240>
    2818:      	ldr	x8, [sp, #0x200]
    281c:      	eor	x8, x8, x26
    2820:      	eor	x8, x8, x8, lsr #30
    2824:      	mul	x8, x8, x6
    2828:      	eor	x8, x8, x8, lsr #27
    282c:      	mul	x8, x8, x5
    2830:      	eor	x10, x8, x8, lsr #31
    2834:      	add	x8, x0, x25
    2838:      	ldr	x9, [sp, #0x210]
    283c:      	cbnz	x9, 0x27ac <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1100>
    2840:      	mov	x10, #0x0               ; =0
    2844:      	cmp	x10, x9
    2848:      	b.hs	0x28a4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x11f8>
    284c:      	ldr	x9, [sp, #0x228]
    2850:      	lsr	x11, x9, #14
    2854:      	cbnz	x11, 0x28a4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x11f8>
    2858:      	add	x9, x9, #0x1
    285c:      	str	x9, [sp, #0x228]
    2860:      	ldr	x9, [sp, #0x220]
    2864:      	madd	x10, x10, x23, x9
    2868:      	ldr	w11, [x10]
    286c:      	cmp	w11, #0x1
    2870:      	b.ne	0x28d4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1228>
    2874:      	ldr	x9, [sp, #0x230]
    2878:      	subs	x9, x9, #0x1
    287c:      	csel	x9, xzr, x9, lo
    2880:      	str	x9, [sp, #0x230]
    2884:      	mov	w9, #0x2                ; =2
    2888:      	str	w9, [x10]
    288c:      	stp	x26, x8, [x10, #0x8]
    2890:      	b	0x290c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1260>
    2894:      	cmp	x10, x9
    2898:      	csel	x10, x11, x10, eq
    289c:      	cmp	x10, x9
    28a0:      	b.lo	0x284c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x11a0>
    28a4:      	stp	x20, x26, [sp, #0x110]
    28a8:      	strb	w20, [sp, #0x114]
    28ac:      	str	x8, [sp, #0x120]
    28b0:      	ldur	q0, [x28, #0xd8]
    28b4:      	stur	q0, [x27, #0xe8]
    28b8:      	mov	w8, #0x2                ; =2
    28bc:      	ldr	x9, [sp, #0x238]
    28c0:      	madd	x8, x9, x19, x8
    28c4:      	ldp	x9, x10, [sp, #0x128]
    28c8:      	add	x8, x9, x8
    28cc:      	madd	x8, x8, x19, x10
    28d0:      	b	0x2174 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xac8>
    28d4:      	ldp	x12, x9, [x10, #0x8]
    28d8:      	mov	w13, #0x2               ; =2
    28dc:      	str	w13, [x10]
    28e0:      	stp	x26, x8, [x10, #0x8]
    28e4:      	cbz	w11, 0x290c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1260>
    28e8:      	mov	x26, x12
    28ec:      	stp	x20, x26, [sp, #0x110]
    28f0:      	str	x9, [sp, #0x120]
    28f4:      	ubfx	x9, x20, #32, #8
    28f8:      	ldur	q0, [x28, #0xd8]
    28fc:      	stur	q0, [x27, #0xe8]
    2900:      	mov	w8, #0x1                ; =1
    2904:      	tbnz	w9, #0x0, 0x28b8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x120c>
    2908:      	b	0x28bc <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1210>
    290c:      	stp	xzr, xzr, [x27, #0xd0]
    2910:      	stur	xzr, [x27, #0xe0]
    2914:      	ldr	x8, [sp, #0x238]
    2918:      	mul	x8, x8, x19
    291c:      	b	0x2174 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0xac8>
    2920:      	mov	x12, x13
    2924:      	cmp	x13, #0x4
    2928:      	b.hs	0x29d0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1324>
    292c:      	add	x19, x27, #0x1f8
    2930:      	cbz	x8, 0x2958 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x12ac>
    2934:      	bl	0x2934 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1288>
		0000000000002934:  ARM64_RELOC_BRANCH26	_free
    2938:      	mov	x6, #0xe5b9             ; =58809
    293c:      	movk	x6, #0x1ce4, lsl #16
    2940:      	movk	x6, #0x476d, lsl #32
    2944:      	movk	x6, #0xbf58, lsl #48
    2948:      	mov	x5, #0x11eb             ; =4587
    294c:      	movk	x5, #0x1331, lsl #16
    2950:      	movk	x5, #0x49bb, lsl #32
    2954:      	movk	x5, #0x94d0, lsl #48
    2958:      	ldp	q0, q1, [x19]
    295c:      	stp	q0, q1, [sp, #0x1e0]
    2960:      	ldp	x8, x9, [sp, #0x1e0]
    2964:      	ldp	x10, x11, [sp, #0x1f0]
    2968:      	eor	x8, x8, x8, lsr #30
    296c:      	mul	x8, x8, x6
    2970:      	eor	x8, x8, x8, lsr #27
    2974:      	mul	x8, x8, x5
    2978:      	eor	x9, x9, x9, lsr #30
    297c:      	mul	x9, x9, x6
    2980:      	eor	x9, x9, x9, lsr #27
    2984:      	mul	x9, x9, x5
    2988:      	eor	x12, x9, x8
    298c:      	mov	x13, #0x7c15            ; =31765
    2990:      	movk	x13, #0x7f4a, lsl #16
    2994:      	movk	x13, #0x79b9, lsl #32
    2998:      	movk	x13, #0x9e37, lsl #48
    299c:      	mul	x11, x11, x13
    29a0:      	eor	x10, x10, x11
    29a4:      	eor	x10, x10, x12, lsr #31
    29a8:      	eor	x8, x8, x9
    29ac:      	eor	x0, x10, x8
    29b0:      	add	sp, sp, #0x270
    29b4:      	ldp	x29, x30, [sp, #0x50]
    29b8:      	ldp	x20, x19, [sp, #0x40]
    29bc:      	ldp	x22, x21, [sp, #0x30]
    29c0:      	ldp	x24, x23, [sp, #0x20]
    29c4:      	ldp	x26, x25, [sp, #0x10]
    29c8:      	ldp	x28, x27, [sp], #0x60
    29cc:      	ret
    29d0:      	mov	w13, #0x18              ; =24
    29d4:      	madd	x13, x12, x13, x0
    29d8:      	sub	x13, x13, #0x30
    29dc:      	mov	w14, #0x83              ; =131
    29e0:      	b	0x29f0 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1344>
    29e4:      	sub	x13, x13, #0x60
    29e8:      	sub	x12, x12, #0x4
    29ec:      	cbz	x12, 0x292c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1280>
    29f0:      	ldr	w15, [x13, #0x18]
    29f4:      	cmp	w15, #0x2
    29f8:      	b.ne	0x2a8c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x13e0>
    29fc:      	ldp	x16, x15, [x13, #0x20]
    2a00:      	madd	x15, x16, x14, x15
    2a04:      	add	x9, x15, x9
    2a08:      	str	x9, [sp, #0x240]
    2a0c:      	eor	x15, x15, x15, lsr #30
    2a10:      	mul	x15, x15, x6
    2a14:      	eor	x15, x15, x15, lsr #27
    2a18:      	mul	x15, x15, x5
    2a1c:      	eor	x11, x11, x15, lsr #31
    2a20:      	eor	x11, x11, x15
    2a24:      	str	x11, [sp, #0x248]
    2a28:      	add	x10, x10, #0x1
    2a2c:      	str	x10, [sp, #0x250]
    2a30:      	ldr	w15, [x13]
    2a34:      	cmp	w15, #0x2
    2a38:      	b.eq	0x2a98 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x13ec>
    2a3c:      	ldur	w15, [x13, #-0x18]
    2a40:      	cmp	w15, #0x2
    2a44:      	b.ne	0x2ad8 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x142c>
    2a48:      	ldp	x16, x15, [x13, #-0x10]
    2a4c:      	madd	x15, x16, x14, x15
    2a50:      	add	x9, x15, x9
    2a54:      	str	x9, [sp, #0x240]
    2a58:      	eor	x15, x15, x15, lsr #30
    2a5c:      	mul	x15, x15, x6
    2a60:      	eor	x15, x15, x15, lsr #27
    2a64:      	mul	x15, x15, x5
    2a68:      	eor	x11, x11, x15, lsr #31
    2a6c:      	eor	x11, x11, x15
    2a70:      	str	x11, [sp, #0x248]
    2a74:      	add	x10, x10, #0x1
    2a78:      	str	x10, [sp, #0x250]
    2a7c:      	ldur	w15, [x13, #-0x30]
    2a80:      	cmp	w15, #0x2
    2a84:      	b.ne	0x29e4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1338>
    2a88:      	b	0x2ae4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1438>
    2a8c:      	ldr	w15, [x13]
    2a90:      	cmp	w15, #0x2
    2a94:      	b.ne	0x2a3c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1390>
    2a98:      	ldp	x16, x15, [x13, #0x8]
    2a9c:      	madd	x15, x16, x14, x15
    2aa0:      	add	x9, x15, x9
    2aa4:      	str	x9, [sp, #0x240]
    2aa8:      	eor	x15, x15, x15, lsr #30
    2aac:      	mul	x15, x15, x6
    2ab0:      	eor	x15, x15, x15, lsr #27
    2ab4:      	mul	x15, x15, x5
    2ab8:      	eor	x11, x11, x15, lsr #31
    2abc:      	eor	x11, x11, x15
    2ac0:      	str	x11, [sp, #0x248]
    2ac4:      	add	x10, x10, #0x1
    2ac8:      	str	x10, [sp, #0x250]
    2acc:      	ldur	w15, [x13, #-0x18]
    2ad0:      	cmp	w15, #0x2
    2ad4:      	b.eq	0x2a48 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x139c>
    2ad8:      	ldur	w15, [x13, #-0x30]
    2adc:      	cmp	w15, #0x2
    2ae0:      	b.ne	0x29e4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1338>
    2ae4:      	ldp	x16, x15, [x13, #-0x28]
    2ae8:      	madd	x15, x16, x14, x15
    2aec:      	add	x9, x15, x9
    2af0:      	str	x9, [sp, #0x240]
    2af4:      	eor	x15, x15, x15, lsr #30
    2af8:      	mul	x15, x15, x6
    2afc:      	eor	x15, x15, x15, lsr #27
    2b00:      	mul	x15, x15, x5
    2b04:      	eor	x11, x11, x15, lsr #31
    2b08:      	eor	x11, x11, x15
    2b0c:      	str	x11, [sp, #0x248]
    2b10:      	add	x10, x10, #0x1
    2b14:      	str	x10, [sp, #0x250]
    2b18:      	b	0x29e4 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1338>
    2b1c:      	bl	0x2b1c <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x1470>
		0000000000002b1c:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

0000000000002b20 <_wf_map_cost_library_policy$instance$4250cb78d3f44027>:
    2b20:      	stp	x28, x27, [sp, #-0x60]!
    2b24:      	stp	x26, x25, [sp, #0x10]
    2b28:      	stp	x24, x23, [sp, #0x20]
    2b2c:      	stp	x22, x21, [sp, #0x30]
    2b30:      	stp	x20, x19, [sp, #0x40]
    2b34:      	stp	x29, x30, [sp, #0x50]
    2b38:      	sub	sp, sp, #0x620
    2b3c:      	mov	x19, x0
    2b40:      	mov	x8, #0x7c15             ; =31765
    2b44:      	movk	x8, #0x7f4a, lsl #16
    2b48:      	movk	x8, #0x79b9, lsl #32
    2b4c:      	movk	x8, #0x9e37, lsl #48
    2b50:      	eor	x8, x0, x8
    2b54:      	cmp	x1, #0x0
    2b58:      	cset	w9, ne
    2b5c:      	str	x8, [sp, #0x160]
    2b60:      	strb	w9, [sp, #0x168]
    2b64:      	mov	w0, #0x330              ; =816
    2b68:      	bl	0x2b68 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x48>
		0000000000002b68:  ARM64_RELOC_BRANCH26	_malloc
    2b6c:      	cbz	x0, 0x353c <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0xa1c>
    2b70:      	add	x21, sp, #0x4a0
    2b74:      	str	wzr, [x0]
    2b78:      	add	x8, x0, #0x118
    2b7c:      	add	x9, x0, #0x228
    2b80:      	str	xzr, [x0, #0x328]
    2b84:      	movi.2d	v0, #0000000000000000
    2b88:      	stp	q0, q0, [x9]
    2b8c:      	stp	q0, q0, [x9, #0x20]
    2b90:      	stp	q0, q0, [x9, #0x40]
    2b94:      	stp	q0, q0, [x9, #0x60]
    2b98:      	stp	q0, q0, [x9, #0x80]
    2b9c:      	stp	q0, q0, [x9, #0xa0]
    2ba0:      	stp	q0, q0, [x9, #0xc0]
    2ba4:      	stp	q0, q0, [x9, #0xe0]
    2ba8:      	stur	q0, [x0, #0xf8]
    2bac:      	stur	q0, [x0, #0xe8]
    2bb0:      	stur	q0, [x0, #0xd8]
    2bb4:      	stur	q0, [x0, #0xc8]
    2bb8:      	stur	q0, [x0, #0xb8]
    2bbc:      	stur	q0, [x0, #0xa8]
    2bc0:      	stur	q0, [x0, #0x98]
    2bc4:      	stur	q0, [x0, #0x88]
    2bc8:      	stur	q0, [x0, #0x78]
    2bcc:      	stur	q0, [x0, #0x68]
    2bd0:      	stur	q0, [x0, #0x58]
    2bd4:      	stur	q0, [x0, #0x48]
    2bd8:      	stur	q0, [x0, #0x38]
    2bdc:      	stur	q0, [x0, #0x28]
    2be0:      	stur	q0, [x0, #0x18]
    2be4:      	mov	x9, x0
    2be8:      	str	q0, [x9, #0x8]!
    2bec:      	stur	q0, [x9, #0xfc]
    2bf0:      	stur	q0, [x8, #0xfc]
    2bf4:      	stp	q0, q0, [x8, #0xe0]
    2bf8:      	stp	q0, q0, [x8, #0xc0]
    2bfc:      	stp	q0, q0, [x8, #0xa0]
    2c00:      	stp	q0, q0, [x8, #0x80]
    2c04:      	stp	q0, q0, [x8, #0x60]
    2c08:      	stp	q0, q0, [x8, #0x40]
    2c0c:      	stp	q0, q0, [x8, #0x20]
    2c10:      	stp	q0, q0, [x8]
    2c14:      	mov	w8, #0x3                ; =3
    2c18:      	dup.2d	v0, x8
    2c1c:      	str	q0, [sp, #0x130]
    2c20:      	stp	xzr, xzr, [sp, #0x148]
    2c24:      	str	x0, [sp, #0x140]
    2c28:      	add	x23, x21, #0x128
    2c2c:      	stp	x19, xzr, [sp, #0x110]
    2c30:      	stp	xzr, xzr, [sp, #0x120]
    2c34:      	add	x8, x19, #0x1f
    2c38:      	dup.2d	v1, x19
    2c3c:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x954>
		0000000000002c3c:  ARM64_RELOC_PAGE21	lCPI67_0
    2c40:      	ldr	q0, [x9]
		0000000000002c40:  ARM64_RELOC_PAGEOFF12	lCPI67_0
    2c44:      	str	q0, [sp, #0xf0]
    2c48:      	add.2d	v0, v1, v0
    2c4c:      	stur	q0, [x21, #0x8]
    2c50:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x954>
		0000000000002c50:  ARM64_RELOC_PAGE21	lCPI67_1
    2c54:      	ldr	q0, [x9]
		0000000000002c54:  ARM64_RELOC_PAGEOFF12	lCPI67_1
    2c58:      	str	q0, [sp, #0xe0]
    2c5c:      	add.2d	v0, v1, v0
    2c60:      	stur	q0, [x21, #0x18]
    2c64:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x954>
		0000000000002c64:  ARM64_RELOC_PAGE21	lCPI67_2
    2c68:      	ldr	q0, [x9]
		0000000000002c68:  ARM64_RELOC_PAGEOFF12	lCPI67_2
    2c6c:      	str	q0, [sp, #0xd0]
    2c70:      	add.2d	v0, v1, v0
    2c74:      	stur	q0, [x21, #0x28]
    2c78:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x954>
		0000000000002c78:  ARM64_RELOC_PAGE21	lCPI67_3
    2c7c:      	ldr	q0, [x9]
		0000000000002c7c:  ARM64_RELOC_PAGEOFF12	lCPI67_3
    2c80:      	str	q0, [sp, #0xc0]
    2c84:      	add.2d	v0, v1, v0
    2c88:      	stur	q0, [x21, #0x38]
    2c8c:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x954>
		0000000000002c8c:  ARM64_RELOC_PAGE21	lCPI67_4
    2c90:      	ldr	q0, [x9]
		0000000000002c90:  ARM64_RELOC_PAGEOFF12	lCPI67_4
    2c94:      	str	q0, [sp, #0xb0]
    2c98:      	add.2d	v0, v1, v0
    2c9c:      	stur	q0, [x21, #0x48]
    2ca0:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x954>
		0000000000002ca0:  ARM64_RELOC_PAGE21	lCPI67_5
    2ca4:      	ldr	q0, [x9]
		0000000000002ca4:  ARM64_RELOC_PAGEOFF12	lCPI67_5
    2ca8:      	str	q0, [sp, #0xa0]
    2cac:      	add.2d	v0, v1, v0
    2cb0:      	stur	q0, [x21, #0x58]
    2cb4:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x954>
		0000000000002cb4:  ARM64_RELOC_PAGE21	lCPI67_6
    2cb8:      	ldr	q0, [x9]
		0000000000002cb8:  ARM64_RELOC_PAGEOFF12	lCPI67_6
    2cbc:      	str	q0, [sp, #0x90]
    2cc0:      	add.2d	v0, v1, v0
    2cc4:      	stur	q0, [x21, #0x68]
    2cc8:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x954>
		0000000000002cc8:  ARM64_RELOC_PAGE21	lCPI67_7
    2ccc:      	ldr	q0, [x9]
		0000000000002ccc:  ARM64_RELOC_PAGEOFF12	lCPI67_7
    2cd0:      	str	q0, [sp, #0x80]
    2cd4:      	add.2d	v0, v1, v0
    2cd8:      	stur	q0, [x21, #0x78]
    2cdc:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x954>
		0000000000002cdc:  ARM64_RELOC_PAGE21	lCPI67_8
    2ce0:      	ldr	q0, [x9]
		0000000000002ce0:  ARM64_RELOC_PAGEOFF12	lCPI67_8
    2ce4:      	str	q0, [sp, #0x70]
    2ce8:      	add.2d	v0, v1, v0
    2cec:      	stur	q0, [x21, #0x88]
    2cf0:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x954>
		0000000000002cf0:  ARM64_RELOC_PAGE21	lCPI67_9
    2cf4:      	ldr	q0, [x9]
		0000000000002cf4:  ARM64_RELOC_PAGEOFF12	lCPI67_9
    2cf8:      	str	q0, [sp, #0x60]
    2cfc:      	add.2d	v0, v1, v0
    2d00:      	stur	q0, [x21, #0x98]
    2d04:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x954>
		0000000000002d04:  ARM64_RELOC_PAGE21	lCPI67_10
    2d08:      	ldr	q0, [x9]
		0000000000002d08:  ARM64_RELOC_PAGEOFF12	lCPI67_10
    2d0c:      	str	q0, [sp, #0x50]
    2d10:      	add.2d	v0, v1, v0
    2d14:      	stur	q0, [x21, #0xa8]
    2d18:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x954>
		0000000000002d18:  ARM64_RELOC_PAGE21	lCPI67_11
    2d1c:      	ldr	q0, [x9]
		0000000000002d1c:  ARM64_RELOC_PAGEOFF12	lCPI67_11
    2d20:      	str	q0, [sp, #0x40]
    2d24:      	add.2d	v0, v1, v0
    2d28:      	stur	q0, [x21, #0xb8]
    2d2c:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x954>
		0000000000002d2c:  ARM64_RELOC_PAGE21	lCPI67_12
    2d30:      	ldr	q0, [x9]
		0000000000002d30:  ARM64_RELOC_PAGEOFF12	lCPI67_12
    2d34:      	str	q0, [sp, #0x30]
    2d38:      	add.2d	v0, v1, v0
    2d3c:      	stur	q0, [x21, #0xc8]
    2d40:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x954>
		0000000000002d40:  ARM64_RELOC_PAGE21	lCPI67_13
    2d44:      	ldr	q0, [x9]
		0000000000002d44:  ARM64_RELOC_PAGEOFF12	lCPI67_13
    2d48:      	str	q0, [sp, #0x20]
    2d4c:      	add.2d	v0, v1, v0
    2d50:      	stur	q0, [x21, #0xd8]
    2d54:      	adrp	x9, 0x2000 <_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd+0x954>
		0000000000002d54:  ARM64_RELOC_PAGE21	lCPI67_14
    2d58:      	ldr	q0, [x9]
		0000000000002d58:  ARM64_RELOC_PAGEOFF12	lCPI67_14
    2d5c:      	str	q1, [sp, #0x100]
    2d60:      	str	q0, [sp, #0x10]
    2d64:      	add.2d	v0, v1, v0
    2d68:      	stur	q0, [x21, #0xe8]
    2d6c:      	str	x19, [sp, #0x4a0]
    2d70:      	str	x8, [sp, #0x598]
    2d74:      	ldr	x1, [sp, #0x130]
    2d78:      	ldr	x9, [sp, #0x150]
    2d7c:      	ldp	q1, q0, [sp, #0x130]
    2d80:      	str	q0, [sp, #0x5b0]
    2d84:      	str	q1, [sp, #0x5a0]
    2d88:      	ldr	x8, [sp, #0x5b8]
    2d8c:      	stp	q1, q0, [x23]
    2d90:      	adds	x8, x8, x9
    2d94:      	csinv	x8, x8, xzr, lo
    2d98:      	str	x9, [sp, #0x5c0]
    2d9c:      	str	x9, [sp, #0x5e8]
    2da0:      	cmp	x1, #0x2
    2da4:      	b.hi	0x2e00 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x2e0>
    2da8:      	sub	x9, x1, x1, lsr #2
    2dac:      	cmp	x8, x9
    2db0:      	b.lo	0x2e00 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x2e0>
    2db4:      	ldr	x8, [sp, #0x150]
    2db8:      	str	x8, [x21, #0x170]
    2dbc:      	ldp	q1, q0, [sp, #0x130]
    2dc0:      	stp	q1, q0, [x21, #0x150]
    2dc4:      	ldr	x8, [sp, #0x608]
    2dc8:      	cmp	x8, x1, lsr #1
    2dcc:      	b.lo	0x2de8 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x2c8>
    2dd0:      	cbz	x1, 0x2de4 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x2c4>
    2dd4:      	cmp	x1, #0x1
    2dd8:      	mov	w8, #0x2                ; =2
    2ddc:      	cinc	x1, x8, ne
    2de0:      	b	0x2de8 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x2c8>
    2de4:      	mov	w1, #0x1                ; =1
    2de8:      	add	x0, sp, #0x130
    2dec:      	add	x2, sp, #0x160
    2df0:      	bl	0x2df0 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x2d0>
		0000000000002df0:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07
    2df4:      	str	w0, [sp, #0x618]
    2df8:      	strb	w1, [sp, #0x61c]
    2dfc:      	strb	w2, [sp, #0x61d]
    2e00:      	add	x0, sp, #0x390
    2e04:      	add	x1, sp, #0x130
    2e08:      	add	x3, sp, #0x4a0
    2e0c:      	add	x4, sp, #0x160
    2e10:      	mov	w2, #0x1                ; =1
    2e14:      	bl	0x2e14 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x2f4>
		0000000000002e14:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07
    2e18:      	add	x0, sp, #0x390
    2e1c:      	add	x1, sp, #0x110
    2e20:      	bl	0x2e20 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x300>
		0000000000002e20:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
    2e24:      	add	x8, x19, #0x1
    2e28:      	dup.2d	v0, x8
    2e2c:      	ldr	q1, [sp, #0xf0]
    2e30:      	add.2d	v1, v0, v1
    2e34:      	stur	q1, [x21, #0x8]
    2e38:      	add	x9, x19, #0x20
    2e3c:      	ldr	q1, [sp, #0xe0]
    2e40:      	add.2d	v1, v0, v1
    2e44:      	stur	q1, [x21, #0x18]
    2e48:      	ldr	q1, [sp, #0xd0]
    2e4c:      	add.2d	v1, v0, v1
    2e50:      	stur	q1, [x21, #0x28]
    2e54:      	ldr	q1, [sp, #0xc0]
    2e58:      	add.2d	v1, v0, v1
    2e5c:      	stur	q1, [x21, #0x38]
    2e60:      	ldr	q1, [sp, #0xb0]
    2e64:      	add.2d	v1, v0, v1
    2e68:      	stur	q1, [x21, #0x48]
    2e6c:      	ldr	q1, [sp, #0xa0]
    2e70:      	add.2d	v1, v0, v1
    2e74:      	stur	q1, [x21, #0x58]
    2e78:      	ldr	q1, [sp, #0x90]
    2e7c:      	add.2d	v1, v0, v1
    2e80:      	stur	q1, [x21, #0x68]
    2e84:      	ldr	q1, [sp, #0x80]
    2e88:      	add.2d	v1, v0, v1
    2e8c:      	stur	q1, [x21, #0x78]
    2e90:      	ldr	q1, [sp, #0x70]
    2e94:      	add.2d	v1, v0, v1
    2e98:      	stur	q1, [x21, #0x88]
    2e9c:      	ldr	q1, [sp, #0x60]
    2ea0:      	add.2d	v1, v0, v1
    2ea4:      	stur	q1, [x21, #0x98]
    2ea8:      	ldr	q1, [sp, #0x50]
    2eac:      	add.2d	v1, v0, v1
    2eb0:      	stur	q1, [x21, #0xa8]
    2eb4:      	ldr	q1, [sp, #0x40]
    2eb8:      	add.2d	v1, v0, v1
    2ebc:      	stur	q1, [x21, #0xb8]
    2ec0:      	ldr	q1, [sp, #0x30]
    2ec4:      	add.2d	v1, v0, v1
    2ec8:      	stur	q1, [x21, #0xc8]
    2ecc:      	ldr	q1, [sp, #0x20]
    2ed0:      	add.2d	v1, v0, v1
    2ed4:      	stur	q1, [x21, #0xd8]
    2ed8:      	ldr	q1, [sp, #0x10]
    2edc:      	add.2d	v0, v0, v1
    2ee0:      	stur	q0, [x21, #0xe8]
    2ee4:      	str	x8, [sp, #0x4a0]
    2ee8:      	str	x9, [sp, #0x598]
    2eec:      	ldr	x1, [sp, #0x130]
    2ef0:      	ldr	x8, [sp, #0x150]
    2ef4:      	str	x8, [x21, #0x120]
    2ef8:      	ldp	q1, q0, [sp, #0x130]
    2efc:      	stp	q1, q0, [x21, #0x100]
    2f00:      	str	x8, [x23, #0x20]
    2f04:      	ldr	x8, [sp, #0x5b8]
    2f08:      	ldr	x9, [sp, #0x5e8]
    2f0c:      	adds	x8, x8, x9
    2f10:      	csinv	x8, x8, xzr, lo
    2f14:      	stp	q1, q0, [x23]
    2f18:      	cmp	x1, #0x2
    2f1c:      	b.hi	0x2f78 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x458>
    2f20:      	sub	x9, x1, x1, lsr #2
    2f24:      	cmp	x8, x9
    2f28:      	b.lo	0x2f78 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x458>
    2f2c:      	ldr	x8, [sp, #0x150]
    2f30:      	str	x8, [x21, #0x170]
    2f34:      	ldp	q1, q0, [sp, #0x130]
    2f38:      	stp	q1, q0, [x21, #0x150]
    2f3c:      	ldr	x8, [sp, #0x608]
    2f40:      	cmp	x8, x1, lsr #1
    2f44:      	b.lo	0x2f60 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x440>
    2f48:      	cbz	x1, 0x2f5c <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x43c>
    2f4c:      	cmp	x1, #0x1
    2f50:      	mov	w8, #0x2                ; =2
    2f54:      	cinc	x1, x8, ne
    2f58:      	b	0x2f60 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x440>
    2f5c:      	mov	w1, #0x1                ; =1
    2f60:      	add	x0, sp, #0x130
    2f64:      	add	x2, sp, #0x160
    2f68:      	bl	0x2f68 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x448>
		0000000000002f68:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07
    2f6c:      	str	w0, [sp, #0x618]
    2f70:      	strb	w1, [sp, #0x61c]
    2f74:      	strb	w2, [sp, #0x61d]
    2f78:      	add	x0, sp, #0x390
    2f7c:      	add	x1, sp, #0x130
    2f80:      	add	x3, sp, #0x4a0
    2f84:      	add	x4, sp, #0x160
    2f88:      	mov	w2, #0x3                ; =3
    2f8c:      	bl	0x2f8c <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x46c>
		0000000000002f8c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07
    2f90:      	add	x0, sp, #0x390
    2f94:      	add	x1, sp, #0x110
    2f98:      	bl	0x2f98 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x478>
		0000000000002f98:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
    2f9c:      	add	x8, x19, #0x2
    2fa0:      	dup.2d	v0, x8
    2fa4:      	ldr	q1, [sp, #0xf0]
    2fa8:      	add.2d	v1, v0, v1
    2fac:      	stur	q1, [x21, #0x8]
    2fb0:      	add	x24, x19, #0x21
    2fb4:      	ldr	q1, [sp, #0xe0]
    2fb8:      	add.2d	v1, v0, v1
    2fbc:      	stur	q1, [x21, #0x18]
    2fc0:      	ldr	q1, [sp, #0xd0]
    2fc4:      	add.2d	v1, v0, v1
    2fc8:      	stur	q1, [x21, #0x28]
    2fcc:      	ldr	q1, [sp, #0xc0]
    2fd0:      	add.2d	v1, v0, v1
    2fd4:      	stur	q1, [x21, #0x38]
    2fd8:      	ldr	q1, [sp, #0xb0]
    2fdc:      	add.2d	v1, v0, v1
    2fe0:      	stur	q1, [x21, #0x48]
    2fe4:      	ldr	q1, [sp, #0xa0]
    2fe8:      	add.2d	v1, v0, v1
    2fec:      	stur	q1, [x21, #0x58]
    2ff0:      	ldr	q1, [sp, #0x90]
    2ff4:      	add.2d	v1, v0, v1
    2ff8:      	stur	q1, [x21, #0x68]
    2ffc:      	ldr	q1, [sp, #0x80]
    3000:      	add.2d	v1, v0, v1
    3004:      	stur	q1, [x21, #0x78]
    3008:      	ldr	q1, [sp, #0x70]
    300c:      	add.2d	v1, v0, v1
    3010:      	stur	q1, [x21, #0x88]
    3014:      	ldr	q1, [sp, #0x60]
    3018:      	add.2d	v1, v0, v1
    301c:      	stur	q1, [x21, #0x98]
    3020:      	ldr	q1, [sp, #0x50]
    3024:      	add.2d	v1, v0, v1
    3028:      	stur	q1, [x21, #0xa8]
    302c:      	ldr	q1, [sp, #0x40]
    3030:      	add.2d	v1, v0, v1
    3034:      	stur	q1, [x21, #0xb8]
    3038:      	ldr	q1, [sp, #0x30]
    303c:      	add.2d	v1, v0, v1
    3040:      	stur	q1, [x21, #0xc8]
    3044:      	ldr	q1, [sp, #0x20]
    3048:      	add.2d	v1, v0, v1
    304c:      	stur	q1, [x21, #0xd8]
    3050:      	ldr	q1, [sp, #0x10]
    3054:      	add.2d	v0, v0, v1
    3058:      	stur	q0, [x21, #0xe8]
    305c:      	str	x8, [sp, #0x4a0]
    3060:      	str	x24, [sp, #0x598]
    3064:      	ldr	x1, [sp, #0x130]
    3068:      	ldr	x8, [sp, #0x150]
    306c:      	str	x8, [x21, #0x120]
    3070:      	ldp	q1, q0, [sp, #0x130]
    3074:      	stp	q1, q0, [x21, #0x100]
    3078:      	str	x8, [x23, #0x20]
    307c:      	ldr	x8, [sp, #0x5b8]
    3080:      	ldr	x9, [sp, #0x5e8]
    3084:      	adds	x8, x8, x9
    3088:      	csinv	x8, x8, xzr, lo
    308c:      	stp	q1, q0, [x23]
    3090:      	cmp	x1, #0x2
    3094:      	b.hi	0x30f0 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x5d0>
    3098:      	sub	x9, x1, x1, lsr #2
    309c:      	cmp	x8, x9
    30a0:      	b.lo	0x30f0 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x5d0>
    30a4:      	ldr	x8, [sp, #0x150]
    30a8:      	str	x8, [x21, #0x170]
    30ac:      	ldp	q1, q0, [sp, #0x130]
    30b0:      	stp	q1, q0, [x21, #0x150]
    30b4:      	ldr	x8, [sp, #0x608]
    30b8:      	cmp	x8, x1, lsr #1
    30bc:      	b.lo	0x30d8 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x5b8>
    30c0:      	cbz	x1, 0x30d4 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x5b4>
    30c4:      	cmp	x1, #0x1
    30c8:      	mov	w8, #0x2                ; =2
    30cc:      	cinc	x1, x8, ne
    30d0:      	b	0x30d8 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x5b8>
    30d4:      	mov	w1, #0x1                ; =1
    30d8:      	add	x0, sp, #0x130
    30dc:      	add	x2, sp, #0x160
    30e0:      	bl	0x30e0 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x5c0>
		00000000000030e0:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07
    30e4:      	str	w0, [sp, #0x618]
    30e8:      	strb	w1, [sp, #0x61c]
    30ec:      	strb	w2, [sp, #0x61d]
    30f0:      	add	x0, sp, #0x390
    30f4:      	add	x1, sp, #0x130
    30f8:      	add	x3, sp, #0x4a0
    30fc:      	add	x4, sp, #0x160
    3100:      	mov	w2, #0x5                ; =5
    3104:      	bl	0x3104 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x5e4>
		0000000000003104:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07
    3108:      	add	x0, sp, #0x390
    310c:      	add	x1, sp, #0x110
    3110:      	bl	0x3110 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x5f0>
		0000000000003110:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
    3114:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003114:  ARM64_RELOC_PAGE21	lCPI67_15
    3118:      	ldr	q0, [x8]
		0000000000003118:  ARM64_RELOC_PAGEOFF12	lCPI67_15
    311c:      	ldr	q5, [sp, #0x100]
    3120:      	add.2d	v0, v5, v0
    3124:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003124:  ARM64_RELOC_PAGE21	lCPI67_16
    3128:      	ldr	q1, [x8]
		0000000000003128:  ARM64_RELOC_PAGEOFF12	lCPI67_16
    312c:      	add.2d	v1, v5, v1
    3130:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003130:  ARM64_RELOC_PAGE21	lCPI67_17
    3134:      	ldr	q2, [x8]
		0000000000003134:  ARM64_RELOC_PAGEOFF12	lCPI67_17
    3138:      	add.2d	v2, v5, v2
    313c:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		000000000000313c:  ARM64_RELOC_PAGE21	lCPI67_18
    3140:      	ldr	q3, [x8]
		0000000000003140:  ARM64_RELOC_PAGEOFF12	lCPI67_18
    3144:      	add.2d	v3, v5, v3
    3148:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003148:  ARM64_RELOC_PAGE21	lCPI67_19
    314c:      	ldr	q4, [x8]
		000000000000314c:  ARM64_RELOC_PAGEOFF12	lCPI67_19
    3150:      	add.2d	v4, v5, v4
    3154:      	add	x8, x19, #0x14
    3158:      	add	x9, x19, #0x15
    315c:      	add	x10, x19, #0x16
    3160:      	str	q0, [sp, #0x4a0]
    3164:      	str	q1, [sp, #0x4b0]
    3168:      	add	x11, x19, #0x17
    316c:      	add	x12, x19, #0x18
    3170:      	add	x13, x19, #0x19
    3174:      	add	x14, x19, #0x1a
    3178:      	str	q2, [sp, #0x4c0]
    317c:      	str	q3, [sp, #0x4d0]
    3180:      	add	x15, x19, #0x1b
    3184:      	add	x16, x19, #0x1c
    3188:      	str	q4, [sp, #0x4e0]
    318c:      	add	x17, x19, #0x1d
    3190:      	add	x0, x19, #0x1e
    3194:      	add	x1, x19, #0x1f
    3198:      	add	x25, x19, #0x20
    319c:      	str	x8, [sp, #0xe0]
    31a0:      	str	x8, [sp, #0x4f0]
    31a4:      	str	x9, [sp, #0xd0]
    31a8:      	str	x9, [sp, #0x4f8]
    31ac:      	add	x26, x19, #0x22
    31b0:      	add	x27, x19, #0x23
    31b4:      	add	x28, x19, #0x24
    31b8:      	add	x20, x19, #0x25
    31bc:      	str	x10, [sp, #0xc0]
    31c0:      	str	x10, [sp, #0x500]
    31c4:      	str	x11, [sp, #0xb0]
    31c8:      	str	x11, [sp, #0x508]
    31cc:      	add	x22, x19, #0x26
    31d0:      	add	x21, x19, #0x27
    31d4:      	add	x23, x19, #0x28
    31d8:      	add	x19, x19, #0x29
    31dc:      	str	x12, [sp, #0xa0]
    31e0:      	str	x12, [sp, #0x510]
    31e4:      	str	x13, [sp, #0x90]
    31e8:      	str	x13, [sp, #0x518]
    31ec:      	add	x8, sp, #0x4a0
    31f0:      	add	x8, x8, #0x128
    31f4:      	str	x14, [sp, #0x80]
    31f8:      	str	x14, [sp, #0x520]
    31fc:      	str	x15, [sp, #0x70]
    3200:      	str	x15, [sp, #0x528]
    3204:      	str	x16, [sp, #0x60]
    3208:      	str	x16, [sp, #0x530]
    320c:      	str	x17, [sp, #0x50]
    3210:      	str	x17, [sp, #0x538]
    3214:      	str	x0, [sp, #0x40]
    3218:      	str	x0, [sp, #0x540]
    321c:      	str	x1, [sp, #0x30]
    3220:      	str	x1, [sp, #0x548]
    3224:      	str	x25, [sp, #0x550]
    3228:      	str	x24, [sp, #0xf0]
    322c:      	str	x24, [sp, #0x558]
    3230:      	str	x26, [sp, #0x560]
    3234:      	str	x27, [sp, #0x568]
    3238:      	str	x28, [sp, #0x570]
    323c:      	str	x20, [sp, #0x578]
    3240:      	str	x22, [sp, #0x580]
    3244:      	str	x21, [sp, #0x588]
    3248:      	str	x23, [sp, #0x590]
    324c:      	str	x19, [sp, #0x598]
    3250:      	ldr	x1, [sp, #0x130]
    3254:      	ldr	x9, [sp, #0x150]
    3258:      	ldp	q1, q0, [sp, #0x130]
    325c:      	str	q0, [sp, #0x5b0]
    3260:      	str	q1, [sp, #0x5a0]
    3264:      	ldr	x10, [sp, #0x5b8]
    3268:      	stp	q1, q0, [x8]
    326c:      	adds	x8, x10, x9
    3270:      	csinv	x8, x8, xzr, lo
    3274:      	str	x9, [sp, #0x5c0]
    3278:      	str	x9, [sp, #0x5e8]
    327c:      	cmp	x1, #0x2
    3280:      	b.hi	0x32e0 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x7c0>
    3284:      	sub	x9, x1, x1, lsr #2
    3288:      	cmp	x8, x9
    328c:      	b.lo	0x32e0 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x7c0>
    3290:      	ldp	q1, q0, [sp, #0x130]
    3294:      	str	q0, [sp, #0x600]
    3298:      	str	q1, [sp, #0x5f0]
    329c:      	ldr	x8, [sp, #0x150]
    32a0:      	str	x8, [sp, #0x610]
    32a4:      	ldr	x8, [sp, #0x608]
    32a8:      	cmp	x8, x1, lsr #1
    32ac:      	b.lo	0x32c8 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x7a8>
    32b0:      	cbz	x1, 0x32c4 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x7a4>
    32b4:      	cmp	x1, #0x1
    32b8:      	mov	w8, #0x2                ; =2
    32bc:      	cinc	x1, x8, ne
    32c0:      	b	0x32c8 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x7a8>
    32c4:      	mov	w1, #0x1                ; =1
    32c8:      	add	x0, sp, #0x130
    32cc:      	add	x2, sp, #0x160
    32d0:      	bl	0x32d0 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x7b0>
		00000000000032d0:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07
    32d4:      	str	w0, [sp, #0x618]
    32d8:      	strb	w1, [sp, #0x61c]
    32dc:      	strb	w2, [sp, #0x61d]
    32e0:      	add	x24, sp, #0x4a0
    32e4:      	add	x0, sp, #0x280
    32e8:      	add	x1, sp, #0x130
    32ec:      	add	x3, sp, #0x4a0
    32f0:      	add	x4, sp, #0x160
    32f4:      	mov	w2, #0x1                ; =1
    32f8:      	bl	0x32f8 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x7d8>
		00000000000032f8:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07
    32fc:      	add	x0, sp, #0x280
    3300:      	add	x1, sp, #0x110
    3304:      	bl	0x3304 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x7e4>
		0000000000003304:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
    3308:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003308:  ARM64_RELOC_PAGE21	lCPI67_20
    330c:      	ldr	q0, [x8]
		000000000000330c:  ARM64_RELOC_PAGEOFF12	lCPI67_20
    3310:      	ldr	q5, [sp, #0x100]
    3314:      	add.2d	v0, v5, v0
    3318:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003318:  ARM64_RELOC_PAGE21	lCPI67_21
    331c:      	ldr	q1, [x8]
		000000000000331c:  ARM64_RELOC_PAGEOFF12	lCPI67_21
    3320:      	add.2d	v1, v5, v1
    3324:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003324:  ARM64_RELOC_PAGE21	lCPI67_22
    3328:      	ldr	q2, [x8]
		0000000000003328:  ARM64_RELOC_PAGEOFF12	lCPI67_22
    332c:      	add.2d	v2, v5, v2
    3330:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003330:  ARM64_RELOC_PAGE21	lCPI67_23
    3334:      	ldr	q3, [x8]
		0000000000003334:  ARM64_RELOC_PAGEOFF12	lCPI67_23
    3338:      	add.2d	v3, v5, v3
    333c:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		000000000000333c:  ARM64_RELOC_PAGE21	lCPI67_24
    3340:      	ldr	q4, [x8]
		0000000000003340:  ARM64_RELOC_PAGEOFF12	lCPI67_24
    3344:      	add.2d	v4, v5, v4
    3348:      	add	x8, x24, #0x128
    334c:      	ldr	x9, [sp, #0xe0]
    3350:      	str	x9, [sp, #0x4a0]
    3354:      	ldr	x9, [sp, #0xd0]
    3358:      	str	x9, [sp, #0x4a8]
    335c:      	ldr	x9, [sp, #0xc0]
    3360:      	str	x9, [sp, #0x4b0]
    3364:      	ldr	x9, [sp, #0xb0]
    3368:      	str	x9, [sp, #0x4b8]
    336c:      	ldr	x9, [sp, #0xa0]
    3370:      	str	x9, [sp, #0x4c0]
    3374:      	ldr	x9, [sp, #0x90]
    3378:      	str	x9, [sp, #0x4c8]
    337c:      	ldr	x9, [sp, #0x80]
    3380:      	str	x9, [sp, #0x4d0]
    3384:      	ldr	x9, [sp, #0x70]
    3388:      	str	x9, [sp, #0x4d8]
    338c:      	ldr	x9, [sp, #0x60]
    3390:      	str	x9, [sp, #0x4e0]
    3394:      	ldr	x9, [sp, #0x50]
    3398:      	str	x9, [sp, #0x4e8]
    339c:      	ldr	x9, [sp, #0x40]
    33a0:      	str	x9, [sp, #0x4f0]
    33a4:      	ldr	x9, [sp, #0x30]
    33a8:      	str	x9, [sp, #0x4f8]
    33ac:      	str	x25, [sp, #0x500]
    33b0:      	ldr	x9, [sp, #0xf0]
    33b4:      	str	x9, [sp, #0x508]
    33b8:      	str	x26, [sp, #0x510]
    33bc:      	str	x27, [sp, #0x518]
    33c0:      	str	x28, [sp, #0x520]
    33c4:      	str	x20, [sp, #0x528]
    33c8:      	str	x22, [sp, #0x530]
    33cc:      	str	x21, [sp, #0x538]
    33d0:      	str	x23, [sp, #0x540]
    33d4:      	str	x19, [sp, #0x548]
    33d8:      	str	q0, [sp, #0x550]
    33dc:      	str	q1, [sp, #0x560]
    33e0:      	str	q2, [sp, #0x570]
    33e4:      	str	q3, [sp, #0x580]
    33e8:      	ldr	x1, [sp, #0x130]
    33ec:      	ldp	q1, q0, [sp, #0x130]
    33f0:      	str	q0, [sp, #0x5b0]
    33f4:      	ldr	x9, [sp, #0x150]
    33f8:      	str	q4, [sp, #0x590]
    33fc:      	str	q1, [sp, #0x5a0]
    3400:      	ldr	x10, [sp, #0x5b8]
    3404:      	stp	q1, q0, [x8]
    3408:      	adds	x8, x10, x9
    340c:      	csinv	x8, x8, xzr, lo
    3410:      	str	x9, [sp, #0x5c0]
    3414:      	str	x9, [sp, #0x5e8]
    3418:      	cmp	x1, #0x2
    341c:      	mov	x19, #0x7c15            ; =31765
    3420:      	movk	x19, #0x7f4a, lsl #16
    3424:      	movk	x19, #0x79b9, lsl #32
    3428:      	movk	x19, #0x9e37, lsl #48
    342c:      	b.hi	0x348c <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x96c>
    3430:      	sub	x9, x1, x1, lsr #2
    3434:      	cmp	x8, x9
    3438:      	b.lo	0x348c <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x96c>
    343c:      	ldp	q1, q0, [sp, #0x130]
    3440:      	str	q0, [sp, #0x600]
    3444:      	str	q1, [sp, #0x5f0]
    3448:      	ldr	x8, [sp, #0x150]
    344c:      	str	x8, [sp, #0x610]
    3450:      	ldr	x8, [sp, #0x608]
    3454:      	cmp	x8, x1, lsr #1
    3458:      	b.lo	0x3474 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x954>
    345c:      	cbz	x1, 0x3470 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x950>
    3460:      	cmp	x1, #0x1
    3464:      	mov	w8, #0x2                ; =2
    3468:      	cinc	x1, x8, ne
    346c:      	b	0x3474 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x954>
    3470:      	mov	w1, #0x1                ; =1
    3474:      	add	x0, sp, #0x130
    3478:      	add	x2, sp, #0x160
    347c:      	bl	0x347c <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x95c>
		000000000000347c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07
    3480:      	str	w0, [sp, #0x618]
    3484:      	strb	w1, [sp, #0x61c]
    3488:      	strb	w2, [sp, #0x61d]
    348c:      	add	x0, sp, #0x170
    3490:      	add	x1, sp, #0x130
    3494:      	add	x3, sp, #0x4a0
    3498:      	add	x4, sp, #0x160
    349c:      	mov	w2, #0x7                ; =7
    34a0:      	bl	0x34a0 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x980>
		00000000000034a0:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07
    34a4:      	add	x0, sp, #0x170
    34a8:      	add	x1, sp, #0x110
    34ac:      	bl	0x34ac <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x98c>
		00000000000034ac:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
    34b0:      	add	x0, sp, #0x130
    34b4:      	add	x1, sp, #0x110
    34b8:      	bl	0x34b8 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x998>
		00000000000034b8:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146
    34bc:      	ldp	x8, x9, [sp, #0x110]
    34c0:      	ldp	x10, x11, [sp, #0x120]
    34c4:      	eor	x8, x8, x8, lsr #30
    34c8:      	mov	x12, #0xe5b9            ; =58809
    34cc:      	movk	x12, #0x1ce4, lsl #16
    34d0:      	movk	x12, #0x476d, lsl #32
    34d4:      	movk	x12, #0xbf58, lsl #48
    34d8:      	mul	x8, x8, x12
    34dc:      	eor	x8, x8, x8, lsr #27
    34e0:      	mov	x13, #0x11eb            ; =4587
    34e4:      	movk	x13, #0x1331, lsl #16
    34e8:      	movk	x13, #0x49bb, lsl #32
    34ec:      	movk	x13, #0x94d0, lsl #48
    34f0:      	mul	x8, x8, x13
    34f4:      	eor	x9, x9, x9, lsr #30
    34f8:      	mul	x9, x9, x12
    34fc:      	eor	x9, x9, x9, lsr #27
    3500:      	mul	x9, x9, x13
    3504:      	eor	x12, x9, x8
    3508:      	mul	x11, x11, x19
    350c:      	eor	x10, x10, x11
    3510:      	eor	x10, x10, x12, lsr #31
    3514:      	eor	x8, x8, x9
    3518:      	eor	x0, x10, x8
    351c:      	add	sp, sp, #0x620
    3520:      	ldp	x29, x30, [sp, #0x50]
    3524:      	ldp	x20, x19, [sp, #0x40]
    3528:      	ldp	x22, x21, [sp, #0x30]
    352c:      	ldp	x24, x23, [sp, #0x20]
    3530:      	ldp	x26, x25, [sp, #0x10]
    3534:      	ldp	x28, x27, [sp], #0x60
    3538:      	ret
    353c:      	bl	0x353c <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0xa1c>
		000000000000353c:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

0000000000003540 <_wf_map_cost_library_trace$instance$4250cb78d3f44027>:
    3540:      	stp	x28, x27, [sp, #-0x60]!
    3544:      	stp	x26, x25, [sp, #0x10]
    3548:      	stp	x24, x23, [sp, #0x20]
    354c:      	stp	x22, x21, [sp, #0x30]
    3550:      	stp	x20, x19, [sp, #0x40]
    3554:      	stp	x29, x30, [sp, #0x50]
    3558:      	mov	w9, #0x1ca0             ; =7328
    355c:      	adrp	x16, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		000000000000355c:  ARM64_RELOC_GOT_LOAD_PAGE21	___chkstk_darwin
    3560:      	ldr	x16, [x16]
		0000000000003560:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	___chkstk_darwin
    3564:      	blr	x16
    3568:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
    356c:      	sub	sp, sp, #0xca0
    3570:      	str	x4, [sp, #0x2e0]
    3574:      	str	x2, [sp, #0xe8]
    3578:      	mov	x19, x1
    357c:      	mov	x20, x0
    3580:      	add	x6, sp, #0x350
    3584:      	mov	x8, #0x7c15             ; =31765
    3588:      	movk	x8, #0x7f4a, lsl #16
    358c:      	movk	x8, #0x79b9, lsl #32
    3590:      	movk	x8, #0x9e37, lsl #48
    3594:      	str	x3, [sp, #0xa0]
    3598:      	eor	x8, x3, x8
    359c:      	cmp	x5, #0x0
    35a0:      	cset	w9, ne
    35a4:      	mov	w10, #0x1768            ; =5992
    35a8:      	str	x8, [sp, #0x1ab0]
    35ac:      	strb	w9, [x6, x10]
    35b0:      	cbz	x0, 0x3610 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xd0>
    35b4:      	add	x8, x20, x20, lsl #4
    35b8:      	lsl	x0, x8, #4
    35bc:      	bl	0x35bc <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x7c>
		00000000000035bc:  ARM64_RELOC_BRANCH26	_malloc
    35c0:      	cbz	x0, 0x58f4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x23b4>
    35c4:      	mov	x8, #0x0                ; =0
    35c8:      	add	x9, x0, #0x8
    35cc:      	movi.2d	v0, #0000000000000000
    35d0:      	stur	wzr, [x9, #-0x8]
    35d4:      	add	x8, x8, #0x1
    35d8:      	stp	q0, q0, [x9]
    35dc:      	stp	q0, q0, [x9, #0x20]
    35e0:      	stp	q0, q0, [x9, #0x40]
    35e4:      	stp	q0, q0, [x9, #0x60]
    35e8:      	stp	q0, q0, [x9, #0x80]
    35ec:      	stp	q0, q0, [x9, #0xa0]
    35f0:      	stp	q0, q0, [x9, #0xc0]
    35f4:      	stp	q0, q0, [x9, #0xe0]
    35f8:      	str	xzr, [x9, #0x100]
    35fc:      	add	x9, x9, #0x110
    3600:      	cmp	x20, x8
    3604:      	b.ne	0x35d0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x90>
    3608:      	add	x6, sp, #0x350
    360c:      	b	0x3618 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xd8>
    3610:      	adrp	x0, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003610:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    3614:      	add	x0, x0, #0x0
		0000000000003614:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    3618:      	str	x20, [sp, #0x1ac0]
    361c:      	add	x8, x6, #0x104
    3620:      	str	x8, [sp, #0x228]
    3624:      	str	x20, [sp, #0x230]
    3628:      	str	x20, [sp, #0x1ac8]
    362c:      	mov	w8, #0x1770             ; =6000
    3630:      	str	x0, [sp, #0x1ad0]
    3634:      	movi.2d	v0, #0000000000000000
    3638:      	mov	w9, #0x1788             ; =6024
    363c:      	str	q0, [x6, x9]
    3640:      	add	x8, x6, x8
    3644:      	str	x8, [sp, #0x348]
    3648:      	mov	w8, #0x1798             ; =6040
    364c:      	ldr	x9, [sp, #0xa0]
    3650:      	str	x9, [sp, #0x1ae8]
    3654:      	add	x8, x6, x8
    3658:      	str	x8, [sp, #0x8]
    365c:      	str	xzr, [sp, #0x1af0]
    3660:      	str	xzr, [sp, #0x1b00]
    3664:      	str	xzr, [sp, #0x1af8]
    3668:      	str	x19, [sp, #0xc0]
    366c:      	cbz	x19, 0x3b04 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x5c4>
    3670:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003670:  ARM64_RELOC_PAGE21	lCPI68_0
    3674:      	ldr	q0, [x8]
		0000000000003674:  ARM64_RELOC_PAGEOFF12	lCPI68_0
    3678:      	str	q0, [sp, #0x330]
    367c:      	add	x19, x6, #0x318
    3680:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003680:  ARM64_RELOC_PAGE21	lCPI68_1
    3684:      	ldr	q0, [x8]
		0000000000003684:  ARM64_RELOC_PAGEOFF12	lCPI68_1
    3688:      	str	q0, [sp, #0x320]
    368c:      	add	x20, sp, #0x1, lsl #12  ; =0x1000
    3690:      	add	x20, x20, #0xb20
    3694:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003694:  ARM64_RELOC_PAGE21	lCPI68_2
    3698:      	ldr	q0, [x8]
		0000000000003698:  ARM64_RELOC_PAGEOFF12	lCPI68_2
    369c:      	str	q0, [sp, #0x310]
    36a0:      	add	x22, x20, #0x128
    36a4:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		00000000000036a4:  ARM64_RELOC_PAGE21	lCPI68_3
    36a8:      	ldr	q0, [x8]
		00000000000036a8:  ARM64_RELOC_PAGEOFF12	lCPI68_3
    36ac:      	str	q0, [sp, #0x300]
    36b0:      	add	x23, sp, #0x350
    36b4:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		00000000000036b4:  ARM64_RELOC_PAGE21	lCPI68_4
    36b8:      	ldr	q0, [x8]
		00000000000036b8:  ARM64_RELOC_PAGEOFF12	lCPI68_4
    36bc:      	str	q0, [sp, #0x2f0]
    36c0:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		00000000000036c0:  ARM64_RELOC_PAGE21	lCPI68_5
    36c4:      	ldr	q0, [x8]
		00000000000036c4:  ARM64_RELOC_PAGEOFF12	lCPI68_5
    36c8:      	str	q0, [sp, #0x2d0]
    36cc:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		00000000000036cc:  ARM64_RELOC_PAGE21	lCPI68_6
    36d0:      	ldr	q0, [x8]
		00000000000036d0:  ARM64_RELOC_PAGEOFF12	lCPI68_6
    36d4:      	str	q0, [sp, #0x2c0]
    36d8:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		00000000000036d8:  ARM64_RELOC_PAGE21	lCPI68_7
    36dc:      	ldr	q0, [x8]
		00000000000036dc:  ARM64_RELOC_PAGEOFF12	lCPI68_7
    36e0:      	str	q0, [sp, #0x2b0]
    36e4:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		00000000000036e4:  ARM64_RELOC_PAGE21	lCPI68_8
    36e8:      	ldr	q0, [x8]
		00000000000036e8:  ARM64_RELOC_PAGEOFF12	lCPI68_8
    36ec:      	str	q0, [sp, #0x2a0]
    36f0:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		00000000000036f0:  ARM64_RELOC_PAGE21	lCPI68_9
    36f4:      	ldr	q0, [x8]
		00000000000036f4:  ARM64_RELOC_PAGEOFF12	lCPI68_9
    36f8:      	str	q0, [sp, #0x290]
    36fc:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		00000000000036fc:  ARM64_RELOC_PAGE21	lCPI68_10
    3700:      	ldr	q0, [x8]
		0000000000003700:  ARM64_RELOC_PAGEOFF12	lCPI68_10
    3704:      	str	q0, [sp, #0x280]
    3708:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003708:  ARM64_RELOC_PAGE21	lCPI68_11
    370c:      	ldr	q0, [x8]
		000000000000370c:  ARM64_RELOC_PAGEOFF12	lCPI68_11
    3710:      	str	q0, [sp, #0x270]
    3714:      	mov	w26, #0x83              ; =131
    3718:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003718:  ARM64_RELOC_PAGE21	lCPI68_12
    371c:      	ldr	q0, [x8]
		000000000000371c:  ARM64_RELOC_PAGEOFF12	lCPI68_12
    3720:      	str	q0, [sp, #0x260]
    3724:      	mov	w21, #0x1               ; =1
    3728:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003728:  ARM64_RELOC_PAGE21	lCPI68_13
    372c:      	ldr	q0, [x8]
		000000000000372c:  ARM64_RELOC_PAGEOFF12	lCPI68_13
    3730:      	str	q0, [sp, #0x250]
    3734:      	ldr	x27, [sp, #0xc0]
    3738:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003738:  ARM64_RELOC_PAGE21	lCPI68_14
    373c:      	ldr	q0, [x8]
		000000000000373c:  ARM64_RELOC_PAGEOFF12	lCPI68_14
    3740:      	str	q0, [sp, #0x240]
    3744:      	ldr	x28, [sp, #0xa0]
    3748:      	b	0x38d8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x398>
    374c:      	ldr	x8, [sp, #0x228]
    3750:      	ldrb	w25, [x8]
    3754:      	add	x0, x24, #0x210
    3758:      	add	x1, x23, #0x108
    375c:      	mov	w2, #0x108              ; =264
    3760:      	bl	0x3760 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x220>
		0000000000003760:  ARM64_RELOC_BRANCH26	_memcpy
    3764:      	ldr	x8, [sp, #0x1ae8]
    3768:      	cmp	w25, #0x0
    376c:      	mov	w9, #0x1                ; =1
    3770:      	cinc	x9, x9, ne
    3774:      	madd	x8, x8, x26, x9
    3778:      	ldr	x9, [sp, #0x560]
    377c:      	ldp	q1, q0, [x23, #0x170]
    3780:      	stp	q1, q0, [x19, #0x60]
    3784:      	ldp	q1, q0, [x23, #0x150]
    3788:      	stp	q1, q0, [x19, #0x40]
    378c:      	ldp	q1, q0, [x23, #0x1b0]
    3790:      	stp	q1, q0, [x19, #0xa0]
    3794:      	ldp	q1, q0, [x23, #0x190]
    3798:      	stp	q1, q0, [x19, #0x80]
    379c:      	ldp	q1, q0, [x23, #0x1f0]
    37a0:      	stp	q1, q0, [x19, #0xe0]
    37a4:      	ldp	q1, q0, [x23, #0x1d0]
    37a8:      	stp	q1, q0, [x19, #0xc0]
    37ac:      	ldp	q1, q0, [x23, #0x130]
    37b0:      	stp	q1, q0, [x19, #0x20]
    37b4:      	ldp	q0, q1, [x23, #0x110]
    37b8:      	stp	q0, q1, [x19]
    37bc:      	ldr	x10, [sp, #0x668]
    37c0:      	madd	x9, x9, x26, x10
    37c4:      	ldr	x10, [sp, #0x670]
    37c8:      	madd	x9, x9, x26, x10
    37cc:      	ldr	x10, [sp, #0x678]
    37d0:      	madd	x9, x9, x26, x10
    37d4:      	ldr	x10, [sp, #0x680]
    37d8:      	madd	x9, x9, x26, x10
    37dc:      	ldr	x10, [sp, #0x688]
    37e0:      	madd	x9, x9, x26, x10
    37e4:      	ldr	x10, [sp, #0x690]
    37e8:      	madd	x9, x9, x26, x10
    37ec:      	ldr	x10, [sp, #0x698]
    37f0:      	madd	x9, x9, x26, x10
    37f4:      	ldr	x10, [sp, #0x6a0]
    37f8:      	madd	x9, x9, x26, x10
    37fc:      	ldr	x10, [sp, #0x6a8]
    3800:      	madd	x9, x9, x26, x10
    3804:      	ldr	x10, [sp, #0x6b0]
    3808:      	madd	x9, x9, x26, x10
    380c:      	ldr	x10, [sp, #0x6b8]
    3810:      	madd	x9, x9, x26, x10
    3814:      	ldr	x10, [sp, #0x6c0]
    3818:      	madd	x9, x9, x26, x10
    381c:      	ldr	x10, [sp, #0x6c8]
    3820:      	madd	x9, x9, x26, x10
    3824:      	ldr	x10, [sp, #0x6d0]
    3828:      	madd	x9, x9, x26, x10
    382c:      	ldr	x10, [sp, #0x6d8]
    3830:      	madd	x9, x9, x26, x10
    3834:      	ldr	x10, [sp, #0x6e0]
    3838:      	madd	x9, x9, x26, x10
    383c:      	ldr	x10, [sp, #0x6e8]
    3840:      	madd	x9, x9, x26, x10
    3844:      	ldr	x10, [sp, #0x6f0]
    3848:      	madd	x9, x9, x26, x10
    384c:      	ldr	x10, [sp, #0x6f8]
    3850:      	madd	x9, x9, x26, x10
    3854:      	ldr	x10, [sp, #0x700]
    3858:      	madd	x9, x9, x26, x10
    385c:      	ldr	x10, [sp, #0x708]
    3860:      	madd	x9, x9, x26, x10
    3864:      	ldr	x10, [sp, #0x710]
    3868:      	madd	x9, x9, x26, x10
    386c:      	ldr	x10, [sp, #0x718]
    3870:      	madd	x9, x9, x26, x10
    3874:      	ldr	x10, [sp, #0x720]
    3878:      	madd	x9, x9, x26, x10
    387c:      	ldr	x10, [sp, #0x728]
    3880:      	madd	x9, x9, x26, x10
    3884:      	ldr	x10, [sp, #0x730]
    3888:      	madd	x9, x9, x26, x10
    388c:      	ldr	x10, [sp, #0x738]
    3890:      	madd	x9, x9, x26, x10
    3894:      	ldr	x10, [sp, #0x740]
    3898:      	madd	x9, x9, x26, x10
    389c:      	ldr	x10, [sp, #0x748]
    38a0:      	madd	x9, x9, x26, x10
    38a4:      	ldr	x10, [sp, #0x750]
    38a8:      	madd	x9, x9, x26, x10
    38ac:      	ldr	x10, [sp, #0x758]
    38b0:      	add	x8, x8, x10
    38b4:      	madd	x8, x9, x26, x8
    38b8:      	ldr	x9, [sp, #0x760]
    38bc:      	madd	x8, x8, x26, x9
    38c0:      	str	x8, [sp, #0x1ae8]
    38c4:      	add	x28, x28, #0x1
    38c8:      	add	x21, x21, #0x2
    38cc:      	subs	x27, x27, #0x1
    38d0:      	add	x6, sp, #0x350
    38d4:      	b.eq	0x3b04 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x5c4>
    38d8:      	add	x8, x28, #0x1f
    38dc:      	str	x28, [sp, #0x350]
    38e0:      	dup.2d	v0, x28
    38e4:      	ldr	q1, [sp, #0x330]
    38e8:      	add.2d	v1, v0, v1
    38ec:      	add	x9, sp, #0x259
    38f0:      	stur	q1, [x9, #0xff]
    38f4:      	ldr	q1, [sp, #0x320]
    38f8:      	add.2d	v1, v0, v1
    38fc:      	add	x9, sp, #0x269
    3900:      	stur	q1, [x9, #0xff]
    3904:      	ldr	q1, [sp, #0x310]
    3908:      	add.2d	v1, v0, v1
    390c:      	add	x9, sp, #0x279
    3910:      	stur	q1, [x9, #0xff]
    3914:      	ldr	q1, [sp, #0x300]
    3918:      	add.2d	v1, v0, v1
    391c:      	add	x9, sp, #0x289
    3920:      	stur	q1, [x9, #0xff]
    3924:      	ldr	q1, [sp, #0x2f0]
    3928:      	add.2d	v1, v0, v1
    392c:      	add	x9, sp, #0x299
    3930:      	stur	q1, [x9, #0xff]
    3934:      	ldr	q1, [sp, #0x2d0]
    3938:      	add.2d	v1, v0, v1
    393c:      	add	x9, sp, #0x2a9
    3940:      	stur	q1, [x9, #0xff]
    3944:      	ldr	q1, [sp, #0x2c0]
    3948:      	add.2d	v1, v0, v1
    394c:      	add	x9, sp, #0x2b9
    3950:      	stur	q1, [x9, #0xff]
    3954:      	ldr	q1, [sp, #0x2b0]
    3958:      	add.2d	v1, v0, v1
    395c:      	add	x9, sp, #0x2c9
    3960:      	stur	q1, [x9, #0xff]
    3964:      	ldr	q1, [sp, #0x2a0]
    3968:      	add.2d	v1, v0, v1
    396c:      	stur	q1, [x6, #0x88]
    3970:      	ldr	q1, [sp, #0x290]
    3974:      	add.2d	v1, v0, v1
    3978:      	stur	q1, [x6, #0x98]
    397c:      	ldr	q1, [sp, #0x280]
    3980:      	add.2d	v1, v0, v1
    3984:      	stur	q1, [x6, #0xa8]
    3988:      	ldr	q1, [sp, #0x270]
    398c:      	add.2d	v1, v0, v1
    3990:      	stur	q1, [x6, #0xb8]
    3994:      	ldr	q1, [sp, #0x260]
    3998:      	add.2d	v1, v0, v1
    399c:      	stur	q1, [x6, #0xc8]
    39a0:      	ldr	q1, [sp, #0x250]
    39a4:      	add.2d	v1, v0, v1
    39a8:      	stur	q1, [x6, #0xd8]
    39ac:      	ldr	q1, [sp, #0x240]
    39b0:      	add.2d	v0, v0, v1
    39b4:      	stur	q0, [x6, #0xe8]
    39b8:      	str	x8, [sp, #0x448]
    39bc:      	ldr	q0, [sp, #0x410]
    39c0:      	ldr	q1, [sp, #0x420]
    39c4:      	str	q0, [sp, #0x1be0]
    39c8:      	str	q1, [sp, #0x1bf0]
    39cc:      	ldr	q0, [sp, #0x430]
    39d0:      	ldr	q1, [sp, #0x440]
    39d4:      	str	q0, [sp, #0x1c00]
    39d8:      	str	q1, [sp, #0x1c10]
    39dc:      	ldp	q0, q1, [sp, #0x3d0]
    39e0:      	str	q0, [sp, #0x1ba0]
    39e4:      	str	q1, [sp, #0x1bb0]
    39e8:      	ldp	q0, q1, [sp, #0x3f0]
    39ec:      	str	q0, [sp, #0x1bc0]
    39f0:      	str	q1, [sp, #0x1bd0]
    39f4:      	ldp	q0, q1, [sp, #0x390]
    39f8:      	str	q0, [sp, #0x1b60]
    39fc:      	str	q1, [sp, #0x1b70]
    3a00:      	ldp	q0, q1, [sp, #0x3b0]
    3a04:      	str	q0, [sp, #0x1b80]
    3a08:      	str	q1, [sp, #0x1b90]
    3a0c:      	ldp	q0, q1, [sp, #0x350]
    3a10:      	str	q0, [sp, #0x1b20]
    3a14:      	str	q1, [sp, #0x1b30]
    3a18:      	ldp	q0, q1, [sp, #0x370]
    3a1c:      	str	q0, [sp, #0x1b40]
    3a20:      	str	q1, [sp, #0x1b50]
    3a24:      	ldr	x1, [sp, #0x1ac0]
    3a28:      	ldr	x9, [sp, #0x348]
    3a2c:      	ldr	x8, [x9, #0x20]
    3a30:      	str	x8, [x20, #0x120]
    3a34:      	ldp	q1, q0, [x9]
    3a38:      	stp	q1, q0, [x20, #0x100]
    3a3c:      	str	x8, [x22, #0x20]
    3a40:      	ldr	x8, [sp, #0x1c38]
    3a44:      	ldr	x9, [sp, #0x1c68]
    3a48:      	adds	x8, x8, x9
    3a4c:      	csinv	x9, x8, xzr, lo
    3a50:      	lsr	x8, x1, #14
    3a54:      	stp	q1, q0, [x22]
    3a58:      	cbnz	x8, 0x3acc <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x58c>
    3a5c:      	sub	x8, x1, x1, lsr #2
    3a60:      	cmp	x9, x8
    3a64:      	b.lo	0x3acc <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x58c>
    3a68:      	ldr	x10, [sp, #0x348]
    3a6c:      	ldr	x9, [x10, #0x20]
    3a70:      	str	x9, [x20, #0x170]
    3a74:      	ldp	q1, q0, [x10]
    3a78:      	stp	q1, q0, [x20, #0x150]
    3a7c:      	ldr	x9, [sp, #0x1c88]
    3a80:      	cmp	x9, x8, lsr #1
    3a84:      	b.lo	0x3aa4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x564>
    3a88:      	cbz	x1, 0x3aa0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x560>
    3a8c:      	cmp	x1, #0x2, lsl #12       ; =0x2000
    3a90:      	mov	w8, #0x2000             ; =8192
    3a94:      	csel	x8, x1, x8, lo
    3a98:      	lsl	x1, x8, #1
    3a9c:      	b	0x3aa4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x564>
    3aa0:      	mov	w1, #0x1                ; =1
    3aa4:      	mov	w8, #0x1760             ; =5984
    3aa8:      	add	x2, x6, x8
    3aac:      	ldr	x0, [sp, #0x348]
    3ab0:      	bl	0x3ab0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x570>
		0000000000003ab0:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    3ab4:      	add	x6, sp, #0x350
    3ab8:      	str	w0, [sp, #0x1c98]
    3abc:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
    3ac0:      	add	x8, x8, #0xb20
    3ac4:      	strb	w1, [x8, #0x17c]
    3ac8:      	strb	w2, [x8, #0x17d]
    3acc:      	add	x0, x6, #0x100
    3ad0:      	add	x3, sp, #0x1, lsl #12   ; =0x1000
    3ad4:      	add	x3, x3, #0xb20
    3ad8:      	add	x24, sp, #0x350
    3adc:      	mov	w8, #0x1760             ; =5984
    3ae0:      	add	x4, x24, x8
    3ae4:      	ldr	x1, [sp, #0x348]
    3ae8:      	mov	x2, x21
    3aec:      	bl	0x3aec <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x5ac>
		0000000000003aec:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
    3af0:      	ldr	w8, [sp, #0x450]
    3af4:      	cbnz	w8, 0x374c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x20c>
    3af8:      	ldr	x8, [sp, #0x1ae8]
    3afc:      	mul	x8, x8, x26
    3b00:      	b	0x38c0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x380>
    3b04:      	ldr	x8, [sp, #0xe8]
    3b08:      	ldr	x22, [sp, #0xc0]
    3b0c:      	ldr	x23, [sp, #0x2e0]
    3b10:      	cbz	x8, 0x5820 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x22e0>
    3b14:      	ldr	x9, [sp, #0x230]
    3b18:      	lsl	x8, x9, #1
    3b1c:      	cmp	x9, #0x0
    3b20:      	csinc	x21, x8, xzr, ne
    3b24:      	cmp	x23, #0x1
    3b28:      	csel	x16, x22, xzr, eq
    3b2c:      	add	x14, sp, #0x350
    3b30:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
    3b34:      	add	x8, x8, #0xb20
    3b38:      	add	x8, x8, #0x128
    3b3c:      	str	x8, [sp, #0x330]
    3b40:      	cmp	x23, #0x5
    3b44:      	b.ne	0x46d0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1190>
    3b48:      	mov	x10, #0x0               ; =0
    3b4c:      	add	x20, x6, #0x418
    3b50:      	add	x8, x6, #0x630
    3b54:      	str	x8, [sp, #0x1b0]
    3b58:      	add	x25, x6, #0x768
    3b5c:      	add	x8, x6, #0xa80
    3b60:      	str	x8, [sp, #0x210]
    3b64:      	ldr	x9, [sp, #0x228]
    3b68:      	add	x8, x9, #0x324
    3b6c:      	str	x8, [sp, #0x1a0]
    3b70:      	add	x8, x9, #0x334
    3b74:      	str	x8, [sp, #0x190]
    3b78:      	add	x8, x9, #0x344
    3b7c:      	str	x8, [sp, #0x180]
    3b80:      	add	x8, x9, #0x354
    3b84:      	str	x8, [sp, #0x170]
    3b88:      	add	x8, x9, #0x364
    3b8c:      	str	x8, [sp, #0x160]
    3b90:      	add	x8, x9, #0x374
    3b94:      	str	x8, [sp, #0x150]
    3b98:      	add	x8, x9, #0x384
    3b9c:      	str	x8, [sp, #0x140]
    3ba0:      	add	x8, x9, #0x394
    3ba4:      	str	x8, [sp, #0x130]
    3ba8:      	add	x8, x9, #0x3a4
    3bac:      	str	x8, [sp, #0x120]
    3bb0:      	add	x8, x9, #0x3b4
    3bb4:      	str	x8, [sp, #0x110]
    3bb8:      	add	x8, x9, #0x3c4
    3bbc:      	str	x8, [sp, #0x100]
    3bc0:      	add	x8, x9, #0x3d4
    3bc4:      	str	x8, [sp, #0xf0]
    3bc8:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003bc8:  ARM64_RELOC_PAGE21	lCPI68_0
    3bcc:      	ldr	q0, [x8]
		0000000000003bcc:  ARM64_RELOC_PAGEOFF12	lCPI68_0
    3bd0:      	str	q0, [sp, #0x310]
    3bd4:      	add	x8, x9, #0x3e4
    3bd8:      	str	x8, [sp, #0xe0]
    3bdc:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003bdc:  ARM64_RELOC_PAGE21	lCPI68_1
    3be0:      	ldr	q0, [x8]
		0000000000003be0:  ARM64_RELOC_PAGEOFF12	lCPI68_1
    3be4:      	str	q0, [sp, #0x300]
    3be8:      	add	x8, x9, #0x3f4
    3bec:      	str	x8, [sp, #0xd8]
    3bf0:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003bf0:  ARM64_RELOC_PAGE21	lCPI68_2
    3bf4:      	ldr	q0, [x8]
		0000000000003bf4:  ARM64_RELOC_PAGEOFF12	lCPI68_2
    3bf8:      	str	q0, [sp, #0x2f0]
    3bfc:      	add	x8, x9, #0x404
    3c00:      	str	x8, [sp, #0xd0]
    3c04:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003c04:  ARM64_RELOC_PAGE21	lCPI68_3
    3c08:      	ldr	q0, [x8]
		0000000000003c08:  ARM64_RELOC_PAGEOFF12	lCPI68_3
    3c0c:      	str	q0, [sp, #0x2e0]
    3c10:      	add	x8, x9, #0x414
    3c14:      	str	x8, [sp, #0xc8]
    3c18:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003c18:  ARM64_RELOC_PAGE21	lCPI68_4
    3c1c:      	ldr	q0, [x8]
		0000000000003c1c:  ARM64_RELOC_PAGEOFF12	lCPI68_4
    3c20:      	str	q0, [sp, #0x2d0]
    3c24:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003c24:  ARM64_RELOC_PAGE21	lCPI68_5
    3c28:      	ldr	q0, [x8]
		0000000000003c28:  ARM64_RELOC_PAGEOFF12	lCPI68_5
    3c2c:      	str	q0, [sp, #0x2c0]
    3c30:      	sub	x8, x22, x22, lsr #1
    3c34:      	adrp	x9, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003c34:  ARM64_RELOC_PAGE21	lCPI68_6
    3c38:      	ldr	q0, [x9]
		0000000000003c38:  ARM64_RELOC_PAGEOFF12	lCPI68_6
    3c3c:      	str	q0, [sp, #0x2b0]
    3c40:      	cmp	x8, #0x1
    3c44:      	adrp	x9, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003c44:  ARM64_RELOC_PAGE21	lCPI68_7
    3c48:      	ldr	q0, [x9]
		0000000000003c48:  ARM64_RELOC_PAGEOFF12	lCPI68_7
    3c4c:      	str	q0, [sp, #0x2a0]
    3c50:      	csinc	x8, x8, xzr, hi
    3c54:      	str	x8, [sp, #0x320]
    3c58:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003c58:  ARM64_RELOC_PAGE21	lCPI68_8
    3c5c:      	ldr	q0, [x8]
		0000000000003c5c:  ARM64_RELOC_PAGEOFF12	lCPI68_8
    3c60:      	str	q0, [sp, #0x290]
    3c64:      	add	x19, x14, #0x878
    3c68:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003c68:  ARM64_RELOC_PAGE21	lCPI68_9
    3c6c:      	ldr	q0, [x8]
		0000000000003c6c:  ARM64_RELOC_PAGEOFF12	lCPI68_9
    3c70:      	str	q0, [sp, #0x280]
    3c74:      	ldr	x8, [sp, #0xa0]
    3c78:      	add	x8, x8, x22
    3c7c:      	str	x8, [sp, #0x1d0]
    3c80:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003c80:  ARM64_RELOC_PAGE21	lCPI68_10
    3c84:      	ldr	q0, [x8]
		0000000000003c84:  ARM64_RELOC_PAGEOFF12	lCPI68_10
    3c88:      	str	q0, [sp, #0x270]
    3c8c:      	mov	w26, #0x83              ; =131
    3c90:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003c90:  ARM64_RELOC_PAGE21	lCPI68_11
    3c94:      	ldr	q0, [x8]
		0000000000003c94:  ARM64_RELOC_PAGEOFF12	lCPI68_11
    3c98:      	str	q0, [sp, #0x260]
    3c9c:      	mov	w15, #0x1               ; =1
    3ca0:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003ca0:  ARM64_RELOC_PAGE21	lCPI68_12
    3ca4:      	ldr	q0, [x8]
		0000000000003ca4:  ARM64_RELOC_PAGEOFF12	lCPI68_12
    3ca8:      	str	q0, [sp, #0x250]
    3cac:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003cac:  ARM64_RELOC_PAGE21	lCPI68_13
    3cb0:      	ldr	q0, [x8]
		0000000000003cb0:  ARM64_RELOC_PAGEOFF12	lCPI68_13
    3cb4:      	str	q0, [sp, #0x240]
    3cb8:      	adrp	x8, 0x3000 <_wf_map_cost_library_policy$instance$4250cb78d3f44027+0x4e0>
		0000000000003cb8:  ARM64_RELOC_PAGE21	lCPI68_14
    3cbc:      	ldr	q0, [x8]
		0000000000003cbc:  ARM64_RELOC_PAGEOFF12	lCPI68_14
    3cc0:      	str	q0, [sp, #0x230]
    3cc4:      	mov	w24, #0x110             ; =272
    3cc8:      	b	0x3cf4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x7b4>
    3ccc:      	ldr	x10, [sp, #0x1e0]
    3cd0:      	add	x10, x10, #0x1
    3cd4:      	add	x6, sp, #0x350
    3cd8:      	mov	w15, #0x1               ; =1
    3cdc:      	ldr	x8, [sp, #0x1d0]
    3ce0:      	add	x8, x8, x22
    3ce4:      	str	x8, [sp, #0x1d0]
    3ce8:      	ldr	x8, [sp, #0xe8]
    3cec:      	cmp	x10, x8
    3cf0:      	b.eq	0x5820 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x22e0>
    3cf4:      	str	x10, [sp, #0x1e0]
    3cf8:      	ldr	x21, [sp, #0x1ac0]
    3cfc:      	cbz	x22, 0x4198 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xc58>
    3d00:      	mov	x28, #0x0               ; =0
    3d04:      	ldr	x17, [sp, #0x1ad8]
    3d08:      	ldr	x23, [sp, #0x1ab0]
    3d0c:      	mov	w8, #0x1768             ; =5992
    3d10:      	ldrb	w0, [x6, x8]
    3d14:      	ldr	x22, [sp, #0x1ad0]
    3d18:      	ldr	x2, [sp, #0x1ae0]
    3d1c:      	mov	x27, #0x11eb            ; =4587
    3d20:      	movk	x27, #0x1331, lsl #16
    3d24:      	movk	x27, #0x49bb, lsl #32
    3d28:      	movk	x27, #0x94d0, lsl #48
    3d2c:      	str	w0, [sp, #0x1c0]
    3d30:      	b	0x3d58 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x818>
    3d34:      	str	w15, [sp, #0xa80]
    3d38:      	str	xzr, [sp, #0xa88]
    3d3c:      	mul	x8, x8, x26
    3d40:      	strb	wzr, [sp, #0xa90]
    3d44:      	str	x8, [sp, #0x1ae8]
    3d48:      	add	x28, x28, #0x1
    3d4c:      	ldr	x8, [sp, #0x320]
    3d50:      	cmp	x28, x8
    3d54:      	b.eq	0x41ac <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xc6c>
    3d58:      	orr	x8, x15, x28, lsl #2
    3d5c:      	str	x8, [sp, #0x1b08]
    3d60:      	cbz	x17, 0x40c8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xb88>
    3d64:      	tbz	w0, #0x0, 0x3d74 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x834>
    3d68:      	mov	x9, #0x0                ; =0
    3d6c:      	cbnz	x21, 0x3da0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x860>
    3d70:      	b	0x40c8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xb88>
    3d74:      	eor	x9, x23, x8
    3d78:      	eor	x9, x9, x9, lsr #30
    3d7c:      	mov	x10, #0xe5b9            ; =58809
    3d80:      	movk	x10, #0x1ce4, lsl #16
    3d84:      	movk	x10, #0x476d, lsl #32
    3d88:      	movk	x10, #0xbf58, lsl #48
    3d8c:      	mul	x9, x9, x10
    3d90:      	eor	x9, x9, x9, lsr #27
    3d94:      	mul	x9, x9, x27
    3d98:      	eor	x9, x9, x9, lsr #31
    3d9c:      	cbz	x21, 0x40c8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xb88>
    3da0:      	udiv	x10, x9, x21
    3da4:      	msub	x10, x10, x21, x9
    3da8:      	mov	x11, x21
    3dac:      	b	0x3dc4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x884>
    3db0:      	add	x9, x10, #0x1
    3db4:      	cmp	x9, x21
    3db8:      	csinc	x10, xzr, x10, hs
    3dbc:      	subs	x11, x11, #0x1
    3dc0:      	b.eq	0x40c8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xb88>
    3dc4:      	madd	x9, x10, x24, x22
    3dc8:      	ldr	w12, [x9]
    3dcc:      	cmp	w12, #0x1
    3dd0:      	b.eq	0x3db0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x870>
    3dd4:      	cmp	w12, #0x2
    3dd8:      	b.ne	0x40c8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xb88>
    3ddc:      	ldr	x12, [x9, #0x8]
    3de0:      	cmp	x12, x8
    3de4:      	b.ne	0x3db0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x870>
    3de8:      	str	w15, [x9]
    3dec:      	sub	x17, x17, #0x1
    3df0:      	str	x17, [sp, #0x200]
    3df4:      	adds	x10, x2, #0x1
    3df8:      	csinv	x10, x10, xzr, lo
    3dfc:      	str	x10, [sp, #0x1f0]
    3e00:      	ldp	q0, q1, [x9, #0x10]
    3e04:      	ldp	q2, q3, [x9, #0x30]
    3e08:      	ldp	q4, q5, [x9, #0x50]
    3e0c:      	ldp	q6, q7, [x9, #0x70]
    3e10:      	ldp	q16, q17, [x9, #0x90]
    3e14:      	ldp	q18, q19, [x9, #0xb0]
    3e18:      	ldp	q20, q21, [x9, #0xd0]
    3e1c:      	ldp	q22, q23, [x9, #0xf0]
    3e20:      	movi.2d	v24, #0000000000000000
    3e24:      	stur	q24, [x9, #0x18]
    3e28:      	stur	q24, [x9, #0x28]
    3e2c:      	stur	q24, [x9, #0x38]
    3e30:      	stur	q24, [x9, #0x48]
    3e34:      	stur	q24, [x9, #0x58]
    3e38:      	stur	q24, [x9, #0x68]
    3e3c:      	stur	q24, [x9, #0x78]
    3e40:      	stur	q24, [x9, #0x88]
    3e44:      	stur	q24, [x9, #0x98]
    3e48:      	stur	q24, [x9, #0xa8]
    3e4c:      	stur	q24, [x9, #0xb8]
    3e50:      	stur	q24, [x9, #0xc8]
    3e54:      	stur	q24, [x9, #0xd8]
    3e58:      	stur	q24, [x9, #0xe8]
    3e5c:      	stur	q24, [x9, #0xf8]
    3e60:      	stur	q24, [x9, #0x8]
    3e64:      	str	xzr, [x9, #0x108]
    3e68:      	str	x17, [sp, #0x1ad8]
    3e6c:      	str	x10, [sp, #0x1ae0]
    3e70:      	str	x15, [sp, #0x768]
    3e74:      	str	x8, [sp, #0x770]
    3e78:      	ldr	x27, [sp, #0x1a0]
    3e7c:      	str	q0, [x27]
    3e80:      	ldr	x8, [sp, #0x190]
    3e84:      	str	q1, [x8]
    3e88:      	ldr	x8, [sp, #0x180]
    3e8c:      	str	q2, [x8]
    3e90:      	ldr	x8, [sp, #0x170]
    3e94:      	str	q3, [x8]
    3e98:      	ldr	x8, [sp, #0x160]
    3e9c:      	str	q4, [x8]
    3ea0:      	ldr	x8, [sp, #0x150]
    3ea4:      	str	q5, [x8]
    3ea8:      	ldr	x8, [sp, #0x140]
    3eac:      	str	q6, [x8]
    3eb0:      	ldr	x8, [sp, #0x130]
    3eb4:      	str	q7, [x8]
    3eb8:      	ldr	x8, [sp, #0x120]
    3ebc:      	str	q16, [x8]
    3ec0:      	ldr	x8, [sp, #0x110]
    3ec4:      	str	q17, [x8]
    3ec8:      	ldr	x8, [sp, #0x100]
    3ecc:      	str	q18, [x8]
    3ed0:      	ldr	x8, [sp, #0xf0]
    3ed4:      	str	q19, [x8]
    3ed8:      	ldp	x8, x9, [sp, #0xd8]
    3edc:      	str	q20, [x9]
    3ee0:      	str	q21, [x8]
    3ee4:      	ldp	x8, x9, [sp, #0xc8]
    3ee8:      	str	q22, [x9]
    3eec:      	str	q23, [x8]
    3ef0:      	add	x0, x6, #0x528
    3ef4:      	add	x8, sp, #0x350
    3ef8:      	add	x1, x8, #0x420
    3efc:      	mov	w2, #0x108              ; =264
    3f00:      	bl	0x3f00 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x9c0>
		0000000000003f00:  ARM64_RELOC_BRANCH26	_memcpy
    3f04:      	ldr	x2, [sp, #0x1f0]
    3f08:      	ldr	w0, [sp, #0x1c0]
    3f0c:      	ldr	x17, [sp, #0x200]
    3f10:      	mov	w15, #0x1               ; =1
    3f14:      	add	x6, sp, #0x350
    3f18:      	ldr	x8, [sp, #0x1ae8]
    3f1c:      	ldr	x9, [sp, #0x878]
    3f20:      	ldp	q1, q0, [x27, #0x20]
    3f24:      	ldr	x10, [sp, #0x1b0]
    3f28:      	stp	q1, q0, [x10, #0x20]
    3f2c:      	ldp	q1, q0, [x27, #0x60]
    3f30:      	stp	q1, q0, [x10, #0x60]
    3f34:      	ldp	q1, q0, [x27, #0x40]
    3f38:      	stp	q1, q0, [x10, #0x40]
    3f3c:      	ldp	q1, q0, [x27, #0xa0]
    3f40:      	stp	q1, q0, [x10, #0xa0]
    3f44:      	ldp	q1, q0, [x27, #0x80]
    3f48:      	stp	q1, q0, [x10, #0x80]
    3f4c:      	ldp	q1, q0, [x27, #0xe0]
    3f50:      	stp	q1, q0, [x10, #0xe0]
    3f54:      	ldp	q1, q0, [x27, #0xc0]
    3f58:      	stp	q1, q0, [x10, #0xc0]
    3f5c:      	ldp	q1, q0, [x27]
    3f60:      	mov	x27, #0x11eb            ; =4587
    3f64:      	movk	x27, #0x1331, lsl #16
    3f68:      	movk	x27, #0x49bb, lsl #32
    3f6c:      	movk	x27, #0x94d0, lsl #48
    3f70:      	stp	q1, q0, [x10]
    3f74:      	ldr	x10, [sp, #0xa70]
    3f78:      	madd	x8, x8, x26, x10
    3f7c:      	ldr	x10, [sp, #0x980]
    3f80:      	madd	x9, x9, x26, x10
    3f84:      	ldr	x10, [sp, #0x988]
    3f88:      	madd	x9, x9, x26, x10
    3f8c:      	ldr	x10, [sp, #0x990]
    3f90:      	madd	x9, x9, x26, x10
    3f94:      	ldr	x10, [sp, #0x998]
    3f98:      	madd	x9, x9, x26, x10
    3f9c:      	ldr	x10, [sp, #0x9a0]
    3fa0:      	madd	x9, x9, x26, x10
    3fa4:      	ldr	x10, [sp, #0x9a8]
    3fa8:      	madd	x9, x9, x26, x10
    3fac:      	ldr	x10, [sp, #0x9b0]
    3fb0:      	madd	x9, x9, x26, x10
    3fb4:      	ldr	x10, [sp, #0x9b8]
    3fb8:      	madd	x9, x9, x26, x10
    3fbc:      	ldr	x10, [sp, #0x9c0]
    3fc0:      	madd	x9, x9, x26, x10
    3fc4:      	ldr	x10, [sp, #0x9c8]
    3fc8:      	madd	x9, x9, x26, x10
    3fcc:      	ldr	x10, [sp, #0x9d0]
    3fd0:      	madd	x9, x9, x26, x10
    3fd4:      	ldr	x10, [sp, #0x9d8]
    3fd8:      	madd	x9, x9, x26, x10
    3fdc:      	ldr	x10, [sp, #0x9e0]
    3fe0:      	madd	x9, x9, x26, x10
    3fe4:      	ldr	x10, [sp, #0x9e8]
    3fe8:      	madd	x9, x9, x26, x10
    3fec:      	ldr	x10, [sp, #0x9f0]
    3ff0:      	madd	x9, x9, x26, x10
    3ff4:      	ldr	x10, [sp, #0x9f8]
    3ff8:      	madd	x9, x9, x26, x10
    3ffc:      	ldr	x10, [sp, #0xa00]
    4000:      	madd	x9, x9, x26, x10
    4004:      	ldr	x10, [sp, #0xa08]
    4008:      	madd	x9, x9, x26, x10
    400c:      	ldr	x10, [sp, #0xa10]
    4010:      	madd	x9, x9, x26, x10
    4014:      	ldr	x10, [sp, #0xa18]
    4018:      	madd	x9, x9, x26, x10
    401c:      	ldr	x10, [sp, #0xa20]
    4020:      	madd	x9, x9, x26, x10
    4024:      	ldr	x10, [sp, #0xa28]
    4028:      	madd	x9, x9, x26, x10
    402c:      	ldr	x10, [sp, #0xa30]
    4030:      	madd	x9, x9, x26, x10
    4034:      	ldr	x10, [sp, #0xa38]
    4038:      	madd	x9, x9, x26, x10
    403c:      	ldr	x10, [sp, #0xa40]
    4040:      	madd	x9, x9, x26, x10
    4044:      	ldr	x10, [sp, #0xa48]
    4048:      	madd	x9, x9, x26, x10
    404c:      	ldr	x10, [sp, #0xa50]
    4050:      	madd	x9, x9, x26, x10
    4054:      	ldr	x10, [sp, #0xa58]
    4058:      	madd	x9, x9, x26, x10
    405c:      	ldr	x10, [sp, #0xa60]
    4060:      	madd	x9, x9, x26, x10
    4064:      	ldr	x10, [sp, #0xa68]
    4068:      	madd	x9, x9, x26, x10
    406c:      	madd	x8, x9, x26, x8
    4070:      	ldr	x9, [sp, #0xa78]
    4074:      	madd	x8, x8, x26, x9
    4078:      	add	x8, x8, #0x83
    407c:      	str	x8, [sp, #0x1ae8]
    4080:      	mov	w9, #0x1768             ; =5992
    4084:      	ldrb	w9, [x6, x9]
    4088:      	tbnz	w9, #0x0, 0x4108 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xbc8>
    408c:      	ldr	x9, [sp, #0x1ab0]
    4090:      	ldr	x10, [sp, #0x1b08]
    4094:      	eor	x9, x10, x9
    4098:      	eor	x9, x9, x9, lsr #30
    409c:      	mov	x10, #0xe5b9            ; =58809
    40a0:      	movk	x10, #0x1ce4, lsl #16
    40a4:      	movk	x10, #0x476d, lsl #32
    40a8:      	movk	x10, #0xbf58, lsl #48
    40ac:      	mul	x9, x9, x10
    40b0:      	eor	x9, x9, x9, lsr #27
    40b4:      	mul	x9, x9, x27
    40b8:      	eor	x9, x9, x9, lsr #31
    40bc:      	ldr	x1, [sp, #0x1ac0]
    40c0:      	cbnz	x1, 0x4114 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xbd4>
    40c4:      	b	0x3d34 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x7f4>
    40c8:      	movi.2d	v0, #0000000000000000
    40cc:      	stp	q0, q0, [x20, #0xf0]
    40d0:      	stp	q0, q0, [x20, #0xd0]
    40d4:      	stp	q0, q0, [x20, #0xb0]
    40d8:      	stp	q0, q0, [x20, #0x90]
    40dc:      	stp	q0, q0, [x20, #0x70]
    40e0:      	stp	q0, q0, [x20, #0x50]
    40e4:      	stp	q0, q0, [x20, #0x30]
    40e8:      	stp	q0, q0, [x20, #0x10]
    40ec:      	ldr	x8, [sp, #0x1ae8]
    40f0:      	mul	x8, x8, x26
    40f4:      	str	q0, [x20]
    40f8:      	str	x8, [sp, #0x1ae8]
    40fc:      	mov	w9, #0x1768             ; =5992
    4100:      	ldrb	w9, [x6, x9]
    4104:      	tbz	w9, #0x0, 0x408c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xb4c>
    4108:      	mov	x9, #0x0                ; =0
    410c:      	ldr	x1, [sp, #0x1ac0]
    4110:      	cbz	x1, 0x3d34 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x7f4>
    4114:      	udiv	x10, x9, x1
    4118:      	msub	x9, x10, x1, x9
    411c:      	ldr	x10, [sp, #0x1ad0]
    4120:      	ldr	x11, [sp, #0x1b08]
    4124:      	mov	x12, x1
    4128:      	b	0x4140 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xc00>
    412c:      	add	x13, x9, #0x1
    4130:      	cmp	x13, x1
    4134:      	csinc	x9, xzr, x9, hs
    4138:      	subs	x12, x12, #0x1
    413c:      	b.eq	0x3d34 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x7f4>
    4140:      	madd	x13, x9, x24, x10
    4144:      	ldr	w14, [x13]
    4148:      	cmp	w14, #0x1
    414c:      	b.eq	0x412c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xbec>
    4150:      	cmp	w14, #0x2
    4154:      	b.ne	0x3d34 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x7f4>
    4158:      	ldr	x14, [x13, #0x8]
    415c:      	cmp	x14, x11
    4160:      	b.ne	0x412c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xbec>
    4164:      	ldr	x9, [x13, #0x10]
    4168:      	str	wzr, [sp, #0xa80]
    416c:      	str	x9, [sp, #0xa88]
    4170:      	strb	wzr, [sp, #0xa90]
    4174:      	mov	w10, #0x4309            ; =17161
    4178:      	madd	x8, x8, x10, x9
    417c:      	add	x8, x8, #0x83
    4180:      	str	x8, [sp, #0x1ae8]
    4184:      	add	x28, x28, #0x1
    4188:      	ldr	x8, [sp, #0x320]
    418c:      	cmp	x28, x8
    4190:      	b.ne	0x3d58 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x818>
    4194:      	b	0x41ac <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xc6c>
    4198:      	mov	x1, x21
    419c:      	mov	x27, #0x11eb            ; =4587
    41a0:      	movk	x27, #0x1331, lsl #16
    41a4:      	movk	x27, #0x49bb, lsl #32
    41a8:      	movk	x27, #0x94d0, lsl #48
    41ac:      	mov	w8, #0x1760             ; =5984
    41b0:      	add	x2, x6, x8
    41b4:      	ldr	x28, [sp, #0x348]
    41b8:      	mov	x0, x28
    41bc:      	add	x21, sp, #0x350
    41c0:      	bl	0x41c0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xc80>
		00000000000041c0:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    41c4:      	str	w0, [sp, #0xa98]
    41c8:      	strb	w1, [sp, #0xa9c]
    41cc:      	strb	w2, [sp, #0xa9d]
    41d0:      	cmp	w0, #0x0
    41d4:      	ldr	x8, [sp, #0x1ae8]
    41d8:      	mul	x8, x8, x26
    41dc:      	cinc	x8, x8, eq
    41e0:      	str	x8, [sp, #0x1ae8]
    41e4:      	ldr	x22, [sp, #0xc0]
    41e8:      	cbz	x22, 0x3ccc <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x78c>
    41ec:      	mov	x9, #0x0                ; =0
    41f0:      	ldr	x10, [sp, #0x1ab0]
    41f4:      	mov	w11, #0x1768            ; =5992
    41f8:      	ldrb	w11, [x21, x11]
    41fc:      	ldr	x12, [sp, #0x1ac0]
    4200:      	ldr	x13, [sp, #0x1ad0]
    4204:      	add	x6, sp, #0x350
    4208:      	ldr	x1, [sp, #0x1e0]
    420c:      	mov	w2, #0x1                ; =1
    4210:      	b	0x4234 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xcf4>
    4214:      	str	w2, [sp, #0xaa0]
    4218:      	str	xzr, [sp, #0xaa8]
    421c:      	mul	x8, x8, x26
    4220:      	strb	wzr, [sp, #0xab0]
    4224:      	str	x8, [sp, #0x1ae8]
    4228:      	add	x9, x9, #0x1
    422c:      	cmp	x9, x22
    4230:      	b.eq	0x42ec <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xdac>
    4234:      	orr	x14, x2, x9, lsl #1
    4238:      	str	x14, [sp, #0x1b10]
    423c:      	tbz	w11, #0x0, 0x424c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xd0c>
    4240:      	mov	x15, #0x0               ; =0
    4244:      	cbnz	x12, 0x4278 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xd38>
    4248:      	b	0x4214 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xcd4>
    424c:      	eor	x15, x10, x14
    4250:      	eor	x15, x15, x15, lsr #30
    4254:      	mov	x16, #0xe5b9            ; =58809
    4258:      	movk	x16, #0x1ce4, lsl #16
    425c:      	movk	x16, #0x476d, lsl #32
    4260:      	movk	x16, #0xbf58, lsl #48
    4264:      	mul	x15, x15, x16
    4268:      	eor	x15, x15, x15, lsr #27
    426c:      	mul	x15, x15, x27
    4270:      	eor	x15, x15, x15, lsr #31
    4274:      	cbz	x12, 0x4214 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xcd4>
    4278:      	udiv	x16, x15, x12
    427c:      	msub	x15, x16, x12, x15
    4280:      	mov	x16, x12
    4284:      	b	0x429c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xd5c>
    4288:      	add	x17, x15, #0x1
    428c:      	cmp	x17, x12
    4290:      	csinc	x15, xzr, x15, hs
    4294:      	subs	x16, x16, #0x1
    4298:      	b.eq	0x4214 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xcd4>
    429c:      	madd	x17, x15, x24, x13
    42a0:      	ldr	w0, [x17]
    42a4:      	cmp	w0, #0x1
    42a8:      	b.eq	0x4288 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xd48>
    42ac:      	cmp	w0, #0x2
    42b0:      	b.ne	0x4214 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xcd4>
    42b4:      	ldr	x0, [x17, #0x8]
    42b8:      	cmp	x0, x14
    42bc:      	b.ne	0x4288 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xd48>
    42c0:      	ldr	x14, [x17, #0x10]
    42c4:      	str	wzr, [sp, #0xaa0]
    42c8:      	str	x14, [sp, #0xaa8]
    42cc:      	strb	wzr, [sp, #0xab0]
    42d0:      	mov	w15, #0x4309            ; =17161
    42d4:      	madd	x8, x8, x15, x14
    42d8:      	add	x8, x8, #0x83
    42dc:      	str	x8, [sp, #0x1ae8]
    42e0:      	add	x9, x9, #0x1
    42e4:      	cmp	x9, x22
    42e8:      	b.ne	0x4234 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xcf4>
    42ec:      	add	x1, x1, #0x1
    42f0:      	str	x1, [sp, #0x1e0]
    42f4:      	ldr	x22, [sp, #0x1d0]
    42f8:      	mov	w21, #0x1               ; =1
    42fc:      	ldr	x23, [sp, #0x320]
    4300:      	b	0x4328 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xde8>
    4304:      	ldr	x8, [sp, #0x1ae8]
    4308:      	mul	x8, x8, x26
    430c:      	mov	w15, #0x1               ; =1
    4310:      	str	x8, [sp, #0x1ae8]
    4314:      	add	x21, x21, #0x4
    4318:      	add	x22, x22, #0x2
    431c:      	subs	x23, x23, #0x1
    4320:      	add	x6, sp, #0x350
    4324:      	b.eq	0x46c4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1184>
    4328:      	add	x8, x22, #0x1f
    432c:      	str	x22, [sp, #0xab8]
    4330:      	dup.2d	v0, x22
    4334:      	ldr	q1, [sp, #0x310]
    4338:      	add.2d	v1, v0, v1
    433c:      	str	q1, [sp, #0xac0]
    4340:      	ldr	q1, [sp, #0x300]
    4344:      	add.2d	v1, v0, v1
    4348:      	str	q1, [sp, #0xad0]
    434c:      	ldr	q1, [sp, #0x2f0]
    4350:      	add.2d	v1, v0, v1
    4354:      	str	q1, [sp, #0xae0]
    4358:      	ldr	q1, [sp, #0x2e0]
    435c:      	add.2d	v1, v0, v1
    4360:      	str	q1, [sp, #0xaf0]
    4364:      	ldr	q1, [sp, #0x2d0]
    4368:      	add.2d	v1, v0, v1
    436c:      	str	q1, [sp, #0xb00]
    4370:      	ldr	q1, [sp, #0x2c0]
    4374:      	add.2d	v1, v0, v1
    4378:      	str	q1, [sp, #0xb10]
    437c:      	ldr	q1, [sp, #0x2b0]
    4380:      	add.2d	v1, v0, v1
    4384:      	str	q1, [sp, #0xb20]
    4388:      	ldr	q1, [sp, #0x2a0]
    438c:      	add.2d	v1, v0, v1
    4390:      	str	q1, [sp, #0xb30]
    4394:      	ldr	q1, [sp, #0x290]
    4398:      	add.2d	v1, v0, v1
    439c:      	str	q1, [sp, #0xb40]
    43a0:      	ldr	q1, [sp, #0x280]
    43a4:      	add.2d	v1, v0, v1
    43a8:      	str	q1, [sp, #0xb50]
    43ac:      	ldr	q1, [sp, #0x270]
    43b0:      	add.2d	v1, v0, v1
    43b4:      	str	q1, [sp, #0xb60]
    43b8:      	ldr	q1, [sp, #0x260]
    43bc:      	add.2d	v1, v0, v1
    43c0:      	str	q1, [sp, #0xb70]
    43c4:      	ldr	q1, [sp, #0x250]
    43c8:      	add.2d	v1, v0, v1
    43cc:      	str	q1, [sp, #0xb80]
    43d0:      	ldr	q1, [sp, #0x240]
    43d4:      	add.2d	v1, v0, v1
    43d8:      	str	q1, [sp, #0xb90]
    43dc:      	ldr	q1, [sp, #0x230]
    43e0:      	add.2d	v0, v0, v1
    43e4:      	str	q0, [sp, #0xba0]
    43e8:      	str	x8, [sp, #0xbb0]
    43ec:      	ldp	q0, q1, [x25, #0xc0]
    43f0:      	str	q0, [sp, #0x1be0]
    43f4:      	str	q1, [sp, #0x1bf0]
    43f8:      	ldp	q0, q1, [x25, #0xe0]
    43fc:      	str	q0, [sp, #0x1c00]
    4400:      	str	q1, [sp, #0x1c10]
    4404:      	ldp	q0, q1, [x25, #0x80]
    4408:      	str	q0, [sp, #0x1ba0]
    440c:      	str	q1, [sp, #0x1bb0]
    4410:      	ldp	q0, q1, [x25, #0xa0]
    4414:      	str	q0, [sp, #0x1bc0]
    4418:      	str	q1, [sp, #0x1bd0]
    441c:      	ldp	q0, q1, [x25, #0x40]
    4420:      	str	q0, [sp, #0x1b60]
    4424:      	str	q1, [sp, #0x1b70]
    4428:      	ldp	q0, q1, [x25, #0x60]
    442c:      	str	q0, [sp, #0x1b80]
    4430:      	str	q1, [sp, #0x1b90]
    4434:      	ldp	q0, q1, [x25]
    4438:      	str	q0, [sp, #0x1b20]
    443c:      	str	q1, [sp, #0x1b30]
    4440:      	ldp	q0, q1, [x25, #0x20]
    4444:      	str	q0, [sp, #0x1b40]
    4448:      	str	q1, [sp, #0x1b50]
    444c:      	ldr	x1, [sp, #0x1ac0]
    4450:      	ldr	x8, [x28, #0x20]
    4454:      	add	x9, sp, #0x1, lsl #12   ; =0x1000
    4458:      	add	x9, x9, #0xb20
    445c:      	str	x8, [x9, #0x120]
    4460:      	ldp	q1, q0, [x28]
    4464:      	stp	q1, q0, [x9, #0x100]
    4468:      	ldr	x10, [sp, #0x330]
    446c:      	str	x8, [x10, #0x20]
    4470:      	ldr	x8, [sp, #0x1c38]
    4474:      	ldr	x9, [sp, #0x1c68]
    4478:      	adds	x8, x8, x9
    447c:      	csinv	x9, x8, xzr, lo
    4480:      	lsr	x8, x1, #14
    4484:      	stp	q1, q0, [x10]
    4488:      	cbnz	x8, 0x4500 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xfc0>
    448c:      	sub	x8, x1, x1, lsr #2
    4490:      	cmp	x9, x8
    4494:      	b.lo	0x4500 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xfc0>
    4498:      	ldr	x9, [x28, #0x20]
    449c:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
    44a0:      	add	x10, x10, #0xb20
    44a4:      	str	x9, [x10, #0x170]
    44a8:      	ldp	q1, q0, [x28]
    44ac:      	stp	q1, q0, [x10, #0x150]
    44b0:      	ldr	x9, [sp, #0x1c88]
    44b4:      	cmp	x9, x8, lsr #1
    44b8:      	b.lo	0x44d8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xf98>
    44bc:      	cbz	x1, 0x44d4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xf94>
    44c0:      	cmp	x1, #0x2, lsl #12       ; =0x2000
    44c4:      	mov	w8, #0x2000             ; =8192
    44c8:      	csel	x8, x1, x8, lo
    44cc:      	lsl	x1, x8, #1
    44d0:      	b	0x44d8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xf98>
    44d4:      	mov	w1, #0x1                ; =1
    44d8:      	mov	w8, #0x1760             ; =5984
    44dc:      	add	x2, x6, x8
    44e0:      	mov	x0, x28
    44e4:      	bl	0x44e4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xfa4>
		00000000000044e4:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    44e8:      	add	x6, sp, #0x350
    44ec:      	str	w0, [sp, #0x1c98]
    44f0:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
    44f4:      	add	x8, x8, #0xb20
    44f8:      	strb	w1, [x8, #0x17c]
    44fc:      	strb	w2, [x8, #0x17d]
    4500:      	add	x0, x6, #0x868
    4504:      	add	x3, sp, #0x1, lsl #12   ; =0x1000
    4508:      	add	x3, x3, #0xb20
    450c:      	add	x27, sp, #0x350
    4510:      	mov	w8, #0x1760             ; =5984
    4514:      	add	x4, x27, x8
    4518:      	mov	x1, x28
    451c:      	mov	x2, x21
    4520:      	bl	0x4520 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xfe0>
		0000000000004520:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
    4524:      	ldr	w8, [sp, #0xbb8]
    4528:      	cbz	w8, 0x4304 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xdc4>
    452c:      	ldr	x8, [sp, #0x228]
    4530:      	ldrb	w28, [x8, #0x768]
    4534:      	add	x0, x27, #0x978
    4538:      	add	x8, sp, #0x350
    453c:      	add	x1, x8, #0x870
    4540:      	mov	w2, #0x108              ; =264
    4544:      	bl	0x4544 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1004>
		0000000000004544:  ARM64_RELOC_BRANCH26	_memcpy
    4548:      	ldr	x8, [sp, #0x1ae8]
    454c:      	cmp	w28, #0x0
    4550:      	ldr	x28, [sp, #0x348]
    4554:      	mov	w15, #0x1               ; =1
    4558:      	cinc	x9, x15, ne
    455c:      	madd	x8, x8, x26, x9
    4560:      	ldr	x9, [sp, #0xcc8]
    4564:      	ldp	q1, q0, [x19, #0x60]
    4568:      	ldr	x10, [sp, #0x210]
    456c:      	stp	q1, q0, [x10, #0x60]
    4570:      	ldp	q1, q0, [x19, #0x40]
    4574:      	stp	q1, q0, [x10, #0x40]
    4578:      	ldp	q1, q0, [x19, #0xa0]
    457c:      	stp	q1, q0, [x10, #0xa0]
    4580:      	ldp	q1, q0, [x19, #0x80]
    4584:      	stp	q1, q0, [x10, #0x80]
    4588:      	ldp	q1, q0, [x19, #0xe0]
    458c:      	stp	q1, q0, [x10, #0xe0]
    4590:      	ldp	q1, q0, [x19, #0xc0]
    4594:      	stp	q1, q0, [x10, #0xc0]
    4598:      	ldp	q1, q0, [x19, #0x20]
    459c:      	stp	q1, q0, [x10, #0x20]
    45a0:      	ldp	q0, q1, [x19]
    45a4:      	stp	q0, q1, [x10]
    45a8:      	ldr	x10, [sp, #0xdd0]
    45ac:      	madd	x9, x9, x26, x10
    45b0:      	ldr	x10, [sp, #0xdd8]
    45b4:      	madd	x9, x9, x26, x10
    45b8:      	ldr	x10, [sp, #0xde0]
    45bc:      	madd	x9, x9, x26, x10
    45c0:      	ldr	x10, [sp, #0xde8]
    45c4:      	madd	x9, x9, x26, x10
    45c8:      	ldr	x10, [sp, #0xdf0]
    45cc:      	madd	x9, x9, x26, x10
    45d0:      	ldr	x10, [sp, #0xdf8]
    45d4:      	madd	x9, x9, x26, x10
    45d8:      	ldr	x10, [sp, #0xe00]
    45dc:      	madd	x9, x9, x26, x10
    45e0:      	ldr	x10, [sp, #0xe08]
    45e4:      	madd	x9, x9, x26, x10
    45e8:      	ldr	x10, [sp, #0xe10]
    45ec:      	madd	x9, x9, x26, x10
    45f0:      	ldr	x10, [sp, #0xe18]
    45f4:      	madd	x9, x9, x26, x10
    45f8:      	ldr	x10, [sp, #0xe20]
    45fc:      	madd	x9, x9, x26, x10
    4600:      	ldr	x10, [sp, #0xe28]
    4604:      	madd	x9, x9, x26, x10
    4608:      	ldr	x10, [sp, #0xe30]
    460c:      	madd	x9, x9, x26, x10
    4610:      	ldr	x10, [sp, #0xe38]
    4614:      	madd	x9, x9, x26, x10
    4618:      	ldr	x10, [sp, #0xe40]
    461c:      	madd	x9, x9, x26, x10
    4620:      	ldr	x10, [sp, #0xe48]
    4624:      	madd	x9, x9, x26, x10
    4628:      	ldr	x10, [sp, #0xe50]
    462c:      	madd	x9, x9, x26, x10
    4630:      	ldr	x10, [sp, #0xe58]
    4634:      	madd	x9, x9, x26, x10
    4638:      	ldr	x10, [sp, #0xe60]
    463c:      	madd	x9, x9, x26, x10
    4640:      	ldr	x10, [sp, #0xe68]
    4644:      	madd	x9, x9, x26, x10
    4648:      	ldr	x10, [sp, #0xe70]
    464c:      	madd	x9, x9, x26, x10
    4650:      	ldr	x10, [sp, #0xe78]
    4654:      	madd	x9, x9, x26, x10
    4658:      	ldr	x10, [sp, #0xe80]
    465c:      	madd	x9, x9, x26, x10
    4660:      	ldr	x10, [sp, #0xe88]
    4664:      	madd	x9, x9, x26, x10
    4668:      	ldr	x10, [sp, #0xe90]
    466c:      	madd	x9, x9, x26, x10
    4670:      	ldr	x10, [sp, #0xe98]
    4674:      	madd	x9, x9, x26, x10
    4678:      	ldr	x10, [sp, #0xea0]
    467c:      	madd	x9, x9, x26, x10
    4680:      	ldr	x10, [sp, #0xea8]
    4684:      	madd	x9, x9, x26, x10
    4688:      	ldr	x10, [sp, #0xeb0]
    468c:      	madd	x9, x9, x26, x10
    4690:      	ldr	x10, [sp, #0xeb8]
    4694:      	madd	x9, x9, x26, x10
    4698:      	ldr	x10, [sp, #0xec0]
    469c:      	add	x8, x8, x10
    46a0:      	madd	x8, x9, x26, x8
    46a4:      	ldr	x9, [sp, #0xec8]
    46a8:      	madd	x8, x8, x26, x9
    46ac:      	str	x8, [sp, #0x1ae8]
    46b0:      	add	x21, x21, #0x4
    46b4:      	add	x22, x22, #0x2
    46b8:      	subs	x23, x23, #0x1
    46bc:      	add	x6, sp, #0x350
    46c0:      	b.ne	0x4328 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xde8>
    46c4:      	ldr	x22, [sp, #0xc0]
    46c8:      	ldr	x10, [sp, #0x1e0]
    46cc:      	b	0x3cdc <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x79c>
    46d0:      	mov	x24, #0x0               ; =0
    46d4:      	mov	w8, #0x12e0             ; =4832
    46d8:      	mov	w9, #0x10c8             ; =4296
    46dc:      	mov	w10, #0x11d0            ; =4560
    46e0:      	mov	w11, #0x12e8            ; =4840
    46e4:      	mov	w12, #0x14f8            ; =5368
    46e8:      	mov	w13, #0x1600            ; =5632
    46ec:      	add	x8, x6, x8
    46f0:      	str	x8, [sp, #0x320]
    46f4:      	add	x8, x6, x9
    46f8:      	str	x8, [sp, #0x98]
    46fc:      	add	x8, x6, x10
    4700:      	str	x8, [sp, #0x90]
    4704:      	add	x25, x6, x11
    4708:      	add	x8, x6, x12
    470c:      	str	x8, [sp, #0xe0]
    4710:      	add	x8, x6, x13
    4714:      	str	x8, [sp, #0xd8]
    4718:      	add	x19, x6, #0xba0
    471c:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		000000000000471c:  ARM64_RELOC_PAGE21	lCPI68_15
    4720:      	ldr	q0, [x8]
		0000000000004720:  ARM64_RELOC_PAGEOFF12	lCPI68_15
    4724:      	str	q0, [sp, #0x2d0]
    4728:      	add	x8, x6, #0xeb8
    472c:      	str	x8, [sp, #0xd0]
    4730:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		0000000000004730:  ARM64_RELOC_PAGE21	lCPI68_16
    4734:      	ldr	q0, [x8]
		0000000000004734:  ARM64_RELOC_PAGEOFF12	lCPI68_16
    4738:      	str	q0, [sp, #0x2c0]
    473c:      	add	x20, x6, #0xfb8
    4740:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		0000000000004740:  ARM64_RELOC_PAGE21	lCPI68_17
    4744:      	ldr	q0, [x8]
		0000000000004744:  ARM64_RELOC_PAGEOFF12	lCPI68_17
    4748:      	str	q0, [sp, #0x2b0]
    474c:      	sub	x17, x23, #0x9
    4750:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		0000000000004750:  ARM64_RELOC_PAGE21	lCPI68_18
    4754:      	ldr	q0, [x8]
		0000000000004754:  ARM64_RELOC_PAGEOFF12	lCPI68_18
    4758:      	str	q0, [sp, #0x2a0]
    475c:      	ldr	x9, [sp, #0x228]
    4760:      	add	x8, x9, #0xec4
    4764:      	str	x8, [sp, #0x88]
    4768:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		0000000000004768:  ARM64_RELOC_PAGE21	lCPI68_19
    476c:      	ldr	q0, [x8]
		000000000000476c:  ARM64_RELOC_PAGEOFF12	lCPI68_19
    4770:      	str	q0, [sp, #0x290]
    4774:      	add	x8, x9, #0xed4
    4778:      	str	x8, [sp, #0x80]
    477c:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		000000000000477c:  ARM64_RELOC_PAGE21	lCPI68_20
    4780:      	ldr	q0, [x8]
		0000000000004780:  ARM64_RELOC_PAGEOFF12	lCPI68_20
    4784:      	str	q0, [sp, #0x280]
    4788:      	add	x8, x9, #0xee4
    478c:      	str	x8, [sp, #0x78]
    4790:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		0000000000004790:  ARM64_RELOC_PAGE21	lCPI68_21
    4794:      	ldr	q0, [x8]
		0000000000004794:  ARM64_RELOC_PAGEOFF12	lCPI68_21
    4798:      	str	q0, [sp, #0x270]
    479c:      	add	x8, x9, #0xef4
    47a0:      	str	x8, [sp, #0x70]
    47a4:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		00000000000047a4:  ARM64_RELOC_PAGE21	lCPI68_22
    47a8:      	ldr	q0, [x8]
		00000000000047a8:  ARM64_RELOC_PAGEOFF12	lCPI68_22
    47ac:      	str	q0, [sp, #0x260]
    47b0:      	add	x8, x9, #0xf04
    47b4:      	str	x8, [sp, #0x68]
    47b8:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		00000000000047b8:  ARM64_RELOC_PAGE21	lCPI68_23
    47bc:      	ldr	q0, [x8]
		00000000000047bc:  ARM64_RELOC_PAGEOFF12	lCPI68_23
    47c0:      	str	q0, [sp, #0x250]
    47c4:      	add	x8, x9, #0xf14
    47c8:      	str	x8, [sp, #0x60]
    47cc:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		00000000000047cc:  ARM64_RELOC_PAGE21	lCPI68_24
    47d0:      	ldr	q0, [x8]
		00000000000047d0:  ARM64_RELOC_PAGEOFF12	lCPI68_24
    47d4:      	str	q0, [sp, #0x240]
    47d8:      	add	x8, x9, #0xf24
    47dc:      	str	x8, [sp, #0x58]
    47e0:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		00000000000047e0:  ARM64_RELOC_PAGE21	lCPI68_25
    47e4:      	ldr	q0, [x8]
		00000000000047e4:  ARM64_RELOC_PAGEOFF12	lCPI68_25
    47e8:      	str	q0, [sp, #0x230]
    47ec:      	add	x8, x9, #0xf34
    47f0:      	str	x8, [sp, #0x50]
    47f4:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		00000000000047f4:  ARM64_RELOC_PAGE21	lCPI68_26
    47f8:      	ldr	q0, [x8]
		00000000000047f8:  ARM64_RELOC_PAGEOFF12	lCPI68_26
    47fc:      	str	q0, [sp, #0x210]
    4800:      	add	x8, x9, #0xf44
    4804:      	str	x8, [sp, #0x48]
    4808:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		0000000000004808:  ARM64_RELOC_PAGE21	lCPI68_27
    480c:      	ldr	q0, [x8]
		000000000000480c:  ARM64_RELOC_PAGEOFF12	lCPI68_27
    4810:      	str	q0, [sp, #0x200]
    4814:      	add	x8, x9, #0xf54
    4818:      	str	x8, [sp, #0x40]
    481c:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		000000000000481c:  ARM64_RELOC_PAGE21	lCPI68_28
    4820:      	ldr	q0, [x8]
		0000000000004820:  ARM64_RELOC_PAGEOFF12	lCPI68_28
    4824:      	str	q0, [sp, #0x1f0]
    4828:      	add	x8, x9, #0xf64
    482c:      	str	x8, [sp, #0x38]
    4830:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		0000000000004830:  ARM64_RELOC_PAGE21	lCPI68_29
    4834:      	ldr	q0, [x8]
		0000000000004834:  ARM64_RELOC_PAGEOFF12	lCPI68_29
    4838:      	str	q0, [sp, #0x1e0]
    483c:      	add	x8, x9, #0xf74
    4840:      	str	x8, [sp, #0x30]
    4844:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		0000000000004844:  ARM64_RELOC_PAGE21	lCPI68_0
    4848:      	ldr	q0, [x8]
		0000000000004848:  ARM64_RELOC_PAGEOFF12	lCPI68_0
    484c:      	str	q0, [sp, #0x1d0]
    4850:      	add	x8, x9, #0xf84
    4854:      	str	x8, [sp, #0x28]
    4858:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		0000000000004858:  ARM64_RELOC_PAGE21	lCPI68_1
    485c:      	ldr	q0, [x8]
		000000000000485c:  ARM64_RELOC_PAGEOFF12	lCPI68_1
    4860:      	str	q0, [sp, #0x1c0]
    4864:      	add	x8, x9, #0xf94
    4868:      	str	x8, [sp, #0x20]
    486c:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		000000000000486c:  ARM64_RELOC_PAGE21	lCPI68_2
    4870:      	ldr	q0, [x8]
		0000000000004870:  ARM64_RELOC_PAGEOFF12	lCPI68_2
    4874:      	str	q0, [sp, #0x1b0]
    4878:      	add	x8, x9, #0xfa4
    487c:      	str	x8, [sp, #0x18]
    4880:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		0000000000004880:  ARM64_RELOC_PAGE21	lCPI68_3
    4884:      	ldr	q0, [x8]
		0000000000004884:  ARM64_RELOC_PAGEOFF12	lCPI68_3
    4888:      	str	q0, [sp, #0x1a0]
    488c:      	add	x8, x9, #0xfb4
    4890:      	str	x8, [sp, #0x10]
    4894:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		0000000000004894:  ARM64_RELOC_PAGE21	lCPI68_4
    4898:      	ldr	q0, [x8]
		0000000000004898:  ARM64_RELOC_PAGEOFF12	lCPI68_4
    489c:      	str	q0, [sp, #0x190]
    48a0:      	mov	w8, #0x13f0             ; =5104
    48a4:      	adrp	x9, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		00000000000048a4:  ARM64_RELOC_PAGE21	lCPI68_5
    48a8:      	ldr	q0, [x9]
		00000000000048a8:  ARM64_RELOC_PAGEOFF12	lCPI68_5
    48ac:      	str	q0, [sp, #0x180]
    48b0:      	add	x8, x14, x8
    48b4:      	str	x8, [sp, #0xc8]
    48b8:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		00000000000048b8:  ARM64_RELOC_PAGE21	lCPI68_6
    48bc:      	ldr	q0, [x8]
		00000000000048bc:  ARM64_RELOC_PAGEOFF12	lCPI68_6
    48c0:      	str	q0, [sp, #0x170]
    48c4:      	mov	w8, #0x13f8             ; =5112
    48c8:      	adrp	x9, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		00000000000048c8:  ARM64_RELOC_PAGE21	lCPI68_7
    48cc:      	ldr	q0, [x9]
		00000000000048cc:  ARM64_RELOC_PAGEOFF12	lCPI68_7
    48d0:      	str	q0, [sp, #0x160]
    48d4:      	add	x8, x14, x8
    48d8:      	str	x8, [sp, #0xb8]
    48dc:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		00000000000048dc:  ARM64_RELOC_PAGE21	lCPI68_8
    48e0:      	ldr	q0, [x8]
		00000000000048e0:  ARM64_RELOC_PAGEOFF12	lCPI68_8
    48e4:      	str	q0, [sp, #0x150]
    48e8:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		00000000000048e8:  ARM64_RELOC_PAGE21	lCPI68_9
    48ec:      	ldr	q0, [x8]
		00000000000048ec:  ARM64_RELOC_PAGEOFF12	lCPI68_9
    48f0:      	str	q0, [sp, #0x140]
    48f4:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		00000000000048f4:  ARM64_RELOC_PAGE21	lCPI68_10
    48f8:      	ldr	q0, [x8]
		00000000000048f8:  ARM64_RELOC_PAGEOFF12	lCPI68_10
    48fc:      	str	q0, [sp, #0x130]
    4900:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		0000000000004900:  ARM64_RELOC_PAGE21	lCPI68_11
    4904:      	ldr	q0, [x8]
		0000000000004904:  ARM64_RELOC_PAGEOFF12	lCPI68_11
    4908:      	str	q0, [sp, #0x120]
    490c:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		000000000000490c:  ARM64_RELOC_PAGE21	lCPI68_12
    4910:      	ldr	q0, [x8]
		0000000000004910:  ARM64_RELOC_PAGEOFF12	lCPI68_12
    4914:      	str	q0, [sp, #0x110]
    4918:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		0000000000004918:  ARM64_RELOC_PAGE21	lCPI68_13
    491c:      	ldr	q0, [x8]
		000000000000491c:  ARM64_RELOC_PAGEOFF12	lCPI68_13
    4920:      	str	q0, [sp, #0x100]
    4924:      	adrp	x8, 0x4000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0xac0>
		0000000000004924:  ARM64_RELOC_PAGE21	lCPI68_14
    4928:      	ldr	q0, [x8]
		0000000000004928:  ARM64_RELOC_PAGEOFF12	lCPI68_14
    492c:      	str	q0, [sp, #0xf0]
    4930:      	add	x8, x14, #0xcb0
    4934:      	stp	x21, x8, [sp, #0xa8]
    4938:      	mov	w28, #0x83              ; =131
    493c:      	mov	w3, #0x1                ; =1
    4940:      	mov	w27, #0x110             ; =272
    4944:      	str	x16, [sp, #0x300]
    4948:      	mov	x26, x17
    494c:      	b	0x4964 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1424>
    4950:      	ldr	x8, [sp, #0xe8]
    4954:      	ldr	x24, [sp, #0x2f0]
    4958:      	cmp	x24, x8
    495c:      	ldr	x21, [sp, #0xa8]
    4960:      	b.eq	0x5820 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x22e0>
    4964:      	cmp	x23, #0x4
    4968:      	b.eq	0x498c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x144c>
    496c:      	cmp	x23, #0x9
    4970:      	b.eq	0x498c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x144c>
    4974:      	cmp	x23, #0xa
    4978:      	b.ne	0x4a20 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x14e0>
    497c:      	ldr	x8, [sp, #0x1ae8]
    4980:      	mov	x9, #0x1                ; =1
    4984:      	madd	x8, x8, x28, x9
    4988:      	b	0x4a0c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x14cc>
    498c:      	cmp	x21, #0x4, lsl #12      ; =0x4000
    4990:      	b.ls	0x49a4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1464>
    4994:      	mov	w2, #0x0                ; =0
    4998:      	mov	w1, #0x0                ; =0
    499c:      	mov	w0, #0x1                ; =1
    49a0:      	b	0x49e4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x14a4>
    49a4:      	ldr	x8, [sp, #0x1ac0]
    49a8:      	cmp	x21, x8
    49ac:      	b.ls	0x49d8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1498>
    49b0:      	mov	w8, #0x1760             ; =5984
    49b4:      	add	x2, x6, x8
    49b8:      	ldr	x0, [sp, #0x348]
    49bc:      	mov	x1, x21
    49c0:      	bl	0x49c0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1480>
		00000000000049c0:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    49c4:      	mov	w3, #0x1                ; =1
    49c8:      	mov	x17, x26
    49cc:      	ldr	x16, [sp, #0x300]
    49d0:      	add	x6, sp, #0x350
    49d4:      	b	0x49e4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x14a4>
    49d8:      	mov	w2, #0x0                ; =0
    49dc:      	mov	w1, #0x0                ; =0
    49e0:      	mov	w0, #0x0                ; =0
    49e4:      	str	w0, [sp, #0xed0]
    49e8:      	strb	w1, [sp, #0xed4]
    49ec:      	strb	w2, [sp, #0xed5]
    49f0:      	cmp	w0, #0x0
    49f4:      	ldr	x8, [sp, #0x1ae8]
    49f8:      	mul	x8, x8, x28
    49fc:      	cinc	x8, x8, eq
    4a00:      	str	x8, [sp, #0x1ae8]
    4a04:      	cmp	x17, #0x2
    4a08:      	b.hs	0x4a20 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x14e0>
    4a0c:      	ldr	x9, [sp, #0x1ac0]
    4a10:      	cmp	x9, x21
    4a14:      	mul	x8, x8, x28
    4a18:      	cinc	x8, x8, hs
    4a1c:      	str	x8, [sp, #0x1ae8]
    4a20:      	add	x24, x24, #0x1
    4a24:      	str	x24, [sp, #0x2f0]
    4a28:      	cbz	x22, 0x4950 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1410>
    4a2c:      	mov	x24, #0x0               ; =0
    4a30:      	ldr	x8, [sp, #0xa0]
    4a34:      	ldr	x9, [sp, #0x2f0]
    4a38:      	madd	x8, x9, x22, x8
    4a3c:      	str	x8, [sp, #0x310]
    4a40:      	b	0x4a68 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1528>
    4a44:      	str	w3, [sp, #0xed8]
    4a48:      	str	xzr, [sp, #0xee0]
    4a4c:      	strb	wzr, [sp, #0xee8]
    4a50:      	ldr	x8, [sp, #0x1ae8]
    4a54:      	mul	x8, x8, x28
    4a58:      	str	x8, [sp, #0x1ae8]
    4a5c:      	add	x24, x24, #0x1
    4a60:      	cmp	x24, x22
    4a64:      	b.eq	0x4950 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1410>
    4a68:      	add	x8, x24, x16
    4a6c:      	orr	x21, x3, x8, lsl #1
    4a70:      	str	x21, [sp, #0x1b18]
    4a74:      	cmp	x23, #0x3
    4a78:      	b.gt	0x4ab4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1574>
    4a7c:      	cmp	x23, #0x2
    4a80:      	b.lo	0x4acc <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x158c>
    4a84:      	b.eq	0x4b9c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x165c>
    4a88:      	cmp	x23, #0x3
    4a8c:      	b.ne	0x4a5c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x151c>
    4a90:      	ldr	x8, [sp, #0x1ad8]
    4a94:      	cbz	x8, 0x519c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1c5c>
    4a98:      	mov	w9, #0x1768             ; =5992
    4a9c:      	ldrb	w9, [x6, x9]
    4aa0:      	tbz	w9, #0x0, 0x4e54 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1914>
    4aa4:      	mov	x9, #0x0                ; =0
    4aa8:      	ldr	x10, [sp, #0x1ac0]
    4aac:      	cbnz	x10, 0x4e98 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1958>
    4ab0:      	b	0x519c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1c5c>
    4ab4:      	cmp	x17, #0x2
    4ab8:      	b.lo	0x4acc <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x158c>
    4abc:      	cmp	x23, #0x7
    4ac0:      	b.eq	0x4d58 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1818>
    4ac4:      	cmp	x23, #0x4
    4ac8:      	b.ne	0x4a5c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x151c>
    4acc:      	mov	w8, #0x1768             ; =5992
    4ad0:      	ldrb	w8, [x6, x8]
    4ad4:      	tbz	w8, #0x0, 0x4ae8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x15a8>
    4ad8:      	mov	x9, #0x0                ; =0
    4adc:      	ldr	x8, [sp, #0x1ac0]
    4ae0:      	cbnz	x8, 0x4b2c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x15ec>
    4ae4:      	b	0x4a44 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1504>
    4ae8:      	ldr	x8, [sp, #0x1ab0]
    4aec:      	eor	x8, x8, x21
    4af0:      	eor	x8, x8, x8, lsr #30
    4af4:      	mov	x9, #0xe5b9             ; =58809
    4af8:      	movk	x9, #0x1ce4, lsl #16
    4afc:      	movk	x9, #0x476d, lsl #32
    4b00:      	movk	x9, #0xbf58, lsl #48
    4b04:      	mul	x8, x8, x9
    4b08:      	eor	x8, x8, x8, lsr #27
    4b0c:      	mov	x9, #0x11eb             ; =4587
    4b10:      	movk	x9, #0x1331, lsl #16
    4b14:      	movk	x9, #0x49bb, lsl #32
    4b18:      	movk	x9, #0x94d0, lsl #48
    4b1c:      	mul	x8, x8, x9
    4b20:      	eor	x9, x8, x8, lsr #31
    4b24:      	ldr	x8, [sp, #0x1ac0]
    4b28:      	cbz	x8, 0x4a44 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1504>
    4b2c:      	udiv	x10, x9, x8
    4b30:      	msub	x9, x10, x8, x9
    4b34:      	ldr	x10, [sp, #0x1ad0]
    4b38:      	mov	x11, x8
    4b3c:      	b	0x4b54 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1614>
    4b40:      	add	x12, x9, #0x1
    4b44:      	cmp	x12, x8
    4b48:      	csinc	x9, xzr, x9, hs
    4b4c:      	subs	x11, x11, #0x1
    4b50:      	b.eq	0x4a44 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1504>
    4b54:      	madd	x12, x9, x27, x10
    4b58:      	ldr	w13, [x12]
    4b5c:      	cmp	w13, #0x1
    4b60:      	b.eq	0x4b40 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1600>
    4b64:      	cmp	w13, #0x2
    4b68:      	b.ne	0x4a44 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1504>
    4b6c:      	ldr	x13, [x12, #0x8]
    4b70:      	cmp	x13, x21
    4b74:      	b.ne	0x4b40 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1600>
    4b78:      	ldr	x8, [x12, #0x10]
    4b7c:      	str	wzr, [sp, #0xed8]
    4b80:      	str	x8, [sp, #0xee0]
    4b84:      	strb	wzr, [sp, #0xee8]
    4b88:      	ldr	x9, [sp, #0x1ae8]
    4b8c:      	mov	w10, #0x4309            ; =17161
    4b90:      	madd	x8, x9, x10, x8
    4b94:      	add	x8, x8, #0x83
    4b98:      	b	0x4a58 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1518>
    4b9c:      	ldr	x8, [sp, #0x310]
    4ba0:      	add	x8, x8, x24
    4ba4:      	str	x8, [sp, #0xef0]
    4ba8:      	add	x9, x8, #0x1
    4bac:      	dup.2d	v0, x8
    4bb0:      	str	x9, [sp, #0xef8]
    4bb4:      	ldr	q1, [sp, #0x2d0]
    4bb8:      	add.2d	v1, v0, v1
    4bbc:      	str	q1, [sp, #0xf00]
    4bc0:      	ldr	q1, [sp, #0x2c0]
    4bc4:      	add.2d	v1, v0, v1
    4bc8:      	str	q1, [sp, #0xf10]
    4bcc:      	ldr	q1, [sp, #0x2b0]
    4bd0:      	add.2d	v1, v0, v1
    4bd4:      	str	q1, [sp, #0xf20]
    4bd8:      	ldr	q1, [sp, #0x2a0]
    4bdc:      	add.2d	v1, v0, v1
    4be0:      	str	q1, [sp, #0xf30]
    4be4:      	ldr	q1, [sp, #0x290]
    4be8:      	add.2d	v1, v0, v1
    4bec:      	str	q1, [sp, #0xf40]
    4bf0:      	ldr	q1, [sp, #0x280]
    4bf4:      	add.2d	v1, v0, v1
    4bf8:      	str	q1, [sp, #0xf50]
    4bfc:      	ldr	q1, [sp, #0x270]
    4c00:      	add.2d	v1, v0, v1
    4c04:      	str	q1, [sp, #0xf60]
    4c08:      	ldr	q1, [sp, #0x260]
    4c0c:      	add.2d	v1, v0, v1
    4c10:      	str	q1, [sp, #0xf70]
    4c14:      	ldr	q1, [sp, #0x250]
    4c18:      	add.2d	v1, v0, v1
    4c1c:      	str	q1, [sp, #0xf80]
    4c20:      	ldr	q1, [sp, #0x240]
    4c24:      	add.2d	v1, v0, v1
    4c28:      	str	q1, [sp, #0xf90]
    4c2c:      	ldr	q1, [sp, #0x230]
    4c30:      	add.2d	v1, v0, v1
    4c34:      	str	q1, [sp, #0xfa0]
    4c38:      	ldr	q1, [sp, #0x210]
    4c3c:      	add.2d	v1, v0, v1
    4c40:      	str	q1, [sp, #0xfb0]
    4c44:      	ldr	q1, [sp, #0x200]
    4c48:      	add.2d	v1, v0, v1
    4c4c:      	str	q1, [sp, #0xfc0]
    4c50:      	ldr	q1, [sp, #0x1f0]
    4c54:      	add.2d	v1, v0, v1
    4c58:      	str	q1, [sp, #0xfd0]
    4c5c:      	ldr	q1, [sp, #0x1e0]
    4c60:      	add.2d	v0, v0, v1
    4c64:      	str	q0, [sp, #0xfe0]
    4c68:      	ldp	q0, q1, [x19, #0xc0]
    4c6c:      	str	q0, [sp, #0x1be0]
    4c70:      	str	q1, [sp, #0x1bf0]
    4c74:      	ldp	q0, q1, [x19, #0xe0]
    4c78:      	str	q0, [sp, #0x1c00]
    4c7c:      	str	q1, [sp, #0x1c10]
    4c80:      	ldp	q0, q1, [x19, #0x80]
    4c84:      	str	q0, [sp, #0x1ba0]
    4c88:      	str	q1, [sp, #0x1bb0]
    4c8c:      	ldp	q0, q1, [x19, #0xa0]
    4c90:      	str	q0, [sp, #0x1bc0]
    4c94:      	str	q1, [sp, #0x1bd0]
    4c98:      	ldp	q0, q1, [x19, #0x40]
    4c9c:      	str	q0, [sp, #0x1b60]
    4ca0:      	str	q1, [sp, #0x1b70]
    4ca4:      	ldp	q0, q1, [x19, #0x60]
    4ca8:      	str	q0, [sp, #0x1b80]
    4cac:      	str	q1, [sp, #0x1b90]
    4cb0:      	ldp	q0, q1, [x19]
    4cb4:      	str	q0, [sp, #0x1b20]
    4cb8:      	str	q1, [sp, #0x1b30]
    4cbc:      	ldp	q0, q1, [x19, #0x20]
    4cc0:      	str	q0, [sp, #0x1b40]
    4cc4:      	str	q1, [sp, #0x1b50]
    4cc8:      	ldr	x1, [sp, #0x1ac0]
    4ccc:      	ldr	x9, [sp, #0x348]
    4cd0:      	ldr	x8, [x9, #0x20]
    4cd4:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
    4cd8:      	add	x10, x10, #0xb20
    4cdc:      	str	x8, [x10, #0x120]
    4ce0:      	ldp	q1, q0, [x9]
    4ce4:      	stp	q1, q0, [x10, #0x100]
    4ce8:      	ldr	x10, [sp, #0x330]
    4cec:      	str	x8, [x10, #0x20]
    4cf0:      	ldr	x8, [sp, #0x1c38]
    4cf4:      	ldr	x9, [sp, #0x1c68]
    4cf8:      	adds	x8, x8, x9
    4cfc:      	csinv	x9, x8, xzr, lo
    4d00:      	lsr	x8, x1, #14
    4d04:      	stp	q1, q0, [x10]
    4d08:      	cbnz	x8, 0x5640 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x2100>
    4d0c:      	sub	x8, x1, x1, lsr #2
    4d10:      	cmp	x9, x8
    4d14:      	b.lo	0x5640 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x2100>
    4d18:      	ldr	x10, [sp, #0x348]
    4d1c:      	ldr	x9, [x10, #0x20]
    4d20:      	add	x11, sp, #0x1, lsl #12  ; =0x1000
    4d24:      	add	x11, x11, #0xb20
    4d28:      	str	x9, [x11, #0x170]
    4d2c:      	ldp	q1, q0, [x10]
    4d30:      	stp	q1, q0, [x11, #0x150]
    4d34:      	ldr	x9, [sp, #0x1c88]
    4d38:      	cmp	x9, x8, lsr #1
    4d3c:      	b.lo	0x5618 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x20d8>
    4d40:      	cbz	x1, 0x5614 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x20d4>
    4d44:      	cmp	x1, #0x2, lsl #12       ; =0x2000
    4d48:      	mov	w8, #0x2000             ; =8192
    4d4c:      	csel	x8, x1, x8, lo
    4d50:      	lsl	x1, x8, #1
    4d54:      	b	0x5618 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x20d8>
    4d58:      	mov	w8, #0x1768             ; =5992
    4d5c:      	ldrb	w8, [x6, x8]
    4d60:      	tbz	w8, #0x0, 0x4d74 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1834>
    4d64:      	mov	x10, #0x0               ; =0
    4d68:      	ldr	x8, [sp, #0x1ac0]
    4d6c:      	cbnz	x8, 0x4db8 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1878>
    4d70:      	b	0x4e40 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1900>
    4d74:      	ldr	x8, [sp, #0x1ab0]
    4d78:      	eor	x8, x8, x21
    4d7c:      	eor	x8, x8, x8, lsr #30
    4d80:      	mov	x9, #0xe5b9             ; =58809
    4d84:      	movk	x9, #0x1ce4, lsl #16
    4d88:      	movk	x9, #0x476d, lsl #32
    4d8c:      	movk	x9, #0xbf58, lsl #48
    4d90:      	mul	x8, x8, x9
    4d94:      	eor	x8, x8, x8, lsr #27
    4d98:      	mov	x9, #0x11eb             ; =4587
    4d9c:      	movk	x9, #0x1331, lsl #16
    4da0:      	movk	x9, #0x49bb, lsl #32
    4da4:      	movk	x9, #0x94d0, lsl #48
    4da8:      	mul	x8, x8, x9
    4dac:      	eor	x10, x8, x8, lsr #31
    4db0:      	ldr	x8, [sp, #0x1ac0]
    4db4:      	cbz	x8, 0x4e40 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1900>
    4db8:      	mov	x9, #0x0                ; =0
    4dbc:      	udiv	x11, x10, x8
    4dc0:      	msub	x10, x11, x8, x10
    4dc4:      	sub	x11, x8, x10
    4dc8:      	neg	x12, x11
    4dcc:      	ldr	x13, [sp, #0x1ad0]
    4dd0:      	b	0x4de0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x18a0>
    4dd4:      	add	x9, x9, #0x1
    4dd8:      	cmp	x8, x9
    4ddc:      	b.eq	0x4e40 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1900>
    4de0:      	cmp	x9, x11
    4de4:      	csel	x14, x10, x12, lo
    4de8:      	add	x14, x14, x9
    4dec:      	madd	x14, x14, x27, x13
    4df0:      	ldr	w15, [x14]
    4df4:      	cmp	w15, #0x1
    4df8:      	b.eq	0x4dd4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1894>
    4dfc:      	cmp	w15, #0x2
    4e00:      	b.ne	0x4e40 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1900>
    4e04:      	ldr	x15, [x14, #0x8]
    4e08:      	cmp	x15, x21
    4e0c:      	b.ne	0x4dd4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1894>
    4e10:      	ldr	x8, [x14, #0x10]
    4e14:      	add	x9, x8, #0x1
    4e18:      	str	x9, [x14, #0x10]
    4e1c:      	str	wzr, [sp, #0x1a50]
    4e20:      	str	x9, [sp, #0x1a58]
    4e24:      	ldr	x9, [sp, #0x320]
    4e28:      	strb	wzr, [x9, #0x430]
    4e2c:      	ldr	x9, [sp, #0x1ae8]
    4e30:      	mov	w10, #0x4309            ; =17161
    4e34:      	madd	x8, x9, x10, x8
    4e38:      	add	x8, x8, #0x84
    4e3c:      	b	0x4a58 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1518>
    4e40:      	str	w3, [sp, #0x1a50]
    4e44:      	str	xzr, [sp, #0x1a58]
    4e48:      	ldr	x8, [sp, #0x320]
    4e4c:      	strb	wzr, [x8, #0x430]
    4e50:      	b	0x4a50 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1510>
    4e54:      	ldr	x9, [sp, #0x1ab0]
    4e58:      	eor	x9, x9, x21
    4e5c:      	eor	x9, x9, x9, lsr #30
    4e60:      	mov	x10, #0xe5b9            ; =58809
    4e64:      	movk	x10, #0x1ce4, lsl #16
    4e68:      	movk	x10, #0x476d, lsl #32
    4e6c:      	movk	x10, #0xbf58, lsl #48
    4e70:      	mul	x9, x9, x10
    4e74:      	eor	x9, x9, x9, lsr #27
    4e78:      	mov	x10, #0x11eb            ; =4587
    4e7c:      	movk	x10, #0x1331, lsl #16
    4e80:      	movk	x10, #0x49bb, lsl #32
    4e84:      	movk	x10, #0x94d0, lsl #48
    4e88:      	mul	x9, x9, x10
    4e8c:      	eor	x9, x9, x9, lsr #31
    4e90:      	ldr	x10, [sp, #0x1ac0]
    4e94:      	cbz	x10, 0x519c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1c5c>
    4e98:      	udiv	x11, x9, x10
    4e9c:      	msub	x11, x11, x10, x9
    4ea0:      	ldr	x12, [sp, #0x1ad0]
    4ea4:      	mov	x13, x10
    4ea8:      	b	0x4ec0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1980>
    4eac:      	add	x9, x11, #0x1
    4eb0:      	cmp	x9, x10
    4eb4:      	csinc	x11, xzr, x11, hs
    4eb8:      	subs	x13, x13, #0x1
    4ebc:      	b.eq	0x519c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1c5c>
    4ec0:      	madd	x9, x11, x27, x12
    4ec4:      	ldr	w14, [x9]
    4ec8:      	cmp	w14, #0x1
    4ecc:      	b.eq	0x4eac <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x196c>
    4ed0:      	cmp	w14, #0x2
    4ed4:      	b.ne	0x519c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1c5c>
    4ed8:      	ldr	x14, [x9, #0x8]
    4edc:      	cmp	x14, x21
    4ee0:      	b.ne	0x4eac <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x196c>
    4ee4:      	str	w3, [x9]
    4ee8:      	sub	x8, x8, #0x1
    4eec:      	ldp	q0, q1, [x9, #0x10]
    4ef0:      	ldp	q2, q3, [x9, #0x30]
    4ef4:      	ldp	q4, q5, [x9, #0x50]
    4ef8:      	ldp	q6, q7, [x9, #0x70]
    4efc:      	ldp	q16, q17, [x9, #0x90]
    4f00:      	ldp	q18, q19, [x9, #0xb0]
    4f04:      	ldp	q20, q21, [x9, #0xd0]
    4f08:      	ldp	q22, q23, [x9, #0xf0]
    4f0c:      	movi.2d	v24, #0000000000000000
    4f10:      	stur	q24, [x9, #0x18]
    4f14:      	stur	q24, [x9, #0x28]
    4f18:      	stur	q24, [x9, #0x38]
    4f1c:      	stur	q24, [x9, #0x48]
    4f20:      	stur	q24, [x9, #0x58]
    4f24:      	stur	q24, [x9, #0x68]
    4f28:      	stur	q24, [x9, #0x78]
    4f2c:      	stur	q24, [x9, #0x88]
    4f30:      	stur	q24, [x9, #0x98]
    4f34:      	stur	q24, [x9, #0xa8]
    4f38:      	stur	q24, [x9, #0xb8]
    4f3c:      	stur	q24, [x9, #0xc8]
    4f40:      	stur	q24, [x9, #0xd8]
    4f44:      	stur	q24, [x9, #0xe8]
    4f48:      	stur	q24, [x9, #0xf8]
    4f4c:      	stur	q24, [x9, #0x8]
    4f50:      	str	xzr, [x9, #0x108]
    4f54:      	str	x8, [sp, #0x1ad8]
    4f58:      	ldr	x8, [sp, #0x1ae0]
    4f5c:      	adds	x8, x8, #0x1
    4f60:      	csinv	x8, x8, xzr, lo
    4f64:      	str	x8, [sp, #0x1ae0]
    4f68:      	str	x3, [sp, #0x1308]
    4f6c:      	str	x21, [sp, #0x1310]
    4f70:      	ldp	x8, x21, [sp, #0x80]
    4f74:      	str	q0, [x21]
    4f78:      	str	q1, [x8]
    4f7c:      	ldp	x8, x9, [sp, #0x70]
    4f80:      	str	q2, [x9]
    4f84:      	str	q3, [x8]
    4f88:      	ldp	x8, x9, [sp, #0x60]
    4f8c:      	str	q4, [x9]
    4f90:      	str	q5, [x8]
    4f94:      	ldp	x8, x9, [sp, #0x50]
    4f98:      	str	q6, [x9]
    4f9c:      	str	q7, [x8]
    4fa0:      	ldp	x8, x9, [sp, #0x40]
    4fa4:      	str	q16, [x9]
    4fa8:      	str	q17, [x8]
    4fac:      	ldp	x8, x9, [sp, #0x30]
    4fb0:      	str	q18, [x9]
    4fb4:      	str	q19, [x8]
    4fb8:      	ldp	x8, x9, [sp, #0x20]
    4fbc:      	str	q20, [x9]
    4fc0:      	str	q21, [x8]
    4fc4:      	ldp	x8, x9, [sp, #0x10]
    4fc8:      	str	q22, [x9]
    4fcc:      	str	q23, [x8]
    4fd0:      	add	x8, sp, #0x350
    4fd4:      	add	x1, x8, #0xfc0
    4fd8:      	ldr	x0, [sp, #0x98]
    4fdc:      	mov	w2, #0x108              ; =264
    4fe0:      	bl	0x4fe0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1aa0>
		0000000000004fe0:  ARM64_RELOC_BRANCH26	_memcpy
    4fe4:      	mov	w3, #0x1                ; =1
    4fe8:      	add	x6, sp, #0x350
    4fec:      	ldr	x8, [sp, #0x1ae8]
    4ff0:      	ldr	x9, [sp, #0x1418]
    4ff4:      	ldp	q1, q0, [x21, #0x20]
    4ff8:      	ldr	x10, [sp, #0x90]
    4ffc:      	stp	q1, q0, [x10, #0x20]
    5000:      	ldp	q1, q0, [x21, #0x60]
    5004:      	stp	q1, q0, [x10, #0x60]
    5008:      	ldp	q1, q0, [x21, #0x40]
    500c:      	stp	q1, q0, [x10, #0x40]
    5010:      	ldp	q1, q0, [x21, #0xa0]
    5014:      	stp	q1, q0, [x10, #0xa0]
    5018:      	ldp	q1, q0, [x21, #0x80]
    501c:      	stp	q1, q0, [x10, #0x80]
    5020:      	ldp	q1, q0, [x21, #0xe0]
    5024:      	stp	q1, q0, [x10, #0xe0]
    5028:      	ldp	q1, q0, [x21, #0xc0]
    502c:      	stp	q1, q0, [x10, #0xc0]
    5030:      	ldp	q1, q0, [x21]
    5034:      	stp	q1, q0, [x10]
    5038:      	ldr	x10, [sp, #0x1610]
    503c:      	madd	x8, x8, x28, x10
    5040:      	ldr	x10, [sp, #0x1520]
    5044:      	madd	x9, x9, x28, x10
    5048:      	ldr	x10, [sp, #0x1528]
    504c:      	madd	x9, x9, x28, x10
    5050:      	ldr	x10, [sp, #0x1530]
    5054:      	madd	x9, x9, x28, x10
    5058:      	ldr	x10, [sp, #0x1538]
    505c:      	madd	x9, x9, x28, x10
    5060:      	ldr	x10, [sp, #0x1540]
    5064:      	madd	x9, x9, x28, x10
    5068:      	ldr	x10, [sp, #0x1548]
    506c:      	madd	x9, x9, x28, x10
    5070:      	ldr	x10, [sp, #0x1550]
    5074:      	madd	x9, x9, x28, x10
    5078:      	ldr	x10, [sp, #0x1558]
    507c:      	madd	x9, x9, x28, x10
    5080:      	ldr	x10, [sp, #0x1560]
    5084:      	madd	x9, x9, x28, x10
    5088:      	ldr	x10, [sp, #0x1568]
    508c:      	madd	x9, x9, x28, x10
    5090:      	ldr	x10, [sp, #0x1570]
    5094:      	madd	x9, x9, x28, x10
    5098:      	ldr	x10, [sp, #0x1578]
    509c:      	madd	x9, x9, x28, x10
    50a0:      	ldr	x10, [sp, #0x1580]
    50a4:      	madd	x9, x9, x28, x10
    50a8:      	ldr	x10, [sp, #0x1588]
    50ac:      	madd	x9, x9, x28, x10
    50b0:      	ldr	x10, [sp, #0x1590]
    50b4:      	madd	x9, x9, x28, x10
    50b8:      	ldr	x10, [sp, #0x1598]
    50bc:      	madd	x9, x9, x28, x10
    50c0:      	ldr	x10, [sp, #0x15a0]
    50c4:      	madd	x9, x9, x28, x10
    50c8:      	ldr	x10, [sp, #0x15a8]
    50cc:      	madd	x9, x9, x28, x10
    50d0:      	ldr	x10, [sp, #0x15b0]
    50d4:      	madd	x9, x9, x28, x10
    50d8:      	ldr	x10, [sp, #0x15b8]
    50dc:      	madd	x9, x9, x28, x10
    50e0:      	ldr	x10, [sp, #0x15c0]
    50e4:      	madd	x9, x9, x28, x10
    50e8:      	ldr	x10, [sp, #0x15c8]
    50ec:      	madd	x9, x9, x28, x10
    50f0:      	ldr	x10, [sp, #0x15d0]
    50f4:      	madd	x9, x9, x28, x10
    50f8:      	ldr	x10, [sp, #0x15d8]
    50fc:      	madd	x9, x9, x28, x10
    5100:      	ldr	x10, [sp, #0x15e0]
    5104:      	madd	x9, x9, x28, x10
    5108:      	ldr	x10, [sp, #0x15e8]
    510c:      	madd	x9, x9, x28, x10
    5110:      	ldr	x10, [sp, #0x15f0]
    5114:      	madd	x9, x9, x28, x10
    5118:      	ldr	x10, [sp, #0x15f8]
    511c:      	madd	x9, x9, x28, x10
    5120:      	ldr	x10, [sp, #0x1600]
    5124:      	madd	x9, x9, x28, x10
    5128:      	ldr	x10, [sp, #0x1608]
    512c:      	madd	x9, x9, x28, x10
    5130:      	madd	x8, x9, x28, x8
    5134:      	ldr	x9, [sp, #0x1618]
    5138:      	madd	x8, x8, x28, x9
    513c:      	add	x9, x8, #0x83
    5140:      	str	x9, [sp, #0x1ae8]
    5144:      	mov	w8, #0x1768             ; =5992
    5148:      	ldrb	w8, [x6, x8]
    514c:      	ldr	x21, [sp, #0x1b18]
    5150:      	tbnz	w8, #0x0, 0x51e0 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1ca0>
    5154:      	ldr	x8, [sp, #0x1ab0]
    5158:      	eor	x8, x21, x8
    515c:      	eor	x8, x8, x8, lsr #30
    5160:      	mov	x10, #0xe5b9            ; =58809
    5164:      	movk	x10, #0x1ce4, lsl #16
    5168:      	movk	x10, #0x476d, lsl #32
    516c:      	movk	x10, #0xbf58, lsl #48
    5170:      	mul	x8, x8, x10
    5174:      	eor	x8, x8, x8, lsr #27
    5178:      	mov	x10, #0x11eb            ; =4587
    517c:      	movk	x10, #0x1331, lsl #16
    5180:      	movk	x10, #0x49bb, lsl #32
    5184:      	movk	x10, #0x94d0, lsl #48
    5188:      	mul	x8, x8, x10
    518c:      	eor	x10, x8, x8, lsr #31
    5190:      	ldr	x8, [sp, #0x1ac0]
    5194:      	cbnz	x8, 0x51ec <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1cac>
    5198:      	b	0x525c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1d1c>
    519c:      	movi.2d	v0, #0000000000000000
    51a0:      	stp	q0, q0, [x20, #0xf0]
    51a4:      	stp	q0, q0, [x20, #0xd0]
    51a8:      	stp	q0, q0, [x20, #0xb0]
    51ac:      	stp	q0, q0, [x20, #0x90]
    51b0:      	stp	q0, q0, [x20, #0x70]
    51b4:      	stp	q0, q0, [x20, #0x50]
    51b8:      	stp	q0, q0, [x20, #0x30]
    51bc:      	stp	q0, q0, [x20, #0x10]
    51c0:      	ldr	x8, [sp, #0x1ae8]
    51c4:      	mul	x9, x8, x28
    51c8:      	str	q0, [x20]
    51cc:      	str	x9, [sp, #0x1ae8]
    51d0:      	mov	w8, #0x1768             ; =5992
    51d4:      	ldrb	w8, [x6, x8]
    51d8:      	ldr	x21, [sp, #0x1b18]
    51dc:      	tbz	w8, #0x0, 0x5154 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1c14>
    51e0:      	mov	x10, #0x0               ; =0
    51e4:      	ldr	x8, [sp, #0x1ac0]
    51e8:      	cbz	x8, 0x525c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1d1c>
    51ec:      	udiv	x11, x10, x8
    51f0:      	msub	x10, x11, x8, x10
    51f4:      	ldr	x11, [sp, #0x1ad0]
    51f8:      	mov	x12, x8
    51fc:      	b	0x5214 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1cd4>
    5200:      	add	x13, x10, #0x1
    5204:      	cmp	x13, x8
    5208:      	csinc	x10, xzr, x10, hs
    520c:      	subs	x12, x12, #0x1
    5210:      	b.eq	0x525c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1d1c>
    5214:      	madd	x13, x10, x27, x11
    5218:      	ldr	w14, [x13]
    521c:      	cmp	w14, #0x1
    5220:      	b.eq	0x5200 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1cc0>
    5224:      	cmp	w14, #0x2
    5228:      	b.ne	0x525c <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1d1c>
    522c:      	ldr	x14, [x13, #0x8]
    5230:      	cmp	x14, x21
    5234:      	b.ne	0x5200 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1cc0>
    5238:      	ldr	x10, [x13, #0x10]
    523c:      	str	wzr, [sp, #0x1620]
    5240:      	str	x10, [sp, #0x1628]
    5244:      	ldr	x11, [sp, #0x320]
    5248:      	strb	wzr, [x11]
    524c:      	mov	w11, #0x4309            ; =17161
    5250:      	madd	x9, x9, x11, x10
    5254:      	add	x9, x9, #0x83
    5258:      	b	0x5270 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1d30>
    525c:      	str	w3, [sp, #0x1620]
    5260:      	str	xzr, [sp, #0x1628]
    5264:      	mul	x9, x9, x28
    5268:      	ldr	x10, [sp, #0x320]
    526c:      	strb	wzr, [x10]
    5270:      	str	x9, [sp, #0x1ae8]
    5274:      	ldr	x9, [sp, #0x310]
    5278:      	add	x9, x9, x24
    527c:      	add	x10, x9, #0x1f
    5280:      	dup.2d	v0, x9
    5284:      	str	x9, [sp, #0x1638]
    5288:      	ldr	q1, [sp, #0x1d0]
    528c:      	add.2d	v1, v0, v1
    5290:      	str	q1, [sp, #0x1640]
    5294:      	ldr	q1, [sp, #0x1c0]
    5298:      	add.2d	v1, v0, v1
    529c:      	str	q1, [sp, #0x1650]
    52a0:      	ldr	q1, [sp, #0x1b0]
    52a4:      	add.2d	v1, v0, v1
    52a8:      	str	q1, [sp, #0x1660]
    52ac:      	ldr	q1, [sp, #0x1a0]
    52b0:      	add.2d	v1, v0, v1
    52b4:      	str	q1, [sp, #0x1670]
    52b8:      	ldr	q1, [sp, #0x190]
    52bc:      	add.2d	v1, v0, v1
    52c0:      	str	q1, [sp, #0x1680]
    52c4:      	ldr	q1, [sp, #0x180]
    52c8:      	add.2d	v1, v0, v1
    52cc:      	str	q1, [sp, #0x1690]
    52d0:      	ldr	q1, [sp, #0x170]
    52d4:      	add.2d	v1, v0, v1
    52d8:      	str	q1, [sp, #0x16a0]
    52dc:      	ldr	q1, [sp, #0x160]
    52e0:      	add.2d	v1, v0, v1
    52e4:      	str	q1, [sp, #0x16b0]
    52e8:      	ldr	q1, [sp, #0x150]
    52ec:      	add.2d	v1, v0, v1
    52f0:      	str	q1, [sp, #0x16c0]
    52f4:      	ldr	q1, [sp, #0x140]
    52f8:      	add.2d	v1, v0, v1
    52fc:      	str	q1, [sp, #0x16d0]
    5300:      	ldr	q1, [sp, #0x130]
    5304:      	add.2d	v1, v0, v1
    5308:      	str	q1, [sp, #0x16e0]
    530c:      	ldr	q1, [sp, #0x120]
    5310:      	add.2d	v1, v0, v1
    5314:      	str	q1, [sp, #0x16f0]
    5318:      	ldr	q1, [sp, #0x110]
    531c:      	add.2d	v1, v0, v1
    5320:      	str	q1, [sp, #0x1700]
    5324:      	ldr	q1, [sp, #0x100]
    5328:      	add.2d	v1, v0, v1
    532c:      	str	q1, [sp, #0x1710]
    5330:      	ldr	q1, [sp, #0xf0]
    5334:      	add.2d	v0, v0, v1
    5338:      	str	q0, [sp, #0x1720]
    533c:      	str	x10, [sp, #0x1730]
    5340:      	ldp	q0, q1, [x25, #0xc0]
    5344:      	str	q0, [sp, #0x1be0]
    5348:      	str	q1, [sp, #0x1bf0]
    534c:      	ldp	q0, q1, [x25, #0xe0]
    5350:      	str	q0, [sp, #0x1c00]
    5354:      	str	q1, [sp, #0x1c10]
    5358:      	ldp	q0, q1, [x25, #0x80]
    535c:      	str	q0, [sp, #0x1ba0]
    5360:      	str	q1, [sp, #0x1bb0]
    5364:      	ldp	q0, q1, [x25, #0xa0]
    5368:      	str	q0, [sp, #0x1bc0]
    536c:      	str	q1, [sp, #0x1bd0]
    5370:      	ldp	q0, q1, [x25, #0x40]
    5374:      	str	q0, [sp, #0x1b60]
    5378:      	str	q1, [sp, #0x1b70]
    537c:      	ldp	q0, q1, [x25, #0x60]
    5380:      	str	q0, [sp, #0x1b80]
    5384:      	str	q1, [sp, #0x1b90]
    5388:      	ldp	q0, q1, [x25]
    538c:      	str	q0, [sp, #0x1b20]
    5390:      	str	q1, [sp, #0x1b30]
    5394:      	ldp	q0, q1, [x25, #0x20]
    5398:      	str	q0, [sp, #0x1b40]
    539c:      	str	q1, [sp, #0x1b50]
    53a0:      	ldr	x10, [sp, #0x348]
    53a4:      	ldr	x9, [x10, #0x20]
    53a8:      	add	x11, sp, #0x1, lsl #12  ; =0x1000
    53ac:      	add	x11, x11, #0xb20
    53b0:      	str	x9, [x11, #0x120]
    53b4:      	ldp	q1, q0, [x10]
    53b8:      	stp	q1, q0, [x11, #0x100]
    53bc:      	ldr	x11, [sp, #0x330]
    53c0:      	str	x9, [x11, #0x20]
    53c4:      	ldr	x9, [sp, #0x1c38]
    53c8:      	ldr	x10, [sp, #0x1c68]
    53cc:      	adds	x9, x9, x10
    53d0:      	csinv	x10, x9, xzr, lo
    53d4:      	lsr	x9, x8, #14
    53d8:      	stp	q1, q0, [x11]
    53dc:      	cbnz	x9, 0x5450 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1f10>
    53e0:      	sub	x9, x8, x8, lsr #2
    53e4:      	cmp	x10, x9
    53e8:      	b.lo	0x5450 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1f10>
    53ec:      	ldr	x0, [sp, #0x348]
    53f0:      	ldr	x10, [x0, #0x20]
    53f4:      	add	x11, sp, #0x1, lsl #12  ; =0x1000
    53f8:      	add	x11, x11, #0xb20
    53fc:      	str	x10, [x11, #0x170]
    5400:      	ldp	q1, q0, [x0]
    5404:      	stp	q1, q0, [x11, #0x150]
    5408:      	ldr	x10, [sp, #0x1c88]
    540c:      	cmp	x8, #0x2, lsl #12       ; =0x2000
    5410:      	mov	w11, #0x2000            ; =8192
    5414:      	csel	x11, x8, x11, lo
    5418:      	lsl	x11, x11, #1
    541c:      	cmp	x8, #0x0
    5420:      	csinc	x11, x11, xzr, ne
    5424:      	cmp	x10, x9, lsr #1
    5428:      	csel	x1, x8, x11, lo
    542c:      	mov	w8, #0x1760             ; =5984
    5430:      	add	x2, x6, x8
    5434:      	bl	0x5434 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1ef4>
		0000000000005434:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    5438:      	add	x6, sp, #0x350
    543c:      	str	w0, [sp, #0x1c98]
    5440:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
    5444:      	add	x8, x8, #0xb20
    5448:      	strb	w1, [x8, #0x17c]
    544c:      	strb	w2, [x8, #0x17d]
    5450:      	mov	w8, #0x13e8             ; =5096
    5454:      	add	x0, x6, x8
    5458:      	add	x3, sp, #0x1, lsl #12   ; =0x1000
    545c:      	add	x3, x3, #0xb20
    5460:      	add	x8, sp, #0x350
    5464:      	mov	w9, #0x1760             ; =5984
    5468:      	add	x4, x8, x9
    546c:      	ldr	x1, [sp, #0x348]
    5470:      	mov	x2, x21
    5474:      	bl	0x5474 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1f34>
		0000000000005474:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
    5478:      	ldr	w8, [sp, #0x1738]
    547c:      	cbz	w8, 0x5604 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x20c4>
    5480:      	ldr	x8, [sp, #0x320]
    5484:      	ldrb	w21, [x8, #0x10c]
    5488:      	ldr	x0, [sp, #0xe0]
    548c:      	ldr	x1, [sp, #0xc8]
    5490:      	mov	w2, #0x108              ; =264
    5494:      	bl	0x5494 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1f54>
		0000000000005494:  ARM64_RELOC_BRANCH26	_memcpy
    5498:      	ldr	x8, [sp, #0x1ae8]
    549c:      	cmp	w21, #0x0
    54a0:      	mov	w3, #0x1                ; =1
    54a4:      	cinc	x9, x3, ne
    54a8:      	madd	x8, x8, x28, x9
    54ac:      	ldr	x9, [sp, #0x1848]
    54b0:      	ldr	x11, [sp, #0xb8]
    54b4:      	ldp	q1, q0, [x11, #0x60]
    54b8:      	ldr	x10, [sp, #0xd8]
    54bc:      	stp	q1, q0, [x10, #0x60]
    54c0:      	ldp	q1, q0, [x11, #0x40]
    54c4:      	stp	q1, q0, [x10, #0x40]
    54c8:      	ldp	q1, q0, [x11, #0xa0]
    54cc:      	stp	q1, q0, [x10, #0xa0]
    54d0:      	ldp	q1, q0, [x11, #0x80]
    54d4:      	stp	q1, q0, [x10, #0x80]
    54d8:      	ldp	q1, q0, [x11, #0xe0]
    54dc:      	stp	q1, q0, [x10, #0xe0]
    54e0:      	ldp	q1, q0, [x11, #0xc0]
    54e4:      	stp	q1, q0, [x10, #0xc0]
    54e8:      	ldp	q1, q0, [x11, #0x20]
    54ec:      	stp	q1, q0, [x10, #0x20]
    54f0:      	ldp	q0, q1, [x11]
    54f4:      	stp	q0, q1, [x10]
    54f8:      	ldr	x10, [sp, #0x1950]
    54fc:      	madd	x9, x9, x28, x10
    5500:      	ldr	x10, [sp, #0x1958]
    5504:      	madd	x9, x9, x28, x10
    5508:      	ldr	x10, [sp, #0x1960]
    550c:      	madd	x9, x9, x28, x10
    5510:      	ldr	x10, [sp, #0x1968]
    5514:      	madd	x9, x9, x28, x10
    5518:      	ldr	x10, [sp, #0x1970]
    551c:      	madd	x9, x9, x28, x10
    5520:      	ldr	x10, [sp, #0x1978]
    5524:      	madd	x9, x9, x28, x10
    5528:      	ldr	x10, [sp, #0x1980]
    552c:      	madd	x9, x9, x28, x10
    5530:      	ldr	x10, [sp, #0x1988]
    5534:      	madd	x9, x9, x28, x10
    5538:      	ldr	x10, [sp, #0x1990]
    553c:      	madd	x9, x9, x28, x10
    5540:      	ldr	x10, [sp, #0x1998]
    5544:      	madd	x9, x9, x28, x10
    5548:      	ldr	x10, [sp, #0x19a0]
    554c:      	madd	x9, x9, x28, x10
    5550:      	ldr	x10, [sp, #0x19a8]
    5554:      	madd	x9, x9, x28, x10
    5558:      	ldr	x10, [sp, #0x19b0]
    555c:      	madd	x9, x9, x28, x10
    5560:      	ldr	x10, [sp, #0x19b8]
    5564:      	madd	x9, x9, x28, x10
    5568:      	ldr	x10, [sp, #0x19c0]
    556c:      	madd	x9, x9, x28, x10
    5570:      	ldr	x10, [sp, #0x19c8]
    5574:      	madd	x9, x9, x28, x10
    5578:      	ldr	x10, [sp, #0x19d0]
    557c:      	madd	x9, x9, x28, x10
    5580:      	ldr	x10, [sp, #0x19d8]
    5584:      	madd	x9, x9, x28, x10
    5588:      	ldr	x10, [sp, #0x19e0]
    558c:      	madd	x9, x9, x28, x10
    5590:      	ldr	x10, [sp, #0x19e8]
    5594:      	madd	x9, x9, x28, x10
    5598:      	ldr	x10, [sp, #0x19f0]
    559c:      	madd	x9, x9, x28, x10
    55a0:      	ldr	x10, [sp, #0x19f8]
    55a4:      	madd	x9, x9, x28, x10
    55a8:      	ldr	x10, [sp, #0x1a00]
    55ac:      	madd	x9, x9, x28, x10
    55b0:      	ldr	x10, [sp, #0x1a08]
    55b4:      	madd	x9, x9, x28, x10
    55b8:      	ldr	x10, [sp, #0x1a10]
    55bc:      	madd	x9, x9, x28, x10
    55c0:      	ldr	x10, [sp, #0x1a18]
    55c4:      	madd	x9, x9, x28, x10
    55c8:      	ldr	x10, [sp, #0x1a20]
    55cc:      	madd	x9, x9, x28, x10
    55d0:      	ldr	x10, [sp, #0x1a28]
    55d4:      	madd	x9, x9, x28, x10
    55d8:      	ldr	x10, [sp, #0x1a30]
    55dc:      	madd	x9, x9, x28, x10
    55e0:      	ldr	x10, [sp, #0x1a38]
    55e4:      	madd	x9, x9, x28, x10
    55e8:      	ldr	x10, [sp, #0x1a40]
    55ec:      	add	x8, x8, x10
    55f0:      	madd	x8, x9, x28, x8
    55f4:      	ldr	x9, [sp, #0x1a48]
    55f8:      	madd	x8, x8, x28, x9
    55fc:      	add	x6, sp, #0x350
    5600:      	b	0x57f4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x22b4>
    5604:      	ldr	x8, [sp, #0x1ae8]
    5608:      	mul	x8, x8, x28
    560c:      	add	x6, sp, #0x350
    5610:      	b	0x5810 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x22d0>
    5614:      	mov	w1, #0x1                ; =1
    5618:      	mov	w8, #0x1760             ; =5984
    561c:      	add	x2, x6, x8
    5620:      	ldr	x0, [sp, #0x348]
    5624:      	bl	0x5624 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x20e4>
		0000000000005624:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    5628:      	add	x6, sp, #0x350
    562c:      	str	w0, [sp, #0x1c98]
    5630:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
    5634:      	add	x8, x8, #0xb20
    5638:      	strb	w1, [x8, #0x17c]
    563c:      	strb	w2, [x8, #0x17d]
    5640:      	add	x0, x6, #0xca0
    5644:      	add	x3, sp, #0x1, lsl #12   ; =0x1000
    5648:      	add	x3, x3, #0xb20
    564c:      	add	x23, sp, #0x350
    5650:      	mov	w8, #0x1760             ; =5984
    5654:      	add	x4, x23, x8
    5658:      	ldr	x1, [sp, #0x348]
    565c:      	mov	x2, x21
    5660:      	bl	0x5660 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x2120>
		0000000000005660:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
    5664:      	ldr	w8, [sp, #0xff0]
    5668:      	cbz	w8, 0x5800 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x22c0>
    566c:      	ldr	x8, [sp, #0x228]
    5670:      	ldrb	w21, [x8, #0xba0]
    5674:      	add	x0, x23, #0xdb0
    5678:      	add	x8, sp, #0x350
    567c:      	add	x1, x8, #0xca8
    5680:      	mov	w2, #0x108              ; =264
    5684:      	bl	0x5684 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x2144>
		0000000000005684:  ARM64_RELOC_BRANCH26	_memcpy
    5688:      	ldr	x8, [sp, #0x1ae8]
    568c:      	cmp	w21, #0x0
    5690:      	mov	w3, #0x1                ; =1
    5694:      	cinc	x9, x3, ne
    5698:      	madd	x8, x8, x28, x9
    569c:      	ldr	x9, [sp, #0x1100]
    56a0:      	ldr	x11, [sp, #0xb0]
    56a4:      	ldp	q1, q0, [x11, #0x60]
    56a8:      	ldr	x10, [sp, #0xd0]
    56ac:      	stp	q1, q0, [x10, #0x60]
    56b0:      	ldp	q1, q0, [x11, #0x40]
    56b4:      	stp	q1, q0, [x10, #0x40]
    56b8:      	ldp	q1, q0, [x11, #0xa0]
    56bc:      	stp	q1, q0, [x10, #0xa0]
    56c0:      	ldp	q1, q0, [x11, #0x80]
    56c4:      	stp	q1, q0, [x10, #0x80]
    56c8:      	ldp	q1, q0, [x11, #0xe0]
    56cc:      	stp	q1, q0, [x10, #0xe0]
    56d0:      	ldp	q1, q0, [x11, #0xc0]
    56d4:      	stp	q1, q0, [x10, #0xc0]
    56d8:      	ldp	q1, q0, [x11, #0x20]
    56dc:      	stp	q1, q0, [x10, #0x20]
    56e0:      	ldp	q0, q1, [x11]
    56e4:      	stp	q0, q1, [x10]
    56e8:      	ldr	x10, [sp, #0x1208]
    56ec:      	madd	x9, x9, x28, x10
    56f0:      	ldr	x10, [sp, #0x1210]
    56f4:      	madd	x9, x9, x28, x10
    56f8:      	ldr	x10, [sp, #0x1218]
    56fc:      	madd	x9, x9, x28, x10
    5700:      	ldr	x10, [sp, #0x1220]
    5704:      	madd	x9, x9, x28, x10
    5708:      	ldr	x10, [sp, #0x1228]
    570c:      	madd	x9, x9, x28, x10
    5710:      	ldr	x10, [sp, #0x1230]
    5714:      	madd	x9, x9, x28, x10
    5718:      	ldr	x10, [sp, #0x1238]
    571c:      	madd	x9, x9, x28, x10
    5720:      	ldr	x10, [sp, #0x1240]
    5724:      	madd	x9, x9, x28, x10
    5728:      	ldr	x10, [sp, #0x1248]
    572c:      	madd	x9, x9, x28, x10
    5730:      	ldr	x10, [sp, #0x1250]
    5734:      	madd	x9, x9, x28, x10
    5738:      	ldr	x10, [sp, #0x1258]
    573c:      	madd	x9, x9, x28, x10
    5740:      	ldr	x10, [sp, #0x1260]
    5744:      	madd	x9, x9, x28, x10
    5748:      	ldr	x10, [sp, #0x1268]
    574c:      	madd	x9, x9, x28, x10
    5750:      	ldr	x10, [sp, #0x1270]
    5754:      	madd	x9, x9, x28, x10
    5758:      	ldr	x10, [sp, #0x1278]
    575c:      	madd	x9, x9, x28, x10
    5760:      	ldr	x10, [sp, #0x1280]
    5764:      	madd	x9, x9, x28, x10
    5768:      	ldr	x10, [sp, #0x1288]
    576c:      	madd	x9, x9, x28, x10
    5770:      	ldr	x10, [sp, #0x1290]
    5774:      	madd	x9, x9, x28, x10
    5778:      	ldr	x10, [sp, #0x1298]
    577c:      	madd	x9, x9, x28, x10
    5780:      	ldr	x10, [sp, #0x12a0]
    5784:      	madd	x9, x9, x28, x10
    5788:      	ldr	x10, [sp, #0x12a8]
    578c:      	madd	x9, x9, x28, x10
    5790:      	ldr	x10, [sp, #0x12b0]
    5794:      	madd	x9, x9, x28, x10
    5798:      	ldr	x10, [sp, #0x12b8]
    579c:      	madd	x9, x9, x28, x10
    57a0:      	ldr	x10, [sp, #0x12c0]
    57a4:      	madd	x9, x9, x28, x10
    57a8:      	ldr	x10, [sp, #0x12c8]
    57ac:      	madd	x9, x9, x28, x10
    57b0:      	ldr	x10, [sp, #0x12d0]
    57b4:      	madd	x9, x9, x28, x10
    57b8:      	ldr	x10, [sp, #0x12d8]
    57bc:      	madd	x9, x9, x28, x10
    57c0:      	ldr	x10, [sp, #0x12e0]
    57c4:      	madd	x9, x9, x28, x10
    57c8:      	ldr	x10, [sp, #0x12e8]
    57cc:      	madd	x9, x9, x28, x10
    57d0:      	ldr	x10, [sp, #0x12f0]
    57d4:      	madd	x9, x9, x28, x10
    57d8:      	ldr	x10, [sp, #0x12f8]
    57dc:      	add	x8, x8, x10
    57e0:      	madd	x8, x9, x28, x8
    57e4:      	ldr	x9, [sp, #0x1300]
    57e8:      	madd	x8, x8, x28, x9
    57ec:      	add	x6, sp, #0x350
    57f0:      	ldr	x23, [sp, #0x2e0]
    57f4:      	ldr	x16, [sp, #0x300]
    57f8:      	mov	x17, x26
    57fc:      	b	0x4a58 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1518>
    5800:      	ldr	x8, [sp, #0x1ae8]
    5804:      	mul	x8, x8, x28
    5808:      	add	x6, sp, #0x350
    580c:      	ldr	x23, [sp, #0x2e0]
    5810:      	ldr	x16, [sp, #0x300]
    5814:      	mov	x17, x26
    5818:      	mov	w3, #0x1                ; =1
    581c:      	b	0x4a58 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1518>
    5820:      	mov	w8, #0x1718             ; =5912
    5824:      	add	x9, sp, #0x350
    5828:      	add	x0, x9, x8
    582c:      	ldr	x8, [sp, #0x348]
    5830:      	ldp	q0, q1, [x8]
    5834:      	stp	q0, q1, [x0]
    5838:      	ldr	x8, [x8, #0x20]
    583c:      	str	x8, [sp, #0x1a88]
    5840:      	ldr	x19, [sp, #0x8]
    5844:      	mov	x1, x19
    5848:      	bl	0x5848 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x2308>
		0000000000005848:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71
    584c:      	ldp	q0, q1, [x19]
    5850:      	str	q0, [sp, #0x1a90]
    5854:      	str	q1, [sp, #0x1aa0]
    5858:      	ldr	x8, [sp, #0x1a90]
    585c:      	ldr	x9, [sp, #0x1a98]
    5860:      	ldr	x10, [sp, #0x1aa0]
    5864:      	ldr	x11, [sp, #0x1aa8]
    5868:      	eor	x8, x8, x8, lsr #30
    586c:      	mov	x13, #0xe5b9            ; =58809
    5870:      	movk	x13, #0x1ce4, lsl #16
    5874:      	movk	x13, #0x476d, lsl #32
    5878:      	movk	x13, #0xbf58, lsl #48
    587c:      	mul	x8, x8, x13
    5880:      	eor	x8, x8, x8, lsr #27
    5884:      	mov	x12, #0x11eb            ; =4587
    5888:      	movk	x12, #0x1331, lsl #16
    588c:      	movk	x12, #0x49bb, lsl #32
    5890:      	movk	x12, #0x94d0, lsl #48
    5894:      	mul	x8, x8, x12
    5898:      	eor	x9, x9, x9, lsr #30
    589c:      	mul	x9, x9, x13
    58a0:      	eor	x9, x9, x9, lsr #27
    58a4:      	mul	x9, x9, x12
    58a8:      	eor	x12, x9, x8
    58ac:      	mov	x13, #0x7c15            ; =31765
    58b0:      	movk	x13, #0x7f4a, lsl #16
    58b4:      	movk	x13, #0x79b9, lsl #32
    58b8:      	movk	x13, #0x9e37, lsl #48
    58bc:      	mul	x11, x11, x13
    58c0:      	eor	x10, x10, x11
    58c4:      	eor	x10, x10, x12, lsr #31
    58c8:      	eor	x8, x8, x9
    58cc:      	eor	x0, x10, x8
    58d0:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
    58d4:      	add	sp, sp, #0xca0
    58d8:      	ldp	x29, x30, [sp, #0x50]
    58dc:      	ldp	x20, x19, [sp, #0x40]
    58e0:      	ldp	x22, x21, [sp, #0x30]
    58e4:      	ldp	x24, x23, [sp, #0x20]
    58e8:      	ldp	x26, x25, [sp, #0x10]
    58ec:      	ldp	x28, x27, [sp], #0x60
    58f0:      	ret
    58f4:      	bl	0x58f4 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x23b4>
		00000000000058f4:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

00000000000058f8 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd>:
    58f8:      	sub	sp, sp, #0xa0
    58fc:      	stp	x28, x27, [sp, #0x40]
    5900:      	stp	x26, x25, [sp, #0x50]
    5904:      	stp	x24, x23, [sp, #0x60]
    5908:      	stp	x22, x21, [sp, #0x70]
    590c:      	stp	x20, x19, [sp, #0x80]
    5910:      	stp	x29, x30, [sp, #0x90]
    5914:      	mov	x19, x2
    5918:      	mov	x21, x1
    591c:      	mov	x20, x0
    5920:      	mov	x22, #0x7c15            ; =31765
    5924:      	movk	x22, #0x7f4a, lsl #16
    5928:      	movk	x22, #0x79b9, lsl #32
    592c:      	movk	x22, #0x9e37, lsl #48
    5930:      	eor	x25, x2, x22
    5934:      	str	x25, [sp, #0x28]
    5938:      	strb	wzr, [sp, #0x30]
    593c:      	cbz	x0, 0x5970 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x78>
    5940:      	add	x8, x20, x20, lsl #1
    5944:      	lsl	x0, x8, #3
    5948:      	bl	0x5948 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x50>
		0000000000005948:  ARM64_RELOC_BRANCH26	_malloc
    594c:      	cbz	x0, 0x5e0c <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x514>
    5950:      	mov	x8, #0x0                ; =0
    5954:      	add	x9, x0, #0x8
    5958:      	stur	wzr, [x9, #-0x8]
    595c:      	add	x8, x8, #0x1
    5960:      	stp	xzr, xzr, [x9], #0x18
    5964:      	cmp	x20, x8
    5968:      	b.ne	0x5958 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x60>
    596c:      	b	0x5978 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x80>
    5970:      	adrp	x0, 0x5000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1ac0>
		0000000000005970:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    5974:      	add	x0, x0, #0x0
		0000000000005974:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    5978:      	mov	x24, #0xe5b9            ; =58809
    597c:      	movk	x24, #0x1ce4, lsl #16
    5980:      	movk	x24, #0x476d, lsl #32
    5984:      	movk	x24, #0xbf58, lsl #48
    5988:      	mov	x16, #0x11eb            ; =4587
    598c:      	movk	x16, #0x1331, lsl #16
    5990:      	movk	x16, #0x49bb, lsl #32
    5994:      	movk	x16, #0x94d0, lsl #48
    5998:      	stp	x20, x20, [sp]
    599c:      	stp	xzr, xzr, [sp, #0x18]
    59a0:      	str	x0, [sp, #0x10]
    59a4:      	cbz	x21, 0x5cbc <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x3c4>
    59a8:      	mov	x26, #0x0               ; =0
    59ac:      	ldrb	w27, [sp, #0x30]
    59b0:      	mov	w28, #0x1               ; =1
    59b4:      	mov	w22, #0x18              ; =24
    59b8:      	mov	w23, #0x83              ; =131
    59bc:      	mov	x1, x20
    59c0:      	mov	x20, x19
    59c4:      	b	0x59ec <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0xf4>
    59c8:      	strb	w28, [sp, #0x3c]
    59cc:      	tst	w28, #0x1
    59d0:      	cinc	x10, x28, ne
    59d4:      	madd	x8, x20, x23, x8
    59d8:      	add	x8, x8, x10
    59dc:      	madd	x20, x8, x23, x9
    59e0:      	add	x26, x26, #0x1
    59e4:      	cmp	x26, x21
    59e8:      	b.eq	0x5ba4 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x2ac>
    59ec:      	ldp	x8, x9, [sp, #0x18]
    59f0:      	adds	x9, x8, x9
    59f4:      	csinv	x9, x9, xzr, lo
    59f8:      	lsr	x10, x1, #14
    59fc:      	cbnz	x10, 0x5a4c <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x154>
    5a00:      	sub	x10, x1, x1, lsr #2
    5a04:      	cmp	x9, x10
    5a08:      	b.lo	0x5a4c <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x154>
    5a0c:      	cmp	x8, x10, lsr #1
    5a10:      	b.lo	0x5a30 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x138>
    5a14:      	cbz	x1, 0x5a2c <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x134>
    5a18:      	cmp	x1, #0x2, lsl #12       ; =0x2000
    5a1c:      	mov	w8, #0x2000             ; =8192
    5a20:      	csel	x8, x1, x8, lo
    5a24:      	lsl	x1, x8, #1
    5a28:      	b	0x5a30 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x138>
    5a2c:      	mov	w1, #0x1                ; =1
    5a30:      	mov	x0, sp
    5a34:      	add	x2, sp, #0x28
    5a38:      	bl	0x5a38 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x140>
		0000000000005a38:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    5a3c:      	mov	x16, #0x11eb            ; =4587
    5a40:      	movk	x16, #0x1331, lsl #16
    5a44:      	movk	x16, #0x49bb, lsl #32
    5a48:      	movk	x16, #0x94d0, lsl #48
    5a4c:      	orr	x8, x28, x26, lsl #1
    5a50:      	tbz	w27, #0x0, 0x5adc <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x1e4>
    5a54:      	mov	x10, #0x0               ; =0
    5a58:      	add	x9, x26, x19
    5a5c:      	ldr	x1, [sp]
    5a60:      	cbz	x1, 0x5b00 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x208>
    5a64:      	udiv	x11, x10, x1
    5a68:      	msub	x11, x11, x1, x10
    5a6c:      	ldr	x12, [sp, #0x10]
    5a70:      	mov	x13, x1
    5a74:      	mov	x10, x1
    5a78:      	b	0x5a98 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x1a0>
    5a7c:      	cmp	x10, x1
    5a80:      	csel	x10, x11, x10, eq
    5a84:      	add	x14, x11, #0x1
    5a88:      	cmp	x14, x1
    5a8c:      	csinc	x11, xzr, x11, hs
    5a90:      	subs	x13, x13, #0x1
    5a94:      	b.eq	0x5b04 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x20c>
    5a98:      	madd	x14, x11, x22, x12
    5a9c:      	ldr	w15, [x14]
    5aa0:      	cmp	w15, #0x1
    5aa4:      	b.eq	0x5a7c <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x184>
    5aa8:      	cmp	w15, #0x2
    5aac:      	b.ne	0x5b54 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x25c>
    5ab0:      	ldr	x15, [x14, #0x8]
    5ab4:      	cmp	x15, x8
    5ab8:      	b.ne	0x5a84 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x18c>
    5abc:      	ldr	x11, [x14, #0x10]
    5ac0:      	mov	w10, #0x2               ; =2
    5ac4:      	str	w10, [x14]
    5ac8:      	str	x9, [x14, #0x10]
    5acc:      	strb	wzr, [sp, #0x3c]
    5ad0:      	mov	w10, #0x1               ; =1
    5ad4:      	mov	x9, x11
    5ad8:      	b	0x59d4 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0xdc>
    5adc:      	eor	x9, x8, x25
    5ae0:      	eor	x9, x9, x9, lsr #30
    5ae4:      	mul	x9, x9, x24
    5ae8:      	eor	x9, x9, x9, lsr #27
    5aec:      	mul	x9, x9, x16
    5af0:      	eor	x10, x9, x9, lsr #31
    5af4:      	add	x9, x26, x19
    5af8:      	ldr	x1, [sp]
    5afc:      	cbnz	x1, 0x5a64 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x16c>
    5b00:      	mov	x10, #0x0               ; =0
    5b04:      	cmp	x10, x1
    5b08:      	b.hs	0x59c8 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0xd0>
    5b0c:      	ldr	x11, [sp, #0x18]
    5b10:      	lsr	x12, x11, #14
    5b14:      	cbnz	x12, 0x59c8 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0xd0>
    5b18:      	add	x11, x11, #0x1
    5b1c:      	str	x11, [sp, #0x18]
    5b20:      	ldr	x11, [sp, #0x10]
    5b24:      	madd	x10, x10, x22, x11
    5b28:      	ldr	w13, [x10]
    5b2c:      	cmp	w13, #0x1
    5b30:      	b.ne	0x5b68 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x270>
    5b34:      	ldr	x11, [sp, #0x20]
    5b38:      	subs	x11, x11, #0x1
    5b3c:      	csel	x11, xzr, x11, lo
    5b40:      	str	x11, [sp, #0x20]
    5b44:      	mov	w11, #0x2               ; =2
    5b48:      	str	w11, [x10]
    5b4c:      	stp	x8, x9, [x10, #0x8]
    5b50:      	b	0x5b90 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x298>
    5b54:      	cmp	x10, x1
    5b58:      	csel	x10, x11, x10, eq
    5b5c:      	cmp	x10, x1
    5b60:      	b.hs	0x59c8 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0xd0>
    5b64:      	b	0x5b0c <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x214>
    5b68:      	ldp	x11, x12, [x10, #0x8]
    5b6c:      	mov	w14, #0x2               ; =2
    5b70:      	str	w14, [x10]
    5b74:      	stp	x8, x9, [x10, #0x8]
    5b78:      	cbz	w13, 0x5b90 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x298>
    5b7c:      	strb	wzr, [sp, #0x3c]
    5b80:      	mov	w10, #0x1               ; =1
    5b84:      	mov	x9, x12
    5b88:      	mov	x8, x11
    5b8c:      	b	0x59d4 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0xdc>
    5b90:      	strb	wzr, [sp, #0x3c]
    5b94:      	mul	x20, x20, x23
    5b98:      	add	x26, x26, #0x1
    5b9c:      	cmp	x26, x21
    5ba0:      	b.ne	0x59ec <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0xf4>
    5ba4:      	ldp	x0, x21, [sp, #0x10]
    5ba8:      	mov	x19, x20
    5bac:      	ldr	x20, [sp, #0x8]
    5bb0:      	mov	x22, #0x7c15            ; =31765
    5bb4:      	movk	x22, #0x7f4a, lsl #16
    5bb8:      	movk	x22, #0x79b9, lsl #32
    5bbc:      	movk	x22, #0x9e37, lsl #48
    5bc0:      	cbz	x1, 0x5cc4 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x3cc>
    5bc4:      	and	x8, x1, #0x3
    5bc8:      	cmp	x1, #0x4
    5bcc:      	b.hs	0x5cd8 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x3e0>
    5bd0:      	mov	x9, #0x0                ; =0
    5bd4:      	mov	x25, #0x0               ; =0
    5bd8:      	mov	x26, #0x0               ; =0
    5bdc:      	mov	x10, x1
    5be0:      	cbz	x8, 0x5c3c <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x344>
    5be4:      	mov	w11, #0x18              ; =24
    5be8:      	madd	x10, x10, x11, x0
    5bec:      	sub	x10, x10, #0x8
    5bf0:      	mov	w11, #0x83              ; =131
    5bf4:      	b	0x5c04 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x30c>
    5bf8:      	sub	x10, x10, #0x18
    5bfc:      	subs	x8, x8, #0x1
    5c00:      	b.eq	0x5c3c <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x344>
    5c04:      	ldur	w12, [x10, #-0x10]
    5c08:      	cmp	w12, #0x2
    5c0c:      	b.ne	0x5bf8 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x300>
    5c10:      	ldp	x13, x12, [x10, #-0x8]
    5c14:      	madd	x12, x13, x11, x12
    5c18:      	add	x26, x12, x26
    5c1c:      	eor	x12, x12, x12, lsr #30
    5c20:      	mul	x12, x12, x24
    5c24:      	eor	x12, x12, x12, lsr #27
    5c28:      	mul	x12, x12, x16
    5c2c:      	eor	x13, x25, x12, lsr #31
    5c30:      	eor	x25, x13, x12
    5c34:      	add	x9, x9, #0x1
    5c38:      	b	0x5bf8 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x300>
    5c3c:      	mul	x22, x9, x22
    5c40:      	cbz	x20, 0x5c60 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x368>
    5c44:      	mov	x20, x1
    5c48:      	bl	0x5c48 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x350>
		0000000000005c48:  ARM64_RELOC_BRANCH26	_free
    5c4c:      	mov	x16, #0x11eb            ; =4587
    5c50:      	movk	x16, #0x1331, lsl #16
    5c54:      	movk	x16, #0x49bb, lsl #32
    5c58:      	movk	x16, #0x94d0, lsl #48
    5c5c:      	mov	x1, x20
    5c60:      	add	x8, x21, x1, lsl #32
    5c64:      	eor	x9, x19, x19, lsr #30
    5c68:      	mul	x9, x9, x24
    5c6c:      	eor	x9, x9, x9, lsr #27
    5c70:      	mul	x9, x9, x16
    5c74:      	eor	x10, x26, x26, lsr #30
    5c78:      	mul	x10, x10, x24
    5c7c:      	eor	x10, x10, x10, lsr #27
    5c80:      	mul	x10, x10, x16
    5c84:      	eor	x11, x10, x9
    5c88:      	eor	x8, x8, x25
    5c8c:      	eor	x8, x8, x22
    5c90:      	eor	x8, x8, x11, lsr #31
    5c94:      	eor	x9, x9, x10
    5c98:      	eor	x0, x8, x9
    5c9c:      	ldp	x29, x30, [sp, #0x90]
    5ca0:      	ldp	x20, x19, [sp, #0x80]
    5ca4:      	ldp	x22, x21, [sp, #0x70]
    5ca8:      	ldp	x24, x23, [sp, #0x60]
    5cac:      	ldp	x26, x25, [sp, #0x50]
    5cb0:      	ldp	x28, x27, [sp, #0x40]
    5cb4:      	add	sp, sp, #0xa0
    5cb8:      	ret
    5cbc:      	mov	x1, x20
    5cc0:      	cbnz	x20, 0x5bc4 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x2cc>
    5cc4:      	mov	x22, #0x0               ; =0
    5cc8:      	mov	x25, #0x0               ; =0
    5ccc:      	mov	x26, #0x0               ; =0
    5cd0:      	cbnz	x20, 0x5c44 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x34c>
    5cd4:      	b	0x5c60 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x368>
    5cd8:      	mov	x9, #0x0                ; =0
    5cdc:      	mov	x25, #0x0               ; =0
    5ce0:      	mov	x26, #0x0               ; =0
    5ce4:      	and	x11, x1, #0xfffffffffffffffc
    5ce8:      	mov	w10, #0x18              ; =24
    5cec:      	madd	x10, x1, x10, x0
    5cf0:      	sub	x12, x10, #0x30
    5cf4:      	mov	w13, #0x83              ; =131
    5cf8:      	mov	x10, x1
    5cfc:      	b	0x5d10 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x418>
    5d00:      	sub	x12, x12, #0x60
    5d04:      	sub	x10, x10, #0x4
    5d08:      	sub	x11, x11, #0x4
    5d0c:      	cbz	x11, 0x5be0 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x2e8>
    5d10:      	ldr	w14, [x12, #0x18]
    5d14:      	cmp	w14, #0x2
    5d18:      	b.eq	0x5d44 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x44c>
    5d1c:      	ldr	w14, [x12]
    5d20:      	cmp	w14, #0x2
    5d24:      	b.eq	0x5d78 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x480>
    5d28:      	ldur	w14, [x12, #-0x18]
    5d2c:      	cmp	w14, #0x2
    5d30:      	b.eq	0x5dac <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x4b4>
    5d34:      	ldur	w14, [x12, #-0x30]
    5d38:      	cmp	w14, #0x2
    5d3c:      	b.ne	0x5d00 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x408>
    5d40:      	b	0x5de0 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x4e8>
    5d44:      	ldp	x15, x14, [x12, #0x20]
    5d48:      	madd	x14, x15, x13, x14
    5d4c:      	add	x26, x14, x26
    5d50:      	eor	x14, x14, x14, lsr #30
    5d54:      	mul	x14, x14, x24
    5d58:      	eor	x14, x14, x14, lsr #27
    5d5c:      	mul	x14, x14, x16
    5d60:      	eor	x15, x25, x14, lsr #31
    5d64:      	eor	x25, x15, x14
    5d68:      	add	x9, x9, #0x1
    5d6c:      	ldr	w14, [x12]
    5d70:      	cmp	w14, #0x2
    5d74:      	b.ne	0x5d28 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x430>
    5d78:      	ldp	x15, x14, [x12, #0x8]
    5d7c:      	madd	x14, x15, x13, x14
    5d80:      	add	x26, x14, x26
    5d84:      	eor	x14, x14, x14, lsr #30
    5d88:      	mul	x14, x14, x24
    5d8c:      	eor	x14, x14, x14, lsr #27
    5d90:      	mul	x14, x14, x16
    5d94:      	eor	x15, x25, x14, lsr #31
    5d98:      	eor	x25, x15, x14
    5d9c:      	add	x9, x9, #0x1
    5da0:      	ldur	w14, [x12, #-0x18]
    5da4:      	cmp	w14, #0x2
    5da8:      	b.ne	0x5d34 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x43c>
    5dac:      	ldp	x15, x14, [x12, #-0x10]
    5db0:      	madd	x14, x15, x13, x14
    5db4:      	add	x26, x14, x26
    5db8:      	eor	x14, x14, x14, lsr #30
    5dbc:      	mul	x14, x14, x24
    5dc0:      	eor	x14, x14, x14, lsr #27
    5dc4:      	mul	x14, x14, x16
    5dc8:      	eor	x15, x25, x14, lsr #31
    5dcc:      	eor	x25, x15, x14
    5dd0:      	add	x9, x9, #0x1
    5dd4:      	ldur	w14, [x12, #-0x30]
    5dd8:      	cmp	w14, #0x2
    5ddc:      	b.ne	0x5d00 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x408>
    5de0:      	ldp	x15, x14, [x12, #-0x28]
    5de4:      	madd	x14, x15, x13, x14
    5de8:      	add	x26, x14, x26
    5dec:      	eor	x14, x14, x14, lsr #30
    5df0:      	mul	x14, x14, x24
    5df4:      	eor	x14, x14, x14, lsr #27
    5df8:      	mul	x14, x14, x16
    5dfc:      	eor	x15, x25, x14, lsr #31
    5e00:      	eor	x25, x15, x14
    5e04:      	add	x9, x9, #0x1
    5e08:      	b	0x5d00 <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x408>
    5e0c:      	bl	0x5e0c <_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd+0x514>
		0000000000005e0c:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

0000000000005e10 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027>:
    5e10:      	stp	x28, x27, [sp, #-0x60]!
    5e14:      	stp	x26, x25, [sp, #0x10]
    5e18:      	stp	x24, x23, [sp, #0x20]
    5e1c:      	stp	x22, x21, [sp, #0x30]
    5e20:      	stp	x20, x19, [sp, #0x40]
    5e24:      	stp	x29, x30, [sp, #0x50]
    5e28:      	sub	sp, sp, #0x3e0
    5e2c:      	mov	x19, x2
    5e30:      	mov	x20, x1
    5e34:      	mov	x21, x0
    5e38:      	mov	x22, #0x7c15            ; =31765
    5e3c:      	movk	x22, #0x7f4a, lsl #16
    5e40:      	movk	x22, #0x79b9, lsl #32
    5e44:      	movk	x22, #0x9e37, lsl #48
    5e48:      	eor	x8, x2, x22
    5e4c:      	str	x8, [sp, #0x140]
    5e50:      	strb	wzr, [sp, #0x148]
    5e54:      	cbz	x0, 0x6138 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x328>
    5e58:      	add	x8, x21, x21, lsl #4
    5e5c:      	lsl	x0, x8, #4
    5e60:      	bl	0x5e60 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x50>
		0000000000005e60:  ARM64_RELOC_BRANCH26	_malloc
    5e64:      	cbz	x0, 0x61f0 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x3e0>
    5e68:      	mov	x8, #0x0                ; =0
    5e6c:      	add	x9, x0, #0x8
    5e70:      	movi.2d	v0, #0000000000000000
    5e74:      	stur	wzr, [x9, #-0x8]
    5e78:      	add	x8, x8, #0x1
    5e7c:      	stp	q0, q0, [x9]
    5e80:      	stp	q0, q0, [x9, #0x20]
    5e84:      	stp	q0, q0, [x9, #0x40]
    5e88:      	stp	q0, q0, [x9, #0x60]
    5e8c:      	stp	q0, q0, [x9, #0x80]
    5e90:      	stp	q0, q0, [x9, #0xa0]
    5e94:      	stp	q0, q0, [x9, #0xc0]
    5e98:      	stp	q0, q0, [x9, #0xe0]
    5e9c:      	str	xzr, [x9, #0x100]
    5ea0:      	add	x9, x9, #0x110
    5ea4:      	cmp	x21, x8
    5ea8:      	b.ne	0x5e74 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x64>
    5eac:      	stp	x21, x21, [sp, #0x118]
    5eb0:      	stp	xzr, xzr, [sp, #0x130]
    5eb4:      	str	x0, [sp, #0x128]
    5eb8:      	stp	x19, xzr, [sp, #0xf8]
    5ebc:      	stp	xzr, xzr, [sp, #0x108]
    5ec0:      	cbz	x20, 0x6158 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x348>
    5ec4:      	adrp	x8, 0x5000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1ac0>
		0000000000005ec4:  ARM64_RELOC_PAGE21	lCPI70_0
    5ec8:      	ldr	q0, [x8]
		0000000000005ec8:  ARM64_RELOC_PAGEOFF12	lCPI70_0
    5ecc:      	str	q0, [sp, #0xe0]
    5ed0:      	add	x23, sp, #0x260
    5ed4:      	adrp	x8, 0x5000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1ac0>
		0000000000005ed4:  ARM64_RELOC_PAGE21	lCPI70_1
    5ed8:      	ldr	q0, [x8]
		0000000000005ed8:  ARM64_RELOC_PAGEOFF12	lCPI70_1
    5edc:      	str	q0, [sp, #0xd0]
    5ee0:      	add	x24, sp, #0x260
    5ee4:      	adrp	x8, 0x5000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1ac0>
		0000000000005ee4:  ARM64_RELOC_PAGE21	lCPI70_2
    5ee8:      	ldr	q0, [x8]
		0000000000005ee8:  ARM64_RELOC_PAGEOFF12	lCPI70_2
    5eec:      	str	q0, [sp, #0xc0]
    5ef0:      	add	x25, x24, #0x128
    5ef4:      	adrp	x8, 0x5000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1ac0>
		0000000000005ef4:  ARM64_RELOC_PAGE21	lCPI70_3
    5ef8:      	ldr	q0, [x8]
		0000000000005ef8:  ARM64_RELOC_PAGEOFF12	lCPI70_3
    5efc:      	str	q0, [sp, #0xb0]
    5f00:      	mov	w21, #0x1               ; =1
    5f04:      	adrp	x8, 0x5000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1ac0>
		0000000000005f04:  ARM64_RELOC_PAGE21	lCPI70_4
    5f08:      	ldr	q0, [x8]
		0000000000005f08:  ARM64_RELOC_PAGEOFF12	lCPI70_4
    5f0c:      	str	q0, [sp, #0xa0]
    5f10:      	adrp	x8, 0x5000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1ac0>
		0000000000005f10:  ARM64_RELOC_PAGE21	lCPI70_5
    5f14:      	ldr	q0, [x8]
		0000000000005f14:  ARM64_RELOC_PAGEOFF12	lCPI70_5
    5f18:      	str	q0, [sp, #0x90]
    5f1c:      	adrp	x8, 0x5000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1ac0>
		0000000000005f1c:  ARM64_RELOC_PAGE21	lCPI70_6
    5f20:      	ldr	q0, [x8]
		0000000000005f20:  ARM64_RELOC_PAGEOFF12	lCPI70_6
    5f24:      	str	q0, [sp, #0x80]
    5f28:      	adrp	x8, 0x5000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1ac0>
		0000000000005f28:  ARM64_RELOC_PAGE21	lCPI70_7
    5f2c:      	ldr	q0, [x8]
		0000000000005f2c:  ARM64_RELOC_PAGEOFF12	lCPI70_7
    5f30:      	str	q0, [sp, #0x70]
    5f34:      	adrp	x8, 0x5000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1ac0>
		0000000000005f34:  ARM64_RELOC_PAGE21	lCPI70_8
    5f38:      	ldr	q0, [x8]
		0000000000005f38:  ARM64_RELOC_PAGEOFF12	lCPI70_8
    5f3c:      	str	q0, [sp, #0x60]
    5f40:      	adrp	x8, 0x5000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1ac0>
		0000000000005f40:  ARM64_RELOC_PAGE21	lCPI70_9
    5f44:      	ldr	q0, [x8]
		0000000000005f44:  ARM64_RELOC_PAGEOFF12	lCPI70_9
    5f48:      	str	q0, [sp, #0x50]
    5f4c:      	adrp	x8, 0x5000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1ac0>
		0000000000005f4c:  ARM64_RELOC_PAGE21	lCPI70_10
    5f50:      	ldr	q0, [x8]
		0000000000005f50:  ARM64_RELOC_PAGEOFF12	lCPI70_10
    5f54:      	str	q0, [sp, #0x40]
    5f58:      	adrp	x8, 0x5000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1ac0>
		0000000000005f58:  ARM64_RELOC_PAGE21	lCPI70_11
    5f5c:      	ldr	q0, [x8]
		0000000000005f5c:  ARM64_RELOC_PAGEOFF12	lCPI70_11
    5f60:      	str	q0, [sp, #0x30]
    5f64:      	adrp	x8, 0x5000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1ac0>
		0000000000005f64:  ARM64_RELOC_PAGE21	lCPI70_12
    5f68:      	ldr	q0, [x8]
		0000000000005f68:  ARM64_RELOC_PAGEOFF12	lCPI70_12
    5f6c:      	str	q0, [sp, #0x20]
    5f70:      	adrp	x8, 0x5000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1ac0>
		0000000000005f70:  ARM64_RELOC_PAGE21	lCPI70_13
    5f74:      	ldr	q0, [x8]
		0000000000005f74:  ARM64_RELOC_PAGEOFF12	lCPI70_13
    5f78:      	str	q0, [sp, #0x10]
    5f7c:      	adrp	x8, 0x5000 <_wf_map_cost_library_trace$instance$4250cb78d3f44027+0x1ac0>
		0000000000005f7c:  ARM64_RELOC_PAGE21	lCPI70_14
    5f80:      	ldr	q0, [x8]
		0000000000005f80:  ARM64_RELOC_PAGEOFF12	lCPI70_14
    5f84:      	str	q0, [sp]
    5f88:      	mov	w26, #0x2000            ; =8192
    5f8c:      	b	0x5fe8 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1d8>
    5f90:      	cmp	x1, #0x2, lsl #12       ; =0x2000
    5f94:      	csel	x8, x1, x26, lo
    5f98:      	lsl	x1, x8, #1
    5f9c:      	add	x0, sp, #0x118
    5fa0:      	add	x2, sp, #0x140
    5fa4:      	bl	0x5fa4 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x194>
		0000000000005fa4:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    5fa8:      	str	w0, [sp, #0x3d8]
    5fac:      	strb	w1, [sp, #0x3dc]
    5fb0:      	strb	w2, [sp, #0x3dd]
    5fb4:      	add	x0, sp, #0x150
    5fb8:      	add	x1, sp, #0x118
    5fbc:      	add	x3, sp, #0x260
    5fc0:      	add	x4, sp, #0x140
    5fc4:      	mov	x2, x21
    5fc8:      	bl	0x5fc8 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1b8>
		0000000000005fc8:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
    5fcc:      	add	x0, sp, #0x150
    5fd0:      	add	x1, sp, #0xf8
    5fd4:      	bl	0x5fd4 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1c4>
		0000000000005fd4:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
    5fd8:      	add	x19, x19, #0x1
    5fdc:      	add	x21, x21, #0x2
    5fe0:      	subs	x20, x20, #0x1
    5fe4:      	b.eq	0x612c <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x31c>
    5fe8:      	dup.2d	v0, x19
    5fec:      	add	x8, x19, #0x1f
    5ff0:      	ldr	q1, [sp, #0xe0]
    5ff4:      	add.2d	v1, v0, v1
    5ff8:      	stur	q1, [x23, #0x8]
    5ffc:      	ldr	q1, [sp, #0xd0]
    6000:      	add.2d	v1, v0, v1
    6004:      	stur	q1, [x23, #0x18]
    6008:      	ldr	q1, [sp, #0xc0]
    600c:      	add.2d	v1, v0, v1
    6010:      	stur	q1, [x23, #0x28]
    6014:      	ldr	q1, [sp, #0xb0]
    6018:      	add.2d	v1, v0, v1
    601c:      	stur	q1, [x23, #0x38]
    6020:      	ldr	q1, [sp, #0xa0]
    6024:      	add.2d	v1, v0, v1
    6028:      	stur	q1, [x23, #0x48]
    602c:      	ldr	q1, [sp, #0x90]
    6030:      	add.2d	v1, v0, v1
    6034:      	stur	q1, [x23, #0x58]
    6038:      	ldr	q1, [sp, #0x80]
    603c:      	add.2d	v1, v0, v1
    6040:      	stur	q1, [x23, #0x68]
    6044:      	ldr	q1, [sp, #0x70]
    6048:      	add.2d	v1, v0, v1
    604c:      	stur	q1, [x23, #0x78]
    6050:      	ldr	q1, [sp, #0x60]
    6054:      	add.2d	v1, v0, v1
    6058:      	stur	q1, [x23, #0x88]
    605c:      	ldr	q1, [sp, #0x50]
    6060:      	add.2d	v1, v0, v1
    6064:      	stur	q1, [x23, #0x98]
    6068:      	ldr	q1, [sp, #0x40]
    606c:      	add.2d	v1, v0, v1
    6070:      	stur	q1, [x23, #0xa8]
    6074:      	ldr	q1, [sp, #0x30]
    6078:      	add.2d	v1, v0, v1
    607c:      	stur	q1, [x23, #0xb8]
    6080:      	ldr	q1, [sp, #0x20]
    6084:      	add.2d	v1, v0, v1
    6088:      	stur	q1, [x23, #0xc8]
    608c:      	ldr	q1, [sp, #0x10]
    6090:      	add.2d	v1, v0, v1
    6094:      	stur	q1, [x23, #0xd8]
    6098:      	ldr	q1, [sp]
    609c:      	add.2d	v0, v0, v1
    60a0:      	stur	q0, [x23, #0xe8]
    60a4:      	str	x19, [sp, #0x260]
    60a8:      	str	x8, [sp, #0x358]
    60ac:      	ldr	x1, [sp, #0x118]
    60b0:      	ldr	x8, [sp, #0x138]
    60b4:      	str	x8, [x24, #0x120]
    60b8:      	add	x9, sp, #0x29
    60bc:      	ldur	q0, [x9, #0xff]
    60c0:      	add	x9, sp, #0x19
    60c4:      	ldur	q1, [x9, #0xff]
    60c8:      	stp	q1, q0, [x24, #0x100]
    60cc:      	str	x8, [x25, #0x20]
    60d0:      	ldr	x8, [sp, #0x378]
    60d4:      	ldr	x9, [sp, #0x3a8]
    60d8:      	adds	x8, x8, x9
    60dc:      	csinv	x9, x8, xzr, lo
    60e0:      	lsr	x8, x1, #14
    60e4:      	stp	q1, q0, [x25]
    60e8:      	cbnz	x8, 0x5fb4 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1a4>
    60ec:      	sub	x8, x1, x1, lsr #2
    60f0:      	cmp	x9, x8
    60f4:      	b.lo	0x5fb4 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1a4>
    60f8:      	ldr	x9, [sp, #0x138]
    60fc:      	str	x9, [x24, #0x170]
    6100:      	add	x9, sp, #0x29
    6104:      	ldur	q0, [x9, #0xff]
    6108:      	add	x9, sp, #0x19
    610c:      	ldur	q1, [x9, #0xff]
    6110:      	stp	q1, q0, [x24, #0x150]
    6114:      	ldr	x9, [sp, #0x3c8]
    6118:      	cmp	x9, x8, lsr #1
    611c:      	b.lo	0x5f9c <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x18c>
    6120:      	cbnz	x1, 0x5f90 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x180>
    6124:      	mov	w1, #0x1                ; =1
    6128:      	b	0x5f9c <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x18c>
    612c:      	ldr	x21, [sp, #0x118]
    6130:      	ldr	x8, [sp, #0x130]
    6134:      	b	0x615c <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x34c>
    6138:      	adrp	x0, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1f0>
		0000000000006138:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    613c:      	add	x0, x0, #0x0
		000000000000613c:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    6140:      	stp	x21, x21, [sp, #0x118]
    6144:      	stp	xzr, xzr, [sp, #0x130]
    6148:      	str	x0, [sp, #0x128]
    614c:      	stp	x19, xzr, [sp, #0xf8]
    6150:      	stp	xzr, xzr, [sp, #0x108]
    6154:      	cbnz	x20, 0x5ec4 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0xb4>
    6158:      	mov	x8, #0x0                ; =0
    615c:      	add	x19, x8, x21, lsl #32
    6160:      	add	x0, sp, #0x118
    6164:      	add	x1, sp, #0xf8
    6168:      	bl	0x6168 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x358>
		0000000000006168:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71
    616c:      	ldp	x8, x9, [sp, #0xf8]
    6170:      	ldp	x10, x11, [sp, #0x108]
    6174:      	eor	x8, x8, x8, lsr #30
    6178:      	mov	x12, #0xe5b9            ; =58809
    617c:      	movk	x12, #0x1ce4, lsl #16
    6180:      	movk	x12, #0x476d, lsl #32
    6184:      	movk	x12, #0xbf58, lsl #48
    6188:      	mul	x8, x8, x12
    618c:      	eor	x8, x8, x8, lsr #27
    6190:      	mov	x13, #0x11eb            ; =4587
    6194:      	movk	x13, #0x1331, lsl #16
    6198:      	movk	x13, #0x49bb, lsl #32
    619c:      	movk	x13, #0x94d0, lsl #48
    61a0:      	mul	x8, x8, x13
    61a4:      	eor	x9, x9, x9, lsr #30
    61a8:      	mul	x9, x9, x12
    61ac:      	eor	x9, x9, x9, lsr #27
    61b0:      	mul	x9, x9, x13
    61b4:      	eor	x12, x9, x8
    61b8:      	mul	x11, x11, x22
    61bc:      	eor	x10, x19, x10
    61c0:      	eor	x10, x10, x11
    61c4:      	eor	x10, x10, x12, lsr #31
    61c8:      	eor	x8, x8, x9
    61cc:      	eor	x0, x10, x8
    61d0:      	add	sp, sp, #0x3e0
    61d4:      	ldp	x29, x30, [sp, #0x50]
    61d8:      	ldp	x20, x19, [sp, #0x40]
    61dc:      	ldp	x22, x21, [sp, #0x30]
    61e0:      	ldp	x24, x23, [sp, #0x20]
    61e4:      	ldp	x26, x25, [sp, #0x10]
    61e8:      	ldp	x28, x27, [sp], #0x60
    61ec:      	ret
    61f0:      	bl	0x61f0 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x3e0>
		00000000000061f0:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

00000000000061f4 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd>:
    61f4:      	sub	sp, sp, #0xa0
    61f8:      	stp	x28, x27, [sp, #0x40]
    61fc:      	stp	x26, x25, [sp, #0x50]
    6200:      	stp	x24, x23, [sp, #0x60]
    6204:      	stp	x22, x21, [sp, #0x70]
    6208:      	stp	x20, x19, [sp, #0x80]
    620c:      	stp	x29, x30, [sp, #0x90]
    6210:      	mov	x20, x3
    6214:      	mov	x19, x2
    6218:      	mov	x21, x0
    621c:      	mov	x8, #0x7c15             ; =31765
    6220:      	movk	x8, #0x7f4a, lsl #16
    6224:      	movk	x8, #0x79b9, lsl #32
    6228:      	movk	x8, #0x9e37, lsl #48
    622c:      	eor	x22, x3, x8
    6230:      	str	x22, [sp, #0x30]
    6234:      	strb	wzr, [sp, #0x38]
    6238:      	cbz	x1, 0x6284 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x90>
    623c:      	mov	x23, x1
    6240:      	add	x8, x1, x1, lsl #1
    6244:      	lsl	x0, x8, #3
    6248:      	bl	0x6248 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x54>
		0000000000006248:  ARM64_RELOC_BRANCH26	_malloc
    624c:      	cbz	x0, 0x6478 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x284>
    6250:      	mov	x8, #0x0                ; =0
    6254:      	add	x9, x0, #0x8
    6258:      	mov	x1, x23
    625c:      	stur	wzr, [x9, #-0x8]
    6260:      	add	x8, x8, #0x1
    6264:      	stp	xzr, xzr, [x9], #0x18
    6268:      	cmp	x1, x8
    626c:      	b.ne	0x625c <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x68>
    6270:      	stp	x1, x1, [sp, #0x8]
    6274:      	stp	xzr, xzr, [sp, #0x20]
    6278:      	str	x0, [sp, #0x18]
    627c:      	cbnz	x19, 0x629c <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0xa8>
    6280:      	b	0x6438 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x244>
    6284:      	adrp	x0, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1f0>
		0000000000006284:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    6288:      	add	x0, x0, #0x0
		0000000000006288:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    628c:      	stp	x1, x1, [sp, #0x8]
    6290:      	stp	xzr, xzr, [sp, #0x20]
    6294:      	str	x0, [sp, #0x18]
    6298:      	cbz	x19, 0x6438 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x244>
    629c:      	mov	x23, #0x0               ; =0
    62a0:      	mov	w24, #0x1               ; =1
    62a4:      	ldrb	w25, [sp, #0x38]
    62a8:      	mov	w27, #0x18              ; =24
    62ac:      	mov	x26, #0xe5b9            ; =58809
    62b0:      	movk	x26, #0x1ce4, lsl #16
    62b4:      	movk	x26, #0x476d, lsl #32
    62b8:      	movk	x26, #0xbf58, lsl #48
    62bc:      	mov	x28, #0x11eb            ; =4587
    62c0:      	movk	x28, #0x1331, lsl #16
    62c4:      	movk	x28, #0x49bb, lsl #32
    62c8:      	movk	x28, #0x94d0, lsl #48
    62cc:      	b	0x62e8 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0xf4>
    62d0:      	mov	w11, #0x2               ; =2
    62d4:      	str	w11, [x10]
    62d8:      	stp	x8, x9, [x10, #0x8]
    62dc:      	add	x23, x23, #0x1
    62e0:      	cmp	x23, x19
    62e4:      	b.eq	0x6438 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x244>
    62e8:      	ldp	x8, x9, [sp, #0x20]
    62ec:      	adds	x9, x8, x9
    62f0:      	csinv	x9, x9, xzr, lo
    62f4:      	lsr	x10, x1, #14
    62f8:      	cbnz	x10, 0x6338 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x144>
    62fc:      	sub	x10, x1, x1, lsr #2
    6300:      	cmp	x9, x10
    6304:      	b.lo	0x6338 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x144>
    6308:      	cmp	x8, x10, lsr #1
    630c:      	b.lo	0x632c <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x138>
    6310:      	cbz	x1, 0x6328 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x134>
    6314:      	cmp	x1, #0x2, lsl #12       ; =0x2000
    6318:      	mov	w8, #0x2000             ; =8192
    631c:      	csel	x8, x1, x8, lo
    6320:      	lsl	x1, x8, #1
    6324:      	b	0x632c <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x138>
    6328:      	mov	w1, #0x1                ; =1
    632c:      	add	x0, sp, #0x8
    6330:      	add	x2, sp, #0x30
    6334:      	bl	0x6334 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x140>
		0000000000006334:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    6338:      	orr	x8, x24, x23, lsl #1
    633c:      	tbz	w25, #0x0, 0x63b8 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x1c4>
    6340:      	mov	x10, #0x0               ; =0
    6344:      	add	x9, x23, x20
    6348:      	ldr	x1, [sp, #0x8]
    634c:      	cbz	x1, 0x63dc <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x1e8>
    6350:      	udiv	x11, x10, x1
    6354:      	msub	x11, x11, x1, x10
    6358:      	ldr	x12, [sp, #0x18]
    635c:      	mov	x13, x1
    6360:      	mov	x10, x1
    6364:      	b	0x6384 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x190>
    6368:      	cmp	x10, x1
    636c:      	csel	x10, x11, x10, eq
    6370:      	add	x14, x11, #0x1
    6374:      	cmp	x14, x1
    6378:      	csinc	x11, xzr, x11, hs
    637c:      	subs	x13, x13, #0x1
    6380:      	b.eq	0x63e0 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x1ec>
    6384:      	madd	x14, x11, x27, x12
    6388:      	ldr	w15, [x14]
    638c:      	cmp	w15, #0x1
    6390:      	b.eq	0x6368 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x174>
    6394:      	cmp	w15, #0x2
    6398:      	b.ne	0x6424 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x230>
    639c:      	ldr	x15, [x14, #0x8]
    63a0:      	cmp	x15, x8
    63a4:      	b.ne	0x6370 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x17c>
    63a8:      	mov	w8, #0x2                ; =2
    63ac:      	str	w8, [x14]
    63b0:      	str	x9, [x14, #0x10]
    63b4:      	b	0x62dc <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0xe8>
    63b8:      	eor	x9, x8, x22
    63bc:      	eor	x9, x9, x9, lsr #30
    63c0:      	mul	x9, x9, x26
    63c4:      	eor	x9, x9, x9, lsr #27
    63c8:      	mul	x9, x9, x28
    63cc:      	eor	x10, x9, x9, lsr #31
    63d0:      	add	x9, x23, x20
    63d4:      	ldr	x1, [sp, #0x8]
    63d8:      	cbnz	x1, 0x6350 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x15c>
    63dc:      	mov	x10, #0x0               ; =0
    63e0:      	cmp	x10, x1
    63e4:      	b.hs	0x62dc <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0xe8>
    63e8:      	ldr	x11, [sp, #0x20]
    63ec:      	lsr	x12, x11, #14
    63f0:      	cbnz	x12, 0x62dc <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0xe8>
    63f4:      	add	x11, x11, #0x1
    63f8:      	str	x11, [sp, #0x20]
    63fc:      	ldr	x11, [sp, #0x18]
    6400:      	madd	x10, x10, x27, x11
    6404:      	ldr	w11, [x10]
    6408:      	cmp	w11, #0x1
    640c:      	b.ne	0x62d0 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0xdc>
    6410:      	ldr	x11, [sp, #0x28]
    6414:      	subs	x11, x11, #0x1
    6418:      	csel	x11, xzr, x11, lo
    641c:      	str	x11, [sp, #0x28]
    6420:      	b	0x62d0 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0xdc>
    6424:      	cmp	x10, x1
    6428:      	csel	x10, x11, x10, eq
    642c:      	cmp	x10, x1
    6430:      	b.hs	0x62dc <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0xe8>
    6434:      	b	0x63e8 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x1f4>
    6438:      	ldur	q0, [sp, #0x8]
    643c:      	ldur	q1, [sp, #0x18]
    6440:      	stp	q0, q1, [x21]
    6444:      	ldr	x8, [sp, #0x28]
    6448:      	str	x8, [x21, #0x20]
    644c:      	ldr	q0, [sp, #0x30]
    6450:      	stur	q0, [x21, #0x28]
    6454:      	stp	x20, x19, [x21, #0x38]
    6458:      	ldp	x29, x30, [sp, #0x90]
    645c:      	ldp	x20, x19, [sp, #0x80]
    6460:      	ldp	x22, x21, [sp, #0x70]
    6464:      	ldp	x24, x23, [sp, #0x60]
    6468:      	ldp	x26, x25, [sp, #0x50]
    646c:      	ldp	x28, x27, [sp, #0x40]
    6470:      	add	sp, sp, #0xa0
    6474:      	ret
    6478:      	bl	0x6478 <_wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd+0x284>
		0000000000006478:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000647c <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027>:
    647c:      	stp	x28, x27, [sp, #-0x60]!
    6480:      	stp	x26, x25, [sp, #0x10]
    6484:      	stp	x24, x23, [sp, #0x20]
    6488:      	stp	x22, x21, [sp, #0x30]
    648c:      	stp	x20, x19, [sp, #0x40]
    6490:      	stp	x29, x30, [sp, #0x50]
    6494:      	sub	sp, sp, #0x3d0
    6498:      	mov	x20, x3
    649c:      	mov	x19, x2
    64a0:      	mov	x22, x1
    64a4:      	mov	x21, x0
    64a8:      	mov	x8, #0x7c15             ; =31765
    64ac:      	movk	x8, #0x7f4a, lsl #16
    64b0:      	movk	x8, #0x79b9, lsl #32
    64b4:      	movk	x8, #0x9e37, lsl #48
    64b8:      	eor	x8, x3, x8
    64bc:      	str	x8, [sp, #0x130]
    64c0:      	strb	wzr, [sp, #0x138]
    64c4:      	cbz	x1, 0x6530 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0xb4>
    64c8:      	add	x8, x22, x22, lsl #4
    64cc:      	lsl	x0, x8, #4
    64d0:      	bl	0x64d0 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x54>
		00000000000064d0:  ARM64_RELOC_BRANCH26	_malloc
    64d4:      	cbz	x0, 0x67f4 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x378>
    64d8:      	mov	x8, #0x0                ; =0
    64dc:      	add	x9, x0, #0x8
    64e0:      	movi.2d	v0, #0000000000000000
    64e4:      	stur	wzr, [x9, #-0x8]
    64e8:      	add	x8, x8, #0x1
    64ec:      	stp	q0, q0, [x9]
    64f0:      	stp	q0, q0, [x9, #0x20]
    64f4:      	stp	q0, q0, [x9, #0x40]
    64f8:      	stp	q0, q0, [x9, #0x60]
    64fc:      	stp	q0, q0, [x9, #0x80]
    6500:      	stp	q0, q0, [x9, #0xa0]
    6504:      	stp	q0, q0, [x9, #0xc0]
    6508:      	stp	q0, q0, [x9, #0xe0]
    650c:      	str	xzr, [x9, #0x100]
    6510:      	add	x9, x9, #0x110
    6514:      	cmp	x22, x8
    6518:      	b.ne	0x64e4 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x68>
    651c:      	stp	x22, x22, [sp, #0x108]
    6520:      	stp	xzr, xzr, [sp, #0x120]
    6524:      	str	x0, [sp, #0x118]
    6528:      	cbnz	x19, 0x6548 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0xcc>
    652c:      	b	0x67ac <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x330>
    6530:      	adrp	x0, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1f0>
		0000000000006530:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    6534:      	add	x0, x0, #0x0
		0000000000006534:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    6538:      	stp	x22, x22, [sp, #0x108]
    653c:      	stp	xzr, xzr, [sp, #0x120]
    6540:      	str	x0, [sp, #0x118]
    6544:      	cbz	x19, 0x67ac <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x330>
    6548:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1f0>
		0000000000006548:  ARM64_RELOC_PAGE21	lCPI72_0
    654c:      	ldr	q0, [x8]
		000000000000654c:  ARM64_RELOC_PAGEOFF12	lCPI72_0
    6550:      	str	q0, [sp, #0xf0]
    6554:      	add	x23, sp, #0x250
    6558:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1f0>
		0000000000006558:  ARM64_RELOC_PAGE21	lCPI72_1
    655c:      	ldr	q0, [x8]
		000000000000655c:  ARM64_RELOC_PAGEOFF12	lCPI72_1
    6560:      	str	q0, [sp, #0xe0]
    6564:      	add	x24, sp, #0x250
    6568:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1f0>
		0000000000006568:  ARM64_RELOC_PAGE21	lCPI72_2
    656c:      	ldr	q0, [x8]
		000000000000656c:  ARM64_RELOC_PAGEOFF12	lCPI72_2
    6570:      	str	q0, [sp, #0xd0]
    6574:      	add	x25, x24, #0x128
    6578:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1f0>
		0000000000006578:  ARM64_RELOC_PAGE21	lCPI72_3
    657c:      	ldr	q0, [x8]
		000000000000657c:  ARM64_RELOC_PAGEOFF12	lCPI72_3
    6580:      	str	q0, [sp, #0xc0]
    6584:      	mov	w22, #0x1               ; =1
    6588:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1f0>
		0000000000006588:  ARM64_RELOC_PAGE21	lCPI72_4
    658c:      	ldr	q0, [x8]
		000000000000658c:  ARM64_RELOC_PAGEOFF12	lCPI72_4
    6590:      	str	q0, [sp, #0xb0]
    6594:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1f0>
		0000000000006594:  ARM64_RELOC_PAGE21	lCPI72_5
    6598:      	ldr	q0, [x8]
		0000000000006598:  ARM64_RELOC_PAGEOFF12	lCPI72_5
    659c:      	str	q0, [sp, #0xa0]
    65a0:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1f0>
		00000000000065a0:  ARM64_RELOC_PAGE21	lCPI72_6
    65a4:      	ldr	q0, [x8]
		00000000000065a4:  ARM64_RELOC_PAGEOFF12	lCPI72_6
    65a8:      	str	q0, [sp, #0x90]
    65ac:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1f0>
		00000000000065ac:  ARM64_RELOC_PAGE21	lCPI72_7
    65b0:      	ldr	q0, [x8]
		00000000000065b0:  ARM64_RELOC_PAGEOFF12	lCPI72_7
    65b4:      	str	q0, [sp, #0x80]
    65b8:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1f0>
		00000000000065b8:  ARM64_RELOC_PAGE21	lCPI72_8
    65bc:      	ldr	q0, [x8]
		00000000000065bc:  ARM64_RELOC_PAGEOFF12	lCPI72_8
    65c0:      	str	q0, [sp, #0x70]
    65c4:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1f0>
		00000000000065c4:  ARM64_RELOC_PAGE21	lCPI72_9
    65c8:      	ldr	q0, [x8]
		00000000000065c8:  ARM64_RELOC_PAGEOFF12	lCPI72_9
    65cc:      	str	q0, [sp, #0x60]
    65d0:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1f0>
		00000000000065d0:  ARM64_RELOC_PAGE21	lCPI72_10
    65d4:      	ldr	q0, [x8]
		00000000000065d4:  ARM64_RELOC_PAGEOFF12	lCPI72_10
    65d8:      	str	q0, [sp, #0x50]
    65dc:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1f0>
		00000000000065dc:  ARM64_RELOC_PAGE21	lCPI72_11
    65e0:      	ldr	q0, [x8]
		00000000000065e0:  ARM64_RELOC_PAGEOFF12	lCPI72_11
    65e4:      	str	q0, [sp, #0x40]
    65e8:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1f0>
		00000000000065e8:  ARM64_RELOC_PAGE21	lCPI72_12
    65ec:      	ldr	q0, [x8]
		00000000000065ec:  ARM64_RELOC_PAGEOFF12	lCPI72_12
    65f0:      	str	q0, [sp, #0x30]
    65f4:      	mov	w26, #0x2000            ; =8192
    65f8:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1f0>
		00000000000065f8:  ARM64_RELOC_PAGE21	lCPI72_13
    65fc:      	ldr	q0, [x8]
		00000000000065fc:  ARM64_RELOC_PAGEOFF12	lCPI72_13
    6600:      	str	q0, [sp, #0x20]
    6604:      	mov	x27, x19
    6608:      	adrp	x8, 0x6000 <_wf_map_cost_library_geometry$instance$4250cb78d3f44027+0x1f0>
		0000000000006608:  ARM64_RELOC_PAGE21	lCPI72_14
    660c:      	ldr	q0, [x8]
		000000000000660c:  ARM64_RELOC_PAGEOFF12	lCPI72_14
    6610:      	str	q0, [sp, #0x10]
    6614:      	mov	x28, x20
    6618:      	b	0x6668 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x1ec>
    661c:      	cmp	x1, #0x2, lsl #12       ; =0x2000
    6620:      	csel	x8, x1, x26, lo
    6624:      	lsl	x1, x8, #1
    6628:      	add	x0, sp, #0x108
    662c:      	add	x2, sp, #0x130
    6630:      	bl	0x6630 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x1b4>
		0000000000006630:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    6634:      	str	w0, [sp, #0x3c8]
    6638:      	strb	w1, [sp, #0x3cc]
    663c:      	strb	w2, [sp, #0x3cd]
    6640:      	add	x0, sp, #0x140
    6644:      	add	x1, sp, #0x108
    6648:      	add	x3, sp, #0x250
    664c:      	add	x4, sp, #0x130
    6650:      	mov	x2, x22
    6654:      	bl	0x6654 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x1d8>
		0000000000006654:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
    6658:      	add	x28, x28, #0x1
    665c:      	add	x22, x22, #0x2
    6660:      	subs	x27, x27, #0x1
    6664:      	b.eq	0x67ac <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x330>
    6668:      	dup.2d	v0, x28
    666c:      	add	x8, x28, #0x1f
    6670:      	ldr	q1, [sp, #0xf0]
    6674:      	add.2d	v1, v0, v1
    6678:      	stur	q1, [x23, #0x8]
    667c:      	ldr	q1, [sp, #0xe0]
    6680:      	add.2d	v1, v0, v1
    6684:      	stur	q1, [x23, #0x18]
    6688:      	ldr	q1, [sp, #0xd0]
    668c:      	add.2d	v1, v0, v1
    6690:      	stur	q1, [x23, #0x28]
    6694:      	ldr	q1, [sp, #0xc0]
    6698:      	add.2d	v1, v0, v1
    669c:      	stur	q1, [x23, #0x38]
    66a0:      	ldr	q1, [sp, #0xb0]
    66a4:      	add.2d	v1, v0, v1
    66a8:      	stur	q1, [x23, #0x48]
    66ac:      	ldr	q1, [sp, #0xa0]
    66b0:      	add.2d	v1, v0, v1
    66b4:      	stur	q1, [x23, #0x58]
    66b8:      	ldr	q1, [sp, #0x90]
    66bc:      	add.2d	v1, v0, v1
    66c0:      	stur	q1, [x23, #0x68]
    66c4:      	ldr	q1, [sp, #0x80]
    66c8:      	add.2d	v1, v0, v1
    66cc:      	stur	q1, [x23, #0x78]
    66d0:      	ldr	q1, [sp, #0x70]
    66d4:      	add.2d	v1, v0, v1
    66d8:      	stur	q1, [x23, #0x88]
    66dc:      	ldr	q1, [sp, #0x60]
    66e0:      	add.2d	v1, v0, v1
    66e4:      	stur	q1, [x23, #0x98]
    66e8:      	ldr	q1, [sp, #0x50]
    66ec:      	add.2d	v1, v0, v1
    66f0:      	stur	q1, [x23, #0xa8]
    66f4:      	ldr	q1, [sp, #0x40]
    66f8:      	add.2d	v1, v0, v1
    66fc:      	stur	q1, [x23, #0xb8]
    6700:      	ldr	q1, [sp, #0x30]
    6704:      	add.2d	v1, v0, v1
    6708:      	stur	q1, [x23, #0xc8]
    670c:      	ldr	q1, [sp, #0x20]
    6710:      	add.2d	v1, v0, v1
    6714:      	stur	q1, [x23, #0xd8]
    6718:      	ldr	q1, [sp, #0x10]
    671c:      	add.2d	v0, v0, v1
    6720:      	stur	q0, [x23, #0xe8]
    6724:      	str	x28, [sp, #0x250]
    6728:      	str	x8, [sp, #0x348]
    672c:      	ldr	x1, [sp, #0x108]
    6730:      	ldr	x8, [sp, #0x128]
    6734:      	str	x8, [x24, #0x120]
    6738:      	add	x9, sp, #0x19
    673c:      	ldur	q0, [x9, #0xff]
    6740:      	add	x9, sp, #0x9
    6744:      	ldur	q1, [x9, #0xff]
    6748:      	stp	q1, q0, [x24, #0x100]
    674c:      	str	x8, [x25, #0x20]
    6750:      	ldr	x8, [sp, #0x368]
    6754:      	ldr	x9, [sp, #0x398]
    6758:      	adds	x8, x8, x9
    675c:      	csinv	x9, x8, xzr, lo
    6760:      	lsr	x8, x1, #14
    6764:      	stp	q1, q0, [x25]
    6768:      	cbnz	x8, 0x6640 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x1c4>
    676c:      	sub	x8, x1, x1, lsr #2
    6770:      	cmp	x9, x8
    6774:      	b.lo	0x6640 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x1c4>
    6778:      	ldr	x9, [sp, #0x128]
    677c:      	str	x9, [x24, #0x170]
    6780:      	add	x9, sp, #0x19
    6784:      	ldur	q0, [x9, #0xff]
    6788:      	add	x9, sp, #0x9
    678c:      	ldur	q1, [x9, #0xff]
    6790:      	stp	q1, q0, [x24, #0x150]
    6794:      	ldr	x9, [sp, #0x3b8]
    6798:      	cmp	x9, x8, lsr #1
    679c:      	b.lo	0x6628 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x1ac>
    67a0:      	cbnz	x1, 0x661c <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x1a0>
    67a4:      	mov	w1, #0x1                ; =1
    67a8:      	b	0x6628 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x1ac>
    67ac:      	add	x8, sp, #0x9
    67b0:      	ldur	q0, [x8, #0xff]
    67b4:      	add	x8, sp, #0x19
    67b8:      	ldur	q1, [x8, #0xff]
    67bc:      	stp	q0, q1, [x21]
    67c0:      	ldr	x8, [sp, #0x128]
    67c4:      	str	x8, [x21, #0x20]
    67c8:      	ldr	q0, [sp, #0x130]
    67cc:      	stur	q0, [x21, #0x28]
    67d0:      	stp	x20, x19, [x21, #0x38]
    67d4:      	add	sp, sp, #0x3d0
    67d8:      	ldp	x29, x30, [sp, #0x50]
    67dc:      	ldp	x20, x19, [sp, #0x40]
    67e0:      	ldp	x22, x21, [sp, #0x30]
    67e4:      	ldp	x24, x23, [sp, #0x20]
    67e8:      	ldp	x26, x25, [sp, #0x10]
    67ec:      	ldp	x28, x27, [sp], #0x60
    67f0:      	ret
    67f4:      	bl	0x67f4 <_wf_map_cost_lookup_prepare$instance$4250cb78d3f44027+0x378>
		00000000000067f4:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

00000000000067f8 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd>:
    67f8:      	mov	x9, #0xe5b9             ; =58809
    67fc:      	movk	x9, #0x1ce4, lsl #16
    6800:      	movk	x9, #0x476d, lsl #32
    6804:      	movk	x9, #0xbf58, lsl #48
    6808:      	mov	x8, #0x11eb             ; =4587
    680c:      	movk	x8, #0x1331, lsl #16
    6810:      	movk	x8, #0x49bb, lsl #32
    6814:      	movk	x8, #0x94d0, lsl #48
    6818:      	ldr	x10, [x0, #0x38]
    681c:      	cmp	x2, #0x0
    6820:      	mov	w11, #0x1               ; =1
    6824:      	cinc	x11, x11, ne
    6828:      	cbz	x1, 0x6908 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x110>
    682c:      	ldr	x12, [x0, #0x40]
    6830:      	cbz	x12, 0x6908 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x110>
    6834:      	ldrb	w15, [x0, #0x30]
    6838:      	ldr	x13, [x0]
    683c:      	cbz	x13, 0x68e8 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0xf0>
    6840:      	stp	x20, x19, [sp, #-0x10]!
    6844:      	ldr	x14, [x0, #0x10]
    6848:      	tbz	w15, #0x0, 0x6920 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x128>
    684c:      	mov	x15, #0x0               ; =0
    6850:      	mov	w16, #0x18              ; =24
    6854:      	mov	w17, #0x83              ; =131
    6858:      	mov	w0, #0x4309             ; =17161
    685c:      	b	0x686c <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x74>
    6860:      	add	x15, x15, #0x1
    6864:      	cmp	x15, x1
    6868:      	b.eq	0x69dc <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x1e4>
    686c:      	mov	x2, #0x0                ; =0
    6870:      	b	0x6884 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x8c>
    6874:      	mul	x10, x10, x17
    6878:      	add	x2, x2, #0x1
    687c:      	cmp	x2, x12
    6880:      	b.eq	0x6860 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x68>
    6884:      	mov	x3, #0x0                ; =0
    6888:      	add	x4, x11, x2, lsl #1
    688c:      	mov	x5, x13
    6890:      	b	0x68a8 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0xb0>
    6894:      	add	x6, x3, #0x1
    6898:      	cmp	x6, x13
    689c:      	csinc	x3, xzr, x3, hs
    68a0:      	subs	x5, x5, #0x1
    68a4:      	b.eq	0x6874 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x7c>
    68a8:      	madd	x6, x3, x16, x14
    68ac:      	ldr	w7, [x6]
    68b0:      	cmp	w7, #0x1
    68b4:      	b.eq	0x6894 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x9c>
    68b8:      	cmp	w7, #0x2
    68bc:      	b.ne	0x6874 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x7c>
    68c0:      	ldr	x7, [x6, #0x8]
    68c4:      	cmp	x7, x4
    68c8:      	b.ne	0x6894 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x9c>
    68cc:      	ldr	x3, [x6, #0x10]
    68d0:      	madd	x10, x10, x0, x3
    68d4:      	add	x10, x10, #0x83
    68d8:      	add	x2, x2, #0x1
    68dc:      	cmp	x2, x12
    68e0:      	b.ne	0x6884 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x8c>
    68e4:      	b	0x6860 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x68>
    68e8:      	and	x11, x12, #0xfffffffffffffffe
    68ec:      	cmp	x12, #0x1
    68f0:      	tbz	w15, #0x0, 0x69f8 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x200>
    68f4:      	b.ne	0x6a10 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x218>
    68f8:      	mov	w11, #0x83              ; =131
    68fc:      	mul	x10, x10, x11
    6900:      	subs	x1, x1, #0x1
    6904:      	b.ne	0x68fc <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x104>
    6908:      	eor	x10, x10, x10, lsr #30
    690c:      	mul	x9, x10, x9
    6910:      	eor	x9, x9, x9, lsr #27
    6914:      	mul	x8, x9, x8
    6918:      	eor	x0, x8, x8, lsr #31
    691c:      	ret
    6920:      	mov	x15, #0x0               ; =0
    6924:      	ldr	x16, [x0, #0x28]
    6928:      	mov	w17, #0x18              ; =24
    692c:      	mov	w0, #0x83               ; =131
    6930:      	mov	w2, #0x4309             ; =17161
    6934:      	b	0x6944 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x14c>
    6938:      	add	x15, x15, #0x1
    693c:      	cmp	x15, x1
    6940:      	b.eq	0x69dc <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x1e4>
    6944:      	mov	x3, #0x0                ; =0
    6948:      	b	0x695c <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x164>
    694c:      	mul	x10, x10, x0
    6950:      	add	x3, x3, #0x1
    6954:      	cmp	x3, x12
    6958:      	b.eq	0x6938 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x140>
    695c:      	add	x4, x11, x3, lsl #1
    6960:      	eor	x5, x16, x4
    6964:      	eor	x5, x5, x5, lsr #30
    6968:      	mul	x5, x5, x9
    696c:      	eor	x5, x5, x5, lsr #27
    6970:      	mul	x5, x5, x8
    6974:      	eor	x5, x5, x5, lsr #31
    6978:      	udiv	x6, x5, x13
    697c:      	msub	x5, x6, x13, x5
    6980:      	mov	x6, x13
    6984:      	b	0x699c <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x1a4>
    6988:      	add	x7, x5, #0x1
    698c:      	cmp	x7, x13
    6990:      	csinc	x5, xzr, x5, hs
    6994:      	subs	x6, x6, #0x1
    6998:      	b.eq	0x694c <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x154>
    699c:      	madd	x7, x5, x17, x14
    69a0:      	ldr	w19, [x7]
    69a4:      	cmp	w19, #0x1
    69a8:      	b.eq	0x6988 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x190>
    69ac:      	cmp	w19, #0x2
    69b0:      	b.ne	0x694c <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x154>
    69b4:      	ldr	x19, [x7, #0x8]
    69b8:      	cmp	x19, x4
    69bc:      	b.ne	0x6988 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x190>
    69c0:      	ldr	x4, [x7, #0x10]
    69c4:      	madd	x10, x10, x2, x4
    69c8:      	add	x10, x10, #0x83
    69cc:      	add	x3, x3, #0x1
    69d0:      	cmp	x3, x12
    69d4:      	b.ne	0x695c <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x164>
    69d8:      	b	0x6938 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x140>
    69dc:      	ldp	x20, x19, [sp], #0x10
    69e0:      	eor	x10, x10, x10, lsr #30
    69e4:      	mul	x9, x10, x9
    69e8:      	eor	x9, x9, x9, lsr #27
    69ec:      	mul	x8, x9, x8
    69f0:      	eor	x0, x8, x8, lsr #31
    69f4:      	ret
    69f8:      	b.ne	0x6a48 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x250>
    69fc:      	mov	w11, #0x83              ; =131
    6a00:      	mul	x10, x10, x11
    6a04:      	subs	x1, x1, #0x1
    6a08:      	b.ne	0x6a00 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x208>
    6a0c:      	b	0x6908 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x110>
    6a10:      	subs	x12, x12, x11
    6a14:      	b.ne	0x6a80 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x288>
    6a18:      	mov	w13, #0x83              ; =131
    6a1c:      	mov	x14, x11
    6a20:      	mov	w15, #0x1               ; =1
    6a24:      	mul	x10, x10, x13
    6a28:      	mul	x15, x15, x13
    6a2c:      	subs	x14, x14, #0x2
    6a30:      	b.ne	0x6a24 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x22c>
    6a34:      	mul	x10, x15, x10
    6a38:      	add	x12, x12, #0x1
    6a3c:      	cmp	x12, x1
    6a40:      	b.ne	0x6a1c <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x224>
    6a44:      	b	0x6908 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x110>
    6a48:      	subs	x12, x12, x11
    6a4c:      	b.ne	0x6ac4 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x2cc>
    6a50:      	mov	w13, #0x83              ; =131
    6a54:      	mov	x14, x11
    6a58:      	mov	w15, #0x1               ; =1
    6a5c:      	mul	x10, x10, x13
    6a60:      	mul	x15, x15, x13
    6a64:      	subs	x14, x14, #0x2
    6a68:      	b.ne	0x6a5c <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x264>
    6a6c:      	mul	x10, x15, x10
    6a70:      	add	x12, x12, #0x1
    6a74:      	cmp	x12, x1
    6a78:      	b.ne	0x6a54 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x25c>
    6a7c:      	b	0x6908 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x110>
    6a80:      	mov	x13, #0x0               ; =0
    6a84:      	mov	w14, #0x83              ; =131
    6a88:      	mov	x15, x11
    6a8c:      	mov	w16, #0x1               ; =1
    6a90:      	mul	x10, x10, x14
    6a94:      	mul	x16, x16, x14
    6a98:      	subs	x15, x15, #0x2
    6a9c:      	b.ne	0x6a90 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x298>
    6aa0:      	mul	x10, x16, x10
    6aa4:      	mov	x15, x12
    6aa8:      	mul	x10, x10, x14
    6aac:      	subs	x15, x15, #0x1
    6ab0:      	b.ne	0x6aa8 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x2b0>
    6ab4:      	add	x13, x13, #0x1
    6ab8:      	cmp	x13, x1
    6abc:      	b.ne	0x6a88 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x290>
    6ac0:      	b	0x6908 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x110>
    6ac4:      	mov	x13, #0x0               ; =0
    6ac8:      	mov	w14, #0x83              ; =131
    6acc:      	mov	x15, x11
    6ad0:      	mov	w16, #0x1               ; =1
    6ad4:      	mul	x10, x10, x14
    6ad8:      	mul	x16, x16, x14
    6adc:      	subs	x15, x15, #0x2
    6ae0:      	b.ne	0x6ad4 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x2dc>
    6ae4:      	mul	x10, x16, x10
    6ae8:      	mov	x15, x12
    6aec:      	mul	x10, x10, x14
    6af0:      	subs	x15, x15, #0x1
    6af4:      	b.ne	0x6aec <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x2f4>
    6af8:      	add	x13, x13, #0x1
    6afc:      	cmp	x13, x1
    6b00:      	b.ne	0x6acc <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x2d4>
    6b04:      	b	0x6908 <_wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd+0x110>

0000000000006b08 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027>:
    6b08:      	mov	x9, #0xe5b9             ; =58809
    6b0c:      	movk	x9, #0x1ce4, lsl #16
    6b10:      	movk	x9, #0x476d, lsl #32
    6b14:      	movk	x9, #0xbf58, lsl #48
    6b18:      	mov	x8, #0x11eb             ; =4587
    6b1c:      	movk	x8, #0x1331, lsl #16
    6b20:      	movk	x8, #0x49bb, lsl #32
    6b24:      	movk	x8, #0x94d0, lsl #48
    6b28:      	ldr	x10, [x0, #0x38]
    6b2c:      	cmp	x2, #0x0
    6b30:      	mov	w11, #0x1               ; =1
    6b34:      	cinc	x11, x11, ne
    6b38:      	cbz	x1, 0x6c18 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x110>
    6b3c:      	ldr	x12, [x0, #0x40]
    6b40:      	cbz	x12, 0x6c18 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x110>
    6b44:      	ldrb	w15, [x0, #0x30]
    6b48:      	ldr	x13, [x0]
    6b4c:      	cbz	x13, 0x6bf8 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0xf0>
    6b50:      	stp	x20, x19, [sp, #-0x10]!
    6b54:      	ldr	x14, [x0, #0x10]
    6b58:      	tbz	w15, #0x0, 0x6c30 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x128>
    6b5c:      	mov	x15, #0x0               ; =0
    6b60:      	mov	w16, #0x110             ; =272
    6b64:      	mov	w17, #0x83              ; =131
    6b68:      	mov	w0, #0x4309             ; =17161
    6b6c:      	b	0x6b7c <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x74>
    6b70:      	add	x15, x15, #0x1
    6b74:      	cmp	x15, x1
    6b78:      	b.eq	0x6cec <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x1e4>
    6b7c:      	mov	x2, #0x0                ; =0
    6b80:      	b	0x6b94 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x8c>
    6b84:      	mul	x10, x10, x17
    6b88:      	add	x2, x2, #0x1
    6b8c:      	cmp	x2, x12
    6b90:      	b.eq	0x6b70 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x68>
    6b94:      	mov	x3, #0x0                ; =0
    6b98:      	add	x4, x11, x2, lsl #1
    6b9c:      	mov	x5, x13
    6ba0:      	b	0x6bb8 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0xb0>
    6ba4:      	add	x6, x3, #0x1
    6ba8:      	cmp	x6, x13
    6bac:      	csinc	x3, xzr, x3, hs
    6bb0:      	subs	x5, x5, #0x1
    6bb4:      	b.eq	0x6b84 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x7c>
    6bb8:      	madd	x6, x3, x16, x14
    6bbc:      	ldr	w7, [x6]
    6bc0:      	cmp	w7, #0x1
    6bc4:      	b.eq	0x6ba4 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x9c>
    6bc8:      	cmp	w7, #0x2
    6bcc:      	b.ne	0x6b84 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x7c>
    6bd0:      	ldr	x7, [x6, #0x8]
    6bd4:      	cmp	x7, x4
    6bd8:      	b.ne	0x6ba4 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x9c>
    6bdc:      	ldr	x3, [x6, #0x10]
    6be0:      	madd	x10, x10, x0, x3
    6be4:      	add	x10, x10, #0x83
    6be8:      	add	x2, x2, #0x1
    6bec:      	cmp	x2, x12
    6bf0:      	b.ne	0x6b94 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x8c>
    6bf4:      	b	0x6b70 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x68>
    6bf8:      	and	x11, x12, #0xfffffffffffffffe
    6bfc:      	cmp	x12, #0x1
    6c00:      	tbz	w15, #0x0, 0x6d08 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x200>
    6c04:      	b.ne	0x6d20 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x218>
    6c08:      	mov	w11, #0x83              ; =131
    6c0c:      	mul	x10, x10, x11
    6c10:      	subs	x1, x1, #0x1
    6c14:      	b.ne	0x6c0c <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x104>
    6c18:      	eor	x10, x10, x10, lsr #30
    6c1c:      	mul	x9, x10, x9
    6c20:      	eor	x9, x9, x9, lsr #27
    6c24:      	mul	x8, x9, x8
    6c28:      	eor	x0, x8, x8, lsr #31
    6c2c:      	ret
    6c30:      	mov	x15, #0x0               ; =0
    6c34:      	ldr	x16, [x0, #0x28]
    6c38:      	mov	w17, #0x110             ; =272
    6c3c:      	mov	w0, #0x83               ; =131
    6c40:      	mov	w2, #0x4309             ; =17161
    6c44:      	b	0x6c54 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x14c>
    6c48:      	add	x15, x15, #0x1
    6c4c:      	cmp	x15, x1
    6c50:      	b.eq	0x6cec <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x1e4>
    6c54:      	mov	x3, #0x0                ; =0
    6c58:      	b	0x6c6c <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x164>
    6c5c:      	mul	x10, x10, x0
    6c60:      	add	x3, x3, #0x1
    6c64:      	cmp	x3, x12
    6c68:      	b.eq	0x6c48 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x140>
    6c6c:      	add	x4, x11, x3, lsl #1
    6c70:      	eor	x5, x16, x4
    6c74:      	eor	x5, x5, x5, lsr #30
    6c78:      	mul	x5, x5, x9
    6c7c:      	eor	x5, x5, x5, lsr #27
    6c80:      	mul	x5, x5, x8
    6c84:      	eor	x5, x5, x5, lsr #31
    6c88:      	udiv	x6, x5, x13
    6c8c:      	msub	x5, x6, x13, x5
    6c90:      	mov	x6, x13
    6c94:      	b	0x6cac <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x1a4>
    6c98:      	add	x7, x5, #0x1
    6c9c:      	cmp	x7, x13
    6ca0:      	csinc	x5, xzr, x5, hs
    6ca4:      	subs	x6, x6, #0x1
    6ca8:      	b.eq	0x6c5c <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x154>
    6cac:      	madd	x7, x5, x17, x14
    6cb0:      	ldr	w19, [x7]
    6cb4:      	cmp	w19, #0x1
    6cb8:      	b.eq	0x6c98 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x190>
    6cbc:      	cmp	w19, #0x2
    6cc0:      	b.ne	0x6c5c <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x154>
    6cc4:      	ldr	x19, [x7, #0x8]
    6cc8:      	cmp	x19, x4
    6ccc:      	b.ne	0x6c98 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x190>
    6cd0:      	ldr	x4, [x7, #0x10]
    6cd4:      	madd	x10, x10, x2, x4
    6cd8:      	add	x10, x10, #0x83
    6cdc:      	add	x3, x3, #0x1
    6ce0:      	cmp	x3, x12
    6ce4:      	b.ne	0x6c6c <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x164>
    6ce8:      	b	0x6c48 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x140>
    6cec:      	ldp	x20, x19, [sp], #0x10
    6cf0:      	eor	x10, x10, x10, lsr #30
    6cf4:      	mul	x9, x10, x9
    6cf8:      	eor	x9, x9, x9, lsr #27
    6cfc:      	mul	x8, x9, x8
    6d00:      	eor	x0, x8, x8, lsr #31
    6d04:      	ret
    6d08:      	b.ne	0x6d58 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x250>
    6d0c:      	mov	w11, #0x83              ; =131
    6d10:      	mul	x10, x10, x11
    6d14:      	subs	x1, x1, #0x1
    6d18:      	b.ne	0x6d10 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x208>
    6d1c:      	b	0x6c18 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x110>
    6d20:      	subs	x12, x12, x11
    6d24:      	b.ne	0x6d90 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x288>
    6d28:      	mov	w13, #0x83              ; =131
    6d2c:      	mov	x14, x11
    6d30:      	mov	w15, #0x1               ; =1
    6d34:      	mul	x10, x10, x13
    6d38:      	mul	x15, x15, x13
    6d3c:      	subs	x14, x14, #0x2
    6d40:      	b.ne	0x6d34 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x22c>
    6d44:      	mul	x10, x15, x10
    6d48:      	add	x12, x12, #0x1
    6d4c:      	cmp	x12, x1
    6d50:      	b.ne	0x6d2c <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x224>
    6d54:      	b	0x6c18 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x110>
    6d58:      	subs	x12, x12, x11
    6d5c:      	b.ne	0x6dd4 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x2cc>
    6d60:      	mov	w13, #0x83              ; =131
    6d64:      	mov	x14, x11
    6d68:      	mov	w15, #0x1               ; =1
    6d6c:      	mul	x10, x10, x13
    6d70:      	mul	x15, x15, x13
    6d74:      	subs	x14, x14, #0x2
    6d78:      	b.ne	0x6d6c <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x264>
    6d7c:      	mul	x10, x15, x10
    6d80:      	add	x12, x12, #0x1
    6d84:      	cmp	x12, x1
    6d88:      	b.ne	0x6d64 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x25c>
    6d8c:      	b	0x6c18 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x110>
    6d90:      	mov	x13, #0x0               ; =0
    6d94:      	mov	w14, #0x83              ; =131
    6d98:      	mov	x15, x11
    6d9c:      	mov	w16, #0x1               ; =1
    6da0:      	mul	x10, x10, x14
    6da4:      	mul	x16, x16, x14
    6da8:      	subs	x15, x15, #0x2
    6dac:      	b.ne	0x6da0 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x298>
    6db0:      	mul	x10, x16, x10
    6db4:      	mov	x15, x12
    6db8:      	mul	x10, x10, x14
    6dbc:      	subs	x15, x15, #0x1
    6dc0:      	b.ne	0x6db8 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x2b0>
    6dc4:      	add	x13, x13, #0x1
    6dc8:      	cmp	x13, x1
    6dcc:      	b.ne	0x6d98 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x290>
    6dd0:      	b	0x6c18 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x110>
    6dd4:      	mov	x13, #0x0               ; =0
    6dd8:      	mov	w14, #0x83              ; =131
    6ddc:      	mov	x15, x11
    6de0:      	mov	w16, #0x1               ; =1
    6de4:      	mul	x10, x10, x14
    6de8:      	mul	x16, x16, x14
    6dec:      	subs	x15, x15, #0x2
    6df0:      	b.ne	0x6de4 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x2dc>
    6df4:      	mul	x10, x16, x10
    6df8:      	mov	x15, x12
    6dfc:      	mul	x10, x10, x14
    6e00:      	subs	x15, x15, #0x1
    6e04:      	b.ne	0x6dfc <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x2f4>
    6e08:      	add	x13, x13, #0x1
    6e0c:      	cmp	x13, x1
    6e10:      	b.ne	0x6ddc <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x2d4>
    6e14:      	b	0x6c18 <_wf_map_cost_lookup_query$instance$4250cb78d3f44027+0x110>

0000000000006e18 <_wf_map_cost_lookup_geometry$instance$e194368921a477a7>:
    6e18:      	ldr	x8, [x0]
    6e1c:      	ldr	x9, [x0, #0x18]
    6e20:      	add	x0, x9, x8, lsl #32
    6e24:      	ret

0000000000006e28 <_wf_map_cost_lookup_geometry$instance$9fed7d4c5d7cc122>:
    6e28:      	ldr	x8, [x0]
    6e2c:      	ldr	x9, [x0, #0x18]
    6e30:      	add	x0, x9, x8, lsl #32
    6e34:      	ret

0000000000006e38 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd>:
    6e38:      	stp	x24, x23, [sp, #-0x40]!
    6e3c:      	stp	x22, x21, [sp, #0x10]
    6e40:      	stp	x20, x19, [sp, #0x20]
    6e44:      	stp	x29, x30, [sp, #0x30]
    6e48:      	mov	x8, x0
    6e4c:      	mov	x20, #0xe5b9            ; =58809
    6e50:      	movk	x20, #0x1ce4, lsl #16
    6e54:      	movk	x20, #0x476d, lsl #32
    6e58:      	movk	x20, #0xbf58, lsl #48
    6e5c:      	mov	x19, #0x11eb            ; =4587
    6e60:      	movk	x19, #0x1331, lsl #16
    6e64:      	movk	x19, #0x49bb, lsl #32
    6e68:      	movk	x19, #0x94d0, lsl #48
    6e6c:      	ldp	x12, x9, [x0]
    6e70:      	ldr	x0, [x0, #0x10]
    6e74:      	cbz	x12, 0x6f54 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x11c>
    6e78:      	and	x10, x12, #0x3
    6e7c:      	cmp	x12, #0x4
    6e80:      	b.hs	0x6f6c <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x134>
    6e84:      	mov	x11, #0x0               ; =0
    6e88:      	mov	x21, #0x0               ; =0
    6e8c:      	mov	x22, #0x0               ; =0
    6e90:      	cbz	x10, 0x6eec <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0xb4>
    6e94:      	mov	w13, #0x18              ; =24
    6e98:      	madd	x12, x12, x13, x0
    6e9c:      	sub	x12, x12, #0x8
    6ea0:      	mov	w13, #0x83              ; =131
    6ea4:      	b	0x6eb4 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x7c>
    6ea8:      	sub	x12, x12, #0x18
    6eac:      	subs	x10, x10, #0x1
    6eb0:      	b.eq	0x6eec <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0xb4>
    6eb4:      	ldur	w14, [x12, #-0x10]
    6eb8:      	cmp	w14, #0x2
    6ebc:      	b.ne	0x6ea8 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x70>
    6ec0:      	ldp	x15, x14, [x12, #-0x8]
    6ec4:      	madd	x14, x15, x13, x14
    6ec8:      	add	x22, x14, x22
    6ecc:      	eor	x14, x14, x14, lsr #30
    6ed0:      	mul	x14, x14, x20
    6ed4:      	eor	x14, x14, x14, lsr #27
    6ed8:      	mul	x14, x14, x19
    6edc:      	eor	x15, x21, x14, lsr #31
    6ee0:      	eor	x21, x15, x14
    6ee4:      	add	x11, x11, #0x1
    6ee8:      	b	0x6ea8 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x70>
    6eec:      	mov	x10, #0x7c15            ; =31765
    6ef0:      	movk	x10, #0x7f4a, lsl #16
    6ef4:      	movk	x10, #0x79b9, lsl #32
    6ef8:      	movk	x10, #0x9e37, lsl #48
    6efc:      	mul	x23, x11, x10
    6f00:      	ldr	x24, [x8, #0x38]
    6f04:      	cbz	x9, 0x6f0c <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0xd4>
    6f08:      	bl	0x6f08 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0xd0>
		0000000000006f08:  ARM64_RELOC_BRANCH26	_free
    6f0c:      	eor	x8, x24, x24, lsr #30
    6f10:      	mul	x8, x8, x20
    6f14:      	eor	x8, x8, x8, lsr #27
    6f18:      	mul	x8, x8, x19
    6f1c:      	eor	x9, x22, x22, lsr #30
    6f20:      	mul	x9, x9, x20
    6f24:      	eor	x9, x9, x9, lsr #27
    6f28:      	mul	x9, x9, x19
    6f2c:      	eor	x10, x9, x8
    6f30:      	eor	x11, x23, x21
    6f34:      	eor	x10, x11, x10, lsr #31
    6f38:      	eor	x8, x8, x9
    6f3c:      	eor	x0, x10, x8
    6f40:      	ldp	x29, x30, [sp, #0x30]
    6f44:      	ldp	x20, x19, [sp, #0x20]
    6f48:      	ldp	x22, x21, [sp, #0x10]
    6f4c:      	ldp	x24, x23, [sp], #0x40
    6f50:      	ret
    6f54:      	mov	x23, #0x0               ; =0
    6f58:      	mov	x21, #0x0               ; =0
    6f5c:      	mov	x22, #0x0               ; =0
    6f60:      	ldr	x24, [x8, #0x38]
    6f64:      	cbnz	x9, 0x6f08 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0xd0>
    6f68:      	b	0x6f0c <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0xd4>
    6f6c:      	mov	x11, #0x0               ; =0
    6f70:      	mov	x21, #0x0               ; =0
    6f74:      	mov	x22, #0x0               ; =0
    6f78:      	and	x13, x12, #0xfffffffffffffffc
    6f7c:      	mov	w14, #0x18              ; =24
    6f80:      	madd	x14, x12, x14, x0
    6f84:      	sub	x14, x14, #0x30
    6f88:      	mov	w15, #0x83              ; =131
    6f8c:      	b	0x6fa0 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x168>
    6f90:      	sub	x14, x14, #0x60
    6f94:      	sub	x12, x12, #0x4
    6f98:      	sub	x13, x13, #0x4
    6f9c:      	cbz	x13, 0x6e90 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x58>
    6fa0:      	ldr	w16, [x14, #0x18]
    6fa4:      	cmp	w16, #0x2
    6fa8:      	b.eq	0x6fd4 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x19c>
    6fac:      	ldr	w16, [x14]
    6fb0:      	cmp	w16, #0x2
    6fb4:      	b.eq	0x7008 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x1d0>
    6fb8:      	ldur	w16, [x14, #-0x18]
    6fbc:      	cmp	w16, #0x2
    6fc0:      	b.eq	0x703c <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x204>
    6fc4:      	ldur	w16, [x14, #-0x30]
    6fc8:      	cmp	w16, #0x2
    6fcc:      	b.ne	0x6f90 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x158>
    6fd0:      	b	0x7070 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x238>
    6fd4:      	ldp	x17, x16, [x14, #0x20]
    6fd8:      	madd	x16, x17, x15, x16
    6fdc:      	add	x22, x16, x22
    6fe0:      	eor	x16, x16, x16, lsr #30
    6fe4:      	mul	x16, x16, x20
    6fe8:      	eor	x16, x16, x16, lsr #27
    6fec:      	mul	x16, x16, x19
    6ff0:      	eor	x17, x21, x16, lsr #31
    6ff4:      	eor	x21, x17, x16
    6ff8:      	add	x11, x11, #0x1
    6ffc:      	ldr	w16, [x14]
    7000:      	cmp	w16, #0x2
    7004:      	b.ne	0x6fb8 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x180>
    7008:      	ldp	x17, x16, [x14, #0x8]
    700c:      	madd	x16, x17, x15, x16
    7010:      	add	x22, x16, x22
    7014:      	eor	x16, x16, x16, lsr #30
    7018:      	mul	x16, x16, x20
    701c:      	eor	x16, x16, x16, lsr #27
    7020:      	mul	x16, x16, x19
    7024:      	eor	x17, x21, x16, lsr #31
    7028:      	eor	x21, x17, x16
    702c:      	add	x11, x11, #0x1
    7030:      	ldur	w16, [x14, #-0x18]
    7034:      	cmp	w16, #0x2
    7038:      	b.ne	0x6fc4 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x18c>
    703c:      	ldp	x17, x16, [x14, #-0x10]
    7040:      	madd	x16, x17, x15, x16
    7044:      	add	x22, x16, x22
    7048:      	eor	x16, x16, x16, lsr #30
    704c:      	mul	x16, x16, x20
    7050:      	eor	x16, x16, x16, lsr #27
    7054:      	mul	x16, x16, x19
    7058:      	eor	x17, x21, x16, lsr #31
    705c:      	eor	x21, x17, x16
    7060:      	add	x11, x11, #0x1
    7064:      	ldur	w16, [x14, #-0x30]
    7068:      	cmp	w16, #0x2
    706c:      	b.ne	0x6f90 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x158>
    7070:      	ldp	x17, x16, [x14, #-0x28]
    7074:      	madd	x16, x17, x15, x16
    7078:      	add	x22, x16, x22
    707c:      	eor	x16, x16, x16, lsr #30
    7080:      	mul	x16, x16, x20
    7084:      	eor	x16, x16, x16, lsr #27
    7088:      	mul	x16, x16, x19
    708c:      	eor	x17, x21, x16, lsr #31
    7090:      	eor	x21, x17, x16
    7094:      	add	x11, x11, #0x1
    7098:      	b	0x6f90 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x158>

000000000000709c <_wf_map_cost_lookup_finish$instance$4250cb78d3f44027>:
    709c:      	sub	sp, sp, #0x60
    70a0:      	stp	x29, x30, [sp, #0x50]
    70a4:      	ldr	x8, [x0, #0x38]
    70a8:      	ldp	q0, q1, [x0]
    70ac:      	stp	q0, q1, [sp, #0x20]
    70b0:      	ldr	x9, [x0, #0x20]
    70b4:      	str	x9, [sp, #0x40]
    70b8:      	stp	x8, xzr, [sp]
    70bc:      	stp	xzr, xzr, [sp, #0x10]
    70c0:      	add	x0, sp, #0x20
    70c4:      	mov	x1, sp
    70c8:      	bl	0x70c8 <_wf_map_cost_lookup_finish$instance$4250cb78d3f44027+0x2c>
		00000000000070c8:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71
    70cc:      	ldp	x8, x9, [sp]
    70d0:      	ldp	x10, x11, [sp, #0x10]
    70d4:      	eor	x8, x8, x8, lsr #30
    70d8:      	mov	x12, #0xe5b9            ; =58809
    70dc:      	movk	x12, #0x1ce4, lsl #16
    70e0:      	movk	x12, #0x476d, lsl #32
    70e4:      	movk	x12, #0xbf58, lsl #48
    70e8:      	mul	x8, x8, x12
    70ec:      	eor	x8, x8, x8, lsr #27
    70f0:      	mov	x13, #0x11eb            ; =4587
    70f4:      	movk	x13, #0x1331, lsl #16
    70f8:      	movk	x13, #0x49bb, lsl #32
    70fc:      	movk	x13, #0x94d0, lsl #48
    7100:      	mul	x8, x8, x13
    7104:      	eor	x9, x9, x9, lsr #30
    7108:      	mul	x9, x9, x12
    710c:      	eor	x9, x9, x9, lsr #27
    7110:      	mul	x9, x9, x13
    7114:      	eor	x12, x9, x8
    7118:      	mov	x13, #0x7c15            ; =31765
    711c:      	movk	x13, #0x7f4a, lsl #16
    7120:      	movk	x13, #0x79b9, lsl #32
    7124:      	movk	x13, #0x9e37, lsl #48
    7128:      	mul	x11, x11, x13
    712c:      	eor	x10, x10, x11
    7130:      	eor	x10, x10, x12, lsr #31
    7134:      	eor	x8, x8, x9
    7138:      	eor	x0, x10, x8
    713c:      	ldp	x29, x30, [sp, #0x50]
    7140:      	add	sp, sp, #0x60
    7144:      	ret

0000000000007148 <_wf_box_slots_new$instance$e194368921a477a7>:
    7148:      	stp	x20, x19, [sp, #-0x20]!
    714c:      	stp	x29, x30, [sp, #0x10]
    7150:      	mov	x19, x0
    7154:      	cbz	x0, 0x717c <_wf_box_slots_new$instance$e194368921a477a7+0x34>
    7158:      	lsl	x0, x19, #3
    715c:      	bl	0x715c <_wf_box_slots_new$instance$e194368921a477a7+0x14>
		000000000000715c:  ARM64_RELOC_BRANCH26	_malloc
    7160:      	mov	x2, x0
    7164:      	cbz	x0, 0x7198 <_wf_box_slots_new$instance$e194368921a477a7+0x50>
    7168:      	mov	x0, #0x0                ; =0
    716c:      	mov	x1, x19
    7170:      	ldp	x29, x30, [sp, #0x10]
    7174:      	ldp	x20, x19, [sp], #0x20
    7178:      	ret
    717c:      	adrp	x2, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x1c8>
		000000000000717c:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    7180:      	add	x2, x2, #0x0
		0000000000007180:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    7184:      	mov	x0, #0x0                ; =0
    7188:      	mov	x1, x19
    718c:      	ldp	x29, x30, [sp, #0x10]
    7190:      	ldp	x20, x19, [sp], #0x20
    7194:      	ret
    7198:      	bl	0x7198 <_wf_box_slots_new$instance$e194368921a477a7+0x50>
		0000000000007198:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000719c <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd>:
    719c:      	sub	sp, sp, #0x50
    71a0:      	stp	x24, x23, [sp, #0x10]
    71a4:      	stp	x22, x21, [sp, #0x20]
    71a8:      	stp	x20, x19, [sp, #0x30]
    71ac:      	stp	x29, x30, [sp, #0x40]
    71b0:      	mov	x19, x3
    71b4:      	mov	x21, x1
    71b8:      	mov	x20, x0
    71bc:      	cbz	x1, 0x7264 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0xc8>
    71c0:      	mov	x23, x2
    71c4:      	lsl	x24, x21, #3
    71c8:      	mov	x0, x24
    71cc:      	bl	0x71cc <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x30>
		00000000000071cc:  ARM64_RELOC_BRANCH26	_malloc
    71d0:      	cbz	x0, 0x7354 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x1b8>
    71d4:      	mov	x22, x0
    71d8:      	mov	w1, #0xff               ; =255
    71dc:      	mov	x2, x24
    71e0:      	bl	0x71e0 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x44>
		00000000000071e0:  ARM64_RELOC_BRANCH26	_memset
    71e4:      	add	x8, x21, x21, lsl #1
    71e8:      	lsl	x0, x8, #3
    71ec:      	bl	0x71ec <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x50>
		00000000000071ec:  ARM64_RELOC_BRANCH26	_malloc
    71f0:      	cbz	x0, 0x7354 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x1b8>
    71f4:      	mov	x8, #0x7c15             ; =31765
    71f8:      	movk	x8, #0x7f4a, lsl #16
    71fc:      	movk	x8, #0x79b9, lsl #32
    7200:      	movk	x8, #0x9e37, lsl #48
    7204:      	eor	x8, x19, x8
    7208:      	strb	wzr, [sp, #0x8]
    720c:      	cbz	x23, 0x7290 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0xf4>
    7210:      	cbz	wzr, 0x72c4 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x128>
    7214:      	mov	x13, #0x0               ; =0
    7218:      	mov	w10, #0x1               ; =1
    721c:      	mov	w11, #0x18              ; =24
    7220:      	mov	x12, x19
    7224:      	b	0x723c <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0xa0>
    7228:      	add	x12, x12, #0x1
    722c:      	add	x10, x10, #0x2
    7230:      	mov	x13, x9
    7234:      	subs	x23, x23, #0x1
    7238:      	b.eq	0x7294 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0xf8>
    723c:      	mov	x9, x21
    7240:      	cmp	x13, x21
    7244:      	b.eq	0x7228 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x8c>
    7248:      	ldr	x9, [x22]
    724c:      	madd	x14, x13, x11, x0
    7250:      	stp	x10, x12, [x14]
    7254:      	str	x9, [x14, #0x10]
    7258:      	add	x9, x13, #0x1
    725c:      	str	x13, [x22]
    7260:      	b	0x7228 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x8c>
    7264:      	mov	x9, #0x0                ; =0
    7268:      	mov	x8, #0x7c15             ; =31765
    726c:      	movk	x8, #0x7f4a, lsl #16
    7270:      	movk	x8, #0x79b9, lsl #32
    7274:      	movk	x8, #0x9e37, lsl #48
    7278:      	eor	x8, x19, x8
    727c:      	strb	wzr, [sp, #0x8]
    7280:      	adrp	x0, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x1c8>
		0000000000007280:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    7284:      	add	x0, x0, #0x0
		0000000000007284:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    7288:      	mov	x22, x0
    728c:      	b	0x7294 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0xf8>
    7290:      	mov	x9, #0x0                ; =0
    7294:      	stp	x21, x21, [x20]
    7298:      	stp	x22, x9, [x20, #0x10]
    729c:      	stp	x21, x0, [x20, #0x20]
    72a0:      	stp	x8, xzr, [x20, #0x30]
    72a4:      	strb	wzr, [x20, #0x38]
    72a8:      	str	x19, [x20, #0x40]
    72ac:      	ldp	x29, x30, [sp, #0x40]
    72b0:      	ldp	x20, x19, [sp, #0x30]
    72b4:      	ldp	x22, x21, [sp, #0x20]
    72b8:      	ldp	x24, x23, [sp, #0x10]
    72bc:      	add	sp, sp, #0x50
    72c0:      	ret
    72c4:      	mov	x15, #0x0               ; =0
    72c8:      	mov	w10, #0x1               ; =1
    72cc:      	mov	x11, #0xe5b9            ; =58809
    72d0:      	movk	x11, #0x1ce4, lsl #16
    72d4:      	movk	x11, #0x476d, lsl #32
    72d8:      	movk	x11, #0xbf58, lsl #48
    72dc:      	mov	x12, #0x11eb            ; =4587
    72e0:      	movk	x12, #0x1331, lsl #16
    72e4:      	movk	x12, #0x49bb, lsl #32
    72e8:      	movk	x12, #0x94d0, lsl #48
    72ec:      	mov	w13, #0x18              ; =24
    72f0:      	mov	x14, x19
    72f4:      	b	0x730c <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x170>
    72f8:      	add	x14, x14, #0x1
    72fc:      	add	x10, x10, #0x2
    7300:      	mov	x15, x9
    7304:      	subs	x23, x23, #0x1
    7308:      	b.eq	0x7294 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0xf8>
    730c:      	mov	x9, x21
    7310:      	cmp	x15, x21
    7314:      	b.eq	0x72f8 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x15c>
    7318:      	eor	x9, x10, x8
    731c:      	eor	x9, x9, x9, lsr #30
    7320:      	mul	x9, x9, x11
    7324:      	eor	x9, x9, x9, lsr #27
    7328:      	mul	x9, x9, x12
    732c:      	eor	x9, x9, x9, lsr #31
    7330:      	udiv	x16, x9, x21
    7334:      	msub	x16, x16, x21, x9
    7338:      	ldr	x9, [x22, x16, lsl #3]
    733c:      	madd	x17, x15, x13, x0
    7340:      	stp	x10, x14, [x17]
    7344:      	str	x9, [x17, #0x10]
    7348:      	add	x9, x15, #0x1
    734c:      	str	x15, [x22, x16, lsl #3]
    7350:      	b	0x72f8 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x15c>
    7354:      	bl	0x7354 <_wf_chain_lookup_prepare$instance$c7c8cd11e7f079bd+0x1b8>
		0000000000007354:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

0000000000007358 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd>:
    7358:      	mov	x9, #0xe5b9             ; =58809
    735c:      	movk	x9, #0x1ce4, lsl #16
    7360:      	movk	x9, #0x476d, lsl #32
    7364:      	movk	x9, #0xbf58, lsl #48
    7368:      	mov	x8, #0x11eb             ; =4587
    736c:      	movk	x8, #0x1331, lsl #16
    7370:      	movk	x8, #0x49bb, lsl #32
    7374:      	movk	x8, #0x94d0, lsl #48
    7378:      	ldr	x10, [x0, #0x40]
    737c:      	cmp	x2, #0x0
    7380:      	mov	w11, #0x1               ; =1
    7384:      	cinc	x11, x11, ne
    7388:      	cbz	x1, 0x745c <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x104>
    738c:      	ldr	x12, [x0, #0x18]
    7390:      	cbz	x12, 0x745c <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x104>
    7394:      	ldrb	w15, [x0, #0x38]
    7398:      	ldr	x14, [x0]
    739c:      	cbz	x14, 0x743c <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0xe4>
    73a0:      	stp	x20, x19, [sp, #-0x10]!
    73a4:      	ldr	x13, [x0, #0x10]
    73a8:      	tbz	w15, #0x0, 0x7474 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x11c>
    73ac:      	mov	x14, #0x0               ; =0
    73b0:      	mov	w15, #0x18              ; =24
    73b4:      	mov	w16, #0x4309            ; =17161
    73b8:      	mov	w17, #0x83              ; =131
    73bc:      	b	0x73cc <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x74>
    73c0:      	add	x14, x14, #0x1
    73c4:      	cmp	x14, x1
    73c8:      	b.eq	0x7528 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x1d0>
    73cc:      	mov	x2, #0x0                ; =0
    73d0:      	b	0x73e4 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x8c>
    73d4:      	mul	x10, x10, x17
    73d8:      	add	x2, x2, #0x1
    73dc:      	cmp	x2, x12
    73e0:      	b.eq	0x73c0 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x68>
    73e4:      	add	x3, x11, x2, lsl #1
    73e8:      	mov	x4, x12
    73ec:      	mov	x5, x13
    73f0:      	ldr	x5, [x5]
    73f4:      	cmp	x5, x12
    73f8:      	b.hs	0x73d4 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x7c>
    73fc:      	ldr	x6, [x0, #0x28]
    7400:      	madd	x5, x5, x15, x6
    7404:      	ldr	x6, [x5]
    7408:      	cmp	x6, x3
    740c:      	b.eq	0x7420 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0xc8>
    7410:      	add	x5, x5, #0x10
    7414:      	subs	x4, x4, #0x1
    7418:      	b.ne	0x73f0 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x98>
    741c:      	b	0x73d4 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x7c>
    7420:      	ldr	x3, [x5, #0x8]
    7424:      	madd	x10, x10, x16, x3
    7428:      	add	x10, x10, #0x83
    742c:      	add	x2, x2, #0x1
    7430:      	cmp	x2, x12
    7434:      	b.ne	0x73e4 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x8c>
    7438:      	b	0x73c0 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x68>
    743c:      	and	x11, x12, #0xfffffffffffffffe
    7440:      	cmp	x12, #0x1
    7444:      	tbz	w15, #0x0, 0x7544 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x1ec>
    7448:      	b.ne	0x755c <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x204>
    744c:      	mov	w11, #0x83              ; =131
    7450:      	mul	x10, x10, x11
    7454:      	subs	x1, x1, #0x1
    7458:      	b.ne	0x7450 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0xf8>
    745c:      	eor	x10, x10, x10, lsr #30
    7460:      	mul	x9, x10, x9
    7464:      	eor	x9, x9, x9, lsr #27
    7468:      	mul	x8, x9, x8
    746c:      	eor	x0, x8, x8, lsr #31
    7470:      	ret
    7474:      	mov	x15, #0x0               ; =0
    7478:      	ldr	x16, [x0, #0x30]
    747c:      	mov	w17, #0x18              ; =24
    7480:      	mov	w2, #0x4309             ; =17161
    7484:      	mov	w3, #0x83               ; =131
    7488:      	b	0x7498 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x140>
    748c:      	add	x15, x15, #0x1
    7490:      	cmp	x15, x1
    7494:      	b.eq	0x7528 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x1d0>
    7498:      	mov	x4, #0x0                ; =0
    749c:      	b	0x74b0 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x158>
    74a0:      	mul	x10, x10, x3
    74a4:      	add	x4, x4, #0x1
    74a8:      	cmp	x4, x12
    74ac:      	b.eq	0x748c <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x134>
    74b0:      	add	x5, x11, x4, lsl #1
    74b4:      	eor	x6, x16, x5
    74b8:      	eor	x6, x6, x6, lsr #30
    74bc:      	mul	x6, x6, x9
    74c0:      	eor	x6, x6, x6, lsr #27
    74c4:      	mul	x6, x6, x8
    74c8:      	eor	x6, x6, x6, lsr #31
    74cc:      	udiv	x7, x6, x14
    74d0:      	msub	x6, x7, x14, x6
    74d4:      	add	x7, x13, x6, lsl #3
    74d8:      	mov	x6, x12
    74dc:      	ldr	x7, [x7]
    74e0:      	cmp	x7, x12
    74e4:      	b.hs	0x74a0 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x148>
    74e8:      	ldr	x19, [x0, #0x28]
    74ec:      	madd	x7, x7, x17, x19
    74f0:      	ldr	x19, [x7]
    74f4:      	cmp	x19, x5
    74f8:      	b.eq	0x750c <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x1b4>
    74fc:      	add	x7, x7, #0x10
    7500:      	subs	x6, x6, #0x1
    7504:      	b.ne	0x74dc <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x184>
    7508:      	b	0x74a0 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x148>
    750c:      	ldr	x5, [x7, #0x8]
    7510:      	madd	x10, x10, x2, x5
    7514:      	add	x10, x10, #0x83
    7518:      	add	x4, x4, #0x1
    751c:      	cmp	x4, x12
    7520:      	b.ne	0x74b0 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x158>
    7524:      	b	0x748c <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x134>
    7528:      	ldp	x20, x19, [sp], #0x10
    752c:      	eor	x10, x10, x10, lsr #30
    7530:      	mul	x9, x10, x9
    7534:      	eor	x9, x9, x9, lsr #27
    7538:      	mul	x8, x9, x8
    753c:      	eor	x0, x8, x8, lsr #31
    7540:      	ret
    7544:      	b.ne	0x7594 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x23c>
    7548:      	mov	w11, #0x83              ; =131
    754c:      	mul	x10, x10, x11
    7550:      	subs	x1, x1, #0x1
    7554:      	b.ne	0x754c <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x1f4>
    7558:      	b	0x745c <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x104>
    755c:      	subs	x12, x12, x11
    7560:      	b.ne	0x75cc <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x274>
    7564:      	mov	w13, #0x83              ; =131
    7568:      	mov	x14, x11
    756c:      	mov	w15, #0x1               ; =1
    7570:      	mul	x10, x10, x13
    7574:      	mul	x15, x15, x13
    7578:      	subs	x14, x14, #0x2
    757c:      	b.ne	0x7570 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x218>
    7580:      	mul	x10, x15, x10
    7584:      	add	x12, x12, #0x1
    7588:      	cmp	x12, x1
    758c:      	b.ne	0x7568 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x210>
    7590:      	b	0x745c <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x104>
    7594:      	subs	x12, x12, x11
    7598:      	b.ne	0x7610 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x2b8>
    759c:      	mov	w13, #0x83              ; =131
    75a0:      	mov	x14, x11
    75a4:      	mov	w15, #0x1               ; =1
    75a8:      	mul	x10, x10, x13
    75ac:      	mul	x15, x15, x13
    75b0:      	subs	x14, x14, #0x2
    75b4:      	b.ne	0x75a8 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x250>
    75b8:      	mul	x10, x15, x10
    75bc:      	add	x12, x12, #0x1
    75c0:      	cmp	x12, x1
    75c4:      	b.ne	0x75a0 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x248>
    75c8:      	b	0x745c <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x104>
    75cc:      	mov	x13, #0x0               ; =0
    75d0:      	mov	w14, #0x83              ; =131
    75d4:      	mov	x15, x11
    75d8:      	mov	w16, #0x1               ; =1
    75dc:      	mul	x10, x10, x14
    75e0:      	mul	x16, x16, x14
    75e4:      	subs	x15, x15, #0x2
    75e8:      	b.ne	0x75dc <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x284>
    75ec:      	mul	x10, x16, x10
    75f0:      	mov	x15, x12
    75f4:      	mul	x10, x10, x14
    75f8:      	subs	x15, x15, #0x1
    75fc:      	b.ne	0x75f4 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x29c>
    7600:      	add	x13, x13, #0x1
    7604:      	cmp	x13, x1
    7608:      	b.ne	0x75d4 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x27c>
    760c:      	b	0x745c <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x104>
    7610:      	mov	x13, #0x0               ; =0
    7614:      	mov	w14, #0x83              ; =131
    7618:      	mov	x15, x11
    761c:      	mov	w16, #0x1               ; =1
    7620:      	mul	x10, x10, x14
    7624:      	mul	x16, x16, x14
    7628:      	subs	x15, x15, #0x2
    762c:      	b.ne	0x7620 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x2c8>
    7630:      	mul	x10, x16, x10
    7634:      	mov	x15, x12
    7638:      	mul	x10, x10, x14
    763c:      	subs	x15, x15, #0x1
    7640:      	b.ne	0x7638 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x2e0>
    7644:      	add	x13, x13, #0x1
    7648:      	cmp	x13, x1
    764c:      	b.ne	0x7618 <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x2c0>
    7650:      	b	0x745c <_wf_chain_lookup_query$instance$c7c8cd11e7f079bd+0x104>

0000000000007654 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd>:
    7654:      	stp	x28, x27, [sp, #-0x60]!
    7658:      	stp	x26, x25, [sp, #0x10]
    765c:      	stp	x24, x23, [sp, #0x20]
    7660:      	stp	x22, x21, [sp, #0x30]
    7664:      	stp	x20, x19, [sp, #0x40]
    7668:      	stp	x29, x30, [sp, #0x50]
    766c:      	mov	x8, x0
    7670:      	mov	x21, #0xe5b9            ; =58809
    7674:      	movk	x21, #0x1ce4, lsl #16
    7678:      	movk	x21, #0x476d, lsl #32
    767c:      	movk	x21, #0xbf58, lsl #48
    7680:      	mov	x20, #0x11eb            ; =4587
    7684:      	movk	x20, #0x1331, lsl #16
    7688:      	movk	x20, #0x49bb, lsl #32
    768c:      	movk	x20, #0x94d0, lsl #48
    7690:      	ldp	x10, x9, [x0, #0x18]
    7694:      	ldr	x0, [x0, #0x28]
    7698:      	cbz	x10, 0x76b4 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0x60>
    769c:      	cmp	x10, #0x4
    76a0:      	b.hs	0x76d0 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0x7c>
    76a4:      	mov	x23, #0x0               ; =0
    76a8:      	mov	x22, #0x0               ; =0
    76ac:      	mov	x11, x10
    76b0:      	b	0x77c8 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0x174>
    76b4:      	mov	x24, #0x0               ; =0
    76b8:      	mov	x22, #0x0               ; =0
    76bc:      	mov	x23, #0x0               ; =0
    76c0:      	ldp	x26, x19, [x8, #0x8]
    76c4:      	ldr	x25, [x8, #0x40]
    76c8:      	cbnz	x9, 0x7824 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0x1d0>
    76cc:      	b	0x7828 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0x1d4>
    76d0:      	mov	x13, #0x0               ; =0
    76d4:      	mov	x14, #0x0               ; =0
    76d8:      	mov	x15, #0x0               ; =0
    76dc:      	mov	x16, #0x0               ; =0
    76e0:      	mov	x17, #0x0               ; =0
    76e4:      	mov	x1, #0x0                ; =0
    76e8:      	mov	x2, #0x0                ; =0
    76ec:      	mov	x3, #0x0                ; =0
    76f0:      	and	x12, x10, #0xfffffffffffffffc
    76f4:      	and	x11, x10, #0x3
    76f8:      	mov	w4, #0x18               ; =24
    76fc:      	madd	x4, x10, x4, x0
    7700:      	sub	x4, x4, #0x30
    7704:      	mov	w5, #0x83               ; =131
    7708:      	mov	x6, x12
    770c:      	ldp	x7, x19, [x4, #0x18]
    7710:      	ldp	x22, x23, [x4]
    7714:      	ldp	x24, x25, [x4, #-0x18]
    7718:      	ldp	x26, x27, [x4, #-0x30]
    771c:      	madd	x7, x7, x5, x19
    7720:      	madd	x19, x22, x5, x23
    7724:      	madd	x22, x24, x5, x25
    7728:      	madd	x23, x26, x5, x27
    772c:      	add	x13, x7, x13
    7730:      	add	x14, x19, x14
    7734:      	add	x15, x22, x15
    7738:      	add	x16, x23, x16
    773c:      	eor	x7, x7, x7, lsr #30
    7740:      	eor	x19, x19, x19, lsr #30
    7744:      	eor	x22, x22, x22, lsr #30
    7748:      	eor	x23, x23, x23, lsr #30
    774c:      	mul	x7, x7, x21
    7750:      	mul	x19, x19, x21
    7754:      	mul	x22, x22, x21
    7758:      	mul	x23, x23, x21
    775c:      	eor	x7, x7, x7, lsr #27
    7760:      	eor	x19, x19, x19, lsr #27
    7764:      	eor	x22, x22, x22, lsr #27
    7768:      	eor	x23, x23, x23, lsr #27
    776c:      	mul	x7, x7, x20
    7770:      	mul	x19, x19, x20
    7774:      	mul	x22, x22, x20
    7778:      	eor	x17, x17, x7, lsr #31
    777c:      	mul	x23, x23, x20
    7780:      	eor	x1, x1, x19, lsr #31
    7784:      	eor	x2, x2, x22, lsr #31
    7788:      	eor	x3, x3, x23, lsr #31
    778c:      	eor	x17, x17, x7
    7790:      	eor	x1, x1, x19
    7794:      	eor	x2, x2, x22
    7798:      	eor	x3, x3, x23
    779c:      	sub	x4, x4, #0x60
    77a0:      	sub	x6, x6, #0x4
    77a4:      	cbnz	x6, 0x770c <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0xb8>
    77a8:      	add	x13, x14, x13
    77ac:      	add	x14, x16, x15
    77b0:      	add	x23, x14, x13
    77b4:      	eor	x13, x1, x17
    77b8:      	eor	x14, x3, x2
    77bc:      	eor	x22, x14, x13
    77c0:      	cmp	x10, x12
    77c4:      	b.eq	0x7804 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0x1b0>
    77c8:      	mov	w12, #0x18              ; =24
    77cc:      	madd	x12, x11, x12, x0
    77d0:      	sub	x12, x12, #0x18
    77d4:      	mov	w13, #0x83              ; =131
    77d8:      	ldp	x14, x15, [x12], #-0x18
    77dc:      	madd	x14, x14, x13, x15
    77e0:      	add	x23, x14, x23
    77e4:      	eor	x14, x14, x14, lsr #30
    77e8:      	mul	x14, x14, x21
    77ec:      	eor	x14, x14, x14, lsr #27
    77f0:      	mul	x14, x14, x20
    77f4:      	eor	x15, x22, x14, lsr #31
    77f8:      	eor	x22, x15, x14
    77fc:      	sub	x11, x11, #0x1
    7800:      	cbnz	x11, 0x77d8 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0x184>
    7804:      	mov	x11, #0x7c15            ; =31765
    7808:      	movk	x11, #0x7f4a, lsl #16
    780c:      	movk	x11, #0x79b9, lsl #32
    7810:      	movk	x11, #0x9e37, lsl #48
    7814:      	mul	x24, x10, x11
    7818:      	ldp	x26, x19, [x8, #0x8]
    781c:      	ldr	x25, [x8, #0x40]
    7820:      	cbz	x9, 0x7828 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0x1d4>
    7824:      	bl	0x7824 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0x1d0>
		0000000000007824:  ARM64_RELOC_BRANCH26	_free
    7828:      	cbz	x26, 0x7834 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0x1e0>
    782c:      	mov	x0, x19
    7830:      	bl	0x7830 <_wf_chain_lookup_finish$instance$c7c8cd11e7f079bd+0x1dc>
		0000000000007830:  ARM64_RELOC_BRANCH26	_free
    7834:      	eor	x8, x23, x23, lsr #30
    7838:      	mul	x8, x8, x21
    783c:      	eor	x8, x8, x8, lsr #27
    7840:      	mul	x8, x8, x20
    7844:      	eor	x9, x25, x25, lsr #30
    7848:      	mul	x9, x9, x21
    784c:      	eor	x9, x9, x9, lsr #27
    7850:      	mul	x9, x9, x20
    7854:      	eor	x10, x8, x9
    7858:      	eor	x11, x24, x22
    785c:      	eor	x10, x11, x10, lsr #31
    7860:      	eor	x8, x9, x8
    7864:      	eor	x0, x10, x8
    7868:      	ldp	x29, x30, [sp, #0x50]
    786c:      	ldp	x20, x19, [sp, #0x40]
    7870:      	ldp	x22, x21, [sp, #0x30]
    7874:      	ldp	x24, x23, [sp, #0x20]
    7878:      	ldp	x26, x25, [sp, #0x10]
    787c:      	ldp	x28, x27, [sp], #0x60
    7880:      	ret

0000000000007884 <_wf_chain_lookup_geometry$instance$e194368921a477a7>:
    7884:      	ldr	x8, [x0]
    7888:      	ldr	x9, [x0, #0x18]
    788c:      	add	x0, x9, x8, lsl #32
    7890:      	ret

0000000000007894 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027>:
    7894:      	sub	sp, sp, #0x50
    7898:      	stp	x24, x23, [sp, #0x10]
    789c:      	stp	x22, x21, [sp, #0x20]
    78a0:      	stp	x20, x19, [sp, #0x30]
    78a4:      	stp	x29, x30, [sp, #0x40]
    78a8:      	mov	x19, x3
    78ac:      	mov	x23, x2
    78b0:      	mov	x21, x1
    78b4:      	mov	x20, x0
    78b8:      	cbz	x1, 0x78f0 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x5c>
    78bc:      	lsl	x24, x21, #3
    78c0:      	mov	x0, x24
    78c4:      	bl	0x78c4 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x30>
		00000000000078c4:  ARM64_RELOC_BRANCH26	_malloc
    78c8:      	cbz	x0, 0x78ec <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x58>
    78cc:      	mov	x22, x0
    78d0:      	mov	w1, #0xff               ; =255
    78d4:      	mov	x2, x24
    78d8:      	bl	0x78d8 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x44>
		00000000000078d8:  ARM64_RELOC_BRANCH26	_memset
    78dc:      	add	x8, x21, x21, lsl #4
    78e0:      	lsl	x0, x8, #4
    78e4:      	bl	0x78e4 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x50>
		00000000000078e4:  ARM64_RELOC_BRANCH26	_malloc
    78e8:      	cbnz	x0, 0x78fc <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x68>
    78ec:      	bl	0x78ec <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x58>
		00000000000078ec:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
    78f0:      	adrp	x22, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x1c8>
		00000000000078f0:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    78f4:      	add	x22, x22, #0x0
		00000000000078f4:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    78f8:      	mov	x0, x22
    78fc:      	mov	x8, #0x7c15             ; =31765
    7900:      	movk	x8, #0x7f4a, lsl #16
    7904:      	movk	x8, #0x79b9, lsl #32
    7908:      	movk	x8, #0x9e37, lsl #48
    790c:      	eor	x8, x19, x8
    7910:      	strb	wzr, [sp, #0x8]
    7914:      	mov	x9, #0x0                ; =0
    7918:      	cbz	x23, 0x7a90 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x1fc>
    791c:      	adrp	x10, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x1c8>
		000000000000791c:  ARM64_RELOC_PAGE21	lCPI84_0
    7920:      	ldr	q0, [x10]
		0000000000007920:  ARM64_RELOC_PAGEOFF12	lCPI84_0
    7924:      	adrp	x10, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x1c8>
		0000000000007924:  ARM64_RELOC_PAGE21	lCPI84_1
    7928:      	ldr	q1, [x10]
		0000000000007928:  ARM64_RELOC_PAGEOFF12	lCPI84_1
    792c:      	mov	w10, #0x1               ; =1
    7930:      	adrp	x11, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x1c8>
		0000000000007930:  ARM64_RELOC_PAGE21	lCPI84_2
    7934:      	ldr	q2, [x11]
		0000000000007934:  ARM64_RELOC_PAGEOFF12	lCPI84_2
    7938:      	adrp	x11, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x1c8>
		0000000000007938:  ARM64_RELOC_PAGE21	lCPI84_3
    793c:      	ldr	q3, [x11]
		000000000000793c:  ARM64_RELOC_PAGEOFF12	lCPI84_3
    7940:      	adrp	x11, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x1c8>
		0000000000007940:  ARM64_RELOC_PAGE21	lCPI84_4
    7944:      	ldr	q4, [x11]
		0000000000007944:  ARM64_RELOC_PAGEOFF12	lCPI84_4
    7948:      	adrp	x11, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x1c8>
		0000000000007948:  ARM64_RELOC_PAGE21	lCPI84_5
    794c:      	ldr	q5, [x11]
		000000000000794c:  ARM64_RELOC_PAGEOFF12	lCPI84_5
    7950:      	adrp	x11, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x1c8>
		0000000000007950:  ARM64_RELOC_PAGE21	lCPI84_6
    7954:      	ldr	q6, [x11]
		0000000000007954:  ARM64_RELOC_PAGEOFF12	lCPI84_6
    7958:      	adrp	x11, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x1c8>
		0000000000007958:  ARM64_RELOC_PAGE21	lCPI84_7
    795c:      	ldr	q7, [x11]
		000000000000795c:  ARM64_RELOC_PAGEOFF12	lCPI84_7
    7960:      	adrp	x11, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x1c8>
		0000000000007960:  ARM64_RELOC_PAGE21	lCPI84_8
    7964:      	ldr	q16, [x11]
		0000000000007964:  ARM64_RELOC_PAGEOFF12	lCPI84_8
    7968:      	adrp	x11, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x1c8>
		0000000000007968:  ARM64_RELOC_PAGE21	lCPI84_9
    796c:      	ldr	q17, [x11]
		000000000000796c:  ARM64_RELOC_PAGEOFF12	lCPI84_9
    7970:      	adrp	x11, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x1c8>
		0000000000007970:  ARM64_RELOC_PAGE21	lCPI84_10
    7974:      	ldr	q18, [x11]
		0000000000007974:  ARM64_RELOC_PAGEOFF12	lCPI84_10
    7978:      	adrp	x11, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x1c8>
		0000000000007978:  ARM64_RELOC_PAGE21	lCPI84_11
    797c:      	ldr	q19, [x11]
		000000000000797c:  ARM64_RELOC_PAGEOFF12	lCPI84_11
    7980:      	mov	w11, #0x110             ; =272
    7984:      	adrp	x12, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x1c8>
		0000000000007984:  ARM64_RELOC_PAGE21	lCPI84_12
    7988:      	ldr	q20, [x12]
		0000000000007988:  ARM64_RELOC_PAGEOFF12	lCPI84_12
    798c:      	mov	x12, #0xe5b9            ; =58809
    7990:      	movk	x12, #0x1ce4, lsl #16
    7994:      	movk	x12, #0x476d, lsl #32
    7998:      	movk	x12, #0xbf58, lsl #48
    799c:      	adrp	x13, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x1c8>
		000000000000799c:  ARM64_RELOC_PAGE21	lCPI84_13
    79a0:      	ldr	q21, [x13]
		00000000000079a0:  ARM64_RELOC_PAGEOFF12	lCPI84_13
    79a4:      	mov	x13, #0x11eb            ; =4587
    79a8:      	movk	x13, #0x1331, lsl #16
    79ac:      	movk	x13, #0x49bb, lsl #32
    79b0:      	movk	x13, #0x94d0, lsl #48
    79b4:      	adrp	x14, 0x7000 <_wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd+0x1c8>
		00000000000079b4:  ARM64_RELOC_PAGE21	lCPI84_14
    79b8:      	ldr	q22, [x14]
		00000000000079b8:  ARM64_RELOC_PAGEOFF12	lCPI84_14
    79bc:      	mov	x14, x19
    79c0:      	b	0x79d4 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x140>
    79c4:      	add	x14, x14, #0x1
    79c8:      	add	x10, x10, #0x2
    79cc:      	subs	x23, x23, #0x1
    79d0:      	b.eq	0x7a90 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x1fc>
    79d4:      	cbz	wzr, 0x79e4 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x150>
    79d8:      	mov	x15, #0x0               ; =0
    79dc:      	cbnz	x21, 0x7a00 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x16c>
    79e0:      	b	0x79c4 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x130>
    79e4:      	eor	x15, x10, x8
    79e8:      	eor	x15, x15, x15, lsr #30
    79ec:      	mul	x15, x15, x12
    79f0:      	eor	x15, x15, x15, lsr #27
    79f4:      	mul	x15, x15, x13
    79f8:      	eor	x15, x15, x15, lsr #31
    79fc:      	cbz	x21, 0x79c4 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x130>
    7a00:      	cmp	x9, x21
    7a04:      	b.eq	0x79c4 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x130>
    7a08:      	dup.2d	v23, x14
    7a0c:      	udiv	x16, x15, x21
    7a10:      	msub	x15, x16, x21, x15
    7a14:      	ldr	x16, [x22, x15, lsl #3]
    7a18:      	madd	x17, x9, x11, x0
    7a1c:      	stp	x10, x14, [x17]
    7a20:      	add.2d	v24, v23, v0
    7a24:      	add.2d	v25, v23, v1
    7a28:      	stp	q24, q25, [x17, #0x10]
    7a2c:      	add.2d	v24, v23, v2
    7a30:      	add.2d	v25, v23, v3
    7a34:      	stp	q24, q25, [x17, #0x30]
    7a38:      	add.2d	v24, v23, v4
    7a3c:      	add.2d	v25, v23, v5
    7a40:      	stp	q24, q25, [x17, #0x50]
    7a44:      	add.2d	v24, v23, v6
    7a48:      	add.2d	v25, v23, v7
    7a4c:      	stp	q24, q25, [x17, #0x70]
    7a50:      	add.2d	v24, v23, v16
    7a54:      	add.2d	v25, v23, v17
    7a58:      	stp	q24, q25, [x17, #0x90]
    7a5c:      	add.2d	v24, v23, v18
    7a60:      	add.2d	v25, v23, v19
    7a64:      	add.2d	v26, v23, v20
    7a68:      	add.2d	v27, v23, v21
    7a6c:      	stp	q24, q25, [x17, #0xb0]
    7a70:      	add.2d	v23, v23, v22
    7a74:      	stp	q26, q27, [x17, #0xd0]
    7a78:      	add	x1, x14, #0x1f
    7a7c:      	str	q23, [x17, #0xf0]
    7a80:      	stp	x1, x16, [x17, #0x100]
    7a84:      	str	x9, [x22, x15, lsl #3]
    7a88:      	add	x9, x9, #0x1
    7a8c:      	b	0x79c4 <_wf_chain_lookup_prepare$instance$4250cb78d3f44027+0x130>
    7a90:      	stp	x21, x21, [x20]
    7a94:      	stp	x22, x9, [x20, #0x10]
    7a98:      	stp	x21, x0, [x20, #0x20]
    7a9c:      	stp	x8, xzr, [x20, #0x30]
    7aa0:      	strb	wzr, [x20, #0x38]
    7aa4:      	str	x19, [x20, #0x40]
    7aa8:      	ldp	x29, x30, [sp, #0x40]
    7aac:      	ldp	x20, x19, [sp, #0x30]
    7ab0:      	ldp	x22, x21, [sp, #0x20]
    7ab4:      	ldp	x24, x23, [sp, #0x10]
    7ab8:      	add	sp, sp, #0x50
    7abc:      	ret

0000000000007ac0 <_wf_chain_lookup_query$instance$4250cb78d3f44027>:
    7ac0:      	mov	x9, #0xe5b9             ; =58809
    7ac4:      	movk	x9, #0x1ce4, lsl #16
    7ac8:      	movk	x9, #0x476d, lsl #32
    7acc:      	movk	x9, #0xbf58, lsl #48
    7ad0:      	mov	x8, #0x11eb             ; =4587
    7ad4:      	movk	x8, #0x1331, lsl #16
    7ad8:      	movk	x8, #0x49bb, lsl #32
    7adc:      	movk	x8, #0x94d0, lsl #48
    7ae0:      	ldr	x10, [x0, #0x40]
    7ae4:      	cmp	x2, #0x0
    7ae8:      	mov	w11, #0x1               ; =1
    7aec:      	cinc	x11, x11, ne
    7af0:      	cbz	x1, 0x7bc4 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x104>
    7af4:      	ldr	x12, [x0, #0x18]
    7af8:      	cbz	x12, 0x7bc4 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x104>
    7afc:      	ldrb	w15, [x0, #0x38]
    7b00:      	ldr	x14, [x0]
    7b04:      	cbz	x14, 0x7ba4 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0xe4>
    7b08:      	stp	x20, x19, [sp, #-0x10]!
    7b0c:      	ldr	x13, [x0, #0x10]
    7b10:      	tbz	w15, #0x0, 0x7bdc <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x11c>
    7b14:      	mov	x14, #0x0               ; =0
    7b18:      	mov	w15, #0x110             ; =272
    7b1c:      	mov	w16, #0x4309            ; =17161
    7b20:      	mov	w17, #0x83              ; =131
    7b24:      	b	0x7b34 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x74>
    7b28:      	add	x14, x14, #0x1
    7b2c:      	cmp	x14, x1
    7b30:      	b.eq	0x7c90 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x1d0>
    7b34:      	mov	x2, #0x0                ; =0
    7b38:      	b	0x7b4c <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x8c>
    7b3c:      	mul	x10, x10, x17
    7b40:      	add	x2, x2, #0x1
    7b44:      	cmp	x2, x12
    7b48:      	b.eq	0x7b28 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x68>
    7b4c:      	add	x3, x11, x2, lsl #1
    7b50:      	mov	x4, x12
    7b54:      	mov	x5, x13
    7b58:      	ldr	x5, [x5]
    7b5c:      	cmp	x5, x12
    7b60:      	b.hs	0x7b3c <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x7c>
    7b64:      	ldr	x6, [x0, #0x28]
    7b68:      	madd	x5, x5, x15, x6
    7b6c:      	ldr	x6, [x5]
    7b70:      	cmp	x6, x3
    7b74:      	b.eq	0x7b88 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0xc8>
    7b78:      	add	x5, x5, #0x108
    7b7c:      	subs	x4, x4, #0x1
    7b80:      	b.ne	0x7b58 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x98>
    7b84:      	b	0x7b3c <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x7c>
    7b88:      	ldr	x3, [x5, #0x8]
    7b8c:      	madd	x10, x10, x16, x3
    7b90:      	add	x10, x10, #0x83
    7b94:      	add	x2, x2, #0x1
    7b98:      	cmp	x2, x12
    7b9c:      	b.ne	0x7b4c <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x8c>
    7ba0:      	b	0x7b28 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x68>
    7ba4:      	and	x11, x12, #0xfffffffffffffffe
    7ba8:      	cmp	x12, #0x1
    7bac:      	tbz	w15, #0x0, 0x7cac <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x1ec>
    7bb0:      	b.ne	0x7cc4 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x204>
    7bb4:      	mov	w11, #0x83              ; =131
    7bb8:      	mul	x10, x10, x11
    7bbc:      	subs	x1, x1, #0x1
    7bc0:      	b.ne	0x7bb8 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0xf8>
    7bc4:      	eor	x10, x10, x10, lsr #30
    7bc8:      	mul	x9, x10, x9
    7bcc:      	eor	x9, x9, x9, lsr #27
    7bd0:      	mul	x8, x9, x8
    7bd4:      	eor	x0, x8, x8, lsr #31
    7bd8:      	ret
    7bdc:      	mov	x15, #0x0               ; =0
    7be0:      	ldr	x16, [x0, #0x30]
    7be4:      	mov	w17, #0x110             ; =272
    7be8:      	mov	w2, #0x4309             ; =17161
    7bec:      	mov	w3, #0x83               ; =131
    7bf0:      	b	0x7c00 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x140>
    7bf4:      	add	x15, x15, #0x1
    7bf8:      	cmp	x15, x1
    7bfc:      	b.eq	0x7c90 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x1d0>
    7c00:      	mov	x4, #0x0                ; =0
    7c04:      	b	0x7c18 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x158>
    7c08:      	mul	x10, x10, x3
    7c0c:      	add	x4, x4, #0x1
    7c10:      	cmp	x4, x12
    7c14:      	b.eq	0x7bf4 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x134>
    7c18:      	add	x5, x11, x4, lsl #1
    7c1c:      	eor	x6, x16, x5
    7c20:      	eor	x6, x6, x6, lsr #30
    7c24:      	mul	x6, x6, x9
    7c28:      	eor	x6, x6, x6, lsr #27
    7c2c:      	mul	x6, x6, x8
    7c30:      	eor	x6, x6, x6, lsr #31
    7c34:      	udiv	x7, x6, x14
    7c38:      	msub	x6, x7, x14, x6
    7c3c:      	add	x7, x13, x6, lsl #3
    7c40:      	mov	x6, x12
    7c44:      	ldr	x7, [x7]
    7c48:      	cmp	x7, x12
    7c4c:      	b.hs	0x7c08 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x148>
    7c50:      	ldr	x19, [x0, #0x28]
    7c54:      	madd	x7, x7, x17, x19
    7c58:      	ldr	x19, [x7]
    7c5c:      	cmp	x19, x5
    7c60:      	b.eq	0x7c74 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x1b4>
    7c64:      	add	x7, x7, #0x108
    7c68:      	subs	x6, x6, #0x1
    7c6c:      	b.ne	0x7c44 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x184>
    7c70:      	b	0x7c08 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x148>
    7c74:      	ldr	x5, [x7, #0x8]
    7c78:      	madd	x10, x10, x2, x5
    7c7c:      	add	x10, x10, #0x83
    7c80:      	add	x4, x4, #0x1
    7c84:      	cmp	x4, x12
    7c88:      	b.ne	0x7c18 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x158>
    7c8c:      	b	0x7bf4 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x134>
    7c90:      	ldp	x20, x19, [sp], #0x10
    7c94:      	eor	x10, x10, x10, lsr #30
    7c98:      	mul	x9, x10, x9
    7c9c:      	eor	x9, x9, x9, lsr #27
    7ca0:      	mul	x8, x9, x8
    7ca4:      	eor	x0, x8, x8, lsr #31
    7ca8:      	ret
    7cac:      	b.ne	0x7cfc <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x23c>
    7cb0:      	mov	w11, #0x83              ; =131
    7cb4:      	mul	x10, x10, x11
    7cb8:      	subs	x1, x1, #0x1
    7cbc:      	b.ne	0x7cb4 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x1f4>
    7cc0:      	b	0x7bc4 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x104>
    7cc4:      	subs	x12, x12, x11
    7cc8:      	b.ne	0x7d34 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x274>
    7ccc:      	mov	w13, #0x83              ; =131
    7cd0:      	mov	x14, x11
    7cd4:      	mov	w15, #0x1               ; =1
    7cd8:      	mul	x10, x10, x13
    7cdc:      	mul	x15, x15, x13
    7ce0:      	subs	x14, x14, #0x2
    7ce4:      	b.ne	0x7cd8 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x218>
    7ce8:      	mul	x10, x15, x10
    7cec:      	add	x12, x12, #0x1
    7cf0:      	cmp	x12, x1
    7cf4:      	b.ne	0x7cd0 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x210>
    7cf8:      	b	0x7bc4 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x104>
    7cfc:      	subs	x12, x12, x11
    7d00:      	b.ne	0x7d78 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x2b8>
    7d04:      	mov	w13, #0x83              ; =131
    7d08:      	mov	x14, x11
    7d0c:      	mov	w15, #0x1               ; =1
    7d10:      	mul	x10, x10, x13
    7d14:      	mul	x15, x15, x13
    7d18:      	subs	x14, x14, #0x2
    7d1c:      	b.ne	0x7d10 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x250>
    7d20:      	mul	x10, x15, x10
    7d24:      	add	x12, x12, #0x1
    7d28:      	cmp	x12, x1
    7d2c:      	b.ne	0x7d08 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x248>
    7d30:      	b	0x7bc4 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x104>
    7d34:      	mov	x13, #0x0               ; =0
    7d38:      	mov	w14, #0x83              ; =131
    7d3c:      	mov	x15, x11
    7d40:      	mov	w16, #0x1               ; =1
    7d44:      	mul	x10, x10, x14
    7d48:      	mul	x16, x16, x14
    7d4c:      	subs	x15, x15, #0x2
    7d50:      	b.ne	0x7d44 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x284>
    7d54:      	mul	x10, x16, x10
    7d58:      	mov	x15, x12
    7d5c:      	mul	x10, x10, x14
    7d60:      	subs	x15, x15, #0x1
    7d64:      	b.ne	0x7d5c <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x29c>
    7d68:      	add	x13, x13, #0x1
    7d6c:      	cmp	x13, x1
    7d70:      	b.ne	0x7d3c <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x27c>
    7d74:      	b	0x7bc4 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x104>
    7d78:      	mov	x13, #0x0               ; =0
    7d7c:      	mov	w14, #0x83              ; =131
    7d80:      	mov	x15, x11
    7d84:      	mov	w16, #0x1               ; =1
    7d88:      	mul	x10, x10, x14
    7d8c:      	mul	x16, x16, x14
    7d90:      	subs	x15, x15, #0x2
    7d94:      	b.ne	0x7d88 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x2c8>
    7d98:      	mul	x10, x16, x10
    7d9c:      	mov	x15, x12
    7da0:      	mul	x10, x10, x14
    7da4:      	subs	x15, x15, #0x1
    7da8:      	b.ne	0x7da0 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x2e0>
    7dac:      	add	x13, x13, #0x1
    7db0:      	cmp	x13, x1
    7db4:      	b.ne	0x7d80 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x2c0>
    7db8:      	b	0x7bc4 <_wf_chain_lookup_query$instance$4250cb78d3f44027+0x104>

0000000000007dbc <_wf_chain_lookup_finish$instance$4250cb78d3f44027>:
    7dbc:      	stp	x26, x25, [sp, #-0x50]!
    7dc0:      	stp	x24, x23, [sp, #0x10]
    7dc4:      	stp	x22, x21, [sp, #0x20]
    7dc8:      	stp	x20, x19, [sp, #0x30]
    7dcc:      	stp	x29, x30, [sp, #0x40]
    7dd0:      	mov	x8, x0
    7dd4:      	mov	x21, #0xe5b9            ; =58809
    7dd8:      	movk	x21, #0x1ce4, lsl #16
    7ddc:      	movk	x21, #0x476d, lsl #32
    7de0:      	movk	x21, #0xbf58, lsl #48
    7de4:      	mov	x20, #0x11eb            ; =4587
    7de8:      	movk	x20, #0x1331, lsl #16
    7dec:      	movk	x20, #0x49bb, lsl #32
    7df0:      	movk	x20, #0x94d0, lsl #48
    7df4:      	ldp	x10, x9, [x0, #0x18]
    7df8:      	ldr	x0, [x0, #0x28]
    7dfc:      	cbz	x10, 0x7f84 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x1c8>
    7e00:      	mov	x23, #0x0               ; =0
    7e04:      	mov	x22, #0x0               ; =0
    7e08:      	mov	w11, #0x110             ; =272
    7e0c:      	madd	x11, x10, x11, x0
    7e10:      	sub	x11, x11, #0x88
    7e14:      	mov	w12, #0x83              ; =131
    7e18:      	mov	x13, x10
    7e1c:      	ldp	x14, x15, [x11, #-0x88]
    7e20:      	madd	x14, x14, x12, x15
    7e24:      	ldp	x15, x16, [x11, #-0x78]
    7e28:      	madd	x14, x14, x12, x15
    7e2c:      	madd	x14, x14, x12, x16
    7e30:      	ldp	x15, x16, [x11, #-0x68]
    7e34:      	madd	x14, x14, x12, x15
    7e38:      	madd	x14, x14, x12, x16
    7e3c:      	ldp	x15, x16, [x11, #-0x58]
    7e40:      	madd	x14, x14, x12, x15
    7e44:      	madd	x14, x14, x12, x16
    7e48:      	ldp	x15, x16, [x11, #-0x48]
    7e4c:      	madd	x14, x14, x12, x15
    7e50:      	madd	x14, x14, x12, x16
    7e54:      	ldp	x15, x16, [x11, #-0x38]
    7e58:      	madd	x14, x14, x12, x15
    7e5c:      	madd	x14, x14, x12, x16
    7e60:      	ldp	x15, x16, [x11, #-0x28]
    7e64:      	madd	x14, x14, x12, x15
    7e68:      	madd	x14, x14, x12, x16
    7e6c:      	ldp	x15, x16, [x11, #-0x18]
    7e70:      	madd	x14, x14, x12, x15
    7e74:      	madd	x14, x14, x12, x16
    7e78:      	ldp	x15, x16, [x11, #-0x8]
    7e7c:      	madd	x14, x14, x12, x15
    7e80:      	madd	x14, x14, x12, x16
    7e84:      	ldp	x15, x16, [x11, #0x8]
    7e88:      	madd	x14, x14, x12, x15
    7e8c:      	madd	x14, x14, x12, x16
    7e90:      	ldp	x15, x16, [x11, #0x18]
    7e94:      	madd	x14, x14, x12, x15
    7e98:      	madd	x14, x14, x12, x16
    7e9c:      	ldp	x15, x16, [x11, #0x28]
    7ea0:      	madd	x14, x14, x12, x15
    7ea4:      	madd	x14, x14, x12, x16
    7ea8:      	ldp	x15, x16, [x11, #0x38]
    7eac:      	madd	x14, x14, x12, x15
    7eb0:      	madd	x14, x14, x12, x16
    7eb4:      	ldp	x15, x16, [x11, #0x48]
    7eb8:      	madd	x14, x14, x12, x15
    7ebc:      	madd	x14, x14, x12, x16
    7ec0:      	ldp	x15, x16, [x11, #0x58]
    7ec4:      	madd	x14, x14, x12, x15
    7ec8:      	madd	x14, x14, x12, x16
    7ecc:      	ldp	x15, x16, [x11, #0x68]
    7ed0:      	madd	x14, x14, x12, x15
    7ed4:      	madd	x14, x14, x12, x16
    7ed8:      	ldr	x15, [x11, #0x78]
    7edc:      	madd	x14, x14, x12, x15
    7ee0:      	add	x23, x14, x23
    7ee4:      	eor	x14, x14, x14, lsr #30
    7ee8:      	mul	x14, x14, x21
    7eec:      	eor	x14, x14, x14, lsr #27
    7ef0:      	mul	x14, x14, x20
    7ef4:      	eor	x15, x22, x14, lsr #31
    7ef8:      	eor	x22, x15, x14
    7efc:      	sub	x11, x11, #0x110
    7f00:      	sub	x13, x13, #0x1
    7f04:      	cbnz	x13, 0x7e1c <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x60>
    7f08:      	mov	x11, #0x7c15            ; =31765
    7f0c:      	movk	x11, #0x7f4a, lsl #16
    7f10:      	movk	x11, #0x79b9, lsl #32
    7f14:      	movk	x11, #0x9e37, lsl #48
    7f18:      	mul	x24, x10, x11
    7f1c:      	ldp	x26, x19, [x8, #0x8]
    7f20:      	ldr	x25, [x8, #0x40]
    7f24:      	cbz	x9, 0x7f2c <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x170>
    7f28:      	bl	0x7f28 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x16c>
		0000000000007f28:  ARM64_RELOC_BRANCH26	_free
    7f2c:      	cbz	x26, 0x7f38 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x17c>
    7f30:      	mov	x0, x19
    7f34:      	bl	0x7f34 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x178>
		0000000000007f34:  ARM64_RELOC_BRANCH26	_free
    7f38:      	eor	x8, x23, x23, lsr #30
    7f3c:      	mul	x8, x8, x21
    7f40:      	eor	x8, x8, x8, lsr #27
    7f44:      	mul	x8, x8, x20
    7f48:      	eor	x9, x25, x25, lsr #30
    7f4c:      	mul	x9, x9, x21
    7f50:      	eor	x9, x9, x9, lsr #27
    7f54:      	mul	x9, x9, x20
    7f58:      	eor	x10, x8, x9
    7f5c:      	eor	x11, x24, x22
    7f60:      	eor	x10, x11, x10, lsr #31
    7f64:      	eor	x8, x9, x8
    7f68:      	eor	x0, x10, x8
    7f6c:      	ldp	x29, x30, [sp, #0x40]
    7f70:      	ldp	x20, x19, [sp, #0x30]
    7f74:      	ldp	x22, x21, [sp, #0x20]
    7f78:      	ldp	x24, x23, [sp, #0x10]
    7f7c:      	ldp	x26, x25, [sp], #0x50
    7f80:      	ret
    7f84:      	mov	x24, #0x0               ; =0
    7f88:      	mov	x22, #0x0               ; =0
    7f8c:      	mov	x23, #0x0               ; =0
    7f90:      	ldp	x26, x19, [x8, #0x8]
    7f94:      	ldr	x25, [x8, #0x40]
    7f98:      	cbnz	x9, 0x7f28 <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x16c>
    7f9c:      	b	0x7f2c <_wf_chain_lookup_finish$instance$4250cb78d3f44027+0x170>

0000000000007fa0 <_wf_chain_lookup_geometry$instance$9fed7d4c5d7cc122>:
    7fa0:      	ldr	x8, [x0]
    7fa4:      	ldr	x9, [x0, #0x18]
    7fa8:      	add	x0, x9, x8, lsl #32
    7fac:      	ret

0000000000007fb0 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd>:
    7fb0:      	sub	sp, sp, #0x50
    7fb4:      	stp	x24, x23, [sp, #0x10]
    7fb8:      	stp	x22, x21, [sp, #0x20]
    7fbc:      	stp	x20, x19, [sp, #0x30]
    7fc0:      	stp	x29, x30, [sp, #0x40]
    7fc4:      	mov	x20, x3
    7fc8:      	mov	x19, x2
    7fcc:      	mov	x22, x1
    7fd0:      	mov	x21, x0
    7fd4:      	mov	x8, #0x7c15             ; =31765
    7fd8:      	movk	x8, #0x7f4a, lsl #16
    7fdc:      	movk	x8, #0x79b9, lsl #32
    7fe0:      	movk	x8, #0x9e37, lsl #48
    7fe4:      	eor	x23, x3, x8
    7fe8:      	strb	wzr, [sp, #0x8]
    7fec:      	cbz	x1, 0x8120 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x170>
    7ff0:      	add	x8, x22, x22, lsl #1
    7ff4:      	lsl	x0, x8, #3
    7ff8:      	bl	0x7ff8 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x48>
		0000000000007ff8:  ARM64_RELOC_BRANCH26	_malloc
    7ffc:      	cbz	x0, 0x816c <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x1bc>
    8000:      	mov	x8, #0x0                ; =0
    8004:      	add	x9, x0, #0x8
    8008:      	stur	wzr, [x9, #-0x8]
    800c:      	add	x8, x8, #0x1
    8010:      	stp	xzr, xzr, [x9], #0x18
    8014:      	cmp	x22, x8
    8018:      	b.ne	0x8008 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x58>
    801c:      	ldrb	w8, [sp, #0x8]
    8020:      	cbz	x19, 0x8134 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x184>
    8024:      	mov	x10, #0x0               ; =0
    8028:      	mov	x9, #0x0                ; =0
    802c:      	mov	w11, #0x1               ; =1
    8030:      	mov	w12, #0x18              ; =24
    8034:      	mov	w13, #0x2               ; =2
    8038:      	mov	x14, #0xe5b9            ; =58809
    803c:      	movk	x14, #0x1ce4, lsl #16
    8040:      	movk	x14, #0x476d, lsl #32
    8044:      	movk	x14, #0xbf58, lsl #48
    8048:      	mov	x15, #0x11eb            ; =4587
    804c:      	movk	x15, #0x1331, lsl #16
    8050:      	movk	x15, #0x49bb, lsl #32
    8054:      	movk	x15, #0x94d0, lsl #48
    8058:      	b	0x8070 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0xc0>
    805c:      	str	w13, [x4]
    8060:      	str	x17, [x4, #0x10]
    8064:      	add	x10, x10, #0x1
    8068:      	cmp	x10, x19
    806c:      	b.eq	0x8138 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x188>
    8070:      	orr	x16, x11, x10, lsl #1
    8074:      	tbz	w8, #0x0, 0x8080 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0xd0>
    8078:      	mov	x1, #0x0                ; =0
    807c:      	b	0x8098 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0xe8>
    8080:      	eor	x17, x16, x23
    8084:      	eor	x17, x17, x17, lsr #30
    8088:      	mul	x17, x17, x14
    808c:      	eor	x17, x17, x17, lsr #27
    8090:      	mul	x17, x17, x15
    8094:      	eor	x1, x17, x17, lsr #31
    8098:      	add	x17, x10, x20
    809c:      	udiv	x2, x1, x22
    80a0:      	msub	x2, x2, x22, x1
    80a4:      	mov	x3, x22
    80a8:      	mov	x1, x22
    80ac:      	b	0x80cc <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x11c>
    80b0:      	cmp	x1, x22
    80b4:      	csel	x1, x2, x1, eq
    80b8:      	add	x4, x2, #0x1
    80bc:      	cmp	x4, x22
    80c0:      	csinc	x2, xzr, x2, hs
    80c4:      	subs	x3, x3, #0x1
    80c8:      	b.eq	0x80fc <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x14c>
    80cc:      	madd	x4, x2, x12, x0
    80d0:      	ldr	w5, [x4]
    80d4:      	cmp	w5, #0x1
    80d8:      	b.eq	0x80b0 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x100>
    80dc:      	cmp	w5, #0x2
    80e0:      	b.ne	0x80f4 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x144>
    80e4:      	ldr	x5, [x4, #0x8]
    80e8:      	cmp	x5, x16
    80ec:      	b.ne	0x80b8 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x108>
    80f0:      	b	0x805c <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0xac>
    80f4:      	cmp	x1, x22
    80f8:      	csel	x1, x2, x1, eq
    80fc:      	cmp	x1, x22
    8100:      	b.hs	0x8064 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0xb4>
    8104:      	cmp	x9, #0x2, lsl #12       ; =0x2000
    8108:      	b.hs	0x8064 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0xb4>
    810c:      	madd	x1, x1, x12, x0
    8110:      	str	w13, [x1]
    8114:      	add	x9, x9, #0x1
    8118:      	stp	x16, x17, [x1, #0x8]
    811c:      	b	0x8064 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0xb4>
    8120:      	mov	x9, #0x0                ; =0
    8124:      	adrp	x0, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000008124:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    8128:      	add	x0, x0, #0x0
		0000000000008128:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    812c:      	ldrb	w8, [sp, #0x8]
    8130:      	b	0x8138 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x188>
    8134:      	mov	x9, #0x0                ; =0
    8138:      	stp	x23, xzr, [x21, #0x28]
    813c:      	stp	x22, x22, [x21]
    8140:      	stp	x0, x9, [x21, #0x10]
    8144:      	str	xzr, [x21, #0x20]
    8148:      	strb	w8, [x21, #0x30]
    814c:      	stp	x20, x19, [x21, #0x38]
    8150:      	str	xzr, [x21, #0x48]
    8154:      	ldp	x29, x30, [sp, #0x40]
    8158:      	ldp	x20, x19, [sp, #0x30]
    815c:      	ldp	x22, x21, [sp, #0x20]
    8160:      	ldp	x24, x23, [sp, #0x10]
    8164:      	add	sp, sp, #0x50
    8168:      	ret
    816c:      	bl	0x816c <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x1bc>
		000000000000816c:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

0000000000008170 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd>:
    8170:      	mov	x9, #0xe5b9             ; =58809
    8174:      	movk	x9, #0x1ce4, lsl #16
    8178:      	movk	x9, #0x476d, lsl #32
    817c:      	movk	x9, #0xbf58, lsl #48
    8180:      	mov	x8, #0x11eb             ; =4587
    8184:      	movk	x8, #0x1331, lsl #16
    8188:      	movk	x8, #0x49bb, lsl #32
    818c:      	movk	x8, #0x94d0, lsl #48
    8190:      	ldr	x10, [x0, #0x38]
    8194:      	cbz	x1, 0x846c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2fc>
    8198:      	ldp	x12, x11, [x0, #0x40]
    819c:      	cbz	x12, 0x8464 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2f4>
    81a0:      	sub	sp, sp, #0x70
    81a4:      	stp	x28, x27, [sp, #0x10]
    81a8:      	stp	x26, x25, [sp, #0x20]
    81ac:      	stp	x24, x23, [sp, #0x30]
    81b0:      	stp	x22, x21, [sp, #0x40]
    81b4:      	stp	x20, x19, [sp, #0x50]
    81b8:      	stp	x29, x30, [sp, #0x60]
    81bc:      	mov	x13, #0x0               ; =0
    81c0:      	ldp	x19, x14, [x0, #0x20]
    81c4:      	ldrb	w15, [x0, #0x30]
    81c8:      	mov	w16, #0x1               ; =1
    81cc:      	mov	w17, #0x18              ; =24
    81d0:      	mov	w3, #0x2                ; =2
    81d4:      	mov	w4, #0x83               ; =131
    81d8:      	mov	x6, x10
    81dc:      	ldr	x7, [x0, #0x18]
    81e0:      	b	0x81f4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x84>
    81e4:      	str	x11, [x0, #0x48]
    81e8:      	add	x13, x13, #0x1
    81ec:      	cmp	x13, x1
    81f0:      	b.eq	0x8430 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2c0>
    81f4:      	mov	x20, #0x0               ; =0
    81f8:      	add	x11, x11, #0x1
    81fc:      	madd	x21, x11, x12, x10
    8200:      	b	0x8228 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xb8>
    8204:      	strb	w16, [sp, #0xc]
    8208:      	tst	w16, #0x1
    820c:      	cinc	x24, x16, ne
    8210:      	madd	x5, x6, x4, x22
    8214:      	add	x5, x5, x24
    8218:      	madd	x6, x5, x4, x23
    821c:      	add	x20, x20, #0x1
    8220:      	cmp	x20, x12
    8224:      	b.eq	0x81e4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x74>
    8228:      	orr	x22, x16, x20, lsl #1
    822c:      	cbz	x2, 0x82e4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x174>
    8230:      	cbz	x7, 0x836c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
    8234:      	tbz	w15, #0x0, 0x8248 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xd8>
    8238:      	mov	x24, #0x0               ; =0
    823c:      	ldr	x23, [x0]
    8240:      	cbnz	x23, 0x8268 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xf8>
    8244:      	b	0x836c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
    8248:      	eor	x5, x14, x22
    824c:      	eor	x5, x5, x5, lsr #30
    8250:      	mul	x5, x5, x9
    8254:      	eor	x5, x5, x5, lsr #27
    8258:      	mul	x5, x5, x8
    825c:      	eor	x24, x5, x5, lsr #31
    8260:      	ldr	x23, [x0]
    8264:      	cbz	x23, 0x836c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
    8268:      	udiv	x5, x24, x23
    826c:      	msub	x24, x5, x23, x24
    8270:      	ldr	x25, [x0, #0x10]
    8274:      	mov	x26, x23
    8278:      	b	0x8290 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x120>
    827c:      	add	x5, x24, #0x1
    8280:      	cmp	x5, x23
    8284:      	csinc	x24, xzr, x24, hs
    8288:      	subs	x26, x26, #0x1
    828c:      	b.eq	0x836c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
    8290:      	madd	x27, x24, x17, x25
    8294:      	ldr	w28, [x27]
    8298:      	cmp	w28, #0x1
    829c:      	b.eq	0x827c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x10c>
    82a0:      	cmp	w28, #0x2
    82a4:      	b.ne	0x836c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
    82a8:      	ldr	x5, [x27, #0x8]
    82ac:      	cmp	x5, x22
    82b0:      	b.ne	0x827c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x10c>
    82b4:      	ldr	x5, [x27, #0x10]
    82b8:      	str	w16, [x27]
    82bc:      	sub	x7, x7, #0x1
    82c0:      	stp	xzr, xzr, [x27, #0x8]
    82c4:      	adds	x19, x19, #0x1
    82c8:      	csinv	x19, x19, xzr, lo
    82cc:      	stp	x7, x19, [x0, #0x18]
    82d0:      	mul	x23, x22, x4
    82d4:      	mov	w24, #0x4309            ; =17161
    82d8:      	madd	x6, x6, x24, x23
    82dc:      	add	x5, x6, x5
    82e0:      	add	x6, x5, #0x83
    82e4:      	tbz	w15, #0x0, 0x8374 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x204>
    82e8:      	mov	x25, #0x0               ; =0
    82ec:      	add	x23, x21, x20
    82f0:      	ldr	x24, [x0]
    82f4:      	cbz	x24, 0x8398 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x228>
    82f8:      	udiv	x5, x25, x24
    82fc:      	msub	x26, x5, x24, x25
    8300:      	ldr	x27, [x0, #0x10]
    8304:      	mov	x28, x24
    8308:      	mov	x25, x24
    830c:      	b	0x832c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1bc>
    8310:      	cmp	x25, x24
    8314:      	csel	x25, x26, x25, eq
    8318:      	add	x5, x26, #0x1
    831c:      	cmp	x5, x24
    8320:      	csinc	x26, xzr, x26, hs
    8324:      	subs	x28, x28, #0x1
    8328:      	b.eq	0x839c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x22c>
    832c:      	madd	x30, x26, x17, x27
    8330:      	ldr	w5, [x30]
    8334:      	cmp	w5, #0x1
    8338:      	b.eq	0x8310 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1a0>
    833c:      	cmp	w5, #0x2
    8340:      	b.ne	0x841c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2ac>
    8344:      	ldr	x5, [x30, #0x8]
    8348:      	cmp	x5, x22
    834c:      	b.ne	0x8318 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1a8>
    8350:      	ldr	x5, [x30, #0x10]
    8354:      	str	w3, [x30]
    8358:      	str	x23, [x30, #0x10]
    835c:      	strb	wzr, [sp, #0xc]
    8360:      	mov	w24, #0x1               ; =1
    8364:      	mov	x23, x5
    8368:      	b	0x8210 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xa0>
    836c:      	mul	x6, x6, x4
    8370:      	tbnz	w15, #0x0, 0x82e8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x178>
    8374:      	eor	x5, x14, x22
    8378:      	eor	x5, x5, x5, lsr #30
    837c:      	mul	x5, x5, x9
    8380:      	eor	x5, x5, x5, lsr #27
    8384:      	mul	x5, x5, x8
    8388:      	eor	x25, x5, x5, lsr #31
    838c:      	add	x23, x21, x20
    8390:      	ldr	x24, [x0]
    8394:      	cbnz	x24, 0x82f8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x188>
    8398:      	mov	x25, #0x0               ; =0
    839c:      	cmp	x25, x24
    83a0:      	b.hs	0x8204 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
    83a4:      	cmp	x7, #0x2, lsl #12       ; =0x2000
    83a8:      	b.hs	0x8204 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
    83ac:      	add	x7, x7, #0x1
    83b0:      	str	x7, [x0, #0x18]
    83b4:      	ldr	x5, [x0, #0x10]
    83b8:      	madd	x24, x25, x17, x5
    83bc:      	ldr	w27, [x24]
    83c0:      	cmp	w27, #0x1
    83c4:      	b.ne	0x83e0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x270>
    83c8:      	subs	x5, x19, #0x1
    83cc:      	csel	x19, xzr, x5, lo
    83d0:      	str	x19, [x0, #0x20]
    83d4:      	str	w3, [x24]
    83d8:      	stp	x22, x23, [x24, #0x8]
    83dc:      	b	0x8404 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x294>
    83e0:      	ldp	x25, x26, [x24, #0x8]
    83e4:      	str	w3, [x24]
    83e8:      	stp	x22, x23, [x24, #0x8]
    83ec:      	cbz	w27, 0x8404 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x294>
    83f0:      	strb	wzr, [sp, #0xc]
    83f4:      	mov	w24, #0x1               ; =1
    83f8:      	mov	x23, x26
    83fc:      	mov	x22, x25
    8400:      	b	0x8210 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xa0>
    8404:      	strb	wzr, [sp, #0xc]
    8408:      	mul	x6, x6, x4
    840c:      	add	x20, x20, #0x1
    8410:      	cmp	x20, x12
    8414:      	b.ne	0x8228 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xb8>
    8418:      	b	0x81e4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x74>
    841c:      	cmp	x25, x24
    8420:      	csel	x25, x26, x25, eq
    8424:      	cmp	x25, x24
    8428:      	b.lo	0x83a4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x234>
    842c:      	b	0x8204 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
    8430:      	ldp	x29, x30, [sp, #0x60]
    8434:      	ldp	x20, x19, [sp, #0x50]
    8438:      	ldp	x22, x21, [sp, #0x40]
    843c:      	ldp	x24, x23, [sp, #0x30]
    8440:      	ldp	x26, x25, [sp, #0x20]
    8444:      	ldp	x28, x27, [sp, #0x10]
    8448:      	add	sp, sp, #0x70
    844c:      	eor	x10, x6, x6, lsr #30
    8450:      	mul	x9, x10, x9
    8454:      	eor	x9, x9, x9, lsr #27
    8458:      	mul	x8, x9, x8
    845c:      	eor	x0, x8, x8, lsr #31
    8460:      	ret
    8464:      	add	x11, x11, x1
    8468:      	str	x11, [x0, #0x48]
    846c:      	eor	x10, x10, x10, lsr #30
    8470:      	mul	x9, x10, x9
    8474:      	eor	x9, x9, x9, lsr #27
    8478:      	mul	x8, x9, x8
    847c:      	eor	x0, x8, x8, lsr #31
    8480:      	ret

0000000000008484 <_wf_flat_mutation_geometry$instance$e194368921a477a7>:
    8484:      	ldr	x8, [x0]
    8488:      	ldr	x9, [x0, #0x18]
    848c:      	add	x0, x9, x8, lsl #32
    8490:      	ret

0000000000008494 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd>:
    8494:      	mov	x9, #0xe5b9             ; =58809
    8498:      	movk	x9, #0x1ce4, lsl #16
    849c:      	movk	x9, #0x476d, lsl #32
    84a0:      	movk	x9, #0xbf58, lsl #48
    84a4:      	mov	x8, #0x11eb             ; =4587
    84a8:      	movk	x8, #0x1331, lsl #16
    84ac:      	movk	x8, #0x49bb, lsl #32
    84b0:      	movk	x8, #0x94d0, lsl #48
    84b4:      	ldp	x1, x10, [x0, #0x38]
    84b8:      	cbz	x10, 0x8620 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x18c>
    84bc:      	mov	x11, #0x0               ; =0
    84c0:      	ldr	x12, [x0, #0x28]
    84c4:      	ldrb	w13, [x0, #0x30]
    84c8:      	mov	w14, #0x83              ; =131
    84cc:      	mov	w15, #0x18              ; =24
    84d0:      	mov	w16, #0x4309            ; =17161
    84d4:      	ldr	x17, [x0]
    84d8:      	b	0x84ec <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x58>
    84dc:      	mul	x1, x1, x14
    84e0:      	add	x11, x11, #0x1
    84e4:      	cmp	x11, x10
    84e8:      	b.eq	0x8620 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x18c>
    84ec:      	mov	w2, #0x1                ; =1
    84f0:      	bfi	x2, x11, #1, #63
    84f4:      	tbz	w13, #0x0, 0x8504 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x70>
    84f8:      	mov	x3, #0x0                ; =0
    84fc:      	cbnz	x17, 0x8520 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x8c>
    8500:      	b	0x85a4 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x110>
    8504:      	eor	x3, x12, x2
    8508:      	eor	x3, x3, x3, lsr #30
    850c:      	mul	x3, x3, x9
    8510:      	eor	x3, x3, x3, lsr #27
    8514:      	mul	x3, x3, x8
    8518:      	eor	x3, x3, x3, lsr #31
    851c:      	cbz	x17, 0x85a4 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x110>
    8520:      	udiv	x4, x3, x17
    8524:      	msub	x3, x4, x17, x3
    8528:      	ldr	x4, [x0, #0x10]
    852c:      	mov	x5, x17
    8530:      	b	0x8548 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0xb4>
    8534:      	add	x6, x3, #0x1
    8538:      	cmp	x6, x17
    853c:      	csinc	x3, xzr, x3, hs
    8540:      	subs	x5, x5, #0x1
    8544:      	b.eq	0x85a4 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x110>
    8548:      	madd	x6, x3, x15, x4
    854c:      	ldr	w7, [x6]
    8550:      	cmp	w7, #0x1
    8554:      	b.eq	0x8534 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0xa0>
    8558:      	cmp	w7, #0x2
    855c:      	b.ne	0x85a4 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x110>
    8560:      	ldr	x7, [x6, #0x8]
    8564:      	cmp	x7, x2
    8568:      	b.ne	0x8534 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0xa0>
    856c:      	ldr	x2, [x6, #0x10]
    8570:      	madd	x1, x1, x16, x2
    8574:      	add	x1, x1, #0x83
    8578:      	lsl	x2, x11, #1
    857c:      	add	x2, x2, #0x2
    8580:      	tbnz	w13, #0x0, 0x85b4 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x120>
    8584:      	eor	x3, x12, x2
    8588:      	eor	x3, x3, x3, lsr #30
    858c:      	mul	x3, x3, x9
    8590:      	eor	x3, x3, x3, lsr #27
    8594:      	mul	x3, x3, x8
    8598:      	eor	x3, x3, x3, lsr #31
    859c:      	cbnz	x17, 0x85bc <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x128>
    85a0:      	b	0x84dc <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x48>
    85a4:      	mul	x1, x1, x14
    85a8:      	lsl	x2, x11, #1
    85ac:      	add	x2, x2, #0x2
    85b0:      	tbz	w13, #0x0, 0x8584 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0xf0>
    85b4:      	mov	x3, #0x0                ; =0
    85b8:      	cbz	x17, 0x84dc <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x48>
    85bc:      	udiv	x4, x3, x17
    85c0:      	msub	x3, x4, x17, x3
    85c4:      	ldr	x4, [x0, #0x10]
    85c8:      	mov	x5, x17
    85cc:      	b	0x85e4 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x150>
    85d0:      	add	x6, x3, #0x1
    85d4:      	cmp	x6, x17
    85d8:      	csinc	x3, xzr, x3, hs
    85dc:      	subs	x5, x5, #0x1
    85e0:      	b.eq	0x84dc <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x48>
    85e4:      	madd	x6, x3, x15, x4
    85e8:      	ldr	w7, [x6]
    85ec:      	cmp	w7, #0x1
    85f0:      	b.eq	0x85d0 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x13c>
    85f4:      	cmp	w7, #0x2
    85f8:      	b.ne	0x84dc <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x48>
    85fc:      	ldr	x7, [x6, #0x8]
    8600:      	cmp	x7, x2
    8604:      	b.ne	0x85d0 <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x13c>
    8608:      	ldr	x2, [x6, #0x10]
    860c:      	madd	x1, x1, x16, x2
    8610:      	add	x1, x1, #0x83
    8614:      	add	x11, x11, #0x1
    8618:      	cmp	x11, x10
    861c:      	b.ne	0x84ec <_wf_flat_mutation_verify$instance$c7c8cd11e7f079bd+0x58>
    8620:      	eor	x10, x1, x1, lsr #30
    8624:      	mul	x9, x10, x9
    8628:      	eor	x9, x9, x9, lsr #27
    862c:      	mul	x8, x9, x8
    8630:      	eor	x0, x8, x8, lsr #31
    8634:      	ret

0000000000008638 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd>:
    8638:      	stp	x24, x23, [sp, #-0x40]!
    863c:      	stp	x22, x21, [sp, #0x10]
    8640:      	stp	x20, x19, [sp, #0x20]
    8644:      	stp	x29, x30, [sp, #0x30]
    8648:      	mov	x8, x0
    864c:      	mov	x20, #0xe5b9            ; =58809
    8650:      	movk	x20, #0x1ce4, lsl #16
    8654:      	movk	x20, #0x476d, lsl #32
    8658:      	movk	x20, #0xbf58, lsl #48
    865c:      	mov	x19, #0x11eb            ; =4587
    8660:      	movk	x19, #0x1331, lsl #16
    8664:      	movk	x19, #0x49bb, lsl #32
    8668:      	movk	x19, #0x94d0, lsl #48
    866c:      	ldp	x12, x9, [x0]
    8670:      	ldr	x0, [x0, #0x10]
    8674:      	cbz	x12, 0x8754 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x11c>
    8678:      	and	x10, x12, #0x3
    867c:      	cmp	x12, #0x4
    8680:      	b.hs	0x876c <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x134>
    8684:      	mov	x11, #0x0               ; =0
    8688:      	mov	x21, #0x0               ; =0
    868c:      	mov	x22, #0x0               ; =0
    8690:      	cbz	x10, 0x86ec <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0xb4>
    8694:      	mov	w13, #0x18              ; =24
    8698:      	madd	x12, x12, x13, x0
    869c:      	sub	x12, x12, #0x8
    86a0:      	mov	w13, #0x83              ; =131
    86a4:      	b	0x86b4 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x7c>
    86a8:      	sub	x12, x12, #0x18
    86ac:      	subs	x10, x10, #0x1
    86b0:      	b.eq	0x86ec <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0xb4>
    86b4:      	ldur	w14, [x12, #-0x10]
    86b8:      	cmp	w14, #0x2
    86bc:      	b.ne	0x86a8 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x70>
    86c0:      	ldp	x15, x14, [x12, #-0x8]
    86c4:      	madd	x14, x15, x13, x14
    86c8:      	add	x22, x14, x22
    86cc:      	eor	x14, x14, x14, lsr #30
    86d0:      	mul	x14, x14, x20
    86d4:      	eor	x14, x14, x14, lsr #27
    86d8:      	mul	x14, x14, x19
    86dc:      	eor	x15, x21, x14, lsr #31
    86e0:      	eor	x21, x15, x14
    86e4:      	add	x11, x11, #0x1
    86e8:      	b	0x86a8 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x70>
    86ec:      	mov	x10, #0x7c15            ; =31765
    86f0:      	movk	x10, #0x7f4a, lsl #16
    86f4:      	movk	x10, #0x79b9, lsl #32
    86f8:      	movk	x10, #0x9e37, lsl #48
    86fc:      	mul	x23, x11, x10
    8700:      	ldr	x24, [x8, #0x38]
    8704:      	cbz	x9, 0x870c <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0xd4>
    8708:      	bl	0x8708 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0xd0>
		0000000000008708:  ARM64_RELOC_BRANCH26	_free
    870c:      	eor	x8, x24, x24, lsr #30
    8710:      	mul	x8, x8, x20
    8714:      	eor	x8, x8, x8, lsr #27
    8718:      	mul	x8, x8, x19
    871c:      	eor	x9, x22, x22, lsr #30
    8720:      	mul	x9, x9, x20
    8724:      	eor	x9, x9, x9, lsr #27
    8728:      	mul	x9, x9, x19
    872c:      	eor	x10, x9, x8
    8730:      	eor	x11, x23, x21
    8734:      	eor	x10, x11, x10, lsr #31
    8738:      	eor	x8, x8, x9
    873c:      	eor	x0, x10, x8
    8740:      	ldp	x29, x30, [sp, #0x30]
    8744:      	ldp	x20, x19, [sp, #0x20]
    8748:      	ldp	x22, x21, [sp, #0x10]
    874c:      	ldp	x24, x23, [sp], #0x40
    8750:      	ret
    8754:      	mov	x23, #0x0               ; =0
    8758:      	mov	x21, #0x0               ; =0
    875c:      	mov	x22, #0x0               ; =0
    8760:      	ldr	x24, [x8, #0x38]
    8764:      	cbnz	x9, 0x8708 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0xd0>
    8768:      	b	0x870c <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0xd4>
    876c:      	mov	x11, #0x0               ; =0
    8770:      	mov	x21, #0x0               ; =0
    8774:      	mov	x22, #0x0               ; =0
    8778:      	and	x13, x12, #0xfffffffffffffffc
    877c:      	mov	w14, #0x18              ; =24
    8780:      	madd	x14, x12, x14, x0
    8784:      	sub	x14, x14, #0x30
    8788:      	mov	w15, #0x83              ; =131
    878c:      	b	0x87a0 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x168>
    8790:      	sub	x14, x14, #0x60
    8794:      	sub	x12, x12, #0x4
    8798:      	sub	x13, x13, #0x4
    879c:      	cbz	x13, 0x8690 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x58>
    87a0:      	ldr	w16, [x14, #0x18]
    87a4:      	cmp	w16, #0x2
    87a8:      	b.eq	0x87d4 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x19c>
    87ac:      	ldr	w16, [x14]
    87b0:      	cmp	w16, #0x2
    87b4:      	b.eq	0x8808 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x1d0>
    87b8:      	ldur	w16, [x14, #-0x18]
    87bc:      	cmp	w16, #0x2
    87c0:      	b.eq	0x883c <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x204>
    87c4:      	ldur	w16, [x14, #-0x30]
    87c8:      	cmp	w16, #0x2
    87cc:      	b.ne	0x8790 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x158>
    87d0:      	b	0x8870 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x238>
    87d4:      	ldp	x17, x16, [x14, #0x20]
    87d8:      	madd	x16, x17, x15, x16
    87dc:      	add	x22, x16, x22
    87e0:      	eor	x16, x16, x16, lsr #30
    87e4:      	mul	x16, x16, x20
    87e8:      	eor	x16, x16, x16, lsr #27
    87ec:      	mul	x16, x16, x19
    87f0:      	eor	x17, x21, x16, lsr #31
    87f4:      	eor	x21, x17, x16
    87f8:      	add	x11, x11, #0x1
    87fc:      	ldr	w16, [x14]
    8800:      	cmp	w16, #0x2
    8804:      	b.ne	0x87b8 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x180>
    8808:      	ldp	x17, x16, [x14, #0x8]
    880c:      	madd	x16, x17, x15, x16
    8810:      	add	x22, x16, x22
    8814:      	eor	x16, x16, x16, lsr #30
    8818:      	mul	x16, x16, x20
    881c:      	eor	x16, x16, x16, lsr #27
    8820:      	mul	x16, x16, x19
    8824:      	eor	x17, x21, x16, lsr #31
    8828:      	eor	x21, x17, x16
    882c:      	add	x11, x11, #0x1
    8830:      	ldur	w16, [x14, #-0x18]
    8834:      	cmp	w16, #0x2
    8838:      	b.ne	0x87c4 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x18c>
    883c:      	ldp	x17, x16, [x14, #-0x10]
    8840:      	madd	x16, x17, x15, x16
    8844:      	add	x22, x16, x22
    8848:      	eor	x16, x16, x16, lsr #30
    884c:      	mul	x16, x16, x20
    8850:      	eor	x16, x16, x16, lsr #27
    8854:      	mul	x16, x16, x19
    8858:      	eor	x17, x21, x16, lsr #31
    885c:      	eor	x21, x17, x16
    8860:      	add	x11, x11, #0x1
    8864:      	ldur	w16, [x14, #-0x30]
    8868:      	cmp	w16, #0x2
    886c:      	b.ne	0x8790 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x158>
    8870:      	ldp	x17, x16, [x14, #-0x28]
    8874:      	madd	x16, x17, x15, x16
    8878:      	add	x22, x16, x22
    887c:      	eor	x16, x16, x16, lsr #30
    8880:      	mul	x16, x16, x20
    8884:      	eor	x16, x16, x16, lsr #27
    8888:      	mul	x16, x16, x19
    888c:      	eor	x17, x21, x16, lsr #31
    8890:      	eor	x21, x17, x16
    8894:      	add	x11, x11, #0x1
    8898:      	b	0x8790 <_wf_flat_mutation_finish$instance$c7c8cd11e7f079bd+0x158>

000000000000889c <_wf_flat_mutation_prepare$instance$4250cb78d3f44027>:
    889c:      	stp	x26, x25, [sp, #-0x50]!
    88a0:      	stp	x24, x23, [sp, #0x10]
    88a4:      	stp	x22, x21, [sp, #0x20]
    88a8:      	stp	x20, x19, [sp, #0x30]
    88ac:      	stp	x29, x30, [sp, #0x40]
    88b0:      	sub	sp, sp, #0x340
    88b4:      	mov	x21, x3
    88b8:      	mov	x20, x2
    88bc:      	mov	x22, x1
    88c0:      	mov	x19, x0
    88c4:      	mov	x8, #0x7c15             ; =31765
    88c8:      	movk	x8, #0x7f4a, lsl #16
    88cc:      	movk	x8, #0x79b9, lsl #32
    88d0:      	movk	x8, #0x9e37, lsl #48
    88d4:      	eor	x8, x3, x8
    88d8:      	str	x8, [sp, #0x120]
    88dc:      	strb	wzr, [sp, #0x128]
    88e0:      	cbz	x1, 0x894c <_wf_flat_mutation_prepare$instance$4250cb78d3f44027+0xb0>
    88e4:      	add	x8, x22, x22, lsl #4
    88e8:      	lsl	x0, x8, #4
    88ec:      	bl	0x88ec <_wf_flat_mutation_prepare$instance$4250cb78d3f44027+0x50>
		00000000000088ec:  ARM64_RELOC_BRANCH26	_malloc
    88f0:      	cbz	x0, 0x8b58 <_wf_flat_mutation_prepare$instance$4250cb78d3f44027+0x2bc>
    88f4:      	mov	x8, #0x0                ; =0
    88f8:      	add	x9, x0, #0x8
    88fc:      	movi.2d	v0, #0000000000000000
    8900:      	stur	wzr, [x9, #-0x8]
    8904:      	add	x8, x8, #0x1
    8908:      	stp	q0, q0, [x9]
    890c:      	stp	q0, q0, [x9, #0x20]
    8910:      	stp	q0, q0, [x9, #0x40]
    8914:      	stp	q0, q0, [x9, #0x60]
    8918:      	stp	q0, q0, [x9, #0x80]
    891c:      	stp	q0, q0, [x9, #0xa0]
    8920:      	stp	q0, q0, [x9, #0xc0]
    8924:      	stp	q0, q0, [x9, #0xe0]
    8928:      	str	xzr, [x9, #0x100]
    892c:      	add	x9, x9, #0x110
    8930:      	cmp	x22, x8
    8934:      	b.ne	0x8900 <_wf_flat_mutation_prepare$instance$4250cb78d3f44027+0x64>
    8938:      	stp	x22, x22, [sp, #0xf8]
    893c:      	stp	xzr, xzr, [sp, #0x110]
    8940:      	str	x0, [sp, #0x108]
    8944:      	cbnz	x20, 0x8964 <_wf_flat_mutation_prepare$instance$4250cb78d3f44027+0xc8>
    8948:      	b	0x8b14 <_wf_flat_mutation_prepare$instance$4250cb78d3f44027+0x278>
    894c:      	adrp	x0, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		000000000000894c:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    8950:      	add	x0, x0, #0x0
		0000000000008950:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    8954:      	stp	x22, x22, [sp, #0xf8]
    8958:      	stp	xzr, xzr, [sp, #0x110]
    895c:      	str	x0, [sp, #0x108]
    8960:      	cbz	x20, 0x8b14 <_wf_flat_mutation_prepare$instance$4250cb78d3f44027+0x278>
    8964:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000008964:  ARM64_RELOC_PAGE21	lCPI93_0
    8968:      	ldr	q0, [x8]
		0000000000008968:  ARM64_RELOC_PAGEOFF12	lCPI93_0
    896c:      	str	q0, [sp, #0xe0]
    8970:      	add	x23, sp, #0x240
    8974:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000008974:  ARM64_RELOC_PAGE21	lCPI93_1
    8978:      	ldr	q0, [x8]
		0000000000008978:  ARM64_RELOC_PAGEOFF12	lCPI93_1
    897c:      	str	q0, [sp, #0xd0]
    8980:      	mov	w22, #0x1               ; =1
    8984:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000008984:  ARM64_RELOC_PAGE21	lCPI93_2
    8988:      	ldr	q0, [x8]
		0000000000008988:  ARM64_RELOC_PAGEOFF12	lCPI93_2
    898c:      	str	q0, [sp, #0xc0]
    8990:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000008990:  ARM64_RELOC_PAGE21	lCPI93_3
    8994:      	ldr	q0, [x8]
		0000000000008994:  ARM64_RELOC_PAGEOFF12	lCPI93_3
    8998:      	str	q0, [sp, #0xb0]
    899c:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		000000000000899c:  ARM64_RELOC_PAGE21	lCPI93_4
    89a0:      	ldr	q0, [x8]
		00000000000089a0:  ARM64_RELOC_PAGEOFF12	lCPI93_4
    89a4:      	str	q0, [sp, #0xa0]
    89a8:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		00000000000089a8:  ARM64_RELOC_PAGE21	lCPI93_5
    89ac:      	ldr	q0, [x8]
		00000000000089ac:  ARM64_RELOC_PAGEOFF12	lCPI93_5
    89b0:      	str	q0, [sp, #0x90]
    89b4:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		00000000000089b4:  ARM64_RELOC_PAGE21	lCPI93_6
    89b8:      	ldr	q0, [x8]
		00000000000089b8:  ARM64_RELOC_PAGEOFF12	lCPI93_6
    89bc:      	str	q0, [sp, #0x80]
    89c0:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		00000000000089c0:  ARM64_RELOC_PAGE21	lCPI93_7
    89c4:      	ldr	q0, [x8]
		00000000000089c4:  ARM64_RELOC_PAGEOFF12	lCPI93_7
    89c8:      	str	q0, [sp, #0x70]
    89cc:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		00000000000089cc:  ARM64_RELOC_PAGE21	lCPI93_8
    89d0:      	ldr	q0, [x8]
		00000000000089d0:  ARM64_RELOC_PAGEOFF12	lCPI93_8
    89d4:      	str	q0, [sp, #0x60]
    89d8:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		00000000000089d8:  ARM64_RELOC_PAGE21	lCPI93_9
    89dc:      	ldr	q0, [x8]
		00000000000089dc:  ARM64_RELOC_PAGEOFF12	lCPI93_9
    89e0:      	str	q0, [sp, #0x50]
    89e4:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		00000000000089e4:  ARM64_RELOC_PAGE21	lCPI93_10
    89e8:      	ldr	q0, [x8]
		00000000000089e8:  ARM64_RELOC_PAGEOFF12	lCPI93_10
    89ec:      	str	q0, [sp, #0x40]
    89f0:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		00000000000089f0:  ARM64_RELOC_PAGE21	lCPI93_11
    89f4:      	ldr	q0, [x8]
		00000000000089f4:  ARM64_RELOC_PAGEOFF12	lCPI93_11
    89f8:      	str	q0, [sp, #0x30]
    89fc:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		00000000000089fc:  ARM64_RELOC_PAGE21	lCPI93_12
    8a00:      	ldr	q0, [x8]
		0000000000008a00:  ARM64_RELOC_PAGEOFF12	lCPI93_12
    8a04:      	str	q0, [sp, #0x20]
    8a08:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000008a08:  ARM64_RELOC_PAGE21	lCPI93_13
    8a0c:      	ldr	q0, [x8]
		0000000000008a0c:  ARM64_RELOC_PAGEOFF12	lCPI93_13
    8a10:      	str	q0, [sp, #0x10]
    8a14:      	mov	x24, x20
    8a18:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000008a18:  ARM64_RELOC_PAGE21	lCPI93_14
    8a1c:      	ldr	q0, [x8]
		0000000000008a1c:  ARM64_RELOC_PAGEOFF12	lCPI93_14
    8a20:      	str	q0, [sp]
    8a24:      	mov	x25, x21
    8a28:      	dup.2d	v0, x25
    8a2c:      	add	x8, x25, #0x1f
    8a30:      	ldr	q1, [sp, #0xe0]
    8a34:      	add.2d	v1, v0, v1
    8a38:      	stur	q1, [x23, #0x8]
    8a3c:      	ldr	q1, [sp, #0xd0]
    8a40:      	add.2d	v1, v0, v1
    8a44:      	stur	q1, [x23, #0x18]
    8a48:      	ldr	q1, [sp, #0xc0]
    8a4c:      	add.2d	v1, v0, v1
    8a50:      	stur	q1, [x23, #0x28]
    8a54:      	ldr	q1, [sp, #0xb0]
    8a58:      	add.2d	v1, v0, v1
    8a5c:      	stur	q1, [x23, #0x38]
    8a60:      	ldr	q1, [sp, #0xa0]
    8a64:      	add.2d	v1, v0, v1
    8a68:      	stur	q1, [x23, #0x48]
    8a6c:      	ldr	q1, [sp, #0x90]
    8a70:      	add.2d	v1, v0, v1
    8a74:      	stur	q1, [x23, #0x58]
    8a78:      	ldr	q1, [sp, #0x80]
    8a7c:      	add.2d	v1, v0, v1
    8a80:      	stur	q1, [x23, #0x68]
    8a84:      	ldr	q1, [sp, #0x70]
    8a88:      	add.2d	v1, v0, v1
    8a8c:      	stur	q1, [x23, #0x78]
    8a90:      	ldr	q1, [sp, #0x60]
    8a94:      	add.2d	v1, v0, v1
    8a98:      	stur	q1, [x23, #0x88]
    8a9c:      	ldr	q1, [sp, #0x50]
    8aa0:      	add.2d	v1, v0, v1
    8aa4:      	stur	q1, [x23, #0x98]
    8aa8:      	ldr	q1, [sp, #0x40]
    8aac:      	add.2d	v1, v0, v1
    8ab0:      	stur	q1, [x23, #0xa8]
    8ab4:      	ldr	q1, [sp, #0x30]
    8ab8:      	add.2d	v1, v0, v1
    8abc:      	stur	q1, [x23, #0xb8]
    8ac0:      	ldr	q1, [sp, #0x20]
    8ac4:      	add.2d	v1, v0, v1
    8ac8:      	stur	q1, [x23, #0xc8]
    8acc:      	ldr	q1, [sp, #0x10]
    8ad0:      	add.2d	v1, v0, v1
    8ad4:      	stur	q1, [x23, #0xd8]
    8ad8:      	ldr	q1, [sp]
    8adc:      	add.2d	v0, v0, v1
    8ae0:      	stur	q0, [x23, #0xe8]
    8ae4:      	str	x25, [sp, #0x240]
    8ae8:      	str	x8, [sp, #0x338]
    8aec:      	add	x0, sp, #0x130
    8af0:      	add	x1, sp, #0xf8
    8af4:      	add	x3, sp, #0x240
    8af8:      	add	x4, sp, #0x120
    8afc:      	mov	x2, x22
    8b00:      	bl	0x8b00 <_wf_flat_mutation_prepare$instance$4250cb78d3f44027+0x264>
		0000000000008b00:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d
    8b04:      	add	x25, x25, #0x1
    8b08:      	add	x22, x22, #0x2
    8b0c:      	subs	x24, x24, #0x1
    8b10:      	b.ne	0x8a28 <_wf_flat_mutation_prepare$instance$4250cb78d3f44027+0x18c>
    8b14:      	ldur	q0, [sp, #0xf8]
    8b18:      	add	x8, sp, #0x9
    8b1c:      	ldur	q1, [x8, #0xff]
    8b20:      	stp	q0, q1, [x19]
    8b24:      	ldr	x8, [sp, #0x118]
    8b28:      	str	x8, [x19, #0x20]
    8b2c:      	ldr	q0, [sp, #0x120]
    8b30:      	stur	q0, [x19, #0x28]
    8b34:      	stp	x21, x20, [x19, #0x38]
    8b38:      	str	xzr, [x19, #0x48]
    8b3c:      	add	sp, sp, #0x340
    8b40:      	ldp	x29, x30, [sp, #0x40]
    8b44:      	ldp	x20, x19, [sp, #0x30]
    8b48:      	ldp	x22, x21, [sp, #0x20]
    8b4c:      	ldp	x24, x23, [sp, #0x10]
    8b50:      	ldp	x26, x25, [sp], #0x50
    8b54:      	ret
    8b58:      	bl	0x8b58 <_wf_flat_mutation_prepare$instance$4250cb78d3f44027+0x2bc>
		0000000000008b58:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

0000000000008b5c <_wf_flat_mutation_batch$instance$4250cb78d3f44027>:
    8b5c:      	stp	x28, x27, [sp, #-0x60]!
    8b60:      	stp	x26, x25, [sp, #0x10]
    8b64:      	stp	x24, x23, [sp, #0x20]
    8b68:      	stp	x22, x21, [sp, #0x30]
    8b6c:      	stp	x20, x19, [sp, #0x40]
    8b70:      	stp	x29, x30, [sp, #0x50]
    8b74:      	sub	sp, sp, #0x3a0
    8b78:      	ldr	x24, [x0, #0x38]
    8b7c:      	str	x1, [sp, #0x8]
    8b80:      	cbz	x1, 0x90fc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x5a0>
    8b84:      	mov	x19, x0
    8b88:      	ldr	x26, [x0, #0x40]
    8b8c:      	cbz	x26, 0x90ec <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x590>
    8b90:      	mov	x21, x2
    8b94:      	str	xzr, [sp, #0x18]
    8b98:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000008b98:  ARM64_RELOC_PAGE21	lCPI94_0
    8b9c:      	ldr	q0, [x8]
		0000000000008b9c:  ARM64_RELOC_PAGEOFF12	lCPI94_0
    8ba0:      	str	q0, [sp, #0x180]
    8ba4:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000008ba4:  ARM64_RELOC_PAGE21	lCPI94_1
    8ba8:      	ldr	q0, [x8]
		0000000000008ba8:  ARM64_RELOC_PAGEOFF12	lCPI94_1
    8bac:      	str	q0, [sp, #0x170]
    8bb0:      	add	x27, sp, #0x2a0
    8bb4:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000008bb4:  ARM64_RELOC_PAGE21	lCPI94_2
    8bb8:      	ldr	q0, [x8]
		0000000000008bb8:  ARM64_RELOC_PAGEOFF12	lCPI94_2
    8bbc:      	str	q0, [sp, #0x160]
    8bc0:      	mov	w28, #0x1               ; =1
    8bc4:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000008bc4:  ARM64_RELOC_PAGE21	lCPI94_3
    8bc8:      	ldr	q0, [x8]
		0000000000008bc8:  ARM64_RELOC_PAGEOFF12	lCPI94_3
    8bcc:      	str	q0, [sp, #0x150]
    8bd0:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000008bd0:  ARM64_RELOC_PAGE21	lCPI94_4
    8bd4:      	ldr	q0, [x8]
		0000000000008bd4:  ARM64_RELOC_PAGEOFF12	lCPI94_4
    8bd8:      	str	q0, [sp, #0x140]
    8bdc:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000008bdc:  ARM64_RELOC_PAGE21	lCPI94_5
    8be0:      	ldr	q0, [x8]
		0000000000008be0:  ARM64_RELOC_PAGEOFF12	lCPI94_5
    8be4:      	str	q0, [sp, #0x130]
    8be8:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000008be8:  ARM64_RELOC_PAGE21	lCPI94_6
    8bec:      	ldr	q0, [x8]
		0000000000008bec:  ARM64_RELOC_PAGEOFF12	lCPI94_6
    8bf0:      	str	q0, [sp, #0x120]
    8bf4:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000008bf4:  ARM64_RELOC_PAGE21	lCPI94_7
    8bf8:      	ldr	q0, [x8]
		0000000000008bf8:  ARM64_RELOC_PAGEOFF12	lCPI94_7
    8bfc:      	str	q0, [sp, #0x110]
    8c00:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000008c00:  ARM64_RELOC_PAGE21	lCPI94_8
    8c04:      	ldr	q0, [x8]
		0000000000008c04:  ARM64_RELOC_PAGEOFF12	lCPI94_8
    8c08:      	str	q0, [sp, #0x100]
    8c0c:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000008c0c:  ARM64_RELOC_PAGE21	lCPI94_9
    8c10:      	ldr	q0, [x8]
		0000000000008c10:  ARM64_RELOC_PAGEOFF12	lCPI94_9
    8c14:      	str	q0, [sp, #0xf0]
    8c18:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000008c18:  ARM64_RELOC_PAGE21	lCPI94_10
    8c1c:      	ldr	q0, [x8]
		0000000000008c1c:  ARM64_RELOC_PAGEOFF12	lCPI94_10
    8c20:      	str	q0, [sp, #0xe0]
    8c24:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000008c24:  ARM64_RELOC_PAGE21	lCPI94_11
    8c28:      	ldr	q0, [x8]
		0000000000008c28:  ARM64_RELOC_PAGEOFF12	lCPI94_11
    8c2c:      	str	q0, [sp, #0xd0]
    8c30:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000008c30:  ARM64_RELOC_PAGE21	lCPI94_12
    8c34:      	ldr	q0, [x8]
		0000000000008c34:  ARM64_RELOC_PAGEOFF12	lCPI94_12
    8c38:      	str	q0, [sp, #0xc0]
    8c3c:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000008c3c:  ARM64_RELOC_PAGE21	lCPI94_13
    8c40:      	ldr	q0, [x8]
		0000000000008c40:  ARM64_RELOC_PAGEOFF12	lCPI94_13
    8c44:      	str	q0, [sp, #0xb0]
    8c48:      	adrp	x8, 0x8000 <_wf_flat_mutation_prepare$instance$c7c8cd11e7f079bd+0x50>
		0000000000008c48:  ARM64_RELOC_PAGE21	lCPI94_14
    8c4c:      	ldr	q0, [x8]
		0000000000008c4c:  ARM64_RELOC_PAGEOFF12	lCPI94_14
    8c50:      	str	q0, [sp, #0xa0]
    8c54:      	mov	w20, #0x83              ; =131
    8c58:      	mov	w22, #0x110             ; =272
    8c5c:      	ldr	x10, [x19, #0x48]
    8c60:      	add	x10, x10, #0x1
    8c64:      	str	x10, [sp, #0x10]
    8c68:      	cbz	x26, 0x90c0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x564>
    8c6c:      	mov	x23, #0x0               ; =0
    8c70:      	ldr	x8, [x19, #0x38]
    8c74:      	madd	x25, x10, x26, x8
    8c78:      	b	0x8d84 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x228>
    8c7c:      	ldrb	w8, [sp, #0x194]
    8c80:      	tst	w8, #0x1
    8c84:      	ldp	x9, x8, [sp, #0x198]
    8c88:      	madd	x8, x9, x20, x8
    8c8c:      	ldp	x10, x9, [sp, #0x1a8]
    8c90:      	madd	x8, x8, x20, x10
    8c94:      	madd	x8, x8, x20, x9
    8c98:      	ldp	x10, x9, [sp, #0x1b8]
    8c9c:      	madd	x8, x8, x20, x10
    8ca0:      	madd	x8, x8, x20, x9
    8ca4:      	ldp	x10, x9, [sp, #0x1c8]
    8ca8:      	madd	x8, x8, x20, x10
    8cac:      	madd	x8, x8, x20, x9
    8cb0:      	ldp	x10, x9, [sp, #0x1d8]
    8cb4:      	madd	x8, x8, x20, x10
    8cb8:      	madd	x8, x8, x20, x9
    8cbc:      	ldp	x10, x9, [sp, #0x1e8]
    8cc0:      	madd	x8, x8, x20, x10
    8cc4:      	madd	x8, x8, x20, x9
    8cc8:      	ldp	x10, x9, [sp, #0x1f8]
    8ccc:      	madd	x8, x8, x20, x10
    8cd0:      	madd	x8, x8, x20, x9
    8cd4:      	ldr	x9, [sp, #0x208]
    8cd8:      	madd	x8, x8, x20, x9
    8cdc:      	ldr	x9, [sp, #0x210]
    8ce0:      	madd	x8, x8, x20, x9
    8ce4:      	ldr	x9, [sp, #0x218]
    8ce8:      	madd	x8, x8, x20, x9
    8cec:      	ldr	x9, [sp, #0x220]
    8cf0:      	madd	x8, x8, x20, x9
    8cf4:      	ldr	x9, [sp, #0x228]
    8cf8:      	madd	x8, x8, x20, x9
    8cfc:      	ldr	x9, [sp, #0x230]
    8d00:      	madd	x8, x8, x20, x9
    8d04:      	ldr	x9, [sp, #0x238]
    8d08:      	madd	x8, x8, x20, x9
    8d0c:      	ldr	x9, [sp, #0x240]
    8d10:      	madd	x8, x8, x20, x9
    8d14:      	ldr	x9, [sp, #0x248]
    8d18:      	madd	x8, x8, x20, x9
    8d1c:      	ldr	x9, [sp, #0x250]
    8d20:      	madd	x8, x8, x20, x9
    8d24:      	ldr	x9, [sp, #0x258]
    8d28:      	madd	x8, x8, x20, x9
    8d2c:      	ldr	x9, [sp, #0x260]
    8d30:      	madd	x8, x8, x20, x9
    8d34:      	ldr	x9, [sp, #0x268]
    8d38:      	madd	x8, x8, x20, x9
    8d3c:      	ldr	x9, [sp, #0x270]
    8d40:      	madd	x8, x8, x20, x9
    8d44:      	ldr	x9, [sp, #0x278]
    8d48:      	madd	x8, x8, x20, x9
    8d4c:      	ldr	x9, [sp, #0x280]
    8d50:      	madd	x8, x8, x20, x9
    8d54:      	ldr	x9, [sp, #0x288]
    8d58:      	add	x9, x9, x24
    8d5c:      	ldr	x10, [sp, #0x290]
    8d60:      	madd	x8, x8, x20, x9
    8d64:      	cinc	x9, x28, ne
    8d68:      	add	x9, x9, x10
    8d6c:      	madd	x8, x8, x20, x9
    8d70:      	ldr	x9, [sp, #0x298]
    8d74:      	madd	x24, x8, x20, x9
    8d78:      	add	x23, x23, #0x1
    8d7c:      	cmp	x23, x26
    8d80:      	b.eq	0x90c0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x564>
    8d84:      	orr	x2, x28, x23, lsl #1
    8d88:      	cbz	x21, 0x8fcc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x470>
    8d8c:      	ldr	x8, [x19, #0x18]
    8d90:      	cbz	x8, 0x8fc8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x46c>
    8d94:      	ldrb	w9, [x19, #0x30]
    8d98:      	tbz	w9, #0x0, 0x8dac <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x250>
    8d9c:      	mov	x9, #0x0                ; =0
    8da0:      	ldr	x10, [x19]
    8da4:      	cbnz	x10, 0x8df0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x294>
    8da8:      	b	0x8fc8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x46c>
    8dac:      	ldr	x9, [x19, #0x28]
    8db0:      	eor	x9, x9, x2
    8db4:      	eor	x9, x9, x9, lsr #30
    8db8:      	mov	x10, #0xe5b9            ; =58809
    8dbc:      	movk	x10, #0x1ce4, lsl #16
    8dc0:      	movk	x10, #0x476d, lsl #32
    8dc4:      	movk	x10, #0xbf58, lsl #48
    8dc8:      	mul	x9, x9, x10
    8dcc:      	eor	x9, x9, x9, lsr #27
    8dd0:      	mov	x10, #0x11eb            ; =4587
    8dd4:      	movk	x10, #0x1331, lsl #16
    8dd8:      	movk	x10, #0x49bb, lsl #32
    8ddc:      	movk	x10, #0x94d0, lsl #48
    8de0:      	mul	x9, x9, x10
    8de4:      	eor	x9, x9, x9, lsr #31
    8de8:      	ldr	x10, [x19]
    8dec:      	cbz	x10, 0x8fc8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x46c>
    8df0:      	udiv	x11, x9, x10
    8df4:      	msub	x11, x11, x10, x9
    8df8:      	ldr	x12, [x19, #0x10]
    8dfc:      	mov	x13, x10
    8e00:      	b	0x8e18 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2bc>
    8e04:      	add	x9, x11, #0x1
    8e08:      	cmp	x9, x10
    8e0c:      	csinc	x11, xzr, x11, hs
    8e10:      	subs	x13, x13, #0x1
    8e14:      	b.eq	0x8fc8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x46c>
    8e18:      	madd	x9, x11, x22, x12
    8e1c:      	ldr	w14, [x9]
    8e20:      	cmp	w14, #0x1
    8e24:      	b.eq	0x8e04 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2a8>
    8e28:      	cmp	w14, #0x2
    8e2c:      	b.ne	0x8fc8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x46c>
    8e30:      	ldr	x14, [x9, #0x8]
    8e34:      	cmp	x14, x2
    8e38:      	b.ne	0x8e04 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2a8>
    8e3c:      	ldp	x11, x10, [x9, #0x10]
    8e40:      	stp	x10, x11, [sp, #0x90]
    8e44:      	ldp	x11, x10, [x9, #0x20]
    8e48:      	stp	x10, x11, [sp, #0x80]
    8e4c:      	ldp	x14, x15, [x9, #0x30]
    8e50:      	ldp	x16, x17, [x9, #0x40]
    8e54:      	ldp	x0, x1, [x9, #0x50]
    8e58:      	ldp	x3, x4, [x9, #0x60]
    8e5c:      	ldp	x5, x6, [x9, #0x70]
    8e60:      	ldp	x7, x30, [x9, #0x80]
    8e64:      	ldp	x11, x10, [x9, #0x90]
    8e68:      	stp	x10, x11, [sp, #0x70]
    8e6c:      	ldp	x11, x10, [x9, #0xa0]
    8e70:      	stp	x10, x11, [sp, #0x60]
    8e74:      	ldp	x11, x10, [x9, #0xb0]
    8e78:      	stp	x10, x11, [sp, #0x50]
    8e7c:      	ldp	x11, x10, [x9, #0xc0]
    8e80:      	stp	x10, x11, [sp, #0x40]
    8e84:      	ldp	x11, x10, [x9, #0xd0]
    8e88:      	stp	x10, x11, [sp, #0x30]
    8e8c:      	ldp	x11, x10, [x9, #0xe0]
    8e90:      	stp	x10, x11, [sp, #0x20]
    8e94:      	str	w28, [x9]
    8e98:      	movi.2d	v0, #0000000000000000
    8e9c:      	stur	q0, [x9, #0x8]
    8ea0:      	stur	q0, [x9, #0x18]
    8ea4:      	stur	q0, [x9, #0x28]
    8ea8:      	stur	q0, [x9, #0x38]
    8eac:      	stur	q0, [x9, #0x48]
    8eb0:      	stur	q0, [x9, #0x58]
    8eb4:      	stur	q0, [x9, #0x68]
    8eb8:      	stur	q0, [x9, #0x78]
    8ebc:      	stur	q0, [x9, #0x88]
    8ec0:      	stur	q0, [x9, #0x98]
    8ec4:      	stur	q0, [x9, #0xa8]
    8ec8:      	stur	q0, [x9, #0xb8]
    8ecc:      	stur	q0, [x9, #0xc8]
    8ed0:      	stur	q0, [x9, #0xd8]
    8ed4:      	ldp	x12, x13, [x9, #0xf0]
    8ed8:      	stur	q0, [x9, #0xe8]
    8edc:      	ldp	x10, x11, [x9, #0x100]
    8ee0:      	stur	q0, [x9, #0xf8]
    8ee4:      	str	xzr, [x9, #0x108]
    8ee8:      	sub	x8, x8, #0x1
    8eec:      	ldr	x9, [x19, #0x20]
    8ef0:      	adds	x9, x9, #0x1
    8ef4:      	csinv	x9, x9, xzr, lo
    8ef8:      	stp	x8, x9, [x19, #0x18]
    8efc:      	ldp	x9, x8, [sp, #0x90]
    8f00:      	madd	x8, x2, x20, x8
    8f04:      	madd	x8, x8, x20, x9
    8f08:      	ldr	x9, [sp, #0x88]
    8f0c:      	madd	x8, x8, x20, x9
    8f10:      	ldr	x9, [sp, #0x80]
    8f14:      	madd	x8, x8, x20, x9
    8f18:      	madd	x8, x8, x20, x14
    8f1c:      	madd	x8, x8, x20, x15
    8f20:      	madd	x8, x8, x20, x16
    8f24:      	madd	x8, x8, x20, x17
    8f28:      	madd	x8, x8, x20, x0
    8f2c:      	madd	x8, x8, x20, x1
    8f30:      	madd	x8, x8, x20, x3
    8f34:      	madd	x8, x8, x20, x4
    8f38:      	madd	x8, x8, x20, x5
    8f3c:      	madd	x8, x8, x20, x6
    8f40:      	madd	x8, x8, x20, x7
    8f44:      	madd	x8, x8, x20, x30
    8f48:      	ldr	x9, [sp, #0x78]
    8f4c:      	madd	x8, x8, x20, x9
    8f50:      	ldr	x9, [sp, #0x70]
    8f54:      	madd	x8, x8, x20, x9
    8f58:      	ldr	x9, [sp, #0x68]
    8f5c:      	madd	x8, x8, x20, x9
    8f60:      	ldr	x9, [sp, #0x60]
    8f64:      	madd	x8, x8, x20, x9
    8f68:      	ldr	x9, [sp, #0x58]
    8f6c:      	madd	x8, x8, x20, x9
    8f70:      	ldr	x9, [sp, #0x50]
    8f74:      	madd	x8, x8, x20, x9
    8f78:      	ldr	x9, [sp, #0x48]
    8f7c:      	madd	x8, x8, x20, x9
    8f80:      	ldr	x9, [sp, #0x40]
    8f84:      	madd	x8, x8, x20, x9
    8f88:      	ldr	x9, [sp, #0x38]
    8f8c:      	madd	x8, x8, x20, x9
    8f90:      	ldr	x9, [sp, #0x30]
    8f94:      	madd	x8, x8, x20, x9
    8f98:      	ldr	x9, [sp, #0x28]
    8f9c:      	madd	x8, x8, x20, x9
    8fa0:      	ldr	x9, [sp, #0x20]
    8fa4:      	madd	x8, x8, x20, x9
    8fa8:      	madd	x8, x8, x20, x12
    8fac:      	madd	x8, x8, x20, x13
    8fb0:      	madd	x8, x8, x20, x10
    8fb4:      	mov	w9, #0x4309             ; =17161
    8fb8:      	madd	x9, x24, x9, x11
    8fbc:      	madd	x8, x8, x20, x9
    8fc0:      	add	x24, x8, #0x83
    8fc4:      	b	0x8fcc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x470>
    8fc8:      	mul	x24, x24, x20
    8fcc:      	add	x8, x25, x23
    8fd0:      	dup.2d	v0, x8
    8fd4:      	ldr	q1, [sp, #0x180]
    8fd8:      	add.2d	v1, v0, v1
    8fdc:      	stur	q1, [x27, #0x8]
    8fe0:      	add	x9, x8, #0x1f
    8fe4:      	ldr	q1, [sp, #0x170]
    8fe8:      	add.2d	v1, v0, v1
    8fec:      	stur	q1, [x27, #0x18]
    8ff0:      	ldr	q1, [sp, #0x160]
    8ff4:      	add.2d	v1, v0, v1
    8ff8:      	stur	q1, [x27, #0x28]
    8ffc:      	ldr	q1, [sp, #0x150]
    9000:      	add.2d	v1, v0, v1
    9004:      	stur	q1, [x27, #0x38]
    9008:      	ldr	q1, [sp, #0x140]
    900c:      	add.2d	v1, v0, v1
    9010:      	stur	q1, [x27, #0x48]
    9014:      	ldr	q1, [sp, #0x130]
    9018:      	add.2d	v1, v0, v1
    901c:      	stur	q1, [x27, #0x58]
    9020:      	ldr	q1, [sp, #0x120]
    9024:      	add.2d	v1, v0, v1
    9028:      	stur	q1, [x27, #0x68]
    902c:      	ldr	q1, [sp, #0x110]
    9030:      	add.2d	v1, v0, v1
    9034:      	stur	q1, [x27, #0x78]
    9038:      	ldr	q1, [sp, #0x100]
    903c:      	add.2d	v1, v0, v1
    9040:      	stur	q1, [x27, #0x88]
    9044:      	ldr	q1, [sp, #0xf0]
    9048:      	add.2d	v1, v0, v1
    904c:      	stur	q1, [x27, #0x98]
    9050:      	ldr	q1, [sp, #0xe0]
    9054:      	add.2d	v1, v0, v1
    9058:      	stur	q1, [x27, #0xa8]
    905c:      	ldr	q1, [sp, #0xd0]
    9060:      	add.2d	v1, v0, v1
    9064:      	stur	q1, [x27, #0xb8]
    9068:      	ldr	q1, [sp, #0xc0]
    906c:      	add.2d	v1, v0, v1
    9070:      	stur	q1, [x27, #0xc8]
    9074:      	ldr	q1, [sp, #0xb0]
    9078:      	add.2d	v1, v0, v1
    907c:      	stur	q1, [x27, #0xd8]
    9080:      	ldr	q1, [sp, #0xa0]
    9084:      	add.2d	v0, v0, v1
    9088:      	stur	q0, [x27, #0xe8]
    908c:      	str	x8, [sp, #0x2a0]
    9090:      	str	x9, [sp, #0x398]
    9094:      	add	x0, sp, #0x190
    9098:      	add	x3, sp, #0x2a0
    909c:      	add	x4, x19, #0x28
    90a0:      	mov	x1, x19
    90a4:      	bl	0x90a4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x548>
		00000000000090a4:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d
    90a8:      	ldr	w8, [sp, #0x190]
    90ac:      	cbnz	w8, 0x8c7c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x120>
    90b0:      	mul	x24, x24, x20
    90b4:      	add	x23, x23, #0x1
    90b8:      	cmp	x23, x26
    90bc:      	b.ne	0x8d84 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x228>
    90c0:      	ldp	x10, x9, [sp, #0x10]
    90c4:      	str	x10, [x19, #0x48]
    90c8:      	add	x9, x9, #0x1
    90cc:      	ldr	x8, [sp, #0x8]
    90d0:      	cmp	x9, x8
    90d4:      	b.eq	0x90fc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x5a0>
    90d8:      	ldr	x26, [x19, #0x40]
    90dc:      	add	x10, x10, #0x1
    90e0:      	stp	x10, x9, [sp, #0x10]
    90e4:      	cbnz	x26, 0x8c6c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x110>
    90e8:      	b	0x90c0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x564>
    90ec:      	ldr	x8, [x19, #0x48]
    90f0:      	ldr	x9, [sp, #0x8]
    90f4:      	add	x8, x8, x9
    90f8:      	str	x8, [x19, #0x48]
    90fc:      	eor	x8, x24, x24, lsr #30
    9100:      	mov	x9, #0xe5b9             ; =58809
    9104:      	movk	x9, #0x1ce4, lsl #16
    9108:      	movk	x9, #0x476d, lsl #32
    910c:      	movk	x9, #0xbf58, lsl #48
    9110:      	mul	x8, x8, x9
    9114:      	eor	x8, x8, x8, lsr #27
    9118:      	mov	x9, #0x11eb             ; =4587
    911c:      	movk	x9, #0x1331, lsl #16
    9120:      	movk	x9, #0x49bb, lsl #32
    9124:      	movk	x9, #0x94d0, lsl #48
    9128:      	mul	x8, x8, x9
    912c:      	eor	x0, x8, x8, lsr #31
    9130:      	add	sp, sp, #0x3a0
    9134:      	ldp	x29, x30, [sp, #0x50]
    9138:      	ldp	x20, x19, [sp, #0x40]
    913c:      	ldp	x22, x21, [sp, #0x30]
    9140:      	ldp	x24, x23, [sp, #0x20]
    9144:      	ldp	x26, x25, [sp, #0x10]
    9148:      	ldp	x28, x27, [sp], #0x60
    914c:      	ret

0000000000009150 <_wf_flat_mutation_geometry$instance$9fed7d4c5d7cc122>:
    9150:      	ldr	x8, [x0]
    9154:      	ldr	x9, [x0, #0x18]
    9158:      	add	x0, x9, x8, lsl #32
    915c:      	ret

0000000000009160 <_wf_flat_mutation_verify$instance$4250cb78d3f44027>:
    9160:      	mov	x9, #0xe5b9             ; =58809
    9164:      	movk	x9, #0x1ce4, lsl #16
    9168:      	movk	x9, #0x476d, lsl #32
    916c:      	movk	x9, #0xbf58, lsl #48
    9170:      	mov	x8, #0x11eb             ; =4587
    9174:      	movk	x8, #0x1331, lsl #16
    9178:      	movk	x8, #0x49bb, lsl #32
    917c:      	movk	x8, #0x94d0, lsl #48
    9180:      	ldp	x1, x10, [x0, #0x38]
    9184:      	cbz	x10, 0x92ec <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x18c>
    9188:      	mov	x11, #0x0               ; =0
    918c:      	ldr	x12, [x0, #0x28]
    9190:      	ldrb	w13, [x0, #0x30]
    9194:      	mov	w14, #0x83              ; =131
    9198:      	mov	w15, #0x110             ; =272
    919c:      	mov	w16, #0x4309            ; =17161
    91a0:      	ldr	x17, [x0]
    91a4:      	b	0x91b8 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x58>
    91a8:      	mul	x1, x1, x14
    91ac:      	add	x11, x11, #0x1
    91b0:      	cmp	x11, x10
    91b4:      	b.eq	0x92ec <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x18c>
    91b8:      	mov	w2, #0x1                ; =1
    91bc:      	bfi	x2, x11, #1, #63
    91c0:      	tbz	w13, #0x0, 0x91d0 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x70>
    91c4:      	mov	x3, #0x0                ; =0
    91c8:      	cbnz	x17, 0x91ec <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x8c>
    91cc:      	b	0x9270 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x110>
    91d0:      	eor	x3, x12, x2
    91d4:      	eor	x3, x3, x3, lsr #30
    91d8:      	mul	x3, x3, x9
    91dc:      	eor	x3, x3, x3, lsr #27
    91e0:      	mul	x3, x3, x8
    91e4:      	eor	x3, x3, x3, lsr #31
    91e8:      	cbz	x17, 0x9270 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x110>
    91ec:      	udiv	x4, x3, x17
    91f0:      	msub	x3, x4, x17, x3
    91f4:      	ldr	x4, [x0, #0x10]
    91f8:      	mov	x5, x17
    91fc:      	b	0x9214 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0xb4>
    9200:      	add	x6, x3, #0x1
    9204:      	cmp	x6, x17
    9208:      	csinc	x3, xzr, x3, hs
    920c:      	subs	x5, x5, #0x1
    9210:      	b.eq	0x9270 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x110>
    9214:      	madd	x6, x3, x15, x4
    9218:      	ldr	w7, [x6]
    921c:      	cmp	w7, #0x1
    9220:      	b.eq	0x9200 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0xa0>
    9224:      	cmp	w7, #0x2
    9228:      	b.ne	0x9270 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x110>
    922c:      	ldr	x7, [x6, #0x8]
    9230:      	cmp	x7, x2
    9234:      	b.ne	0x9200 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0xa0>
    9238:      	ldr	x2, [x6, #0x10]
    923c:      	madd	x1, x1, x16, x2
    9240:      	add	x1, x1, #0x83
    9244:      	lsl	x2, x11, #1
    9248:      	add	x2, x2, #0x2
    924c:      	tbnz	w13, #0x0, 0x9280 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x120>
    9250:      	eor	x3, x12, x2
    9254:      	eor	x3, x3, x3, lsr #30
    9258:      	mul	x3, x3, x9
    925c:      	eor	x3, x3, x3, lsr #27
    9260:      	mul	x3, x3, x8
    9264:      	eor	x3, x3, x3, lsr #31
    9268:      	cbnz	x17, 0x9288 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x128>
    926c:      	b	0x91a8 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x48>
    9270:      	mul	x1, x1, x14
    9274:      	lsl	x2, x11, #1
    9278:      	add	x2, x2, #0x2
    927c:      	tbz	w13, #0x0, 0x9250 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0xf0>
    9280:      	mov	x3, #0x0                ; =0
    9284:      	cbz	x17, 0x91a8 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x48>
    9288:      	udiv	x4, x3, x17
    928c:      	msub	x3, x4, x17, x3
    9290:      	ldr	x4, [x0, #0x10]
    9294:      	mov	x5, x17
    9298:      	b	0x92b0 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x150>
    929c:      	add	x6, x3, #0x1
    92a0:      	cmp	x6, x17
    92a4:      	csinc	x3, xzr, x3, hs
    92a8:      	subs	x5, x5, #0x1
    92ac:      	b.eq	0x91a8 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x48>
    92b0:      	madd	x6, x3, x15, x4
    92b4:      	ldr	w7, [x6]
    92b8:      	cmp	w7, #0x1
    92bc:      	b.eq	0x929c <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x13c>
    92c0:      	cmp	w7, #0x2
    92c4:      	b.ne	0x91a8 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x48>
    92c8:      	ldr	x7, [x6, #0x8]
    92cc:      	cmp	x7, x2
    92d0:      	b.ne	0x929c <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x13c>
    92d4:      	ldr	x2, [x6, #0x10]
    92d8:      	madd	x1, x1, x16, x2
    92dc:      	add	x1, x1, #0x83
    92e0:      	add	x11, x11, #0x1
    92e4:      	cmp	x11, x10
    92e8:      	b.ne	0x91b8 <_wf_flat_mutation_verify$instance$4250cb78d3f44027+0x58>
    92ec:      	eor	x10, x1, x1, lsr #30
    92f0:      	mul	x9, x10, x9
    92f4:      	eor	x9, x9, x9, lsr #27
    92f8:      	mul	x8, x9, x8
    92fc:      	eor	x0, x8, x8, lsr #31
    9300:      	ret

0000000000009304 <_wf_flat_mutation_finish$instance$4250cb78d3f44027>:
    9304:      	sub	sp, sp, #0x60
    9308:      	stp	x29, x30, [sp, #0x50]
    930c:      	ldr	x8, [x0, #0x38]
    9310:      	ldp	q0, q1, [x0]
    9314:      	stp	q0, q1, [sp, #0x20]
    9318:      	ldr	x9, [x0, #0x20]
    931c:      	str	x9, [sp, #0x40]
    9320:      	stp	x8, xzr, [sp]
    9324:      	stp	xzr, xzr, [sp, #0x10]
    9328:      	add	x0, sp, #0x20
    932c:      	mov	x1, sp
    9330:      	bl	0x9330 <_wf_flat_mutation_finish$instance$4250cb78d3f44027+0x2c>
		0000000000009330:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_free$instance$e1a21e22af512733
    9334:      	ldp	x8, x9, [sp]
    9338:      	ldp	x10, x11, [sp, #0x10]
    933c:      	eor	x8, x8, x8, lsr #30
    9340:      	mov	x12, #0xe5b9            ; =58809
    9344:      	movk	x12, #0x1ce4, lsl #16
    9348:      	movk	x12, #0x476d, lsl #32
    934c:      	movk	x12, #0xbf58, lsl #48
    9350:      	mul	x8, x8, x12
    9354:      	eor	x8, x8, x8, lsr #27
    9358:      	mov	x13, #0x11eb            ; =4587
    935c:      	movk	x13, #0x1331, lsl #16
    9360:      	movk	x13, #0x49bb, lsl #32
    9364:      	movk	x13, #0x94d0, lsl #48
    9368:      	mul	x8, x8, x13
    936c:      	eor	x9, x9, x9, lsr #30
    9370:      	mul	x9, x9, x12
    9374:      	eor	x9, x9, x9, lsr #27
    9378:      	mul	x9, x9, x13
    937c:      	eor	x12, x9, x8
    9380:      	mov	x13, #0x7c15            ; =31765
    9384:      	movk	x13, #0x7f4a, lsl #16
    9388:      	movk	x13, #0x79b9, lsl #32
    938c:      	movk	x13, #0x9e37, lsl #48
    9390:      	mul	x11, x11, x13
    9394:      	eor	x10, x10, x11
    9398:      	eor	x10, x10, x12, lsr #31
    939c:      	eor	x8, x8, x9
    93a0:      	eor	x0, x10, x8
    93a4:      	ldp	x29, x30, [sp, #0x50]
    93a8:      	add	sp, sp, #0x60
    93ac:      	ret

00000000000093b0 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd>:
    93b0:      	sub	sp, sp, #0x60
    93b4:      	stp	x26, x25, [sp, #0x10]
    93b8:      	stp	x24, x23, [sp, #0x20]
    93bc:      	stp	x22, x21, [sp, #0x30]
    93c0:      	stp	x20, x19, [sp, #0x40]
    93c4:      	stp	x29, x30, [sp, #0x50]
    93c8:      	mov	x20, x3
    93cc:      	mov	x19, x2
    93d0:      	mov	x22, x1
    93d4:      	mov	x21, x0
    93d8:      	mov	x8, #0x7c15             ; =31765
    93dc:      	movk	x8, #0x7f4a, lsl #16
    93e0:      	movk	x8, #0x79b9, lsl #32
    93e4:      	movk	x8, #0x9e37, lsl #48
    93e8:      	eor	x25, x3, x8
    93ec:      	strb	wzr, [sp, #0x8]
    93f0:      	cbz	x1, 0x94c8 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x118>
    93f4:      	lsl	x24, x22, #3
    93f8:      	mov	x0, x24
    93fc:      	bl	0x93fc <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x4c>
		00000000000093fc:  ARM64_RELOC_BRANCH26	_malloc
    9400:      	cbz	x0, 0x95e8 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x238>
    9404:      	mov	x23, x0
    9408:      	mov	w1, #0xff               ; =255
    940c:      	mov	x2, x24
    9410:      	bl	0x9410 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x60>
		0000000000009410:  ARM64_RELOC_BRANCH26	_memset
    9414:      	add	x8, x22, x22, lsl #1
    9418:      	lsl	x0, x8, #3
    941c:      	bl	0x941c <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x6c>
		000000000000941c:  ARM64_RELOC_BRANCH26	_malloc
    9420:      	cbz	x0, 0x95e8 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x238>
    9424:      	mov	w8, #0x2000             ; =8192
    9428:      	cmp	x22, #0x2, lsl #12      ; =0x2000
    942c:      	csel	x10, x22, x8, lo
    9430:      	ldrb	w8, [sp, #0x8]
    9434:      	cbz	x19, 0x94e0 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x130>
    9438:      	mov	x11, #0x0               ; =0
    943c:      	mov	x9, #0x0                ; =0
    9440:      	tbz	w8, #0x0, 0x94e8 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x138>
    9444:      	ldr	x12, [x23]
    9448:      	mov	w13, #0x1               ; =1
    944c:      	mov	w14, #0x18              ; =24
    9450:      	b	0x9464 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0xb4>
    9454:      	str	x15, [x1, #0x8]
    9458:      	add	x11, x11, #0x1
    945c:      	cmp	x11, x19
    9460:      	b.eq	0x95ac <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x1fc>
    9464:      	orr	x16, x13, x11, lsl #1
    9468:      	add	x15, x11, x20
    946c:      	cbz	x9, 0x94a8 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0xf8>
    9470:      	cmp	x12, x9
    9474:      	b.hs	0x94a8 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0xf8>
    9478:      	mov	w17, #0x1               ; =1
    947c:      	mov	x1, x12
    9480:      	madd	x1, x1, x14, x0
    9484:      	ldr	x2, [x1]
    9488:      	cmp	x2, x16
    948c:      	b.eq	0x9454 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0xa4>
    9490:      	cmp	x17, x9
    9494:      	b.hs	0x94a8 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0xf8>
    9498:      	ldr	x1, [x1, #0x10]
    949c:      	add	x17, x17, #0x1
    94a0:      	cmp	x1, x9
    94a4:      	b.lo	0x9480 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0xd0>
    94a8:      	cmp	x9, x10
    94ac:      	b.hs	0x9458 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0xa8>
    94b0:      	madd	x17, x9, x14, x0
    94b4:      	stp	x16, x15, [x17]
    94b8:      	str	x12, [x17, #0x10]
    94bc:      	mov	x12, x9
    94c0:      	add	x9, x9, #0x1
    94c4:      	b	0x9458 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0xa8>
    94c8:      	mov	x9, #0x0                ; =0
    94cc:      	adrp	x0, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x4a4>
		00000000000094cc:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    94d0:      	add	x0, x0, #0x0
		00000000000094d0:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    94d4:      	ldrb	w8, [sp, #0x8]
    94d8:      	mov	x23, x0
    94dc:      	b	0x95b0 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x200>
    94e0:      	mov	x9, #0x0                ; =0
    94e4:      	b	0x95b0 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x200>
    94e8:      	mov	w12, #0x1               ; =1
    94ec:      	mov	x13, #0xe5b9            ; =58809
    94f0:      	movk	x13, #0x1ce4, lsl #16
    94f4:      	movk	x13, #0x476d, lsl #32
    94f8:      	movk	x13, #0xbf58, lsl #48
    94fc:      	mov	x14, #0x11eb            ; =4587
    9500:      	movk	x14, #0x1331, lsl #16
    9504:      	movk	x14, #0x49bb, lsl #32
    9508:      	movk	x14, #0x94d0, lsl #48
    950c:      	mov	w15, #0x18              ; =24
    9510:      	b	0x9524 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x174>
    9514:      	str	x16, [x4, #0x8]
    9518:      	add	x11, x11, #0x1
    951c:      	cmp	x11, x19
    9520:      	b.eq	0x95b0 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x200>
    9524:      	orr	x17, x12, x11, lsl #1
    9528:      	add	x16, x11, x20
    952c:      	eor	x1, x17, x25
    9530:      	eor	x1, x1, x1, lsr #30
    9534:      	mul	x1, x1, x13
    9538:      	eor	x1, x1, x1, lsr #27
    953c:      	mul	x1, x1, x14
    9540:      	eor	x1, x1, x1, lsr #31
    9544:      	udiv	x2, x1, x22
    9548:      	msub	x1, x2, x22, x1
    954c:      	ldr	x2, [x23, x1, lsl #3]
    9550:      	cbz	x9, 0x958c <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x1dc>
    9554:      	cmp	x2, x9
    9558:      	b.hs	0x958c <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x1dc>
    955c:      	mov	w3, #0x1                ; =1
    9560:      	mov	x4, x2
    9564:      	madd	x4, x4, x15, x0
    9568:      	ldr	x5, [x4]
    956c:      	cmp	x5, x17
    9570:      	b.eq	0x9514 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x164>
    9574:      	cmp	x3, x9
    9578:      	b.hs	0x958c <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x1dc>
    957c:      	ldr	x4, [x4, #0x10]
    9580:      	add	x3, x3, #0x1
    9584:      	cmp	x4, x9
    9588:      	b.lo	0x9564 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x1b4>
    958c:      	cmp	x9, x10
    9590:      	b.hs	0x9518 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x168>
    9594:      	madd	x3, x9, x15, x0
    9598:      	stp	x17, x16, [x3]
    959c:      	str	x2, [x3, #0x10]
    95a0:      	str	x9, [x23, x1, lsl #3]
    95a4:      	add	x9, x9, #0x1
    95a8:      	b	0x9518 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x168>
    95ac:      	str	x12, [x23]
    95b0:      	stp	x22, x22, [x21]
    95b4:      	stp	x23, x9, [x21, #0x10]
    95b8:      	stp	x22, x0, [x21, #0x20]
    95bc:      	stp	x25, xzr, [x21, #0x30]
    95c0:      	strb	w8, [x21, #0x38]
    95c4:      	stp	x20, x19, [x21, #0x40]
    95c8:      	str	xzr, [x21, #0x50]
    95cc:      	ldp	x29, x30, [sp, #0x50]
    95d0:      	ldp	x20, x19, [sp, #0x40]
    95d4:      	ldp	x22, x21, [sp, #0x30]
    95d8:      	ldp	x24, x23, [sp, #0x20]
    95dc:      	ldp	x26, x25, [sp, #0x10]
    95e0:      	add	sp, sp, #0x60
    95e4:      	ret
    95e8:      	bl	0x95e8 <_wf_chain_mutation_prepare$instance$c7c8cd11e7f079bd+0x238>
		00000000000095e8:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

00000000000095ec <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd>:
    95ec:      	sub	sp, sp, #0x70
    95f0:      	stp	x28, x27, [sp, #0x10]
    95f4:      	stp	x26, x25, [sp, #0x20]
    95f8:      	stp	x24, x23, [sp, #0x30]
    95fc:      	stp	x22, x21, [sp, #0x40]
    9600:      	stp	x20, x19, [sp, #0x50]
    9604:      	stp	x29, x30, [sp, #0x60]
    9608:      	mov	x9, #0xe5b9             ; =58809
    960c:      	movk	x9, #0x1ce4, lsl #16
    9610:      	movk	x9, #0x476d, lsl #32
    9614:      	movk	x9, #0xbf58, lsl #48
    9618:      	mov	x8, #0x11eb             ; =4587
    961c:      	movk	x8, #0x1331, lsl #16
    9620:      	movk	x8, #0x49bb, lsl #32
    9624:      	movk	x8, #0x94d0, lsl #48
    9628:      	ldr	x20, [x0, #0x40]
    962c:      	str	x1, [sp]
    9630:      	cbz	x1, 0x9958 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x36c>
    9634:      	ldp	x12, x11, [x0, #0x48]
    9638:      	cbz	x12, 0x9944 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x358>
    963c:      	mov	x13, #0x0               ; =0
    9640:      	ldr	x14, [x0, #0x30]
    9644:      	ldr	x15, [x0]
    9648:      	mov	w10, #0x2000            ; =8192
    964c:      	cmp	x15, #0x2, lsl #12      ; =0x2000
    9650:      	csel	x16, x15, x10, lo
    9654:      	mov	w17, #0x1               ; =1
    9658:      	ldrb	w3, [x0, #0x38]
    965c:      	mov	w4, #0x83               ; =131
    9660:      	mov	w5, #0x18               ; =24
    9664:      	mov	x7, x20
    9668:      	b	0x9680 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
    966c:      	add	x13, x13, #0x1
    9670:      	ldr	x10, [sp]
    9674:      	cmp	x13, x10
    9678:      	mov	x20, x6
    967c:      	b.eq	0x9950 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x364>
    9680:      	mov	x19, #0x0               ; =0
    9684:      	add	x11, x11, #0x1
    9688:      	mov	x6, x20
    968c:      	madd	x20, x11, x12, x20
    9690:      	b	0x96b8 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0xcc>
    9694:      	strb	w17, [sp, #0xc]
    9698:      	tst	w17, #0x1
    969c:      	cinc	x10, x17, ne
    96a0:      	madd	x1, x7, x4, x21
    96a4:      	add	x10, x1, x10
    96a8:      	madd	x7, x10, x4, x22
    96ac:      	add	x19, x19, #0x1
    96b0:      	cmp	x19, x12
    96b4:      	b.eq	0x966c <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x80>
    96b8:      	orr	x21, x17, x19, lsl #1
    96bc:      	cbz	x2, 0x9744 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x158>
    96c0:      	ldr	x25, [x0, #0x18]
    96c4:      	cbz	x25, 0x9740 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x154>
    96c8:      	tbz	w3, #0x0, 0x96d8 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0xec>
    96cc:      	mov	x10, #0x0               ; =0
    96d0:      	cbnz	x15, 0x96f4 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x108>
    96d4:      	b	0x9740 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x154>
    96d8:      	eor	x10, x14, x21
    96dc:      	eor	x10, x10, x10, lsr #30
    96e0:      	mul	x10, x10, x9
    96e4:      	eor	x10, x10, x10, lsr #27
    96e8:      	mul	x10, x10, x8
    96ec:      	eor	x10, x10, x10, lsr #31
    96f0:      	cbz	x15, 0x9740 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x154>
    96f4:      	udiv	x22, x10, x15
    96f8:      	msub	x10, x22, x15, x10
    96fc:      	ldr	x23, [x0, #0x10]
    9700:      	add	x26, x23, x10, lsl #3
    9704:      	mov	x30, x25
    9708:      	mov	x28, x26
    970c:      	mov	x27, x25
    9710:      	ldr	x22, [x28]
    9714:      	cmp	x22, x25
    9718:      	b.hs	0x9740 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x154>
    971c:      	ldr	x24, [x0, #0x28]
    9720:      	madd	x10, x22, x5, x24
    9724:      	mov	x28, x10
    9728:      	ldr	x1, [x28], #0x10
    972c:      	cmp	x1, x21
    9730:      	b.eq	0x9758 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x16c>
    9734:      	mov	x27, x22
    9738:      	subs	x30, x30, #0x1
    973c:      	b.ne	0x9710 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x124>
    9740:      	mul	x7, x7, x4
    9744:      	tbz	w3, #0x0, 0x9858 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x26c>
    9748:      	mov	x10, #0x0               ; =0
    974c:      	add	x22, x20, x19
    9750:      	cbnz	x15, 0x9878 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x28c>
    9754:      	b	0x9694 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0xa8>
    9758:      	ldr	x28, [x28]
    975c:      	cmp	x27, x25
    9760:      	b.hs	0x979c <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x1b0>
    9764:      	madd	x1, x27, x5, x24
    9768:      	str	x28, [x1, #0x10]
    976c:      	sub	x27, x25, #0x1
    9770:      	madd	x25, x27, x5, x24
    9774:      	str	x27, [x0, #0x18]
    9778:      	ldp	x28, x30, [x25]
    977c:      	cmp	x22, x27
    9780:      	b.lo	0x97b8 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x1cc>
    9784:      	mov	w10, #0x4309            ; =17161
    9788:      	madd	x10, x7, x10, x30
    978c:      	madd	x10, x28, x4, x10
    9790:      	add	x7, x10, #0x83
    9794:      	tbnz	w3, #0x0, 0x9748 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x15c>
    9798:      	b	0x9858 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x26c>
    979c:      	str	x28, [x26]
    97a0:      	sub	x27, x25, #0x1
    97a4:      	madd	x25, x27, x5, x24
    97a8:      	str	x27, [x0, #0x18]
    97ac:      	ldp	x28, x30, [x25]
    97b0:      	cmp	x22, x27
    97b4:      	b.hs	0x9784 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x198>
    97b8:      	ldr	x1, [x25, #0x10]
    97bc:      	ldp	x25, x26, [x10]
    97c0:      	stp	x28, x30, [x10]
    97c4:      	str	x1, [x10, #0x10]
    97c8:      	tbz	w3, #0x0, 0x9814 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x228>
    97cc:      	mov	x10, #0x0               ; =0
    97d0:      	udiv	x1, x10, x15
    97d4:      	msub	x10, x1, x15, x10
    97d8:      	ldr	x28, [x23, x10, lsl #3]
    97dc:      	cmp	x28, x27
    97e0:      	b.eq	0x9840 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x254>
    97e4:      	b.hs	0x9844 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x258>
    97e8:      	mov	w23, #0x1               ; =1
    97ec:      	madd	x10, x28, x5, x24
    97f0:      	ldr	x28, [x10, #0x10]!
    97f4:      	cmp	x28, x27
    97f8:      	b.eq	0x9928 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x33c>
    97fc:      	cmp	x23, x27
    9800:      	b.hs	0x9844 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x258>
    9804:      	add	x23, x23, #0x1
    9808:      	cmp	x28, x27
    980c:      	b.lo	0x97ec <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x200>
    9810:      	b	0x9844 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x258>
    9814:      	eor	x10, x28, x14
    9818:      	eor	x10, x10, x10, lsr #30
    981c:      	mul	x10, x10, x9
    9820:      	eor	x10, x10, x10, lsr #27
    9824:      	mul	x10, x10, x8
    9828:      	eor	x10, x10, x10, lsr #31
    982c:      	udiv	x1, x10, x15
    9830:      	msub	x10, x1, x15, x10
    9834:      	ldr	x28, [x23, x10, lsl #3]
    9838:      	cmp	x28, x27
    983c:      	b.ne	0x97e4 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x1f8>
    9840:      	str	x22, [x23, x10, lsl #3]
    9844:      	mov	w10, #0x4309            ; =17161
    9848:      	madd	x10, x7, x10, x26
    984c:      	madd	x10, x25, x4, x10
    9850:      	add	x7, x10, #0x83
    9854:      	tbnz	w3, #0x0, 0x9748 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x15c>
    9858:      	eor	x10, x14, x21
    985c:      	eor	x10, x10, x10, lsr #30
    9860:      	mul	x10, x10, x9
    9864:      	eor	x10, x10, x10, lsr #27
    9868:      	mul	x10, x10, x8
    986c:      	eor	x10, x10, x10, lsr #31
    9870:      	add	x22, x20, x19
    9874:      	cbz	x15, 0x9694 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0xa8>
    9878:      	udiv	x1, x10, x15
    987c:      	msub	x23, x1, x15, x10
    9880:      	ldp	x24, x25, [x0, #0x10]
    9884:      	ldr	x26, [x24, x23, lsl #3]
    9888:      	cbz	x25, 0x98c8 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x2dc>
    988c:      	cmp	x26, x25
    9890:      	b.hs	0x98c8 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x2dc>
    9894:      	ldr	x27, [x0, #0x28]
    9898:      	mov	w28, #0x1               ; =1
    989c:      	mov	x10, x26
    98a0:      	madd	x10, x10, x5, x27
    98a4:      	ldr	x1, [x10]
    98a8:      	cmp	x1, x21
    98ac:      	b.eq	0x9910 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x324>
    98b0:      	cmp	x28, x25
    98b4:      	b.hs	0x98c8 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x2dc>
    98b8:      	ldr	x10, [x10, #0x10]
    98bc:      	add	x28, x28, #0x1
    98c0:      	cmp	x10, x25
    98c4:      	b.lo	0x98a0 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x2b4>
    98c8:      	cmp	x25, x16
    98cc:      	b.hs	0x9694 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0xa8>
    98d0:      	ldr	x10, [x0, #0x20]
    98d4:      	cmp	x25, x10
    98d8:      	b.hs	0x9694 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0xa8>
    98dc:      	ldr	x10, [x0, #0x28]
    98e0:      	madd	x10, x25, x5, x10
    98e4:      	stp	x21, x22, [x10]
    98e8:      	str	x26, [x10, #0x10]
    98ec:      	add	x10, x25, #0x1
    98f0:      	str	x10, [x0, #0x18]
    98f4:      	str	x25, [x24, x23, lsl #3]
    98f8:      	strb	wzr, [sp, #0xc]
    98fc:      	mul	x7, x7, x4
    9900:      	add	x19, x19, #0x1
    9904:      	cmp	x19, x12
    9908:      	b.ne	0x96b8 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0xcc>
    990c:      	b	0x966c <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x80>
    9910:      	ldr	x1, [x10, #0x8]
    9914:      	str	x22, [x10, #0x8]
    9918:      	strb	wzr, [sp, #0xc]
    991c:      	mov	w10, #0x1               ; =1
    9920:      	mov	x22, x1
    9924:      	b	0x96a0 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0xb4>
    9928:      	str	x22, [x10]
    992c:      	mov	w10, #0x4309            ; =17161
    9930:      	madd	x10, x7, x10, x26
    9934:      	madd	x10, x25, x4, x10
    9938:      	add	x7, x10, #0x83
    993c:      	tbnz	w3, #0x0, 0x9748 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x15c>
    9940:      	b	0x9858 <_wf_chain_mutation_batch$instance$c7c8cd11e7f079bd+0x26c>
    9944:      	ldr	x10, [sp]
    9948:      	add	x11, x11, x10
    994c:      	mov	x7, x20
    9950:      	str	x11, [x0, #0x50]
    9954:      	mov	x20, x7
    9958:      	eor	x10, x20, x20, lsr #30
    995c:      	mul	x9, x10, x9
    9960:      	eor	x9, x9, x9, lsr #27
    9964:      	mul	x8, x9, x8
    9968:      	eor	x0, x8, x8, lsr #31
    996c:      	ldp	x29, x30, [sp, #0x60]
    9970:      	ldp	x20, x19, [sp, #0x50]
    9974:      	ldp	x22, x21, [sp, #0x40]
    9978:      	ldp	x24, x23, [sp, #0x30]
    997c:      	ldp	x26, x25, [sp, #0x20]
    9980:      	ldp	x28, x27, [sp, #0x10]
    9984:      	add	sp, sp, #0x70
    9988:      	ret

000000000000998c <_wf_chain_mutation_geometry$instance$e194368921a477a7>:
    998c:      	ldr	x8, [x0]
    9990:      	ldr	x9, [x0, #0x18]
    9994:      	add	x0, x9, x8, lsl #32
    9998:      	ret

000000000000999c <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd>:
    999c:      	mov	x9, #0xe5b9             ; =58809
    99a0:      	movk	x9, #0x1ce4, lsl #16
    99a4:      	movk	x9, #0x476d, lsl #32
    99a8:      	movk	x9, #0xbf58, lsl #48
    99ac:      	mov	x8, #0x11eb             ; =4587
    99b0:      	movk	x8, #0x1331, lsl #16
    99b4:      	movk	x8, #0x49bb, lsl #32
    99b8:      	movk	x8, #0x94d0, lsl #48
    99bc:      	ldp	x1, x10, [x0, #0x40]
    99c0:      	cbz	x10, 0x9b34 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x198>
    99c4:      	stp	x20, x19, [sp, #-0x10]!
    99c8:      	mov	x11, #0x0               ; =0
    99cc:      	ldr	x12, [x0, #0x30]
    99d0:      	ldrb	w13, [x0, #0x38]
    99d4:      	mov	w14, #0x83              ; =131
    99d8:      	mov	w15, #0x18              ; =24
    99dc:      	mov	w16, #0x4309            ; =17161
    99e0:      	ldr	x17, [x0]
    99e4:      	b	0x99f8 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x5c>
    99e8:      	mul	x1, x1, x14
    99ec:      	add	x11, x11, #0x1
    99f0:      	cmp	x11, x10
    99f4:      	b.eq	0x9b30 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x194>
    99f8:      	mov	w2, #0x1                ; =1
    99fc:      	bfi	x2, x11, #1, #63
    9a00:      	tbz	w13, #0x0, 0x9a10 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x74>
    9a04:      	mov	x4, #0x0                ; =0
    9a08:      	cbnz	x17, 0x9a2c <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x90>
    9a0c:      	b	0x9a74 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0xd8>
    9a10:      	eor	x3, x12, x2
    9a14:      	eor	x3, x3, x3, lsr #30
    9a18:      	mul	x3, x3, x9
    9a1c:      	eor	x3, x3, x3, lsr #27
    9a20:      	mul	x3, x3, x8
    9a24:      	eor	x4, x3, x3, lsr #31
    9a28:      	cbz	x17, 0x9a74 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0xd8>
    9a2c:      	ldr	x3, [x0, #0x18]
    9a30:      	cbz	x3, 0x9a74 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0xd8>
    9a34:      	udiv	x5, x4, x17
    9a38:      	msub	x4, x5, x17, x4
    9a3c:      	ldr	x5, [x0, #0x10]
    9a40:      	add	x5, x5, x4, lsl #3
    9a44:      	mov	x4, x3
    9a48:      	ldr	x5, [x5]
    9a4c:      	cmp	x5, x3
    9a50:      	b.hs	0x9a74 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0xd8>
    9a54:      	ldr	x6, [x0, #0x28]
    9a58:      	madd	x7, x5, x15, x6
    9a5c:      	ldr	x19, [x7]
    9a60:      	cmp	x19, x2
    9a64:      	b.eq	0x9a90 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0xf4>
    9a68:      	add	x5, x7, #0x10
    9a6c:      	subs	x4, x4, #0x1
    9a70:      	b.ne	0x9a48 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0xac>
    9a74:      	mul	x1, x1, x14
    9a78:      	lsl	x2, x11, #1
    9a7c:      	add	x2, x2, #0x2
    9a80:      	tbz	w13, #0x0, 0x9aac <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x110>
    9a84:      	mov	x4, #0x0                ; =0
    9a88:      	cbnz	x17, 0x9ac8 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x12c>
    9a8c:      	b	0x99e8 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x4c>
    9a90:      	madd	x2, x5, x15, x6
    9a94:      	ldr	x2, [x2, #0x8]
    9a98:      	madd	x1, x1, x16, x2
    9a9c:      	add	x1, x1, #0x83
    9aa0:      	lsl	x2, x11, #1
    9aa4:      	add	x2, x2, #0x2
    9aa8:      	tbnz	w13, #0x0, 0x9a84 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0xe8>
    9aac:      	eor	x3, x12, x2
    9ab0:      	eor	x3, x3, x3, lsr #30
    9ab4:      	mul	x3, x3, x9
    9ab8:      	eor	x3, x3, x3, lsr #27
    9abc:      	mul	x3, x3, x8
    9ac0:      	eor	x4, x3, x3, lsr #31
    9ac4:      	cbz	x17, 0x99e8 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x4c>
    9ac8:      	ldr	x3, [x0, #0x18]
    9acc:      	cbz	x3, 0x99e8 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x4c>
    9ad0:      	udiv	x5, x4, x17
    9ad4:      	msub	x4, x5, x17, x4
    9ad8:      	ldr	x5, [x0, #0x10]
    9adc:      	add	x5, x5, x4, lsl #3
    9ae0:      	mov	x4, x3
    9ae4:      	ldr	x5, [x5]
    9ae8:      	cmp	x5, x3
    9aec:      	b.hs	0x99e8 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x4c>
    9af0:      	ldr	x6, [x0, #0x28]
    9af4:      	madd	x7, x5, x15, x6
    9af8:      	ldr	x19, [x7]
    9afc:      	cmp	x19, x2
    9b00:      	b.eq	0x9b14 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x178>
    9b04:      	add	x5, x7, #0x10
    9b08:      	subs	x4, x4, #0x1
    9b0c:      	b.ne	0x9ae4 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x148>
    9b10:      	b	0x99e8 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x4c>
    9b14:      	madd	x2, x5, x15, x6
    9b18:      	ldr	x2, [x2, #0x8]
    9b1c:      	madd	x1, x1, x16, x2
    9b20:      	add	x1, x1, #0x83
    9b24:      	add	x11, x11, #0x1
    9b28:      	cmp	x11, x10
    9b2c:      	b.ne	0x99f8 <_wf_chain_mutation_verify$instance$c7c8cd11e7f079bd+0x5c>
    9b30:      	ldp	x20, x19, [sp], #0x10
    9b34:      	eor	x10, x1, x1, lsr #30
    9b38:      	mul	x9, x10, x9
    9b3c:      	eor	x9, x9, x9, lsr #27
    9b40:      	mul	x8, x9, x8
    9b44:      	eor	x0, x8, x8, lsr #31
    9b48:      	ret

0000000000009b4c <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd>:
    9b4c:      	stp	x28, x27, [sp, #-0x60]!
    9b50:      	stp	x26, x25, [sp, #0x10]
    9b54:      	stp	x24, x23, [sp, #0x20]
    9b58:      	stp	x22, x21, [sp, #0x30]
    9b5c:      	stp	x20, x19, [sp, #0x40]
    9b60:      	stp	x29, x30, [sp, #0x50]
    9b64:      	mov	x8, x0
    9b68:      	mov	x22, #0xe5b9            ; =58809
    9b6c:      	movk	x22, #0x1ce4, lsl #16
    9b70:      	movk	x22, #0x476d, lsl #32
    9b74:      	movk	x22, #0xbf58, lsl #48
    9b78:      	mov	x21, #0x11eb            ; =4587
    9b7c:      	movk	x21, #0x1331, lsl #16
    9b80:      	movk	x21, #0x49bb, lsl #32
    9b84:      	movk	x21, #0x94d0, lsl #48
    9b88:      	ldp	x20, x9, [x0, #0x18]
    9b8c:      	ldr	x0, [x0, #0x28]
    9b90:      	cbz	x20, 0x9bac <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd+0x60>
    9b94:      	cmp	x20, #0x4
    9b98:      	b.hs	0x9bb8 <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd+0x6c>
    9b9c:      	mov	x23, #0x0               ; =0
    9ba0:      	mov	x24, #0x0               ; =0
    9ba4:      	mov	x10, x20
    9ba8:      	b	0x9cb0 <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd+0x164>
    9bac:      	mov	x23, #0x0               ; =0
    9bb0:      	mov	x24, #0x0               ; =0
    9bb4:      	b	0x9cec <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd+0x1a0>
    9bb8:      	mov	x16, #0x0               ; =0
    9bbc:      	mov	x17, #0x0               ; =0
    9bc0:      	mov	x1, #0x0                ; =0
    9bc4:      	mov	x2, #0x0                ; =0
    9bc8:      	mov	x12, #0x0               ; =0
    9bcc:      	mov	x13, #0x0               ; =0
    9bd0:      	mov	x14, #0x0               ; =0
    9bd4:      	mov	x15, #0x0               ; =0
    9bd8:      	and	x11, x20, #0xfffffffffffffffc
    9bdc:      	and	x10, x20, #0x3
    9be0:      	mov	w3, #0x18               ; =24
    9be4:      	madd	x3, x20, x3, x0
    9be8:      	sub	x3, x3, #0x30
    9bec:      	mov	w4, #0x83               ; =131
    9bf0:      	mov	x5, x11
    9bf4:      	ldp	x6, x7, [x3, #0x18]
    9bf8:      	ldp	x19, x23, [x3]
    9bfc:      	ldp	x24, x25, [x3, #-0x18]
    9c00:      	ldp	x26, x27, [x3, #-0x30]
    9c04:      	madd	x6, x6, x4, x7
    9c08:      	madd	x7, x19, x4, x23
    9c0c:      	madd	x19, x24, x4, x25
    9c10:      	madd	x23, x26, x4, x27
    9c14:      	add	x12, x6, x12
    9c18:      	add	x13, x7, x13
    9c1c:      	add	x14, x19, x14
    9c20:      	add	x15, x23, x15
    9c24:      	eor	x6, x6, x6, lsr #30
    9c28:      	eor	x7, x7, x7, lsr #30
    9c2c:      	eor	x19, x19, x19, lsr #30
    9c30:      	eor	x23, x23, x23, lsr #30
    9c34:      	mul	x6, x6, x22
    9c38:      	mul	x7, x7, x22
    9c3c:      	mul	x19, x19, x22
    9c40:      	mul	x23, x23, x22
    9c44:      	eor	x6, x6, x6, lsr #27
    9c48:      	eor	x7, x7, x7, lsr #27
    9c4c:      	eor	x19, x19, x19, lsr #27
    9c50:      	eor	x23, x23, x23, lsr #27
    9c54:      	mul	x6, x6, x21
    9c58:      	mul	x7, x7, x21
    9c5c:      	mul	x19, x19, x21
    9c60:      	eor	x16, x16, x6, lsr #31
    9c64:      	mul	x23, x23, x21
    9c68:      	eor	x17, x17, x7, lsr #31
    9c6c:      	eor	x1, x1, x19, lsr #31
    9c70:      	eor	x2, x2, x23, lsr #31
    9c74:      	eor	x16, x16, x6
    9c78:      	eor	x17, x17, x7
    9c7c:      	eor	x1, x1, x19
    9c80:      	eor	x2, x2, x23
    9c84:      	sub	x3, x3, #0x60
    9c88:      	sub	x5, x5, #0x4
    9c8c:      	cbnz	x5, 0x9bf4 <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd+0xa8>
    9c90:      	eor	x16, x17, x16
    9c94:      	eor	x17, x2, x1
    9c98:      	eor	x23, x17, x16
    9c9c:      	add	x12, x13, x12
    9ca0:      	add	x13, x15, x14
    9ca4:      	add	x24, x13, x12
    9ca8:      	cmp	x20, x11
    9cac:      	b.eq	0x9cec <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd+0x1a0>
    9cb0:      	mov	w11, #0x18              ; =24
    9cb4:      	madd	x11, x10, x11, x0
    9cb8:      	sub	x11, x11, #0x18
    9cbc:      	mov	w12, #0x83              ; =131
    9cc0:      	ldp	x13, x14, [x11], #-0x18
    9cc4:      	madd	x13, x13, x12, x14
    9cc8:      	add	x24, x13, x24
    9ccc:      	eor	x13, x13, x13, lsr #30
    9cd0:      	mul	x13, x13, x22
    9cd4:      	eor	x13, x13, x13, lsr #27
    9cd8:      	mul	x13, x13, x21
    9cdc:      	eor	x14, x23, x13, lsr #31
    9ce0:      	eor	x23, x14, x13
    9ce4:      	sub	x10, x10, #0x1
    9ce8:      	cbnz	x10, 0x9cc0 <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd+0x174>
    9cec:      	ldp	x26, x19, [x8, #0x8]
    9cf0:      	ldr	x25, [x8, #0x40]
    9cf4:      	cbz	x9, 0x9cfc <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd+0x1b0>
    9cf8:      	bl	0x9cf8 <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd+0x1ac>
		0000000000009cf8:  ARM64_RELOC_BRANCH26	_free
    9cfc:      	cbz	x26, 0x9d08 <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd+0x1bc>
    9d00:      	mov	x0, x19
    9d04:      	bl	0x9d04 <_wf_chain_mutation_finish$instance$c7c8cd11e7f079bd+0x1b8>
		0000000000009d04:  ARM64_RELOC_BRANCH26	_free
    9d08:      	eor	x8, x25, x25, lsr #30
    9d0c:      	mul	x8, x8, x22
    9d10:      	eor	x8, x8, x8, lsr #27
    9d14:      	mul	x8, x8, x21
    9d18:      	eor	x9, x24, x24, lsr #30
    9d1c:      	mul	x9, x9, x22
    9d20:      	eor	x9, x9, x9, lsr #27
    9d24:      	mul	x9, x9, x21
    9d28:      	eor	x10, x9, x8
    9d2c:      	mov	x11, #0x7c15            ; =31765
    9d30:      	movk	x11, #0x7f4a, lsl #16
    9d34:      	movk	x11, #0x79b9, lsl #32
    9d38:      	movk	x11, #0x9e37, lsl #48
    9d3c:      	mul	x11, x20, x11
    9d40:      	eor	x11, x11, x23
    9d44:      	eor	x10, x11, x10, lsr #31
    9d48:      	eor	x8, x8, x9
    9d4c:      	eor	x0, x10, x8
    9d50:      	ldp	x29, x30, [sp, #0x50]
    9d54:      	ldp	x20, x19, [sp, #0x40]
    9d58:      	ldp	x22, x21, [sp, #0x30]
    9d5c:      	ldp	x24, x23, [sp, #0x20]
    9d60:      	ldp	x26, x25, [sp, #0x10]
    9d64:      	ldp	x28, x27, [sp], #0x60
    9d68:      	ret

0000000000009d6c <_wf_chain_mutation_prepare$instance$4250cb78d3f44027>:
    9d6c:      	stp	x26, x25, [sp, #-0x50]!
    9d70:      	stp	x24, x23, [sp, #0x10]
    9d74:      	stp	x22, x21, [sp, #0x20]
    9d78:      	stp	x20, x19, [sp, #0x30]
    9d7c:      	stp	x29, x30, [sp, #0x40]
    9d80:      	sub	sp, sp, #0x340
    9d84:      	mov	x21, x3
    9d88:      	mov	x20, x2
    9d8c:      	mov	x22, x1
    9d90:      	mov	x19, x0
    9d94:      	mov	x8, #0x7c15             ; =31765
    9d98:      	movk	x8, #0x7f4a, lsl #16
    9d9c:      	movk	x8, #0x79b9, lsl #32
    9da0:      	movk	x8, #0x9e37, lsl #48
    9da4:      	eor	x8, x3, x8
    9da8:      	str	x8, [sp, #0x120]
    9dac:      	strb	wzr, [sp, #0x128]
    9db0:      	cbz	x1, 0x9df8 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x8c>
    9db4:      	lsl	x24, x22, #3
    9db8:      	mov	x0, x24
    9dbc:      	bl	0x9dbc <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x50>
		0000000000009dbc:  ARM64_RELOC_BRANCH26	_malloc
    9dc0:      	cbz	x0, 0x9ff4 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x288>
    9dc4:      	mov	x23, x0
    9dc8:      	mov	w1, #0xff               ; =255
    9dcc:      	mov	x2, x24
    9dd0:      	bl	0x9dd0 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x64>
		0000000000009dd0:  ARM64_RELOC_BRANCH26	_memset
    9dd4:      	add	x8, x22, x22, lsl #4
    9dd8:      	lsl	x0, x8, #4
    9ddc:      	bl	0x9ddc <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x70>
		0000000000009ddc:  ARM64_RELOC_BRANCH26	_malloc
    9de0:      	cbz	x0, 0x9ff4 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x288>
    9de4:      	stp	x22, x22, [sp, #0xf0]
    9de8:      	stp	x23, xzr, [sp, #0x100]
    9dec:      	stp	x22, x0, [sp, #0x110]
    9df0:      	cbnz	x20, 0x9e10 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0xa4>
    9df4:      	b	0x9fc0 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x254>
    9df8:      	adrp	x23, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x4a4>
		0000000000009df8:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    9dfc:      	add	x23, x23, #0x0
		0000000000009dfc:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    9e00:      	stp	x22, x22, [sp, #0xf0]
    9e04:      	stp	x23, xzr, [sp, #0x100]
    9e08:      	stp	x22, x23, [sp, #0x110]
    9e0c:      	cbz	x20, 0x9fc0 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x254>
    9e10:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x4a4>
		0000000000009e10:  ARM64_RELOC_PAGE21	lCPI103_0
    9e14:      	ldr	q0, [x8]
		0000000000009e14:  ARM64_RELOC_PAGEOFF12	lCPI103_0
    9e18:      	str	q0, [sp, #0xe0]
    9e1c:      	add	x23, sp, #0x240
    9e20:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x4a4>
		0000000000009e20:  ARM64_RELOC_PAGE21	lCPI103_1
    9e24:      	ldr	q0, [x8]
		0000000000009e24:  ARM64_RELOC_PAGEOFF12	lCPI103_1
    9e28:      	str	q0, [sp, #0xd0]
    9e2c:      	mov	w22, #0x1               ; =1
    9e30:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x4a4>
		0000000000009e30:  ARM64_RELOC_PAGE21	lCPI103_2
    9e34:      	ldr	q0, [x8]
		0000000000009e34:  ARM64_RELOC_PAGEOFF12	lCPI103_2
    9e38:      	str	q0, [sp, #0xc0]
    9e3c:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x4a4>
		0000000000009e3c:  ARM64_RELOC_PAGE21	lCPI103_3
    9e40:      	ldr	q0, [x8]
		0000000000009e40:  ARM64_RELOC_PAGEOFF12	lCPI103_3
    9e44:      	str	q0, [sp, #0xb0]
    9e48:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x4a4>
		0000000000009e48:  ARM64_RELOC_PAGE21	lCPI103_4
    9e4c:      	ldr	q0, [x8]
		0000000000009e4c:  ARM64_RELOC_PAGEOFF12	lCPI103_4
    9e50:      	str	q0, [sp, #0xa0]
    9e54:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x4a4>
		0000000000009e54:  ARM64_RELOC_PAGE21	lCPI103_5
    9e58:      	ldr	q0, [x8]
		0000000000009e58:  ARM64_RELOC_PAGEOFF12	lCPI103_5
    9e5c:      	str	q0, [sp, #0x90]
    9e60:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x4a4>
		0000000000009e60:  ARM64_RELOC_PAGE21	lCPI103_6
    9e64:      	ldr	q0, [x8]
		0000000000009e64:  ARM64_RELOC_PAGEOFF12	lCPI103_6
    9e68:      	str	q0, [sp, #0x80]
    9e6c:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x4a4>
		0000000000009e6c:  ARM64_RELOC_PAGE21	lCPI103_7
    9e70:      	ldr	q0, [x8]
		0000000000009e70:  ARM64_RELOC_PAGEOFF12	lCPI103_7
    9e74:      	str	q0, [sp, #0x70]
    9e78:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x4a4>
		0000000000009e78:  ARM64_RELOC_PAGE21	lCPI103_8
    9e7c:      	ldr	q0, [x8]
		0000000000009e7c:  ARM64_RELOC_PAGEOFF12	lCPI103_8
    9e80:      	str	q0, [sp, #0x60]
    9e84:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x4a4>
		0000000000009e84:  ARM64_RELOC_PAGE21	lCPI103_9
    9e88:      	ldr	q0, [x8]
		0000000000009e88:  ARM64_RELOC_PAGEOFF12	lCPI103_9
    9e8c:      	str	q0, [sp, #0x50]
    9e90:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x4a4>
		0000000000009e90:  ARM64_RELOC_PAGE21	lCPI103_10
    9e94:      	ldr	q0, [x8]
		0000000000009e94:  ARM64_RELOC_PAGEOFF12	lCPI103_10
    9e98:      	str	q0, [sp, #0x40]
    9e9c:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x4a4>
		0000000000009e9c:  ARM64_RELOC_PAGE21	lCPI103_11
    9ea0:      	ldr	q0, [x8]
		0000000000009ea0:  ARM64_RELOC_PAGEOFF12	lCPI103_11
    9ea4:      	str	q0, [sp, #0x30]
    9ea8:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x4a4>
		0000000000009ea8:  ARM64_RELOC_PAGE21	lCPI103_12
    9eac:      	ldr	q0, [x8]
		0000000000009eac:  ARM64_RELOC_PAGEOFF12	lCPI103_12
    9eb0:      	str	q0, [sp, #0x20]
    9eb4:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x4a4>
		0000000000009eb4:  ARM64_RELOC_PAGE21	lCPI103_13
    9eb8:      	ldr	q0, [x8]
		0000000000009eb8:  ARM64_RELOC_PAGEOFF12	lCPI103_13
    9ebc:      	str	q0, [sp, #0x10]
    9ec0:      	mov	x24, x20
    9ec4:      	adrp	x8, 0x9000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x4a4>
		0000000000009ec4:  ARM64_RELOC_PAGE21	lCPI103_14
    9ec8:      	ldr	q0, [x8]
		0000000000009ec8:  ARM64_RELOC_PAGEOFF12	lCPI103_14
    9ecc:      	str	q0, [sp]
    9ed0:      	mov	x25, x21
    9ed4:      	dup.2d	v0, x25
    9ed8:      	add	x8, x25, #0x1f
    9edc:      	ldr	q1, [sp, #0xe0]
    9ee0:      	add.2d	v1, v0, v1
    9ee4:      	stur	q1, [x23, #0x8]
    9ee8:      	ldr	q1, [sp, #0xd0]
    9eec:      	add.2d	v1, v0, v1
    9ef0:      	stur	q1, [x23, #0x18]
    9ef4:      	ldr	q1, [sp, #0xc0]
    9ef8:      	add.2d	v1, v0, v1
    9efc:      	stur	q1, [x23, #0x28]
    9f00:      	ldr	q1, [sp, #0xb0]
    9f04:      	add.2d	v1, v0, v1
    9f08:      	stur	q1, [x23, #0x38]
    9f0c:      	ldr	q1, [sp, #0xa0]
    9f10:      	add.2d	v1, v0, v1
    9f14:      	stur	q1, [x23, #0x48]
    9f18:      	ldr	q1, [sp, #0x90]
    9f1c:      	add.2d	v1, v0, v1
    9f20:      	stur	q1, [x23, #0x58]
    9f24:      	ldr	q1, [sp, #0x80]
    9f28:      	add.2d	v1, v0, v1
    9f2c:      	stur	q1, [x23, #0x68]
    9f30:      	ldr	q1, [sp, #0x70]
    9f34:      	add.2d	v1, v0, v1
    9f38:      	stur	q1, [x23, #0x78]
    9f3c:      	ldr	q1, [sp, #0x60]
    9f40:      	add.2d	v1, v0, v1
    9f44:      	stur	q1, [x23, #0x88]
    9f48:      	ldr	q1, [sp, #0x50]
    9f4c:      	add.2d	v1, v0, v1
    9f50:      	stur	q1, [x23, #0x98]
    9f54:      	ldr	q1, [sp, #0x40]
    9f58:      	add.2d	v1, v0, v1
    9f5c:      	stur	q1, [x23, #0xa8]
    9f60:      	ldr	q1, [sp, #0x30]
    9f64:      	add.2d	v1, v0, v1
    9f68:      	stur	q1, [x23, #0xb8]
    9f6c:      	ldr	q1, [sp, #0x20]
    9f70:      	add.2d	v1, v0, v1
    9f74:      	stur	q1, [x23, #0xc8]
    9f78:      	ldr	q1, [sp, #0x10]
    9f7c:      	add.2d	v1, v0, v1
    9f80:      	stur	q1, [x23, #0xd8]
    9f84:      	ldr	q1, [sp]
    9f88:      	add.2d	v0, v0, v1
    9f8c:      	stur	q0, [x23, #0xe8]
    9f90:      	str	x25, [sp, #0x240]
    9f94:      	str	x8, [sp, #0x338]
    9f98:      	add	x0, sp, #0x130
    9f9c:      	add	x1, sp, #0xf0
    9fa0:      	add	x3, sp, #0x240
    9fa4:      	add	x4, sp, #0x120
    9fa8:      	mov	x2, x22
    9fac:      	bl	0x9fac <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x240>
		0000000000009fac:  ARM64_RELOC_BRANCH26	_wf_full_chain_try_put$instance$58dd6ca826103b6d
    9fb0:      	add	x25, x25, #0x1
    9fb4:      	add	x22, x22, #0x2
    9fb8:      	subs	x24, x24, #0x1
    9fbc:      	b.ne	0x9ed4 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x168>
    9fc0:      	ldp	q0, q1, [sp, #0xf0]
    9fc4:      	stp	q0, q1, [x19]
    9fc8:      	ldp	q0, q1, [sp, #0x110]
    9fcc:      	stp	q0, q1, [x19, #0x20]
    9fd0:      	stp	x21, x20, [x19, #0x40]
    9fd4:      	str	xzr, [x19, #0x50]
    9fd8:      	add	sp, sp, #0x340
    9fdc:      	ldp	x29, x30, [sp, #0x40]
    9fe0:      	ldp	x20, x19, [sp, #0x30]
    9fe4:      	ldp	x22, x21, [sp, #0x20]
    9fe8:      	ldp	x24, x23, [sp, #0x10]
    9fec:      	ldp	x26, x25, [sp], #0x50
    9ff0:      	ret
    9ff4:      	bl	0x9ff4 <_wf_chain_mutation_prepare$instance$4250cb78d3f44027+0x288>
		0000000000009ff4:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

0000000000009ff8 <_wf_chain_mutation_batch$instance$4250cb78d3f44027>:
    9ff8:      	stp	x28, x27, [sp, #-0x60]!
    9ffc:      	stp	x26, x25, [sp, #0x10]
    a000:      	stp	x24, x23, [sp, #0x20]
    a004:      	stp	x22, x21, [sp, #0x30]
    a008:      	stp	x20, x19, [sp, #0x40]
    a00c:      	stp	x29, x30, [sp, #0x50]
    a010:      	sub	sp, sp, #0x440
    a014:      	ldr	x23, [x0, #0x40]
    a018:      	str	x1, [sp, #0x10]
    a01c:      	cbz	x1, 0xa480 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x488>
    a020:      	mov	x19, x0
    a024:      	ldr	x27, [x0, #0x48]
    a028:      	cbz	x27, 0xa470 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x478>
    a02c:      	mov	x21, x2
    a030:      	mov	x24, #0x0               ; =0
    a034:      	ldr	x25, [x19, #0x50]
    a038:      	add	x26, sp, #0x230
    a03c:      	adrp	x8, 0xa000 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x8>
		000000000000a03c:  ARM64_RELOC_PAGE21	lCPI104_0
    a040:      	ldr	q0, [x8]
		000000000000a040:  ARM64_RELOC_PAGEOFF12	lCPI104_0
    a044:      	str	q0, [sp, #0x100]
    a048:      	add	x9, x25, #0x1
    a04c:      	adrp	x8, 0xa000 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x8>
		000000000000a04c:  ARM64_RELOC_PAGE21	lCPI104_1
    a050:      	ldr	q0, [x8]
		000000000000a050:  ARM64_RELOC_PAGEOFF12	lCPI104_1
    a054:      	str	q0, [sp, #0xf0]
    a058:      	adrp	x8, 0xa000 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x8>
		000000000000a058:  ARM64_RELOC_PAGE21	lCPI104_2
    a05c:      	ldr	q0, [x8]
		000000000000a05c:  ARM64_RELOC_PAGEOFF12	lCPI104_2
    a060:      	str	q0, [sp, #0xe0]
    a064:      	adrp	x8, 0xa000 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x8>
		000000000000a064:  ARM64_RELOC_PAGE21	lCPI104_3
    a068:      	ldr	q0, [x8]
		000000000000a068:  ARM64_RELOC_PAGEOFF12	lCPI104_3
    a06c:      	str	q0, [sp, #0xd0]
    a070:      	adrp	x8, 0xa000 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x8>
		000000000000a070:  ARM64_RELOC_PAGE21	lCPI104_4
    a074:      	ldr	q0, [x8]
		000000000000a074:  ARM64_RELOC_PAGEOFF12	lCPI104_4
    a078:      	str	q0, [sp, #0xc0]
    a07c:      	adrp	x8, 0xa000 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x8>
		000000000000a07c:  ARM64_RELOC_PAGE21	lCPI104_5
    a080:      	ldr	q0, [x8]
		000000000000a080:  ARM64_RELOC_PAGEOFF12	lCPI104_5
    a084:      	str	q0, [sp, #0xb0]
    a088:      	adrp	x8, 0xa000 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x8>
		000000000000a088:  ARM64_RELOC_PAGE21	lCPI104_6
    a08c:      	ldr	q0, [x8]
		000000000000a08c:  ARM64_RELOC_PAGEOFF12	lCPI104_6
    a090:      	str	q0, [sp, #0xa0]
    a094:      	adrp	x8, 0xa000 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x8>
		000000000000a094:  ARM64_RELOC_PAGE21	lCPI104_7
    a098:      	ldr	q0, [x8]
		000000000000a098:  ARM64_RELOC_PAGEOFF12	lCPI104_7
    a09c:      	str	q0, [sp, #0x90]
    a0a0:      	adrp	x8, 0xa000 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x8>
		000000000000a0a0:  ARM64_RELOC_PAGE21	lCPI104_8
    a0a4:      	ldr	q0, [x8]
		000000000000a0a4:  ARM64_RELOC_PAGEOFF12	lCPI104_8
    a0a8:      	str	q0, [sp, #0x80]
    a0ac:      	adrp	x8, 0xa000 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x8>
		000000000000a0ac:  ARM64_RELOC_PAGE21	lCPI104_9
    a0b0:      	ldr	q0, [x8]
		000000000000a0b0:  ARM64_RELOC_PAGEOFF12	lCPI104_9
    a0b4:      	str	q0, [sp, #0x70]
    a0b8:      	adrp	x8, 0xa000 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x8>
		000000000000a0b8:  ARM64_RELOC_PAGE21	lCPI104_10
    a0bc:      	ldr	q0, [x8]
		000000000000a0bc:  ARM64_RELOC_PAGEOFF12	lCPI104_10
    a0c0:      	str	q0, [sp, #0x60]
    a0c4:      	adrp	x8, 0xa000 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x8>
		000000000000a0c4:  ARM64_RELOC_PAGE21	lCPI104_11
    a0c8:      	ldr	q0, [x8]
		000000000000a0c8:  ARM64_RELOC_PAGEOFF12	lCPI104_11
    a0cc:      	str	q0, [sp, #0x50]
    a0d0:      	adrp	x8, 0xa000 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x8>
		000000000000a0d0:  ARM64_RELOC_PAGE21	lCPI104_12
    a0d4:      	ldr	q0, [x8]
		000000000000a0d4:  ARM64_RELOC_PAGEOFF12	lCPI104_12
    a0d8:      	str	q0, [sp, #0x40]
    a0dc:      	adrp	x8, 0xa000 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x8>
		000000000000a0dc:  ARM64_RELOC_PAGE21	lCPI104_13
    a0e0:      	ldr	q0, [x8]
		000000000000a0e0:  ARM64_RELOC_PAGEOFF12	lCPI104_13
    a0e4:      	str	q0, [sp, #0x30]
    a0e8:      	mov	w28, #0x83              ; =131
    a0ec:      	adrp	x8, 0xa000 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x8>
		000000000000a0ec:  ARM64_RELOC_PAGE21	lCPI104_14
    a0f0:      	ldr	q0, [x8]
		000000000000a0f0:  ARM64_RELOC_PAGEOFF12	lCPI104_14
    a0f4:      	str	q0, [sp, #0x20]
    a0f8:      	str	x9, [sp, #0x18]
    a0fc:      	cbz	x27, 0xa440 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x448>
    a100:      	ldr	x8, [x19, #0x40]
    a104:      	madd	x20, x27, x9, x8
    a108:      	mov	w22, #0x1               ; =1
    a10c:      	b	0xa304 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x30c>
    a110:      	mul	x23, x23, x28
    a114:      	dup.2d	v0, x20
    a118:      	add	x8, x20, #0x1f
    a11c:      	ldr	q1, [sp, #0x100]
    a120:      	add.2d	v1, v0, v1
    a124:      	stur	q1, [x26, #0x8]
    a128:      	ldr	q1, [sp, #0xf0]
    a12c:      	add.2d	v1, v0, v1
    a130:      	stur	q1, [x26, #0x18]
    a134:      	ldr	q1, [sp, #0xe0]
    a138:      	add.2d	v1, v0, v1
    a13c:      	stur	q1, [x26, #0x28]
    a140:      	ldr	q1, [sp, #0xd0]
    a144:      	add.2d	v1, v0, v1
    a148:      	stur	q1, [x26, #0x38]
    a14c:      	ldr	q1, [sp, #0xc0]
    a150:      	add.2d	v1, v0, v1
    a154:      	stur	q1, [x26, #0x48]
    a158:      	ldr	q1, [sp, #0xb0]
    a15c:      	add.2d	v1, v0, v1
    a160:      	stur	q1, [x26, #0x58]
    a164:      	ldr	q1, [sp, #0xa0]
    a168:      	add.2d	v1, v0, v1
    a16c:      	stur	q1, [x26, #0x68]
    a170:      	ldr	q1, [sp, #0x90]
    a174:      	add.2d	v1, v0, v1
    a178:      	stur	q1, [x26, #0x78]
    a17c:      	ldr	q1, [sp, #0x80]
    a180:      	add.2d	v1, v0, v1
    a184:      	stur	q1, [x26, #0x88]
    a188:      	ldr	q1, [sp, #0x70]
    a18c:      	add.2d	v1, v0, v1
    a190:      	stur	q1, [x26, #0x98]
    a194:      	ldr	q1, [sp, #0x60]
    a198:      	add.2d	v1, v0, v1
    a19c:      	stur	q1, [x26, #0xa8]
    a1a0:      	ldr	q1, [sp, #0x50]
    a1a4:      	add.2d	v1, v0, v1
    a1a8:      	stur	q1, [x26, #0xb8]
    a1ac:      	ldr	q1, [sp, #0x40]
    a1b0:      	add.2d	v1, v0, v1
    a1b4:      	stur	q1, [x26, #0xc8]
    a1b8:      	ldr	q1, [sp, #0x30]
    a1bc:      	add.2d	v1, v0, v1
    a1c0:      	stur	q1, [x26, #0xd8]
    a1c4:      	ldr	q1, [sp, #0x20]
    a1c8:      	add.2d	v0, v0, v1
    a1cc:      	stur	q0, [x26, #0xe8]
    a1d0:      	str	x20, [sp, #0x230]
    a1d4:      	str	x8, [sp, #0x328]
    a1d8:      	add	x0, sp, #0x120
    a1dc:      	add	x3, sp, #0x230
    a1e0:      	add	x4, x19, #0x30
    a1e4:      	mov	x1, x19
    a1e8:      	mov	x2, x22
    a1ec:      	bl	0xa1ec <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x1f4>
		000000000000a1ec:  ARM64_RELOC_BRANCH26	_wf_full_chain_try_put$instance$58dd6ca826103b6d
    a1f0:      	ldr	w8, [sp, #0x120]
    a1f4:      	cbz	w8, 0xa2f0 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x2f8>
    a1f8:      	ldrb	w8, [sp, #0x124]
    a1fc:      	tst	w8, #0x1
    a200:      	ldp	x9, x8, [sp, #0x128]
    a204:      	madd	x8, x9, x28, x8
    a208:      	ldp	x10, x9, [sp, #0x138]
    a20c:      	madd	x8, x8, x28, x10
    a210:      	madd	x8, x8, x28, x9
    a214:      	ldp	x10, x9, [sp, #0x148]
    a218:      	madd	x8, x8, x28, x10
    a21c:      	madd	x8, x8, x28, x9
    a220:      	ldp	x10, x9, [sp, #0x158]
    a224:      	madd	x8, x8, x28, x10
    a228:      	madd	x8, x8, x28, x9
    a22c:      	ldp	x10, x9, [sp, #0x168]
    a230:      	madd	x8, x8, x28, x10
    a234:      	madd	x8, x8, x28, x9
    a238:      	ldp	x10, x9, [sp, #0x178]
    a23c:      	madd	x8, x8, x28, x10
    a240:      	madd	x8, x8, x28, x9
    a244:      	ldp	x10, x9, [sp, #0x188]
    a248:      	madd	x8, x8, x28, x10
    a24c:      	madd	x8, x8, x28, x9
    a250:      	ldp	x10, x9, [sp, #0x198]
    a254:      	madd	x8, x8, x28, x10
    a258:      	madd	x8, x8, x28, x9
    a25c:      	ldp	x10, x9, [sp, #0x1a8]
    a260:      	madd	x8, x8, x28, x10
    a264:      	madd	x8, x8, x28, x9
    a268:      	ldp	x10, x9, [sp, #0x1b8]
    a26c:      	madd	x8, x8, x28, x10
    a270:      	madd	x8, x8, x28, x9
    a274:      	ldp	x10, x9, [sp, #0x1c8]
    a278:      	madd	x8, x8, x28, x10
    a27c:      	madd	x8, x8, x28, x9
    a280:      	ldp	x10, x9, [sp, #0x1d8]
    a284:      	madd	x8, x8, x28, x10
    a288:      	madd	x8, x8, x28, x9
    a28c:      	ldp	x10, x9, [sp, #0x1e8]
    a290:      	madd	x8, x8, x28, x10
    a294:      	madd	x8, x8, x28, x9
    a298:      	ldp	x10, x9, [sp, #0x1f8]
    a29c:      	madd	x8, x8, x28, x10
    a2a0:      	madd	x8, x8, x28, x9
    a2a4:      	ldr	x9, [sp, #0x208]
    a2a8:      	madd	x8, x8, x28, x9
    a2ac:      	ldr	x9, [sp, #0x210]
    a2b0:      	madd	x8, x8, x28, x9
    a2b4:      	ldr	x9, [sp, #0x218]
    a2b8:      	add	x9, x9, x23
    a2bc:      	ldr	x10, [sp, #0x220]
    a2c0:      	madd	x8, x8, x28, x9
    a2c4:      	mov	w9, #0x1                ; =1
    a2c8:      	cinc	x9, x9, ne
    a2cc:      	add	x9, x9, x10
    a2d0:      	madd	x8, x8, x28, x9
    a2d4:      	ldr	x9, [sp, #0x228]
    a2d8:      	madd	x23, x8, x28, x9
    a2dc:      	add	x20, x20, #0x1
    a2e0:      	add	x22, x22, #0x2
    a2e4:      	subs	x27, x27, #0x1
    a2e8:      	b.ne	0xa304 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x30c>
    a2ec:      	b	0xa440 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x448>
    a2f0:      	mul	x23, x23, x28
    a2f4:      	add	x20, x20, #0x1
    a2f8:      	add	x22, x22, #0x2
    a2fc:      	subs	x27, x27, #0x1
    a300:      	b.eq	0xa440 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x448>
    a304:      	str	x22, [sp, #0x118]
    a308:      	cbz	x21, 0xa114 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x11c>
    a30c:      	add	x0, sp, #0x330
    a310:      	add	x2, sp, #0x118
    a314:      	add	x3, x19, #0x30
    a318:      	mov	x1, x19
    a31c:      	bl	0xa31c <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x324>
		000000000000a31c:  ARM64_RELOC_BRANCH26	_wf_full_chain_remove$instance$58dd6ca826103b6d
    a320:      	ldr	w8, [sp, #0x330]
    a324:      	cmp	w8, #0x1
    a328:      	b.ne	0xa110 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x118>
    a32c:      	ldr	x8, [sp, #0x338]
    a330:      	ldr	x9, [sp, #0x340]
    a334:      	madd	x8, x8, x28, x9
    a338:      	ldr	x9, [sp, #0x348]
    a33c:      	ldr	x10, [sp, #0x350]
    a340:      	madd	x8, x8, x28, x9
    a344:      	madd	x8, x8, x28, x10
    a348:      	ldr	x9, [sp, #0x358]
    a34c:      	ldr	x10, [sp, #0x360]
    a350:      	madd	x8, x8, x28, x9
    a354:      	madd	x8, x8, x28, x10
    a358:      	ldr	x9, [sp, #0x368]
    a35c:      	ldr	x10, [sp, #0x370]
    a360:      	madd	x8, x8, x28, x9
    a364:      	madd	x8, x8, x28, x10
    a368:      	ldr	x9, [sp, #0x378]
    a36c:      	ldr	x10, [sp, #0x380]
    a370:      	madd	x8, x8, x28, x9
    a374:      	madd	x8, x8, x28, x10
    a378:      	ldr	x9, [sp, #0x388]
    a37c:      	ldr	x10, [sp, #0x390]
    a380:      	madd	x8, x8, x28, x9
    a384:      	madd	x8, x8, x28, x10
    a388:      	ldr	x9, [sp, #0x398]
    a38c:      	ldr	x10, [sp, #0x3a0]
    a390:      	madd	x8, x8, x28, x9
    a394:      	madd	x8, x8, x28, x10
    a398:      	ldr	x9, [sp, #0x3a8]
    a39c:      	ldr	x10, [sp, #0x3b0]
    a3a0:      	madd	x8, x8, x28, x9
    a3a4:      	madd	x8, x8, x28, x10
    a3a8:      	ldr	x9, [sp, #0x3b8]
    a3ac:      	ldr	x10, [sp, #0x3c0]
    a3b0:      	madd	x8, x8, x28, x9
    a3b4:      	madd	x8, x8, x28, x10
    a3b8:      	ldr	x9, [sp, #0x3c8]
    a3bc:      	ldr	x10, [sp, #0x3d0]
    a3c0:      	madd	x8, x8, x28, x9
    a3c4:      	madd	x8, x8, x28, x10
    a3c8:      	ldr	x9, [sp, #0x3d8]
    a3cc:      	ldr	x10, [sp, #0x3e0]
    a3d0:      	madd	x8, x8, x28, x9
    a3d4:      	madd	x8, x8, x28, x10
    a3d8:      	ldr	x9, [sp, #0x3e8]
    a3dc:      	ldr	x10, [sp, #0x3f0]
    a3e0:      	madd	x8, x8, x28, x9
    a3e4:      	madd	x8, x8, x28, x10
    a3e8:      	ldr	x9, [sp, #0x3f8]
    a3ec:      	ldr	x10, [sp, #0x400]
    a3f0:      	madd	x8, x8, x28, x9
    a3f4:      	madd	x8, x8, x28, x10
    a3f8:      	ldr	x9, [sp, #0x408]
    a3fc:      	ldr	x10, [sp, #0x410]
    a400:      	madd	x8, x8, x28, x9
    a404:      	madd	x8, x8, x28, x10
    a408:      	ldr	x9, [sp, #0x418]
    a40c:      	ldr	x10, [sp, #0x420]
    a410:      	madd	x8, x8, x28, x9
    a414:      	madd	x8, x8, x28, x10
    a418:      	ldr	x9, [sp, #0x428]
    a41c:      	ldr	x10, [sp, #0x430]
    a420:      	madd	x8, x8, x28, x9
    a424:      	madd	x8, x8, x28, x10
    a428:      	ldr	x9, [sp, #0x438]
    a42c:      	mov	w10, #0x4309            ; =17161
    a430:      	madd	x9, x23, x10, x9
    a434:      	madd	x8, x8, x28, x9
    a438:      	add	x23, x8, #0x83
    a43c:      	b	0xa114 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x11c>
    a440:      	add	x25, x25, #0x1
    a444:      	str	x25, [x19, #0x50]
    a448:      	add	x24, x24, #0x1
    a44c:      	ldr	x8, [sp, #0x10]
    a450:      	cmp	x24, x8
    a454:      	b.eq	0xa480 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x488>
    a458:      	ldr	x27, [x19, #0x48]
    a45c:      	ldr	x9, [sp, #0x18]
    a460:      	add	x9, x9, #0x1
    a464:      	str	x9, [sp, #0x18]
    a468:      	cbnz	x27, 0xa100 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x108>
    a46c:      	b	0xa440 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x448>
    a470:      	ldr	x8, [x19, #0x50]
    a474:      	ldr	x9, [sp, #0x10]
    a478:      	add	x8, x8, x9
    a47c:      	str	x8, [x19, #0x50]
    a480:      	eor	x8, x23, x23, lsr #30
    a484:      	mov	x9, #0xe5b9             ; =58809
    a488:      	movk	x9, #0x1ce4, lsl #16
    a48c:      	movk	x9, #0x476d, lsl #32
    a490:      	movk	x9, #0xbf58, lsl #48
    a494:      	mul	x8, x8, x9
    a498:      	eor	x8, x8, x8, lsr #27
    a49c:      	mov	x9, #0x11eb             ; =4587
    a4a0:      	movk	x9, #0x1331, lsl #16
    a4a4:      	movk	x9, #0x49bb, lsl #32
    a4a8:      	movk	x9, #0x94d0, lsl #48
    a4ac:      	mul	x8, x8, x9
    a4b0:      	eor	x0, x8, x8, lsr #31
    a4b4:      	add	sp, sp, #0x440
    a4b8:      	ldp	x29, x30, [sp, #0x50]
    a4bc:      	ldp	x20, x19, [sp, #0x40]
    a4c0:      	ldp	x22, x21, [sp, #0x30]
    a4c4:      	ldp	x24, x23, [sp, #0x20]
    a4c8:      	ldp	x26, x25, [sp, #0x10]
    a4cc:      	ldp	x28, x27, [sp], #0x60
    a4d0:      	ret

000000000000a4d4 <_wf_chain_mutation_geometry$instance$9fed7d4c5d7cc122>:
    a4d4:      	ldr	x8, [x0]
    a4d8:      	ldr	x9, [x0, #0x18]
    a4dc:      	add	x0, x9, x8, lsl #32
    a4e0:      	ret

000000000000a4e4 <_wf_chain_mutation_verify$instance$4250cb78d3f44027>:
    a4e4:      	mov	x9, #0xe5b9             ; =58809
    a4e8:      	movk	x9, #0x1ce4, lsl #16
    a4ec:      	movk	x9, #0x476d, lsl #32
    a4f0:      	movk	x9, #0xbf58, lsl #48
    a4f4:      	mov	x8, #0x11eb             ; =4587
    a4f8:      	movk	x8, #0x1331, lsl #16
    a4fc:      	movk	x8, #0x49bb, lsl #32
    a500:      	movk	x8, #0x94d0, lsl #48
    a504:      	ldp	x1, x10, [x0, #0x40]
    a508:      	cbz	x10, 0xa67c <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x198>
    a50c:      	stp	x20, x19, [sp, #-0x10]!
    a510:      	mov	x11, #0x0               ; =0
    a514:      	ldr	x12, [x0, #0x30]
    a518:      	ldrb	w13, [x0, #0x38]
    a51c:      	mov	w14, #0x83              ; =131
    a520:      	mov	w15, #0x110             ; =272
    a524:      	mov	w16, #0x4309            ; =17161
    a528:      	ldr	x17, [x0]
    a52c:      	b	0xa540 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x5c>
    a530:      	mul	x1, x1, x14
    a534:      	add	x11, x11, #0x1
    a538:      	cmp	x11, x10
    a53c:      	b.eq	0xa678 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x194>
    a540:      	mov	w2, #0x1                ; =1
    a544:      	bfi	x2, x11, #1, #63
    a548:      	tbz	w13, #0x0, 0xa558 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x74>
    a54c:      	mov	x4, #0x0                ; =0
    a550:      	cbnz	x17, 0xa574 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x90>
    a554:      	b	0xa5bc <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0xd8>
    a558:      	eor	x3, x12, x2
    a55c:      	eor	x3, x3, x3, lsr #30
    a560:      	mul	x3, x3, x9
    a564:      	eor	x3, x3, x3, lsr #27
    a568:      	mul	x3, x3, x8
    a56c:      	eor	x4, x3, x3, lsr #31
    a570:      	cbz	x17, 0xa5bc <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0xd8>
    a574:      	ldr	x3, [x0, #0x18]
    a578:      	cbz	x3, 0xa5bc <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0xd8>
    a57c:      	udiv	x5, x4, x17
    a580:      	msub	x4, x5, x17, x4
    a584:      	ldr	x5, [x0, #0x10]
    a588:      	add	x5, x5, x4, lsl #3
    a58c:      	mov	x4, x3
    a590:      	ldr	x5, [x5]
    a594:      	cmp	x5, x3
    a598:      	b.hs	0xa5bc <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0xd8>
    a59c:      	ldr	x6, [x0, #0x28]
    a5a0:      	madd	x7, x5, x15, x6
    a5a4:      	ldr	x19, [x7]
    a5a8:      	cmp	x19, x2
    a5ac:      	b.eq	0xa5d8 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0xf4>
    a5b0:      	add	x5, x7, #0x108
    a5b4:      	subs	x4, x4, #0x1
    a5b8:      	b.ne	0xa590 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0xac>
    a5bc:      	mul	x1, x1, x14
    a5c0:      	lsl	x2, x11, #1
    a5c4:      	add	x2, x2, #0x2
    a5c8:      	tbz	w13, #0x0, 0xa5f4 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x110>
    a5cc:      	mov	x4, #0x0                ; =0
    a5d0:      	cbnz	x17, 0xa610 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x12c>
    a5d4:      	b	0xa530 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x4c>
    a5d8:      	madd	x2, x5, x15, x6
    a5dc:      	ldr	x2, [x2, #0x8]
    a5e0:      	madd	x1, x1, x16, x2
    a5e4:      	add	x1, x1, #0x83
    a5e8:      	lsl	x2, x11, #1
    a5ec:      	add	x2, x2, #0x2
    a5f0:      	tbnz	w13, #0x0, 0xa5cc <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0xe8>
    a5f4:      	eor	x3, x12, x2
    a5f8:      	eor	x3, x3, x3, lsr #30
    a5fc:      	mul	x3, x3, x9
    a600:      	eor	x3, x3, x3, lsr #27
    a604:      	mul	x3, x3, x8
    a608:      	eor	x4, x3, x3, lsr #31
    a60c:      	cbz	x17, 0xa530 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x4c>
    a610:      	ldr	x3, [x0, #0x18]
    a614:      	cbz	x3, 0xa530 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x4c>
    a618:      	udiv	x5, x4, x17
    a61c:      	msub	x4, x5, x17, x4
    a620:      	ldr	x5, [x0, #0x10]
    a624:      	add	x5, x5, x4, lsl #3
    a628:      	mov	x4, x3
    a62c:      	ldr	x5, [x5]
    a630:      	cmp	x5, x3
    a634:      	b.hs	0xa530 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x4c>
    a638:      	ldr	x6, [x0, #0x28]
    a63c:      	madd	x7, x5, x15, x6
    a640:      	ldr	x19, [x7]
    a644:      	cmp	x19, x2
    a648:      	b.eq	0xa65c <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x178>
    a64c:      	add	x5, x7, #0x108
    a650:      	subs	x4, x4, #0x1
    a654:      	b.ne	0xa62c <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x148>
    a658:      	b	0xa530 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x4c>
    a65c:      	madd	x2, x5, x15, x6
    a660:      	ldr	x2, [x2, #0x8]
    a664:      	madd	x1, x1, x16, x2
    a668:      	add	x1, x1, #0x83
    a66c:      	add	x11, x11, #0x1
    a670:      	cmp	x11, x10
    a674:      	b.ne	0xa540 <_wf_chain_mutation_verify$instance$4250cb78d3f44027+0x5c>
    a678:      	ldp	x20, x19, [sp], #0x10
    a67c:      	eor	x10, x1, x1, lsr #30
    a680:      	mul	x9, x10, x9
    a684:      	eor	x9, x9, x9, lsr #27
    a688:      	mul	x8, x9, x8
    a68c:      	eor	x0, x8, x8, lsr #31
    a690:      	ret

000000000000a694 <_wf_chain_mutation_finish$instance$4250cb78d3f44027>:
    a694:      	sub	sp, sp, #0x60
    a698:      	stp	x29, x30, [sp, #0x50]
    a69c:      	ldr	x8, [x0, #0x40]
    a6a0:      	ldp	q0, q1, [x0]
    a6a4:      	stp	q0, q1, [sp, #0x20]
    a6a8:      	ldr	q0, [x0, #0x20]
    a6ac:      	str	q0, [sp, #0x40]
    a6b0:      	stp	x8, xzr, [sp]
    a6b4:      	stp	xzr, xzr, [sp, #0x10]
    a6b8:      	add	x0, sp, #0x20
    a6bc:      	mov	x1, sp
    a6c0:      	bl	0xa6c0 <_wf_chain_mutation_finish$instance$4250cb78d3f44027+0x2c>
		000000000000a6c0:  ARM64_RELOC_BRANCH26	_wf_full_chain_free$instance$e1a21e22af512733
    a6c4:      	ldp	x8, x9, [sp]
    a6c8:      	ldp	x10, x11, [sp, #0x10]
    a6cc:      	eor	x8, x8, x8, lsr #30
    a6d0:      	mov	x12, #0xe5b9            ; =58809
    a6d4:      	movk	x12, #0x1ce4, lsl #16
    a6d8:      	movk	x12, #0x476d, lsl #32
    a6dc:      	movk	x12, #0xbf58, lsl #48
    a6e0:      	mul	x8, x8, x12
    a6e4:      	eor	x8, x8, x8, lsr #27
    a6e8:      	mov	x13, #0x11eb            ; =4587
    a6ec:      	movk	x13, #0x1331, lsl #16
    a6f0:      	movk	x13, #0x49bb, lsl #32
    a6f4:      	movk	x13, #0x94d0, lsl #48
    a6f8:      	mul	x8, x8, x13
    a6fc:      	eor	x9, x9, x9, lsr #30
    a700:      	mul	x9, x9, x12
    a704:      	eor	x9, x9, x9, lsr #27
    a708:      	mul	x9, x9, x13
    a70c:      	eor	x12, x9, x8
    a710:      	mov	x13, #0x7c15            ; =31765
    a714:      	movk	x13, #0x7f4a, lsl #16
    a718:      	movk	x13, #0x79b9, lsl #32
    a71c:      	movk	x13, #0x9e37, lsl #48
    a720:      	mul	x11, x11, x13
    a724:      	eor	x10, x10, x11
    a728:      	eor	x10, x10, x12, lsr #31
    a72c:      	eor	x8, x8, x9
    a730:      	eor	x0, x10, x8
    a734:      	ldp	x29, x30, [sp, #0x50]
    a738:      	add	sp, sp, #0x60
    a73c:      	ret

000000000000a740 <_wf_std.collections.hash_map.hash_map_new$instance$a62a753cf2b0b5ca>:
    a740:      	stp	x20, x19, [sp, #-0x20]!
    a744:      	stp	x29, x30, [sp, #0x10]
    a748:      	mov	x20, x1
    a74c:      	mov	x19, x0
    a750:      	cbz	x1, 0xa798 <_wf_std.collections.hash_map.hash_map_new$instance$a62a753cf2b0b5ca+0x58>
    a754:      	add	x8, x20, x20, lsl #1
    a758:      	lsl	x0, x8, #3
    a75c:      	bl	0xa75c <_wf_std.collections.hash_map.hash_map_new$instance$a62a753cf2b0b5ca+0x1c>
		000000000000a75c:  ARM64_RELOC_BRANCH26	_malloc
    a760:      	cbz	x0, 0xa7b8 <_wf_std.collections.hash_map.hash_map_new$instance$a62a753cf2b0b5ca+0x78>
    a764:      	mov	x8, #0x0                ; =0
    a768:      	add	x9, x0, #0x8
    a76c:      	stur	wzr, [x9, #-0x8]
    a770:      	add	x8, x8, #0x1
    a774:      	stp	xzr, xzr, [x9], #0x18
    a778:      	cmp	x20, x8
    a77c:      	b.ne	0xa76c <_wf_std.collections.hash_map.hash_map_new$instance$a62a753cf2b0b5ca+0x2c>
    a780:      	stp	x20, x20, [x19]
    a784:      	stp	xzr, xzr, [x19, #0x18]
    a788:      	str	x0, [x19, #0x10]
    a78c:      	ldp	x29, x30, [sp, #0x10]
    a790:      	ldp	x20, x19, [sp], #0x20
    a794:      	ret
    a798:      	adrp	x0, 0xa000 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x8>
		000000000000a798:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    a79c:      	add	x0, x0, #0x0
		000000000000a79c:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    a7a0:      	stp	x20, x20, [x19]
    a7a4:      	stp	xzr, xzr, [x19, #0x18]
    a7a8:      	str	x0, [x19, #0x10]
    a7ac:      	ldp	x29, x30, [sp, #0x10]
    a7b0:      	ldp	x20, x19, [sp], #0x20
    a7b4:      	ret
    a7b8:      	bl	0xa7b8 <_wf_std.collections.hash_map.hash_map_new$instance$a62a753cf2b0b5ca+0x78>
		000000000000a7b8:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000a7bc <_wf_std.collections.hash_map.hash_map_put$instance$c7b22b9ef52855b6>:
    a7bc:      	ldr	x8, [x1]
    a7c0:      	ldp	x9, x10, [x1, #0x18]
    a7c4:      	adds	x10, x9, x10
    a7c8:      	csinv	x10, x10, xzr, lo
    a7cc:      	sub	x11, x8, x8, lsr #2
    a7d0:      	cmp	x8, #0x2
    a7d4:      	ccmp	x10, x11, #0x0, ls
    a7d8:      	b.lo	0xa854 <_wf_std.collections.hash_map.hash_map_put$instance$c7b22b9ef52855b6+0x98>
    a7dc:      	stp	x24, x23, [sp, #-0x40]!
    a7e0:      	stp	x22, x21, [sp, #0x10]
    a7e4:      	stp	x20, x19, [sp, #0x20]
    a7e8:      	stp	x29, x30, [sp, #0x30]
    a7ec:      	mov	w10, #0x1               ; =1
    a7f0:      	cmp	x8, #0x1
    a7f4:      	mov	w11, #0x2               ; =2
    a7f8:      	cinc	x11, x11, ne
    a7fc:      	cmp	x8, #0x0
    a800:      	csel	x10, x10, x11, eq
    a804:      	cmp	x9, x8, lsr #1
    a808:      	csel	x8, x10, x8, hs
    a80c:      	mov	x19, x0
    a810:      	mov	x0, x1
    a814:      	mov	x20, x1
    a818:      	mov	x1, x8
    a81c:      	mov	x21, x2
    a820:      	mov	x2, x4
    a824:      	mov	x22, x4
    a828:      	mov	x23, x3
    a82c:      	bl	0xa82c <_wf_std.collections.hash_map.hash_map_put$instance$c7b22b9ef52855b6+0x70>
		000000000000a82c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6
    a830:      	mov	x0, x19
    a834:      	mov	x1, x20
    a838:      	mov	x2, x21
    a83c:      	mov	x3, x23
    a840:      	mov	x4, x22
    a844:      	ldp	x29, x30, [sp, #0x30]
    a848:      	ldp	x20, x19, [sp, #0x20]
    a84c:      	ldp	x22, x21, [sp, #0x10]
    a850:      	ldp	x24, x23, [sp], #0x40
    a854:      	b	0xa854 <_wf_std.collections.hash_map.hash_map_put$instance$c7b22b9ef52855b6+0x98>
		000000000000a854:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6

000000000000a858 <_wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd>:
    a858:      	ldr	w8, [x0]
    a85c:      	cbz	w8, 0xa894 <_wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd+0x3c>
    a860:      	ldp	x9, x8, [x0, #0x8]
    a864:      	ldrb	w10, [x0, #0x4]
    a868:      	ldr	x11, [x1]
    a86c:      	mov	w12, #0x83              ; =131
    a870:      	tst	w10, #0x1
    a874:      	mov	w10, #0x1               ; =1
    a878:      	cinc	x10, x10, ne
    a87c:      	madd	x10, x11, x12, x10
    a880:      	add	x9, x10, x9
    a884:      	madd	x8, x9, x12, x8
    a888:      	str	x8, [x1]
    a88c:      	mov	w0, #0x0                ; =0
    a890:      	ret
    a894:      	ldr	x8, [x1]
    a898:      	mov	w9, #0x83               ; =131
    a89c:      	mul	x8, x8, x9
    a8a0:      	str	x8, [x1]
    a8a4:      	mov	w0, #0x0                ; =0
    a8a8:      	ret

000000000000a8ac <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760>:
    a8ac:      	stp	x29, x30, [sp, #-0x10]!
    a8b0:      	ldp	x15, x8, [x0]
    a8b4:      	ldr	x0, [x0, #0x10]
    a8b8:      	cbz	x15, 0xa960 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0xb4>
    a8bc:      	mov	x9, #0xe5b9             ; =58809
    a8c0:      	movk	x9, #0x1ce4, lsl #16
    a8c4:      	movk	x9, #0x476d, lsl #32
    a8c8:      	movk	x9, #0xbf58, lsl #48
    a8cc:      	mov	x10, #0x11eb            ; =4587
    a8d0:      	movk	x10, #0x1331, lsl #16
    a8d4:      	movk	x10, #0x49bb, lsl #32
    a8d8:      	movk	x10, #0x94d0, lsl #48
    a8dc:      	ldp	x11, x13, [x1, #0x8]
    a8e0:      	ldr	x12, [x1, #0x18]
    a8e4:      	ands	x16, x15, #0x3
    a8e8:      	b.eq	0xa954 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0xa8>
    a8ec:      	mov	w14, #0x18              ; =24
    a8f0:      	madd	x14, x15, x14, x0
    a8f4:      	sub	x17, x14, #0x8
    a8f8:      	mov	w2, #0x83               ; =131
    a8fc:      	mov	x14, x15
    a900:      	b	0xa914 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0x68>
    a904:      	sub	x17, x17, #0x18
    a908:      	sub	x14, x14, #0x1
    a90c:      	sub	x16, x16, #0x1
    a910:      	cbz	x16, 0xa958 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0xac>
    a914:      	ldur	w3, [x17, #-0x10]
    a918:      	cmp	w3, #0x2
    a91c:      	b.ne	0xa904 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0x58>
    a920:      	ldp	x4, x3, [x17, #-0x8]
    a924:      	madd	x3, x4, x2, x3
    a928:      	add	x11, x3, x11
    a92c:      	eor	x3, x3, x3, lsr #30
    a930:      	mul	x3, x3, x9
    a934:      	eor	x3, x3, x3, lsr #27
    a938:      	mul	x3, x3, x10
    a93c:      	eor	x13, x13, x3, lsr #31
    a940:      	eor	x13, x13, x3
    a944:      	stp	x11, x13, [x1, #0x8]
    a948:      	add	x12, x12, #0x1
    a94c:      	str	x12, [x1, #0x18]
    a950:      	b	0xa904 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0x58>
    a954:      	mov	x14, x15
    a958:      	cmp	x15, #0x4
    a95c:      	b.hs	0xa974 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0xc8>
    a960:      	cbz	x8, 0xa968 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0xbc>
    a964:      	bl	0xa964 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0xb8>
		000000000000a964:  ARM64_RELOC_BRANCH26	_free
    a968:      	mov	w0, #0x0                ; =0
    a96c:      	ldp	x29, x30, [sp], #0x10
    a970:      	ret
    a974:      	mov	w15, #0x18              ; =24
    a978:      	madd	x15, x14, x15, x0
    a97c:      	sub	x15, x15, #0x30
    a980:      	mov	w16, #0x83              ; =131
    a984:      	b	0xa994 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0xe8>
    a988:      	sub	x15, x15, #0x60
    a98c:      	sub	x14, x14, #0x4
    a990:      	cbz	x14, 0xa960 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0xb4>
    a994:      	ldr	w17, [x15, #0x18]
    a998:      	cmp	w17, #0x2
    a99c:      	b.eq	0xa9c8 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0x11c>
    a9a0:      	ldr	w17, [x15]
    a9a4:      	cmp	w17, #0x2
    a9a8:      	b.eq	0xaa04 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0x158>
    a9ac:      	ldur	w17, [x15, #-0x18]
    a9b0:      	cmp	w17, #0x2
    a9b4:      	b.eq	0xaa40 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0x194>
    a9b8:      	ldur	w17, [x15, #-0x30]
    a9bc:      	cmp	w17, #0x2
    a9c0:      	b.ne	0xa988 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0xdc>
    a9c4:      	b	0xaa7c <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0x1d0>
    a9c8:      	ldp	x2, x17, [x15, #0x20]
    a9cc:      	madd	x17, x2, x16, x17
    a9d0:      	add	x11, x17, x11
    a9d4:      	eor	x17, x17, x17, lsr #30
    a9d8:      	mul	x17, x17, x9
    a9dc:      	eor	x17, x17, x17, lsr #27
    a9e0:      	mul	x17, x17, x10
    a9e4:      	eor	x13, x13, x17, lsr #31
    a9e8:      	eor	x13, x13, x17
    a9ec:      	stp	x11, x13, [x1, #0x8]
    a9f0:      	add	x12, x12, #0x1
    a9f4:      	str	x12, [x1, #0x18]
    a9f8:      	ldr	w17, [x15]
    a9fc:      	cmp	w17, #0x2
    aa00:      	b.ne	0xa9ac <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0x100>
    aa04:      	ldp	x2, x17, [x15, #0x8]
    aa08:      	madd	x17, x2, x16, x17
    aa0c:      	add	x11, x17, x11
    aa10:      	eor	x17, x17, x17, lsr #30
    aa14:      	mul	x17, x17, x9
    aa18:      	eor	x17, x17, x17, lsr #27
    aa1c:      	mul	x17, x17, x10
    aa20:      	eor	x13, x13, x17, lsr #31
    aa24:      	eor	x13, x13, x17
    aa28:      	stp	x11, x13, [x1, #0x8]
    aa2c:      	add	x12, x12, #0x1
    aa30:      	str	x12, [x1, #0x18]
    aa34:      	ldur	w17, [x15, #-0x18]
    aa38:      	cmp	w17, #0x2
    aa3c:      	b.ne	0xa9b8 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0x10c>
    aa40:      	ldp	x2, x17, [x15, #-0x10]
    aa44:      	madd	x17, x2, x16, x17
    aa48:      	add	x11, x17, x11
    aa4c:      	eor	x17, x17, x17, lsr #30
    aa50:      	mul	x17, x17, x9
    aa54:      	eor	x17, x17, x17, lsr #27
    aa58:      	mul	x17, x17, x10
    aa5c:      	eor	x13, x13, x17, lsr #31
    aa60:      	eor	x13, x13, x17
    aa64:      	stp	x11, x13, [x1, #0x8]
    aa68:      	add	x12, x12, #0x1
    aa6c:      	str	x12, [x1, #0x18]
    aa70:      	ldur	w17, [x15, #-0x30]
    aa74:      	cmp	w17, #0x2
    aa78:      	b.ne	0xa988 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0xdc>
    aa7c:      	ldp	x2, x17, [x15, #-0x28]
    aa80:      	madd	x17, x2, x16, x17
    aa84:      	add	x11, x17, x11
    aa88:      	eor	x17, x17, x17, lsr #30
    aa8c:      	mul	x17, x17, x9
    aa90:      	eor	x17, x17, x17, lsr #27
    aa94:      	mul	x17, x17, x10
    aa98:      	eor	x13, x13, x17, lsr #31
    aa9c:      	eor	x13, x13, x17
    aaa0:      	stp	x11, x13, [x1, #0x8]
    aaa4:      	add	x12, x12, #0x1
    aaa8:      	str	x12, [x1, #0x18]
    aaac:      	b	0xa988 <_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760+0xdc>

000000000000aab0 <_wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd>:
    aab0:      	stp	x20, x19, [sp, #-0x20]!
    aab4:      	stp	x29, x30, [sp, #0x10]
    aab8:      	mov	x20, x1
    aabc:      	mov	x19, x0
    aac0:      	cbz	x1, 0xab08 <_wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd+0x58>
    aac4:      	add	x8, x20, x20, lsl #1
    aac8:      	lsl	x0, x8, #3
    aacc:      	bl	0xaacc <_wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd+0x1c>
		000000000000aacc:  ARM64_RELOC_BRANCH26	_malloc
    aad0:      	cbz	x0, 0xab28 <_wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd+0x78>
    aad4:      	mov	x8, #0x0                ; =0
    aad8:      	add	x9, x0, #0x8
    aadc:      	stur	wzr, [x9, #-0x8]
    aae0:      	add	x8, x8, #0x1
    aae4:      	stp	xzr, xzr, [x9], #0x18
    aae8:      	cmp	x20, x8
    aaec:      	b.ne	0xaadc <_wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd+0x2c>
    aaf0:      	stp	x20, x20, [x19]
    aaf4:      	stp	xzr, xzr, [x19, #0x18]
    aaf8:      	str	x0, [x19, #0x10]
    aafc:      	ldp	x29, x30, [sp, #0x10]
    ab00:      	ldp	x20, x19, [sp], #0x20
    ab04:      	ret
    ab08:      	adrp	x0, 0xa000 <_wf_chain_mutation_batch$instance$4250cb78d3f44027+0x8>
		000000000000ab08:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    ab0c:      	add	x0, x0, #0x0
		000000000000ab0c:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    ab10:      	stp	x20, x20, [x19]
    ab14:      	stp	xzr, xzr, [x19, #0x18]
    ab18:      	str	x0, [x19, #0x10]
    ab1c:      	ldp	x29, x30, [sp, #0x10]
    ab20:      	ldp	x20, x19, [sp], #0x20
    ab24:      	ret
    ab28:      	bl	0xab28 <_wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd+0x78>
		000000000000ab28:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000ab2c <_wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad>:
    ab2c:      	ldr	x8, [x1]
    ab30:      	ldp	x9, x10, [x1, #0x18]
    ab34:      	adds	x10, x9, x10
    ab38:      	csinv	x11, x10, xzr, lo
    ab3c:      	sub	x10, x8, x8, lsr #2
    ab40:      	lsr	x12, x8, #14
    ab44:      	cmp	x12, #0x0
    ab48:      	ccmp	x11, x10, #0x0, eq
    ab4c:      	b.lo	0xabcc <_wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad+0xa0>
    ab50:      	stp	x24, x23, [sp, #-0x40]!
    ab54:      	stp	x22, x21, [sp, #0x10]
    ab58:      	stp	x20, x19, [sp, #0x20]
    ab5c:      	stp	x29, x30, [sp, #0x30]
    ab60:      	mov	w11, #0x1               ; =1
    ab64:      	mov	w12, #0x2000            ; =8192
    ab68:      	cmp	x8, #0x2, lsl #12       ; =0x2000
    ab6c:      	csel	x12, x8, x12, lo
    ab70:      	lsl	x12, x12, #1
    ab74:      	cmp	x8, #0x0
    ab78:      	csel	x11, x11, x12, eq
    ab7c:      	cmp	x9, x10, lsr #1
    ab80:      	csel	x8, x11, x8, hs
    ab84:      	mov	x19, x0
    ab88:      	mov	x0, x1
    ab8c:      	mov	x20, x1
    ab90:      	mov	x1, x8
    ab94:      	mov	x21, x2
    ab98:      	mov	x2, x4
    ab9c:      	mov	x22, x4
    aba0:      	mov	x23, x3
    aba4:      	bl	0xaba4 <_wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad+0x78>
		000000000000aba4:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    aba8:      	mov	x0, x19
    abac:      	mov	x1, x20
    abb0:      	mov	x2, x21
    abb4:      	mov	x3, x23
    abb8:      	mov	x4, x22
    abbc:      	ldp	x29, x30, [sp, #0x30]
    abc0:      	ldp	x20, x19, [sp, #0x20]
    abc4:      	ldp	x22, x21, [sp, #0x10]
    abc8:      	ldp	x24, x23, [sp], #0x40
    abcc:      	b	0xabcc <_wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad+0xa0>
		000000000000abcc:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad

000000000000abd0 <_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad>:
    abd0:      	ldr	x10, [x0, #0x18]
    abd4:      	cbz	x10, 0xacbc <_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad+0xec>
    abd8:      	ldrb	w8, [x2, #0x8]
    abdc:      	tbz	w8, #0x0, 0xabf0 <_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad+0x20>
    abe0:      	mov	x8, #0x0                ; =0
    abe4:      	ldr	x11, [x0]
    abe8:      	cbnz	x11, 0xac38 <_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad+0x68>
    abec:      	b	0xacbc <_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad+0xec>
    abf0:      	ldr	x8, [x2]
    abf4:      	ldr	x9, [x1]
    abf8:      	eor	x8, x9, x8
    abfc:      	eor	x8, x8, x8, lsr #30
    ac00:      	mov	x9, #0xe5b9             ; =58809
    ac04:      	movk	x9, #0x1ce4, lsl #16
    ac08:      	movk	x9, #0x476d, lsl #32
    ac0c:      	movk	x9, #0xbf58, lsl #48
    ac10:      	mul	x8, x8, x9
    ac14:      	eor	x8, x8, x8, lsr #27
    ac18:      	mov	x9, #0x11eb             ; =4587
    ac1c:      	movk	x9, #0x1331, lsl #16
    ac20:      	movk	x9, #0x49bb, lsl #32
    ac24:      	movk	x9, #0x94d0, lsl #48
    ac28:      	mul	x8, x8, x9
    ac2c:      	eor	x8, x8, x8, lsr #31
    ac30:      	ldr	x11, [x0]
    ac34:      	cbz	x11, 0xacbc <_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad+0xec>
    ac38:      	udiv	x9, x8, x11
    ac3c:      	msub	x12, x9, x11, x8
    ac40:      	ldr	x13, [x0, #0x10]
    ac44:      	mov	w14, #0x18              ; =24
    ac48:      	mov	x15, x11
    ac4c:      	b	0xac64 <_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad+0x94>
    ac50:      	add	x8, x12, #0x1
    ac54:      	cmp	x8, x11
    ac58:      	csinc	x12, xzr, x12, hs
    ac5c:      	subs	x15, x15, #0x1
    ac60:      	b.eq	0xacbc <_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad+0xec>
    ac64:      	madd	x16, x12, x14, x13
    ac68:      	ldr	w8, [x16]
    ac6c:      	cmp	w8, #0x1
    ac70:      	b.eq	0xac50 <_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad+0x80>
    ac74:      	cmp	w8, #0x2
    ac78:      	b.ne	0xacd4 <_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad+0x104>
    ac7c:      	ldr	x9, [x16, #0x8]
    ac80:      	ldr	x8, [x1]
    ac84:      	cmp	x9, x8
    ac88:      	b.ne	0xac50 <_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad+0x80>
    ac8c:      	ldr	x2, [x16, #0x10]
    ac90:      	mov	w8, #0x1                ; =1
    ac94:      	str	w8, [x16]
    ac98:      	sub	x10, x10, #0x1
    ac9c:      	stp	xzr, xzr, [x16, #0x8]
    aca0:      	ldr	x11, [x0, #0x20]
    aca4:      	adds	x11, x11, #0x1
    aca8:      	csinv	x11, x11, xzr, lo
    acac:      	stp	x10, x11, [x0, #0x18]
    acb0:      	mov	x0, x8
    acb4:      	mov	x1, x9
    acb8:      	ret
    acbc:      	mov	w8, #0x0                ; =0
    acc0:      	mov	x9, #0x0                ; =0
    acc4:      	mov	x2, #0x0                ; =0
    acc8:      	mov	x0, x8
    accc:      	mov	x1, x9
    acd0:      	ret
    acd4:      	mov	x9, x8
    acd8:      	mov	x2, x8
    acdc:      	mov	x0, x8
    ace0:      	mov	x1, x9
    ace4:      	ret

000000000000ace8 <_wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50>:
    ace8:      	ldrb	w8, [x2, #0x8]
    acec:      	tbz	w8, #0x0, 0xad00 <_wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50+0x18>
    acf0:      	mov	x8, #0x0                ; =0
    acf4:      	ldr	x9, [x0]
    acf8:      	cbnz	x9, 0xad48 <_wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50+0x60>
    acfc:      	b	0xadb0 <_wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50+0xc8>
    ad00:      	ldr	x8, [x2]
    ad04:      	ldr	x9, [x1]
    ad08:      	eor	x8, x9, x8
    ad0c:      	eor	x8, x8, x8, lsr #30
    ad10:      	mov	x9, #0xe5b9             ; =58809
    ad14:      	movk	x9, #0x1ce4, lsl #16
    ad18:      	movk	x9, #0x476d, lsl #32
    ad1c:      	movk	x9, #0xbf58, lsl #48
    ad20:      	mul	x8, x8, x9
    ad24:      	eor	x8, x8, x8, lsr #27
    ad28:      	mov	x9, #0x11eb             ; =4587
    ad2c:      	movk	x9, #0x1331, lsl #16
    ad30:      	movk	x9, #0x49bb, lsl #32
    ad34:      	movk	x9, #0x94d0, lsl #48
    ad38:      	mul	x8, x8, x9
    ad3c:      	eor	x8, x8, x8, lsr #31
    ad40:      	ldr	x9, [x0]
    ad44:      	cbz	x9, 0xadb0 <_wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50+0xc8>
    ad48:      	udiv	x10, x8, x9
    ad4c:      	msub	x10, x10, x9, x8
    ad50:      	ldr	x11, [x0, #0x10]
    ad54:      	mov	w12, #0x18              ; =24
    ad58:      	mov	x13, x9
    ad5c:      	b	0xad74 <_wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50+0x8c>
    ad60:      	add	x8, x10, #0x1
    ad64:      	cmp	x8, x9
    ad68:      	csinc	x10, xzr, x10, hs
    ad6c:      	subs	x13, x13, #0x1
    ad70:      	b.eq	0xadb0 <_wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50+0xc8>
    ad74:      	madd	x14, x10, x12, x11
    ad78:      	ldr	w8, [x14]
    ad7c:      	cmp	w8, #0x1
    ad80:      	b.eq	0xad60 <_wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50+0x78>
    ad84:      	cmp	w8, #0x2
    ad88:      	b.ne	0xadb4 <_wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50+0xcc>
    ad8c:      	ldr	x8, [x14, #0x8]
    ad90:      	ldr	x15, [x1]
    ad94:      	cmp	x8, x15
    ad98:      	b.ne	0xad60 <_wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50+0x78>
    ad9c:      	mov	w0, #0x0                ; =0
    ada0:      	ldr	x8, [x14, #0x10]
    ada4:      	mov	x1, x8
    ada8:      	mov	w2, #0x0                ; =0
    adac:      	ret
    adb0:      	mov	x8, #0x0                ; =0
    adb4:      	mov	w0, #0x1                ; =1
    adb8:      	mov	x1, x8
    adbc:      	mov	w2, #0x0                ; =0
    adc0:      	ret

000000000000adc4 <_wf_std.collections.hash_map.hash_map_rehash$instance$fde7c6722a8b0dad>:
    adc4:      	mov	x2, x1
    adc8:      	ldr	x1, [x0]
    adcc:      	b	0xadcc <_wf_std.collections.hash_map.hash_map_rehash$instance$fde7c6722a8b0dad+0x8>
		000000000000adcc:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad

000000000000add0 <_wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad>:
    add0:      	cmp	x1, #0x4, lsl #12       ; =0x4000
    add4:      	b.ls	0xade8 <_wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad+0x18>
    add8:      	mov	w2, #0x0                ; =0
    addc:      	mov	w1, #0x0                ; =0
    ade0:      	mov	w0, #0x1                ; =1
    ade4:      	ret
    ade8:      	ldr	x8, [x0]
    adec:      	cmp	x1, x8
    adf0:      	b.ls	0xae04 <_wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad+0x34>
    adf4:      	stp	x29, x30, [sp, #-0x10]!
    adf8:      	bl	0xadf8 <_wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad+0x28>
		000000000000adf8:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
    adfc:      	ldp	x29, x30, [sp], #0x10
    ae00:      	ret
    ae04:      	mov	w2, #0x0                ; =0
    ae08:      	mov	w1, #0x0                ; =0
    ae0c:      	mov	w0, #0x0                ; =0
    ae10:      	ret

000000000000ae14 <_wf_std.collections.hash_map.hash_map_capacity$instance$820b2044b97e0fbd>:
    ae14:      	ldr	x0, [x0]
    ae18:      	ret

000000000000ae1c <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567>:
    ae1c:      	ldrb	w8, [x2, #0x8]
    ae20:      	tbz	w8, #0x0, 0xae34 <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567+0x18>
    ae24:      	mov	x8, #0x0                ; =0
    ae28:      	ldr	x9, [x0]
    ae2c:      	cbnz	x9, 0xae7c <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567+0x60>
    ae30:      	b	0xaef8 <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567+0xdc>
    ae34:      	ldr	x8, [x2]
    ae38:      	ldr	x9, [x1]
    ae3c:      	eor	x8, x9, x8
    ae40:      	eor	x8, x8, x8, lsr #30
    ae44:      	mov	x9, #0xe5b9             ; =58809
    ae48:      	movk	x9, #0x1ce4, lsl #16
    ae4c:      	movk	x9, #0x476d, lsl #32
    ae50:      	movk	x9, #0xbf58, lsl #48
    ae54:      	mul	x8, x8, x9
    ae58:      	eor	x8, x8, x8, lsr #27
    ae5c:      	mov	x9, #0x11eb             ; =4587
    ae60:      	movk	x9, #0x1331, lsl #16
    ae64:      	movk	x9, #0x49bb, lsl #32
    ae68:      	movk	x9, #0x94d0, lsl #48
    ae6c:      	mul	x8, x8, x9
    ae70:      	eor	x8, x8, x8, lsr #31
    ae74:      	ldr	x9, [x0]
    ae78:      	cbz	x9, 0xaef8 <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567+0xdc>
    ae7c:      	mov	x10, #0x0               ; =0
    ae80:      	udiv	x11, x8, x9
    ae84:      	msub	x11, x11, x9, x8
    ae88:      	sub	x12, x9, x11
    ae8c:      	neg	x13, x12
    ae90:      	ldr	x14, [x0, #0x10]
    ae94:      	mov	w15, #0x18              ; =24
    ae98:      	b	0xaea8 <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567+0x8c>
    ae9c:      	add	x10, x10, #0x1
    aea0:      	cmp	x9, x10
    aea4:      	b.eq	0xaef8 <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567+0xdc>
    aea8:      	cmp	x10, x12
    aeac:      	csel	x8, x11, x13, lo
    aeb0:      	add	x8, x8, x10
    aeb4:      	madd	x16, x8, x15, x14
    aeb8:      	ldr	w8, [x16]
    aebc:      	cmp	w8, #0x1
    aec0:      	b.eq	0xae9c <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567+0x80>
    aec4:      	cmp	w8, #0x2
    aec8:      	b.ne	0xaefc <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567+0xe0>
    aecc:      	ldr	x8, [x16, #0x8]
    aed0:      	ldr	x17, [x1]
    aed4:      	cmp	x8, x17
    aed8:      	b.ne	0xae9c <_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567+0x80>
    aedc:      	mov	w0, #0x0                ; =0
    aee0:      	ldr	x8, [x16, #0x10]
    aee4:      	add	x8, x8, #0x1
    aee8:      	str	x8, [x16, #0x10]
    aeec:      	mov	x1, x8
    aef0:      	mov	w2, #0x0                ; =0
    aef4:      	ret
    aef8:      	mov	x8, #0x0                ; =0
    aefc:      	mov	w0, #0x1                ; =1
    af00:      	mov	x1, x8
    af04:      	mov	w2, #0x0                ; =0
    af08:      	ret

000000000000af0c <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19>:
    af0c:      	stp	x29, x30, [sp, #-0x10]!
    af10:      	ldp	x15, x8, [x0]
    af14:      	ldr	x0, [x0, #0x10]
    af18:      	cbz	x15, 0xafc0 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xb4>
    af1c:      	mov	x9, #0xe5b9             ; =58809
    af20:      	movk	x9, #0x1ce4, lsl #16
    af24:      	movk	x9, #0x476d, lsl #32
    af28:      	movk	x9, #0xbf58, lsl #48
    af2c:      	mov	x10, #0x11eb            ; =4587
    af30:      	movk	x10, #0x1331, lsl #16
    af34:      	movk	x10, #0x49bb, lsl #32
    af38:      	movk	x10, #0x94d0, lsl #48
    af3c:      	ldp	x11, x13, [x1, #0x8]
    af40:      	ldr	x12, [x1, #0x18]
    af44:      	ands	x16, x15, #0x3
    af48:      	b.eq	0xafb4 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xa8>
    af4c:      	mov	w14, #0x18              ; =24
    af50:      	madd	x14, x15, x14, x0
    af54:      	sub	x17, x14, #0x8
    af58:      	mov	w2, #0x83               ; =131
    af5c:      	mov	x14, x15
    af60:      	b	0xaf74 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0x68>
    af64:      	sub	x17, x17, #0x18
    af68:      	sub	x14, x14, #0x1
    af6c:      	sub	x16, x16, #0x1
    af70:      	cbz	x16, 0xafb8 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xac>
    af74:      	ldur	w3, [x17, #-0x10]
    af78:      	cmp	w3, #0x2
    af7c:      	b.ne	0xaf64 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0x58>
    af80:      	ldp	x4, x3, [x17, #-0x8]
    af84:      	madd	x3, x4, x2, x3
    af88:      	add	x11, x3, x11
    af8c:      	eor	x3, x3, x3, lsr #30
    af90:      	mul	x3, x3, x9
    af94:      	eor	x3, x3, x3, lsr #27
    af98:      	mul	x3, x3, x10
    af9c:      	eor	x13, x13, x3, lsr #31
    afa0:      	eor	x13, x13, x3
    afa4:      	stp	x11, x13, [x1, #0x8]
    afa8:      	add	x12, x12, #0x1
    afac:      	str	x12, [x1, #0x18]
    afb0:      	b	0xaf64 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0x58>
    afb4:      	mov	x14, x15
    afb8:      	cmp	x15, #0x4
    afbc:      	b.hs	0xafd4 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xc8>
    afc0:      	cbz	x8, 0xafc8 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xbc>
    afc4:      	bl	0xafc4 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xb8>
		000000000000afc4:  ARM64_RELOC_BRANCH26	_free
    afc8:      	mov	w0, #0x0                ; =0
    afcc:      	ldp	x29, x30, [sp], #0x10
    afd0:      	ret
    afd4:      	mov	w15, #0x18              ; =24
    afd8:      	madd	x15, x14, x15, x0
    afdc:      	sub	x15, x15, #0x30
    afe0:      	mov	w16, #0x83              ; =131
    afe4:      	b	0xaff4 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xe8>
    afe8:      	sub	x15, x15, #0x60
    afec:      	sub	x14, x14, #0x4
    aff0:      	cbz	x14, 0xafc0 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xb4>
    aff4:      	ldr	w17, [x15, #0x18]
    aff8:      	cmp	w17, #0x2
    affc:      	b.eq	0xb028 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0x11c>
    b000:      	ldr	w17, [x15]
    b004:      	cmp	w17, #0x2
    b008:      	b.eq	0xb064 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0x158>
    b00c:      	ldur	w17, [x15, #-0x18]
    b010:      	cmp	w17, #0x2
    b014:      	b.eq	0xb0a0 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0x194>
    b018:      	ldur	w17, [x15, #-0x30]
    b01c:      	cmp	w17, #0x2
    b020:      	b.ne	0xafe8 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xdc>
    b024:      	b	0xb0dc <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0x1d0>
    b028:      	ldp	x2, x17, [x15, #0x20]
    b02c:      	madd	x17, x2, x16, x17
    b030:      	add	x11, x17, x11
    b034:      	eor	x17, x17, x17, lsr #30
    b038:      	mul	x17, x17, x9
    b03c:      	eor	x17, x17, x17, lsr #27
    b040:      	mul	x17, x17, x10
    b044:      	eor	x13, x13, x17, lsr #31
    b048:      	eor	x13, x13, x17
    b04c:      	stp	x11, x13, [x1, #0x8]
    b050:      	add	x12, x12, #0x1
    b054:      	str	x12, [x1, #0x18]
    b058:      	ldr	w17, [x15]
    b05c:      	cmp	w17, #0x2
    b060:      	b.ne	0xb00c <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0x100>
    b064:      	ldp	x2, x17, [x15, #0x8]
    b068:      	madd	x17, x2, x16, x17
    b06c:      	add	x11, x17, x11
    b070:      	eor	x17, x17, x17, lsr #30
    b074:      	mul	x17, x17, x9
    b078:      	eor	x17, x17, x17, lsr #27
    b07c:      	mul	x17, x17, x10
    b080:      	eor	x13, x13, x17, lsr #31
    b084:      	eor	x13, x13, x17
    b088:      	stp	x11, x13, [x1, #0x8]
    b08c:      	add	x12, x12, #0x1
    b090:      	str	x12, [x1, #0x18]
    b094:      	ldur	w17, [x15, #-0x18]
    b098:      	cmp	w17, #0x2
    b09c:      	b.ne	0xb018 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0x10c>
    b0a0:      	ldp	x2, x17, [x15, #-0x10]
    b0a4:      	madd	x17, x2, x16, x17
    b0a8:      	add	x11, x17, x11
    b0ac:      	eor	x17, x17, x17, lsr #30
    b0b0:      	mul	x17, x17, x9
    b0b4:      	eor	x17, x17, x17, lsr #27
    b0b8:      	mul	x17, x17, x10
    b0bc:      	eor	x13, x13, x17, lsr #31
    b0c0:      	eor	x13, x13, x17
    b0c4:      	stp	x11, x13, [x1, #0x8]
    b0c8:      	add	x12, x12, #0x1
    b0cc:      	str	x12, [x1, #0x18]
    b0d0:      	ldur	w17, [x15, #-0x30]
    b0d4:      	cmp	w17, #0x2
    b0d8:      	b.ne	0xafe8 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xdc>
    b0dc:      	ldp	x2, x17, [x15, #-0x28]
    b0e0:      	madd	x17, x2, x16, x17
    b0e4:      	add	x11, x17, x11
    b0e8:      	eor	x17, x17, x17, lsr #30
    b0ec:      	mul	x17, x17, x9
    b0f0:      	eor	x17, x17, x17, lsr #27
    b0f4:      	mul	x17, x17, x10
    b0f8:      	eor	x13, x13, x17, lsr #31
    b0fc:      	eor	x13, x13, x17
    b100:      	stp	x11, x13, [x1, #0x8]
    b104:      	add	x12, x12, #0x1
    b108:      	str	x12, [x1, #0x18]
    b10c:      	b	0xafe8 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xdc>

000000000000b110 <_wf_std.collections.hash_map.hash_map_new$instance$96033bf6ddb80743>:
    b110:      	stp	x20, x19, [sp, #-0x20]!
    b114:      	stp	x29, x30, [sp, #0x10]
    b118:      	mov	x20, x1
    b11c:      	mov	x19, x0
    b120:      	cbz	x1, 0xb190 <_wf_std.collections.hash_map.hash_map_new$instance$96033bf6ddb80743+0x80>
    b124:      	add	x8, x20, x20, lsl #4
    b128:      	lsl	x0, x8, #4
    b12c:      	bl	0xb12c <_wf_std.collections.hash_map.hash_map_new$instance$96033bf6ddb80743+0x1c>
		000000000000b12c:  ARM64_RELOC_BRANCH26	_malloc
    b130:      	cbz	x0, 0xb1b0 <_wf_std.collections.hash_map.hash_map_new$instance$96033bf6ddb80743+0xa0>
    b134:      	mov	x8, #0x0                ; =0
    b138:      	add	x9, x0, #0x8
    b13c:      	movi.2d	v0, #0000000000000000
    b140:      	stur	wzr, [x9, #-0x8]
    b144:      	add	x8, x8, #0x1
    b148:      	stp	q0, q0, [x9]
    b14c:      	stp	q0, q0, [x9, #0x20]
    b150:      	stp	q0, q0, [x9, #0x40]
    b154:      	stp	q0, q0, [x9, #0x60]
    b158:      	stp	q0, q0, [x9, #0x80]
    b15c:      	stp	q0, q0, [x9, #0xa0]
    b160:      	stp	q0, q0, [x9, #0xc0]
    b164:      	stp	q0, q0, [x9, #0xe0]
    b168:      	str	xzr, [x9, #0x100]
    b16c:      	add	x9, x9, #0x110
    b170:      	cmp	x20, x8
    b174:      	b.ne	0xb140 <_wf_std.collections.hash_map.hash_map_new$instance$96033bf6ddb80743+0x30>
    b178:      	stp	x20, x20, [x19]
    b17c:      	stp	xzr, xzr, [x19, #0x18]
    b180:      	str	x0, [x19, #0x10]
    b184:      	ldp	x29, x30, [sp, #0x10]
    b188:      	ldp	x20, x19, [sp], #0x20
    b18c:      	ret
    b190:      	adrp	x0, 0xb000 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xf4>
		000000000000b190:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    b194:      	add	x0, x0, #0x0
		000000000000b194:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    b198:      	stp	x20, x20, [x19]
    b19c:      	stp	xzr, xzr, [x19, #0x18]
    b1a0:      	str	x0, [x19, #0x10]
    b1a4:      	ldp	x29, x30, [sp, #0x10]
    b1a8:      	ldp	x20, x19, [sp], #0x20
    b1ac:      	ret
    b1b0:      	bl	0xb1b0 <_wf_std.collections.hash_map.hash_map_new$instance$96033bf6ddb80743+0xa0>
		000000000000b1b0:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000b1b4 <_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07>:
    b1b4:      	sub	sp, sp, #0x1c0
    b1b8:      	stp	x28, x27, [sp, #0x180]
    b1bc:      	stp	x22, x21, [sp, #0x190]
    b1c0:      	stp	x20, x19, [sp, #0x1a0]
    b1c4:      	stp	x29, x30, [sp, #0x1b0]
    b1c8:      	ldp	q0, q1, [x3, #0xc0]
    b1cc:      	mov	x8, sp
    b1d0:      	add	x9, x8, #0x128
    b1d4:      	stp	q0, q1, [sp, #0xc0]
    b1d8:      	ldp	q0, q1, [x3, #0xe0]
    b1dc:      	stp	q0, q1, [sp, #0xe0]
    b1e0:      	ldp	q0, q1, [x3, #0x80]
    b1e4:      	stp	q0, q1, [sp, #0x80]
    b1e8:      	ldp	q0, q1, [x3, #0xa0]
    b1ec:      	stp	q0, q1, [sp, #0xa0]
    b1f0:      	ldp	q0, q1, [x3, #0x40]
    b1f4:      	stp	q0, q1, [sp, #0x40]
    b1f8:      	ldp	q0, q1, [x3, #0x60]
    b1fc:      	stp	q0, q1, [sp, #0x60]
    b200:      	ldp	q0, q1, [x3]
    b204:      	stp	q0, q1, [sp]
    b208:      	ldp	q0, q1, [x3, #0x20]
    b20c:      	stp	q0, q1, [sp, #0x20]
    b210:      	ldr	x8, [x1]
    b214:      	ldp	q1, q0, [x1]
    b218:      	stp	q1, q0, [sp, #0x100]
    b21c:      	ldr	x10, [x1, #0x20]
    b220:      	ldr	x11, [sp, #0x118]
    b224:      	stp	q1, q0, [x9]
    b228:      	adds	x9, x11, x10
    b22c:      	csinv	x9, x9, xzr, lo
    b230:      	str	x10, [sp, #0x120]
    b234:      	str	x10, [sp, #0x148]
    b238:      	cmp	x8, #0x2
    b23c:      	b.hi	0xb2c0 <_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07+0x10c>
    b240:      	sub	x10, x8, x8, lsr #2
    b244:      	cmp	x9, x10
    b248:      	b.lo	0xb2c0 <_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07+0x10c>
    b24c:      	ldp	q1, q0, [x1]
    b250:      	stp	q1, q0, [sp, #0x150]
    b254:      	ldr	x9, [x1, #0x20]
    b258:      	str	x9, [sp, #0x170]
    b25c:      	ldr	x9, [sp, #0x168]
    b260:      	mov	x19, x0
    b264:      	mov	x20, x2
    b268:      	cmp	x9, x8, lsr #1
    b26c:      	b.lo	0xb288 <_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07+0xd4>
    b270:      	cbz	x8, 0xb284 <_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07+0xd0>
    b274:      	cmp	x8, #0x1
    b278:      	mov	w8, #0x2                ; =2
    b27c:      	cinc	x8, x8, ne
    b280:      	b	0xb288 <_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07+0xd4>
    b284:      	mov	w8, #0x1                ; =1
    b288:      	mov	x0, x1
    b28c:      	mov	x21, x1
    b290:      	mov	x1, x8
    b294:      	mov	x2, x4
    b298:      	mov	x22, x4
    b29c:      	bl	0xb29c <_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07+0xe8>
		000000000000b29c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07
    b2a0:      	mov	x4, x22
    b2a4:      	mov	x8, x1
    b2a8:      	mov	x1, x21
    b2ac:      	str	w0, [sp, #0x178]
    b2b0:      	strb	w8, [sp, #0x17c]
    b2b4:      	strb	w2, [sp, #0x17d]
    b2b8:      	mov	x2, x20
    b2bc:      	mov	x0, x19
    b2c0:      	mov	x3, sp
    b2c4:      	bl	0xb2c4 <_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07+0x110>
		000000000000b2c4:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07
    b2c8:      	ldp	x29, x30, [sp, #0x1b0]
    b2cc:      	ldp	x20, x19, [sp, #0x1a0]
    b2d0:      	ldp	x22, x21, [sp, #0x190]
    b2d4:      	ldp	x28, x27, [sp, #0x180]
    b2d8:      	add	sp, sp, #0x1c0
    b2dc:      	ret

000000000000b2e0 <_wf_map_cost_library_policy_result$instance$4250cb78d3f44027>:
    b2e0:      	ldr	w8, [x0]
    b2e4:      	cbz	w8, 0xb414 <_wf_map_cost_library_policy_result$instance$4250cb78d3f44027+0x134>
    b2e8:      	ldrb	w9, [x0, #0x4]
    b2ec:      	ldr	x10, [x1]
    b2f0:      	mov	w8, #0x83               ; =131
    b2f4:      	tst	w9, #0x1
    b2f8:      	mov	w9, #0x1                ; =1
    b2fc:      	cinc	x9, x9, ne
    b300:      	madd	x9, x10, x8, x9
    b304:      	ldp	x11, x10, [x0, #0x8]
    b308:      	madd	x10, x11, x8, x10
    b30c:      	ldr	x11, [x0, #0x18]
    b310:      	madd	x10, x10, x8, x11
    b314:      	ldr	x11, [x0, #0x20]
    b318:      	madd	x10, x10, x8, x11
    b31c:      	ldr	x11, [x0, #0x28]
    b320:      	madd	x10, x10, x8, x11
    b324:      	ldr	x11, [x0, #0x30]
    b328:      	madd	x10, x10, x8, x11
    b32c:      	ldr	x11, [x0, #0x38]
    b330:      	madd	x10, x10, x8, x11
    b334:      	ldr	x11, [x0, #0x40]
    b338:      	madd	x10, x10, x8, x11
    b33c:      	ldr	x11, [x0, #0x48]
    b340:      	madd	x10, x10, x8, x11
    b344:      	ldr	x11, [x0, #0x50]
    b348:      	madd	x10, x10, x8, x11
    b34c:      	ldr	x11, [x0, #0x58]
    b350:      	madd	x10, x10, x8, x11
    b354:      	ldr	x11, [x0, #0x60]
    b358:      	madd	x10, x10, x8, x11
    b35c:      	ldr	x11, [x0, #0x68]
    b360:      	madd	x10, x10, x8, x11
    b364:      	ldr	x11, [x0, #0x70]
    b368:      	madd	x10, x10, x8, x11
    b36c:      	ldr	x11, [x0, #0x78]
    b370:      	madd	x10, x10, x8, x11
    b374:      	ldr	x11, [x0, #0x80]
    b378:      	madd	x10, x10, x8, x11
    b37c:      	ldr	x11, [x0, #0x88]
    b380:      	madd	x10, x10, x8, x11
    b384:      	ldr	x11, [x0, #0x90]
    b388:      	madd	x10, x10, x8, x11
    b38c:      	ldr	x11, [x0, #0x98]
    b390:      	madd	x10, x10, x8, x11
    b394:      	ldr	x11, [x0, #0xa0]
    b398:      	madd	x10, x10, x8, x11
    b39c:      	ldr	x11, [x0, #0xa8]
    b3a0:      	madd	x10, x10, x8, x11
    b3a4:      	ldr	x11, [x0, #0xb0]
    b3a8:      	madd	x10, x10, x8, x11
    b3ac:      	ldr	x11, [x0, #0xb8]
    b3b0:      	madd	x10, x10, x8, x11
    b3b4:      	ldr	x11, [x0, #0xc0]
    b3b8:      	madd	x10, x10, x8, x11
    b3bc:      	ldr	x11, [x0, #0xc8]
    b3c0:      	madd	x10, x10, x8, x11
    b3c4:      	ldr	x11, [x0, #0xd0]
    b3c8:      	madd	x10, x10, x8, x11
    b3cc:      	ldr	x11, [x0, #0xd8]
    b3d0:      	madd	x10, x10, x8, x11
    b3d4:      	ldr	x11, [x0, #0xe0]
    b3d8:      	madd	x10, x10, x8, x11
    b3dc:      	ldr	x11, [x0, #0xe8]
    b3e0:      	madd	x10, x10, x8, x11
    b3e4:      	ldr	x11, [x0, #0xf0]
    b3e8:      	madd	x10, x10, x8, x11
    b3ec:      	ldr	x11, [x0, #0xf8]
    b3f0:      	madd	x10, x10, x8, x11
    b3f4:      	ldr	x11, [x0, #0x100]
    b3f8:      	madd	x10, x10, x8, x11
    b3fc:      	add	x9, x10, x9
    b400:      	ldr	x10, [x0, #0x108]
    b404:      	madd	x8, x9, x8, x10
    b408:      	str	x8, [x1]
    b40c:      	mov	w0, #0x0                ; =0
    b410:      	ret
    b414:      	ldr	x8, [x1]
    b418:      	mov	w9, #0x83               ; =131
    b41c:      	mul	x8, x8, x9
    b420:      	str	x8, [x1]
    b424:      	mov	w0, #0x0                ; =0
    b428:      	ret

000000000000b42c <_wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146>:
    b42c:      	stp	x29, x30, [sp, #-0x10]!
    b430:      	ldp	x9, x8, [x0]
    b434:      	ldr	x0, [x0, #0x10]
    b438:      	cbz	x9, 0xb580 <_wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146+0x154>
    b43c:      	ldp	x10, x11, [x1, #0x8]
    b440:      	mov	w12, #0x110             ; =272
    b444:      	madd	x13, x9, x12, x0
    b448:      	ldr	x12, [x1, #0x18]
    b44c:      	sub	x13, x13, #0x88
    b450:      	mov	w14, #0x83              ; =131
    b454:      	mov	x15, #0xe5b9            ; =58809
    b458:      	movk	x15, #0x1ce4, lsl #16
    b45c:      	movk	x15, #0x476d, lsl #32
    b460:      	movk	x15, #0xbf58, lsl #48
    b464:      	mov	x16, #0x11eb            ; =4587
    b468:      	movk	x16, #0x1331, lsl #16
    b46c:      	movk	x16, #0x49bb, lsl #32
    b470:      	movk	x16, #0x94d0, lsl #48
    b474:      	b	0xb484 <_wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146+0x58>
    b478:      	sub	x13, x13, #0x110
    b47c:      	sub	x9, x9, #0x1
    b480:      	cbz	x9, 0xb580 <_wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146+0x154>
    b484:      	ldur	w17, [x13, #-0x88]
    b488:      	cmp	w17, #0x2
    b48c:      	b.ne	0xb478 <_wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146+0x4c>
    b490:      	ldp	x2, x17, [x13, #-0x80]
    b494:      	madd	x17, x2, x14, x17
    b498:      	ldp	x3, x2, [x13, #-0x70]
    b49c:      	madd	x17, x17, x14, x3
    b4a0:      	madd	x17, x17, x14, x2
    b4a4:      	ldp	x3, x2, [x13, #-0x60]
    b4a8:      	madd	x17, x17, x14, x3
    b4ac:      	madd	x17, x17, x14, x2
    b4b0:      	ldp	x3, x2, [x13, #-0x50]
    b4b4:      	madd	x17, x17, x14, x3
    b4b8:      	madd	x17, x17, x14, x2
    b4bc:      	ldp	x3, x2, [x13, #-0x40]
    b4c0:      	madd	x17, x17, x14, x3
    b4c4:      	madd	x17, x17, x14, x2
    b4c8:      	ldp	x3, x2, [x13, #-0x30]
    b4cc:      	madd	x17, x17, x14, x3
    b4d0:      	madd	x17, x17, x14, x2
    b4d4:      	ldp	x3, x2, [x13, #-0x20]
    b4d8:      	madd	x17, x17, x14, x3
    b4dc:      	madd	x17, x17, x14, x2
    b4e0:      	ldp	x3, x2, [x13, #-0x10]
    b4e4:      	madd	x17, x17, x14, x3
    b4e8:      	madd	x17, x17, x14, x2
    b4ec:      	ldp	x3, x2, [x13]
    b4f0:      	madd	x17, x17, x14, x3
    b4f4:      	madd	x17, x17, x14, x2
    b4f8:      	ldp	x3, x2, [x13, #0x10]
    b4fc:      	madd	x17, x17, x14, x3
    b500:      	madd	x17, x17, x14, x2
    b504:      	ldp	x3, x2, [x13, #0x20]
    b508:      	madd	x17, x17, x14, x3
    b50c:      	madd	x17, x17, x14, x2
    b510:      	ldp	x3, x2, [x13, #0x30]
    b514:      	madd	x17, x17, x14, x3
    b518:      	madd	x17, x17, x14, x2
    b51c:      	ldp	x3, x2, [x13, #0x40]
    b520:      	madd	x17, x17, x14, x3
    b524:      	madd	x17, x17, x14, x2
    b528:      	ldp	x3, x2, [x13, #0x50]
    b52c:      	madd	x17, x17, x14, x3
    b530:      	madd	x17, x17, x14, x2
    b534:      	ldp	x3, x2, [x13, #0x60]
    b538:      	madd	x17, x17, x14, x3
    b53c:      	madd	x17, x17, x14, x2
    b540:      	ldp	x3, x2, [x13, #0x70]
    b544:      	madd	x17, x17, x14, x3
    b548:      	madd	x17, x17, x14, x2
    b54c:      	ldr	x2, [x13, #0x80]
    b550:      	madd	x17, x17, x14, x2
    b554:      	add	x10, x17, x10
    b558:      	eor	x17, x17, x17, lsr #30
    b55c:      	mul	x17, x17, x15
    b560:      	eor	x17, x17, x17, lsr #27
    b564:      	mul	x17, x17, x16
    b568:      	eor	x11, x11, x17, lsr #31
    b56c:      	eor	x11, x11, x17
    b570:      	stp	x10, x11, [x1, #0x8]
    b574:      	add	x12, x12, #0x1
    b578:      	str	x12, [x1, #0x18]
    b57c:      	b	0xb478 <_wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146+0x4c>
    b580:      	cbz	x8, 0xb588 <_wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146+0x15c>
    b584:      	bl	0xb584 <_wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146+0x158>
		000000000000b584:  ARM64_RELOC_BRANCH26	_free
    b588:      	mov	w0, #0x0                ; =0
    b58c:      	ldp	x29, x30, [sp], #0x10
    b590:      	ret

000000000000b594 <_wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374>:
    b594:      	stp	x20, x19, [sp, #-0x20]!
    b598:      	stp	x29, x30, [sp, #0x10]
    b59c:      	mov	x20, x1
    b5a0:      	mov	x19, x0
    b5a4:      	cbz	x1, 0xb614 <_wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374+0x80>
    b5a8:      	add	x8, x20, x20, lsl #4
    b5ac:      	lsl	x0, x8, #4
    b5b0:      	bl	0xb5b0 <_wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374+0x1c>
		000000000000b5b0:  ARM64_RELOC_BRANCH26	_malloc
    b5b4:      	cbz	x0, 0xb634 <_wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374+0xa0>
    b5b8:      	mov	x8, #0x0                ; =0
    b5bc:      	add	x9, x0, #0x8
    b5c0:      	movi.2d	v0, #0000000000000000
    b5c4:      	stur	wzr, [x9, #-0x8]
    b5c8:      	add	x8, x8, #0x1
    b5cc:      	stp	q0, q0, [x9]
    b5d0:      	stp	q0, q0, [x9, #0x20]
    b5d4:      	stp	q0, q0, [x9, #0x40]
    b5d8:      	stp	q0, q0, [x9, #0x60]
    b5dc:      	stp	q0, q0, [x9, #0x80]
    b5e0:      	stp	q0, q0, [x9, #0xa0]
    b5e4:      	stp	q0, q0, [x9, #0xc0]
    b5e8:      	stp	q0, q0, [x9, #0xe0]
    b5ec:      	str	xzr, [x9, #0x100]
    b5f0:      	add	x9, x9, #0x110
    b5f4:      	cmp	x20, x8
    b5f8:      	b.ne	0xb5c4 <_wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374+0x30>
    b5fc:      	stp	x20, x20, [x19]
    b600:      	stp	xzr, xzr, [x19, #0x18]
    b604:      	str	x0, [x19, #0x10]
    b608:      	ldp	x29, x30, [sp, #0x10]
    b60c:      	ldp	x20, x19, [sp], #0x20
    b610:      	ret
    b614:      	adrp	x0, 0xb000 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xf4>
		000000000000b614:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    b618:      	add	x0, x0, #0x0
		000000000000b618:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    b61c:      	stp	x20, x20, [x19]
    b620:      	stp	xzr, xzr, [x19, #0x18]
    b624:      	str	x0, [x19, #0x10]
    b628:      	ldp	x29, x30, [sp, #0x10]
    b62c:      	ldp	x20, x19, [sp], #0x20
    b630:      	ret
    b634:      	bl	0xb634 <_wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374+0xa0>
		000000000000b634:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000b638 <_wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65>:
    b638:      	sub	sp, sp, #0x1c0
    b63c:      	stp	x28, x27, [sp, #0x180]
    b640:      	stp	x22, x21, [sp, #0x190]
    b644:      	stp	x20, x19, [sp, #0x1a0]
    b648:      	stp	x29, x30, [sp, #0x1b0]
    b64c:      	ldp	q0, q1, [x3, #0xc0]
    b650:      	mov	x8, sp
    b654:      	add	x9, x8, #0x128
    b658:      	stp	q0, q1, [sp, #0xc0]
    b65c:      	ldp	q0, q1, [x3, #0xe0]
    b660:      	stp	q0, q1, [sp, #0xe0]
    b664:      	ldp	q0, q1, [x3, #0x80]
    b668:      	stp	q0, q1, [sp, #0x80]
    b66c:      	ldp	q0, q1, [x3, #0xa0]
    b670:      	stp	q0, q1, [sp, #0xa0]
    b674:      	ldp	q0, q1, [x3, #0x40]
    b678:      	stp	q0, q1, [sp, #0x40]
    b67c:      	ldp	q0, q1, [x3, #0x60]
    b680:      	stp	q0, q1, [sp, #0x60]
    b684:      	ldp	q0, q1, [x3]
    b688:      	stp	q0, q1, [sp]
    b68c:      	ldp	q0, q1, [x3, #0x20]
    b690:      	stp	q0, q1, [sp, #0x20]
    b694:      	ldr	x8, [x1]
    b698:      	ldp	q1, q0, [x1]
    b69c:      	stp	q1, q0, [sp, #0x100]
    b6a0:      	ldr	x11, [x1, #0x20]
    b6a4:      	ldr	x10, [sp, #0x118]
    b6a8:      	stp	q1, q0, [x9]
    b6ac:      	adds	x9, x10, x11
    b6b0:      	csinv	x10, x9, xzr, lo
    b6b4:      	lsr	x9, x8, #14
    b6b8:      	str	x11, [sp, #0x120]
    b6bc:      	str	x11, [sp, #0x148]
    b6c0:      	cbnz	x9, 0xb748 <_wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65+0x110>
    b6c4:      	sub	x9, x8, x8, lsr #2
    b6c8:      	cmp	x10, x9
    b6cc:      	b.lo	0xb748 <_wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65+0x110>
    b6d0:      	ldp	q1, q0, [x1]
    b6d4:      	stp	q1, q0, [sp, #0x150]
    b6d8:      	ldr	x10, [x1, #0x20]
    b6dc:      	str	x10, [sp, #0x170]
    b6e0:      	ldr	x10, [sp, #0x168]
    b6e4:      	mov	x19, x0
    b6e8:      	mov	x20, x2
    b6ec:      	cmp	x10, x9, lsr #1
    b6f0:      	b.lo	0xb710 <_wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65+0xd8>
    b6f4:      	cbz	x8, 0xb70c <_wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65+0xd4>
    b6f8:      	mov	w9, #0x2000             ; =8192
    b6fc:      	cmp	x8, #0x2, lsl #12       ; =0x2000
    b700:      	csel	x8, x8, x9, lo
    b704:      	lsl	x8, x8, #1
    b708:      	b	0xb710 <_wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65+0xd8>
    b70c:      	mov	w8, #0x1                ; =1
    b710:      	mov	x0, x1
    b714:      	mov	x21, x1
    b718:      	mov	x1, x8
    b71c:      	mov	x2, x4
    b720:      	mov	x22, x4
    b724:      	bl	0xb724 <_wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65+0xec>
		000000000000b724:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    b728:      	mov	x4, x22
    b72c:      	mov	x8, x1
    b730:      	mov	x1, x21
    b734:      	str	w0, [sp, #0x178]
    b738:      	strb	w8, [sp, #0x17c]
    b73c:      	strb	w2, [sp, #0x17d]
    b740:      	mov	x2, x20
    b744:      	mov	x0, x19
    b748:      	mov	x3, sp
    b74c:      	bl	0xb74c <_wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65+0x114>
		000000000000b74c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
    b750:      	ldp	x29, x30, [sp, #0x1b0]
    b754:      	ldp	x20, x19, [sp, #0x1a0]
    b758:      	ldp	x22, x21, [sp, #0x190]
    b75c:      	ldp	x28, x27, [sp, #0x180]
    b760:      	add	sp, sp, #0x1c0
    b764:      	ret

000000000000b768 <_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65>:
    b768:      	ldr	x8, [x1, #0x18]
    b76c:      	cbz	x8, 0xb8d4 <_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65+0x16c>
    b770:      	ldrb	w9, [x3, #0x8]
    b774:      	tbz	w9, #0x0, 0xb788 <_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65+0x20>
    b778:      	mov	x9, #0x0                ; =0
    b77c:      	ldr	x11, [x1]
    b780:      	cbnz	x11, 0xb7d0 <_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65+0x68>
    b784:      	b	0xb8d4 <_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65+0x16c>
    b788:      	ldr	x9, [x3]
    b78c:      	ldr	x10, [x2]
    b790:      	eor	x9, x10, x9
    b794:      	eor	x9, x9, x9, lsr #30
    b798:      	mov	x10, #0xe5b9            ; =58809
    b79c:      	movk	x10, #0x1ce4, lsl #16
    b7a0:      	movk	x10, #0x476d, lsl #32
    b7a4:      	movk	x10, #0xbf58, lsl #48
    b7a8:      	mul	x9, x9, x10
    b7ac:      	eor	x9, x9, x9, lsr #27
    b7b0:      	mov	x10, #0x11eb            ; =4587
    b7b4:      	movk	x10, #0x1331, lsl #16
    b7b8:      	movk	x10, #0x49bb, lsl #32
    b7bc:      	movk	x10, #0x94d0, lsl #48
    b7c0:      	mul	x9, x9, x10
    b7c4:      	eor	x9, x9, x9, lsr #31
    b7c8:      	ldr	x11, [x1]
    b7cc:      	cbz	x11, 0xb8d4 <_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65+0x16c>
    b7d0:      	udiv	x10, x9, x11
    b7d4:      	msub	x12, x10, x11, x9
    b7d8:      	ldr	x13, [x1, #0x10]
    b7dc:      	mov	w14, #0x110             ; =272
    b7e0:      	mov	x15, x11
    b7e4:      	b	0xb7fc <_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65+0x94>
    b7e8:      	add	x9, x12, #0x1
    b7ec:      	cmp	x9, x11
    b7f0:      	csinc	x12, xzr, x12, hs
    b7f4:      	subs	x15, x15, #0x1
    b7f8:      	b.eq	0xb8d4 <_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65+0x16c>
    b7fc:      	madd	x9, x12, x14, x13
    b800:      	ldr	w10, [x9]
    b804:      	cmp	w10, #0x1
    b808:      	b.eq	0xb7e8 <_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65+0x80>
    b80c:      	cmp	w10, #0x2
    b810:      	b.ne	0xb8d4 <_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65+0x16c>
    b814:      	ldr	x10, [x9, #0x8]
    b818:      	ldr	x16, [x2]
    b81c:      	cmp	x10, x16
    b820:      	b.ne	0xb7e8 <_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65+0x80>
    b824:      	mov	w11, #0x1               ; =1
    b828:      	str	w11, [x9]
    b82c:      	sub	x8, x8, #0x1
    b830:      	ldp	q0, q1, [x9, #0x10]
    b834:      	ldp	q2, q3, [x9, #0x30]
    b838:      	ldp	q4, q5, [x9, #0x50]
    b83c:      	ldp	q6, q7, [x9, #0x70]
    b840:      	ldp	q16, q17, [x9, #0x90]
    b844:      	ldp	q18, q19, [x9, #0xb0]
    b848:      	ldp	q20, q21, [x9, #0xd0]
    b84c:      	ldp	q22, q23, [x9, #0xf0]
    b850:      	movi.2d	v24, #0000000000000000
    b854:      	stur	q24, [x9, #0x18]
    b858:      	stur	q24, [x9, #0x28]
    b85c:      	stur	q24, [x9, #0x38]
    b860:      	stur	q24, [x9, #0x48]
    b864:      	stur	q24, [x9, #0x58]
    b868:      	stur	q24, [x9, #0x68]
    b86c:      	stur	q24, [x9, #0x78]
    b870:      	stur	q24, [x9, #0x88]
    b874:      	stur	q24, [x9, #0x98]
    b878:      	stur	q24, [x9, #0xa8]
    b87c:      	stur	q24, [x9, #0xb8]
    b880:      	stur	q24, [x9, #0xc8]
    b884:      	stur	q24, [x9, #0xd8]
    b888:      	stur	q24, [x9, #0xe8]
    b88c:      	stur	q24, [x9, #0xf8]
    b890:      	stur	q24, [x9, #0x8]
    b894:      	str	xzr, [x9, #0x108]
    b898:      	ldr	x9, [x1, #0x20]
    b89c:      	adds	x9, x9, #0x1
    b8a0:      	csinv	x9, x9, xzr, lo
    b8a4:      	stp	x8, x9, [x1, #0x18]
    b8a8:      	stp	xzr, x10, [x0]
    b8ac:      	str	w11, [x0]
    b8b0:      	stp	q0, q1, [x0, #0x10]
    b8b4:      	stp	q2, q3, [x0, #0x30]
    b8b8:      	stp	q4, q5, [x0, #0x50]
    b8bc:      	stp	q6, q7, [x0, #0x70]
    b8c0:      	stp	q16, q17, [x0, #0x90]
    b8c4:      	stp	q18, q19, [x0, #0xb0]
    b8c8:      	stp	q20, q21, [x0, #0xd0]
    b8cc:      	stp	q22, q23, [x0, #0xf0]
    b8d0:      	ret
    b8d4:      	movi.2d	v0, #0000000000000000
    b8d8:      	stp	q0, q0, [x0, #0xf0]
    b8dc:      	stp	q0, q0, [x0, #0xd0]
    b8e0:      	stp	q0, q0, [x0, #0xb0]
    b8e4:      	stp	q0, q0, [x0, #0x90]
    b8e8:      	stp	q0, q0, [x0, #0x70]
    b8ec:      	stp	q0, q0, [x0, #0x50]
    b8f0:      	stp	q0, q0, [x0, #0x30]
    b8f4:      	stp	q0, q0, [x0, #0x10]
    b8f8:      	str	q0, [x0]
    b8fc:      	ret

000000000000b900 <_wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe>:
    b900:      	ldrb	w8, [x2, #0x8]
    b904:      	tbz	w8, #0x0, 0xb918 <_wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe+0x18>
    b908:      	mov	x8, #0x0                ; =0
    b90c:      	ldr	x9, [x0]
    b910:      	cbnz	x9, 0xb960 <_wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe+0x60>
    b914:      	b	0xb9c8 <_wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe+0xc8>
    b918:      	ldr	x8, [x2]
    b91c:      	ldr	x9, [x1]
    b920:      	eor	x8, x9, x8
    b924:      	eor	x8, x8, x8, lsr #30
    b928:      	mov	x9, #0xe5b9             ; =58809
    b92c:      	movk	x9, #0x1ce4, lsl #16
    b930:      	movk	x9, #0x476d, lsl #32
    b934:      	movk	x9, #0xbf58, lsl #48
    b938:      	mul	x8, x8, x9
    b93c:      	eor	x8, x8, x8, lsr #27
    b940:      	mov	x9, #0x11eb             ; =4587
    b944:      	movk	x9, #0x1331, lsl #16
    b948:      	movk	x9, #0x49bb, lsl #32
    b94c:      	movk	x9, #0x94d0, lsl #48
    b950:      	mul	x8, x8, x9
    b954:      	eor	x8, x8, x8, lsr #31
    b958:      	ldr	x9, [x0]
    b95c:      	cbz	x9, 0xb9c8 <_wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe+0xc8>
    b960:      	udiv	x10, x8, x9
    b964:      	msub	x10, x10, x9, x8
    b968:      	ldr	x11, [x0, #0x10]
    b96c:      	mov	w12, #0x110             ; =272
    b970:      	mov	x13, x9
    b974:      	b	0xb98c <_wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe+0x8c>
    b978:      	add	x8, x10, #0x1
    b97c:      	cmp	x8, x9
    b980:      	csinc	x10, xzr, x10, hs
    b984:      	subs	x13, x13, #0x1
    b988:      	b.eq	0xb9c8 <_wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe+0xc8>
    b98c:      	madd	x14, x10, x12, x11
    b990:      	ldr	w8, [x14]
    b994:      	cmp	w8, #0x1
    b998:      	b.eq	0xb978 <_wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe+0x78>
    b99c:      	cmp	w8, #0x2
    b9a0:      	b.ne	0xb9cc <_wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe+0xcc>
    b9a4:      	ldr	x8, [x14, #0x8]
    b9a8:      	ldr	x15, [x1]
    b9ac:      	cmp	x8, x15
    b9b0:      	b.ne	0xb978 <_wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe+0x78>
    b9b4:      	mov	w0, #0x0                ; =0
    b9b8:      	ldr	x8, [x14, #0x10]
    b9bc:      	mov	x1, x8
    b9c0:      	mov	w2, #0x0                ; =0
    b9c4:      	ret
    b9c8:      	mov	x8, #0x0                ; =0
    b9cc:      	mov	w0, #0x1                ; =1
    b9d0:      	mov	x1, x8
    b9d4:      	mov	w2, #0x0                ; =0
    b9d8:      	ret

000000000000b9dc <_wf_std.collections.hash_map.hash_map_rehash$instance$28da32efc51c2b65>:
    b9dc:      	mov	x2, x1
    b9e0:      	ldr	x1, [x0]
    b9e4:      	b	0xb9e4 <_wf_std.collections.hash_map.hash_map_rehash$instance$28da32efc51c2b65+0x8>
		000000000000b9e4:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65

000000000000b9e8 <_wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65>:
    b9e8:      	cmp	x1, #0x4, lsl #12       ; =0x4000
    b9ec:      	b.ls	0xba00 <_wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65+0x18>
    b9f0:      	mov	w2, #0x0                ; =0
    b9f4:      	mov	w1, #0x0                ; =0
    b9f8:      	mov	w0, #0x1                ; =1
    b9fc:      	ret
    ba00:      	ldr	x8, [x0]
    ba04:      	cmp	x1, x8
    ba08:      	b.ls	0xba1c <_wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65+0x34>
    ba0c:      	stp	x29, x30, [sp, #-0x10]!
    ba10:      	bl	0xba10 <_wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65+0x28>
		000000000000ba10:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
    ba14:      	ldp	x29, x30, [sp], #0x10
    ba18:      	ret
    ba1c:      	mov	w2, #0x0                ; =0
    ba20:      	mov	w1, #0x0                ; =0
    ba24:      	mov	w0, #0x0                ; =0
    ba28:      	ret

000000000000ba2c <_wf_std.collections.hash_map.hash_map_capacity$instance$0e108827ecbbe374>:
    ba2c:      	ldr	x0, [x0]
    ba30:      	ret

000000000000ba34 <_wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49>:
    ba34:      	ldrb	w8, [x2, #0x8]
    ba38:      	tbz	w8, #0x0, 0xba4c <_wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49+0x18>
    ba3c:      	mov	x8, #0x0                ; =0
    ba40:      	ldr	x9, [x0]
    ba44:      	cbnz	x9, 0xba94 <_wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49+0x60>
    ba48:      	b	0xbb10 <_wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49+0xdc>
    ba4c:      	ldr	x8, [x2]
    ba50:      	ldr	x9, [x1]
    ba54:      	eor	x8, x9, x8
    ba58:      	eor	x8, x8, x8, lsr #30
    ba5c:      	mov	x9, #0xe5b9             ; =58809
    ba60:      	movk	x9, #0x1ce4, lsl #16
    ba64:      	movk	x9, #0x476d, lsl #32
    ba68:      	movk	x9, #0xbf58, lsl #48
    ba6c:      	mul	x8, x8, x9
    ba70:      	eor	x8, x8, x8, lsr #27
    ba74:      	mov	x9, #0x11eb             ; =4587
    ba78:      	movk	x9, #0x1331, lsl #16
    ba7c:      	movk	x9, #0x49bb, lsl #32
    ba80:      	movk	x9, #0x94d0, lsl #48
    ba84:      	mul	x8, x8, x9
    ba88:      	eor	x8, x8, x8, lsr #31
    ba8c:      	ldr	x9, [x0]
    ba90:      	cbz	x9, 0xbb10 <_wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49+0xdc>
    ba94:      	mov	x10, #0x0               ; =0
    ba98:      	udiv	x11, x8, x9
    ba9c:      	msub	x11, x11, x9, x8
    baa0:      	sub	x12, x9, x11
    baa4:      	neg	x13, x12
    baa8:      	ldr	x14, [x0, #0x10]
    baac:      	mov	w15, #0x110             ; =272
    bab0:      	b	0xbac0 <_wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49+0x8c>
    bab4:      	add	x10, x10, #0x1
    bab8:      	cmp	x9, x10
    babc:      	b.eq	0xbb10 <_wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49+0xdc>
    bac0:      	cmp	x10, x12
    bac4:      	csel	x8, x11, x13, lo
    bac8:      	add	x8, x8, x10
    bacc:      	madd	x16, x8, x15, x14
    bad0:      	ldr	w8, [x16]
    bad4:      	cmp	w8, #0x1
    bad8:      	b.eq	0xbab4 <_wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49+0x80>
    badc:      	cmp	w8, #0x2
    bae0:      	b.ne	0xbb14 <_wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49+0xe0>
    bae4:      	ldr	x8, [x16, #0x8]
    bae8:      	ldr	x17, [x1]
    baec:      	cmp	x8, x17
    baf0:      	b.ne	0xbab4 <_wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49+0x80>
    baf4:      	mov	w0, #0x0                ; =0
    baf8:      	ldr	x8, [x16, #0x10]
    bafc:      	add	x8, x8, #0x1
    bb00:      	str	x8, [x16, #0x10]
    bb04:      	mov	x1, x8
    bb08:      	mov	w2, #0x0                ; =0
    bb0c:      	ret
    bb10:      	mov	x8, #0x0                ; =0
    bb14:      	mov	w0, #0x1                ; =1
    bb18:      	mov	x1, x8
    bb1c:      	mov	w2, #0x0                ; =0
    bb20:      	ret

000000000000bb24 <_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71>:
    bb24:      	stp	x29, x30, [sp, #-0x10]!
    bb28:      	ldp	x9, x8, [x0]
    bb2c:      	ldr	x0, [x0, #0x10]
    bb30:      	cbz	x9, 0xbc78 <_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71+0x154>
    bb34:      	ldp	x10, x11, [x1, #0x8]
    bb38:      	mov	w12, #0x110             ; =272
    bb3c:      	madd	x13, x9, x12, x0
    bb40:      	ldr	x12, [x1, #0x18]
    bb44:      	sub	x13, x13, #0x88
    bb48:      	mov	w14, #0x83              ; =131
    bb4c:      	mov	x15, #0xe5b9            ; =58809
    bb50:      	movk	x15, #0x1ce4, lsl #16
    bb54:      	movk	x15, #0x476d, lsl #32
    bb58:      	movk	x15, #0xbf58, lsl #48
    bb5c:      	mov	x16, #0x11eb            ; =4587
    bb60:      	movk	x16, #0x1331, lsl #16
    bb64:      	movk	x16, #0x49bb, lsl #32
    bb68:      	movk	x16, #0x94d0, lsl #48
    bb6c:      	b	0xbb7c <_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71+0x58>
    bb70:      	sub	x13, x13, #0x110
    bb74:      	sub	x9, x9, #0x1
    bb78:      	cbz	x9, 0xbc78 <_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71+0x154>
    bb7c:      	ldur	w17, [x13, #-0x88]
    bb80:      	cmp	w17, #0x2
    bb84:      	b.ne	0xbb70 <_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71+0x4c>
    bb88:      	ldp	x2, x17, [x13, #-0x80]
    bb8c:      	madd	x17, x2, x14, x17
    bb90:      	ldp	x3, x2, [x13, #-0x70]
    bb94:      	madd	x17, x17, x14, x3
    bb98:      	madd	x17, x17, x14, x2
    bb9c:      	ldp	x3, x2, [x13, #-0x60]
    bba0:      	madd	x17, x17, x14, x3
    bba4:      	madd	x17, x17, x14, x2
    bba8:      	ldp	x3, x2, [x13, #-0x50]
    bbac:      	madd	x17, x17, x14, x3
    bbb0:      	madd	x17, x17, x14, x2
    bbb4:      	ldp	x3, x2, [x13, #-0x40]
    bbb8:      	madd	x17, x17, x14, x3
    bbbc:      	madd	x17, x17, x14, x2
    bbc0:      	ldp	x3, x2, [x13, #-0x30]
    bbc4:      	madd	x17, x17, x14, x3
    bbc8:      	madd	x17, x17, x14, x2
    bbcc:      	ldp	x3, x2, [x13, #-0x20]
    bbd0:      	madd	x17, x17, x14, x3
    bbd4:      	madd	x17, x17, x14, x2
    bbd8:      	ldp	x3, x2, [x13, #-0x10]
    bbdc:      	madd	x17, x17, x14, x3
    bbe0:      	madd	x17, x17, x14, x2
    bbe4:      	ldp	x3, x2, [x13]
    bbe8:      	madd	x17, x17, x14, x3
    bbec:      	madd	x17, x17, x14, x2
    bbf0:      	ldp	x3, x2, [x13, #0x10]
    bbf4:      	madd	x17, x17, x14, x3
    bbf8:      	madd	x17, x17, x14, x2
    bbfc:      	ldp	x3, x2, [x13, #0x20]
    bc00:      	madd	x17, x17, x14, x3
    bc04:      	madd	x17, x17, x14, x2
    bc08:      	ldp	x3, x2, [x13, #0x30]
    bc0c:      	madd	x17, x17, x14, x3
    bc10:      	madd	x17, x17, x14, x2
    bc14:      	ldp	x3, x2, [x13, #0x40]
    bc18:      	madd	x17, x17, x14, x3
    bc1c:      	madd	x17, x17, x14, x2
    bc20:      	ldp	x3, x2, [x13, #0x50]
    bc24:      	madd	x17, x17, x14, x3
    bc28:      	madd	x17, x17, x14, x2
    bc2c:      	ldp	x3, x2, [x13, #0x60]
    bc30:      	madd	x17, x17, x14, x3
    bc34:      	madd	x17, x17, x14, x2
    bc38:      	ldp	x3, x2, [x13, #0x70]
    bc3c:      	madd	x17, x17, x14, x3
    bc40:      	madd	x17, x17, x14, x2
    bc44:      	ldr	x2, [x13, #0x80]
    bc48:      	madd	x17, x17, x14, x2
    bc4c:      	add	x10, x17, x10
    bc50:      	eor	x17, x17, x17, lsr #30
    bc54:      	mul	x17, x17, x15
    bc58:      	eor	x17, x17, x17, lsr #27
    bc5c:      	mul	x17, x17, x16
    bc60:      	eor	x11, x11, x17, lsr #31
    bc64:      	eor	x11, x11, x17
    bc68:      	stp	x10, x11, [x1, #0x8]
    bc6c:      	add	x12, x12, #0x1
    bc70:      	str	x12, [x1, #0x18]
    bc74:      	b	0xbb70 <_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71+0x4c>
    bc78:      	cbz	x8, 0xbc80 <_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71+0x15c>
    bc7c:      	bl	0xbc7c <_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71+0x158>
		000000000000bc7c:  ARM64_RELOC_BRANCH26	_free
    bc80:      	mov	w0, #0x0                ; =0
    bc84:      	ldp	x29, x30, [sp], #0x10
    bc88:      	ret

000000000000bc8c <_wf_std.collections.hash_map.hash_map_len$instance$820b2044b97e0fbd>:
    bc8c:      	ldr	x0, [x0, #0x18]
    bc90:      	ret

000000000000bc94 <_wf_std.collections.hash_map.hash_map_len$instance$0e108827ecbbe374>:
    bc94:      	ldr	x0, [x0, #0x18]
    bc98:      	ret

000000000000bc9c <_wf_box_slots_new$instance$9c4aeb814d69349e>:
    bc9c:      	stp	x20, x19, [sp, #-0x20]!
    bca0:      	stp	x29, x30, [sp, #0x10]
    bca4:      	mov	x19, x0
    bca8:      	cbz	x0, 0xbcd4 <_wf_box_slots_new$instance$9c4aeb814d69349e+0x38>
    bcac:      	add	x8, x19, x19, lsl #1
    bcb0:      	lsl	x0, x8, #3
    bcb4:      	bl	0xbcb4 <_wf_box_slots_new$instance$9c4aeb814d69349e+0x18>
		000000000000bcb4:  ARM64_RELOC_BRANCH26	_malloc
    bcb8:      	mov	x2, x0
    bcbc:      	cbz	x0, 0xbcf0 <_wf_box_slots_new$instance$9c4aeb814d69349e+0x54>
    bcc0:      	mov	x0, #0x0                ; =0
    bcc4:      	mov	x1, x19
    bcc8:      	ldp	x29, x30, [sp, #0x10]
    bccc:      	ldp	x20, x19, [sp], #0x20
    bcd0:      	ret
    bcd4:      	adrp	x2, 0xb000 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xf4>
		000000000000bcd4:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    bcd8:      	add	x2, x2, #0x0
		000000000000bcd8:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    bcdc:      	mov	x0, #0x0                ; =0
    bce0:      	mov	x1, x19
    bce4:      	ldp	x29, x30, [sp, #0x10]
    bce8:      	ldp	x20, x19, [sp], #0x20
    bcec:      	ret
    bcf0:      	bl	0xbcf0 <_wf_box_slots_new$instance$9c4aeb814d69349e+0x54>
		000000000000bcf0:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000bcf4 <_wf_chain_insert$instance$fc5e3cb62bdf3601>:
    bcf4:      	ldrb	w8, [x4, #0x8]
    bcf8:      	tbz	w8, #0x0, 0xbd0c <_wf_chain_insert$instance$fc5e3cb62bdf3601+0x18>
    bcfc:      	mov	x9, #0x0                ; =0
    bd00:      	ldr	x10, [x1]
    bd04:      	cbnz	x10, 0xbd50 <_wf_chain_insert$instance$fc5e3cb62bdf3601+0x5c>
    bd08:      	b	0xbd5c <_wf_chain_insert$instance$fc5e3cb62bdf3601+0x68>
    bd0c:      	ldr	x8, [x4]
    bd10:      	eor	x8, x8, x2
    bd14:      	eor	x8, x8, x8, lsr #30
    bd18:      	mov	x9, #0xe5b9             ; =58809
    bd1c:      	movk	x9, #0x1ce4, lsl #16
    bd20:      	movk	x9, #0x476d, lsl #32
    bd24:      	movk	x9, #0xbf58, lsl #48
    bd28:      	mul	x8, x8, x9
    bd2c:      	eor	x8, x8, x8, lsr #27
    bd30:      	mov	x9, #0x11eb             ; =4587
    bd34:      	movk	x9, #0x1331, lsl #16
    bd38:      	movk	x9, #0x49bb, lsl #32
    bd3c:      	movk	x9, #0x94d0, lsl #48
    bd40:      	mul	x8, x8, x9
    bd44:      	eor	x9, x8, x8, lsr #31
    bd48:      	ldr	x10, [x1]
    bd4c:      	cbz	x10, 0xbd5c <_wf_chain_insert$instance$fc5e3cb62bdf3601+0x68>
    bd50:      	ldp	x8, x11, [x1, #0x18]
    bd54:      	cmp	x8, x11
    bd58:      	b.ne	0xbd70 <_wf_chain_insert$instance$fc5e3cb62bdf3601+0x7c>
    bd5c:      	stp	xzr, x2, [x0]
    bd60:      	mov	w8, #0x1                ; =1
    bd64:      	str	w8, [x0]
    bd68:      	str	x3, [x0, #0x10]
    bd6c:      	ret
    bd70:      	udiv	x11, x9, x10
    bd74:      	msub	x9, x11, x10, x9
    bd78:      	ldr	x10, [x1, #0x10]
    bd7c:      	ldr	x11, [x10, x9, lsl #3]
    bd80:      	ldr	x12, [x1, #0x28]
    bd84:      	mov	w13, #0x18              ; =24
    bd88:      	madd	x12, x8, x13, x12
    bd8c:      	stp	x2, x3, [x12]
    bd90:      	str	x11, [x12, #0x10]
    bd94:      	add	x11, x8, #0x1
    bd98:      	str	x11, [x1, #0x18]
    bd9c:      	str	x8, [x10, x9, lsl #3]
    bda0:      	stp	xzr, xzr, [x0]
    bda4:      	str	xzr, [x0, #0x10]
    bda8:      	ret

000000000000bdac <_wf_chain_lookup$instance$b1b46ac9d1583c8f>:
    bdac:      	ldrb	w8, [x2, #0x8]
    bdb0:      	tbz	w8, #0x0, 0xbdc4 <_wf_chain_lookup$instance$b1b46ac9d1583c8f+0x18>
    bdb4:      	mov	x9, #0x0                ; =0
    bdb8:      	ldr	x10, [x0]
    bdbc:      	cbnz	x10, 0xbe0c <_wf_chain_lookup$instance$b1b46ac9d1583c8f+0x60>
    bdc0:      	b	0xbe5c <_wf_chain_lookup$instance$b1b46ac9d1583c8f+0xb0>
    bdc4:      	ldr	x8, [x2]
    bdc8:      	ldr	x9, [x1]
    bdcc:      	eor	x8, x9, x8
    bdd0:      	eor	x8, x8, x8, lsr #30
    bdd4:      	mov	x9, #0xe5b9             ; =58809
    bdd8:      	movk	x9, #0x1ce4, lsl #16
    bddc:      	movk	x9, #0x476d, lsl #32
    bde0:      	movk	x9, #0xbf58, lsl #48
    bde4:      	mul	x8, x8, x9
    bde8:      	eor	x8, x8, x8, lsr #27
    bdec:      	mov	x9, #0x11eb             ; =4587
    bdf0:      	movk	x9, #0x1331, lsl #16
    bdf4:      	movk	x9, #0x49bb, lsl #32
    bdf8:      	movk	x9, #0x94d0, lsl #48
    bdfc:      	mul	x8, x8, x9
    be00:      	eor	x9, x8, x8, lsr #31
    be04:      	ldr	x10, [x0]
    be08:      	cbz	x10, 0xbe5c <_wf_chain_lookup$instance$b1b46ac9d1583c8f+0xb0>
    be0c:      	ldr	x8, [x0, #0x18]
    be10:      	cbz	x8, 0xbe5c <_wf_chain_lookup$instance$b1b46ac9d1583c8f+0xb0>
    be14:      	udiv	x11, x9, x10
    be18:      	msub	x9, x11, x10, x9
    be1c:      	ldr	x10, [x0, #0x10]
    be20:      	add	x11, x10, x9, lsl #3
    be24:      	mov	w9, #0x18               ; =24
    be28:      	mov	x10, x8
    be2c:      	ldr	x11, [x11]
    be30:      	cmp	x11, x8
    be34:      	b.hs	0xbe5c <_wf_chain_lookup$instance$b1b46ac9d1583c8f+0xb0>
    be38:      	ldr	x12, [x0, #0x28]
    be3c:      	madd	x11, x11, x9, x12
    be40:      	ldr	x12, [x11]
    be44:      	ldr	x13, [x1]
    be48:      	cmp	x12, x13
    be4c:      	b.eq	0xbe6c <_wf_chain_lookup$instance$b1b46ac9d1583c8f+0xc0>
    be50:      	add	x11, x11, #0x10
    be54:      	subs	x10, x10, #0x1
    be58:      	b.ne	0xbe2c <_wf_chain_lookup$instance$b1b46ac9d1583c8f+0x80>
    be5c:      	mov	x1, #0x0                ; =0
    be60:      	mov	w0, #0x1                ; =1
    be64:      	mov	w2, #0x0                ; =0
    be68:      	ret
    be6c:      	mov	w0, #0x0                ; =0
    be70:      	ldr	x1, [x11, #0x8]
    be74:      	mov	w2, #0x0                ; =0
    be78:      	ret

000000000000be7c <_wf_box_slots_new$instance$1883e0e22b50fc85>:
    be7c:      	stp	x20, x19, [sp, #-0x20]!
    be80:      	stp	x29, x30, [sp, #0x10]
    be84:      	mov	x19, x0
    be88:      	cbz	x0, 0xbeb4 <_wf_box_slots_new$instance$1883e0e22b50fc85+0x38>
    be8c:      	add	x8, x19, x19, lsl #4
    be90:      	lsl	x0, x8, #4
    be94:      	bl	0xbe94 <_wf_box_slots_new$instance$1883e0e22b50fc85+0x18>
		000000000000be94:  ARM64_RELOC_BRANCH26	_malloc
    be98:      	mov	x2, x0
    be9c:      	cbz	x0, 0xbed0 <_wf_box_slots_new$instance$1883e0e22b50fc85+0x54>
    bea0:      	mov	x0, #0x0                ; =0
    bea4:      	mov	x1, x19
    bea8:      	ldp	x29, x30, [sp, #0x10]
    beac:      	ldp	x20, x19, [sp], #0x20
    beb0:      	ret
    beb4:      	adrp	x2, 0xb000 <_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19+0xf4>
		000000000000beb4:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    beb8:      	add	x2, x2, #0x0
		000000000000beb8:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    bebc:      	mov	x0, #0x0                ; =0
    bec0:      	mov	x1, x19
    bec4:      	ldp	x29, x30, [sp, #0x10]
    bec8:      	ldp	x20, x19, [sp], #0x20
    becc:      	ret
    bed0:      	bl	0xbed0 <_wf_box_slots_new$instance$1883e0e22b50fc85+0x54>
		000000000000bed0:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000bed4 <_wf_chain_insert$instance$c6df3d8464f8cde0>:
    bed4:      	ldrb	w8, [x4, #0x8]
    bed8:      	tbz	w8, #0x0, 0xbeec <_wf_chain_insert$instance$c6df3d8464f8cde0+0x18>
    bedc:      	mov	x9, #0x0                ; =0
    bee0:      	ldr	x10, [x1]
    bee4:      	cbnz	x10, 0xbf30 <_wf_chain_insert$instance$c6df3d8464f8cde0+0x5c>
    bee8:      	b	0xbf3c <_wf_chain_insert$instance$c6df3d8464f8cde0+0x68>
    beec:      	ldr	x8, [x4]
    bef0:      	eor	x8, x8, x2
    bef4:      	eor	x8, x8, x8, lsr #30
    bef8:      	mov	x9, #0xe5b9             ; =58809
    befc:      	movk	x9, #0x1ce4, lsl #16
    bf00:      	movk	x9, #0x476d, lsl #32
    bf04:      	movk	x9, #0xbf58, lsl #48
    bf08:      	mul	x8, x8, x9
    bf0c:      	eor	x8, x8, x8, lsr #27
    bf10:      	mov	x9, #0x11eb             ; =4587
    bf14:      	movk	x9, #0x1331, lsl #16
    bf18:      	movk	x9, #0x49bb, lsl #32
    bf1c:      	movk	x9, #0x94d0, lsl #48
    bf20:      	mul	x8, x8, x9
    bf24:      	eor	x9, x8, x8, lsr #31
    bf28:      	ldr	x10, [x1]
    bf2c:      	cbz	x10, 0xbf3c <_wf_chain_insert$instance$c6df3d8464f8cde0+0x68>
    bf30:      	ldp	x8, x11, [x1, #0x18]
    bf34:      	cmp	x8, x11
    bf38:      	b.ne	0xbf8c <_wf_chain_insert$instance$c6df3d8464f8cde0+0xb8>
    bf3c:      	ldp	q0, q1, [x3]
    bf40:      	ldp	q2, q3, [x3, #0x20]
    bf44:      	ldp	q4, q5, [x3, #0x40]
    bf48:      	ldp	q6, q7, [x3, #0x60]
    bf4c:      	ldp	q16, q17, [x3, #0x80]
    bf50:      	ldp	q18, q19, [x3, #0xa0]
    bf54:      	ldp	q20, q21, [x3, #0xc0]
    bf58:      	ldp	q22, q23, [x3, #0xe0]
    bf5c:      	stp	xzr, x2, [x0]
    bf60:      	mov	w8, #0x1                ; =1
    bf64:      	str	w8, [x0]
    bf68:      	stp	q0, q1, [x0, #0x10]
    bf6c:      	stp	q2, q3, [x0, #0x30]
    bf70:      	stp	q4, q5, [x0, #0x50]
    bf74:      	stp	q6, q7, [x0, #0x70]
    bf78:      	stp	q16, q17, [x0, #0x90]
    bf7c:      	stp	q18, q19, [x0, #0xb0]
    bf80:      	stp	q20, q21, [x0, #0xd0]
    bf84:      	stp	q22, q23, [x0, #0xf0]
    bf88:      	ret
    bf8c:      	ldr	x11, [x1, #0x10]
    bf90:      	udiv	x12, x9, x10
    bf94:      	msub	x9, x12, x10, x9
    bf98:      	ldr	x10, [x11, x9, lsl #3]
    bf9c:      	ldr	x12, [x1, #0x28]
    bfa0:      	ldp	q0, q1, [x3]
    bfa4:      	ldp	q2, q3, [x3, #0x20]
    bfa8:      	ldp	q4, q5, [x3, #0x40]
    bfac:      	ldp	q6, q7, [x3, #0x60]
    bfb0:      	ldp	q16, q17, [x3, #0x80]
    bfb4:      	ldp	q18, q19, [x3, #0xa0]
    bfb8:      	ldp	q20, q21, [x3, #0xc0]
    bfbc:      	ldp	q22, q23, [x3, #0xe0]
    bfc0:      	mov	w13, #0x110             ; =272
    bfc4:      	madd	x12, x8, x13, x12
    bfc8:      	str	x2, [x12]
    bfcc:      	stur	q0, [x12, #0x8]
    bfd0:      	stur	q1, [x12, #0x18]
    bfd4:      	stur	q2, [x12, #0x28]
    bfd8:      	stur	q3, [x12, #0x38]
    bfdc:      	stur	q4, [x12, #0x48]
    bfe0:      	stur	q5, [x12, #0x58]
    bfe4:      	stur	q6, [x12, #0x68]
    bfe8:      	stur	q7, [x12, #0x78]
    bfec:      	stur	q16, [x12, #0x88]
    bff0:      	stur	q17, [x12, #0x98]
    bff4:      	stur	q18, [x12, #0xa8]
    bff8:      	stur	q19, [x12, #0xb8]
    bffc:      	stur	q20, [x12, #0xc8]
    c000:      	stur	q21, [x12, #0xd8]
    c004:      	stur	q22, [x12, #0xe8]
    c008:      	stur	q23, [x12, #0xf8]
    c00c:      	str	x10, [x12, #0x108]
    c010:      	add	x10, x8, #0x1
    c014:      	str	x10, [x1, #0x18]
    c018:      	str	x8, [x11, x9, lsl #3]
    c01c:      	movi.2d	v0, #0000000000000000
    c020:      	stp	q0, q0, [x0, #0xf0]
    c024:      	stp	q0, q0, [x0, #0xd0]
    c028:      	stp	q0, q0, [x0, #0xb0]
    c02c:      	stp	q0, q0, [x0, #0x90]
    c030:      	stp	q0, q0, [x0, #0x70]
    c034:      	stp	q0, q0, [x0, #0x50]
    c038:      	stp	q0, q0, [x0, #0x30]
    c03c:      	stp	q0, q0, [x0, #0x10]
    c040:      	str	q0, [x0]
    c044:      	ret

000000000000c048 <_wf_chain_lookup$instance$0aacc27190a3eaff>:
    c048:      	ldrb	w8, [x2, #0x8]
    c04c:      	tbz	w8, #0x0, 0xc060 <_wf_chain_lookup$instance$0aacc27190a3eaff+0x18>
    c050:      	mov	x9, #0x0                ; =0
    c054:      	ldr	x10, [x0]
    c058:      	cbnz	x10, 0xc0a8 <_wf_chain_lookup$instance$0aacc27190a3eaff+0x60>
    c05c:      	b	0xc0f8 <_wf_chain_lookup$instance$0aacc27190a3eaff+0xb0>
    c060:      	ldr	x8, [x2]
    c064:      	ldr	x9, [x1]
    c068:      	eor	x8, x9, x8
    c06c:      	eor	x8, x8, x8, lsr #30
    c070:      	mov	x9, #0xe5b9             ; =58809
    c074:      	movk	x9, #0x1ce4, lsl #16
    c078:      	movk	x9, #0x476d, lsl #32
    c07c:      	movk	x9, #0xbf58, lsl #48
    c080:      	mul	x8, x8, x9
    c084:      	eor	x8, x8, x8, lsr #27
    c088:      	mov	x9, #0x11eb             ; =4587
    c08c:      	movk	x9, #0x1331, lsl #16
    c090:      	movk	x9, #0x49bb, lsl #32
    c094:      	movk	x9, #0x94d0, lsl #48
    c098:      	mul	x8, x8, x9
    c09c:      	eor	x9, x8, x8, lsr #31
    c0a0:      	ldr	x10, [x0]
    c0a4:      	cbz	x10, 0xc0f8 <_wf_chain_lookup$instance$0aacc27190a3eaff+0xb0>
    c0a8:      	ldr	x8, [x0, #0x18]
    c0ac:      	cbz	x8, 0xc0f8 <_wf_chain_lookup$instance$0aacc27190a3eaff+0xb0>
    c0b0:      	udiv	x11, x9, x10
    c0b4:      	msub	x9, x11, x10, x9
    c0b8:      	ldr	x10, [x0, #0x10]
    c0bc:      	add	x11, x10, x9, lsl #3
    c0c0:      	mov	w9, #0x110              ; =272
    c0c4:      	mov	x10, x8
    c0c8:      	ldr	x11, [x11]
    c0cc:      	cmp	x11, x8
    c0d0:      	b.hs	0xc0f8 <_wf_chain_lookup$instance$0aacc27190a3eaff+0xb0>
    c0d4:      	ldr	x12, [x0, #0x28]
    c0d8:      	madd	x11, x11, x9, x12
    c0dc:      	ldr	x12, [x11]
    c0e0:      	ldr	x13, [x1]
    c0e4:      	cmp	x12, x13
    c0e8:      	b.eq	0xc108 <_wf_chain_lookup$instance$0aacc27190a3eaff+0xc0>
    c0ec:      	add	x11, x11, #0x108
    c0f0:      	subs	x10, x10, #0x1
    c0f4:      	b.ne	0xc0c8 <_wf_chain_lookup$instance$0aacc27190a3eaff+0x80>
    c0f8:      	mov	x1, #0x0                ; =0
    c0fc:      	mov	w0, #0x1                ; =1
    c100:      	mov	w2, #0x0                ; =0
    c104:      	ret
    c108:      	mov	w0, #0x0                ; =0
    c10c:      	ldr	x1, [x11, #0x8]
    c110:      	mov	w2, #0x0                ; =0
    c114:      	ret

000000000000c118 <_wf_std.collections.hash_map.hash_map_new$instance$e85fc351f8333b14>:
    c118:      	stp	x20, x19, [sp, #-0x20]!
    c11c:      	stp	x29, x30, [sp, #0x10]
    c120:      	mov	x20, x1
    c124:      	mov	x19, x0
    c128:      	cbz	x1, 0xc170 <_wf_std.collections.hash_map.hash_map_new$instance$e85fc351f8333b14+0x58>
    c12c:      	add	x8, x20, x20, lsl #1
    c130:      	lsl	x0, x8, #3
    c134:      	bl	0xc134 <_wf_std.collections.hash_map.hash_map_new$instance$e85fc351f8333b14+0x1c>
		000000000000c134:  ARM64_RELOC_BRANCH26	_malloc
    c138:      	cbz	x0, 0xc190 <_wf_std.collections.hash_map.hash_map_new$instance$e85fc351f8333b14+0x78>
    c13c:      	mov	x8, #0x0                ; =0
    c140:      	add	x9, x0, #0x8
    c144:      	stur	wzr, [x9, #-0x8]
    c148:      	add	x8, x8, #0x1
    c14c:      	stp	xzr, xzr, [x9], #0x18
    c150:      	cmp	x20, x8
    c154:      	b.ne	0xc144 <_wf_std.collections.hash_map.hash_map_new$instance$e85fc351f8333b14+0x2c>
    c158:      	stp	x20, x20, [x19]
    c15c:      	stp	xzr, xzr, [x19, #0x18]
    c160:      	str	x0, [x19, #0x10]
    c164:      	ldp	x29, x30, [sp, #0x10]
    c168:      	ldp	x20, x19, [sp], #0x20
    c16c:      	ret
    c170:      	adrp	x0, 0xc000 <_wf_chain_insert$instance$c6df3d8464f8cde0+0x12c>
		000000000000c170:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    c174:      	add	x0, x0, #0x0
		000000000000c174:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    c178:      	stp	x20, x20, [x19]
    c17c:      	stp	xzr, xzr, [x19, #0x18]
    c180:      	str	x0, [x19, #0x10]
    c184:      	ldp	x29, x30, [sp, #0x10]
    c188:      	ldp	x20, x19, [sp], #0x20
    c18c:      	ret
    c190:      	bl	0xc190 <_wf_std.collections.hash_map.hash_map_new$instance$e85fc351f8333b14+0x78>
		000000000000c190:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000c194 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e>:
    c194:      	ldrb	w8, [x4, #0x8]
    c198:      	tbz	w8, #0x0, 0xc224 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x90>
    c19c:      	mov	x9, #0x0                ; =0
    c1a0:      	ldr	x8, [x1]
    c1a4:      	cbz	x8, 0xc268 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0xd4>
    c1a8:      	udiv	x10, x9, x8
    c1ac:      	msub	x10, x10, x8, x9
    c1b0:      	ldr	x11, [x1, #0x10]
    c1b4:      	mov	w12, #0x18              ; =24
    c1b8:      	mov	x13, x8
    c1bc:      	mov	x9, x8
    c1c0:      	b	0xc1e0 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x4c>
    c1c4:      	cmp	x9, x8
    c1c8:      	csel	x9, x10, x9, eq
    c1cc:      	add	x14, x10, #0x1
    c1d0:      	cmp	x14, x8
    c1d4:      	csinc	x10, xzr, x10, hs
    c1d8:      	subs	x13, x13, #0x1
    c1dc:      	b.eq	0xc26c <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0xd8>
    c1e0:      	madd	x14, x10, x12, x11
    c1e4:      	ldr	w15, [x14]
    c1e8:      	cmp	w15, #0x1
    c1ec:      	b.eq	0xc1c4 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x30>
    c1f0:      	cmp	w15, #0x2
    c1f4:      	b.ne	0xc2c8 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x134>
    c1f8:      	ldr	x15, [x14, #0x8]
    c1fc:      	cmp	x15, x2
    c200:      	b.ne	0xc1cc <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x38>
    c204:      	ldr	x8, [x14, #0x10]
    c208:      	mov	w9, #0x2                ; =2
    c20c:      	str	w9, [x14]
    c210:      	str	x3, [x14, #0x10]
    c214:      	mov	w9, #0x1                ; =1
    c218:      	stp	x9, x2, [x0]
    c21c:      	str	x8, [x0, #0x10]
    c220:      	ret
    c224:      	ldr	x8, [x4]
    c228:      	eor	x8, x8, x2
    c22c:      	eor	x8, x8, x8, lsr #30
    c230:      	mov	x9, #0xe5b9             ; =58809
    c234:      	movk	x9, #0x1ce4, lsl #16
    c238:      	movk	x9, #0x476d, lsl #32
    c23c:      	movk	x9, #0xbf58, lsl #48
    c240:      	mul	x8, x8, x9
    c244:      	eor	x8, x8, x8, lsr #27
    c248:      	mov	x9, #0x11eb             ; =4587
    c24c:      	movk	x9, #0x1331, lsl #16
    c250:      	movk	x9, #0x49bb, lsl #32
    c254:      	movk	x9, #0x94d0, lsl #48
    c258:      	mul	x8, x8, x9
    c25c:      	eor	x9, x8, x8, lsr #31
    c260:      	ldr	x8, [x1]
    c264:      	cbnz	x8, 0xc1a8 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x14>
    c268:      	mov	x9, #0x0                ; =0
    c26c:      	cmp	x9, x8
    c270:      	b.hs	0xc2d8 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x144>
    c274:      	ldr	x8, [x1, #0x18]
    c278:      	lsr	x10, x8, #13
    c27c:      	cbnz	x10, 0xc2d8 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x144>
    c280:      	add	x8, x8, #0x1
    c284:      	str	x8, [x1, #0x18]
    c288:      	ldr	x8, [x1, #0x10]
    c28c:      	mov	w10, #0x18              ; =24
    c290:      	madd	x8, x9, x10, x8
    c294:      	ldr	w9, [x8]
    c298:      	cmp	w9, #0x1
    c29c:      	b.ne	0xc2f0 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x15c>
    c2a0:      	ldr	x9, [x1, #0x20]
    c2a4:      	subs	x9, x9, #0x1
    c2a8:      	csel	x9, xzr, x9, lo
    c2ac:      	str	x9, [x1, #0x20]
    c2b0:      	mov	w9, #0x2                ; =2
    c2b4:      	str	w9, [x8]
    c2b8:      	stp	x2, x3, [x8, #0x8]
    c2bc:      	stp	xzr, xzr, [x0, #0x8]
    c2c0:      	str	xzr, [x0]
    c2c4:      	ret
    c2c8:      	cmp	x9, x8
    c2cc:      	csel	x9, x10, x9, eq
    c2d0:      	cmp	x9, x8
    c2d4:      	b.lo	0xc274 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0xe0>
    c2d8:      	stp	xzr, x2, [x0]
    c2dc:      	mov	w8, #0x1                ; =1
    c2e0:      	str	w8, [x0]
    c2e4:      	strb	w8, [x0, #0x4]
    c2e8:      	str	x3, [x0, #0x10]
    c2ec:      	ret
    c2f0:      	ldur	q0, [x8, #0x8]
    c2f4:      	mov	w10, #0x2               ; =2
    c2f8:      	str	w10, [x8]
    c2fc:      	stp	x2, x3, [x8, #0x8]
    c300:      	cbz	w9, 0xc314 <_wf_std.collections.hash_map.hash_map_try_put$instance$29255544f66aec6e+0x180>
    c304:      	mov	w8, #0x1                ; =1
    c308:      	str	x8, [x0]
    c30c:      	stur	q0, [x0, #0x8]
    c310:      	ret
    c314:      	stp	xzr, xzr, [x0]
    c318:      	str	xzr, [x0, #0x10]
    c31c:      	ret

000000000000c320 <_wf_std.collections.hash_map.hash_map_remove$instance$29255544f66aec6e>:
    c320:      	ldr	x10, [x0, #0x18]
    c324:      	cbz	x10, 0xc40c <_wf_std.collections.hash_map.hash_map_remove$instance$29255544f66aec6e+0xec>
    c328:      	ldrb	w8, [x2, #0x8]
    c32c:      	tbz	w8, #0x0, 0xc340 <_wf_std.collections.hash_map.hash_map_remove$instance$29255544f66aec6e+0x20>
    c330:      	mov	x8, #0x0                ; =0
    c334:      	ldr	x11, [x0]
    c338:      	cbnz	x11, 0xc388 <_wf_std.collections.hash_map.hash_map_remove$instance$29255544f66aec6e+0x68>
    c33c:      	b	0xc40c <_wf_std.collections.hash_map.hash_map_remove$instance$29255544f66aec6e+0xec>
    c340:      	ldr	x8, [x2]
    c344:      	ldr	x9, [x1]
    c348:      	eor	x8, x9, x8
    c34c:      	eor	x8, x8, x8, lsr #30
    c350:      	mov	x9, #0xe5b9             ; =58809
    c354:      	movk	x9, #0x1ce4, lsl #16
    c358:      	movk	x9, #0x476d, lsl #32
    c35c:      	movk	x9, #0xbf58, lsl #48
    c360:      	mul	x8, x8, x9
    c364:      	eor	x8, x8, x8, lsr #27
    c368:      	mov	x9, #0x11eb             ; =4587
    c36c:      	movk	x9, #0x1331, lsl #16
    c370:      	movk	x9, #0x49bb, lsl #32
    c374:      	movk	x9, #0x94d0, lsl #48
    c378:      	mul	x8, x8, x9
    c37c:      	eor	x8, x8, x8, lsr #31
    c380:      	ldr	x11, [x0]
    c384:      	cbz	x11, 0xc40c <_wf_std.collections.hash_map.hash_map_remove$instance$29255544f66aec6e+0xec>
    c388:      	udiv	x9, x8, x11
    c38c:      	msub	x12, x9, x11, x8
    c390:      	ldr	x13, [x0, #0x10]
    c394:      	mov	w14, #0x18              ; =24
    c398:      	mov	x15, x11
    c39c:      	b	0xc3b4 <_wf_std.collections.hash_map.hash_map_remove$instance$29255544f66aec6e+0x94>
    c3a0:      	add	x8, x12, #0x1
    c3a4:      	cmp	x8, x11
    c3a8:      	csinc	x12, xzr, x12, hs
    c3ac:      	subs	x15, x15, #0x1
    c3b0:      	b.eq	0xc40c <_wf_std.collections.hash_map.hash_map_remove$instance$29255544f66aec6e+0xec>
    c3b4:      	madd	x16, x12, x14, x13
    c3b8:      	ldr	w8, [x16]
    c3bc:      	cmp	w8, #0x1
    c3c0:      	b.eq	0xc3a0 <_wf_std.collections.hash_map.hash_map_remove$instance$29255544f66aec6e+0x80>
    c3c4:      	cmp	w8, #0x2
    c3c8:      	b.ne	0xc424 <_wf_std.collections.hash_map.hash_map_remove$instance$29255544f66aec6e+0x104>
    c3cc:      	ldr	x9, [x16, #0x8]
    c3d0:      	ldr	x8, [x1]
    c3d4:      	cmp	x9, x8
    c3d8:      	b.ne	0xc3a0 <_wf_std.collections.hash_map.hash_map_remove$instance$29255544f66aec6e+0x80>
    c3dc:      	ldr	x2, [x16, #0x10]
    c3e0:      	mov	w8, #0x1                ; =1
    c3e4:      	str	w8, [x16]
    c3e8:      	sub	x10, x10, #0x1
    c3ec:      	stp	xzr, xzr, [x16, #0x8]
    c3f0:      	ldr	x11, [x0, #0x20]
    c3f4:      	adds	x11, x11, #0x1
    c3f8:      	csinv	x11, x11, xzr, lo
    c3fc:      	stp	x10, x11, [x0, #0x18]
    c400:      	mov	x0, x8
    c404:      	mov	x1, x9
    c408:      	ret
    c40c:      	mov	w8, #0x0                ; =0
    c410:      	mov	x9, #0x0                ; =0
    c414:      	mov	x2, #0x0                ; =0
    c418:      	mov	x0, x8
    c41c:      	mov	x1, x9
    c420:      	ret
    c424:      	mov	x9, x8
    c428:      	mov	x2, x8
    c42c:      	mov	x0, x8
    c430:      	mov	x1, x9
    c434:      	ret

000000000000c438 <_wf_std.collections.hash_map.hash_map_capacity$instance$e85fc351f8333b14>:
    c438:      	ldr	x0, [x0]
    c43c:      	ret

000000000000c440 <_wf_std.collections.hash_map.hash_map_len$instance$e85fc351f8333b14>:
    c440:      	ldr	x0, [x0, #0x18]
    c444:      	ret

000000000000c448 <_wf_std.collections.hash_map.hash_map_lookup$instance$7c9d455aedf48152>:
    c448:      	ldrb	w8, [x2, #0x8]
    c44c:      	tbz	w8, #0x0, 0xc460 <_wf_std.collections.hash_map.hash_map_lookup$instance$7c9d455aedf48152+0x18>
    c450:      	mov	x8, #0x0                ; =0
    c454:      	ldr	x9, [x0]
    c458:      	cbnz	x9, 0xc4a8 <_wf_std.collections.hash_map.hash_map_lookup$instance$7c9d455aedf48152+0x60>
    c45c:      	b	0xc510 <_wf_std.collections.hash_map.hash_map_lookup$instance$7c9d455aedf48152+0xc8>
    c460:      	ldr	x8, [x2]
    c464:      	ldr	x9, [x1]
    c468:      	eor	x8, x9, x8
    c46c:      	eor	x8, x8, x8, lsr #30
    c470:      	mov	x9, #0xe5b9             ; =58809
    c474:      	movk	x9, #0x1ce4, lsl #16
    c478:      	movk	x9, #0x476d, lsl #32
    c47c:      	movk	x9, #0xbf58, lsl #48
    c480:      	mul	x8, x8, x9
    c484:      	eor	x8, x8, x8, lsr #27
    c488:      	mov	x9, #0x11eb             ; =4587
    c48c:      	movk	x9, #0x1331, lsl #16
    c490:      	movk	x9, #0x49bb, lsl #32
    c494:      	movk	x9, #0x94d0, lsl #48
    c498:      	mul	x8, x8, x9
    c49c:      	eor	x8, x8, x8, lsr #31
    c4a0:      	ldr	x9, [x0]
    c4a4:      	cbz	x9, 0xc510 <_wf_std.collections.hash_map.hash_map_lookup$instance$7c9d455aedf48152+0xc8>
    c4a8:      	udiv	x10, x8, x9
    c4ac:      	msub	x10, x10, x9, x8
    c4b0:      	ldr	x11, [x0, #0x10]
    c4b4:      	mov	w12, #0x18              ; =24
    c4b8:      	mov	x13, x9
    c4bc:      	b	0xc4d4 <_wf_std.collections.hash_map.hash_map_lookup$instance$7c9d455aedf48152+0x8c>
    c4c0:      	add	x8, x10, #0x1
    c4c4:      	cmp	x8, x9
    c4c8:      	csinc	x10, xzr, x10, hs
    c4cc:      	subs	x13, x13, #0x1
    c4d0:      	b.eq	0xc510 <_wf_std.collections.hash_map.hash_map_lookup$instance$7c9d455aedf48152+0xc8>
    c4d4:      	madd	x14, x10, x12, x11
    c4d8:      	ldr	w8, [x14]
    c4dc:      	cmp	w8, #0x1
    c4e0:      	b.eq	0xc4c0 <_wf_std.collections.hash_map.hash_map_lookup$instance$7c9d455aedf48152+0x78>
    c4e4:      	cmp	w8, #0x2
    c4e8:      	b.ne	0xc514 <_wf_std.collections.hash_map.hash_map_lookup$instance$7c9d455aedf48152+0xcc>
    c4ec:      	ldr	x8, [x14, #0x8]
    c4f0:      	ldr	x15, [x1]
    c4f4:      	cmp	x8, x15
    c4f8:      	b.ne	0xc4c0 <_wf_std.collections.hash_map.hash_map_lookup$instance$7c9d455aedf48152+0x78>
    c4fc:      	mov	w0, #0x0                ; =0
    c500:      	ldr	x8, [x14, #0x10]
    c504:      	mov	x1, x8
    c508:      	mov	w2, #0x0                ; =0
    c50c:      	ret
    c510:      	mov	x8, #0x0                ; =0
    c514:      	mov	w0, #0x1                ; =1
    c518:      	mov	x1, x8
    c51c:      	mov	w2, #0x0                ; =0
    c520:      	ret

000000000000c524 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46>:
    c524:      	stp	x29, x30, [sp, #-0x10]!
    c528:      	ldp	x15, x8, [x0]
    c52c:      	ldr	x0, [x0, #0x10]
    c530:      	cbz	x15, 0xc5d8 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0xb4>
    c534:      	mov	x9, #0xe5b9             ; =58809
    c538:      	movk	x9, #0x1ce4, lsl #16
    c53c:      	movk	x9, #0x476d, lsl #32
    c540:      	movk	x9, #0xbf58, lsl #48
    c544:      	mov	x10, #0x11eb            ; =4587
    c548:      	movk	x10, #0x1331, lsl #16
    c54c:      	movk	x10, #0x49bb, lsl #32
    c550:      	movk	x10, #0x94d0, lsl #48
    c554:      	ldp	x11, x13, [x1, #0x8]
    c558:      	ldr	x12, [x1, #0x18]
    c55c:      	ands	x16, x15, #0x3
    c560:      	b.eq	0xc5cc <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0xa8>
    c564:      	mov	w14, #0x18              ; =24
    c568:      	madd	x14, x15, x14, x0
    c56c:      	sub	x17, x14, #0x8
    c570:      	mov	w2, #0x83               ; =131
    c574:      	mov	x14, x15
    c578:      	b	0xc58c <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0x68>
    c57c:      	sub	x17, x17, #0x18
    c580:      	sub	x14, x14, #0x1
    c584:      	sub	x16, x16, #0x1
    c588:      	cbz	x16, 0xc5d0 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0xac>
    c58c:      	ldur	w3, [x17, #-0x10]
    c590:      	cmp	w3, #0x2
    c594:      	b.ne	0xc57c <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0x58>
    c598:      	ldp	x4, x3, [x17, #-0x8]
    c59c:      	madd	x3, x4, x2, x3
    c5a0:      	add	x11, x3, x11
    c5a4:      	eor	x3, x3, x3, lsr #30
    c5a8:      	mul	x3, x3, x9
    c5ac:      	eor	x3, x3, x3, lsr #27
    c5b0:      	mul	x3, x3, x10
    c5b4:      	eor	x13, x13, x3, lsr #31
    c5b8:      	eor	x13, x13, x3
    c5bc:      	stp	x11, x13, [x1, #0x8]
    c5c0:      	add	x12, x12, #0x1
    c5c4:      	str	x12, [x1, #0x18]
    c5c8:      	b	0xc57c <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0x58>
    c5cc:      	mov	x14, x15
    c5d0:      	cmp	x15, #0x4
    c5d4:      	b.hs	0xc5ec <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0xc8>
    c5d8:      	cbz	x8, 0xc5e0 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0xbc>
    c5dc:      	bl	0xc5dc <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0xb8>
		000000000000c5dc:  ARM64_RELOC_BRANCH26	_free
    c5e0:      	mov	w0, #0x0                ; =0
    c5e4:      	ldp	x29, x30, [sp], #0x10
    c5e8:      	ret
    c5ec:      	mov	w15, #0x18              ; =24
    c5f0:      	madd	x15, x14, x15, x0
    c5f4:      	sub	x15, x15, #0x30
    c5f8:      	mov	w16, #0x83              ; =131
    c5fc:      	b	0xc60c <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0xe8>
    c600:      	sub	x15, x15, #0x60
    c604:      	sub	x14, x14, #0x4
    c608:      	cbz	x14, 0xc5d8 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0xb4>
    c60c:      	ldr	w17, [x15, #0x18]
    c610:      	cmp	w17, #0x2
    c614:      	b.eq	0xc640 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0x11c>
    c618:      	ldr	w17, [x15]
    c61c:      	cmp	w17, #0x2
    c620:      	b.eq	0xc67c <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0x158>
    c624:      	ldur	w17, [x15, #-0x18]
    c628:      	cmp	w17, #0x2
    c62c:      	b.eq	0xc6b8 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0x194>
    c630:      	ldur	w17, [x15, #-0x30]
    c634:      	cmp	w17, #0x2
    c638:      	b.ne	0xc600 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0xdc>
    c63c:      	b	0xc6f4 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0x1d0>
    c640:      	ldp	x2, x17, [x15, #0x20]
    c644:      	madd	x17, x2, x16, x17
    c648:      	add	x11, x17, x11
    c64c:      	eor	x17, x17, x17, lsr #30
    c650:      	mul	x17, x17, x9
    c654:      	eor	x17, x17, x17, lsr #27
    c658:      	mul	x17, x17, x10
    c65c:      	eor	x13, x13, x17, lsr #31
    c660:      	eor	x13, x13, x17
    c664:      	stp	x11, x13, [x1, #0x8]
    c668:      	add	x12, x12, #0x1
    c66c:      	str	x12, [x1, #0x18]
    c670:      	ldr	w17, [x15]
    c674:      	cmp	w17, #0x2
    c678:      	b.ne	0xc624 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0x100>
    c67c:      	ldp	x2, x17, [x15, #0x8]
    c680:      	madd	x17, x2, x16, x17
    c684:      	add	x11, x17, x11
    c688:      	eor	x17, x17, x17, lsr #30
    c68c:      	mul	x17, x17, x9
    c690:      	eor	x17, x17, x17, lsr #27
    c694:      	mul	x17, x17, x10
    c698:      	eor	x13, x13, x17, lsr #31
    c69c:      	eor	x13, x13, x17
    c6a0:      	stp	x11, x13, [x1, #0x8]
    c6a4:      	add	x12, x12, #0x1
    c6a8:      	str	x12, [x1, #0x18]
    c6ac:      	ldur	w17, [x15, #-0x18]
    c6b0:      	cmp	w17, #0x2
    c6b4:      	b.ne	0xc630 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0x10c>
    c6b8:      	ldp	x2, x17, [x15, #-0x10]
    c6bc:      	madd	x17, x2, x16, x17
    c6c0:      	add	x11, x17, x11
    c6c4:      	eor	x17, x17, x17, lsr #30
    c6c8:      	mul	x17, x17, x9
    c6cc:      	eor	x17, x17, x17, lsr #27
    c6d0:      	mul	x17, x17, x10
    c6d4:      	eor	x13, x13, x17, lsr #31
    c6d8:      	eor	x13, x13, x17
    c6dc:      	stp	x11, x13, [x1, #0x8]
    c6e0:      	add	x12, x12, #0x1
    c6e4:      	str	x12, [x1, #0x18]
    c6e8:      	ldur	w17, [x15, #-0x30]
    c6ec:      	cmp	w17, #0x2
    c6f0:      	b.ne	0xc600 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0xdc>
    c6f4:      	ldp	x2, x17, [x15, #-0x28]
    c6f8:      	madd	x17, x2, x16, x17
    c6fc:      	add	x11, x17, x11
    c700:      	eor	x17, x17, x17, lsr #30
    c704:      	mul	x17, x17, x9
    c708:      	eor	x17, x17, x17, lsr #27
    c70c:      	mul	x17, x17, x10
    c710:      	eor	x13, x13, x17, lsr #31
    c714:      	eor	x13, x13, x17
    c718:      	stp	x11, x13, [x1, #0x8]
    c71c:      	add	x12, x12, #0x1
    c720:      	str	x12, [x1, #0x18]
    c724:      	b	0xc600 <_wf_std.collections.hash_map.hash_map_free$instance$d30acb1e89e19e46+0xdc>

000000000000c728 <_wf_std.collections.hash_map.hash_map_new$instance$1fa0694bfbd574aa>:
    c728:      	stp	x20, x19, [sp, #-0x20]!
    c72c:      	stp	x29, x30, [sp, #0x10]
    c730:      	mov	x20, x1
    c734:      	mov	x19, x0
    c738:      	cbz	x1, 0xc7a8 <_wf_std.collections.hash_map.hash_map_new$instance$1fa0694bfbd574aa+0x80>
    c73c:      	add	x8, x20, x20, lsl #4
    c740:      	lsl	x0, x8, #4
    c744:      	bl	0xc744 <_wf_std.collections.hash_map.hash_map_new$instance$1fa0694bfbd574aa+0x1c>
		000000000000c744:  ARM64_RELOC_BRANCH26	_malloc
    c748:      	cbz	x0, 0xc7c8 <_wf_std.collections.hash_map.hash_map_new$instance$1fa0694bfbd574aa+0xa0>
    c74c:      	mov	x8, #0x0                ; =0
    c750:      	add	x9, x0, #0x8
    c754:      	movi.2d	v0, #0000000000000000
    c758:      	stur	wzr, [x9, #-0x8]
    c75c:      	add	x8, x8, #0x1
    c760:      	stp	q0, q0, [x9]
    c764:      	stp	q0, q0, [x9, #0x20]
    c768:      	stp	q0, q0, [x9, #0x40]
    c76c:      	stp	q0, q0, [x9, #0x60]
    c770:      	stp	q0, q0, [x9, #0x80]
    c774:      	stp	q0, q0, [x9, #0xa0]
    c778:      	stp	q0, q0, [x9, #0xc0]
    c77c:      	stp	q0, q0, [x9, #0xe0]
    c780:      	str	xzr, [x9, #0x100]
    c784:      	add	x9, x9, #0x110
    c788:      	cmp	x20, x8
    c78c:      	b.ne	0xc758 <_wf_std.collections.hash_map.hash_map_new$instance$1fa0694bfbd574aa+0x30>
    c790:      	stp	x20, x20, [x19]
    c794:      	stp	xzr, xzr, [x19, #0x18]
    c798:      	str	x0, [x19, #0x10]
    c79c:      	ldp	x29, x30, [sp, #0x10]
    c7a0:      	ldp	x20, x19, [sp], #0x20
    c7a4:      	ret
    c7a8:      	adrp	x0, 0xc000 <_wf_chain_insert$instance$c6df3d8464f8cde0+0x12c>
		000000000000c7a8:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    c7ac:      	add	x0, x0, #0x0
		000000000000c7ac:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    c7b0:      	stp	x20, x20, [x19]
    c7b4:      	stp	xzr, xzr, [x19, #0x18]
    c7b8:      	str	x0, [x19, #0x10]
    c7bc:      	ldp	x29, x30, [sp, #0x10]
    c7c0:      	ldp	x20, x19, [sp], #0x20
    c7c4:      	ret
    c7c8:      	bl	0xc7c8 <_wf_std.collections.hash_map.hash_map_new$instance$1fa0694bfbd574aa+0xa0>
		000000000000c7c8:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000c7cc <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d>:
    c7cc:      	mov	x9, x3
    c7d0:      	mov	x3, x2
    c7d4:      	ldrb	w8, [x4, #0x8]
    c7d8:      	tbz	w8, #0x0, 0xc850 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x84>
    c7dc:      	mov	x8, #0x0                ; =0
    c7e0:      	ldr	x10, [x1]
    c7e4:      	cbz	x10, 0xc894 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xc8>
    c7e8:      	udiv	x11, x8, x10
    c7ec:      	msub	x8, x11, x10, x8
    c7f0:      	ldr	x11, [x1, #0x10]
    c7f4:      	mov	w12, #0x110             ; =272
    c7f8:      	mov	x13, x10
    c7fc:      	mov	x2, x10
    c800:      	b	0xc820 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x54>
    c804:      	cmp	x2, x10
    c808:      	csel	x2, x8, x2, eq
    c80c:      	add	x14, x8, #0x1
    c810:      	cmp	x14, x10
    c814:      	csinc	x8, xzr, x8, hs
    c818:      	subs	x13, x13, #0x1
    c81c:      	b.eq	0xc898 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xcc>
    c820:      	madd	x14, x8, x12, x11
    c824:      	ldr	w15, [x14]
    c828:      	cmp	w15, #0x1
    c82c:      	b.eq	0xc804 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x38>
    c830:      	cmp	w15, #0x2
    c834:      	b.ne	0xc8e4 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x118>
    c838:      	ldr	x14, [x14, #0x8]
    c83c:      	cmp	x14, x3
    c840:      	b.ne	0xc80c <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x40>
    c844:      	mov	x2, x8
    c848:      	mov	x4, x9
    c84c:      	b	0xc84c <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x80>
		000000000000c84c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    c850:      	ldr	x8, [x4]
    c854:      	eor	x8, x8, x3
    c858:      	eor	x8, x8, x8, lsr #30
    c85c:      	mov	x10, #0xe5b9            ; =58809
    c860:      	movk	x10, #0x1ce4, lsl #16
    c864:      	movk	x10, #0x476d, lsl #32
    c868:      	movk	x10, #0xbf58, lsl #48
    c86c:      	mul	x8, x8, x10
    c870:      	eor	x8, x8, x8, lsr #27
    c874:      	mov	x10, #0x11eb            ; =4587
    c878:      	movk	x10, #0x1331, lsl #16
    c87c:      	movk	x10, #0x49bb, lsl #32
    c880:      	movk	x10, #0x94d0, lsl #48
    c884:      	mul	x8, x8, x10
    c888:      	eor	x8, x8, x8, lsr #31
    c88c:      	ldr	x10, [x1]
    c890:      	cbnz	x10, 0xc7e8 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x1c>
    c894:      	mov	x2, #0x0                ; =0
    c898:      	cmp	x2, x10
    c89c:      	b.hs	0xc8f4 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x128>
    c8a0:      	ldr	x8, [x1, #0x18]
    c8a4:      	lsr	x10, x8, #13
    c8a8:      	cbnz	x10, 0xc8f4 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x128>
    c8ac:      	add	x8, x8, #0x1
    c8b0:      	str	x8, [x1, #0x18]
    c8b4:      	ldr	x8, [x1, #0x10]
    c8b8:      	mov	w10, #0x110             ; =272
    c8bc:      	mul	x10, x2, x10
    c8c0:      	ldr	w8, [x8, x10]
    c8c4:      	cmp	w8, #0x1
    c8c8:      	b.ne	0xc8dc <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x110>
    c8cc:      	ldr	x8, [x1, #0x20]
    c8d0:      	subs	x8, x8, #0x1
    c8d4:      	csel	x8, xzr, x8, lo
    c8d8:      	str	x8, [x1, #0x20]
    c8dc:      	mov	x4, x9
    c8e0:      	b	0xc8e0 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x114>
		000000000000c8e0:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    c8e4:      	cmp	x2, x10
    c8e8:      	csel	x2, x8, x2, eq
    c8ec:      	cmp	x2, x10
    c8f0:      	b.lo	0xc8a0 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xd4>
    c8f4:      	ldp	q0, q1, [x9]
    c8f8:      	ldp	q2, q3, [x9, #0x20]
    c8fc:      	ldp	q4, q5, [x9, #0x40]
    c900:      	ldp	q6, q7, [x9, #0x60]
    c904:      	ldp	q16, q17, [x9, #0x80]
    c908:      	ldp	q18, q19, [x9, #0xa0]
    c90c:      	ldp	q20, q21, [x9, #0xc0]
    c910:      	ldp	q22, q23, [x9, #0xe0]
    c914:      	stp	xzr, x3, [x0]
    c918:      	mov	w8, #0x1                ; =1
    c91c:      	str	w8, [x0]
    c920:      	strb	w8, [x0, #0x4]
    c924:      	stp	q0, q1, [x0, #0x10]
    c928:      	stp	q2, q3, [x0, #0x30]
    c92c:      	stp	q4, q5, [x0, #0x50]
    c930:      	stp	q6, q7, [x0, #0x70]
    c934:      	stp	q16, q17, [x0, #0x90]
    c938:      	stp	q18, q19, [x0, #0xb0]
    c93c:      	stp	q20, q21, [x0, #0xd0]
    c940:      	stp	q22, q23, [x0, #0xf0]
    c944:      	ret

000000000000c948 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d>:
    c948:      	ldr	x8, [x1, #0x18]
    c94c:      	cbz	x8, 0xcab4 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x16c>
    c950:      	ldrb	w9, [x3, #0x8]
    c954:      	tbz	w9, #0x0, 0xc968 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x20>
    c958:      	mov	x9, #0x0                ; =0
    c95c:      	ldr	x11, [x1]
    c960:      	cbnz	x11, 0xc9b0 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x68>
    c964:      	b	0xcab4 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x16c>
    c968:      	ldr	x9, [x3]
    c96c:      	ldr	x10, [x2]
    c970:      	eor	x9, x10, x9
    c974:      	eor	x9, x9, x9, lsr #30
    c978:      	mov	x10, #0xe5b9            ; =58809
    c97c:      	movk	x10, #0x1ce4, lsl #16
    c980:      	movk	x10, #0x476d, lsl #32
    c984:      	movk	x10, #0xbf58, lsl #48
    c988:      	mul	x9, x9, x10
    c98c:      	eor	x9, x9, x9, lsr #27
    c990:      	mov	x10, #0x11eb            ; =4587
    c994:      	movk	x10, #0x1331, lsl #16
    c998:      	movk	x10, #0x49bb, lsl #32
    c99c:      	movk	x10, #0x94d0, lsl #48
    c9a0:      	mul	x9, x9, x10
    c9a4:      	eor	x9, x9, x9, lsr #31
    c9a8:      	ldr	x11, [x1]
    c9ac:      	cbz	x11, 0xcab4 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x16c>
    c9b0:      	udiv	x10, x9, x11
    c9b4:      	msub	x12, x10, x11, x9
    c9b8:      	ldr	x13, [x1, #0x10]
    c9bc:      	mov	w14, #0x110             ; =272
    c9c0:      	mov	x15, x11
    c9c4:      	b	0xc9dc <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x94>
    c9c8:      	add	x9, x12, #0x1
    c9cc:      	cmp	x9, x11
    c9d0:      	csinc	x12, xzr, x12, hs
    c9d4:      	subs	x15, x15, #0x1
    c9d8:      	b.eq	0xcab4 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x16c>
    c9dc:      	madd	x9, x12, x14, x13
    c9e0:      	ldr	w10, [x9]
    c9e4:      	cmp	w10, #0x1
    c9e8:      	b.eq	0xc9c8 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x80>
    c9ec:      	cmp	w10, #0x2
    c9f0:      	b.ne	0xcab4 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x16c>
    c9f4:      	ldr	x10, [x9, #0x8]
    c9f8:      	ldr	x16, [x2]
    c9fc:      	cmp	x10, x16
    ca00:      	b.ne	0xc9c8 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x80>
    ca04:      	mov	w11, #0x1               ; =1
    ca08:      	str	w11, [x9]
    ca0c:      	sub	x8, x8, #0x1
    ca10:      	ldp	q0, q1, [x9, #0x10]
    ca14:      	ldp	q2, q3, [x9, #0x30]
    ca18:      	ldp	q4, q5, [x9, #0x50]
    ca1c:      	ldp	q6, q7, [x9, #0x70]
    ca20:      	ldp	q16, q17, [x9, #0x90]
    ca24:      	ldp	q18, q19, [x9, #0xb0]
    ca28:      	ldp	q20, q21, [x9, #0xd0]
    ca2c:      	ldp	q22, q23, [x9, #0xf0]
    ca30:      	movi.2d	v24, #0000000000000000
    ca34:      	stur	q24, [x9, #0x18]
    ca38:      	stur	q24, [x9, #0x28]
    ca3c:      	stur	q24, [x9, #0x38]
    ca40:      	stur	q24, [x9, #0x48]
    ca44:      	stur	q24, [x9, #0x58]
    ca48:      	stur	q24, [x9, #0x68]
    ca4c:      	stur	q24, [x9, #0x78]
    ca50:      	stur	q24, [x9, #0x88]
    ca54:      	stur	q24, [x9, #0x98]
    ca58:      	stur	q24, [x9, #0xa8]
    ca5c:      	stur	q24, [x9, #0xb8]
    ca60:      	stur	q24, [x9, #0xc8]
    ca64:      	stur	q24, [x9, #0xd8]
    ca68:      	stur	q24, [x9, #0xe8]
    ca6c:      	stur	q24, [x9, #0xf8]
    ca70:      	stur	q24, [x9, #0x8]
    ca74:      	str	xzr, [x9, #0x108]
    ca78:      	ldr	x9, [x1, #0x20]
    ca7c:      	adds	x9, x9, #0x1
    ca80:      	csinv	x9, x9, xzr, lo
    ca84:      	stp	x8, x9, [x1, #0x18]
    ca88:      	stp	xzr, x10, [x0]
    ca8c:      	str	w11, [x0]
    ca90:      	stp	q0, q1, [x0, #0x10]
    ca94:      	stp	q2, q3, [x0, #0x30]
    ca98:      	stp	q4, q5, [x0, #0x50]
    ca9c:      	stp	q6, q7, [x0, #0x70]
    caa0:      	stp	q16, q17, [x0, #0x90]
    caa4:      	stp	q18, q19, [x0, #0xb0]
    caa8:      	stp	q20, q21, [x0, #0xd0]
    caac:      	stp	q22, q23, [x0, #0xf0]
    cab0:      	ret
    cab4:      	movi.2d	v0, #0000000000000000
    cab8:      	stp	q0, q0, [x0, #0xf0]
    cabc:      	stp	q0, q0, [x0, #0xd0]
    cac0:      	stp	q0, q0, [x0, #0xb0]
    cac4:      	stp	q0, q0, [x0, #0x90]
    cac8:      	stp	q0, q0, [x0, #0x70]
    cacc:      	stp	q0, q0, [x0, #0x50]
    cad0:      	stp	q0, q0, [x0, #0x30]
    cad4:      	stp	q0, q0, [x0, #0x10]
    cad8:      	str	q0, [x0]
    cadc:      	ret

000000000000cae0 <_wf_std.collections.hash_map.hash_map_capacity$instance$1fa0694bfbd574aa>:
    cae0:      	ldr	x0, [x0]
    cae4:      	ret

000000000000cae8 <_wf_std.collections.hash_map.hash_map_len$instance$1fa0694bfbd574aa>:
    cae8:      	ldr	x0, [x0, #0x18]
    caec:      	ret

000000000000caf0 <_wf_std.collections.hash_map.hash_map_lookup$instance$45d862e2288df95e>:
    caf0:      	ldrb	w8, [x2, #0x8]
    caf4:      	tbz	w8, #0x0, 0xcb08 <_wf_std.collections.hash_map.hash_map_lookup$instance$45d862e2288df95e+0x18>
    caf8:      	mov	x8, #0x0                ; =0
    cafc:      	ldr	x9, [x0]
    cb00:      	cbnz	x9, 0xcb50 <_wf_std.collections.hash_map.hash_map_lookup$instance$45d862e2288df95e+0x60>
    cb04:      	b	0xcbb8 <_wf_std.collections.hash_map.hash_map_lookup$instance$45d862e2288df95e+0xc8>
    cb08:      	ldr	x8, [x2]
    cb0c:      	ldr	x9, [x1]
    cb10:      	eor	x8, x9, x8
    cb14:      	eor	x8, x8, x8, lsr #30
    cb18:      	mov	x9, #0xe5b9             ; =58809
    cb1c:      	movk	x9, #0x1ce4, lsl #16
    cb20:      	movk	x9, #0x476d, lsl #32
    cb24:      	movk	x9, #0xbf58, lsl #48
    cb28:      	mul	x8, x8, x9
    cb2c:      	eor	x8, x8, x8, lsr #27
    cb30:      	mov	x9, #0x11eb             ; =4587
    cb34:      	movk	x9, #0x1331, lsl #16
    cb38:      	movk	x9, #0x49bb, lsl #32
    cb3c:      	movk	x9, #0x94d0, lsl #48
    cb40:      	mul	x8, x8, x9
    cb44:      	eor	x8, x8, x8, lsr #31
    cb48:      	ldr	x9, [x0]
    cb4c:      	cbz	x9, 0xcbb8 <_wf_std.collections.hash_map.hash_map_lookup$instance$45d862e2288df95e+0xc8>
    cb50:      	udiv	x10, x8, x9
    cb54:      	msub	x10, x10, x9, x8
    cb58:      	ldr	x11, [x0, #0x10]
    cb5c:      	mov	w12, #0x110             ; =272
    cb60:      	mov	x13, x9
    cb64:      	b	0xcb7c <_wf_std.collections.hash_map.hash_map_lookup$instance$45d862e2288df95e+0x8c>
    cb68:      	add	x8, x10, #0x1
    cb6c:      	cmp	x8, x9
    cb70:      	csinc	x10, xzr, x10, hs
    cb74:      	subs	x13, x13, #0x1
    cb78:      	b.eq	0xcbb8 <_wf_std.collections.hash_map.hash_map_lookup$instance$45d862e2288df95e+0xc8>
    cb7c:      	madd	x14, x10, x12, x11
    cb80:      	ldr	w8, [x14]
    cb84:      	cmp	w8, #0x1
    cb88:      	b.eq	0xcb68 <_wf_std.collections.hash_map.hash_map_lookup$instance$45d862e2288df95e+0x78>
    cb8c:      	cmp	w8, #0x2
    cb90:      	b.ne	0xcbbc <_wf_std.collections.hash_map.hash_map_lookup$instance$45d862e2288df95e+0xcc>
    cb94:      	ldr	x8, [x14, #0x8]
    cb98:      	ldr	x15, [x1]
    cb9c:      	cmp	x8, x15
    cba0:      	b.ne	0xcb68 <_wf_std.collections.hash_map.hash_map_lookup$instance$45d862e2288df95e+0x78>
    cba4:      	mov	w0, #0x0                ; =0
    cba8:      	ldr	x8, [x14, #0x10]
    cbac:      	mov	x1, x8
    cbb0:      	mov	w2, #0x0                ; =0
    cbb4:      	ret
    cbb8:      	mov	x8, #0x0                ; =0
    cbbc:      	mov	w0, #0x1                ; =1
    cbc0:      	mov	x1, x8
    cbc4:      	mov	w2, #0x0                ; =0
    cbc8:      	ret

000000000000cbcc <_wf_std.collections.hash_map.hash_map_free$instance$e1a21e22af512733>:
    cbcc:      	stp	x29, x30, [sp, #-0x10]!
    cbd0:      	ldp	x9, x8, [x0]
    cbd4:      	ldr	x0, [x0, #0x10]
    cbd8:      	cbz	x9, 0xcd20 <_wf_std.collections.hash_map.hash_map_free$instance$e1a21e22af512733+0x154>
    cbdc:      	ldp	x10, x11, [x1, #0x8]
    cbe0:      	mov	w12, #0x110             ; =272
    cbe4:      	madd	x13, x9, x12, x0
    cbe8:      	ldr	x12, [x1, #0x18]
    cbec:      	sub	x13, x13, #0x88
    cbf0:      	mov	w14, #0x83              ; =131
    cbf4:      	mov	x15, #0xe5b9            ; =58809
    cbf8:      	movk	x15, #0x1ce4, lsl #16
    cbfc:      	movk	x15, #0x476d, lsl #32
    cc00:      	movk	x15, #0xbf58, lsl #48
    cc04:      	mov	x16, #0x11eb            ; =4587
    cc08:      	movk	x16, #0x1331, lsl #16
    cc0c:      	movk	x16, #0x49bb, lsl #32
    cc10:      	movk	x16, #0x94d0, lsl #48
    cc14:      	b	0xcc24 <_wf_std.collections.hash_map.hash_map_free$instance$e1a21e22af512733+0x58>
    cc18:      	sub	x13, x13, #0x110
    cc1c:      	sub	x9, x9, #0x1
    cc20:      	cbz	x9, 0xcd20 <_wf_std.collections.hash_map.hash_map_free$instance$e1a21e22af512733+0x154>
    cc24:      	ldur	w17, [x13, #-0x88]
    cc28:      	cmp	w17, #0x2
    cc2c:      	b.ne	0xcc18 <_wf_std.collections.hash_map.hash_map_free$instance$e1a21e22af512733+0x4c>
    cc30:      	ldp	x2, x17, [x13, #-0x80]
    cc34:      	madd	x17, x2, x14, x17
    cc38:      	ldp	x3, x2, [x13, #-0x70]
    cc3c:      	madd	x17, x17, x14, x3
    cc40:      	madd	x17, x17, x14, x2
    cc44:      	ldp	x3, x2, [x13, #-0x60]
    cc48:      	madd	x17, x17, x14, x3
    cc4c:      	madd	x17, x17, x14, x2
    cc50:      	ldp	x3, x2, [x13, #-0x50]
    cc54:      	madd	x17, x17, x14, x3
    cc58:      	madd	x17, x17, x14, x2
    cc5c:      	ldp	x3, x2, [x13, #-0x40]
    cc60:      	madd	x17, x17, x14, x3
    cc64:      	madd	x17, x17, x14, x2
    cc68:      	ldp	x3, x2, [x13, #-0x30]
    cc6c:      	madd	x17, x17, x14, x3
    cc70:      	madd	x17, x17, x14, x2
    cc74:      	ldp	x3, x2, [x13, #-0x20]
    cc78:      	madd	x17, x17, x14, x3
    cc7c:      	madd	x17, x17, x14, x2
    cc80:      	ldp	x3, x2, [x13, #-0x10]
    cc84:      	madd	x17, x17, x14, x3
    cc88:      	madd	x17, x17, x14, x2
    cc8c:      	ldp	x3, x2, [x13]
    cc90:      	madd	x17, x17, x14, x3
    cc94:      	madd	x17, x17, x14, x2
    cc98:      	ldp	x3, x2, [x13, #0x10]
    cc9c:      	madd	x17, x17, x14, x3
    cca0:      	madd	x17, x17, x14, x2
    cca4:      	ldp	x3, x2, [x13, #0x20]
    cca8:      	madd	x17, x17, x14, x3
    ccac:      	madd	x17, x17, x14, x2
    ccb0:      	ldp	x3, x2, [x13, #0x30]
    ccb4:      	madd	x17, x17, x14, x3
    ccb8:      	madd	x17, x17, x14, x2
    ccbc:      	ldp	x3, x2, [x13, #0x40]
    ccc0:      	madd	x17, x17, x14, x3
    ccc4:      	madd	x17, x17, x14, x2
    ccc8:      	ldp	x3, x2, [x13, #0x50]
    cccc:      	madd	x17, x17, x14, x3
    ccd0:      	madd	x17, x17, x14, x2
    ccd4:      	ldp	x3, x2, [x13, #0x60]
    ccd8:      	madd	x17, x17, x14, x3
    ccdc:      	madd	x17, x17, x14, x2
    cce0:      	ldp	x3, x2, [x13, #0x70]
    cce4:      	madd	x17, x17, x14, x3
    cce8:      	madd	x17, x17, x14, x2
    ccec:      	ldr	x2, [x13, #0x80]
    ccf0:      	madd	x17, x17, x14, x2
    ccf4:      	add	x10, x17, x10
    ccf8:      	eor	x17, x17, x17, lsr #30
    ccfc:      	mul	x17, x17, x15
    cd00:      	eor	x17, x17, x17, lsr #27
    cd04:      	mul	x17, x17, x16
    cd08:      	eor	x11, x11, x17, lsr #31
    cd0c:      	eor	x11, x11, x17
    cd10:      	stp	x10, x11, [x1, #0x8]
    cd14:      	add	x12, x12, #0x1
    cd18:      	str	x12, [x1, #0x18]
    cd1c:      	b	0xcc18 <_wf_std.collections.hash_map.hash_map_free$instance$e1a21e22af512733+0x4c>
    cd20:      	cbz	x8, 0xcd28 <_wf_std.collections.hash_map.hash_map_free$instance$e1a21e22af512733+0x15c>
    cd24:      	bl	0xcd24 <_wf_std.collections.hash_map.hash_map_free$instance$e1a21e22af512733+0x158>
		000000000000cd24:  ARM64_RELOC_BRANCH26	_free
    cd28:      	mov	w0, #0x0                ; =0
    cd2c:      	ldp	x29, x30, [sp], #0x10
    cd30:      	ret

000000000000cd34 <_wf_full_chain_new$instance$e85fc351f8333b14>:
    cd34:      	stp	x22, x21, [sp, #-0x30]!
    cd38:      	stp	x20, x19, [sp, #0x10]
    cd3c:      	stp	x29, x30, [sp, #0x20]
    cd40:      	mov	x20, x1
    cd44:      	mov	x19, x0
    cd48:      	cbz	x1, 0xcd80 <_wf_full_chain_new$instance$e85fc351f8333b14+0x4c>
    cd4c:      	lsl	x22, x20, #3
    cd50:      	mov	x0, x22
    cd54:      	bl	0xcd54 <_wf_full_chain_new$instance$e85fc351f8333b14+0x20>
		000000000000cd54:  ARM64_RELOC_BRANCH26	_malloc
    cd58:      	cbz	x0, 0xcd7c <_wf_full_chain_new$instance$e85fc351f8333b14+0x48>
    cd5c:      	mov	x21, x0
    cd60:      	mov	w1, #0xff               ; =255
    cd64:      	mov	x2, x22
    cd68:      	bl	0xcd68 <_wf_full_chain_new$instance$e85fc351f8333b14+0x34>
		000000000000cd68:  ARM64_RELOC_BRANCH26	_memset
    cd6c:      	add	x8, x20, x20, lsl #1
    cd70:      	lsl	x0, x8, #3
    cd74:      	bl	0xcd74 <_wf_full_chain_new$instance$e85fc351f8333b14+0x40>
		000000000000cd74:  ARM64_RELOC_BRANCH26	_malloc
    cd78:      	cbnz	x0, 0xcd8c <_wf_full_chain_new$instance$e85fc351f8333b14+0x58>
    cd7c:      	bl	0xcd7c <_wf_full_chain_new$instance$e85fc351f8333b14+0x48>
		000000000000cd7c:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
    cd80:      	adrp	x21, 0xc000 <_wf_chain_insert$instance$c6df3d8464f8cde0+0x12c>
		000000000000cd80:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    cd84:      	add	x21, x21, #0x0
		000000000000cd84:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    cd88:      	mov	x0, x21
    cd8c:      	stp	x20, x20, [x19]
    cd90:      	stp	x21, xzr, [x19, #0x10]
    cd94:      	stp	x20, x0, [x19, #0x20]
    cd98:      	ldp	x29, x30, [sp, #0x20]
    cd9c:      	ldp	x20, x19, [sp, #0x10]
    cda0:      	ldp	x22, x21, [sp], #0x30
    cda4:      	ret

000000000000cda8 <_wf_full_chain_try_put$instance$29255544f66aec6e>:
    cda8:      	ldrb	w8, [x4, #0x8]
    cdac:      	tbz	w8, #0x0, 0xcdc0 <_wf_full_chain_try_put$instance$29255544f66aec6e+0x18>
    cdb0:      	mov	x8, #0x0                ; =0
    cdb4:      	ldr	x12, [x1]
    cdb8:      	cbnz	x12, 0xce04 <_wf_full_chain_try_put$instance$29255544f66aec6e+0x5c>
    cdbc:      	b	0xcea0 <_wf_full_chain_try_put$instance$29255544f66aec6e+0xf8>
    cdc0:      	ldr	x8, [x4]
    cdc4:      	eor	x8, x8, x2
    cdc8:      	eor	x8, x8, x8, lsr #30
    cdcc:      	mov	x9, #0xe5b9             ; =58809
    cdd0:      	movk	x9, #0x1ce4, lsl #16
    cdd4:      	movk	x9, #0x476d, lsl #32
    cdd8:      	movk	x9, #0xbf58, lsl #48
    cddc:      	mul	x8, x8, x9
    cde0:      	eor	x8, x8, x8, lsr #27
    cde4:      	mov	x9, #0x11eb             ; =4587
    cde8:      	movk	x9, #0x1331, lsl #16
    cdec:      	movk	x9, #0x49bb, lsl #32
    cdf0:      	movk	x9, #0x94d0, lsl #48
    cdf4:      	mul	x8, x8, x9
    cdf8:      	eor	x8, x8, x8, lsr #31
    cdfc:      	ldr	x12, [x1]
    ce00:      	cbz	x12, 0xcea0 <_wf_full_chain_try_put$instance$29255544f66aec6e+0xf8>
    ce04:      	udiv	x9, x8, x12
    ce08:      	msub	x8, x9, x12, x8
    ce0c:      	ldp	x9, x10, [x1, #0x10]
    ce10:      	ldr	x11, [x9, x8, lsl #3]
    ce14:      	cbz	x10, 0xce58 <_wf_full_chain_try_put$instance$29255544f66aec6e+0xb0>
    ce18:      	cmp	x11, x10
    ce1c:      	b.hs	0xce58 <_wf_full_chain_try_put$instance$29255544f66aec6e+0xb0>
    ce20:      	ldr	x13, [x1, #0x28]
    ce24:      	mov	w14, #0x1               ; =1
    ce28:      	mov	w15, #0x18              ; =24
    ce2c:      	mov	x16, x11
    ce30:      	madd	x16, x16, x15, x13
    ce34:      	ldr	x17, [x16]
    ce38:      	cmp	x17, x2
    ce3c:      	b.eq	0xceb8 <_wf_full_chain_try_put$instance$29255544f66aec6e+0x110>
    ce40:      	cmp	x14, x10
    ce44:      	b.hs	0xce58 <_wf_full_chain_try_put$instance$29255544f66aec6e+0xb0>
    ce48:      	ldr	x16, [x16, #0x10]
    ce4c:      	add	x14, x14, #0x1
    ce50:      	cmp	x16, x10
    ce54:      	b.lo	0xce30 <_wf_full_chain_try_put$instance$29255544f66aec6e+0x88>
    ce58:      	cmp	x10, x12
    ce5c:      	b.hs	0xcea0 <_wf_full_chain_try_put$instance$29255544f66aec6e+0xf8>
    ce60:      	cmp	x10, #0x2, lsl #12      ; =0x2000
    ce64:      	b.hs	0xcea0 <_wf_full_chain_try_put$instance$29255544f66aec6e+0xf8>
    ce68:      	ldr	x12, [x1, #0x20]
    ce6c:      	cmp	x10, x12
    ce70:      	b.hs	0xcea0 <_wf_full_chain_try_put$instance$29255544f66aec6e+0xf8>
    ce74:      	ldr	x12, [x1, #0x28]
    ce78:      	mov	w13, #0x18              ; =24
    ce7c:      	madd	x12, x10, x13, x12
    ce80:      	stp	x2, x3, [x12]
    ce84:      	str	x11, [x12, #0x10]
    ce88:      	add	x11, x10, #0x1
    ce8c:      	str	x11, [x1, #0x18]
    ce90:      	str	x10, [x9, x8, lsl #3]
    ce94:      	stp	xzr, xzr, [x0]
    ce98:      	str	xzr, [x0, #0x10]
    ce9c:      	ret
    cea0:      	stp	xzr, x2, [x0]
    cea4:      	mov	w8, #0x1                ; =1
    cea8:      	str	w8, [x0]
    ceac:      	strb	w8, [x0, #0x4]
    ceb0:      	str	x3, [x0, #0x10]
    ceb4:      	ret
    ceb8:      	ldr	x8, [x16, #0x8]
    cebc:      	str	x3, [x16, #0x8]
    cec0:      	stp	xzr, x2, [x0]
    cec4:      	mov	w9, #0x1                ; =1
    cec8:      	str	w9, [x0]
    cecc:      	str	x8, [x0, #0x10]
    ced0:      	ret

000000000000ced4 <_wf_full_chain_remove$instance$29255544f66aec6e>:
    ced4:      	ldr	x14, [x0, #0x18]
    ced8:      	cbz	x14, 0xcf90 <_wf_full_chain_remove$instance$29255544f66aec6e+0xbc>
    cedc:      	ldr	x10, [x2]
    cee0:      	ldrb	w13, [x2, #0x8]
    cee4:      	tbz	w13, #0x0, 0xcef8 <_wf_full_chain_remove$instance$29255544f66aec6e+0x24>
    cee8:      	mov	x8, #0x0                ; =0
    ceec:      	ldr	x12, [x0]
    cef0:      	cbnz	x12, 0xcf3c <_wf_full_chain_remove$instance$29255544f66aec6e+0x68>
    cef4:      	b	0xcf90 <_wf_full_chain_remove$instance$29255544f66aec6e+0xbc>
    cef8:      	ldr	x8, [x1]
    cefc:      	eor	x8, x8, x10
    cf00:      	eor	x8, x8, x8, lsr #30
    cf04:      	mov	x9, #0xe5b9             ; =58809
    cf08:      	movk	x9, #0x1ce4, lsl #16
    cf0c:      	movk	x9, #0x476d, lsl #32
    cf10:      	movk	x9, #0xbf58, lsl #48
    cf14:      	mul	x8, x8, x9
    cf18:      	eor	x8, x8, x8, lsr #27
    cf1c:      	mov	x9, #0x11eb             ; =4587
    cf20:      	movk	x9, #0x1331, lsl #16
    cf24:      	movk	x9, #0x49bb, lsl #32
    cf28:      	movk	x9, #0x94d0, lsl #48
    cf2c:      	mul	x8, x8, x9
    cf30:      	eor	x8, x8, x8, lsr #31
    cf34:      	ldr	x12, [x0]
    cf38:      	cbz	x12, 0xcf90 <_wf_full_chain_remove$instance$29255544f66aec6e+0xbc>
    cf3c:      	udiv	x9, x8, x12
    cf40:      	msub	x8, x9, x12, x8
    cf44:      	ldr	x11, [x0, #0x10]
    cf48:      	add	x15, x11, x8, lsl #3
    cf4c:      	mov	w16, #0x18              ; =24
    cf50:      	mov	x3, x14
    cf54:      	mov	x4, x15
    cf58:      	mov	x2, x14
    cf5c:      	ldr	x8, [x4]
    cf60:      	cmp	x8, x14
    cf64:      	b.hs	0xcf90 <_wf_full_chain_remove$instance$29255544f66aec6e+0xbc>
    cf68:      	ldr	x9, [x0, #0x28]
    cf6c:      	madd	x17, x8, x16, x9
    cf70:      	mov	x4, x17
    cf74:      	ldr	x5, [x4], #0x10
    cf78:      	ldr	x6, [x1]
    cf7c:      	cmp	x5, x6
    cf80:      	b.eq	0xcfa0 <_wf_full_chain_remove$instance$29255544f66aec6e+0xcc>
    cf84:      	mov	x2, x8
    cf88:      	subs	x3, x3, #0x1
    cf8c:      	b.ne	0xcf5c <_wf_full_chain_remove$instance$29255544f66aec6e+0x88>
    cf90:      	mov	w0, #0x0                ; =0
    cf94:      	mov	x1, #0x0                ; =0
    cf98:      	mov	x2, #0x0                ; =0
    cf9c:      	ret
    cfa0:      	ldr	x16, [x4]
    cfa4:      	cmp	x2, x14
    cfa8:      	b.hs	0xcfbc <_wf_full_chain_remove$instance$29255544f66aec6e+0xe8>
    cfac:      	mov	w15, #0x18              ; =24
    cfb0:      	madd	x15, x2, x15, x9
    cfb4:      	str	x16, [x15, #0x10]
    cfb8:      	b	0xcfc0 <_wf_full_chain_remove$instance$29255544f66aec6e+0xec>
    cfbc:      	str	x16, [x15]
    cfc0:      	sub	x16, x14, #0x1
    cfc4:      	mov	w14, #0x18              ; =24
    cfc8:      	madd	x14, x16, x14, x9
    cfcc:      	str	x16, [x0, #0x18]
    cfd0:      	ldp	x1, x2, [x14]
    cfd4:      	cmp	x8, x16
    cfd8:      	b.hs	0xd040 <_wf_full_chain_remove$instance$29255544f66aec6e+0x16c>
    cfdc:      	ldr	x0, [x14, #0x10]
    cfe0:      	ldp	x15, x14, [x17]
    cfe4:      	stp	x1, x2, [x17]
    cfe8:      	str	x0, [x17, #0x10]
    cfec:      	tbz	w13, #0x0, 0xd048 <_wf_full_chain_remove$instance$29255544f66aec6e+0x174>
    cff0:      	mov	x10, #0x0               ; =0
    cff4:      	udiv	x13, x10, x12
    cff8:      	msub	x12, x13, x12, x10
    cffc:      	ldr	x10, [x11, x12, lsl #3]
    d000:      	cmp	x10, x16
    d004:      	b.eq	0xd094 <_wf_full_chain_remove$instance$29255544f66aec6e+0x1c0>
    d008:      	b.hs	0xd0a8 <_wf_full_chain_remove$instance$29255544f66aec6e+0x1d4>
    d00c:      	mov	w11, #0x1               ; =1
    d010:      	mov	w12, #0x18              ; =24
    d014:      	mov	w0, #0x1                ; =1
    d018:      	madd	x13, x10, x12, x9
    d01c:      	ldr	x10, [x13, #0x10]!
    d020:      	cmp	x10, x16
    d024:      	b.eq	0xd0b8 <_wf_full_chain_remove$instance$29255544f66aec6e+0x1e4>
    d028:      	cmp	x11, x16
    d02c:      	b.hs	0xd09c <_wf_full_chain_remove$instance$29255544f66aec6e+0x1c8>
    d030:      	add	x11, x11, #0x1
    d034:      	cmp	x10, x16
    d038:      	b.lo	0xd018 <_wf_full_chain_remove$instance$29255544f66aec6e+0x144>
    d03c:      	b	0xd09c <_wf_full_chain_remove$instance$29255544f66aec6e+0x1c8>
    d040:      	mov	w0, #0x1                ; =1
    d044:      	ret
    d048:      	eor	x10, x1, x10
    d04c:      	eor	x10, x10, x10, lsr #30
    d050:      	mov	x13, #0xe5b9            ; =58809
    d054:      	movk	x13, #0x1ce4, lsl #16
    d058:      	movk	x13, #0x476d, lsl #32
    d05c:      	movk	x13, #0xbf58, lsl #48
    d060:      	mul	x10, x10, x13
    d064:      	eor	x10, x10, x10, lsr #27
    d068:      	mov	x13, #0x11eb            ; =4587
    d06c:      	movk	x13, #0x1331, lsl #16
    d070:      	movk	x13, #0x49bb, lsl #32
    d074:      	movk	x13, #0x94d0, lsl #48
    d078:      	mul	x10, x10, x13
    d07c:      	eor	x10, x10, x10, lsr #31
    d080:      	udiv	x13, x10, x12
    d084:      	msub	x12, x13, x12, x10
    d088:      	ldr	x10, [x11, x12, lsl #3]
    d08c:      	cmp	x10, x16
    d090:      	b.ne	0xd008 <_wf_full_chain_remove$instance$29255544f66aec6e+0x134>
    d094:      	str	x8, [x11, x12, lsl #3]
    d098:      	mov	w0, #0x1                ; =1
    d09c:      	mov	x1, x15
    d0a0:      	mov	x2, x14
    d0a4:      	ret
    d0a8:      	mov	w0, #0x1                ; =1
    d0ac:      	mov	x1, x15
    d0b0:      	mov	x2, x14
    d0b4:      	ret
    d0b8:      	str	x8, [x13]
    d0bc:      	mov	w0, #0x1                ; =1
    d0c0:      	mov	x1, x15
    d0c4:      	mov	x2, x14
    d0c8:      	ret

000000000000d0cc <_wf_full_chain_capacity$instance$e85fc351f8333b14>:
    d0cc:      	ldr	x0, [x0]
    d0d0:      	ret

000000000000d0d4 <_wf_full_chain_len$instance$e85fc351f8333b14>:
    d0d4:      	ldr	x0, [x0, #0x18]
    d0d8:      	ret

000000000000d0dc <_wf_full_chain_lookup$instance$7c9d455aedf48152>:
    d0dc:      	ldrb	w8, [x2, #0x8]
    d0e0:      	tbz	w8, #0x0, 0xd0f4 <_wf_full_chain_lookup$instance$7c9d455aedf48152+0x18>
    d0e4:      	mov	x9, #0x0                ; =0
    d0e8:      	ldr	x10, [x0]
    d0ec:      	cbnz	x10, 0xd13c <_wf_full_chain_lookup$instance$7c9d455aedf48152+0x60>
    d0f0:      	b	0xd18c <_wf_full_chain_lookup$instance$7c9d455aedf48152+0xb0>
    d0f4:      	ldr	x8, [x2]
    d0f8:      	ldr	x9, [x1]
    d0fc:      	eor	x8, x9, x8
    d100:      	eor	x8, x8, x8, lsr #30
    d104:      	mov	x9, #0xe5b9             ; =58809
    d108:      	movk	x9, #0x1ce4, lsl #16
    d10c:      	movk	x9, #0x476d, lsl #32
    d110:      	movk	x9, #0xbf58, lsl #48
    d114:      	mul	x8, x8, x9
    d118:      	eor	x8, x8, x8, lsr #27
    d11c:      	mov	x9, #0x11eb             ; =4587
    d120:      	movk	x9, #0x1331, lsl #16
    d124:      	movk	x9, #0x49bb, lsl #32
    d128:      	movk	x9, #0x94d0, lsl #48
    d12c:      	mul	x8, x8, x9
    d130:      	eor	x9, x8, x8, lsr #31
    d134:      	ldr	x10, [x0]
    d138:      	cbz	x10, 0xd18c <_wf_full_chain_lookup$instance$7c9d455aedf48152+0xb0>
    d13c:      	ldr	x8, [x0, #0x18]
    d140:      	cbz	x8, 0xd18c <_wf_full_chain_lookup$instance$7c9d455aedf48152+0xb0>
    d144:      	udiv	x11, x9, x10
    d148:      	msub	x9, x11, x10, x9
    d14c:      	ldr	x10, [x0, #0x10]
    d150:      	add	x11, x10, x9, lsl #3
    d154:      	mov	w9, #0x18               ; =24
    d158:      	mov	x10, x8
    d15c:      	ldr	x11, [x11]
    d160:      	cmp	x11, x8
    d164:      	b.hs	0xd18c <_wf_full_chain_lookup$instance$7c9d455aedf48152+0xb0>
    d168:      	ldr	x12, [x0, #0x28]
    d16c:      	madd	x13, x11, x9, x12
    d170:      	ldr	x14, [x13]
    d174:      	ldr	x15, [x1]
    d178:      	cmp	x14, x15
    d17c:      	b.eq	0xd19c <_wf_full_chain_lookup$instance$7c9d455aedf48152+0xc0>
    d180:      	add	x11, x13, #0x10
    d184:      	subs	x10, x10, #0x1
    d188:      	b.ne	0xd15c <_wf_full_chain_lookup$instance$7c9d455aedf48152+0x80>
    d18c:      	mov	x1, #0x0                ; =0
    d190:      	mov	w0, #0x1                ; =1
    d194:      	mov	w2, #0x0                ; =0
    d198:      	ret
    d19c:      	mov	w0, #0x0                ; =0
    d1a0:      	mov	w8, #0x18               ; =24
    d1a4:      	madd	x8, x11, x8, x12
    d1a8:      	ldr	x1, [x8, #0x8]
    d1ac:      	mov	w2, #0x0                ; =0
    d1b0:      	ret

000000000000d1b4 <_wf_full_chain_free$instance$d30acb1e89e19e46>:
    d1b4:      	stp	x28, x27, [sp, #-0x60]!
    d1b8:      	stp	x26, x25, [sp, #0x10]
    d1bc:      	stp	x24, x23, [sp, #0x20]
    d1c0:      	stp	x22, x21, [sp, #0x30]
    d1c4:      	stp	x20, x19, [sp, #0x40]
    d1c8:      	stp	x29, x30, [sp, #0x50]
    d1cc:      	mov	x8, x0
    d1d0:      	ldp	x10, x9, [x0, #0x18]
    d1d4:      	ldr	x0, [x0, #0x28]
    d1d8:      	cbz	x10, 0xd34c <_wf_full_chain_free$instance$d30acb1e89e19e46+0x198>
    d1dc:      	mov	x12, #0xe5b9            ; =58809
    d1e0:      	movk	x12, #0x1ce4, lsl #16
    d1e4:      	movk	x12, #0x476d, lsl #32
    d1e8:      	movk	x12, #0xbf58, lsl #48
    d1ec:      	mov	x13, #0x11eb            ; =4587
    d1f0:      	movk	x13, #0x1331, lsl #16
    d1f4:      	movk	x13, #0x49bb, lsl #32
    d1f8:      	movk	x13, #0x94d0, lsl #48
    d1fc:      	ldp	x11, x15, [x1, #0x8]
    d200:      	ldr	x14, [x1, #0x18]
    d204:      	cmp	x10, #0x4
    d208:      	b.hs	0xd214 <_wf_full_chain_free$instance$d30acb1e89e19e46+0x60>
    d20c:      	mov	x16, x10
    d210:      	b	0xd304 <_wf_full_chain_free$instance$d30acb1e89e19e46+0x150>
    d214:      	mov	x5, #0x0                ; =0
    d218:      	mov	x6, #0x0                ; =0
    d21c:      	mov	x7, #0x0                ; =0
    d220:      	mov	x2, #0x0                ; =0
    d224:      	mov	x3, #0x0                ; =0
    d228:      	mov	x4, #0x0                ; =0
    d22c:      	and	x17, x10, #0xfffffffffffffffc
    d230:      	and	x16, x10, #0x3
    d234:      	mov	w19, #0x18              ; =24
    d238:      	madd	x19, x10, x19, x0
    d23c:      	sub	x19, x19, #0x30
    d240:      	mov	w20, #0x83              ; =131
    d244:      	mov	x21, x17
    d248:      	ldp	x22, x23, [x19, #0x18]
    d24c:      	ldp	x24, x25, [x19]
    d250:      	ldp	x26, x27, [x19, #-0x18]
    d254:      	ldp	x28, x30, [x19, #-0x30]
    d258:      	madd	x22, x22, x20, x23
    d25c:      	madd	x23, x24, x20, x25
    d260:      	madd	x24, x26, x20, x27
    d264:      	madd	x25, x28, x20, x30
    d268:      	add	x11, x11, x22
    d26c:      	add	x2, x2, x23
    d270:      	add	x3, x3, x24
    d274:      	add	x4, x4, x25
    d278:      	eor	x22, x22, x22, lsr #30
    d27c:      	eor	x23, x23, x23, lsr #30
    d280:      	eor	x24, x24, x24, lsr #30
    d284:      	eor	x25, x25, x25, lsr #30
    d288:      	mul	x22, x22, x12
    d28c:      	mul	x23, x23, x12
    d290:      	mul	x24, x24, x12
    d294:      	mul	x25, x25, x12
    d298:      	eor	x22, x22, x22, lsr #27
    d29c:      	eor	x23, x23, x23, lsr #27
    d2a0:      	eor	x24, x24, x24, lsr #27
    d2a4:      	eor	x25, x25, x25, lsr #27
    d2a8:      	mul	x22, x22, x13
    d2ac:      	mul	x23, x23, x13
    d2b0:      	mul	x24, x24, x13
    d2b4:      	eor	x15, x15, x22, lsr #31
    d2b8:      	mul	x25, x25, x13
    d2bc:      	eor	x5, x5, x23, lsr #31
    d2c0:      	eor	x6, x6, x24, lsr #31
    d2c4:      	eor	x7, x7, x25, lsr #31
    d2c8:      	eor	x15, x15, x22
    d2cc:      	eor	x5, x5, x23
    d2d0:      	eor	x6, x6, x24
    d2d4:      	eor	x7, x7, x25
    d2d8:      	sub	x19, x19, #0x60
    d2dc:      	sub	x21, x21, #0x4
    d2e0:      	cbnz	x21, 0xd248 <_wf_full_chain_free$instance$d30acb1e89e19e46+0x94>
    d2e4:      	eor	x15, x5, x15
    d2e8:      	eor	x5, x7, x6
    d2ec:      	eor	x15, x5, x15
    d2f0:      	add	x11, x2, x11
    d2f4:      	add	x2, x4, x3
    d2f8:      	add	x11, x2, x11
    d2fc:      	cmp	x10, x17
    d300:      	b.eq	0xd340 <_wf_full_chain_free$instance$d30acb1e89e19e46+0x18c>
    d304:      	mov	w17, #0x18              ; =24
    d308:      	madd	x17, x16, x17, x0
    d30c:      	sub	x17, x17, #0x18
    d310:      	mov	w2, #0x83               ; =131
    d314:      	ldp	x3, x4, [x17], #-0x18
    d318:      	madd	x3, x3, x2, x4
    d31c:      	add	x11, x11, x3
    d320:      	eor	x3, x3, x3, lsr #30
    d324:      	mul	x3, x3, x12
    d328:      	eor	x3, x3, x3, lsr #27
    d32c:      	mul	x3, x3, x13
    d330:      	eor	x15, x15, x3, lsr #31
    d334:      	eor	x15, x15, x3
    d338:      	sub	x16, x16, #0x1
    d33c:      	cbnz	x16, 0xd314 <_wf_full_chain_free$instance$d30acb1e89e19e46+0x160>
    d340:      	add	x10, x10, x14
    d344:      	stp	x11, x15, [x1, #0x8]
    d348:      	str	x10, [x1, #0x18]
    d34c:      	ldp	x20, x19, [x8, #0x8]
    d350:      	cbz	x9, 0xd358 <_wf_full_chain_free$instance$d30acb1e89e19e46+0x1a4>
    d354:      	bl	0xd354 <_wf_full_chain_free$instance$d30acb1e89e19e46+0x1a0>
		000000000000d354:  ARM64_RELOC_BRANCH26	_free
    d358:      	cbz	x20, 0xd364 <_wf_full_chain_free$instance$d30acb1e89e19e46+0x1b0>
    d35c:      	mov	x0, x19
    d360:      	bl	0xd360 <_wf_full_chain_free$instance$d30acb1e89e19e46+0x1ac>
		000000000000d360:  ARM64_RELOC_BRANCH26	_free
    d364:      	mov	w0, #0x0                ; =0
    d368:      	ldp	x29, x30, [sp, #0x50]
    d36c:      	ldp	x20, x19, [sp, #0x40]
    d370:      	ldp	x22, x21, [sp, #0x30]
    d374:      	ldp	x24, x23, [sp, #0x20]
    d378:      	ldp	x26, x25, [sp, #0x10]
    d37c:      	ldp	x28, x27, [sp], #0x60
    d380:      	ret

000000000000d384 <_wf_full_chain_new$instance$1fa0694bfbd574aa>:
    d384:      	stp	x22, x21, [sp, #-0x30]!
    d388:      	stp	x20, x19, [sp, #0x10]
    d38c:      	stp	x29, x30, [sp, #0x20]
    d390:      	mov	x20, x1
    d394:      	mov	x19, x0
    d398:      	cbz	x1, 0xd3d0 <_wf_full_chain_new$instance$1fa0694bfbd574aa+0x4c>
    d39c:      	lsl	x22, x20, #3
    d3a0:      	mov	x0, x22
    d3a4:      	bl	0xd3a4 <_wf_full_chain_new$instance$1fa0694bfbd574aa+0x20>
		000000000000d3a4:  ARM64_RELOC_BRANCH26	_malloc
    d3a8:      	cbz	x0, 0xd3cc <_wf_full_chain_new$instance$1fa0694bfbd574aa+0x48>
    d3ac:      	mov	x21, x0
    d3b0:      	mov	w1, #0xff               ; =255
    d3b4:      	mov	x2, x22
    d3b8:      	bl	0xd3b8 <_wf_full_chain_new$instance$1fa0694bfbd574aa+0x34>
		000000000000d3b8:  ARM64_RELOC_BRANCH26	_memset
    d3bc:      	add	x8, x20, x20, lsl #4
    d3c0:      	lsl	x0, x8, #4
    d3c4:      	bl	0xd3c4 <_wf_full_chain_new$instance$1fa0694bfbd574aa+0x40>
		000000000000d3c4:  ARM64_RELOC_BRANCH26	_malloc
    d3c8:      	cbnz	x0, 0xd3dc <_wf_full_chain_new$instance$1fa0694bfbd574aa+0x58>
    d3cc:      	bl	0xd3cc <_wf_full_chain_new$instance$1fa0694bfbd574aa+0x48>
		000000000000d3cc:  ARM64_RELOC_BRANCH26	l_wf_resource_abort
    d3d0:      	adrp	x21, 0xd000 <_wf_full_chain_remove$instance$29255544f66aec6e+0x12c>
		000000000000d3d0:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    d3d4:      	add	x21, x21, #0x0
		000000000000d3d4:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    d3d8:      	mov	x0, x21
    d3dc:      	stp	x20, x20, [x19]
    d3e0:      	stp	x21, xzr, [x19, #0x10]
    d3e4:      	stp	x20, x0, [x19, #0x20]
    d3e8:      	ldp	x29, x30, [sp, #0x20]
    d3ec:      	ldp	x20, x19, [sp, #0x10]
    d3f0:      	ldp	x22, x21, [sp], #0x30
    d3f4:      	ret

000000000000d3f8 <_wf_full_chain_try_put$instance$58dd6ca826103b6d>:
    d3f8:      	sub	sp, sp, #0xe0
    d3fc:      	stp	x28, x27, [sp, #0x80]
    d400:      	stp	x26, x25, [sp, #0x90]
    d404:      	stp	x24, x23, [sp, #0xa0]
    d408:      	stp	x22, x21, [sp, #0xb0]
    d40c:      	stp	x20, x19, [sp, #0xc0]
    d410:      	stp	x29, x30, [sp, #0xd0]
    d414:      	ldrb	w8, [x4, #0x8]
    d418:      	tbz	w8, #0x0, 0xd424 <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x2c>
    d41c:      	mov	x15, #0x0               ; =0
    d420:      	b	0xd460 <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x68>
    d424:      	ldr	x8, [x4]
    d428:      	eor	x8, x8, x2
    d42c:      	eor	x8, x8, x8, lsr #30
    d430:      	mov	x9, #0xe5b9             ; =58809
    d434:      	movk	x9, #0x1ce4, lsl #16
    d438:      	movk	x9, #0x476d, lsl #32
    d43c:      	movk	x9, #0xbf58, lsl #48
    d440:      	mul	x8, x8, x9
    d444:      	eor	x8, x8, x8, lsr #27
    d448:      	mov	x9, #0x11eb             ; =4587
    d44c:      	movk	x9, #0x1331, lsl #16
    d450:      	movk	x9, #0x49bb, lsl #32
    d454:      	movk	x9, #0x94d0, lsl #48
    d458:      	mul	x8, x8, x9
    d45c:      	eor	x15, x8, x8, lsr #31
    d460:      	ldp	x14, x13, [x3]
    d464:      	ldp	x12, x11, [x3, #0x10]
    d468:      	ldp	x10, x9, [x3, #0x20]
    d46c:      	ldp	x8, x30, [x3, #0x30]
    d470:      	ldp	x28, x27, [x3, #0x40]
    d474:      	ldp	x26, x25, [x3, #0x50]
    d478:      	ldp	x24, x23, [x3, #0x60]
    d47c:      	ldp	x22, x21, [x3, #0x70]
    d480:      	ldp	x20, x17, [x3, #0x80]
    d484:      	ldr	x16, [x3, #0x90]
    d488:      	stp	x17, x16, [sp, #0x28]
    d48c:      	ldp	x17, x16, [x3, #0x98]
    d490:      	stp	x17, x16, [sp, #0x38]
    d494:      	ldp	x17, x16, [x3, #0xa8]
    d498:      	stp	x17, x16, [sp, #0x48]
    d49c:      	ldp	x17, x16, [x3, #0xb8]
    d4a0:      	stp	x17, x16, [sp, #0x58]
    d4a4:      	ldp	x17, x16, [x3, #0xc8]
    d4a8:      	stp	x17, x16, [sp, #0x68]
    d4ac:      	ldp	x16, x4, [x3, #0xd8]
    d4b0:      	str	x16, [sp, #0x78]
    d4b4:      	ldp	x19, x7, [x3, #0xe8]
    d4b8:      	ldr	x6, [x3, #0xf8]
    d4bc:      	ldr	x5, [x1]
    d4c0:      	cbz	x5, 0xd5f0 <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x1f8>
    d4c4:      	stp	x4, x19, [sp, #0x8]
    d4c8:      	stp	x7, x6, [sp, #0x18]
    d4cc:      	udiv	x16, x15, x5
    d4d0:      	msub	x17, x16, x5, x15
    d4d4:      	ldp	x15, x16, [x1, #0x10]
    d4d8:      	str	x17, [sp]
    d4dc:      	ldr	x17, [x15, x17, lsl #3]
    d4e0:      	cbz	x16, 0xd524 <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x12c>
    d4e4:      	cmp	x17, x16
    d4e8:      	b.hs	0xd524 <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x12c>
    d4ec:      	ldr	x6, [x1, #0x28]
    d4f0:      	mov	w7, #0x1                ; =1
    d4f4:      	mov	w3, #0x110              ; =272
    d4f8:      	mov	x4, x17
    d4fc:      	madd	x4, x4, x3, x6
    d500:      	ldr	x19, [x4]
    d504:      	cmp	x19, x2
    d508:      	b.eq	0xd678 <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x280>
    d50c:      	cmp	x7, x16
    d510:      	b.hs	0xd524 <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x12c>
    d514:      	ldr	x4, [x4, #0x108]
    d518:      	add	x7, x7, #0x1
    d51c:      	cmp	x4, x16
    d520:      	b.lo	0xd4fc <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x104>
    d524:      	cmp	x16, x5
    d528:      	ldp	x7, x6, [sp, #0x18]
    d52c:      	ldp	x4, x19, [sp, #0x8]
    d530:      	b.hs	0xd5f0 <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x1f8>
    d534:      	cmp	x16, #0x2, lsl #12      ; =0x2000
    d538:      	b.hs	0xd5f0 <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x1f8>
    d53c:      	ldr	x3, [x1, #0x20]
    d540:      	cmp	x16, x3
    d544:      	b.hs	0xd5f0 <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x1f8>
    d548:      	ldr	x3, [x1, #0x28]
    d54c:      	mov	x5, x4
    d550:      	mov	w4, #0x110              ; =272
    d554:      	madd	x3, x16, x4, x3
    d558:      	stp	x2, x14, [x3]
    d55c:      	stp	x13, x12, [x3, #0x10]
    d560:      	stp	x11, x10, [x3, #0x20]
    d564:      	stp	x9, x8, [x3, #0x30]
    d568:      	stp	x30, x28, [x3, #0x40]
    d56c:      	stp	x27, x26, [x3, #0x50]
    d570:      	stp	x25, x24, [x3, #0x60]
    d574:      	stp	x23, x22, [x3, #0x70]
    d578:      	stp	x21, x20, [x3, #0x80]
    d57c:      	ldp	x9, x8, [sp, #0x28]
    d580:      	stp	x9, x8, [x3, #0x90]
    d584:      	ldp	x9, x8, [sp, #0x38]
    d588:      	stp	x9, x8, [x3, #0xa0]
    d58c:      	ldp	x9, x8, [sp, #0x48]
    d590:      	stp	x9, x8, [x3, #0xb0]
    d594:      	ldp	x9, x8, [sp, #0x58]
    d598:      	stp	x9, x8, [x3, #0xc0]
    d59c:      	ldp	x9, x8, [sp, #0x68]
    d5a0:      	stp	x9, x8, [x3, #0xd0]
    d5a4:      	ldr	x8, [sp, #0x78]
    d5a8:      	stp	x8, x5, [x3, #0xe0]
    d5ac:      	stp	x19, x7, [x3, #0xf0]
    d5b0:      	stp	x6, x17, [x3, #0x100]
    d5b4:      	ldr	x8, [sp]
    d5b8:      	str	x16, [x15, x8, lsl #3]
    d5bc:      	add	x8, x16, #0x1
    d5c0:      	str	x8, [x1, #0x18]
    d5c4:      	movi.2d	v0, #0000000000000000
    d5c8:      	stp	q0, q0, [x0]
    d5cc:      	stp	q0, q0, [x0, #0x20]
    d5d0:      	stp	q0, q0, [x0, #0x40]
    d5d4:      	stp	q0, q0, [x0, #0x60]
    d5d8:      	stp	q0, q0, [x0, #0x80]
    d5dc:      	stp	q0, q0, [x0, #0xa0]
    d5e0:      	stp	q0, q0, [x0, #0xc0]
    d5e4:      	stp	q0, q0, [x0, #0xe0]
    d5e8:      	str	q0, [x0, #0x100]
    d5ec:      	b	0xd658 <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x260>
    d5f0:      	stp	x14, x13, [x0, #0x10]
    d5f4:      	stp	x12, x11, [x0, #0x20]
    d5f8:      	stp	xzr, x2, [x0]
    d5fc:      	mov	w11, #0x1               ; =1
    d600:      	str	w11, [x0]
    d604:      	strb	w11, [x0, #0x4]
    d608:      	stp	x10, x9, [x0, #0x30]
    d60c:      	stp	x8, x30, [x0, #0x40]
    d610:      	stp	x28, x27, [x0, #0x50]
    d614:      	stp	x26, x25, [x0, #0x60]
    d618:      	stp	x24, x23, [x0, #0x70]
    d61c:      	stp	x22, x21, [x0, #0x80]
    d620:      	ldp	x9, x10, [sp, #0x28]
    d624:      	stp	x20, x9, [x0, #0x90]
    d628:      	ldp	x9, x11, [sp, #0x38]
    d62c:      	stp	x10, x9, [x0, #0xa0]
    d630:      	ldp	x9, x10, [sp, #0x48]
    d634:      	stp	x11, x9, [x0, #0xb0]
    d638:      	ldp	x9, x11, [sp, #0x58]
    d63c:      	stp	x10, x9, [x0, #0xc0]
    d640:      	ldp	x9, x10, [sp, #0x68]
    d644:      	stp	x11, x9, [x0, #0xd0]
    d648:      	ldr	x8, [sp, #0x78]
    d64c:      	stp	x10, x8, [x0, #0xe0]
    d650:      	stp	x4, x19, [x0, #0xf0]
    d654:      	stp	x7, x6, [x0, #0x100]
    d658:      	ldp	x29, x30, [sp, #0xd0]
    d65c:      	ldp	x20, x19, [sp, #0xc0]
    d660:      	ldp	x22, x21, [sp, #0xb0]
    d664:      	ldp	x24, x23, [sp, #0xa0]
    d668:      	ldp	x26, x25, [sp, #0x90]
    d66c:      	ldp	x28, x27, [sp, #0x80]
    d670:      	add	sp, sp, #0xe0
    d674:      	ret
    d678:      	ldur	q0, [x4, #0x8]
    d67c:      	stp	x14, x13, [x4, #0x8]
    d680:      	ldur	q1, [x4, #0x18]
    d684:      	stp	x12, x11, [x4, #0x18]
    d688:      	ldur	q2, [x4, #0x28]
    d68c:      	stp	x10, x9, [x4, #0x28]
    d690:      	ldur	q3, [x4, #0x38]
    d694:      	stp	x8, x30, [x4, #0x38]
    d698:      	ldur	q4, [x4, #0x48]
    d69c:      	stp	x28, x27, [x4, #0x48]
    d6a0:      	ldur	q5, [x4, #0x58]
    d6a4:      	stp	x26, x25, [x4, #0x58]
    d6a8:      	ldur	q6, [x4, #0x68]
    d6ac:      	stp	x24, x23, [x4, #0x68]
    d6b0:      	ldur	q7, [x4, #0x78]
    d6b4:      	stp	x22, x21, [x4, #0x78]
    d6b8:      	ldur	q16, [x4, #0x88]
    d6bc:      	ldp	x9, x10, [sp, #0x28]
    d6c0:      	stp	x20, x9, [x4, #0x88]
    d6c4:      	ldur	q17, [x4, #0x98]
    d6c8:      	ldp	x9, x11, [sp, #0x38]
    d6cc:      	stp	x10, x9, [x4, #0x98]
    d6d0:      	ldur	q18, [x4, #0xa8]
    d6d4:      	ldp	x9, x10, [sp, #0x48]
    d6d8:      	stp	x11, x9, [x4, #0xa8]
    d6dc:      	ldur	q19, [x4, #0xb8]
    d6e0:      	ldp	x9, x11, [sp, #0x58]
    d6e4:      	stp	x10, x9, [x4, #0xb8]
    d6e8:      	ldur	q20, [x4, #0xc8]
    d6ec:      	ldp	x9, x10, [sp, #0x68]
    d6f0:      	stp	x11, x9, [x4, #0xc8]
    d6f4:      	ldur	q21, [x4, #0xd8]
    d6f8:      	ldr	x8, [sp, #0x78]
    d6fc:      	stp	x10, x8, [x4, #0xd8]
    d700:      	ldur	q22, [x4, #0xe8]
    d704:      	ldp	x9, x8, [sp, #0x8]
    d708:      	stp	x9, x8, [x4, #0xe8]
    d70c:      	ldur	q23, [x4, #0xf8]
    d710:      	ldp	x9, x8, [sp, #0x18]
    d714:      	stp	x9, x8, [x4, #0xf8]
    d718:      	stp	xzr, x2, [x0]
    d71c:      	mov	w8, #0x1                ; =1
    d720:      	str	w8, [x0]
    d724:      	stp	q0, q1, [x0, #0x10]
    d728:      	stp	q2, q3, [x0, #0x30]
    d72c:      	stp	q4, q5, [x0, #0x50]
    d730:      	stp	q6, q7, [x0, #0x70]
    d734:      	stp	q16, q17, [x0, #0x90]
    d738:      	stp	q18, q19, [x0, #0xb0]
    d73c:      	stp	q20, q21, [x0, #0xd0]
    d740:      	stp	q22, q23, [x0, #0xf0]
    d744:      	b	0xd658 <_wf_full_chain_try_put$instance$58dd6ca826103b6d+0x260>

000000000000d748 <_wf_full_chain_remove$instance$58dd6ca826103b6d>:
    d748:      	stp	d15, d14, [sp, #-0x40]!
    d74c:      	stp	d13, d12, [sp, #0x10]
    d750:      	stp	d11, d10, [sp, #0x20]
    d754:      	stp	d9, d8, [sp, #0x30]
    d758:      	ldr	x8, [x1, #0x18]
    d75c:      	cbz	x8, 0xd814 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0xcc>
    d760:      	ldrb	w10, [x3, #0x8]
    d764:      	tbz	w10, #0x0, 0xd778 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x30>
    d768:      	mov	x9, #0x0                ; =0
    d76c:      	ldr	x11, [x1]
    d770:      	cbnz	x11, 0xd7c0 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x78>
    d774:      	b	0xd814 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0xcc>
    d778:      	ldr	x9, [x2]
    d77c:      	ldr	x11, [x3]
    d780:      	eor	x9, x11, x9
    d784:      	eor	x9, x9, x9, lsr #30
    d788:      	mov	x11, #0xe5b9            ; =58809
    d78c:      	movk	x11, #0x1ce4, lsl #16
    d790:      	movk	x11, #0x476d, lsl #32
    d794:      	movk	x11, #0xbf58, lsl #48
    d798:      	mul	x9, x9, x11
    d79c:      	eor	x9, x9, x9, lsr #27
    d7a0:      	mov	x11, #0x11eb            ; =4587
    d7a4:      	movk	x11, #0x1331, lsl #16
    d7a8:      	movk	x11, #0x49bb, lsl #32
    d7ac:      	movk	x11, #0x94d0, lsl #48
    d7b0:      	mul	x9, x9, x11
    d7b4:      	eor	x9, x9, x9, lsr #31
    d7b8:      	ldr	x11, [x1]
    d7bc:      	cbz	x11, 0xd814 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0xcc>
    d7c0:      	udiv	x12, x9, x11
    d7c4:      	msub	x9, x12, x11, x9
    d7c8:      	ldr	x12, [x1, #0x10]
    d7cc:      	add	x14, x12, x9, lsl #3
    d7d0:      	mov	w16, #0x110             ; =272
    d7d4:      	mov	x4, x8
    d7d8:      	mov	x5, x14
    d7dc:      	mov	x17, x8
    d7e0:      	ldr	x9, [x5]
    d7e4:      	cmp	x9, x8
    d7e8:      	b.hs	0xd814 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0xcc>
    d7ec:      	ldr	x13, [x1, #0x28]
    d7f0:      	madd	x15, x9, x16, x13
    d7f4:      	ldr	x6, [x15]
    d7f8:      	ldr	x7, [x2]
    d7fc:      	add	x5, x15, #0x108
    d800:      	cmp	x6, x7
    d804:      	b.eq	0xd850 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x108>
    d808:      	mov	x17, x9
    d80c:      	subs	x4, x4, #0x1
    d810:      	b.ne	0xd7e0 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x98>
    d814:      	movi.2d	v0, #0000000000000000
    d818:      	stp	q0, q0, [x0, #0xf0]
    d81c:      	stp	q0, q0, [x0, #0xd0]
    d820:      	stp	q0, q0, [x0, #0xb0]
    d824:      	stp	q0, q0, [x0, #0x90]
    d828:      	stp	q0, q0, [x0, #0x70]
    d82c:      	stp	q0, q0, [x0, #0x50]
    d830:      	stp	q0, q0, [x0, #0x30]
    d834:      	stp	q0, q0, [x0, #0x10]
    d838:      	str	q0, [x0]
    d83c:      	ldp	d9, d8, [sp, #0x30]
    d840:      	ldp	d11, d10, [sp, #0x20]
    d844:      	ldp	d13, d12, [sp, #0x10]
    d848:      	ldp	d15, d14, [sp], #0x40
    d84c:      	ret
    d850:      	ldr	x16, [x5]
    d854:      	cmp	x17, x8
    d858:      	b.hs	0xd86c <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x124>
    d85c:      	mov	w14, #0x110             ; =272
    d860:      	madd	x14, x17, x14, x13
    d864:      	str	x16, [x14, #0x108]
    d868:      	b	0xd870 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x128>
    d86c:      	str	x16, [x14]
    d870:      	sub	x14, x8, #0x1
    d874:      	mov	w8, #0x110              ; =272
    d878:      	str	x14, [x1, #0x18]
    d87c:      	madd	x8, x14, x8, x13
    d880:      	ldp	q15, q14, [x8]
    d884:      	ldp	q13, q12, [x8, #0x20]
    d888:      	ldp	q11, q10, [x8, #0x40]
    d88c:      	ldp	q9, q8, [x8, #0x60]
    d890:      	ldp	q31, q30, [x8, #0x80]
    d894:      	ldp	q29, q28, [x8, #0xa0]
    d898:      	ldp	q27, q26, [x8, #0xc0]
    d89c:      	ldp	q25, q24, [x8, #0xe0]
    d8a0:      	ldr	x16, [x8, #0x100]
    d8a4:      	cmp	x9, x14
    d8a8:      	b.hs	0xd944 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x1fc>
    d8ac:      	ldr	x17, [x8]
    d8b0:      	ldr	x1, [x8, #0x108]
    d8b4:      	ldp	q0, q1, [x15]
    d8b8:      	ldp	q2, q3, [x15, #0x20]
    d8bc:      	ldp	q4, q5, [x15, #0x40]
    d8c0:      	ldp	q6, q7, [x15, #0x60]
    d8c4:      	ldp	q16, q17, [x15, #0x80]
    d8c8:      	ldp	q18, q19, [x15, #0xa0]
    d8cc:      	ldp	q20, q21, [x15, #0xc0]
    d8d0:      	ldp	q22, q23, [x15, #0xe0]
    d8d4:      	ldr	x8, [x15, #0x100]
    d8d8:      	stp	q15, q14, [x15]
    d8dc:      	stp	q13, q12, [x15, #0x20]
    d8e0:      	stp	q11, q10, [x15, #0x40]
    d8e4:      	stp	q9, q8, [x15, #0x60]
    d8e8:      	stp	q31, q30, [x15, #0x80]
    d8ec:      	stp	q29, q28, [x15, #0xa0]
    d8f0:      	stp	q27, q26, [x15, #0xc0]
    d8f4:      	stp	q25, q24, [x15, #0xe0]
    d8f8:      	stp	x16, x1, [x15, #0x100]
    d8fc:      	tbz	w10, #0x0, 0xd98c <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x244>
    d900:      	mov	x10, #0x0               ; =0
    d904:      	udiv	x15, x10, x11
    d908:      	msub	x11, x15, x11, x10
    d90c:      	ldr	x10, [x12, x11, lsl #3]
    d910:      	cmp	x10, x14
    d914:      	b.eq	0xd9dc <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x294>
    d918:      	b.hs	0xd9e8 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x2a0>
    d91c:      	mov	w11, #0x1               ; =1
    d920:      	mov	w12, #0x110             ; =272
    d924:      	madd	x15, x10, x12, x13
    d928:      	ldr	x10, [x15, #0x108]
    d92c:      	cmp	x10, x14
    d930:      	b.eq	0xd9e4 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x29c>
    d934:      	ccmp	x11, x14, #0x2, lo
    d938:      	add	x11, x11, #0x1
    d93c:      	b.lo	0xd924 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x1dc>
    d940:      	b	0xd9e8 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x2a0>
    d944:      	mov	x8, x16
    d948:      	mov.16b	v0, v15
    d94c:      	mov.16b	v1, v14
    d950:      	mov.16b	v2, v13
    d954:      	mov.16b	v3, v12
    d958:      	mov.16b	v4, v11
    d95c:      	mov.16b	v5, v10
    d960:      	mov.16b	v6, v9
    d964:      	mov.16b	v7, v8
    d968:      	mov.16b	v16, v31
    d96c:      	mov.16b	v17, v30
    d970:      	mov.16b	v18, v29
    d974:      	mov.16b	v19, v28
    d978:      	mov.16b	v20, v27
    d97c:      	mov.16b	v21, v26
    d980:      	mov.16b	v22, v25
    d984:      	mov.16b	v23, v24
    d988:      	b	0xd9e8 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x2a0>
    d98c:      	ldr	x10, [x3]
    d990:      	eor	x10, x10, x17
    d994:      	eor	x10, x10, x10, lsr #30
    d998:      	mov	x15, #0xe5b9            ; =58809
    d99c:      	movk	x15, #0x1ce4, lsl #16
    d9a0:      	movk	x15, #0x476d, lsl #32
    d9a4:      	movk	x15, #0xbf58, lsl #48
    d9a8:      	mul	x10, x10, x15
    d9ac:      	eor	x10, x10, x10, lsr #27
    d9b0:      	mov	x15, #0x11eb            ; =4587
    d9b4:      	movk	x15, #0x1331, lsl #16
    d9b8:      	movk	x15, #0x49bb, lsl #32
    d9bc:      	movk	x15, #0x94d0, lsl #48
    d9c0:      	mul	x10, x10, x15
    d9c4:      	eor	x10, x10, x10, lsr #31
    d9c8:      	udiv	x15, x10, x11
    d9cc:      	msub	x11, x15, x11, x10
    d9d0:      	ldr	x10, [x12, x11, lsl #3]
    d9d4:      	cmp	x10, x14
    d9d8:      	b.ne	0xd918 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x1d0>
    d9dc:      	str	x9, [x12, x11, lsl #3]
    d9e0:      	b	0xd9e8 <_wf_full_chain_remove$instance$58dd6ca826103b6d+0x2a0>
    d9e4:      	str	x9, [x15, #0x108]
    d9e8:      	str	xzr, [x0]
    d9ec:      	mov	w9, #0x1                ; =1
    d9f0:      	str	w9, [x0]
    d9f4:      	stur	q0, [x0, #0x8]
    d9f8:      	stur	q1, [x0, #0x18]
    d9fc:      	stur	q2, [x0, #0x28]
    da00:      	stur	q3, [x0, #0x38]
    da04:      	stur	q4, [x0, #0x48]
    da08:      	stur	q5, [x0, #0x58]
    da0c:      	stur	q6, [x0, #0x68]
    da10:      	stur	q7, [x0, #0x78]
    da14:      	stur	q16, [x0, #0x88]
    da18:      	stur	q17, [x0, #0x98]
    da1c:      	stur	q18, [x0, #0xa8]
    da20:      	stur	q19, [x0, #0xb8]
    da24:      	stur	q20, [x0, #0xc8]
    da28:      	stur	q21, [x0, #0xd8]
    da2c:      	stur	q22, [x0, #0xe8]
    da30:      	stur	q23, [x0, #0xf8]
    da34:      	str	x8, [x0, #0x108]
    da38:      	ldp	d9, d8, [sp, #0x30]
    da3c:      	ldp	d11, d10, [sp, #0x20]
    da40:      	ldp	d13, d12, [sp, #0x10]
    da44:      	ldp	d15, d14, [sp], #0x40
    da48:      	ret

000000000000da4c <_wf_full_chain_capacity$instance$1fa0694bfbd574aa>:
    da4c:      	ldr	x0, [x0]
    da50:      	ret

000000000000da54 <_wf_full_chain_len$instance$1fa0694bfbd574aa>:
    da54:      	ldr	x0, [x0, #0x18]
    da58:      	ret

000000000000da5c <_wf_full_chain_lookup$instance$45d862e2288df95e>:
    da5c:      	ldrb	w8, [x2, #0x8]
    da60:      	tbz	w8, #0x0, 0xda74 <_wf_full_chain_lookup$instance$45d862e2288df95e+0x18>
    da64:      	mov	x9, #0x0                ; =0
    da68:      	ldr	x10, [x0]
    da6c:      	cbnz	x10, 0xdabc <_wf_full_chain_lookup$instance$45d862e2288df95e+0x60>
    da70:      	b	0xdb0c <_wf_full_chain_lookup$instance$45d862e2288df95e+0xb0>
    da74:      	ldr	x8, [x2]
    da78:      	ldr	x9, [x1]
    da7c:      	eor	x8, x9, x8
    da80:      	eor	x8, x8, x8, lsr #30
    da84:      	mov	x9, #0xe5b9             ; =58809
    da88:      	movk	x9, #0x1ce4, lsl #16
    da8c:      	movk	x9, #0x476d, lsl #32
    da90:      	movk	x9, #0xbf58, lsl #48
    da94:      	mul	x8, x8, x9
    da98:      	eor	x8, x8, x8, lsr #27
    da9c:      	mov	x9, #0x11eb             ; =4587
    daa0:      	movk	x9, #0x1331, lsl #16
    daa4:      	movk	x9, #0x49bb, lsl #32
    daa8:      	movk	x9, #0x94d0, lsl #48
    daac:      	mul	x8, x8, x9
    dab0:      	eor	x9, x8, x8, lsr #31
    dab4:      	ldr	x10, [x0]
    dab8:      	cbz	x10, 0xdb0c <_wf_full_chain_lookup$instance$45d862e2288df95e+0xb0>
    dabc:      	ldr	x8, [x0, #0x18]
    dac0:      	cbz	x8, 0xdb0c <_wf_full_chain_lookup$instance$45d862e2288df95e+0xb0>
    dac4:      	udiv	x11, x9, x10
    dac8:      	msub	x9, x11, x10, x9
    dacc:      	ldr	x10, [x0, #0x10]
    dad0:      	add	x11, x10, x9, lsl #3
    dad4:      	mov	w9, #0x110              ; =272
    dad8:      	mov	x10, x8
    dadc:      	ldr	x11, [x11]
    dae0:      	cmp	x11, x8
    dae4:      	b.hs	0xdb0c <_wf_full_chain_lookup$instance$45d862e2288df95e+0xb0>
    dae8:      	ldr	x12, [x0, #0x28]
    daec:      	madd	x13, x11, x9, x12
    daf0:      	ldr	x14, [x13]
    daf4:      	ldr	x15, [x1]
    daf8:      	cmp	x14, x15
    dafc:      	b.eq	0xdb1c <_wf_full_chain_lookup$instance$45d862e2288df95e+0xc0>
    db00:      	add	x11, x13, #0x108
    db04:      	subs	x10, x10, #0x1
    db08:      	b.ne	0xdadc <_wf_full_chain_lookup$instance$45d862e2288df95e+0x80>
    db0c:      	mov	x1, #0x0                ; =0
    db10:      	mov	w0, #0x1                ; =1
    db14:      	mov	w2, #0x0                ; =0
    db18:      	ret
    db1c:      	mov	w0, #0x0                ; =0
    db20:      	mov	w8, #0x110              ; =272
    db24:      	madd	x8, x11, x8, x12
    db28:      	ldr	x1, [x8, #0x8]
    db2c:      	mov	w2, #0x0                ; =0
    db30:      	ret

000000000000db34 <_wf_full_chain_free$instance$e1a21e22af512733>:
    db34:      	stp	x20, x19, [sp, #-0x20]!
    db38:      	stp	x29, x30, [sp, #0x10]
    db3c:      	mov	x8, x0
    db40:      	ldp	x10, x9, [x0, #0x18]
    db44:      	ldr	x0, [x0, #0x28]
    db48:      	cbz	x10, 0xdc80 <_wf_full_chain_free$instance$e1a21e22af512733+0x14c>
    db4c:      	ldp	x11, x12, [x1, #0x8]
    db50:      	mov	w13, #0x110             ; =272
    db54:      	madd	x13, x10, x13, x0
    db58:      	sub	x14, x13, #0x88
    db5c:      	ldr	x13, [x1, #0x18]
    db60:      	mov	w15, #0x83              ; =131
    db64:      	mov	x16, #0xe5b9            ; =58809
    db68:      	movk	x16, #0x1ce4, lsl #16
    db6c:      	movk	x16, #0x476d, lsl #32
    db70:      	movk	x16, #0xbf58, lsl #48
    db74:      	mov	x17, #0x11eb            ; =4587
    db78:      	movk	x17, #0x1331, lsl #16
    db7c:      	movk	x17, #0x49bb, lsl #32
    db80:      	movk	x17, #0x94d0, lsl #48
    db84:      	mov	x2, x10
    db88:      	ldp	x3, x4, [x14, #-0x88]
    db8c:      	madd	x3, x3, x15, x4
    db90:      	ldp	x4, x5, [x14, #-0x78]
    db94:      	madd	x3, x3, x15, x4
    db98:      	madd	x3, x3, x15, x5
    db9c:      	ldp	x4, x5, [x14, #-0x68]
    dba0:      	madd	x3, x3, x15, x4
    dba4:      	madd	x3, x3, x15, x5
    dba8:      	ldp	x4, x5, [x14, #-0x58]
    dbac:      	madd	x3, x3, x15, x4
    dbb0:      	madd	x3, x3, x15, x5
    dbb4:      	ldp	x4, x5, [x14, #-0x48]
    dbb8:      	madd	x3, x3, x15, x4
    dbbc:      	madd	x3, x3, x15, x5
    dbc0:      	ldp	x4, x5, [x14, #-0x38]
    dbc4:      	madd	x3, x3, x15, x4
    dbc8:      	madd	x3, x3, x15, x5
    dbcc:      	ldp	x4, x5, [x14, #-0x28]
    dbd0:      	madd	x3, x3, x15, x4
    dbd4:      	madd	x3, x3, x15, x5
    dbd8:      	ldp	x4, x5, [x14, #-0x18]
    dbdc:      	madd	x3, x3, x15, x4
    dbe0:      	madd	x3, x3, x15, x5
    dbe4:      	ldp	x4, x5, [x14, #-0x8]
    dbe8:      	madd	x3, x3, x15, x4
    dbec:      	madd	x3, x3, x15, x5
    dbf0:      	ldp	x4, x5, [x14, #0x8]
    dbf4:      	madd	x3, x3, x15, x4
    dbf8:      	madd	x3, x3, x15, x5
    dbfc:      	ldp	x4, x5, [x14, #0x18]
    dc00:      	madd	x3, x3, x15, x4
    dc04:      	madd	x3, x3, x15, x5
    dc08:      	ldp	x4, x5, [x14, #0x28]
    dc0c:      	madd	x3, x3, x15, x4
    dc10:      	madd	x3, x3, x15, x5
    dc14:      	ldp	x4, x5, [x14, #0x38]
    dc18:      	madd	x3, x3, x15, x4
    dc1c:      	madd	x3, x3, x15, x5
    dc20:      	ldp	x4, x5, [x14, #0x48]
    dc24:      	madd	x3, x3, x15, x4
    dc28:      	madd	x3, x3, x15, x5
    dc2c:      	ldp	x4, x5, [x14, #0x58]
    dc30:      	madd	x3, x3, x15, x4
    dc34:      	madd	x3, x3, x15, x5
    dc38:      	ldp	x4, x5, [x14, #0x68]
    dc3c:      	madd	x3, x3, x15, x4
    dc40:      	madd	x3, x3, x15, x5
    dc44:      	ldr	x4, [x14, #0x78]
    dc48:      	madd	x3, x3, x15, x4
    dc4c:      	add	x11, x3, x11
    dc50:      	eor	x3, x3, x3, lsr #30
    dc54:      	mul	x3, x3, x16
    dc58:      	eor	x3, x3, x3, lsr #27
    dc5c:      	mul	x3, x3, x17
    dc60:      	eor	x12, x12, x3, lsr #31
    dc64:      	eor	x12, x12, x3
    dc68:      	sub	x14, x14, #0x110
    dc6c:      	sub	x2, x2, #0x1
    dc70:      	cbnz	x2, 0xdb88 <_wf_full_chain_free$instance$e1a21e22af512733+0x54>
    dc74:      	add	x10, x10, x13
    dc78:      	stp	x11, x12, [x1, #0x8]
    dc7c:      	str	x10, [x1, #0x18]
    dc80:      	ldp	x20, x19, [x8, #0x8]
    dc84:      	cbz	x9, 0xdc8c <_wf_full_chain_free$instance$e1a21e22af512733+0x158>
    dc88:      	bl	0xdc88 <_wf_full_chain_free$instance$e1a21e22af512733+0x154>
		000000000000dc88:  ARM64_RELOC_BRANCH26	_free
    dc8c:      	cbz	x20, 0xdc98 <_wf_full_chain_free$instance$e1a21e22af512733+0x164>
    dc90:      	mov	x0, x19
    dc94:      	bl	0xdc94 <_wf_full_chain_free$instance$e1a21e22af512733+0x160>
		000000000000dc94:  ARM64_RELOC_BRANCH26	_free
    dc98:      	mov	w0, #0x0                ; =0
    dc9c:      	ldp	x29, x30, [sp, #0x10]
    dca0:      	ldp	x20, x19, [sp], #0x20
    dca4:      	ret

000000000000dca8 <_wf_box_slots_new$instance$b45b69d9d0c6bbd0>:
    dca8:      	stp	x20, x19, [sp, #-0x20]!
    dcac:      	stp	x29, x30, [sp, #0x10]
    dcb0:      	mov	x19, x0
    dcb4:      	cbz	x0, 0xdce0 <_wf_box_slots_new$instance$b45b69d9d0c6bbd0+0x38>
    dcb8:      	add	x8, x19, x19, lsl #1
    dcbc:      	lsl	x0, x8, #3
    dcc0:      	bl	0xdcc0 <_wf_box_slots_new$instance$b45b69d9d0c6bbd0+0x18>
		000000000000dcc0:  ARM64_RELOC_BRANCH26	_malloc
    dcc4:      	mov	x2, x0
    dcc8:      	cbz	x0, 0xdcfc <_wf_box_slots_new$instance$b45b69d9d0c6bbd0+0x54>
    dccc:      	mov	x0, #0x0                ; =0
    dcd0:      	mov	x1, x19
    dcd4:      	ldp	x29, x30, [sp, #0x10]
    dcd8:      	ldp	x20, x19, [sp], #0x20
    dcdc:      	ret
    dce0:      	adrp	x2, 0xd000 <_wf_full_chain_remove$instance$29255544f66aec6e+0x12c>
		000000000000dce0:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    dce4:      	add	x2, x2, #0x0
		000000000000dce4:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    dce8:      	mov	x0, #0x0                ; =0
    dcec:      	mov	x1, x19
    dcf0:      	ldp	x29, x30, [sp, #0x10]
    dcf4:      	ldp	x20, x19, [sp], #0x20
    dcf8:      	ret
    dcfc:      	bl	0xdcfc <_wf_box_slots_new$instance$b45b69d9d0c6bbd0+0x54>
		000000000000dcfc:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000dd00 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca>:
    dd00:      	stp	x24, x23, [sp, #-0x40]!
    dd04:      	stp	x22, x21, [sp, #0x10]
    dd08:      	stp	x20, x19, [sp, #0x20]
    dd0c:      	stp	x29, x30, [sp, #0x30]
    dd10:      	mov	x20, x1
    dd14:      	mov	x19, x0
    dd18:      	ldp	x23, x22, [x0]
    dd1c:      	cmp	x22, x1
    dd20:      	b.hs	0xdd80 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x80>
    dd24:      	ldr	x21, [x19, #0x10]
    dd28:      	add	x8, x20, x20, lsl #1
    dd2c:      	lsl	x1, x8, #3
    dd30:      	cmp	x22, #0x0
    dd34:      	ccmp	x23, x22, #0x0, ne
    dd38:      	b.eq	0xdd70 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x70>
    dd3c:      	mov	x0, x1
    dd40:      	bl	0xdd40 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x40>
		000000000000dd40:  ARM64_RELOC_BRANCH26	_malloc
    dd44:      	cbz	x0, 0xddc8 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xc8>
    dd48:      	cbz	x22, 0xdd7c <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x7c>
    dd4c:      	add	x8, x23, x23, lsl #1
    dd50:      	lsl	x2, x8, #3
    dd54:      	mov	x22, x0
    dd58:      	mov	x1, x21
    dd5c:      	bl	0xdd5c <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x5c>
		000000000000dd5c:  ARM64_RELOC_BRANCH26	_memcpy
    dd60:      	mov	x0, x21
    dd64:      	bl	0xdd64 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x64>
		000000000000dd64:  ARM64_RELOC_BRANCH26	_free
    dd68:      	mov	x0, x22
    dd6c:      	b	0xdd7c <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x7c>
    dd70:      	mov	x0, x21
    dd74:      	bl	0xdd74 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x74>
		000000000000dd74:  ARM64_RELOC_BRANCH26	_realloc
    dd78:      	cbz	x0, 0xddc8 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xc8>
    dd7c:      	stp	x20, x0, [x19, #0x8]
    dd80:      	cmp	x23, x20
    dd84:      	b.hs	0xddb0 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xb0>
    dd88:      	ldr	x8, [x19, #0x10]
    dd8c:      	mov	w9, #0x18               ; =24
    dd90:      	madd	x8, x23, x9, x8
    dd94:      	add	x8, x8, #0x8
    dd98:      	stur	wzr, [x8, #-0x8]
    dd9c:      	add	x23, x23, #0x1
    dda0:      	stp	xzr, xzr, [x8], #0x18
    dda4:      	cmp	x20, x23
    dda8:      	b.ne	0xdd98 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0x98>
    ddac:      	str	x23, [x19]
    ddb0:      	mov	w0, #0x0                ; =0
    ddb4:      	ldp	x29, x30, [sp, #0x30]
    ddb8:      	ldp	x20, x19, [sp, #0x20]
    ddbc:      	ldp	x22, x21, [sp, #0x10]
    ddc0:      	ldp	x24, x23, [sp], #0x40
    ddc4:      	ret
    ddc8:      	bl	0xddc8 <_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca+0xc8>
		000000000000ddc8:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000ddcc <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6>:
    ddcc:      	sub	sp, sp, #0x60
    ddd0:      	stp	x24, x23, [sp, #0x20]
    ddd4:      	stp	x22, x21, [sp, #0x30]
    ddd8:      	stp	x20, x19, [sp, #0x40]
    dddc:      	stp	x29, x30, [sp, #0x50]
    dde0:      	cmp	x1, #0x3
    dde4:      	b.hi	0xddf4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x28>
    dde8:      	ldr	x20, [x0]
    ddec:      	cmp	x1, x20
    ddf0:      	b.hs	0xde18 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x4c>
    ddf4:      	mov	w0, #0x1                ; =1
    ddf8:      	mov	w1, #0x0                ; =0
    ddfc:      	mov	w2, #0x0                ; =0
    de00:      	ldp	x29, x30, [sp, #0x50]
    de04:      	ldp	x20, x19, [sp, #0x40]
    de08:      	ldp	x22, x21, [sp, #0x30]
    de0c:      	ldp	x24, x23, [sp, #0x20]
    de10:      	add	sp, sp, #0x60
    de14:      	ret
    de18:      	cbz	x1, 0xdeec <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x120>
    de1c:      	mov	x19, x0
    de20:      	ldr	x21, [x2]
    de24:      	ldrb	w22, [x2, #0x8]
    de28:      	mov	x23, x1
    de2c:      	add	x8, x1, x1, lsl #1
    de30:      	lsl	x0, x8, #3
    de34:      	bl	0xde34 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x68>
		000000000000de34:  ARM64_RELOC_BRANCH26	_malloc
    de38:      	cbz	x0, 0xdfdc <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x210>
    de3c:      	mov	x8, #0x0                ; =0
    de40:      	add	x11, x0, #0x8
    de44:      	mov	x9, x19
    de48:      	mov	x10, x23
    de4c:      	stur	wzr, [x11, #-0x8]
    de50:      	add	x8, x8, #0x1
    de54:      	stp	xzr, xzr, [x11], #0x18
    de58:      	cmp	x10, x8
    de5c:      	b.ne	0xde4c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x80>
    de60:      	ldp	x11, x8, [x9, #0x8]
    de64:      	stp	x10, x10, [x9]
    de68:      	str	x0, [x9, #0x10]
    de6c:      	cbz	x20, 0xdfc0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1f4>
    de70:      	mov	w12, #0x18              ; =24
    de74:      	tbz	w22, #0x0, 0xdef4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x128>
    de78:      	add	x13, sp, #0x8
    de7c:      	mov	w14, #0x2               ; =2
    de80:      	b	0xde88 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xbc>
    de84:      	cbz	x20, 0xdfc0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1f4>
    de88:      	sub	x20, x20, #0x1
    de8c:      	madd	x15, x20, x12, x8
    de90:      	ldr	w16, [x15]
    de94:      	cmp	w16, #0x2
    de98:      	b.lo	0xde84 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xb8>
    de9c:      	ldur	q0, [x15, #0x8]
    dea0:      	stur	q0, [sp, #0x10]
    dea4:      	mov	w15, #0x1               ; =1
    dea8:      	b	0xdec8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xfc>
    deac:      	sub	x15, x15, #0x1
    deb0:      	add	x17, x13, x15, lsl #4
    deb4:      	str	x15, [sp, #0x8]
    deb8:      	str	w14, [x16]
    debc:      	ldur	q0, [x17, #0x8]
    dec0:      	stur	q0, [x16, #0x8]
    dec4:      	cbz	x15, 0xde84 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xb8>
    dec8:      	mov	x16, x0
    decc:      	mov	x17, x10
    ded0:      	ldr	w1, [x16]
    ded4:      	cmp	w1, #0x1
    ded8:      	b.ls	0xdeac <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xe0>
    dedc:      	add	x16, x16, #0x18
    dee0:      	subs	x17, x17, #0x1
    dee4:      	b.ne	0xded0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x104>
    dee8:      	b	0xdec4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0xf8>
    deec:      	mov	w0, #0x0                ; =0
    def0:      	b	0xddf8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x2c>
    def4:      	mov	x13, #0xe5b9            ; =58809
    def8:      	movk	x13, #0x1ce4, lsl #16
    defc:      	movk	x13, #0x476d, lsl #32
    df00:      	movk	x13, #0xbf58, lsl #48
    df04:      	mov	x14, #0x11eb            ; =4587
    df08:      	movk	x14, #0x1331, lsl #16
    df0c:      	movk	x14, #0x49bb, lsl #32
    df10:      	movk	x14, #0x94d0, lsl #48
    df14:      	add	x15, sp, #0x8
    df18:      	mov	w16, #0x2               ; =2
    df1c:      	b	0xdf24 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x158>
    df20:      	cbz	x20, 0xdfc0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1f4>
    df24:      	sub	x20, x20, #0x1
    df28:      	madd	x17, x20, x12, x8
    df2c:      	ldr	w1, [x17]
    df30:      	cmp	w1, #0x1
    df34:      	b.ls	0xdf20 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x154>
    df38:      	ldur	q0, [x17, #0x8]
    df3c:      	ldr	x17, [x17, #0x8]
    df40:      	stur	q0, [sp, #0x10]
    df44:      	eor	x17, x17, x21
    df48:      	eor	x17, x17, x17, lsr #30
    df4c:      	mul	x17, x17, x13
    df50:      	eor	x17, x17, x17, lsr #27
    df54:      	mul	x17, x17, x14
    df58:      	eor	x17, x17, x17, lsr #31
    df5c:      	udiv	x1, x17, x10
    df60:      	msub	x17, x1, x10, x17
    df64:      	sub	x1, x10, x17
    df68:      	neg	x2, x1
    df6c:      	mov	w3, #0x1                ; =1
    df70:      	b	0xdf90 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1c4>
    df74:      	sub	x3, x3, #0x1
    df78:      	add	x4, x15, x3, lsl #4
    df7c:      	str	x3, [sp, #0x8]
    df80:      	str	w16, [x5]
    df84:      	ldur	q0, [x4, #0x8]
    df88:      	stur	q0, [x5, #0x8]
    df8c:      	cbz	x3, 0xdf20 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x154>
    df90:      	mov	x4, #0x0                ; =0
    df94:      	cmp	x4, x1
    df98:      	csel	x5, x17, x2, lo
    df9c:      	add	x5, x5, x4
    dfa0:      	madd	x5, x5, x12, x0
    dfa4:      	ldr	w6, [x5]
    dfa8:      	cmp	w6, #0x2
    dfac:      	b.lo	0xdf74 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1a8>
    dfb0:      	add	x4, x4, #0x1
    dfb4:      	cmp	x10, x4
    dfb8:      	b.ne	0xdf94 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1c8>
    dfbc:      	b	0xdf8c <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1c0>
    dfc0:      	cbz	x11, 0xdfd0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x204>
    dfc4:      	mov	x0, x8
    dfc8:      	bl	0xdfc8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x1fc>
		000000000000dfc8:  ARM64_RELOC_BRANCH26	_free
    dfcc:      	mov	x9, x19
    dfd0:      	mov	w0, #0x0                ; =0
    dfd4:      	str	xzr, [x9, #0x20]
    dfd8:      	b	0xddf8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x2c>
    dfdc:      	bl	0xdfdc <_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6+0x210>
		000000000000dfdc:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000dfe0 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6>:
    dfe0:      	ldrb	w8, [x4, #0x8]
    dfe4:      	tbz	w8, #0x0, 0xe070 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0x90>
    dfe8:      	mov	x9, #0x0                ; =0
    dfec:      	ldr	x8, [x1]
    dff0:      	cbz	x8, 0xe0b4 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0xd4>
    dff4:      	udiv	x10, x9, x8
    dff8:      	msub	x10, x10, x8, x9
    dffc:      	ldr	x11, [x1, #0x10]
    e000:      	mov	w12, #0x18              ; =24
    e004:      	mov	x13, x8
    e008:      	mov	x9, x8
    e00c:      	b	0xe02c <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0x4c>
    e010:      	cmp	x9, x8
    e014:      	csel	x9, x10, x9, eq
    e018:      	add	x14, x10, #0x1
    e01c:      	cmp	x14, x8
    e020:      	csinc	x10, xzr, x10, hs
    e024:      	subs	x13, x13, #0x1
    e028:      	b.eq	0xe0b8 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0xd8>
    e02c:      	madd	x14, x10, x12, x11
    e030:      	ldr	w15, [x14]
    e034:      	cmp	w15, #0x1
    e038:      	b.eq	0xe010 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0x30>
    e03c:      	cmp	w15, #0x2
    e040:      	b.ne	0xe114 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0x134>
    e044:      	ldr	x15, [x14, #0x8]
    e048:      	cmp	x15, x2
    e04c:      	b.ne	0xe018 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0x38>
    e050:      	ldr	x8, [x14, #0x10]
    e054:      	mov	w9, #0x2                ; =2
    e058:      	str	w9, [x14]
    e05c:      	str	x3, [x14, #0x10]
    e060:      	mov	w9, #0x1                ; =1
    e064:      	stp	x9, x2, [x0]
    e068:      	str	x8, [x0, #0x10]
    e06c:      	ret
    e070:      	ldr	x8, [x4]
    e074:      	eor	x8, x8, x2
    e078:      	eor	x8, x8, x8, lsr #30
    e07c:      	mov	x9, #0xe5b9             ; =58809
    e080:      	movk	x9, #0x1ce4, lsl #16
    e084:      	movk	x9, #0x476d, lsl #32
    e088:      	movk	x9, #0xbf58, lsl #48
    e08c:      	mul	x8, x8, x9
    e090:      	eor	x8, x8, x8, lsr #27
    e094:      	mov	x9, #0x11eb             ; =4587
    e098:      	movk	x9, #0x1331, lsl #16
    e09c:      	movk	x9, #0x49bb, lsl #32
    e0a0:      	movk	x9, #0x94d0, lsl #48
    e0a4:      	mul	x8, x8, x9
    e0a8:      	eor	x9, x8, x8, lsr #31
    e0ac:      	ldr	x8, [x1]
    e0b0:      	cbnz	x8, 0xdff4 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0x14>
    e0b4:      	mov	x9, #0x0                ; =0
    e0b8:      	cmp	x9, x8
    e0bc:      	b.hs	0xe124 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0x144>
    e0c0:      	ldr	x8, [x1, #0x18]
    e0c4:      	cmp	x8, #0x2
    e0c8:      	b.hi	0xe124 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0x144>
    e0cc:      	add	x8, x8, #0x1
    e0d0:      	str	x8, [x1, #0x18]
    e0d4:      	ldr	x8, [x1, #0x10]
    e0d8:      	mov	w10, #0x18              ; =24
    e0dc:      	madd	x8, x9, x10, x8
    e0e0:      	ldr	w9, [x8]
    e0e4:      	cmp	w9, #0x1
    e0e8:      	b.ne	0xe13c <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0x15c>
    e0ec:      	ldr	x9, [x1, #0x20]
    e0f0:      	subs	x9, x9, #0x1
    e0f4:      	csel	x9, xzr, x9, lo
    e0f8:      	str	x9, [x1, #0x20]
    e0fc:      	mov	w9, #0x2                ; =2
    e100:      	str	w9, [x8]
    e104:      	stp	x2, x3, [x8, #0x8]
    e108:      	stp	xzr, xzr, [x0, #0x8]
    e10c:      	str	xzr, [x0]
    e110:      	ret
    e114:      	cmp	x9, x8
    e118:      	csel	x9, x10, x9, eq
    e11c:      	cmp	x9, x8
    e120:      	b.lo	0xe0c0 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0xe0>
    e124:      	stp	xzr, x2, [x0]
    e128:      	mov	w8, #0x1                ; =1
    e12c:      	str	w8, [x0]
    e130:      	strb	w8, [x0, #0x4]
    e134:      	str	x3, [x0, #0x10]
    e138:      	ret
    e13c:      	ldur	q0, [x8, #0x8]
    e140:      	mov	w10, #0x2               ; =2
    e144:      	str	w10, [x8]
    e148:      	stp	x2, x3, [x8, #0x8]
    e14c:      	cbz	w9, 0xe160 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0x180>
    e150:      	mov	w8, #0x1                ; =1
    e154:      	str	x8, [x0]
    e158:      	stur	q0, [x0, #0x8]
    e15c:      	ret
    e160:      	stp	xzr, xzr, [x0]
    e164:      	str	xzr, [x0, #0x10]
    e168:      	ret

000000000000e16c <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd>:
    e16c:      	stp	x24, x23, [sp, #-0x40]!
    e170:      	stp	x22, x21, [sp, #0x10]
    e174:      	stp	x20, x19, [sp, #0x20]
    e178:      	stp	x29, x30, [sp, #0x30]
    e17c:      	mov	x20, x1
    e180:      	mov	x19, x0
    e184:      	ldp	x23, x22, [x0]
    e188:      	cmp	x22, x1
    e18c:      	b.hs	0xe1ec <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x80>
    e190:      	ldr	x21, [x19, #0x10]
    e194:      	add	x8, x20, x20, lsl #1
    e198:      	lsl	x1, x8, #3
    e19c:      	cmp	x22, #0x0
    e1a0:      	ccmp	x23, x22, #0x0, ne
    e1a4:      	b.eq	0xe1dc <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x70>
    e1a8:      	mov	x0, x1
    e1ac:      	bl	0xe1ac <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x40>
		000000000000e1ac:  ARM64_RELOC_BRANCH26	_malloc
    e1b0:      	cbz	x0, 0xe234 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xc8>
    e1b4:      	cbz	x22, 0xe1e8 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x7c>
    e1b8:      	add	x8, x23, x23, lsl #1
    e1bc:      	lsl	x2, x8, #3
    e1c0:      	mov	x22, x0
    e1c4:      	mov	x1, x21
    e1c8:      	bl	0xe1c8 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x5c>
		000000000000e1c8:  ARM64_RELOC_BRANCH26	_memcpy
    e1cc:      	mov	x0, x21
    e1d0:      	bl	0xe1d0 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x64>
		000000000000e1d0:  ARM64_RELOC_BRANCH26	_free
    e1d4:      	mov	x0, x22
    e1d8:      	b	0xe1e8 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x7c>
    e1dc:      	mov	x0, x21
    e1e0:      	bl	0xe1e0 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x74>
		000000000000e1e0:  ARM64_RELOC_BRANCH26	_realloc
    e1e4:      	cbz	x0, 0xe234 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xc8>
    e1e8:      	stp	x20, x0, [x19, #0x8]
    e1ec:      	cmp	x23, x20
    e1f0:      	b.hs	0xe21c <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xb0>
    e1f4:      	ldr	x8, [x19, #0x10]
    e1f8:      	mov	w9, #0x18               ; =24
    e1fc:      	madd	x8, x23, x9, x8
    e200:      	add	x8, x8, #0x8
    e204:      	stur	wzr, [x8, #-0x8]
    e208:      	add	x23, x23, #0x1
    e20c:      	stp	xzr, xzr, [x8], #0x18
    e210:      	cmp	x20, x23
    e214:      	b.ne	0xe204 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0x98>
    e218:      	str	x23, [x19]
    e21c:      	mov	w0, #0x0                ; =0
    e220:      	ldp	x29, x30, [sp, #0x30]
    e224:      	ldp	x20, x19, [sp, #0x20]
    e228:      	ldp	x22, x21, [sp, #0x10]
    e22c:      	ldp	x24, x23, [sp], #0x40
    e230:      	ret
    e234:      	bl	0xe234 <_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd+0xc8>
		000000000000e234:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000e238 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad>:
    e238:      	sub	sp, sp, #0x60
    e23c:      	stp	x24, x23, [sp, #0x20]
    e240:      	stp	x22, x21, [sp, #0x30]
    e244:      	stp	x20, x19, [sp, #0x40]
    e248:      	stp	x29, x30, [sp, #0x50]
    e24c:      	cmp	x1, #0x4, lsl #12       ; =0x4000
    e250:      	b.hi	0xe260 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x28>
    e254:      	ldr	x20, [x0]
    e258:      	cmp	x1, x20
    e25c:      	b.hs	0xe284 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x4c>
    e260:      	mov	w0, #0x1                ; =1
    e264:      	mov	w1, #0x0                ; =0
    e268:      	mov	w2, #0x0                ; =0
    e26c:      	ldp	x29, x30, [sp, #0x50]
    e270:      	ldp	x20, x19, [sp, #0x40]
    e274:      	ldp	x22, x21, [sp, #0x30]
    e278:      	ldp	x24, x23, [sp, #0x20]
    e27c:      	add	sp, sp, #0x60
    e280:      	ret
    e284:      	cbz	x1, 0xe358 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x120>
    e288:      	mov	x19, x0
    e28c:      	ldr	x21, [x2]
    e290:      	ldrb	w22, [x2, #0x8]
    e294:      	mov	x23, x1
    e298:      	add	x8, x1, x1, lsl #1
    e29c:      	lsl	x0, x8, #3
    e2a0:      	bl	0xe2a0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x68>
		000000000000e2a0:  ARM64_RELOC_BRANCH26	_malloc
    e2a4:      	cbz	x0, 0xe448 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x210>
    e2a8:      	mov	x8, #0x0                ; =0
    e2ac:      	add	x11, x0, #0x8
    e2b0:      	mov	x9, x19
    e2b4:      	mov	x10, x23
    e2b8:      	stur	wzr, [x11, #-0x8]
    e2bc:      	add	x8, x8, #0x1
    e2c0:      	stp	xzr, xzr, [x11], #0x18
    e2c4:      	cmp	x10, x8
    e2c8:      	b.ne	0xe2b8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x80>
    e2cc:      	ldp	x11, x8, [x9, #0x8]
    e2d0:      	stp	x10, x10, [x9]
    e2d4:      	str	x0, [x9, #0x10]
    e2d8:      	cbz	x20, 0xe42c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1f4>
    e2dc:      	mov	w12, #0x18              ; =24
    e2e0:      	tbz	w22, #0x0, 0xe360 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x128>
    e2e4:      	add	x13, sp, #0x8
    e2e8:      	mov	w14, #0x2               ; =2
    e2ec:      	b	0xe2f4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xbc>
    e2f0:      	cbz	x20, 0xe42c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1f4>
    e2f4:      	sub	x20, x20, #0x1
    e2f8:      	madd	x15, x20, x12, x8
    e2fc:      	ldr	w16, [x15]
    e300:      	cmp	w16, #0x2
    e304:      	b.lo	0xe2f0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xb8>
    e308:      	ldur	q0, [x15, #0x8]
    e30c:      	stur	q0, [sp, #0x10]
    e310:      	mov	w15, #0x1               ; =1
    e314:      	b	0xe334 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xfc>
    e318:      	sub	x15, x15, #0x1
    e31c:      	add	x17, x13, x15, lsl #4
    e320:      	str	x15, [sp, #0x8]
    e324:      	str	w14, [x16]
    e328:      	ldur	q0, [x17, #0x8]
    e32c:      	stur	q0, [x16, #0x8]
    e330:      	cbz	x15, 0xe2f0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xb8>
    e334:      	mov	x16, x0
    e338:      	mov	x17, x10
    e33c:      	ldr	w1, [x16]
    e340:      	cmp	w1, #0x1
    e344:      	b.ls	0xe318 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xe0>
    e348:      	add	x16, x16, #0x18
    e34c:      	subs	x17, x17, #0x1
    e350:      	b.ne	0xe33c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x104>
    e354:      	b	0xe330 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0xf8>
    e358:      	mov	w0, #0x0                ; =0
    e35c:      	b	0xe264 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x2c>
    e360:      	mov	x13, #0xe5b9            ; =58809
    e364:      	movk	x13, #0x1ce4, lsl #16
    e368:      	movk	x13, #0x476d, lsl #32
    e36c:      	movk	x13, #0xbf58, lsl #48
    e370:      	mov	x14, #0x11eb            ; =4587
    e374:      	movk	x14, #0x1331, lsl #16
    e378:      	movk	x14, #0x49bb, lsl #32
    e37c:      	movk	x14, #0x94d0, lsl #48
    e380:      	add	x15, sp, #0x8
    e384:      	mov	w16, #0x2               ; =2
    e388:      	b	0xe390 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x158>
    e38c:      	cbz	x20, 0xe42c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1f4>
    e390:      	sub	x20, x20, #0x1
    e394:      	madd	x17, x20, x12, x8
    e398:      	ldr	w1, [x17]
    e39c:      	cmp	w1, #0x1
    e3a0:      	b.ls	0xe38c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x154>
    e3a4:      	ldur	q0, [x17, #0x8]
    e3a8:      	ldr	x17, [x17, #0x8]
    e3ac:      	stur	q0, [sp, #0x10]
    e3b0:      	eor	x17, x17, x21
    e3b4:      	eor	x17, x17, x17, lsr #30
    e3b8:      	mul	x17, x17, x13
    e3bc:      	eor	x17, x17, x17, lsr #27
    e3c0:      	mul	x17, x17, x14
    e3c4:      	eor	x17, x17, x17, lsr #31
    e3c8:      	udiv	x1, x17, x10
    e3cc:      	msub	x17, x1, x10, x17
    e3d0:      	sub	x1, x10, x17
    e3d4:      	neg	x2, x1
    e3d8:      	mov	w3, #0x1                ; =1
    e3dc:      	b	0xe3fc <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1c4>
    e3e0:      	sub	x3, x3, #0x1
    e3e4:      	add	x4, x15, x3, lsl #4
    e3e8:      	str	x3, [sp, #0x8]
    e3ec:      	str	w16, [x5]
    e3f0:      	ldur	q0, [x4, #0x8]
    e3f4:      	stur	q0, [x5, #0x8]
    e3f8:      	cbz	x3, 0xe38c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x154>
    e3fc:      	mov	x4, #0x0                ; =0
    e400:      	cmp	x4, x1
    e404:      	csel	x5, x17, x2, lo
    e408:      	add	x5, x5, x4
    e40c:      	madd	x5, x5, x12, x0
    e410:      	ldr	w6, [x5]
    e414:      	cmp	w6, #0x2
    e418:      	b.lo	0xe3e0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1a8>
    e41c:      	add	x4, x4, #0x1
    e420:      	cmp	x10, x4
    e424:      	b.ne	0xe400 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1c8>
    e428:      	b	0xe3f8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1c0>
    e42c:      	cbz	x11, 0xe43c <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x204>
    e430:      	mov	x0, x8
    e434:      	bl	0xe434 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x1fc>
		000000000000e434:  ARM64_RELOC_BRANCH26	_free
    e438:      	mov	x9, x19
    e43c:      	mov	w0, #0x0                ; =0
    e440:      	str	xzr, [x9, #0x20]
    e444:      	b	0xe264 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x2c>
    e448:      	bl	0xe448 <_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad+0x210>
		000000000000e448:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000e44c <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad>:
    e44c:      	ldrb	w8, [x4, #0x8]
    e450:      	tbz	w8, #0x0, 0xe4dc <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0x90>
    e454:      	mov	x9, #0x0                ; =0
    e458:      	ldr	x8, [x1]
    e45c:      	cbz	x8, 0xe520 <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0xd4>
    e460:      	udiv	x10, x9, x8
    e464:      	msub	x10, x10, x8, x9
    e468:      	ldr	x11, [x1, #0x10]
    e46c:      	mov	w12, #0x18              ; =24
    e470:      	mov	x13, x8
    e474:      	mov	x9, x8
    e478:      	b	0xe498 <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0x4c>
    e47c:      	cmp	x9, x8
    e480:      	csel	x9, x10, x9, eq
    e484:      	add	x14, x10, #0x1
    e488:      	cmp	x14, x8
    e48c:      	csinc	x10, xzr, x10, hs
    e490:      	subs	x13, x13, #0x1
    e494:      	b.eq	0xe524 <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0xd8>
    e498:      	madd	x14, x10, x12, x11
    e49c:      	ldr	w15, [x14]
    e4a0:      	cmp	w15, #0x1
    e4a4:      	b.eq	0xe47c <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0x30>
    e4a8:      	cmp	w15, #0x2
    e4ac:      	b.ne	0xe580 <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0x134>
    e4b0:      	ldr	x15, [x14, #0x8]
    e4b4:      	cmp	x15, x2
    e4b8:      	b.ne	0xe484 <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0x38>
    e4bc:      	ldr	x8, [x14, #0x10]
    e4c0:      	mov	w9, #0x2                ; =2
    e4c4:      	str	w9, [x14]
    e4c8:      	str	x3, [x14, #0x10]
    e4cc:      	mov	w9, #0x1                ; =1
    e4d0:      	stp	x9, x2, [x0]
    e4d4:      	str	x8, [x0, #0x10]
    e4d8:      	ret
    e4dc:      	ldr	x8, [x4]
    e4e0:      	eor	x8, x8, x2
    e4e4:      	eor	x8, x8, x8, lsr #30
    e4e8:      	mov	x9, #0xe5b9             ; =58809
    e4ec:      	movk	x9, #0x1ce4, lsl #16
    e4f0:      	movk	x9, #0x476d, lsl #32
    e4f4:      	movk	x9, #0xbf58, lsl #48
    e4f8:      	mul	x8, x8, x9
    e4fc:      	eor	x8, x8, x8, lsr #27
    e500:      	mov	x9, #0x11eb             ; =4587
    e504:      	movk	x9, #0x1331, lsl #16
    e508:      	movk	x9, #0x49bb, lsl #32
    e50c:      	movk	x9, #0x94d0, lsl #48
    e510:      	mul	x8, x8, x9
    e514:      	eor	x9, x8, x8, lsr #31
    e518:      	ldr	x8, [x1]
    e51c:      	cbnz	x8, 0xe460 <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0x14>
    e520:      	mov	x9, #0x0                ; =0
    e524:      	cmp	x9, x8
    e528:      	b.hs	0xe590 <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0x144>
    e52c:      	ldr	x8, [x1, #0x18]
    e530:      	lsr	x10, x8, #14
    e534:      	cbnz	x10, 0xe590 <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0x144>
    e538:      	add	x8, x8, #0x1
    e53c:      	str	x8, [x1, #0x18]
    e540:      	ldr	x8, [x1, #0x10]
    e544:      	mov	w10, #0x18              ; =24
    e548:      	madd	x8, x9, x10, x8
    e54c:      	ldr	w9, [x8]
    e550:      	cmp	w9, #0x1
    e554:      	b.ne	0xe5a8 <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0x15c>
    e558:      	ldr	x9, [x1, #0x20]
    e55c:      	subs	x9, x9, #0x1
    e560:      	csel	x9, xzr, x9, lo
    e564:      	str	x9, [x1, #0x20]
    e568:      	mov	w9, #0x2                ; =2
    e56c:      	str	w9, [x8]
    e570:      	stp	x2, x3, [x8, #0x8]
    e574:      	stp	xzr, xzr, [x0, #0x8]
    e578:      	str	xzr, [x0]
    e57c:      	ret
    e580:      	cmp	x9, x8
    e584:      	csel	x9, x10, x9, eq
    e588:      	cmp	x9, x8
    e58c:      	b.lo	0xe52c <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0xe0>
    e590:      	stp	xzr, x2, [x0]
    e594:      	mov	w8, #0x1                ; =1
    e598:      	str	w8, [x0]
    e59c:      	strb	w8, [x0, #0x4]
    e5a0:      	str	x3, [x0, #0x10]
    e5a4:      	ret
    e5a8:      	ldur	q0, [x8, #0x8]
    e5ac:      	mov	w10, #0x2               ; =2
    e5b0:      	str	w10, [x8]
    e5b4:      	stp	x2, x3, [x8, #0x8]
    e5b8:      	cbz	w9, 0xe5cc <_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad+0x180>
    e5bc:      	mov	w8, #0x1                ; =1
    e5c0:      	str	x8, [x0]
    e5c4:      	stur	q0, [x0, #0x8]
    e5c8:      	ret
    e5cc:      	stp	xzr, xzr, [x0]
    e5d0:      	str	xzr, [x0, #0x10]
    e5d4:      	ret

000000000000e5d8 <_wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad>:
    e5d8:      	ldrb	w8, [x2, #0x8]
    e5dc:      	tbz	w8, #0x0, 0xe5f0 <_wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad+0x18>
    e5e0:      	mov	x8, #0x0                ; =0
    e5e4:      	ldr	x9, [x0]
    e5e8:      	cbnz	x9, 0xe638 <_wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad+0x60>
    e5ec:      	b	0xe69c <_wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad+0xc4>
    e5f0:      	ldr	x8, [x2]
    e5f4:      	ldr	x9, [x1]
    e5f8:      	eor	x8, x9, x8
    e5fc:      	eor	x8, x8, x8, lsr #30
    e600:      	mov	x9, #0xe5b9             ; =58809
    e604:      	movk	x9, #0x1ce4, lsl #16
    e608:      	movk	x9, #0x476d, lsl #32
    e60c:      	movk	x9, #0xbf58, lsl #48
    e610:      	mul	x8, x8, x9
    e614:      	eor	x8, x8, x8, lsr #27
    e618:      	mov	x9, #0x11eb             ; =4587
    e61c:      	movk	x9, #0x1331, lsl #16
    e620:      	movk	x9, #0x49bb, lsl #32
    e624:      	movk	x9, #0x94d0, lsl #48
    e628:      	mul	x8, x8, x9
    e62c:      	eor	x8, x8, x8, lsr #31
    e630:      	ldr	x9, [x0]
    e634:      	cbz	x9, 0xe69c <_wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad+0xc4>
    e638:      	udiv	x10, x8, x9
    e63c:      	msub	x8, x10, x9, x8
    e640:      	ldr	x10, [x0, #0x10]
    e644:      	mov	w11, #0x18              ; =24
    e648:      	mov	x12, x9
    e64c:      	b	0xe664 <_wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad+0x8c>
    e650:      	add	x13, x8, #0x1
    e654:      	cmp	x13, x9
    e658:      	csinc	x8, xzr, x8, hs
    e65c:      	subs	x12, x12, #0x1
    e660:      	b.eq	0xe69c <_wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad+0xc4>
    e664:      	madd	x14, x8, x11, x10
    e668:      	ldr	w13, [x14]
    e66c:      	cmp	w13, #0x1
    e670:      	b.eq	0xe650 <_wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad+0x78>
    e674:      	cmp	w13, #0x2
    e678:      	b.ne	0xe6b0 <_wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad+0xd8>
    e67c:      	ldr	x13, [x14, #0x8]
    e680:      	ldr	x14, [x1]
    e684:      	cmp	x13, x14
    e688:      	b.ne	0xe650 <_wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad+0x78>
    e68c:      	mov	w0, #0x0                ; =0
    e690:      	mov	x1, x8
    e694:      	mov	w2, #0x0                ; =0
    e698:      	ret
    e69c:      	mov	x8, #0x0                ; =0
    e6a0:      	mov	w0, #0x1                ; =1
    e6a4:      	mov	x1, x8
    e6a8:      	mov	w2, #0x0                ; =0
    e6ac:      	ret
    e6b0:      	mov	w0, #0x1                ; =1
    e6b4:      	mov	x8, x13
    e6b8:      	mov	x1, x8
    e6bc:      	mov	w2, #0x0                ; =0
    e6c0:      	ret

000000000000e6c4 <_wf_box_slots_new$instance$9eabc50a9cce2251>:
    e6c4:      	stp	x20, x19, [sp, #-0x20]!
    e6c8:      	stp	x29, x30, [sp, #0x10]
    e6cc:      	mov	x19, x0
    e6d0:      	cbz	x0, 0xe6fc <_wf_box_slots_new$instance$9eabc50a9cce2251+0x38>
    e6d4:      	add	x8, x19, x19, lsl #4
    e6d8:      	lsl	x0, x8, #4
    e6dc:      	bl	0xe6dc <_wf_box_slots_new$instance$9eabc50a9cce2251+0x18>
		000000000000e6dc:  ARM64_RELOC_BRANCH26	_malloc
    e6e0:      	mov	x2, x0
    e6e4:      	cbz	x0, 0xe718 <_wf_box_slots_new$instance$9eabc50a9cce2251+0x54>
    e6e8:      	mov	x0, #0x0                ; =0
    e6ec:      	mov	x1, x19
    e6f0:      	ldp	x29, x30, [sp, #0x10]
    e6f4:      	ldp	x20, x19, [sp], #0x20
    e6f8:      	ret
    e6fc:      	adrp	x2, 0xe000 <_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6+0x20>
		000000000000e6fc:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    e700:      	add	x2, x2, #0x0
		000000000000e700:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    e704:      	mov	x0, #0x0                ; =0
    e708:      	mov	x1, x19
    e70c:      	ldp	x29, x30, [sp, #0x10]
    e710:      	ldp	x20, x19, [sp], #0x20
    e714:      	ret
    e718:      	bl	0xe718 <_wf_box_slots_new$instance$9eabc50a9cce2251+0x54>
		000000000000e718:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000e71c <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743>:
    e71c:      	stp	x24, x23, [sp, #-0x40]!
    e720:      	stp	x22, x21, [sp, #0x10]
    e724:      	stp	x20, x19, [sp, #0x20]
    e728:      	stp	x29, x30, [sp, #0x30]
    e72c:      	mov	x20, x1
    e730:      	mov	x19, x0
    e734:      	ldp	x23, x22, [x0]
    e738:      	cmp	x22, x1
    e73c:      	b.hs	0xe79c <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x80>
    e740:      	ldr	x21, [x19, #0x10]
    e744:      	add	x8, x20, x20, lsl #4
    e748:      	lsl	x1, x8, #4
    e74c:      	cmp	x22, #0x0
    e750:      	ccmp	x23, x22, #0x0, ne
    e754:      	b.eq	0xe78c <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x70>
    e758:      	mov	x0, x1
    e75c:      	bl	0xe75c <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x40>
		000000000000e75c:  ARM64_RELOC_BRANCH26	_malloc
    e760:      	cbz	x0, 0xe80c <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xf0>
    e764:      	cbz	x22, 0xe798 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x7c>
    e768:      	add	x8, x23, x23, lsl #4
    e76c:      	lsl	x2, x8, #4
    e770:      	mov	x22, x0
    e774:      	mov	x1, x21
    e778:      	bl	0xe778 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x5c>
		000000000000e778:  ARM64_RELOC_BRANCH26	_memcpy
    e77c:      	mov	x0, x21
    e780:      	bl	0xe780 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x64>
		000000000000e780:  ARM64_RELOC_BRANCH26	_free
    e784:      	mov	x0, x22
    e788:      	b	0xe798 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x7c>
    e78c:      	mov	x0, x21
    e790:      	bl	0xe790 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x74>
		000000000000e790:  ARM64_RELOC_BRANCH26	_realloc
    e794:      	cbz	x0, 0xe80c <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xf0>
    e798:      	stp	x20, x0, [x19, #0x8]
    e79c:      	cmp	x23, x20
    e7a0:      	b.hs	0xe7f4 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xd8>
    e7a4:      	ldr	x8, [x19, #0x10]
    e7a8:      	mov	w9, #0x110              ; =272
    e7ac:      	madd	x8, x23, x9, x8
    e7b0:      	add	x8, x8, #0x8
    e7b4:      	movi.2d	v0, #0000000000000000
    e7b8:      	stur	wzr, [x8, #-0x8]
    e7bc:      	add	x23, x23, #0x1
    e7c0:      	stp	q0, q0, [x8]
    e7c4:      	stp	q0, q0, [x8, #0x20]
    e7c8:      	stp	q0, q0, [x8, #0x40]
    e7cc:      	stp	q0, q0, [x8, #0x60]
    e7d0:      	stp	q0, q0, [x8, #0x80]
    e7d4:      	stp	q0, q0, [x8, #0xa0]
    e7d8:      	stp	q0, q0, [x8, #0xc0]
    e7dc:      	stp	q0, q0, [x8, #0xe0]
    e7e0:      	str	xzr, [x8, #0x100]
    e7e4:      	add	x8, x8, #0x110
    e7e8:      	cmp	x20, x23
    e7ec:      	b.ne	0xe7b8 <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0x9c>
    e7f0:      	str	x23, [x19]
    e7f4:      	mov	w0, #0x0                ; =0
    e7f8:      	ldp	x29, x30, [sp, #0x30]
    e7fc:      	ldp	x20, x19, [sp, #0x20]
    e800:      	ldp	x22, x21, [sp, #0x10]
    e804:      	ldp	x24, x23, [sp], #0x40
    e808:      	ret
    e80c:      	bl	0xe80c <_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743+0xf0>
		000000000000e80c:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000e810 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07>:
    e810:      	stp	x28, x27, [sp, #-0x60]!
    e814:      	stp	x26, x25, [sp, #0x10]
    e818:      	stp	x24, x23, [sp, #0x20]
    e81c:      	stp	x22, x21, [sp, #0x30]
    e820:      	stp	x20, x19, [sp, #0x40]
    e824:      	stp	x29, x30, [sp, #0x50]
    e828:      	sub	sp, sp, #0x250
    e82c:      	cmp	x1, #0x3
    e830:      	b.hi	0xe848 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x38>
    e834:      	mov	x20, x1
    e838:      	mov	x19, x0
    e83c:      	ldr	x22, [x0]
    e840:      	cmp	x1, x22
    e844:      	b.hs	0xe874 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x64>
    e848:      	mov	w0, #0x1                ; =1
    e84c:      	mov	w1, #0x0                ; =0
    e850:      	mov	w2, #0x0                ; =0
    e854:      	add	sp, sp, #0x250
    e858:      	ldp	x29, x30, [sp, #0x50]
    e85c:      	ldp	x20, x19, [sp, #0x40]
    e860:      	ldp	x22, x21, [sp, #0x30]
    e864:      	ldp	x24, x23, [sp, #0x20]
    e868:      	ldp	x26, x25, [sp, #0x10]
    e86c:      	ldp	x28, x27, [sp], #0x60
    e870:      	ret
    e874:      	cbz	x20, 0xeb38 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x328>
    e878:      	ldr	x25, [x2]
    e87c:      	ldrb	w8, [x2, #0x8]
    e880:      	str	w8, [sp, #0x1c]
    e884:      	add	x8, x20, x20, lsl #4
    e888:      	lsl	x0, x8, #4
    e88c:      	bl	0xe88c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x7c>
		000000000000e88c:  ARM64_RELOC_BRANCH26	_malloc
    e890:      	cbz	x0, 0xeb40 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x330>
    e894:      	mov	x21, x0
    e898:      	mov	x8, #0x0                ; =0
    e89c:      	add	x9, x0, #0x8
    e8a0:      	movi.2d	v0, #0000000000000000
    e8a4:      	stur	wzr, [x9, #-0x8]
    e8a8:      	add	x8, x8, #0x1
    e8ac:      	stp	q0, q0, [x9]
    e8b0:      	stp	q0, q0, [x9, #0x20]
    e8b4:      	stp	q0, q0, [x9, #0x40]
    e8b8:      	stp	q0, q0, [x9, #0x60]
    e8bc:      	stp	q0, q0, [x9, #0x80]
    e8c0:      	stp	q0, q0, [x9, #0xa0]
    e8c4:      	stp	q0, q0, [x9, #0xc0]
    e8c8:      	stp	q0, q0, [x9, #0xe0]
    e8cc:      	str	xzr, [x9, #0x100]
    e8d0:      	add	x9, x9, #0x110
    e8d4:      	cmp	x20, x8
    e8d8:      	b.ne	0xe8a4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x94>
    e8dc:      	ldp	x9, x8, [x19, #0x8]
    e8e0:      	str	x9, [sp, #0x10]
    e8e4:      	str	x8, [sp, #0x20]
    e8e8:      	stp	x20, x20, [x19]
    e8ec:      	str	x21, [x19, #0x10]
    e8f0:      	cbz	x22, 0xeb1c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x30c>
    e8f4:      	mov	w26, #0x110             ; =272
    e8f8:      	add	x27, sp, #0x30
    e8fc:      	mov	x24, #0x11eb            ; =4587
    e900:      	movk	x24, #0x1331, lsl #16
    e904:      	movk	x24, #0x49bb, lsl #32
    e908:      	movk	x24, #0x94d0, lsl #48
    e90c:      	b	0xe918 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x108>
    e910:      	ldr	x22, [sp, #0x28]
    e914:      	cbz	x22, 0xeb1c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x30c>
    e918:      	sub	x22, x22, #0x1
    e91c:      	str	x22, [sp, #0x28]
    e920:      	ldr	x8, [sp, #0x20]
    e924:      	madd	x8, x22, x26, x8
    e928:      	ldr	w9, [x8]
    e92c:      	cmp	w9, #0x1
    e930:      	b.ls	0xe910 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x100>
    e934:      	ldr	x9, [x8, #0x108]
    e938:      	ldur	q0, [x8, #0x8]
    e93c:      	stur	q0, [sp, #0x38]
    e940:      	ldur	q0, [x8, #0x18]
    e944:      	stur	q0, [sp, #0x48]
    e948:      	ldur	q0, [x8, #0x28]
    e94c:      	stur	q0, [sp, #0x58]
    e950:      	ldur	q0, [x8, #0x38]
    e954:      	stur	q0, [sp, #0x68]
    e958:      	ldur	q0, [x8, #0x48]
    e95c:      	stur	q0, [sp, #0x78]
    e960:      	ldur	q0, [x8, #0x58]
    e964:      	stur	q0, [sp, #0x88]
    e968:      	ldur	q0, [x8, #0x68]
    e96c:      	stur	q0, [sp, #0x98]
    e970:      	ldur	q0, [x8, #0x78]
    e974:      	stur	q0, [sp, #0xa8]
    e978:      	ldur	q0, [x8, #0x88]
    e97c:      	add	x10, sp, #0x30
    e980:      	stur	q0, [x10, #0x88]
    e984:      	ldur	q0, [x8, #0x98]
    e988:      	stur	q0, [x10, #0x98]
    e98c:      	ldur	q0, [x8, #0xa8]
    e990:      	stur	q0, [x10, #0xa8]
    e994:      	ldur	q0, [x8, #0xb8]
    e998:      	stur	q0, [x10, #0xb8]
    e99c:      	ldur	q0, [x8, #0xc8]
    e9a0:      	stur	q0, [x10, #0xc8]
    e9a4:      	ldur	q0, [x8, #0xd8]
    e9a8:      	stur	q0, [x10, #0xd8]
    e9ac:      	ldur	q0, [x8, #0xe8]
    e9b0:      	stur	q0, [x10, #0xe8]
    e9b4:      	ldur	q0, [x8, #0xf8]
    e9b8:      	stur	q0, [x10, #0xf8]
    e9bc:      	str	x9, [sp, #0x138]
    e9c0:      	mov	w8, #0x1                ; =1
    e9c4:      	str	x8, [sp, #0x30]
    e9c8:      	ldr	w8, [sp, #0x1c]
    e9cc:      	tbz	w8, #0x0, 0xea54 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x244>
    e9d0:      	mov	w28, #0x1               ; =1
    e9d4:      	b	0xea20 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x210>
    e9d8:      	sub	x22, x28, #0x1
    e9dc:      	str	x22, [sp, #0x30]
    e9e0:      	mov	w8, #0x108              ; =264
    e9e4:      	madd	x23, x28, x8, x27
    e9e8:      	ldr	x3, [x23, #-0x100]!
    e9ec:      	add	x0, sp, #0x140
    e9f0:      	add	x4, x23, #0x8
    e9f4:      	mov	x1, x19
    e9f8:      	bl	0xe9f8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x1e8>
		000000000000e9f8:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    e9fc:      	ldr	w8, [sp, #0x140]
    ea00:      	cbz	w8, 0xea48 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x238>
    ea04:      	add	x8, sp, #0x140
    ea08:      	add	x1, x8, #0x8
    ea0c:      	mov	x0, x23
    ea10:      	mov	w2, #0x108              ; =264
    ea14:      	bl	0xea14 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x204>
		000000000000ea14:  ARM64_RELOC_BRANCH26	_memcpy
    ea18:      	str	x28, [sp, #0x30]
    ea1c:      	cbz	x28, 0xe910 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x100>
    ea20:      	mov	x2, #0x0                ; =0
    ea24:      	mov	x8, x21
    ea28:      	ldr	w9, [x8]
    ea2c:      	cmp	w9, #0x2
    ea30:      	b.lo	0xe9d8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x1c8>
    ea34:      	add	x8, x8, #0x110
    ea38:      	add	x2, x2, #0x1
    ea3c:      	cmp	x20, x2
    ea40:      	b.ne	0xea28 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x218>
    ea44:      	b	0xea1c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x20c>
    ea48:      	mov	x28, x22
    ea4c:      	cbnz	x22, 0xea20 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x210>
    ea50:      	b	0xe910 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x100>
    ea54:      	mov	w22, #0x1               ; =1
    ea58:      	b	0xeaa4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x294>
    ea5c:      	sub	x28, x22, #0x1
    ea60:      	str	x28, [sp, #0x30]
    ea64:      	mov	w8, #0x108              ; =264
    ea68:      	madd	x23, x22, x8, x27
    ea6c:      	ldr	x3, [x23, #-0x100]!
    ea70:      	add	x0, sp, #0x140
    ea74:      	add	x4, x23, #0x8
    ea78:      	mov	x1, x19
    ea7c:      	bl	0xea7c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x26c>
		000000000000ea7c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    ea80:      	ldr	w8, [sp, #0x140]
    ea84:      	cbz	w8, 0xeb10 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x300>
    ea88:      	add	x8, sp, #0x140
    ea8c:      	add	x1, x8, #0x8
    ea90:      	mov	x0, x23
    ea94:      	mov	w2, #0x108              ; =264
    ea98:      	bl	0xea98 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x288>
		000000000000ea98:  ARM64_RELOC_BRANCH26	_memcpy
    ea9c:      	str	x22, [sp, #0x30]
    eaa0:      	cbz	x22, 0xe910 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x100>
    eaa4:      	mov	x8, #0x0                ; =0
    eaa8:      	ldr	x9, [sp, #0x38]
    eaac:      	eor	x9, x9, x25
    eab0:      	eor	x9, x9, x9, lsr #30
    eab4:      	mov	x10, #0xe5b9            ; =58809
    eab8:      	movk	x10, #0x1ce4, lsl #16
    eabc:      	movk	x10, #0x476d, lsl #32
    eac0:      	movk	x10, #0xbf58, lsl #48
    eac4:      	mul	x9, x9, x10
    eac8:      	eor	x9, x9, x9, lsr #27
    eacc:      	mul	x9, x9, x24
    ead0:      	eor	x9, x9, x9, lsr #31
    ead4:      	udiv	x10, x9, x20
    ead8:      	msub	x9, x10, x20, x9
    eadc:      	sub	x10, x20, x9
    eae0:      	neg	x11, x10
    eae4:      	cmp	x8, x10
    eae8:      	csel	x12, x9, x11, lo
    eaec:      	add	x2, x12, x8
    eaf0:      	mul	x12, x2, x26
    eaf4:      	ldr	w12, [x21, x12]
    eaf8:      	cmp	w12, #0x2
    eafc:      	b.lo	0xea5c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x24c>
    eb00:      	add	x8, x8, #0x1
    eb04:      	cmp	x20, x8
    eb08:      	b.ne	0xeae4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x2d4>
    eb0c:      	b	0xeaa0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x290>
    eb10:      	mov	x22, x28
    eb14:      	cbnz	x28, 0xeaa4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x294>
    eb18:      	b	0xe910 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x100>
    eb1c:      	ldr	x8, [sp, #0x10]
    eb20:      	cbz	x8, 0xeb2c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x31c>
    eb24:      	ldr	x0, [sp, #0x20]
    eb28:      	bl	0xeb28 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x318>
		000000000000eb28:  ARM64_RELOC_BRANCH26	_free
    eb2c:      	mov	w0, #0x0                ; =0
    eb30:      	str	xzr, [x19, #0x20]
    eb34:      	b	0xe84c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x3c>
    eb38:      	mov	w0, #0x0                ; =0
    eb3c:      	b	0xe84c <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x3c>
    eb40:      	bl	0xeb40 <_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07+0x330>
		000000000000eb40:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000eb44 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07>:
    eb44:      	mov	x9, x3
    eb48:      	mov	x3, x2
    eb4c:      	ldrb	w8, [x4, #0x8]
    eb50:      	tbz	w8, #0x0, 0xebc8 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x84>
    eb54:      	mov	x8, #0x0                ; =0
    eb58:      	ldr	x10, [x1]
    eb5c:      	cbz	x10, 0xec0c <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0xc8>
    eb60:      	udiv	x11, x8, x10
    eb64:      	msub	x8, x11, x10, x8
    eb68:      	ldr	x11, [x1, #0x10]
    eb6c:      	mov	w12, #0x110             ; =272
    eb70:      	mov	x13, x10
    eb74:      	mov	x2, x10
    eb78:      	b	0xeb98 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x54>
    eb7c:      	cmp	x2, x10
    eb80:      	csel	x2, x8, x2, eq
    eb84:      	add	x14, x8, #0x1
    eb88:      	cmp	x14, x10
    eb8c:      	csinc	x8, xzr, x8, hs
    eb90:      	subs	x13, x13, #0x1
    eb94:      	b.eq	0xec10 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0xcc>
    eb98:      	madd	x14, x8, x12, x11
    eb9c:      	ldr	w15, [x14]
    eba0:      	cmp	w15, #0x1
    eba4:      	b.eq	0xeb7c <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x38>
    eba8:      	cmp	w15, #0x2
    ebac:      	b.ne	0xec5c <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x118>
    ebb0:      	ldr	x14, [x14, #0x8]
    ebb4:      	cmp	x14, x3
    ebb8:      	b.ne	0xeb84 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x40>
    ebbc:      	mov	x2, x8
    ebc0:      	mov	x4, x9
    ebc4:      	b	0xebc4 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x80>
		000000000000ebc4:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    ebc8:      	ldr	x8, [x4]
    ebcc:      	eor	x8, x8, x3
    ebd0:      	eor	x8, x8, x8, lsr #30
    ebd4:      	mov	x10, #0xe5b9            ; =58809
    ebd8:      	movk	x10, #0x1ce4, lsl #16
    ebdc:      	movk	x10, #0x476d, lsl #32
    ebe0:      	movk	x10, #0xbf58, lsl #48
    ebe4:      	mul	x8, x8, x10
    ebe8:      	eor	x8, x8, x8, lsr #27
    ebec:      	mov	x10, #0x11eb            ; =4587
    ebf0:      	movk	x10, #0x1331, lsl #16
    ebf4:      	movk	x10, #0x49bb, lsl #32
    ebf8:      	movk	x10, #0x94d0, lsl #48
    ebfc:      	mul	x8, x8, x10
    ec00:      	eor	x8, x8, x8, lsr #31
    ec04:      	ldr	x10, [x1]
    ec08:      	cbnz	x10, 0xeb60 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x1c>
    ec0c:      	mov	x2, #0x0                ; =0
    ec10:      	cmp	x2, x10
    ec14:      	b.hs	0xec6c <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x128>
    ec18:      	ldr	x8, [x1, #0x18]
    ec1c:      	cmp	x8, #0x2
    ec20:      	b.hi	0xec6c <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x128>
    ec24:      	add	x8, x8, #0x1
    ec28:      	str	x8, [x1, #0x18]
    ec2c:      	ldr	x8, [x1, #0x10]
    ec30:      	mov	w10, #0x110             ; =272
    ec34:      	mul	x10, x2, x10
    ec38:      	ldr	w8, [x8, x10]
    ec3c:      	cmp	w8, #0x1
    ec40:      	b.ne	0xec54 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x110>
    ec44:      	ldr	x8, [x1, #0x20]
    ec48:      	subs	x8, x8, #0x1
    ec4c:      	csel	x8, xzr, x8, lo
    ec50:      	str	x8, [x1, #0x20]
    ec54:      	mov	x4, x9
    ec58:      	b	0xec58 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0x114>
		000000000000ec58:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    ec5c:      	cmp	x2, x10
    ec60:      	csel	x2, x8, x2, eq
    ec64:      	cmp	x2, x10
    ec68:      	b.lo	0xec18 <_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07+0xd4>
    ec6c:      	ldp	q0, q1, [x9]
    ec70:      	ldp	q2, q3, [x9, #0x20]
    ec74:      	ldp	q4, q5, [x9, #0x40]
    ec78:      	ldp	q6, q7, [x9, #0x60]
    ec7c:      	ldp	q16, q17, [x9, #0x80]
    ec80:      	ldp	q18, q19, [x9, #0xa0]
    ec84:      	ldp	q20, q21, [x9, #0xc0]
    ec88:      	ldp	q22, q23, [x9, #0xe0]
    ec8c:      	stp	xzr, x3, [x0]
    ec90:      	mov	w8, #0x1                ; =1
    ec94:      	str	w8, [x0]
    ec98:      	strb	w8, [x0, #0x4]
    ec9c:      	stp	q0, q1, [x0, #0x10]
    eca0:      	stp	q2, q3, [x0, #0x30]
    eca4:      	stp	q4, q5, [x0, #0x50]
    eca8:      	stp	q6, q7, [x0, #0x70]
    ecac:      	stp	q16, q17, [x0, #0x90]
    ecb0:      	stp	q18, q19, [x0, #0xb0]
    ecb4:      	stp	q20, q21, [x0, #0xd0]
    ecb8:      	stp	q22, q23, [x0, #0xf0]
    ecbc:      	ret

000000000000ecc0 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374>:
    ecc0:      	stp	x24, x23, [sp, #-0x40]!
    ecc4:      	stp	x22, x21, [sp, #0x10]
    ecc8:      	stp	x20, x19, [sp, #0x20]
    eccc:      	stp	x29, x30, [sp, #0x30]
    ecd0:      	mov	x20, x1
    ecd4:      	mov	x19, x0
    ecd8:      	ldp	x23, x22, [x0]
    ecdc:      	cmp	x22, x1
    ece0:      	b.hs	0xed40 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x80>
    ece4:      	ldr	x21, [x19, #0x10]
    ece8:      	add	x8, x20, x20, lsl #4
    ecec:      	lsl	x1, x8, #4
    ecf0:      	cmp	x22, #0x0
    ecf4:      	ccmp	x23, x22, #0x0, ne
    ecf8:      	b.eq	0xed30 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x70>
    ecfc:      	mov	x0, x1
    ed00:      	bl	0xed00 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x40>
		000000000000ed00:  ARM64_RELOC_BRANCH26	_malloc
    ed04:      	cbz	x0, 0xedb0 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xf0>
    ed08:      	cbz	x22, 0xed3c <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x7c>
    ed0c:      	add	x8, x23, x23, lsl #4
    ed10:      	lsl	x2, x8, #4
    ed14:      	mov	x22, x0
    ed18:      	mov	x1, x21
    ed1c:      	bl	0xed1c <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x5c>
		000000000000ed1c:  ARM64_RELOC_BRANCH26	_memcpy
    ed20:      	mov	x0, x21
    ed24:      	bl	0xed24 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x64>
		000000000000ed24:  ARM64_RELOC_BRANCH26	_free
    ed28:      	mov	x0, x22
    ed2c:      	b	0xed3c <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x7c>
    ed30:      	mov	x0, x21
    ed34:      	bl	0xed34 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x74>
		000000000000ed34:  ARM64_RELOC_BRANCH26	_realloc
    ed38:      	cbz	x0, 0xedb0 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xf0>
    ed3c:      	stp	x20, x0, [x19, #0x8]
    ed40:      	cmp	x23, x20
    ed44:      	b.hs	0xed98 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xd8>
    ed48:      	ldr	x8, [x19, #0x10]
    ed4c:      	mov	w9, #0x110              ; =272
    ed50:      	madd	x8, x23, x9, x8
    ed54:      	add	x8, x8, #0x8
    ed58:      	movi.2d	v0, #0000000000000000
    ed5c:      	stur	wzr, [x8, #-0x8]
    ed60:      	add	x23, x23, #0x1
    ed64:      	stp	q0, q0, [x8]
    ed68:      	stp	q0, q0, [x8, #0x20]
    ed6c:      	stp	q0, q0, [x8, #0x40]
    ed70:      	stp	q0, q0, [x8, #0x60]
    ed74:      	stp	q0, q0, [x8, #0x80]
    ed78:      	stp	q0, q0, [x8, #0xa0]
    ed7c:      	stp	q0, q0, [x8, #0xc0]
    ed80:      	stp	q0, q0, [x8, #0xe0]
    ed84:      	str	xzr, [x8, #0x100]
    ed88:      	add	x8, x8, #0x110
    ed8c:      	cmp	x20, x23
    ed90:      	b.ne	0xed5c <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0x9c>
    ed94:      	str	x23, [x19]
    ed98:      	mov	w0, #0x0                ; =0
    ed9c:      	ldp	x29, x30, [sp, #0x30]
    eda0:      	ldp	x20, x19, [sp, #0x20]
    eda4:      	ldp	x22, x21, [sp, #0x10]
    eda8:      	ldp	x24, x23, [sp], #0x40
    edac:      	ret
    edb0:      	bl	0xedb0 <_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374+0xf0>
		000000000000edb0:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000edb4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65>:
    edb4:      	stp	x28, x27, [sp, #-0x60]!
    edb8:      	stp	x26, x25, [sp, #0x10]
    edbc:      	stp	x24, x23, [sp, #0x20]
    edc0:      	stp	x22, x21, [sp, #0x30]
    edc4:      	stp	x20, x19, [sp, #0x40]
    edc8:      	stp	x29, x30, [sp, #0x50]
    edcc:      	sub	sp, sp, #0x250
    edd0:      	cmp	x1, #0x4, lsl #12       ; =0x4000
    edd4:      	b.hi	0xedec <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x38>
    edd8:      	mov	x20, x1
    eddc:      	mov	x19, x0
    ede0:      	ldr	x22, [x0]
    ede4:      	cmp	x1, x22
    ede8:      	b.hs	0xee18 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x64>
    edec:      	mov	w0, #0x1                ; =1
    edf0:      	mov	w1, #0x0                ; =0
    edf4:      	mov	w2, #0x0                ; =0
    edf8:      	add	sp, sp, #0x250
    edfc:      	ldp	x29, x30, [sp, #0x50]
    ee00:      	ldp	x20, x19, [sp, #0x40]
    ee04:      	ldp	x22, x21, [sp, #0x30]
    ee08:      	ldp	x24, x23, [sp, #0x20]
    ee0c:      	ldp	x26, x25, [sp, #0x10]
    ee10:      	ldp	x28, x27, [sp], #0x60
    ee14:      	ret
    ee18:      	cbz	x20, 0xf0dc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x328>
    ee1c:      	ldr	x25, [x2]
    ee20:      	ldrb	w8, [x2, #0x8]
    ee24:      	str	w8, [sp, #0x1c]
    ee28:      	add	x8, x20, x20, lsl #4
    ee2c:      	lsl	x0, x8, #4
    ee30:      	bl	0xee30 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x7c>
		000000000000ee30:  ARM64_RELOC_BRANCH26	_malloc
    ee34:      	cbz	x0, 0xf0e4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x330>
    ee38:      	mov	x21, x0
    ee3c:      	mov	x8, #0x0                ; =0
    ee40:      	add	x9, x0, #0x8
    ee44:      	movi.2d	v0, #0000000000000000
    ee48:      	stur	wzr, [x9, #-0x8]
    ee4c:      	add	x8, x8, #0x1
    ee50:      	stp	q0, q0, [x9]
    ee54:      	stp	q0, q0, [x9, #0x20]
    ee58:      	stp	q0, q0, [x9, #0x40]
    ee5c:      	stp	q0, q0, [x9, #0x60]
    ee60:      	stp	q0, q0, [x9, #0x80]
    ee64:      	stp	q0, q0, [x9, #0xa0]
    ee68:      	stp	q0, q0, [x9, #0xc0]
    ee6c:      	stp	q0, q0, [x9, #0xe0]
    ee70:      	str	xzr, [x9, #0x100]
    ee74:      	add	x9, x9, #0x110
    ee78:      	cmp	x20, x8
    ee7c:      	b.ne	0xee48 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x94>
    ee80:      	ldp	x9, x8, [x19, #0x8]
    ee84:      	str	x9, [sp, #0x10]
    ee88:      	str	x8, [sp, #0x20]
    ee8c:      	stp	x20, x20, [x19]
    ee90:      	str	x21, [x19, #0x10]
    ee94:      	cbz	x22, 0xf0c0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x30c>
    ee98:      	mov	w26, #0x110             ; =272
    ee9c:      	add	x27, sp, #0x30
    eea0:      	mov	x24, #0x11eb            ; =4587
    eea4:      	movk	x24, #0x1331, lsl #16
    eea8:      	movk	x24, #0x49bb, lsl #32
    eeac:      	movk	x24, #0x94d0, lsl #48
    eeb0:      	b	0xeebc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x108>
    eeb4:      	ldr	x22, [sp, #0x28]
    eeb8:      	cbz	x22, 0xf0c0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x30c>
    eebc:      	sub	x22, x22, #0x1
    eec0:      	str	x22, [sp, #0x28]
    eec4:      	ldr	x8, [sp, #0x20]
    eec8:      	madd	x8, x22, x26, x8
    eecc:      	ldr	w9, [x8]
    eed0:      	cmp	w9, #0x1
    eed4:      	b.ls	0xeeb4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x100>
    eed8:      	ldr	x9, [x8, #0x108]
    eedc:      	ldur	q0, [x8, #0x8]
    eee0:      	stur	q0, [sp, #0x38]
    eee4:      	ldur	q0, [x8, #0x18]
    eee8:      	stur	q0, [sp, #0x48]
    eeec:      	ldur	q0, [x8, #0x28]
    eef0:      	stur	q0, [sp, #0x58]
    eef4:      	ldur	q0, [x8, #0x38]
    eef8:      	stur	q0, [sp, #0x68]
    eefc:      	ldur	q0, [x8, #0x48]
    ef00:      	stur	q0, [sp, #0x78]
    ef04:      	ldur	q0, [x8, #0x58]
    ef08:      	stur	q0, [sp, #0x88]
    ef0c:      	ldur	q0, [x8, #0x68]
    ef10:      	stur	q0, [sp, #0x98]
    ef14:      	ldur	q0, [x8, #0x78]
    ef18:      	stur	q0, [sp, #0xa8]
    ef1c:      	ldur	q0, [x8, #0x88]
    ef20:      	add	x10, sp, #0x30
    ef24:      	stur	q0, [x10, #0x88]
    ef28:      	ldur	q0, [x8, #0x98]
    ef2c:      	stur	q0, [x10, #0x98]
    ef30:      	ldur	q0, [x8, #0xa8]
    ef34:      	stur	q0, [x10, #0xa8]
    ef38:      	ldur	q0, [x8, #0xb8]
    ef3c:      	stur	q0, [x10, #0xb8]
    ef40:      	ldur	q0, [x8, #0xc8]
    ef44:      	stur	q0, [x10, #0xc8]
    ef48:      	ldur	q0, [x8, #0xd8]
    ef4c:      	stur	q0, [x10, #0xd8]
    ef50:      	ldur	q0, [x8, #0xe8]
    ef54:      	stur	q0, [x10, #0xe8]
    ef58:      	ldur	q0, [x8, #0xf8]
    ef5c:      	stur	q0, [x10, #0xf8]
    ef60:      	str	x9, [sp, #0x138]
    ef64:      	mov	w8, #0x1                ; =1
    ef68:      	str	x8, [sp, #0x30]
    ef6c:      	ldr	w8, [sp, #0x1c]
    ef70:      	tbz	w8, #0x0, 0xeff8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x244>
    ef74:      	mov	w28, #0x1               ; =1
    ef78:      	b	0xefc4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x210>
    ef7c:      	sub	x22, x28, #0x1
    ef80:      	str	x22, [sp, #0x30]
    ef84:      	mov	w8, #0x108              ; =264
    ef88:      	madd	x23, x28, x8, x27
    ef8c:      	ldr	x3, [x23, #-0x100]!
    ef90:      	add	x0, sp, #0x140
    ef94:      	add	x4, x23, #0x8
    ef98:      	mov	x1, x19
    ef9c:      	bl	0xef9c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x1e8>
		000000000000ef9c:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    efa0:      	ldr	w8, [sp, #0x140]
    efa4:      	cbz	w8, 0xefec <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x238>
    efa8:      	add	x8, sp, #0x140
    efac:      	add	x1, x8, #0x8
    efb0:      	mov	x0, x23
    efb4:      	mov	w2, #0x108              ; =264
    efb8:      	bl	0xefb8 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x204>
		000000000000efb8:  ARM64_RELOC_BRANCH26	_memcpy
    efbc:      	str	x28, [sp, #0x30]
    efc0:      	cbz	x28, 0xeeb4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x100>
    efc4:      	mov	x2, #0x0                ; =0
    efc8:      	mov	x8, x21
    efcc:      	ldr	w9, [x8]
    efd0:      	cmp	w9, #0x2
    efd4:      	b.lo	0xef7c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x1c8>
    efd8:      	add	x8, x8, #0x110
    efdc:      	add	x2, x2, #0x1
    efe0:      	cmp	x20, x2
    efe4:      	b.ne	0xefcc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x218>
    efe8:      	b	0xefc0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x20c>
    efec:      	mov	x28, x22
    eff0:      	cbnz	x22, 0xefc4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x210>
    eff4:      	b	0xeeb4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x100>
    eff8:      	mov	w22, #0x1               ; =1
    effc:      	b	0xf048 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x294>
    f000:      	sub	x28, x22, #0x1
    f004:      	str	x28, [sp, #0x30]
    f008:      	mov	w8, #0x108              ; =264
    f00c:      	madd	x23, x22, x8, x27
    f010:      	ldr	x3, [x23, #-0x100]!
    f014:      	add	x0, sp, #0x140
    f018:      	add	x4, x23, #0x8
    f01c:      	mov	x1, x19
    f020:      	bl	0xf020 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x26c>
		000000000000f020:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    f024:      	ldr	w8, [sp, #0x140]
    f028:      	cbz	w8, 0xf0b4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x300>
    f02c:      	add	x8, sp, #0x140
    f030:      	add	x1, x8, #0x8
    f034:      	mov	x0, x23
    f038:      	mov	w2, #0x108              ; =264
    f03c:      	bl	0xf03c <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x288>
		000000000000f03c:  ARM64_RELOC_BRANCH26	_memcpy
    f040:      	str	x22, [sp, #0x30]
    f044:      	cbz	x22, 0xeeb4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x100>
    f048:      	mov	x8, #0x0                ; =0
    f04c:      	ldr	x9, [sp, #0x38]
    f050:      	eor	x9, x9, x25
    f054:      	eor	x9, x9, x9, lsr #30
    f058:      	mov	x10, #0xe5b9            ; =58809
    f05c:      	movk	x10, #0x1ce4, lsl #16
    f060:      	movk	x10, #0x476d, lsl #32
    f064:      	movk	x10, #0xbf58, lsl #48
    f068:      	mul	x9, x9, x10
    f06c:      	eor	x9, x9, x9, lsr #27
    f070:      	mul	x9, x9, x24
    f074:      	eor	x9, x9, x9, lsr #31
    f078:      	udiv	x10, x9, x20
    f07c:      	msub	x9, x10, x20, x9
    f080:      	sub	x10, x20, x9
    f084:      	neg	x11, x10
    f088:      	cmp	x8, x10
    f08c:      	csel	x12, x9, x11, lo
    f090:      	add	x2, x12, x8
    f094:      	mul	x12, x2, x26
    f098:      	ldr	w12, [x21, x12]
    f09c:      	cmp	w12, #0x2
    f0a0:      	b.lo	0xf000 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x24c>
    f0a4:      	add	x8, x8, #0x1
    f0a8:      	cmp	x20, x8
    f0ac:      	b.ne	0xf088 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x2d4>
    f0b0:      	b	0xf044 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x290>
    f0b4:      	mov	x22, x28
    f0b8:      	cbnz	x28, 0xf048 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x294>
    f0bc:      	b	0xeeb4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x100>
    f0c0:      	ldr	x8, [sp, #0x10]
    f0c4:      	cbz	x8, 0xf0d0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x31c>
    f0c8:      	ldr	x0, [sp, #0x20]
    f0cc:      	bl	0xf0cc <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x318>
		000000000000f0cc:  ARM64_RELOC_BRANCH26	_free
    f0d0:      	mov	w0, #0x0                ; =0
    f0d4:      	str	xzr, [x19, #0x20]
    f0d8:      	b	0xedf0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x3c>
    f0dc:      	mov	w0, #0x0                ; =0
    f0e0:      	b	0xedf0 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x3c>
    f0e4:      	bl	0xf0e4 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x330>
		000000000000f0e4:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000f0e8 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65>:
    f0e8:      	mov	x9, x3
    f0ec:      	mov	x3, x2
    f0f0:      	ldrb	w8, [x4, #0x8]
    f0f4:      	tbz	w8, #0x0, 0xf16c <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x84>
    f0f8:      	mov	x8, #0x0                ; =0
    f0fc:      	ldr	x10, [x1]
    f100:      	cbz	x10, 0xf1b0 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0xc8>
    f104:      	udiv	x11, x8, x10
    f108:      	msub	x8, x11, x10, x8
    f10c:      	ldr	x11, [x1, #0x10]
    f110:      	mov	w12, #0x110             ; =272
    f114:      	mov	x13, x10
    f118:      	mov	x2, x10
    f11c:      	b	0xf13c <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x54>
    f120:      	cmp	x2, x10
    f124:      	csel	x2, x8, x2, eq
    f128:      	add	x14, x8, #0x1
    f12c:      	cmp	x14, x10
    f130:      	csinc	x8, xzr, x8, hs
    f134:      	subs	x13, x13, #0x1
    f138:      	b.eq	0xf1b4 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0xcc>
    f13c:      	madd	x14, x8, x12, x11
    f140:      	ldr	w15, [x14]
    f144:      	cmp	w15, #0x1
    f148:      	b.eq	0xf120 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x38>
    f14c:      	cmp	w15, #0x2
    f150:      	b.ne	0xf200 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x118>
    f154:      	ldr	x14, [x14, #0x8]
    f158:      	cmp	x14, x3
    f15c:      	b.ne	0xf128 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x40>
    f160:      	mov	x2, x8
    f164:      	mov	x4, x9
    f168:      	b	0xf168 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x80>
		000000000000f168:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    f16c:      	ldr	x8, [x4]
    f170:      	eor	x8, x8, x3
    f174:      	eor	x8, x8, x8, lsr #30
    f178:      	mov	x10, #0xe5b9            ; =58809
    f17c:      	movk	x10, #0x1ce4, lsl #16
    f180:      	movk	x10, #0x476d, lsl #32
    f184:      	movk	x10, #0xbf58, lsl #48
    f188:      	mul	x8, x8, x10
    f18c:      	eor	x8, x8, x8, lsr #27
    f190:      	mov	x10, #0x11eb            ; =4587
    f194:      	movk	x10, #0x1331, lsl #16
    f198:      	movk	x10, #0x49bb, lsl #32
    f19c:      	movk	x10, #0x94d0, lsl #48
    f1a0:      	mul	x8, x8, x10
    f1a4:      	eor	x8, x8, x8, lsr #31
    f1a8:      	ldr	x10, [x1]
    f1ac:      	cbnz	x10, 0xf104 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x1c>
    f1b0:      	mov	x2, #0x0                ; =0
    f1b4:      	cmp	x2, x10
    f1b8:      	b.hs	0xf210 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x128>
    f1bc:      	ldr	x8, [x1, #0x18]
    f1c0:      	lsr	x10, x8, #14
    f1c4:      	cbnz	x10, 0xf210 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x128>
    f1c8:      	add	x8, x8, #0x1
    f1cc:      	str	x8, [x1, #0x18]
    f1d0:      	ldr	x8, [x1, #0x10]
    f1d4:      	mov	w10, #0x110             ; =272
    f1d8:      	mul	x10, x2, x10
    f1dc:      	ldr	w8, [x8, x10]
    f1e0:      	cmp	w8, #0x1
    f1e4:      	b.ne	0xf1f8 <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x110>
    f1e8:      	ldr	x8, [x1, #0x20]
    f1ec:      	subs	x8, x8, #0x1
    f1f0:      	csel	x8, xzr, x8, lo
    f1f4:      	str	x8, [x1, #0x20]
    f1f8:      	mov	x4, x9
    f1fc:      	b	0xf1fc <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0x114>
		000000000000f1fc:  ARM64_RELOC_BRANCH26	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
    f200:      	cmp	x2, x10
    f204:      	csel	x2, x8, x2, eq
    f208:      	cmp	x2, x10
    f20c:      	b.lo	0xf1bc <_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65+0xd4>
    f210:      	ldp	q0, q1, [x9]
    f214:      	ldp	q2, q3, [x9, #0x20]
    f218:      	ldp	q4, q5, [x9, #0x40]
    f21c:      	ldp	q6, q7, [x9, #0x60]
    f220:      	ldp	q16, q17, [x9, #0x80]
    f224:      	ldp	q18, q19, [x9, #0xa0]
    f228:      	ldp	q20, q21, [x9, #0xc0]
    f22c:      	ldp	q22, q23, [x9, #0xe0]
    f230:      	stp	xzr, x3, [x0]
    f234:      	mov	w8, #0x1                ; =1
    f238:      	str	w8, [x0]
    f23c:      	strb	w8, [x0, #0x4]
    f240:      	stp	q0, q1, [x0, #0x10]
    f244:      	stp	q2, q3, [x0, #0x30]
    f248:      	stp	q4, q5, [x0, #0x50]
    f24c:      	stp	q6, q7, [x0, #0x70]
    f250:      	stp	q16, q17, [x0, #0x90]
    f254:      	stp	q18, q19, [x0, #0xb0]
    f258:      	stp	q20, q21, [x0, #0xd0]
    f25c:      	stp	q22, q23, [x0, #0xf0]
    f260:      	ret

000000000000f264 <_wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65>:
    f264:      	ldrb	w8, [x2, #0x8]
    f268:      	tbz	w8, #0x0, 0xf27c <_wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65+0x18>
    f26c:      	mov	x8, #0x0                ; =0
    f270:      	ldr	x9, [x0]
    f274:      	cbnz	x9, 0xf2c4 <_wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65+0x60>
    f278:      	b	0xf328 <_wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65+0xc4>
    f27c:      	ldr	x8, [x2]
    f280:      	ldr	x9, [x1]
    f284:      	eor	x8, x9, x8
    f288:      	eor	x8, x8, x8, lsr #30
    f28c:      	mov	x9, #0xe5b9             ; =58809
    f290:      	movk	x9, #0x1ce4, lsl #16
    f294:      	movk	x9, #0x476d, lsl #32
    f298:      	movk	x9, #0xbf58, lsl #48
    f29c:      	mul	x8, x8, x9
    f2a0:      	eor	x8, x8, x8, lsr #27
    f2a4:      	mov	x9, #0x11eb             ; =4587
    f2a8:      	movk	x9, #0x1331, lsl #16
    f2ac:      	movk	x9, #0x49bb, lsl #32
    f2b0:      	movk	x9, #0x94d0, lsl #48
    f2b4:      	mul	x8, x8, x9
    f2b8:      	eor	x8, x8, x8, lsr #31
    f2bc:      	ldr	x9, [x0]
    f2c0:      	cbz	x9, 0xf328 <_wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65+0xc4>
    f2c4:      	udiv	x10, x8, x9
    f2c8:      	msub	x8, x10, x9, x8
    f2cc:      	ldr	x10, [x0, #0x10]
    f2d0:      	mov	w11, #0x110             ; =272
    f2d4:      	mov	x12, x9
    f2d8:      	b	0xf2f0 <_wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65+0x8c>
    f2dc:      	add	x13, x8, #0x1
    f2e0:      	cmp	x13, x9
    f2e4:      	csinc	x8, xzr, x8, hs
    f2e8:      	subs	x12, x12, #0x1
    f2ec:      	b.eq	0xf328 <_wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65+0xc4>
    f2f0:      	madd	x14, x8, x11, x10
    f2f4:      	ldr	w13, [x14]
    f2f8:      	cmp	w13, #0x1
    f2fc:      	b.eq	0xf2dc <_wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65+0x78>
    f300:      	cmp	w13, #0x2
    f304:      	b.ne	0xf33c <_wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65+0xd8>
    f308:      	ldr	x13, [x14, #0x8]
    f30c:      	ldr	x14, [x1]
    f310:      	cmp	x13, x14
    f314:      	b.ne	0xf2dc <_wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65+0x78>
    f318:      	mov	w0, #0x0                ; =0
    f31c:      	mov	x1, x8
    f320:      	mov	w2, #0x0                ; =0
    f324:      	ret
    f328:      	mov	x8, #0x0                ; =0
    f32c:      	mov	w0, #0x1                ; =1
    f330:      	mov	x1, x8
    f334:      	mov	w2, #0x0                ; =0
    f338:      	ret
    f33c:      	mov	w0, #0x1                ; =1
    f340:      	mov	x8, x13
    f344:      	mov	x1, x8
    f348:      	mov	w2, #0x0                ; =0
    f34c:      	ret

000000000000f350 <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14>:
    f350:      	stp	x24, x23, [sp, #-0x40]!
    f354:      	stp	x22, x21, [sp, #0x10]
    f358:      	stp	x20, x19, [sp, #0x20]
    f35c:      	stp	x29, x30, [sp, #0x30]
    f360:      	mov	x20, x1
    f364:      	mov	x19, x0
    f368:      	ldp	x23, x22, [x0]
    f36c:      	cmp	x22, x1
    f370:      	b.hs	0xf3d0 <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0x80>
    f374:      	ldr	x21, [x19, #0x10]
    f378:      	add	x8, x20, x20, lsl #1
    f37c:      	lsl	x1, x8, #3
    f380:      	cmp	x22, #0x0
    f384:      	ccmp	x23, x22, #0x0, ne
    f388:      	b.eq	0xf3c0 <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0x70>
    f38c:      	mov	x0, x1
    f390:      	bl	0xf390 <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0x40>
		000000000000f390:  ARM64_RELOC_BRANCH26	_malloc
    f394:      	cbz	x0, 0xf418 <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0xc8>
    f398:      	cbz	x22, 0xf3cc <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0x7c>
    f39c:      	add	x8, x23, x23, lsl #1
    f3a0:      	lsl	x2, x8, #3
    f3a4:      	mov	x22, x0
    f3a8:      	mov	x1, x21
    f3ac:      	bl	0xf3ac <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0x5c>
		000000000000f3ac:  ARM64_RELOC_BRANCH26	_memcpy
    f3b0:      	mov	x0, x21
    f3b4:      	bl	0xf3b4 <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0x64>
		000000000000f3b4:  ARM64_RELOC_BRANCH26	_free
    f3b8:      	mov	x0, x22
    f3bc:      	b	0xf3cc <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0x7c>
    f3c0:      	mov	x0, x21
    f3c4:      	bl	0xf3c4 <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0x74>
		000000000000f3c4:  ARM64_RELOC_BRANCH26	_realloc
    f3c8:      	cbz	x0, 0xf418 <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0xc8>
    f3cc:      	stp	x20, x0, [x19, #0x8]
    f3d0:      	cmp	x23, x20
    f3d4:      	b.hs	0xf400 <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0xb0>
    f3d8:      	ldr	x8, [x19, #0x10]
    f3dc:      	mov	w9, #0x18               ; =24
    f3e0:      	madd	x8, x23, x9, x8
    f3e4:      	add	x8, x8, #0x8
    f3e8:      	stur	wzr, [x8, #-0x8]
    f3ec:      	add	x23, x23, #0x1
    f3f0:      	stp	xzr, xzr, [x8], #0x18
    f3f4:      	cmp	x20, x23
    f3f8:      	b.ne	0xf3e8 <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0x98>
    f3fc:      	str	x23, [x19]
    f400:      	mov	w0, #0x0                ; =0
    f404:      	ldp	x29, x30, [sp, #0x30]
    f408:      	ldp	x20, x19, [sp, #0x20]
    f40c:      	ldp	x22, x21, [sp, #0x10]
    f410:      	ldp	x24, x23, [sp], #0x40
    f414:      	ret
    f418:      	bl	0xf418 <_wf_std.collections.hash_map.hash_map_extend$instance$e85fc351f8333b14+0xc8>
		000000000000f418:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000f41c <_wf_std.collections.hash_map.hash_map_action$instance$fc5e3cb62bdf3601>:
    f41c:      	mov	x8, x0
    f420:      	ldr	w0, [x0]
    f424:      	cmp	w0, #0x1
    f428:      	b.ls	0xf440 <_wf_std.collections.hash_map.hash_map_action$instance$fc5e3cb62bdf3601+0x24>
    f42c:      	ldr	x8, [x8, #0x8]
    f430:      	ldr	x9, [x1]
    f434:      	cmp	x8, x9
    f438:      	mov	w8, #0x2                ; =2
    f43c:      	cinc	w0, w8, eq
    f440:      	ret

000000000000f444 <_wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3>:
    f444:      	ldr	x8, [x1, #0x10]
    f448:      	mov	w9, #0x18               ; =24
    f44c:      	madd	x9, x2, x9, x8
    f450:      	ldr	w8, [x9]
    f454:      	ldur	q0, [x9, #0x8]
    f458:      	mov	w10, #0x2               ; =2
    f45c:      	str	w10, [x9]
    f460:      	stp	x3, x4, [x9, #0x8]
    f464:      	cbz	w8, 0xf470 <_wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3+0x2c>
    f468:      	cmp	w8, #0x1
    f46c:      	b.ne	0xf47c <_wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3+0x38>
    f470:      	stp	xzr, xzr, [x0]
    f474:      	str	xzr, [x0, #0x10]
    f478:      	ret
    f47c:      	str	xzr, [x0]
    f480:      	mov	w8, #0x1                ; =1
    f484:      	str	w8, [x0]
    f488:      	stur	q0, [x0, #0x8]
    f48c:      	ret

000000000000f490 <_wf_std.collections.hash_map.hash_map_is_deleted$instance$0ed342445dd803f3>:
    f490:      	ldr	w8, [x0]
    f494:      	cmp	w8, #0x1
    f498:      	cset	w0, eq
    f49c:      	ret

000000000000f4a0 <_wf_std.collections.hash_map.hash_map_find$instance$29255544f66aec6e>:
    f4a0:      	ldrb	w8, [x2, #0x8]
    f4a4:      	tbz	w8, #0x0, 0xf4b8 <_wf_std.collections.hash_map.hash_map_find$instance$29255544f66aec6e+0x18>
    f4a8:      	mov	x8, #0x0                ; =0
    f4ac:      	ldr	x9, [x0]
    f4b0:      	cbnz	x9, 0xf500 <_wf_std.collections.hash_map.hash_map_find$instance$29255544f66aec6e+0x60>
    f4b4:      	b	0xf564 <_wf_std.collections.hash_map.hash_map_find$instance$29255544f66aec6e+0xc4>
    f4b8:      	ldr	x8, [x2]
    f4bc:      	ldr	x9, [x1]
    f4c0:      	eor	x8, x9, x8
    f4c4:      	eor	x8, x8, x8, lsr #30
    f4c8:      	mov	x9, #0xe5b9             ; =58809
    f4cc:      	movk	x9, #0x1ce4, lsl #16
    f4d0:      	movk	x9, #0x476d, lsl #32
    f4d4:      	movk	x9, #0xbf58, lsl #48
    f4d8:      	mul	x8, x8, x9
    f4dc:      	eor	x8, x8, x8, lsr #27
    f4e0:      	mov	x9, #0x11eb             ; =4587
    f4e4:      	movk	x9, #0x1331, lsl #16
    f4e8:      	movk	x9, #0x49bb, lsl #32
    f4ec:      	movk	x9, #0x94d0, lsl #48
    f4f0:      	mul	x8, x8, x9
    f4f4:      	eor	x8, x8, x8, lsr #31
    f4f8:      	ldr	x9, [x0]
    f4fc:      	cbz	x9, 0xf564 <_wf_std.collections.hash_map.hash_map_find$instance$29255544f66aec6e+0xc4>
    f500:      	udiv	x10, x8, x9
    f504:      	msub	x8, x10, x9, x8
    f508:      	ldr	x10, [x0, #0x10]
    f50c:      	mov	w11, #0x18              ; =24
    f510:      	mov	x12, x9
    f514:      	b	0xf52c <_wf_std.collections.hash_map.hash_map_find$instance$29255544f66aec6e+0x8c>
    f518:      	add	x13, x8, #0x1
    f51c:      	cmp	x13, x9
    f520:      	csinc	x8, xzr, x8, hs
    f524:      	subs	x12, x12, #0x1
    f528:      	b.eq	0xf564 <_wf_std.collections.hash_map.hash_map_find$instance$29255544f66aec6e+0xc4>
    f52c:      	madd	x14, x8, x11, x10
    f530:      	ldr	w13, [x14]
    f534:      	cmp	w13, #0x1
    f538:      	b.eq	0xf518 <_wf_std.collections.hash_map.hash_map_find$instance$29255544f66aec6e+0x78>
    f53c:      	cmp	w13, #0x2
    f540:      	b.ne	0xf578 <_wf_std.collections.hash_map.hash_map_find$instance$29255544f66aec6e+0xd8>
    f544:      	ldr	x13, [x14, #0x8]
    f548:      	ldr	x14, [x1]
    f54c:      	cmp	x13, x14
    f550:      	b.ne	0xf518 <_wf_std.collections.hash_map.hash_map_find$instance$29255544f66aec6e+0x78>
    f554:      	mov	w0, #0x0                ; =0
    f558:      	mov	x1, x8
    f55c:      	mov	w2, #0x0                ; =0
    f560:      	ret
    f564:      	mov	x8, #0x0                ; =0
    f568:      	mov	w0, #0x1                ; =1
    f56c:      	mov	x1, x8
    f570:      	mov	w2, #0x0                ; =0
    f574:      	ret
    f578:      	mov	w0, #0x1                ; =1
    f57c:      	mov	x8, x13
    f580:      	mov	x1, x8
    f584:      	mov	w2, #0x0                ; =0
    f588:      	ret

000000000000f58c <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa>:
    f58c:      	stp	x24, x23, [sp, #-0x40]!
    f590:      	stp	x22, x21, [sp, #0x10]
    f594:      	stp	x20, x19, [sp, #0x20]
    f598:      	stp	x29, x30, [sp, #0x30]
    f59c:      	mov	x20, x1
    f5a0:      	mov	x19, x0
    f5a4:      	ldp	x23, x22, [x0]
    f5a8:      	cmp	x22, x1
    f5ac:      	b.hs	0xf60c <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0x80>
    f5b0:      	ldr	x21, [x19, #0x10]
    f5b4:      	add	x8, x20, x20, lsl #4
    f5b8:      	lsl	x1, x8, #4
    f5bc:      	cmp	x22, #0x0
    f5c0:      	ccmp	x23, x22, #0x0, ne
    f5c4:      	b.eq	0xf5fc <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0x70>
    f5c8:      	mov	x0, x1
    f5cc:      	bl	0xf5cc <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0x40>
		000000000000f5cc:  ARM64_RELOC_BRANCH26	_malloc
    f5d0:      	cbz	x0, 0xf67c <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0xf0>
    f5d4:      	cbz	x22, 0xf608 <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0x7c>
    f5d8:      	add	x8, x23, x23, lsl #4
    f5dc:      	lsl	x2, x8, #4
    f5e0:      	mov	x22, x0
    f5e4:      	mov	x1, x21
    f5e8:      	bl	0xf5e8 <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0x5c>
		000000000000f5e8:  ARM64_RELOC_BRANCH26	_memcpy
    f5ec:      	mov	x0, x21
    f5f0:      	bl	0xf5f0 <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0x64>
		000000000000f5f0:  ARM64_RELOC_BRANCH26	_free
    f5f4:      	mov	x0, x22
    f5f8:      	b	0xf608 <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0x7c>
    f5fc:      	mov	x0, x21
    f600:      	bl	0xf600 <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0x74>
		000000000000f600:  ARM64_RELOC_BRANCH26	_realloc
    f604:      	cbz	x0, 0xf67c <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0xf0>
    f608:      	stp	x20, x0, [x19, #0x8]
    f60c:      	cmp	x23, x20
    f610:      	b.hs	0xf664 <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0xd8>
    f614:      	ldr	x8, [x19, #0x10]
    f618:      	mov	w9, #0x110              ; =272
    f61c:      	madd	x8, x23, x9, x8
    f620:      	add	x8, x8, #0x8
    f624:      	movi.2d	v0, #0000000000000000
    f628:      	stur	wzr, [x8, #-0x8]
    f62c:      	add	x23, x23, #0x1
    f630:      	stp	q0, q0, [x8]
    f634:      	stp	q0, q0, [x8, #0x20]
    f638:      	stp	q0, q0, [x8, #0x40]
    f63c:      	stp	q0, q0, [x8, #0x60]
    f640:      	stp	q0, q0, [x8, #0x80]
    f644:      	stp	q0, q0, [x8, #0xa0]
    f648:      	stp	q0, q0, [x8, #0xc0]
    f64c:      	stp	q0, q0, [x8, #0xe0]
    f650:      	str	xzr, [x8, #0x100]
    f654:      	add	x8, x8, #0x110
    f658:      	cmp	x20, x23
    f65c:      	b.ne	0xf628 <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0x9c>
    f660:      	str	x23, [x19]
    f664:      	mov	w0, #0x0                ; =0
    f668:      	ldp	x29, x30, [sp, #0x30]
    f66c:      	ldp	x20, x19, [sp, #0x20]
    f670:      	ldp	x22, x21, [sp, #0x10]
    f674:      	ldp	x24, x23, [sp], #0x40
    f678:      	ret
    f67c:      	bl	0xf67c <_wf_std.collections.hash_map.hash_map_extend$instance$1fa0694bfbd574aa+0xf0>
		000000000000f67c:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000f680 <_wf_std.collections.hash_map.hash_map_action$instance$c6df3d8464f8cde0>:
    f680:      	mov	x8, x0
    f684:      	ldr	w0, [x0]
    f688:      	cmp	w0, #0x1
    f68c:      	b.ls	0xf6a4 <_wf_std.collections.hash_map.hash_map_action$instance$c6df3d8464f8cde0+0x24>
    f690:      	ldr	x8, [x8, #0x8]
    f694:      	ldr	x9, [x1]
    f698:      	cmp	x8, x9
    f69c:      	mov	w8, #0x2                ; =2
    f6a0:      	cinc	w0, w8, eq
    f6a4:      	ret

000000000000f6a8 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449>:
    f6a8:      	stp	d15, d14, [sp, #-0x40]!
    f6ac:      	stp	d13, d12, [sp, #0x10]
    f6b0:      	stp	d11, d10, [sp, #0x20]
    f6b4:      	stp	d9, d8, [sp, #0x30]
    f6b8:      	ldr	x8, [x1, #0x10]
    f6bc:      	mov	w9, #0x110              ; =272
    f6c0:      	madd	x10, x2, x9, x8
    f6c4:      	ldr	w9, [x10]
    f6c8:      	ldur	q0, [x10, #0x8]
    f6cc:      	ldur	q1, [x10, #0x18]
    f6d0:      	ldur	q2, [x10, #0x28]
    f6d4:      	ldur	q3, [x10, #0x38]
    f6d8:      	ldur	q4, [x10, #0x48]
    f6dc:      	ldur	q5, [x10, #0x58]
    f6e0:      	ldur	q6, [x10, #0x68]
    f6e4:      	ldur	q7, [x10, #0x78]
    f6e8:      	ldur	q16, [x10, #0x88]
    f6ec:      	ldur	q17, [x10, #0x98]
    f6f0:      	ldur	q18, [x10, #0xa8]
    f6f4:      	ldur	q19, [x10, #0xb8]
    f6f8:      	ldur	q20, [x10, #0xc8]
    f6fc:      	ldur	q21, [x10, #0xd8]
    f700:      	ldur	q22, [x10, #0xe8]
    f704:      	ldur	q23, [x10, #0xf8]
    f708:      	ldr	x8, [x10, #0x108]
    f70c:      	ldp	q24, q25, [x4]
    f710:      	ldp	q26, q27, [x4, #0x20]
    f714:      	ldp	q28, q29, [x4, #0x40]
    f718:      	ldp	q30, q31, [x4, #0x60]
    f71c:      	ldp	q8, q9, [x4, #0x80]
    f720:      	ldp	q10, q11, [x4, #0xa0]
    f724:      	ldp	q12, q13, [x4, #0xc0]
    f728:      	ldp	q14, q15, [x4, #0xe0]
    f72c:      	mov	w11, #0x2               ; =2
    f730:      	str	w11, [x10]
    f734:      	str	x3, [x10, #0x8]
    f738:      	stp	q24, q25, [x10, #0x10]
    f73c:      	stp	q26, q27, [x10, #0x30]
    f740:      	stp	q28, q29, [x10, #0x50]
    f744:      	stp	q30, q31, [x10, #0x70]
    f748:      	stp	q8, q9, [x10, #0x90]
    f74c:      	stp	q10, q11, [x10, #0xb0]
    f750:      	stp	q12, q13, [x10, #0xd0]
    f754:      	stp	q14, q15, [x10, #0xf0]
    f758:      	cbz	w9, 0xf764 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449+0xbc>
    f75c:      	cmp	w9, #0x1
    f760:      	b.ne	0xf7a0 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449+0xf8>
    f764:      	movi.2d	v0, #0000000000000000
    f768:      	stp	q0, q0, [x0, #0xf0]
    f76c:      	stp	q0, q0, [x0, #0xd0]
    f770:      	stp	q0, q0, [x0, #0xb0]
    f774:      	stp	q0, q0, [x0, #0x90]
    f778:      	stp	q0, q0, [x0, #0x70]
    f77c:      	stp	q0, q0, [x0, #0x50]
    f780:      	stp	q0, q0, [x0, #0x30]
    f784:      	stp	q0, q0, [x0, #0x10]
    f788:      	str	q0, [x0]
    f78c:      	ldp	d9, d8, [sp, #0x30]
    f790:      	ldp	d11, d10, [sp, #0x20]
    f794:      	ldp	d13, d12, [sp, #0x10]
    f798:      	ldp	d15, d14, [sp], #0x40
    f79c:      	ret
    f7a0:      	str	xzr, [x0]
    f7a4:      	mov	w9, #0x1                ; =1
    f7a8:      	str	w9, [x0]
    f7ac:      	stur	q0, [x0, #0x8]
    f7b0:      	stur	q1, [x0, #0x18]
    f7b4:      	stur	q2, [x0, #0x28]
    f7b8:      	stur	q3, [x0, #0x38]
    f7bc:      	stur	q4, [x0, #0x48]
    f7c0:      	stur	q5, [x0, #0x58]
    f7c4:      	stur	q6, [x0, #0x68]
    f7c8:      	stur	q7, [x0, #0x78]
    f7cc:      	stur	q16, [x0, #0x88]
    f7d0:      	stur	q17, [x0, #0x98]
    f7d4:      	stur	q18, [x0, #0xa8]
    f7d8:      	stur	q19, [x0, #0xb8]
    f7dc:      	stur	q20, [x0, #0xc8]
    f7e0:      	stur	q21, [x0, #0xd8]
    f7e4:      	stur	q22, [x0, #0xe8]
    f7e8:      	stur	q23, [x0, #0xf8]
    f7ec:      	str	x8, [x0, #0x108]
    f7f0:      	ldp	d9, d8, [sp, #0x30]
    f7f4:      	ldp	d11, d10, [sp, #0x20]
    f7f8:      	ldp	d13, d12, [sp, #0x10]
    f7fc:      	ldp	d15, d14, [sp], #0x40
    f800:      	ret

000000000000f804 <_wf_std.collections.hash_map.hash_map_is_deleted$instance$d7a1a90c27bba449>:
    f804:      	ldr	w8, [x0]
    f808:      	cmp	w8, #0x1
    f80c:      	cset	w0, eq
    f810:      	ret

000000000000f814 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d>:
    f814:      	ldrb	w8, [x2, #0x8]
    f818:      	tbz	w8, #0x0, 0xf82c <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0x18>
    f81c:      	mov	x8, #0x0                ; =0
    f820:      	ldr	x9, [x0]
    f824:      	cbnz	x9, 0xf874 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0x60>
    f828:      	b	0xf8d8 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0xc4>
    f82c:      	ldr	x8, [x2]
    f830:      	ldr	x9, [x1]
    f834:      	eor	x8, x9, x8
    f838:      	eor	x8, x8, x8, lsr #30
    f83c:      	mov	x9, #0xe5b9             ; =58809
    f840:      	movk	x9, #0x1ce4, lsl #16
    f844:      	movk	x9, #0x476d, lsl #32
    f848:      	movk	x9, #0xbf58, lsl #48
    f84c:      	mul	x8, x8, x9
    f850:      	eor	x8, x8, x8, lsr #27
    f854:      	mov	x9, #0x11eb             ; =4587
    f858:      	movk	x9, #0x1331, lsl #16
    f85c:      	movk	x9, #0x49bb, lsl #32
    f860:      	movk	x9, #0x94d0, lsl #48
    f864:      	mul	x8, x8, x9
    f868:      	eor	x8, x8, x8, lsr #31
    f86c:      	ldr	x9, [x0]
    f870:      	cbz	x9, 0xf8d8 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0xc4>
    f874:      	udiv	x10, x8, x9
    f878:      	msub	x8, x10, x9, x8
    f87c:      	ldr	x10, [x0, #0x10]
    f880:      	mov	w11, #0x110             ; =272
    f884:      	mov	x12, x9
    f888:      	b	0xf8a0 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0x8c>
    f88c:      	add	x13, x8, #0x1
    f890:      	cmp	x13, x9
    f894:      	csinc	x8, xzr, x8, hs
    f898:      	subs	x12, x12, #0x1
    f89c:      	b.eq	0xf8d8 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0xc4>
    f8a0:      	madd	x14, x8, x11, x10
    f8a4:      	ldr	w13, [x14]
    f8a8:      	cmp	w13, #0x1
    f8ac:      	b.eq	0xf88c <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0x78>
    f8b0:      	cmp	w13, #0x2
    f8b4:      	b.ne	0xf8ec <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0xd8>
    f8b8:      	ldr	x13, [x14, #0x8]
    f8bc:      	ldr	x14, [x1]
    f8c0:      	cmp	x13, x14
    f8c4:      	b.ne	0xf88c <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0x78>
    f8c8:      	mov	w0, #0x0                ; =0
    f8cc:      	mov	x1, x8
    f8d0:      	mov	w2, #0x0                ; =0
    f8d4:      	ret
    f8d8:      	mov	x8, #0x0                ; =0
    f8dc:      	mov	w0, #0x1                ; =1
    f8e0:      	mov	x1, x8
    f8e4:      	mov	w2, #0x0                ; =0
    f8e8:      	ret
    f8ec:      	mov	w0, #0x1                ; =1
    f8f0:      	mov	x8, x13
    f8f4:      	mov	x1, x8
    f8f8:      	mov	w2, #0x0                ; =0
    f8fc:      	ret

000000000000f900 <_wf_full_chain_heads$instance$1dd16a80e802bd86>:
    f900:      	stp	x22, x21, [sp, #-0x30]!
    f904:      	stp	x20, x19, [sp, #0x10]
    f908:      	stp	x29, x30, [sp, #0x20]
    f90c:      	mov	x19, x0
    f910:      	cbz	x0, 0xf938 <_wf_full_chain_heads$instance$1dd16a80e802bd86+0x38>
    f914:      	lsl	x21, x19, #3
    f918:      	mov	x0, x21
    f91c:      	bl	0xf91c <_wf_full_chain_heads$instance$1dd16a80e802bd86+0x1c>
		000000000000f91c:  ARM64_RELOC_BRANCH26	_malloc
    f920:      	cbz	x0, 0xf95c <_wf_full_chain_heads$instance$1dd16a80e802bd86+0x5c>
    f924:      	mov	x20, x0
    f928:      	mov	w1, #0xff               ; =255
    f92c:      	mov	x2, x21
    f930:      	bl	0xf930 <_wf_full_chain_heads$instance$1dd16a80e802bd86+0x30>
		000000000000f930:  ARM64_RELOC_BRANCH26	_memset
    f934:      	b	0xf940 <_wf_full_chain_heads$instance$1dd16a80e802bd86+0x40>
    f938:      	adrp	x20, 0xf000 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x24c>
		000000000000f938:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    f93c:      	add	x20, x20, #0x0
		000000000000f93c:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    f940:      	mov	x0, x19
    f944:      	mov	x1, x19
    f948:      	mov	x2, x20
    f94c:      	ldp	x29, x30, [sp, #0x20]
    f950:      	ldp	x20, x19, [sp, #0x10]
    f954:      	ldp	x22, x21, [sp], #0x30
    f958:      	ret
    f95c:      	bl	0xf95c <_wf_full_chain_heads$instance$1dd16a80e802bd86+0x5c>
		000000000000f95c:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000f960 <_wf_box_slots_new$instance$6587598b151ba54d>:
    f960:      	stp	x20, x19, [sp, #-0x20]!
    f964:      	stp	x29, x30, [sp, #0x10]
    f968:      	mov	x19, x0
    f96c:      	cbz	x0, 0xf998 <_wf_box_slots_new$instance$6587598b151ba54d+0x38>
    f970:      	add	x8, x19, x19, lsl #1
    f974:      	lsl	x0, x8, #3
    f978:      	bl	0xf978 <_wf_box_slots_new$instance$6587598b151ba54d+0x18>
		000000000000f978:  ARM64_RELOC_BRANCH26	_malloc
    f97c:      	mov	x2, x0
    f980:      	cbz	x0, 0xf9b4 <_wf_box_slots_new$instance$6587598b151ba54d+0x54>
    f984:      	mov	x0, #0x0                ; =0
    f988:      	mov	x1, x19
    f98c:      	ldp	x29, x30, [sp, #0x10]
    f990:      	ldp	x20, x19, [sp], #0x20
    f994:      	ret
    f998:      	adrp	x2, 0xf000 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x24c>
		000000000000f998:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    f99c:      	add	x2, x2, #0x0
		000000000000f99c:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    f9a0:      	mov	x0, #0x0                ; =0
    f9a4:      	mov	x1, x19
    f9a8:      	ldp	x29, x30, [sp, #0x10]
    f9ac:      	ldp	x20, x19, [sp], #0x20
    f9b0:      	ret
    f9b4:      	bl	0xf9b4 <_wf_box_slots_new$instance$6587598b151ba54d+0x54>
		000000000000f9b4:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000f9b8 <_wf_full_chain_find$instance$29255544f66aec6e>:
    f9b8:      	ldrb	w8, [x2, #0x8]
    f9bc:      	tbz	w8, #0x0, 0xf9d0 <_wf_full_chain_find$instance$29255544f66aec6e+0x18>
    f9c0:      	mov	x8, #0x0                ; =0
    f9c4:      	ldr	x10, [x0]
    f9c8:      	cbnz	x10, 0xfa18 <_wf_full_chain_find$instance$29255544f66aec6e+0x60>
    f9cc:      	b	0xfa68 <_wf_full_chain_find$instance$29255544f66aec6e+0xb0>
    f9d0:      	ldr	x8, [x2]
    f9d4:      	ldr	x9, [x1]
    f9d8:      	eor	x8, x9, x8
    f9dc:      	eor	x8, x8, x8, lsr #30
    f9e0:      	mov	x9, #0xe5b9             ; =58809
    f9e4:      	movk	x9, #0x1ce4, lsl #16
    f9e8:      	movk	x9, #0x476d, lsl #32
    f9ec:      	movk	x9, #0xbf58, lsl #48
    f9f0:      	mul	x8, x8, x9
    f9f4:      	eor	x8, x8, x8, lsr #27
    f9f8:      	mov	x9, #0x11eb             ; =4587
    f9fc:      	movk	x9, #0x1331, lsl #16
    fa00:      	movk	x9, #0x49bb, lsl #32
    fa04:      	movk	x9, #0x94d0, lsl #48
    fa08:      	mul	x8, x8, x9
    fa0c:      	eor	x8, x8, x8, lsr #31
    fa10:      	ldr	x10, [x0]
    fa14:      	cbz	x10, 0xfa68 <_wf_full_chain_find$instance$29255544f66aec6e+0xb0>
    fa18:      	ldr	x9, [x0, #0x18]
    fa1c:      	cbz	x9, 0xfa68 <_wf_full_chain_find$instance$29255544f66aec6e+0xb0>
    fa20:      	udiv	x11, x8, x10
    fa24:      	msub	x8, x11, x10, x8
    fa28:      	ldr	x10, [x0, #0x10]
    fa2c:      	add	x8, x10, x8, lsl #3
    fa30:      	mov	w10, #0x18              ; =24
    fa34:      	mov	x11, x9
    fa38:      	ldr	x8, [x8]
    fa3c:      	cmp	x8, x9
    fa40:      	b.hs	0xfa68 <_wf_full_chain_find$instance$29255544f66aec6e+0xb0>
    fa44:      	ldr	x12, [x0, #0x28]
    fa48:      	madd	x12, x8, x10, x12
    fa4c:      	ldr	x13, [x12]
    fa50:      	ldr	x14, [x1]
    fa54:      	cmp	x13, x14
    fa58:      	b.eq	0xfa7c <_wf_full_chain_find$instance$29255544f66aec6e+0xc4>
    fa5c:      	add	x8, x12, #0x10
    fa60:      	subs	x11, x11, #0x1
    fa64:      	b.ne	0xfa38 <_wf_full_chain_find$instance$29255544f66aec6e+0x80>
    fa68:      	mov	x8, #0x0                ; =0
    fa6c:      	mov	w0, #0x1                ; =1
    fa70:      	mov	x1, x8
    fa74:      	mov	w2, #0x0                ; =0
    fa78:      	ret
    fa7c:      	mov	w0, #0x0                ; =0
    fa80:      	mov	x1, x8
    fa84:      	mov	w2, #0x0                ; =0
    fa88:      	ret

000000000000fa8c <_wf_box_slots_new$instance$c630f48ffb9953bf>:
    fa8c:      	stp	x20, x19, [sp, #-0x20]!
    fa90:      	stp	x29, x30, [sp, #0x10]
    fa94:      	mov	x19, x0
    fa98:      	cbz	x0, 0xfac4 <_wf_box_slots_new$instance$c630f48ffb9953bf+0x38>
    fa9c:      	add	x8, x19, x19, lsl #4
    faa0:      	lsl	x0, x8, #4
    faa4:      	bl	0xfaa4 <_wf_box_slots_new$instance$c630f48ffb9953bf+0x18>
		000000000000faa4:  ARM64_RELOC_BRANCH26	_malloc
    faa8:      	mov	x2, x0
    faac:      	cbz	x0, 0xfae0 <_wf_box_slots_new$instance$c630f48ffb9953bf+0x54>
    fab0:      	mov	x0, #0x0                ; =0
    fab4:      	mov	x1, x19
    fab8:      	ldp	x29, x30, [sp, #0x10]
    fabc:      	ldp	x20, x19, [sp], #0x20
    fac0:      	ret
    fac4:      	adrp	x2, 0xf000 <_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65+0x24c>
		000000000000fac4:  ARM64_RELOC_PAGE21	l_.wf.empty.slots.payload
    fac8:      	add	x2, x2, #0x0
		000000000000fac8:  ARM64_RELOC_PAGEOFF12	l_.wf.empty.slots.payload
    facc:      	mov	x0, #0x0                ; =0
    fad0:      	mov	x1, x19
    fad4:      	ldp	x29, x30, [sp, #0x10]
    fad8:      	ldp	x20, x19, [sp], #0x20
    fadc:      	ret
    fae0:      	bl	0xfae0 <_wf_box_slots_new$instance$c630f48ffb9953bf+0x54>
		000000000000fae0:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000000fae4 <_wf_full_chain_find$instance$58dd6ca826103b6d>:
    fae4:      	ldrb	w8, [x2, #0x8]
    fae8:      	tbz	w8, #0x0, 0xfafc <_wf_full_chain_find$instance$58dd6ca826103b6d+0x18>
    faec:      	mov	x8, #0x0                ; =0
    faf0:      	ldr	x10, [x0]
    faf4:      	cbnz	x10, 0xfb44 <_wf_full_chain_find$instance$58dd6ca826103b6d+0x60>
    faf8:      	b	0xfb94 <_wf_full_chain_find$instance$58dd6ca826103b6d+0xb0>
    fafc:      	ldr	x8, [x2]
    fb00:      	ldr	x9, [x1]
    fb04:      	eor	x8, x9, x8
    fb08:      	eor	x8, x8, x8, lsr #30
    fb0c:      	mov	x9, #0xe5b9             ; =58809
    fb10:      	movk	x9, #0x1ce4, lsl #16
    fb14:      	movk	x9, #0x476d, lsl #32
    fb18:      	movk	x9, #0xbf58, lsl #48
    fb1c:      	mul	x8, x8, x9
    fb20:      	eor	x8, x8, x8, lsr #27
    fb24:      	mov	x9, #0x11eb             ; =4587
    fb28:      	movk	x9, #0x1331, lsl #16
    fb2c:      	movk	x9, #0x49bb, lsl #32
    fb30:      	movk	x9, #0x94d0, lsl #48
    fb34:      	mul	x8, x8, x9
    fb38:      	eor	x8, x8, x8, lsr #31
    fb3c:      	ldr	x10, [x0]
    fb40:      	cbz	x10, 0xfb94 <_wf_full_chain_find$instance$58dd6ca826103b6d+0xb0>
    fb44:      	ldr	x9, [x0, #0x18]
    fb48:      	cbz	x9, 0xfb94 <_wf_full_chain_find$instance$58dd6ca826103b6d+0xb0>
    fb4c:      	udiv	x11, x8, x10
    fb50:      	msub	x8, x11, x10, x8
    fb54:      	ldr	x10, [x0, #0x10]
    fb58:      	add	x8, x10, x8, lsl #3
    fb5c:      	mov	w10, #0x110             ; =272
    fb60:      	mov	x11, x9
    fb64:      	ldr	x8, [x8]
    fb68:      	cmp	x8, x9
    fb6c:      	b.hs	0xfb94 <_wf_full_chain_find$instance$58dd6ca826103b6d+0xb0>
    fb70:      	ldr	x12, [x0, #0x28]
    fb74:      	madd	x12, x8, x10, x12
    fb78:      	ldr	x13, [x12]
    fb7c:      	ldr	x14, [x1]
    fb80:      	cmp	x13, x14
    fb84:      	b.eq	0xfba8 <_wf_full_chain_find$instance$58dd6ca826103b6d+0xc4>
    fb88:      	add	x8, x12, #0x108
    fb8c:      	subs	x11, x11, #0x1
    fb90:      	b.ne	0xfb64 <_wf_full_chain_find$instance$58dd6ca826103b6d+0x80>
    fb94:      	mov	x8, #0x0                ; =0
    fb98:      	mov	w0, #0x1                ; =1
    fb9c:      	mov	x1, x8
    fba0:      	mov	w2, #0x0                ; =0
    fba4:      	ret
    fba8:      	mov	w0, #0x0                ; =0
    fbac:      	mov	x1, x8
    fbb0:      	mov	w2, #0x0                ; =0
    fbb4:      	ret

000000000000fbb8 <_wf_slots_new$instance$15df03c28018958d>:
    fbb8:      	mov	x0, #0x0                ; =0
    fbbc:      	mov	x1, #0x0                ; =0
    fbc0:      	mov	x2, #0x0                ; =0
    fbc4:      	ret

000000000000fbc8 <_wf_std.collections.hash_map.hash_map_is_available$instance$0ed342445dd803f3>:
    fbc8:      	ldr	w8, [x0]
    fbcc:      	cmp	w8, #0x2
    fbd0:      	cset	w0, lo
    fbd4:      	ret

000000000000fbd8 <_wf_slots_new$instance$8ac6e57475a1cbbb>:
    fbd8:      	movi.2d	v0, #0000000000000000
    fbdc:      	stp	q0, q0, [x0, #0xf0]
    fbe0:      	stp	q0, q0, [x0, #0xd0]
    fbe4:      	stp	q0, q0, [x0, #0xb0]
    fbe8:      	stp	q0, q0, [x0, #0x90]
    fbec:      	stp	q0, q0, [x0, #0x70]
    fbf0:      	stp	q0, q0, [x0, #0x50]
    fbf4:      	stp	q0, q0, [x0, #0x30]
    fbf8:      	stp	q0, q0, [x0, #0x10]
    fbfc:      	str	q0, [x0]
    fc00:      	ret

000000000000fc04 <_wf_std.collections.hash_map.hash_map_is_available$instance$d7a1a90c27bba449>:
    fc04:      	ldr	w8, [x0]
    fc08:      	cmp	w8, #0x2
    fc0c:      	cset	w0, lo
    fc10:      	ret

000000000000fc14 <_wf_place_back$instance$b128cca62ef74569>:
    fc14:      	ldr	x8, [x0]
    fc18:      	ldr	x9, [x0, #0x10]
    fc1c:      	str	x1, [x9, x8, lsl #3]
    fc20:      	add	x8, x8, #0x1
    fc24:      	str	x8, [x0]
    fc28:      	mov	w0, #0x0                ; =0
    fc2c:      	ret

000000000000fc30 <_wf_take_back$instance$af662f3d444ff600>:
    fc30:      	ldr	x8, [x0]
    fc34:      	sub	x8, x8, #0x1
    fc38:      	ldr	x9, [x0, #0x10]
    fc3c:      	mov	w10, #0x18              ; =24
    fc40:      	madd	x9, x8, x10, x9
    fc44:      	str	x8, [x0]
    fc48:      	ldp	x0, x1, [x9]
    fc4c:      	ldr	x2, [x9, #0x10]
    fc50:      	ret

000000000000fc54 <_wf_free_empty$instance$6dd04c483b97c747>:
    fc54:      	ldr	x8, [x0, #0x8]
    fc58:      	cbz	x8, 0xfc6c <_wf_free_empty$instance$6dd04c483b97c747+0x18>
    fc5c:      	stp	x29, x30, [sp, #-0x10]!
    fc60:      	ldr	x0, [x0, #0x10]
    fc64:      	bl	0xfc64 <_wf_free_empty$instance$6dd04c483b97c747+0x10>
		000000000000fc64:  ARM64_RELOC_BRANCH26	_free
    fc68:      	ldp	x29, x30, [sp], #0x10
    fc6c:      	mov	w0, #0x0                ; =0
    fc70:      	ret

000000000000fc74 <_wf_take_back$instance$b37b665fdb22758d>:
    fc74:      	ldr	x8, [x1]
    fc78:      	sub	x9, x8, #0x1
    fc7c:      	ldr	x8, [x1, #0x10]
    fc80:      	mov	w10, #0x110             ; =272
    fc84:      	madd	x8, x9, x10, x8
    fc88:      	str	x9, [x1]
    fc8c:      	mov	x1, x8
    fc90:      	mov	w2, #0x110              ; =272
    fc94:      	b	0xfc94 <_wf_take_back$instance$b37b665fdb22758d+0x20>
		000000000000fc94:  ARM64_RELOC_BRANCH26	_memmove

000000000000fc98 <_wf_free_empty$instance$85bf88ba50f5d3e1>:
    fc98:      	ldr	x8, [x0, #0x8]
    fc9c:      	cbz	x8, 0xfcb0 <_wf_free_empty$instance$85bf88ba50f5d3e1+0x18>
    fca0:      	stp	x29, x30, [sp, #-0x10]!
    fca4:      	ldr	x0, [x0, #0x10]
    fca8:      	bl	0xfca8 <_wf_free_empty$instance$85bf88ba50f5d3e1+0x10>
		000000000000fca8:  ARM64_RELOC_BRANCH26	_free
    fcac:      	ldp	x29, x30, [sp], #0x10
    fcb0:      	mov	w0, #0x0                ; =0
    fcb4:      	ret

000000000000fcb8 <_wf_take_back$instance$9985a87b1cb96650>:
    fcb8:      	ldr	x8, [x0]
    fcbc:      	sub	x8, x8, #0x1
    fcc0:      	ldr	x9, [x0, #0x10]
    fcc4:      	mov	w10, #0x18              ; =24
    fcc8:      	madd	x9, x8, x10, x9
    fccc:      	str	x8, [x0]
    fcd0:      	ldr	w0, [x9]
    fcd4:      	ldp	x1, x2, [x9, #0x8]
    fcd8:      	ret

000000000000fcdc <_wf_free_empty$instance$43608765810d87c7>:
    fcdc:      	ldr	x8, [x0, #0x8]
    fce0:      	cbz	x8, 0xfcf4 <_wf_free_empty$instance$43608765810d87c7+0x18>
    fce4:      	stp	x29, x30, [sp, #-0x10]!
    fce8:      	ldr	x0, [x0, #0x10]
    fcec:      	bl	0xfcec <_wf_free_empty$instance$43608765810d87c7+0x10>
		000000000000fcec:  ARM64_RELOC_BRANCH26	_free
    fcf0:      	ldp	x29, x30, [sp], #0x10
    fcf4:      	mov	w0, #0x0                ; =0
    fcf8:      	ret

000000000000fcfc <_wf_swap$instance$b45b69d9d0c6bbd0>:
    fcfc:      	ldr	q0, [x0]
    fd00:      	str	q0, [sp, #-0x20]!
    fd04:      	ldr	x8, [x0, #0x10]
    fd08:      	str	x8, [sp, #0x10]
    fd0c:      	ldr	x9, [x1, #0x10]
    fd10:      	ldr	q1, [x1]
    fd14:      	str	q1, [x0]
    fd18:      	str	x9, [x0, #0x10]
    fd1c:      	str	q0, [x1]
    fd20:      	str	x8, [x1, #0x10]
    fd24:      	mov	w0, #0x0                ; =0
    fd28:      	add	sp, sp, #0x20
    fd2c:      	ret

000000000000fd30 <_wf_take_back$instance$d5bb00f00cd669fb>:
    fd30:      	ldr	x8, [x1]
    fd34:      	sub	x9, x8, #0x1
    fd38:      	ldr	x8, [x1, #0x10]
    fd3c:      	mov	w10, #0x110             ; =272
    fd40:      	madd	x8, x9, x10, x8
    fd44:      	str	x9, [x1]
    fd48:      	mov	x1, x8
    fd4c:      	mov	w2, #0x110              ; =272
    fd50:      	b	0xfd50 <_wf_take_back$instance$d5bb00f00cd669fb+0x20>
		000000000000fd50:  ARM64_RELOC_BRANCH26	_memmove

000000000000fd54 <_wf_free_empty$instance$d692d011b23a4a18>:
    fd54:      	ldr	x8, [x0, #0x8]
    fd58:      	cbz	x8, 0xfd6c <_wf_free_empty$instance$d692d011b23a4a18+0x18>
    fd5c:      	stp	x29, x30, [sp, #-0x10]!
    fd60:      	ldr	x0, [x0, #0x10]
    fd64:      	bl	0xfd64 <_wf_free_empty$instance$d692d011b23a4a18+0x10>
		000000000000fd64:  ARM64_RELOC_BRANCH26	_free
    fd68:      	ldp	x29, x30, [sp], #0x10
    fd6c:      	mov	w0, #0x0                ; =0
    fd70:      	ret

000000000000fd74 <_wf_swap$instance$9eabc50a9cce2251>:
    fd74:      	sub	sp, sp, #0x140
    fd78:      	stp	x28, x27, [sp, #0x110]
    fd7c:      	stp	x20, x19, [sp, #0x120]
    fd80:      	stp	x29, x30, [sp, #0x130]
    fd84:      	mov	x19, x1
    fd88:      	mov	x20, x0
    fd8c:      	mov	x0, sp
    fd90:      	mov	x1, x20
    fd94:      	mov	w2, #0x110              ; =272
    fd98:      	bl	0xfd98 <_wf_swap$instance$9eabc50a9cce2251+0x24>
		000000000000fd98:  ARM64_RELOC_BRANCH26	_memcpy
    fd9c:      	mov	x0, x20
    fda0:      	mov	x1, x19
    fda4:      	mov	w2, #0x110              ; =272
    fda8:      	bl	0xfda8 <_wf_swap$instance$9eabc50a9cce2251+0x34>
		000000000000fda8:  ARM64_RELOC_BRANCH26	_memmove
    fdac:      	mov	x1, sp
    fdb0:      	mov	x0, x19
    fdb4:      	mov	w2, #0x110              ; =272
    fdb8:      	bl	0xfdb8 <_wf_swap$instance$9eabc50a9cce2251+0x44>
		000000000000fdb8:  ARM64_RELOC_BRANCH26	_memcpy
    fdbc:      	mov	w0, #0x0                ; =0
    fdc0:      	ldp	x29, x30, [sp, #0x130]
    fdc4:      	ldp	x20, x19, [sp, #0x120]
    fdc8:      	ldp	x28, x27, [sp, #0x110]
    fdcc:      	add	sp, sp, #0x140
    fdd0:      	ret

000000000000fdd4 <_wf_place_back$instance$af662f3d444ff600>:
    fdd4:      	ldr	x8, [x0]
    fdd8:      	ldr	x9, [x0, #0x10]
    fddc:      	mov	w10, #0x18              ; =24
    fde0:      	madd	x9, x8, x10, x9
    fde4:      	ldr	x10, [x1, #0x10]
    fde8:      	ldr	q0, [x1]
    fdec:      	str	q0, [x9]
    fdf0:      	str	x10, [x9, #0x10]
    fdf4:      	add	x8, x8, #0x1
    fdf8:      	str	x8, [x0]
    fdfc:      	mov	w0, #0x0                ; =0
    fe00:      	ret

000000000000fe04 <_wf_place_back$instance$b37b665fdb22758d>:
    fe04:      	stp	x20, x19, [sp, #-0x20]!
    fe08:      	stp	x29, x30, [sp, #0x10]
    fe0c:      	mov	x19, x0
    fe10:      	ldr	x20, [x0]
    fe14:      	ldr	x8, [x0, #0x10]
    fe18:      	mov	w9, #0x110              ; =272
    fe1c:      	madd	x0, x20, x9, x8
    fe20:      	mov	w2, #0x110              ; =272
    fe24:      	bl	0xfe24 <_wf_place_back$instance$b37b665fdb22758d+0x20>
		000000000000fe24:  ARM64_RELOC_BRANCH26	_memmove
    fe28:      	add	x8, x20, #0x1
    fe2c:      	str	x8, [x19]
    fe30:      	mov	w0, #0x0                ; =0
    fe34:      	ldp	x29, x30, [sp, #0x10]
    fe38:      	ldp	x20, x19, [sp], #0x20
    fe3c:      	ret

000000000000fe40 <_wf_swap$instance$e194368921a477a7>:
    fe40:      	ldr	x8, [x0]
    fe44:      	ldr	x9, [x1]
    fe48:      	str	x9, [x0]
    fe4c:      	str	x8, [x1]
    fe50:      	mov	w0, #0x0                ; =0
    fe54:      	ret

000000000000fe58 <_wf_place_back$instance$35b9fd6def1fa8a6>:
    fe58:      	ldr	x8, [x0]
    fe5c:      	ldr	x9, [x0, #0x10]
    fe60:      	mov	w10, #0x18              ; =24
    fe64:      	madd	x9, x8, x10, x9
    fe68:      	ldr	x10, [x1, #0x10]
    fe6c:      	ldr	q0, [x1]
    fe70:      	str	q0, [x9]
    fe74:      	str	x10, [x9, #0x10]
    fe78:      	add	x8, x8, #0x1
    fe7c:      	str	x8, [x0]
    fe80:      	mov	w0, #0x0                ; =0
    fe84:      	ret

000000000000fe88 <_wf_take_back$instance$35b9fd6def1fa8a6>:
    fe88:      	ldr	x8, [x0]
    fe8c:      	sub	x8, x8, #0x1
    fe90:      	ldr	x9, [x0, #0x10]
    fe94:      	mov	w10, #0x18              ; =24
    fe98:      	madd	x9, x8, x10, x9
    fe9c:      	str	x8, [x0]
    fea0:      	ldp	x0, x1, [x9]
    fea4:      	ldr	x2, [x9, #0x10]
    fea8:      	ret

000000000000feac <_wf_swap$instance$6587598b151ba54d>:
    feac:      	ldr	q0, [x0]
    feb0:      	str	q0, [sp, #-0x20]!
    feb4:      	ldr	x8, [x0, #0x10]
    feb8:      	str	x8, [sp, #0x10]
    febc:      	ldr	x9, [x1, #0x10]
    fec0:      	ldr	q1, [x1]
    fec4:      	str	q1, [x0]
    fec8:      	str	x9, [x0, #0x10]
    fecc:      	str	q0, [x1]
    fed0:      	str	x8, [x1, #0x10]
    fed4:      	mov	w0, #0x0                ; =0
    fed8:      	add	sp, sp, #0x20
    fedc:      	ret

000000000000fee0 <_wf_free_empty$instance$285db5ca5cf1fc4f>:
    fee0:      	ldr	x8, [x0, #0x8]
    fee4:      	cbz	x8, 0xfef8 <_wf_free_empty$instance$285db5ca5cf1fc4f+0x18>
    fee8:      	stp	x29, x30, [sp, #-0x10]!
    feec:      	ldr	x0, [x0, #0x10]
    fef0:      	bl	0xfef0 <_wf_free_empty$instance$285db5ca5cf1fc4f+0x10>
		000000000000fef0:  ARM64_RELOC_BRANCH26	_free
    fef4:      	ldp	x29, x30, [sp], #0x10
    fef8:      	mov	w0, #0x0                ; =0
    fefc:      	ret

000000000000ff00 <_wf_swap$instance$9fed7d4c5d7cc122>:
    ff00:      	sub	sp, sp, #0x110
    ff04:      	stp	x28, x27, [sp, #0x100]
    ff08:      	ldp	q0, q1, [x0, #0xc0]
    ff0c:      	stp	q0, q1, [sp, #0xc0]
    ff10:      	ldp	q0, q1, [x0, #0xe0]
    ff14:      	stp	q0, q1, [sp, #0xe0]
    ff18:      	ldp	q0, q1, [x0, #0x80]
    ff1c:      	stp	q0, q1, [sp, #0x80]
    ff20:      	ldp	q0, q1, [x0, #0xa0]
    ff24:      	stp	q0, q1, [sp, #0xa0]
    ff28:      	ldp	q0, q1, [x0, #0x40]
    ff2c:      	stp	q0, q1, [sp, #0x40]
    ff30:      	ldp	q0, q1, [x0, #0x60]
    ff34:      	stp	q0, q1, [sp, #0x60]
    ff38:      	ldp	q0, q1, [x0]
    ff3c:      	stp	q0, q1, [sp]
    ff40:      	ldp	q0, q1, [x0, #0x20]
    ff44:      	stp	q0, q1, [sp, #0x20]
    ff48:      	ldp	q0, q1, [x1]
    ff4c:      	ldp	q2, q3, [x1, #0x20]
    ff50:      	ldp	q4, q5, [x1, #0x40]
    ff54:      	ldp	q6, q7, [x1, #0x60]
    ff58:      	ldp	q16, q17, [x1, #0x80]
    ff5c:      	ldp	q18, q19, [x1, #0xa0]
    ff60:      	ldp	q20, q21, [x1, #0xc0]
    ff64:      	ldp	q22, q23, [x1, #0xe0]
    ff68:      	stp	q22, q23, [x0, #0xe0]
    ff6c:      	stp	q20, q21, [x0, #0xc0]
    ff70:      	stp	q18, q19, [x0, #0xa0]
    ff74:      	stp	q16, q17, [x0, #0x80]
    ff78:      	stp	q6, q7, [x0, #0x60]
    ff7c:      	stp	q4, q5, [x0, #0x40]
    ff80:      	stp	q2, q3, [x0, #0x20]
    ff84:      	stp	q0, q1, [x0]
    ff88:      	ldp	q0, q1, [sp, #0xc0]
    ff8c:      	stp	q0, q1, [x1, #0xc0]
    ff90:      	ldp	q0, q1, [sp, #0xe0]
    ff94:      	stp	q0, q1, [x1, #0xe0]
    ff98:      	ldp	q0, q1, [sp, #0x80]
    ff9c:      	stp	q0, q1, [x1, #0x80]
    ffa0:      	ldp	q0, q1, [sp, #0xa0]
    ffa4:      	stp	q0, q1, [x1, #0xa0]
    ffa8:      	ldp	q0, q1, [sp, #0x40]
    ffac:      	stp	q0, q1, [x1, #0x40]
    ffb0:      	ldp	q0, q1, [sp, #0x60]
    ffb4:      	stp	q0, q1, [x1, #0x60]
    ffb8:      	ldp	q0, q1, [sp]
    ffbc:      	stp	q0, q1, [x1]
    ffc0:      	ldp	q0, q1, [sp, #0x20]
    ffc4:      	stp	q0, q1, [x1, #0x20]
    ffc8:      	mov	w0, #0x0                ; =0
    ffcc:      	ldp	x28, x27, [sp, #0x100]
    ffd0:      	add	sp, sp, #0x110
    ffd4:      	ret

000000000000ffd8 <_wf_place_back$instance$96bbd2925df9d964>:
    ffd8:      	stp	x20, x19, [sp, #-0x20]!
    ffdc:      	stp	x29, x30, [sp, #0x10]
    ffe0:      	mov	x19, x0
    ffe4:      	ldr	x20, [x0]
    ffe8:      	ldr	x8, [x0, #0x10]
    ffec:      	mov	w9, #0x110              ; =272
    fff0:      	madd	x0, x20, x9, x8
    fff4:      	mov	w2, #0x110              ; =272
    fff8:      	bl	0xfff8 <_wf_place_back$instance$96bbd2925df9d964+0x20>
		000000000000fff8:  ARM64_RELOC_BRANCH26	_memmove
    fffc:      	add	x8, x20, #0x1
   10000:      	str	x8, [x19]
   10004:      	mov	w0, #0x0                ; =0
   10008:      	ldp	x29, x30, [sp, #0x10]
   1000c:      	ldp	x20, x19, [sp], #0x20
   10010:      	ret

0000000000010014 <_wf_take_back$instance$96bbd2925df9d964>:
   10014:      	ldr	x8, [x1]
   10018:      	sub	x9, x8, #0x1
   1001c:      	ldr	x8, [x1, #0x10]
   10020:      	mov	w10, #0x110             ; =272
   10024:      	madd	x8, x9, x10, x8
   10028:      	str	x9, [x1]
   1002c:      	mov	x1, x8
   10030:      	mov	w2, #0x110              ; =272
   10034:      	b	0x10034 <_wf_take_back$instance$96bbd2925df9d964+0x20>
		0000000000010034:  ARM64_RELOC_BRANCH26	_memmove

0000000000010038 <_wf_swap$instance$c630f48ffb9953bf>:
   10038:      	sub	sp, sp, #0x140
   1003c:      	stp	x28, x27, [sp, #0x110]
   10040:      	stp	x20, x19, [sp, #0x120]
   10044:      	stp	x29, x30, [sp, #0x130]
   10048:      	mov	x19, x1
   1004c:      	mov	x20, x0
   10050:      	mov	x0, sp
   10054:      	mov	x1, x20
   10058:      	mov	w2, #0x110              ; =272
   1005c:      	bl	0x1005c <_wf_swap$instance$c630f48ffb9953bf+0x24>
		000000000001005c:  ARM64_RELOC_BRANCH26	_memcpy
   10060:      	mov	x0, x20
   10064:      	mov	x1, x19
   10068:      	mov	w2, #0x110              ; =272
   1006c:      	bl	0x1006c <_wf_swap$instance$c630f48ffb9953bf+0x34>
		000000000001006c:  ARM64_RELOC_BRANCH26	_memmove
   10070:      	mov	x1, sp
   10074:      	mov	x0, x19
   10078:      	mov	w2, #0x110              ; =272
   1007c:      	bl	0x1007c <_wf_swap$instance$c630f48ffb9953bf+0x44>
		000000000001007c:  ARM64_RELOC_BRANCH26	_memcpy
   10080:      	mov	w0, #0x0                ; =0
   10084:      	ldp	x29, x30, [sp, #0x130]
   10088:      	ldp	x20, x19, [sp, #0x120]
   1008c:      	ldp	x28, x27, [sp, #0x110]
   10090:      	add	sp, sp, #0x140
   10094:      	ret

0000000000010098 <_wf_free_empty$instance$3b253a6d70922bfd>:
   10098:      	ldr	x8, [x0, #0x8]
   1009c:      	cbz	x8, 0x100b0 <_wf_free_empty$instance$3b253a6d70922bfd+0x18>
   100a0:      	stp	x29, x30, [sp, #-0x10]!
   100a4:      	ldr	x0, [x0, #0x10]
   100a8:      	bl	0x100a8 <_wf_free_empty$instance$3b253a6d70922bfd+0x10>
		00000000000100a8:  ARM64_RELOC_BRANCH26	_free
   100ac:      	ldp	x29, x30, [sp], #0x10
   100b0:      	mov	w0, #0x0                ; =0
   100b4:      	ret

00000000000100b8 <_wf_grow$instance$b45b69d9d0c6bbd0>:
   100b8:      	stp	x24, x23, [sp, #-0x40]!
   100bc:      	stp	x22, x21, [sp, #0x10]
   100c0:      	stp	x20, x19, [sp, #0x20]
   100c4:      	stp	x29, x30, [sp, #0x30]
   100c8:      	mov	x19, x1
   100cc:      	mov	x20, x0
   100d0:      	ldr	x21, [x0, #0x10]
   100d4:      	cbz	x1, 0x10124 <_wf_grow$instance$b45b69d9d0c6bbd0+0x6c>
   100d8:      	add	x8, x19, x19, lsl #1
   100dc:      	lsl	x1, x8, #3
   100e0:      	ldp	x22, x23, [x20]
   100e4:      	cmp	x22, x23
   100e8:      	ccmp	x23, #0x0, #0x4, eq
   100ec:      	b.ne	0x1012c <_wf_grow$instance$b45b69d9d0c6bbd0+0x74>
   100f0:      	mov	x0, x1
   100f4:      	bl	0x100f4 <_wf_grow$instance$b45b69d9d0c6bbd0+0x3c>
		00000000000100f4:  ARM64_RELOC_BRANCH26	_malloc
   100f8:      	cbz	x0, 0x10154 <_wf_grow$instance$b45b69d9d0c6bbd0+0x9c>
   100fc:      	cbz	x23, 0x10138 <_wf_grow$instance$b45b69d9d0c6bbd0+0x80>
   10100:      	add	x8, x22, x22, lsl #1
   10104:      	lsl	x2, x8, #3
   10108:      	mov	x22, x0
   1010c:      	mov	x1, x21
   10110:      	bl	0x10110 <_wf_grow$instance$b45b69d9d0c6bbd0+0x58>
		0000000000010110:  ARM64_RELOC_BRANCH26	_memcpy
   10114:      	mov	x0, x21
   10118:      	bl	0x10118 <_wf_grow$instance$b45b69d9d0c6bbd0+0x60>
		0000000000010118:  ARM64_RELOC_BRANCH26	_free
   1011c:      	mov	x0, x22
   10120:      	b	0x10138 <_wf_grow$instance$b45b69d9d0c6bbd0+0x80>
   10124:      	mov	x0, x21
   10128:      	b	0x10138 <_wf_grow$instance$b45b69d9d0c6bbd0+0x80>
   1012c:      	mov	x0, x21
   10130:      	bl	0x10130 <_wf_grow$instance$b45b69d9d0c6bbd0+0x78>
		0000000000010130:  ARM64_RELOC_BRANCH26	_realloc
   10134:      	cbz	x0, 0x10154 <_wf_grow$instance$b45b69d9d0c6bbd0+0x9c>
   10138:      	stp	x19, x0, [x20, #0x8]
   1013c:      	mov	w0, #0x0                ; =0
   10140:      	ldp	x29, x30, [sp, #0x30]
   10144:      	ldp	x20, x19, [sp, #0x20]
   10148:      	ldp	x22, x21, [sp, #0x10]
   1014c:      	ldp	x24, x23, [sp], #0x40
   10150:      	ret
   10154:      	bl	0x10154 <_wf_grow$instance$b45b69d9d0c6bbd0+0x9c>
		0000000000010154:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

0000000000010158 <_wf_place_back$instance$9985a87b1cb96650>:
   10158:      	ldr	x8, [x0]
   1015c:      	ldr	x9, [x0, #0x10]
   10160:      	mov	w10, #0x18              ; =24
   10164:      	madd	x9, x8, x10, x9
   10168:      	ldr	x10, [x1, #0x10]
   1016c:      	ldr	q0, [x1]
   10170:      	str	q0, [x9]
   10174:      	str	x10, [x9, #0x10]
   10178:      	add	x8, x8, #0x1
   1017c:      	str	x8, [x0]
   10180:      	mov	w0, #0x0                ; =0
   10184:      	ret

0000000000010188 <_wf_swap$instance$43608765810d87c7>:
   10188:      	ldr	q0, [x0]
   1018c:      	str	q0, [sp, #-0x20]!
   10190:      	ldr	x8, [x0, #0x10]
   10194:      	str	x8, [sp, #0x10]
   10198:      	ldr	x9, [x1, #0x10]
   1019c:      	ldr	q1, [x1]
   101a0:      	str	q1, [x0]
   101a4:      	str	x9, [x0, #0x10]
   101a8:      	str	q0, [x1]
   101ac:      	str	x8, [x1, #0x10]
   101b0:      	mov	w0, #0x0                ; =0
   101b4:      	add	sp, sp, #0x20
   101b8:      	ret

00000000000101bc <_wf_place_back$instance$a6542e06bf5acd99>:
   101bc:      	ldr	x8, [x0]
   101c0:      	add	x9, x0, x8, lsl #4
   101c4:      	ldr	q0, [x1]
   101c8:      	stur	q0, [x9, #0x8]
   101cc:      	add	x8, x8, #0x1
   101d0:      	str	x8, [x0]
   101d4:      	mov	w0, #0x0                ; =0
   101d8:      	ret

00000000000101dc <_wf_take_back$instance$a6542e06bf5acd99>:
   101dc:      	ldr	x8, [x0]
   101e0:      	sub	x8, x8, #0x1
   101e4:      	add	x9, x0, x8, lsl #4
   101e8:      	str	x8, [x0]
   101ec:      	ldp	x0, x1, [x9, #0x8]
   101f0:      	ret

00000000000101f4 <_wf_free_empty$instance$bb96e2f57d31495e>:
   101f4:      	mov	w0, #0x0                ; =0
   101f8:      	ret

00000000000101fc <_wf_grow$instance$9eabc50a9cce2251>:
   101fc:      	stp	x24, x23, [sp, #-0x40]!
   10200:      	stp	x22, x21, [sp, #0x10]
   10204:      	stp	x20, x19, [sp, #0x20]
   10208:      	stp	x29, x30, [sp, #0x30]
   1020c:      	mov	x19, x1
   10210:      	mov	x20, x0
   10214:      	ldr	x21, [x0, #0x10]
   10218:      	cbz	x1, 0x10268 <_wf_grow$instance$9eabc50a9cce2251+0x6c>
   1021c:      	add	x8, x19, x19, lsl #4
   10220:      	lsl	x1, x8, #4
   10224:      	ldp	x22, x23, [x20]
   10228:      	cmp	x22, x23
   1022c:      	ccmp	x23, #0x0, #0x4, eq
   10230:      	b.ne	0x10270 <_wf_grow$instance$9eabc50a9cce2251+0x74>
   10234:      	mov	x0, x1
   10238:      	bl	0x10238 <_wf_grow$instance$9eabc50a9cce2251+0x3c>
		0000000000010238:  ARM64_RELOC_BRANCH26	_malloc
   1023c:      	cbz	x0, 0x10298 <_wf_grow$instance$9eabc50a9cce2251+0x9c>
   10240:      	cbz	x23, 0x1027c <_wf_grow$instance$9eabc50a9cce2251+0x80>
   10244:      	add	x8, x22, x22, lsl #4
   10248:      	lsl	x2, x8, #4
   1024c:      	mov	x22, x0
   10250:      	mov	x1, x21
   10254:      	bl	0x10254 <_wf_grow$instance$9eabc50a9cce2251+0x58>
		0000000000010254:  ARM64_RELOC_BRANCH26	_memcpy
   10258:      	mov	x0, x21
   1025c:      	bl	0x1025c <_wf_grow$instance$9eabc50a9cce2251+0x60>
		000000000001025c:  ARM64_RELOC_BRANCH26	_free
   10260:      	mov	x0, x22
   10264:      	b	0x1027c <_wf_grow$instance$9eabc50a9cce2251+0x80>
   10268:      	mov	x0, x21
   1026c:      	b	0x1027c <_wf_grow$instance$9eabc50a9cce2251+0x80>
   10270:      	mov	x0, x21
   10274:      	bl	0x10274 <_wf_grow$instance$9eabc50a9cce2251+0x78>
		0000000000010274:  ARM64_RELOC_BRANCH26	_realloc
   10278:      	cbz	x0, 0x10298 <_wf_grow$instance$9eabc50a9cce2251+0x9c>
   1027c:      	stp	x19, x0, [x20, #0x8]
   10280:      	mov	w0, #0x0                ; =0
   10284:      	ldp	x29, x30, [sp, #0x30]
   10288:      	ldp	x20, x19, [sp, #0x20]
   1028c:      	ldp	x22, x21, [sp, #0x10]
   10290:      	ldp	x24, x23, [sp], #0x40
   10294:      	ret
   10298:      	bl	0x10298 <_wf_grow$instance$9eabc50a9cce2251+0x9c>
		0000000000010298:  ARM64_RELOC_BRANCH26	l_wf_resource_abort

000000000001029c <_wf_place_back$instance$d5bb00f00cd669fb>:
   1029c:      	stp	x20, x19, [sp, #-0x20]!
   102a0:      	stp	x29, x30, [sp, #0x10]
   102a4:      	mov	x19, x0
   102a8:      	ldr	x20, [x0]
   102ac:      	ldr	x8, [x0, #0x10]
   102b0:      	mov	w9, #0x110              ; =272
   102b4:      	madd	x0, x20, x9, x8
   102b8:      	mov	w2, #0x110              ; =272
   102bc:      	bl	0x102bc <_wf_place_back$instance$d5bb00f00cd669fb+0x20>
		00000000000102bc:  ARM64_RELOC_BRANCH26	_memmove
   102c0:      	add	x8, x20, #0x1
   102c4:      	str	x8, [x19]
   102c8:      	mov	w0, #0x0                ; =0
   102cc:      	ldp	x29, x30, [sp, #0x10]
   102d0:      	ldp	x20, x19, [sp], #0x20
   102d4:      	ret

00000000000102d8 <_wf_swap$instance$d692d011b23a4a18>:
   102d8:      	ldr	q0, [x0]
   102dc:      	str	q0, [sp, #-0x20]!
   102e0:      	ldr	x8, [x0, #0x10]
   102e4:      	str	x8, [sp, #0x10]
   102e8:      	ldr	x9, [x1, #0x10]
   102ec:      	ldr	q1, [x1]
   102f0:      	str	q1, [x0]
   102f4:      	str	x9, [x0, #0x10]
   102f8:      	str	q0, [x1]
   102fc:      	str	x8, [x1, #0x10]
   10300:      	mov	w0, #0x0                ; =0
   10304:      	add	sp, sp, #0x20
   10308:      	ret

000000000001030c <_wf_place_back$instance$c189ec082e7c2a1f>:
   1030c:      	stp	x20, x19, [sp, #-0x20]!
   10310:      	stp	x29, x30, [sp, #0x10]
   10314:      	mov	x19, x0
   10318:      	ldr	x20, [x0]
   1031c:      	mov	w8, #0x108              ; =264
   10320:      	madd	x8, x20, x8, x0
   10324:      	add	x0, x8, #0x8
   10328:      	mov	w2, #0x108              ; =264
   1032c:      	bl	0x1032c <_wf_place_back$instance$c189ec082e7c2a1f+0x20>
		000000000001032c:  ARM64_RELOC_BRANCH26	_memcpy
   10330:      	add	x8, x20, #0x1
   10334:      	str	x8, [x19]
   10338:      	mov	w0, #0x0                ; =0
   1033c:      	ldp	x29, x30, [sp, #0x10]
   10340:      	ldp	x20, x19, [sp], #0x20
   10344:      	ret

0000000000010348 <_wf_take_back$instance$c189ec082e7c2a1f>:
   10348:      	ldr	x8, [x1]
   1034c:      	sub	x9, x8, #0x1
   10350:      	mov	w10, #0x108             ; =264
   10354:      	madd	x8, x8, x10, x1
   10358:      	sub	x8, x8, #0x100
   1035c:      	str	x9, [x1]
   10360:      	mov	x1, x8
   10364:      	mov	w2, #0x108              ; =264
   10368:      	b	0x10368 <_wf_take_back$instance$c189ec082e7c2a1f+0x20>
		0000000000010368:  ARM64_RELOC_BRANCH26	_memcpy

000000000001036c <_wf_free_empty$instance$41f1fc367c8c34ad>:
   1036c:      	mov	w0, #0x0                ; =0
   10370:      	ret

0000000000010374 <_wf__floor_run>:
   10374:      	b	0x10374 <_wf__floor_run>
		0000000000010374:  ARM64_RELOC_BRANCH26	_wf__main_body

0000000000010378 <_wf__main_body>:
   10378:      	sub	sp, sp, #0x30
   1037c:      	stp	x29, x30, [sp, #0x20]
   10380:      	mov	w0, #0x3                ; =3
   10384:      	mov	w1, #0x2                ; =2
   10388:      	mov	w2, #0x2                ; =2
   1038c:      	mov	w3, #0x11               ; =17
   10390:      	mov	x5, #0x0                ; =0
   10394:      	mov	w4, #0x7                ; =7
   10398:      	bl	0x10398 <_wf__main_body+0x20>
		0000000000010398:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd
   1039c:      	mov	w0, #0x3                ; =3
   103a0:      	mov	w1, #0x2                ; =2
   103a4:      	mov	w2, #0x2                ; =2
   103a8:      	mov	w3, #0x11               ; =17
   103ac:      	mov	w4, #0x3                ; =3
   103b0:      	mov	w5, #0x1                ; =1
   103b4:      	bl	0x103b4 <_wf__main_body+0x3c>
		00000000000103b4:  ARM64_RELOC_BRANCH26	_wf_map_cost_library_trace$instance$4250cb78d3f44027
   103b8:      	mov	x0, sp
   103bc:      	mov	w1, #0x0                ; =0
   103c0:      	bl	0x103c0 <_wf__main_body+0x48>
		00000000000103c0:  ARM64_RELOC_BRANCH26	_wf_std.process.exit_status
   103c4:      	mov	x0, sp
   103c8:      	bl	0x103c8 <_wf__main_body+0x50>
		00000000000103c8:  ARM64_RELOC_BRANCH26	_wf__ordinary_exit_code
   103cc:      	and	w0, w0, #0xff
   103d0:      	ldp	x29, x30, [sp, #0x20]
   103d4:      	add	sp, sp, #0x30
   103d8:      	ret

00000000000103dc <_main>:
   103dc:      	b	0x103dc <_main>
		00000000000103dc:  ARM64_RELOC_BRANCH26	_wf__floor_run
