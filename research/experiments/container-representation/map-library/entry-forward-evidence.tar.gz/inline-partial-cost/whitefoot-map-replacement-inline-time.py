import pathlib,hashlib,subprocess,time,json,csv,os
assert os.environ.get('WHITEFOOT_CHECK_OWNER')
root=pathlib.Path.cwd();d=root/'research/experiments/container-representation/map-library/.build/lookup-api/mutation-screen';base=pathlib.Path('/private/tmp/whitefoot-map-replacement-inline');out=base/'partial-cost';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
images={'control':d/'entry-forward-timed','candidate':base/'candidate-timed'}
meta={'criterion_sha256':sha(base/'partial-cost-criterion.txt'),'images_before':{str(p):sha(p) for p in images.values()},'work':1048576,'order':['control0','candidate0','candidate1','control1'],'stages':[]}
for a,c in [('control',0),('candidate',0),('candidate',1),('control',1)]:
 label=a+'-cohort-'+str(c);args=[str(images[a]),'measure',str(c),'1048576'];start=time.monotonic();print('START',label,flush=True)
 with (out/(label+'.csv')).open('w') as stdout,(out/(label+'.stderr')).open('w') as stderr:
  try:p=subprocess.run(args,stdout=stdout,stderr=stderr,timeout=180);code=p.returncode
  except subprocess.TimeoutExpired:code=None
 meta['stages'].append({'label':label,'argv':args,'exit':code,'seconds':time.monotonic()-start});(out/'metadata.json').write_text(json.dumps(meta,indent=2));print('END',label,code,flush=True);assert code==0
 rows=list(csv.DictReader((out/(label+'.csv')).open()));assert len(rows)==288
meta['images_after']={str(p):sha(p) for p in images.values()};assert meta['images_after']==meta['images_before'];(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');print('Complete: 1152 new diagnostic samples; original failed native criterion preserved.',flush=True)
