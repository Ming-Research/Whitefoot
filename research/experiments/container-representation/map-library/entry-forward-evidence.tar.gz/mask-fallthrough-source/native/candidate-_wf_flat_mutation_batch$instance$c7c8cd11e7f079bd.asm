00000001000a3c20 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd>:
1000a3c20:     	mov	x9, #0xe5b9             ; =58809
1000a3c24:     	movk	x9, #0x1ce4, lsl #16
1000a3c28:     	movk	x9, #0x476d, lsl #32
1000a3c2c:     	movk	x9, #0xbf58, lsl #48
1000a3c30:     	mov	x8, #0x11eb             ; =4587
1000a3c34:     	movk	x8, #0x1331, lsl #16
1000a3c38:     	movk	x8, #0x49bb, lsl #32
1000a3c3c:     	movk	x8, #0x94d0, lsl #48
1000a3c40:     	ldr	x10, [x0, #0x38]
1000a3c44:     	cbz	x1, 0x1000a3f3c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x31c>
1000a3c48:     	ldp	x12, x11, [x0, #0x40]
1000a3c4c:     	cbz	x12, 0x1000a3f34 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x314>
1000a3c50:     	sub	sp, sp, #0x70
1000a3c54:     	stp	x28, x27, [sp, #0x10]
1000a3c58:     	stp	x26, x25, [sp, #0x20]
1000a3c5c:     	stp	x24, x23, [sp, #0x30]
1000a3c60:     	stp	x22, x21, [sp, #0x40]
1000a3c64:     	stp	x20, x19, [sp, #0x50]
1000a3c68:     	stp	x29, x30, [sp, #0x60]
1000a3c6c:     	mov	x13, #0x0               ; =0
1000a3c70:     	ldp	x19, x14, [x0, #0x20]
1000a3c74:     	ldrb	w15, [x0, #0x30]
1000a3c78:     	mov	w16, #0x1               ; =1
1000a3c7c:     	mov	w17, #0x18              ; =24
1000a3c80:     	mov	w3, #0x2                ; =2
1000a3c84:     	mov	w4, #0x83               ; =131
1000a3c88:     	mov	x6, x10
1000a3c8c:     	ldr	x7, [x0, #0x18]
1000a3c90:     	b	0x1000a3ca4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x84>
1000a3c94:     	str	x11, [x0, #0x48]
1000a3c98:     	add	x13, x13, #0x1
1000a3c9c:     	cmp	x13, x1
1000a3ca0:     	b.eq	0x1000a3f00 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2e0>
1000a3ca4:     	mov	x20, #0x0               ; =0
1000a3ca8:     	add	x11, x11, #0x1
1000a3cac:     	madd	x21, x11, x12, x10
1000a3cb0:     	b	0x1000a3cd8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xb8>
1000a3cb4:     	strb	w16, [sp, #0xc]
1000a3cb8:     	tst	w16, #0x1
1000a3cbc:     	cinc	x24, x16, ne
1000a3cc0:     	madd	x5, x6, x4, x22
1000a3cc4:     	add	x5, x5, x24
1000a3cc8:     	madd	x6, x5, x4, x23
1000a3ccc:     	add	x20, x20, #0x1
1000a3cd0:     	cmp	x20, x12
1000a3cd4:     	b.eq	0x1000a3c94 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x74>
1000a3cd8:     	orr	x22, x16, x20, lsl #1
1000a3cdc:     	cbz	x2, 0x1000a3da4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x184>
1000a3ce0:     	cbz	x7, 0x1000a3e3c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x21c>
1000a3ce4:     	tbz	w15, #0x0, 0x1000a3cf8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xd8>
1000a3ce8:     	mov	x24, #0x0               ; =0
1000a3cec:     	ldr	x23, [x0]
1000a3cf0:     	cbnz	x23, 0x1000a3d18 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xf8>
1000a3cf4:     	b	0x1000a3e3c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x21c>
1000a3cf8:     	eor	x5, x14, x22
1000a3cfc:     	eor	x5, x5, x5, lsr #30
1000a3d00:     	mul	x5, x5, x9
1000a3d04:     	eor	x5, x5, x5, lsr #27
1000a3d08:     	mul	x5, x5, x8
1000a3d0c:     	eor	x24, x5, x5, lsr #31
1000a3d10:     	ldr	x23, [x0]
1000a3d14:     	cbz	x23, 0x1000a3e3c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x21c>
1000a3d18:     	sub	x5, x23, #0x1
1000a3d1c:     	and	x25, x5, x24
1000a3d20:     	udiv	x26, x24, x23
1000a3d24:     	msub	x24, x26, x23, x24
1000a3d28:     	tst	x23, x5
1000a3d2c:     	csel	x24, x25, x24, eq
1000a3d30:     	ldr	x25, [x0, #0x10]
1000a3d34:     	mov	x26, x23
1000a3d38:     	b	0x1000a3d50 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x130>
1000a3d3c:     	add	x5, x24, #0x1
1000a3d40:     	cmp	x5, x23
1000a3d44:     	csinc	x24, xzr, x24, hs
1000a3d48:     	subs	x26, x26, #0x1
1000a3d4c:     	b.eq	0x1000a3e3c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x21c>
1000a3d50:     	madd	x27, x24, x17, x25
1000a3d54:     	ldr	w28, [x27]
1000a3d58:     	cmp	w28, #0x1
1000a3d5c:     	b.eq	0x1000a3d3c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x11c>
1000a3d60:     	cmp	w28, #0x2
1000a3d64:     	b.ne	0x1000a3e3c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x21c>
1000a3d68:     	ldr	x5, [x27, #0x8]
1000a3d6c:     	cmp	x5, x22
1000a3d70:     	b.ne	0x1000a3d3c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x11c>
1000a3d74:     	ldr	x5, [x27, #0x10]
1000a3d78:     	str	w16, [x27]
1000a3d7c:     	sub	x7, x7, #0x1
1000a3d80:     	stp	xzr, xzr, [x27, #0x8]
1000a3d84:     	adds	x19, x19, #0x1
1000a3d88:     	csinv	x19, x19, xzr, lo
1000a3d8c:     	stp	x7, x19, [x0, #0x18]
1000a3d90:     	mul	x23, x22, x4
1000a3d94:     	mov	w24, #0x4309            ; =17161
1000a3d98:     	madd	x6, x6, x24, x23
1000a3d9c:     	add	x5, x6, x5
1000a3da0:     	add	x6, x5, #0x83
1000a3da4:     	tbz	w15, #0x0, 0x1000a3e44 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x224>
1000a3da8:     	mov	x25, #0x0               ; =0
1000a3dac:     	add	x23, x21, x20
1000a3db0:     	ldr	x24, [x0]
1000a3db4:     	cbz	x24, 0x1000a3e68 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x248>
1000a3db8:     	sub	x5, x24, #0x1
1000a3dbc:     	and	x26, x5, x25
1000a3dc0:     	udiv	x27, x25, x24
1000a3dc4:     	msub	x25, x27, x24, x25
1000a3dc8:     	tst	x24, x5
1000a3dcc:     	csel	x26, x26, x25, eq
1000a3dd0:     	ldr	x27, [x0, #0x10]
1000a3dd4:     	mov	x28, x24
1000a3dd8:     	mov	x25, x24
1000a3ddc:     	b	0x1000a3dfc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1dc>
1000a3de0:     	cmp	x25, x24
1000a3de4:     	csel	x25, x26, x25, eq
1000a3de8:     	add	x5, x26, #0x1
1000a3dec:     	cmp	x5, x24
1000a3df0:     	csinc	x26, xzr, x26, hs
1000a3df4:     	subs	x28, x28, #0x1
1000a3df8:     	b.eq	0x1000a3e6c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x24c>
1000a3dfc:     	madd	x30, x26, x17, x27
1000a3e00:     	ldr	w5, [x30]
1000a3e04:     	cmp	w5, #0x1
1000a3e08:     	b.eq	0x1000a3de0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1c0>
1000a3e0c:     	cmp	w5, #0x2
1000a3e10:     	b.ne	0x1000a3eec <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2cc>
1000a3e14:     	ldr	x5, [x30, #0x8]
1000a3e18:     	cmp	x5, x22
1000a3e1c:     	b.ne	0x1000a3de8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1c8>
1000a3e20:     	ldr	x5, [x30, #0x10]
1000a3e24:     	str	w3, [x30]
1000a3e28:     	str	x23, [x30, #0x10]
1000a3e2c:     	strb	wzr, [sp, #0xc]
1000a3e30:     	mov	w24, #0x1               ; =1
1000a3e34:     	mov	x23, x5
1000a3e38:     	b	0x1000a3cc0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xa0>
1000a3e3c:     	mul	x6, x6, x4
1000a3e40:     	tbnz	w15, #0x0, 0x1000a3da8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x188>
1000a3e44:     	eor	x5, x14, x22
1000a3e48:     	eor	x5, x5, x5, lsr #30
1000a3e4c:     	mul	x5, x5, x9
1000a3e50:     	eor	x5, x5, x5, lsr #27
1000a3e54:     	mul	x5, x5, x8
1000a3e58:     	eor	x25, x5, x5, lsr #31
1000a3e5c:     	add	x23, x21, x20
1000a3e60:     	ldr	x24, [x0]
1000a3e64:     	cbnz	x24, 0x1000a3db8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x198>
1000a3e68:     	mov	x25, #0x0               ; =0
1000a3e6c:     	cmp	x25, x24
1000a3e70:     	b.hs	0x1000a3cb4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
1000a3e74:     	cmp	x7, #0x2, lsl #12       ; =0x2000
1000a3e78:     	b.hs	0x1000a3cb4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
1000a3e7c:     	add	x7, x7, #0x1
1000a3e80:     	str	x7, [x0, #0x18]
1000a3e84:     	ldr	x5, [x0, #0x10]
1000a3e88:     	madd	x24, x25, x17, x5
1000a3e8c:     	ldr	w27, [x24]
1000a3e90:     	cmp	w27, #0x1
1000a3e94:     	b.ne	0x1000a3eb0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x290>
1000a3e98:     	subs	x5, x19, #0x1
1000a3e9c:     	csel	x19, xzr, x5, lo
1000a3ea0:     	str	x19, [x0, #0x20]
1000a3ea4:     	str	w3, [x24]
1000a3ea8:     	stp	x22, x23, [x24, #0x8]
1000a3eac:     	b	0x1000a3ed4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2b4>
1000a3eb0:     	ldp	x25, x26, [x24, #0x8]
1000a3eb4:     	str	w3, [x24]
1000a3eb8:     	stp	x22, x23, [x24, #0x8]
1000a3ebc:     	cbz	w27, 0x1000a3ed4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2b4>
1000a3ec0:     	strb	wzr, [sp, #0xc]
1000a3ec4:     	mov	w24, #0x1               ; =1
1000a3ec8:     	mov	x23, x26
1000a3ecc:     	mov	x22, x25
1000a3ed0:     	b	0x1000a3cc0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xa0>
1000a3ed4:     	strb	wzr, [sp, #0xc]
1000a3ed8:     	mul	x6, x6, x4
1000a3edc:     	add	x20, x20, #0x1
1000a3ee0:     	cmp	x20, x12
1000a3ee4:     	b.ne	0x1000a3cd8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xb8>
1000a3ee8:     	b	0x1000a3c94 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x74>
1000a3eec:     	cmp	x25, x24
1000a3ef0:     	csel	x25, x26, x25, eq
1000a3ef4:     	cmp	x25, x24
1000a3ef8:     	b.lo	0x1000a3e74 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x254>
1000a3efc:     	b	0x1000a3cb4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
1000a3f00:     	ldp	x29, x30, [sp, #0x60]
1000a3f04:     	ldp	x20, x19, [sp, #0x50]
1000a3f08:     	ldp	x22, x21, [sp, #0x40]
1000a3f0c:     	ldp	x24, x23, [sp, #0x30]
1000a3f10:     	ldp	x26, x25, [sp, #0x20]
1000a3f14:     	ldp	x28, x27, [sp, #0x10]
1000a3f18:     	add	sp, sp, #0x70
1000a3f1c:     	eor	x10, x6, x6, lsr #30
1000a3f20:     	mul	x9, x10, x9
1000a3f24:     	eor	x9, x9, x9, lsr #27
1000a3f28:     	mul	x8, x9, x8
1000a3f2c:     	eor	x0, x8, x8, lsr #31
1000a3f30:     	ret
1000a3f34:     	add	x11, x11, x1
1000a3f38:     	str	x11, [x0, #0x48]
1000a3f3c:     	eor	x10, x10, x10, lsr #30
1000a3f40:     	mul	x9, x10, x9
1000a3f44:     	eor	x9, x9, x9, lsr #27
1000a3f48:     	mul	x8, x9, x8
1000a3f4c:     	eor	x0, x8, x8, lsr #31
1000a3f50:     	ret

