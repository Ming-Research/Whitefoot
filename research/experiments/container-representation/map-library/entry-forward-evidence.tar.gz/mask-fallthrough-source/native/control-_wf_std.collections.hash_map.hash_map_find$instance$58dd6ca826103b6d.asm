00000001000ab3f0 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d>:
1000ab3f0:     	ldrb	w8, [x2, #0x8]
1000ab3f4:     	tbz	w8, #0x0, 0x1000ab408 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0x18>
1000ab3f8:     	mov	x8, #0x0                ; =0
1000ab3fc:     	ldr	x9, [x0]
1000ab400:     	cbnz	x9, 0x1000ab450 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0x60>
1000ab404:     	b	0x1000ab4c8 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0xd8>
1000ab408:     	ldr	x8, [x2]
1000ab40c:     	ldr	x9, [x1]
1000ab410:     	eor	x8, x9, x8
1000ab414:     	eor	x8, x8, x8, lsr #30
1000ab418:     	mov	x9, #0xe5b9             ; =58809
1000ab41c:     	movk	x9, #0x1ce4, lsl #16
1000ab420:     	movk	x9, #0x476d, lsl #32
1000ab424:     	movk	x9, #0xbf58, lsl #48
1000ab428:     	mul	x8, x8, x9
1000ab42c:     	eor	x8, x8, x8, lsr #27
1000ab430:     	mov	x9, #0x11eb             ; =4587
1000ab434:     	movk	x9, #0x1331, lsl #16
1000ab438:     	movk	x9, #0x49bb, lsl #32
1000ab43c:     	movk	x9, #0x94d0, lsl #48
1000ab440:     	mul	x8, x8, x9
1000ab444:     	eor	x8, x8, x8, lsr #31
1000ab448:     	ldr	x9, [x0]
1000ab44c:     	cbz	x9, 0x1000ab4c8 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0xd8>
1000ab450:     	sub	x10, x9, #0x1
1000ab454:     	tst	x9, x10
1000ab458:     	b.eq	0x1000ab468 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0x78>
1000ab45c:     	udiv	x10, x8, x9
1000ab460:     	msub	x8, x10, x9, x8
1000ab464:     	b	0x1000ab46c <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0x7c>
1000ab468:     	and	x8, x10, x8
1000ab46c:     	ldr	x10, [x0, #0x10]
1000ab470:     	mov	w11, #0x110             ; =272
1000ab474:     	mov	x12, x9
1000ab478:     	b	0x1000ab490 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0xa0>
1000ab47c:     	add	x13, x8, #0x1
1000ab480:     	cmp	x13, x9
1000ab484:     	csinc	x8, xzr, x8, hs
1000ab488:     	subs	x12, x12, #0x1
1000ab48c:     	b.eq	0x1000ab4c8 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0xd8>
1000ab490:     	madd	x14, x8, x11, x10
1000ab494:     	ldr	w13, [x14]
1000ab498:     	cmp	w13, #0x1
1000ab49c:     	b.eq	0x1000ab47c <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0x8c>
1000ab4a0:     	cmp	w13, #0x2
1000ab4a4:     	b.ne	0x1000ab4dc <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0xec>
1000ab4a8:     	ldr	x13, [x14, #0x8]
1000ab4ac:     	ldr	x14, [x1]
1000ab4b0:     	cmp	x13, x14
1000ab4b4:     	b.ne	0x1000ab47c <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0x8c>
1000ab4b8:     	mov	w0, #0x0                ; =0
1000ab4bc:     	mov	x1, x8
1000ab4c0:     	mov	w2, #0x0                ; =0
1000ab4c4:     	ret
1000ab4c8:     	mov	x8, #0x0                ; =0
1000ab4cc:     	mov	w0, #0x1                ; =1
1000ab4d0:     	mov	x1, x8
1000ab4d4:     	mov	w2, #0x0                ; =0
1000ab4d8:     	ret
1000ab4dc:     	mov	w0, #0x1                ; =1
1000ab4e0:     	mov	x8, x13
1000ab4e4:     	mov	x1, x8
1000ab4e8:     	mov	w2, #0x0                ; =0
1000ab4ec:     	ret

