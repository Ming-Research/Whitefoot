00000001000a8478 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d>:
1000a8478:     	ldr	x8, [x1, #0x18]
1000a847c:     	cbz	x8, 0x1000a85f4 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x17c>
1000a8480:     	ldrb	w9, [x3, #0x8]
1000a8484:     	tbz	w9, #0x0, 0x1000a8498 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x20>
1000a8488:     	mov	x9, #0x0                ; =0
1000a848c:     	ldr	x11, [x1]
1000a8490:     	cbnz	x11, 0x1000a84e0 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x68>
1000a8494:     	b	0x1000a85f4 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x17c>
1000a8498:     	ldr	x9, [x3]
1000a849c:     	ldr	x10, [x2]
1000a84a0:     	eor	x9, x10, x9
1000a84a4:     	eor	x9, x9, x9, lsr #30
1000a84a8:     	mov	x10, #0xe5b9            ; =58809
1000a84ac:     	movk	x10, #0x1ce4, lsl #16
1000a84b0:     	movk	x10, #0x476d, lsl #32
1000a84b4:     	movk	x10, #0xbf58, lsl #48
1000a84b8:     	mul	x9, x9, x10
1000a84bc:     	eor	x9, x9, x9, lsr #27
1000a84c0:     	mov	x10, #0x11eb            ; =4587
1000a84c4:     	movk	x10, #0x1331, lsl #16
1000a84c8:     	movk	x10, #0x49bb, lsl #32
1000a84cc:     	movk	x10, #0x94d0, lsl #48
1000a84d0:     	mul	x9, x9, x10
1000a84d4:     	eor	x9, x9, x9, lsr #31
1000a84d8:     	ldr	x11, [x1]
1000a84dc:     	cbz	x11, 0x1000a85f4 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x17c>
1000a84e0:     	sub	x10, x11, #0x1
1000a84e4:     	and	x12, x10, x9
1000a84e8:     	udiv	x13, x9, x11
1000a84ec:     	msub	x9, x13, x11, x9
1000a84f0:     	tst	x11, x10
1000a84f4:     	csel	x12, x12, x9, eq
1000a84f8:     	ldr	x13, [x1, #0x10]
1000a84fc:     	mov	w14, #0x110             ; =272
1000a8500:     	mov	x15, x11
1000a8504:     	b	0x1000a851c <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0xa4>
1000a8508:     	add	x9, x12, #0x1
1000a850c:     	cmp	x9, x11
1000a8510:     	csinc	x12, xzr, x12, hs
1000a8514:     	subs	x15, x15, #0x1
1000a8518:     	b.eq	0x1000a85f4 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x17c>
1000a851c:     	madd	x9, x12, x14, x13
1000a8520:     	ldr	w10, [x9]
1000a8524:     	cmp	w10, #0x1
1000a8528:     	b.eq	0x1000a8508 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x90>
1000a852c:     	cmp	w10, #0x2
1000a8530:     	b.ne	0x1000a85f4 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x17c>
1000a8534:     	ldr	x10, [x9, #0x8]
1000a8538:     	ldr	x16, [x2]
1000a853c:     	cmp	x10, x16
1000a8540:     	b.ne	0x1000a8508 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x90>
1000a8544:     	mov	w11, #0x1               ; =1
1000a8548:     	str	w11, [x9]
1000a854c:     	sub	x8, x8, #0x1
1000a8550:     	ldp	q0, q1, [x9, #0x10]
1000a8554:     	ldp	q2, q3, [x9, #0x30]
1000a8558:     	ldp	q4, q5, [x9, #0x50]
1000a855c:     	ldp	q6, q7, [x9, #0x70]
1000a8560:     	ldp	q16, q17, [x9, #0x90]
1000a8564:     	ldp	q18, q19, [x9, #0xb0]
1000a8568:     	ldp	q20, q21, [x9, #0xd0]
1000a856c:     	ldp	q22, q23, [x9, #0xf0]
1000a8570:     	movi.2d	v24, #0000000000000000
1000a8574:     	stur	q24, [x9, #0x18]
1000a8578:     	stur	q24, [x9, #0x28]
1000a857c:     	stur	q24, [x9, #0x38]
1000a8580:     	stur	q24, [x9, #0x48]
1000a8584:     	stur	q24, [x9, #0x58]
1000a8588:     	stur	q24, [x9, #0x68]
1000a858c:     	stur	q24, [x9, #0x78]
1000a8590:     	stur	q24, [x9, #0x88]
1000a8594:     	stur	q24, [x9, #0x98]
1000a8598:     	stur	q24, [x9, #0xa8]
1000a859c:     	stur	q24, [x9, #0xb8]
1000a85a0:     	stur	q24, [x9, #0xc8]
1000a85a4:     	stur	q24, [x9, #0xd8]
1000a85a8:     	stur	q24, [x9, #0xe8]
1000a85ac:     	stur	q24, [x9, #0xf8]
1000a85b0:     	stur	q24, [x9, #0x8]
1000a85b4:     	str	xzr, [x9, #0x108]
1000a85b8:     	ldr	x9, [x1, #0x20]
1000a85bc:     	adds	x9, x9, #0x1
1000a85c0:     	csinv	x9, x9, xzr, lo
1000a85c4:     	stp	x8, x9, [x1, #0x18]
1000a85c8:     	stp	xzr, x10, [x0]
1000a85cc:     	str	w11, [x0]
1000a85d0:     	stp	q0, q1, [x0, #0x10]
1000a85d4:     	stp	q2, q3, [x0, #0x30]
1000a85d8:     	stp	q4, q5, [x0, #0x50]
1000a85dc:     	stp	q6, q7, [x0, #0x70]
1000a85e0:     	stp	q16, q17, [x0, #0x90]
1000a85e4:     	stp	q18, q19, [x0, #0xb0]
1000a85e8:     	stp	q20, q21, [x0, #0xd0]
1000a85ec:     	stp	q22, q23, [x0, #0xf0]
1000a85f0:     	ret
1000a85f4:     	movi.2d	v0, #0000000000000000
1000a85f8:     	stp	q0, q0, [x0, #0xf0]
1000a85fc:     	stp	q0, q0, [x0, #0xd0]
1000a8600:     	stp	q0, q0, [x0, #0xb0]
1000a8604:     	stp	q0, q0, [x0, #0x90]
1000a8608:     	stp	q0, q0, [x0, #0x70]
1000a860c:     	stp	q0, q0, [x0, #0x50]
1000a8610:     	stp	q0, q0, [x0, #0x30]
1000a8614:     	stp	q0, q0, [x0, #0x10]
1000a8618:     	str	q0, [x0]
1000a861c:     	ret

