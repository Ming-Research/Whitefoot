00000001000a82ec <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d>:
1000a82ec:     	mov	x9, x3
1000a82f0:     	mov	x3, x2
1000a82f4:     	ldrb	w8, [x4, #0x8]
1000a82f8:     	tbz	w8, #0x0, 0x1000a8380 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x94>
1000a82fc:     	mov	x8, #0x0                ; =0
1000a8300:     	ldr	x10, [x1]
1000a8304:     	cbz	x10, 0x1000a83c4 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xd8>
1000a8308:     	sub	x11, x10, #0x1
1000a830c:     	and	x12, x11, x8
1000a8310:     	udiv	x13, x8, x10
1000a8314:     	msub	x8, x13, x10, x8
1000a8318:     	tst	x10, x11
1000a831c:     	csel	x8, x12, x8, eq
1000a8320:     	ldr	x11, [x1, #0x10]
1000a8324:     	mov	w12, #0x110             ; =272
1000a8328:     	mov	x13, x10
1000a832c:     	mov	x2, x10
1000a8330:     	b	0x1000a8350 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x64>
1000a8334:     	cmp	x2, x10
1000a8338:     	csel	x2, x8, x2, eq
1000a833c:     	add	x14, x8, #0x1
1000a8340:     	cmp	x14, x10
1000a8344:     	csinc	x8, xzr, x8, hs
1000a8348:     	subs	x13, x13, #0x1
1000a834c:     	b.eq	0x1000a83c8 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xdc>
1000a8350:     	madd	x14, x8, x12, x11
1000a8354:     	ldr	w15, [x14]
1000a8358:     	cmp	w15, #0x1
1000a835c:     	b.eq	0x1000a8334 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x48>
1000a8360:     	cmp	w15, #0x2
1000a8364:     	b.ne	0x1000a8414 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x128>
1000a8368:     	ldr	x14, [x14, #0x8]
1000a836c:     	cmp	x14, x3
1000a8370:     	b.ne	0x1000a833c <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x50>
1000a8374:     	mov	x2, x8
1000a8378:     	mov	x4, x9
1000a837c:     	b	0x1000ab258 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449>
1000a8380:     	ldr	x8, [x4]
1000a8384:     	eor	x8, x8, x3
1000a8388:     	eor	x8, x8, x8, lsr #30
1000a838c:     	mov	x10, #0xe5b9            ; =58809
1000a8390:     	movk	x10, #0x1ce4, lsl #16
1000a8394:     	movk	x10, #0x476d, lsl #32
1000a8398:     	movk	x10, #0xbf58, lsl #48
1000a839c:     	mul	x8, x8, x10
1000a83a0:     	eor	x8, x8, x8, lsr #27
1000a83a4:     	mov	x10, #0x11eb            ; =4587
1000a83a8:     	movk	x10, #0x1331, lsl #16
1000a83ac:     	movk	x10, #0x49bb, lsl #32
1000a83b0:     	movk	x10, #0x94d0, lsl #48
1000a83b4:     	mul	x8, x8, x10
1000a83b8:     	eor	x8, x8, x8, lsr #31
1000a83bc:     	ldr	x10, [x1]
1000a83c0:     	cbnz	x10, 0x1000a8308 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x1c>
1000a83c4:     	mov	x2, #0x0                ; =0
1000a83c8:     	cmp	x2, x10
1000a83cc:     	b.hs	0x1000a8424 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x138>
1000a83d0:     	ldr	x8, [x1, #0x18]
1000a83d4:     	lsr	x10, x8, #13
1000a83d8:     	cbnz	x10, 0x1000a8424 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x138>
1000a83dc:     	add	x8, x8, #0x1
1000a83e0:     	str	x8, [x1, #0x18]
1000a83e4:     	ldr	x8, [x1, #0x10]
1000a83e8:     	mov	w10, #0x110             ; =272
1000a83ec:     	mul	x10, x2, x10
1000a83f0:     	ldr	w8, [x8, x10]
1000a83f4:     	cmp	w8, #0x1
1000a83f8:     	b.ne	0x1000a840c <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x120>
1000a83fc:     	ldr	x8, [x1, #0x20]
1000a8400:     	subs	x8, x8, #0x1
1000a8404:     	csel	x8, xzr, x8, lo
1000a8408:     	str	x8, [x1, #0x20]
1000a840c:     	mov	x4, x9
1000a8410:     	b	0x1000ab258 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449>
1000a8414:     	cmp	x2, x10
1000a8418:     	csel	x2, x8, x2, eq
1000a841c:     	cmp	x2, x10
1000a8420:     	b.lo	0x1000a83d0 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xe4>
1000a8424:     	ldp	q0, q1, [x9]
1000a8428:     	ldp	q2, q3, [x9, #0x20]
1000a842c:     	ldp	q4, q5, [x9, #0x40]
1000a8430:     	ldp	q6, q7, [x9, #0x60]
1000a8434:     	ldp	q16, q17, [x9, #0x80]
1000a8438:     	ldp	q18, q19, [x9, #0xa0]
1000a843c:     	ldp	q20, q21, [x9, #0xc0]
1000a8440:     	ldp	q22, q23, [x9, #0xe0]
1000a8444:     	stp	xzr, x3, [x0]
1000a8448:     	mov	w8, #0x1                ; =1
1000a844c:     	str	w8, [x0]
1000a8450:     	strb	w8, [x0, #0x4]
1000a8454:     	stp	q0, q1, [x0, #0x10]
1000a8458:     	stp	q2, q3, [x0, #0x30]
1000a845c:     	stp	q4, q5, [x0, #0x50]
1000a8460:     	stp	q6, q7, [x0, #0x70]
1000a8464:     	stp	q16, q17, [x0, #0x90]
1000a8468:     	stp	q18, q19, [x0, #0xb0]
1000a846c:     	stp	q20, q21, [x0, #0xd0]
1000a8470:     	stp	q22, q23, [x0, #0xf0]
1000a8474:     	ret

