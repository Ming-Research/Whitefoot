#include <stdbool.h>
#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "reference-hash.h"

typedef struct { unsigned slot, probes; bool inserted; } Outcome;
static unsigned fault;
static void check(bool ok, const char *what) {
    if (!ok) { fprintf(stderr,"FAILED: %s\n",what); exit(1); }
}
static Outcome insert(unsigned char *occupied, unsigned cap, unsigned home) {
    unsigned cursor=home;
    for (unsigned seen=0; seen<cap; ++seen) {
        if (!occupied[cursor]) {
            occupied[cursor]=1;
            return (Outcome){cursor,seen+(fault==2 ? 0 : 1),true};
        }
        ++cursor;
        if (cursor==cap) {
            if (fault==1) return (Outcome){cap,seen+1,false};
            cursor=0;
        }
    }
    return (Outcome){cap,cap,fault==3};
}
static Outcome reference(unsigned char *occupied,unsigned cap,unsigned home) {
    for(unsigned step=0;step<cap;++step) {
        unsigned slot=(home+step)%cap;
        if (!occupied[slot]) { occupied[slot]=1; return (Outcome){slot,step+1,true}; }
    }
    return (Outcome){cap,cap,false};
}
static void expect(Outcome a,unsigned slot,unsigned probes,bool inserted) {
    check(a.slot==slot && a.probes==probes && a.inserted==inserted,"hand-derived probe outcome");
}
static uint64_t model_hash(uint64_t index,uint64_t seed) {
    uint64_t x=(index*2+1)^(seed^UINT64_C(11400714819323198485));
    x=(x^(x>>30))*UINT64_C(13787848793156543929);
    x=(x^(x>>27))*UINT64_C(10723151780598845931);
    return x^(x>>31);
}
static void checks(void) {
    unsigned char a[8]={0};
    expect(insert(a,0,0),0,0,false);
    expect(insert(a,4,3),3,1,true);
    expect(insert(a,4,3),0,2,true);
    expect(insert(a,4,3),1,3,true);
    expect(insert(a,4,1),2,2,true);
    expect(insert(a,4,2),4,4,false);
    memset(a,0,sizeof(a));
    expect(insert(a,1,0),0,1,true); expect(insert(a,1,0),1,1,false);
    uint64_t sequences=0,steps=0;
    for(unsigned cap=1;cap<=5;++cap) {
        unsigned total=1; for(unsigned k=0;k<5;++k)total*=cap;
        for(unsigned seq=0;seq<total;++seq) {
            unsigned char left[8]={0},right[8]={0}; unsigned digits=seq;
            for(unsigned k=0;k<5;++k) {
                unsigned home=digits%cap; digits/=cap;
                Outcome x=insert(left,cap,home),y=reference(right,cap,home);
                check(x.slot==y.slot && x.probes==y.probes && x.inserted==y.inserted,
                      "independent modulo reference");
                check(memcmp(left,right,sizeof(left))==0,"reference occupancy"); ++steps;
            }
            ++sequences;
        }
    }
    const uint64_t edges[]={0,1,2,31,2047,2559,UINT64_MAX/2,UINT64_MAX};
    for(unsigned i=0;i<sizeof(edges)/sizeof(*edges);++i)
      for(unsigned s=0;s<sizeof(edges)/sizeof(*edges);++s) {
        HashEnv env={edges[s]^UINT64_C(0x9e3779b97f4a7c15),false};
        uint64_t key=key_at(edges[i]);
        check(key_equal(&env,&key,&key),"pinned C equality is reflexive");
        check(model_hash(edges[i],edges[s])==key_hash(&env,&key),"pinned C hash/key cross-check");
      }
    for(unsigned cap=1;cap<=9;++cap)
      for(unsigned i=0;i<cap;++i) check(successor(i,cap)==(i+1)%cap,"pinned C cursor cross-check");
    printf("checks: manual zero/collision/wrap/full; %"PRIu64" independent sequences / %"PRIu64" steps; 64 hash edges; 45 cursor edges\n",sequences,steps);
}
static void model(unsigned size,unsigned cap) {
    unsigned contexts=size==64?256:8, batches=size==64?128:64;
    unsigned initial=size/2,window=size/8;
    uint64_t histogram[8193]={0},position_sum[512]={0},position_n[512]={0};
    unsigned position_max[512]={0},maximum=0;
    uint64_t sum=0,n=0,owners=0;
    unsigned char occupied[8192];
    for(unsigned sample=0;sample<12;++sample) {
        uint64_t ss=0,sn=0; unsigned sm=0;
        for(unsigned b=0;b<batches;++b) for(unsigned ctx=0;ctx<contexts;++ctx) {
            uint64_t seed=101+sample+b*contexts+ctx;
            memset(occupied,0,cap); ++owners;
            for(unsigned i=0;i<initial+window;++i) {
                unsigned home=(unsigned)(model_hash(i,seed)%cap);
                Outcome x=insert(occupied,cap,home);
                check(x.inserted,"fresh distinct key fits physical capacity");
                if(i>=initial) {
                    unsigned pos=i-initial;
                    ++histogram[x.probes]; ++n; sum+=x.probes;
                    ++sn; ss+=x.probes; if(x.probes>sm)sm=x.probes;
                    ++position_n[pos]; position_sum[pos]+=x.probes;
                    if(x.probes>position_max[pos])position_max[pos]=x.probes;
                    if(x.probes>maximum)maximum=x.probes;
                }
            }
        }
        printf("sample,%u,%u,%u,%"PRIu64",%"PRIu64",%u,%.12f\n",size,cap,sample,sn,ss,sm,(double)ss/sn);
    }
    check(n==UINT64_C(3145728),"exact retained observation count");
    printf("total,%u,%u,0,%"PRIu64",%"PRIu64",%u,%.12f\n",size,cap,n,sum,maximum,(double)sum/n);
    printf("owners,%u,%u,0,%"PRIu64",0,0,0\n",size,cap,owners);
    for(unsigned i=1;i<=cap;++i)if(histogram[i])
        printf("histogram,%u,%u,%u,%"PRIu64",%"PRIu64",%u,%u\n",size,cap,i,histogram[i],histogram[i]*i,i,i);
    for(unsigned i=0;i<window;++i)
        printf("position,%u,%u,%u,%"PRIu64",%"PRIu64",%u,%.12f\n",size,cap,i,position_n[i],position_sum[i],position_max[i],(double)position_sum[i]/position_n[i]);
}
int main(int argc,char **argv) {
    if(argc==3 && strcmp(argv[1],"fault")==0) { fault=(unsigned)strtoul(argv[2],NULL,10); check(fault>=1&&fault<=3,"known fault"); checks(); return 0; }
    checks();
    if(argc==2 && strcmp(argv[1],"check")==0)return 0;
    check(argc==1,"known invocation");
    puts("kind,entry_floor,physical_capacity,index,observations,probe_sum,max_probes,mean_probes");
    model(64,85); model(64,128); model(4096,5461); model(4096,8192);
    return 0;
}
