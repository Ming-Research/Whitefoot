from pathlib import Path
import csv,io,json
p=Path(__file__).resolve().parent
text=(p/'model.stdout').read_text(); rows=list(csv.DictReader(io.StringIO(text[text.index('kind,'):])) )
out=[]
for size,oldcap,newcap in [(64,85,128),(4096,5461,8192)]:
    arms=[]
    for cap in [oldcap,newcap]:
        rs=[r for r in rows if int(r['entry_floor'])==size and int(r['physical_capacity'])==cap]
        total=next(r for r in rs if r['kind']=='total'); n=int(total['observations']); totalprobes=int(total['probe_sum'])
        hist={int(r['index']):int(r['observations']) for r in rs if r['kind']=='histogram'}
        assert sum(hist.values())==n and sum(k*v for k,v in hist.items())==totalprobes
        for kind in ['sample','position']:
            selected=[r for r in rs if r['kind']==kind]
            assert sum(int(r['observations']) for r in selected)==n
            assert sum(int(r['probe_sum']) for r in selected)==totalprobes
        quantiles={}
        for label,portion in [('p50',.5),('p90',.9),('p99',.99)]:
            cumulative=0
            for probes,count in sorted(hist.items()):
                cumulative+=count
                if cumulative>=n*portion:quantiles[label]=probes;break
        arms.append(dict(capacity=cap,observations=n,probe_sum=totalprobes,mean=totalprobes/n,max=max(hist),histogram=hist,quantiles=quantiles,first_probe_fraction=hist[1]/n,position_mean_min=min(float(r['mean_probes']) for r in rs if r['kind']=='position'),position_mean_max=max(float(r['mean_probes']) for r in rs if r['kind']=='position')))
    reduction=1-arms[1]['probe_sum']/arms[0]['probe_sum']
    out.append(dict(entry_floor=size,arms=arms,probe_reduction_percent=100*reduction,backing_cell_increase_percent=100*(newcap/oldcap-1)))
classification='strong' if all(x['probe_reduction_percent']>=25 for x in out) else 'deprioritize' if all(x['probe_reduction_percent']<10 for x in out) else 'intermediate: no automatic timing go'
(p/'reduction.json').write_text(json.dumps(dict(cells=out,classification=classification,model='WF first-vacant scalar linear probing only; no elapsed-time or peer inference'),indent=2)+'\n')
print(classification)
for x in out:print(x['entry_floor'],x['probe_reduction_percent'],x['backing_cell_increase_percent'])
